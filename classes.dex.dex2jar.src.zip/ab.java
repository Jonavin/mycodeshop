import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatHistory;

public final class ab
  implements View.OnClickListener
{
  public ab(ChatHistory paramChatHistory)
  {
  }

  public final void onClick(View paramView)
  {
    ChatHistory.access$1400(this.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ab
 * JD-Core Version:    0.5.4
 */