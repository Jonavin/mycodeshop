import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bj
  implements DialogInterface.OnClickListener
{
  public bj(ChatWindowActivity paramChatWindowActivity, int paramInt)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    }
    while (true)
    {
      return;
      ChatWindowActivity localChatWindowActivity1 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      int i = this.jdField_a_of_type_Int;
      ChatWindowActivity.access$3200(localChatWindowActivity1, i);
      continue;
      ChatWindowActivity localChatWindowActivity2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      int j = this.jdField_a_of_type_Int;
      ChatWindowActivity.access$3300(localChatWindowActivity2, j);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bj
 * JD-Core Version:    0.5.4
 */