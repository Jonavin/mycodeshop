import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.adapter.FriendListAdapter;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.qphone.base.remote.AppUpdateInfo;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.QLog;
import java.util.ArrayList;

public final class ch extends BaseActionListener
{
  public ch(ContactActivity paramContactActivity)
  {
  }

  public final void onActionResult(FromServiceMsg paramFromServiceMsg)
  {
    Object localObject1 = 1;
    int i = 1000;
    String str1 = paramFromServiceMsg.serviceCmd;
    Object localObject3;
    Object localObject7;
    Object localObject2;
    try
    {
      boolean bool = "ProfileService.GetSimpleInfo".equals(str1);
      if (bool)
      {
        int j = paramFromServiceMsg.resultCode;
        if (j == i)
        {
          localObject3 = paramFromServiceMsg.extraData;
          localObject7 = "exist";
          localObject3 = ((Bundle)localObject3).getBoolean((String)localObject7);
          if (localObject3 != 0)
          {
            localObject7 = paramFromServiceMsg.extraData.getString("uin");
            localObject2 = ContactActivity.access$600(this.a).a().createEntityManager();
            localObject3 = (Friends)((EntityManager)localObject2).a(Friends.class, (String)localObject7);
            ((EntityManager)localObject2).a();
            localObject2 = ContactActivity.access$600(this.a).a();
            if (localObject2 != null)
            {
              String str2 = ((SimpleAccount)localObject2).getUin();
              if (((String)localObject7).equals(str2))
              {
                String str3 = ((Friends)localObject3).name;
                ((SimpleAccount)localObject2).setNickName((String)localObject3);
                ContactActivity.access$600(this.a).a().setSimpleUser((SimpleAccount)localObject2);
                FromServiceMsg localFromServiceMsg = ContactActivity.access$600(this.a).a().getSimpleUser((String)localObject7);
                String str4 = ((FromServiceMsg)localObject3).serviceCmd;
                SimpleAccount localSimpleAccount1 = (SimpleAccount)((FromServiceMsg)localObject3).getAttribute((String)localObject2);
                ContactActivity.access$600(this.a).a((SimpleAccount)localObject3);
                ContactActivity localContactActivity1 = this.a;
                ci localci = new ci(this);
                ((ContactActivity)localObject3).runOnUiThread((Runnable)localObject2);
              }
              BaseServiceHelper localBaseServiceHelper1 = ContactActivity.access$600(this.a).a();
              String str5 = ContactActivity.access$600(this.a).a().getUin();
              String[] arrayOfString1 = new String[1];
              arrayOfString1[0] = localObject7;
              ProfileUtil.getSignature(localBaseServiceHelper1, str5, arrayOfString1);
            }
          }
        }
      }
      do
      {
        label279: return;
        localObject7 = "ProfileService.GetSignature".equals(localObject3);
        if (localObject7 == 0)
          break label448;
        localObject3 = paramFromServiceMsg.extraData.getStringArray("array_uin");
        if ((localObject3 == null) || (localObject3.length != localObject1))
          break label414;
        Object localObject8 = localObject3[null];
        String str6 = ContactActivity.access$600(this.a).a().getUin();
        if (!((String)localObject3).equals(str6))
          break label414;
        QLog.i("System.out", "// 鍙栬嚜");
      }
      while (paramFromServiceMsg.resultCode != localObject2);
      SimpleAccount localSimpleAccount2 = ContactActivity.access$600(this.a).a();
      ContactActivity.access$600(this.a).a().setSimpleUser(localSimpleAccount2);
      label414: label1320: label448: ContactActivity.access$300(this.a).obtainMessage(10000).sendToTarget();
    }
    catch (Exception localException)
    {
      break label279:
      QLog.i("System.out", "// 鍙栧ソ");
      if (ContactActivity.access$700(this.a) != null);
      ContactActivity.access$700(this.a).a.onActionResult(paramFromServiceMsg);
      break label279:
      localObject7 = "friendlist.getFriendGroupList".equals(localObject3);
      if (localObject7 != 0)
      {
        ContactActivity.access$1900(this.a, paramFromServiceMsg);
        if (!ContactActivity.access$600(this.a).b);
        ContactActivity.access$600(this.a).b = true;
        ContactActivity.access$600(this.a).a().checkUpgrade();
      }
      localObject7 = "friendlist.getTroopList".equals(localObject3);
      if (localObject7 != 0)
      {
        ContactActivity localContactActivity2 = this.a;
        cj localcj = new cj(this, paramFromServiceMsg);
        localContactActivity2.runOnUiThread(localcj);
        if (ContactActivity.access$2100(this.a));
        ContactActivity.access$300(this.a).obtainMessage(10001, null).sendToTarget();
      }
      localObject7 = "MessageSvc.BatchGetGroupFilter".equals(localObject3);
      Object localObject4;
      if (localObject7 != 0)
      {
        localObject4 = paramFromServiceMsg.resultCode;
        if (localObject4 == localObject2)
        {
          String[] arrayOfString2 = paramFromServiceMsg.extraData.getStringArray("group_codes");
          int[] arrayOfInt1 = paramFromServiceMsg.extraData.getIntArray("group_ops");
          ContactActivity.access$600(this.a).a(arrayOfString2, arrayOfInt1);
          ContactActivity localContactActivity3 = this.a;
          ck localck = new ck(this);
          localContactActivity3.runOnUiThread(localck);
          ContactActivity.access$600(this.a).b();
        }
        localObject4 = ContactActivity.access$600(this.a).a().getUin();
        localObject4 = this.a.getSharedPreferences((String)localObject4, 0);
        if (((SharedPreferences)localObject4).getLong("receiveAllTroopsnews", 3L) == 2L);
        SharedPreferences.Editor localEditor = ((SharedPreferences)localObject4).edit();
        ((SharedPreferences.Editor)localObject4).putLong("receiveAllTroopsnews", 3L);
        ((SharedPreferences.Editor)localObject4).commit();
        String[] arrayOfString3 = paramFromServiceMsg.extraData.getStringArray("group_codes");
        BaseServiceHelper localBaseServiceHelper2 = ContactActivity.access$600(this.a).a();
        BaseActionListener localBaseActionListener = ContactActivity.access$2200(this.a);
        String str7 = ContactActivity.access$600(this.a).a().getUin();
        ProfileUtil.SvcRequestBatchGetGroupFilter(localBaseServiceHelper2, localBaseActionListener, str7, localObject4);
      }
      localObject7 = "MessageSvc.BatchSetGroupFilter".equals(localObject4);
      if (localObject7 != 0)
      {
        if (paramFromServiceMsg.resultCode != localObject2);
        String[] arrayOfString4 = paramFromServiceMsg.extraData.getStringArray("group_codes");
        int[] arrayOfInt2 = paramFromServiceMsg.extraData.getIntArray("group_oops");
        ContactActivity.access$600(this.a).a(arrayOfString4, arrayOfInt2);
        ContactActivity localContactActivity4 = this.a;
        cl localcl = new cl(this);
        localContactActivity4.runOnUiThread(localcl);
      }
      localObject7 = "friendlist.getOnlineFriend".equals(localObject4);
      if (localObject7 != 0)
      {
        if (paramFromServiceMsg.resultCode == localObject2);
        ContactActivity localContactActivity5 = this.a;
        cm localcm = new cm(this);
        localContactActivity5.runOnUiThread(localcm);
      }
      localObject7 = "friendlist.delFriend".equals(localObject4);
      if (localObject7 != 0)
      {
        if (paramFromServiceMsg.resultCode != localObject2);
        ContactActivity localContactActivity6 = this.a;
        cn localcn = new cn(this);
        localContactActivity6.runOnUiThread(localcn);
      }
      localObject7 = "ProfileService.getGroupInfoReq".equals(localObject4);
      if (localObject7 != 0)
      {
        localObject5 = paramFromServiceMsg.resultCode;
        if (localObject5 == localObject2);
        localObject5 = (TroopInfo)paramFromServiceMsg.getAttribute("TroopInfo");
        if (localObject5 != null);
        QQApplication localQQApplication1 = ContactActivity.access$600(this.a);
        String str8 = ((TroopInfo)localObject5).troopuin;
        String str9 = ((TroopInfo)localObject5).troopname;
        localQQApplication1.b(str8, str9);
        QQApplication localQQApplication2 = ContactActivity.access$600(this.a);
        String str10 = ((TroopInfo)localObject5).troopuin;
        String str11 = ((TroopInfo)localObject5).troopmemo;
        localQQApplication2.c(str10, (String)localObject5);
        ContactActivity localContactActivity7 = this.a;
        co localco = new co(this);
        ((ContactActivity)localObject5).runOnUiThread(localco);
      }
      localObject7 = "CImgService.GetUserDefineAvatar".equals(localObject5);
      if (localObject7 != 0)
      {
        if (paramFromServiceMsg.resultCode == localObject2);
        String str12 = paramFromServiceMsg.extraData.getString("uin");
        String str13 = ContactActivity.access$600(this.a).a().getUin();
        if (str12.equals(str13))
          ContactActivity.access$300(this.a).sendEmptyMessage(10000);
        ContactActivity.access$300(this.a).removeMessages(1007);
        ContactActivity.access$300(this.a).sendEmptyMessageDelayed(1007, 500L);
      }
      localObject7 = "MessageSvc.GetGroupMsg".equals(localObject5);
      if (localObject7 == 0)
      {
        localObject7 = "MessageSvc.PushGroupMsg".equals(localObject5);
        if (localObject7 == 0)
        {
          localObject7 = "MessageSvc.getmsg".equals(localObject5);
          if (localObject7 == 0)
            break label1320;
        }
      }
      ContactActivity.access$300(this.a).removeMessages(1003);
      ContactActivity.access$300(this.a).sendEmptyMessageDelayed(1003, 500L);
      break label279:
      localObject7 = "StatSvc.register".equals(localObject5);
      if (localObject7 != 0)
        if (paramFromServiceMsg.resultCode != localObject2);
      localObject7 = "ConfigService.ClientReq";
      Object localObject5 = ((String)localObject7).equals(localObject5);
      if (localObject5 != 0);
      Object localObject6 = paramFromServiceMsg.resultCode;
      if (localObject6 == localObject2);
      localObject6 = paramFromServiceMsg.getServiceCmd();
      localObject6 = (ArrayList)paramFromServiceMsg.getAttribute((String)localObject6);
      localObject7 = null;
      if (((ArrayList)localObject6).size() > 0);
      for (localObject6 = (AppUpdateInfo)((ArrayList)localObject6).get(0); ; localObject6 = localObject7)
      {
        if ((localObject6 != null) && (((AppUpdateInfo)localObject6).getiResult() == 0));
        ContactActivity localContactActivity8 = this.a;
        String str14 = ((AppUpdateInfo)localObject6).getStrTitle();
        localContactActivity8.a = str14;
        ContactActivity localContactActivity9 = this.a;
        String str15 = ((AppUpdateInfo)localObject6).getStrUpgradeDesc();
        localContactActivity9.b = str15;
        ContactActivity localContactActivity10 = this.a;
        String str16 = ((AppUpdateInfo)localObject6).getStrUrl();
        localContactActivity10.c = str16;
        localObject6 = ((AppUpdateInfo)localObject6).getiUpgradeType();
        if (localObject6 == 2)
        {
          ContactActivity localContactActivity11 = this.a;
          cp localcp = new cp(this);
          localContactActivity11.runOnUiThread(localcp);
        }
        if (localObject6 == localObject1);
        ContactActivity localContactActivity12 = this.a;
        cq localcq = new cq(this);
        localContactActivity12.runOnUiThread(localcq);
        break label279:
      }
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ch
 * JD-Core Version:    0.5.4
 */