import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ChatWindowActivity.MessageListView;
import com.tencent.mobileqq.adapter.ChatMessageListAdapter;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;

public final class bk extends Handler
{
  public bk(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    int i = 0;
    int j = 1;
    float f1 = null;
    int k = paramMessage.what;
    switch (k)
    {
    case 2:
    default:
    case 4:
    case 0:
    case 1:
    case 3:
    case 6:
    case 5:
    case 7:
    }
    while (true)
    {
      return;
      int l = ChatWindowActivity.access$2100(this.a);
      if (l != 0)
        continue;
      ImageView localImageView = (ImageView)this.a.findViewById(16908294);
      if (localImageView == null)
        continue;
      Friends localFriends = (Friends)paramMessage.obj;
      QQApplication localQQApplication = this.a.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      int i1 = localFriends.faceid;
      String str1 = this.a.jdField_a_of_type_JavaLangString;
      ChatWindowActivity localChatWindowActivity1 = this.a;
      int i2 = localFriends.status;
      int i3 = localFriends.sqqOnLineState;
      boolean bool = ChatWindowActivity.access$4000(localChatWindowActivity1, i2, i3);
      Drawable localDrawable = localQQApplication.b(i1, str1, bool);
      localImageView.setImageDrawable(localDrawable);
      continue;
      ChatMessageListAdapter localChatMessageListAdapter = ChatWindowActivity.access$100(this.a);
      String str2 = this.a.jdField_a_of_type_JavaLangString;
      int i4 = ChatWindowActivity.access$2100(this.a);
      localChatMessageListAdapter.a(str2, i4, j);
      if (ChatWindowActivity.access$2100(this.a) != j)
        continue;
      this.a.jdField_a_of_type_ComTencentMobileqqAppQQApplication.g();
      continue;
      ChatWindowActivity.access$4100(this.a);
      continue;
      View localView1 = this.a.findViewById(2131493075);
      GridView localGridView = (GridView)this.a.findViewById(2131493076);
      if (localGridView.getVisibility() != 0)
        continue;
      float f2 = localGridView.getHeight();
      ChatWindowActivity localChatWindowActivity2 = this.a;
      float f3 = f1 - f2;
      float f4 = f1;
      float f5 = f1;
      ChatWindowActivity.access$2000(localChatWindowActivity2, localGridView, f1, f4, f5, f3);
      float f6 = localView1.getHeight();
      ChatWindowActivity localChatWindowActivity3 = this.a;
      View localView2 = localView1;
      float f7 = f1;
      float f8 = f1;
      ChatWindowActivity.access$2000(localChatWindowActivity3, localGridView, f1, f7, f6, f8);
      ChatWindowActivity.access$1400(this.a).setVisibility(i);
      continue;
      if (this.a.jdField_a_of_type_JavaLangString.equals("10000"))
        continue;
      ChatWindowActivity.access$4200(this.a).setVisibility(i);
      sendEmptyMessageDelayed(7, 100L);
      continue;
      ChatWindowActivity.access$4200(this.a).setVisibility(8);
      continue;
      ChatWindowActivity.MessageListView localMessageListView = ChatWindowActivity.access$2300(this.a);
      int i5 = ChatWindowActivity.access$100(this.a).getCount() - j;
      localMessageListView.setSelection(i5);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bk
 * JD-Core Version:    0.5.4
 */