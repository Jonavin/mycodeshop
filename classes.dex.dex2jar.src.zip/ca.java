public abstract interface ca
{
  public abstract void a(int paramInt1, int paramInt2);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ca
 * JD-Core Version:    0.5.4
 */