import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.mobileqq.activity.AddFriendActivity;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.service.friendlist.FriendListUtil;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseServiceHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

final class b
  implements Runnable
{
  b(a parama, FromServiceMsg paramFromServiceMsg)
  {
  }

  public final void run()
  {
    int i = 1;
    int k = 1000;
    int l = 5;
    ViewGroup localViewGroup1 = null;
    int i1 = 0;
    AddFriendActivity.access$000(this.jdField_a_of_type_A.a).dismiss();
    Object localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.serviceCmd;
    boolean bool = "ProfileService.GetSimpleInfo".equals(localObject2);
    Object localObject3;
    Object localObject5;
    Object localObject1;
    if (bool)
    {
      int i2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.resultCode;
      if (i2 == k)
      {
        localObject3 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData;
        localObject2 = "exist";
        localObject3 = ((Bundle)localObject3).getBoolean((String)localObject2);
        if (localObject3 != 0)
        {
          localObject5 = new ArrayList();
          localObject3 = new HashMap();
          localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("uin");
          ((Map)localObject3).put("uin", localObject1);
          localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("name");
          ((Map)localObject3).put("nickname", localObject1);
          localObject2 = "sex";
          localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getByte("sex");
          if (localObject1 == 0)
          {
            localObject1 = "�";
            label182: ((Map)localObject3).put(localObject2, localObject1);
            String str1 = String.valueOf(this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getByte("age"));
            ((Map)localObject3).put("age", localObject1);
            String str2 = String.valueOf(this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getShort("faceID"));
            ((Map)localObject3).put("faceID", localObject1);
            Friends localFriends1 = AddFriendActivity.access$100(this.jdField_a_of_type_A.a);
            String str3 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("uin");
            ((Friends)localObject2).uin = ((String)localObject1);
            Friends localFriends2 = AddFriendActivity.access$100(this.jdField_a_of_type_A.a);
            String str4 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("name");
            ((Friends)localObject2).name = ((String)localObject1);
            ((List)localObject5).add(localObject3);
            HashSet localHashSet = new HashSet();
            AddFriendActivity localAddFriendActivity1 = this.jdField_a_of_type_A.a;
            String[] arrayOfString = new String[4];
            arrayOfString[i1] = "uin";
            arrayOfString[i] = "nickname";
            arrayOfString[2] = "sex";
            arrayOfString[3] = "age";
            int[] arrayOfInt = { 2131492864, 2131492874, 2131492875, 2131492876 };
            b localb1 = this;
            Object localObject6 = localObject5;
            c localc = new c((b)localObject2, (Context)localObject1, (List)localObject5, arrayOfString, i, localObject6, localHashSet);
            AddFriendActivity.access$200(this.jdField_a_of_type_A.a).setAdapter((ListAdapter)localObject3);
            AddFriendActivity.access$200(this.jdField_a_of_type_A.a).setVisibility(i1);
          }
        }
      }
    }
    while (true)
    {
      label455: return;
      localObject1 = "�";
      break label182:
      AddFriendActivity localAddFriendActivity2 = this.jdField_a_of_type_A.a;
      AlertDialog localAlertDialog1 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
      AddFriendActivity.access$400(localAddFriendActivity2, localAlertDialog1, "鎮ㄦ煡鎵剧殑甯愬彿涓嶅");
      continue;
      AddFriendActivity localAddFriendActivity3 = this.jdField_a_of_type_A.a;
      AlertDialog localAlertDialog2 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
      AddFriendActivity.access$400(localAddFriendActivity3, localAlertDialog2, "璇疯緭�");
      continue;
      localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.serviceCmd;
      localObject3 = "friendlist.getUserAddFriendSetting".equals(localObject2);
      if (localObject3 != 0)
      {
        if (this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.resultCode == localObject1)
        {
          localObject5 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getInt("setting");
          localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("uin");
          ArrayList localArrayList = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getStringArrayList("user_question");
          View localView = this.jdField_a_of_type_A.a.getLayoutInflater().inflate(2130903044, localViewGroup1);
          TextView localTextView1 = (TextView)localView.findViewById(2131492878);
          String str5 = AddFriendActivity.access$100(this.jdField_a_of_type_A.a).name;
          localTextView1.setText(str5);
          ((TextView)localView.findViewById(2131492879)).setText((CharSequence)localObject1);
          switch (localObject5)
          {
          default:
            break;
          case 0:
            BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_A.a.a.a();
            String str6 = this.jdField_a_of_type_A.a.a.a().getUin();
            int i3 = i;
            int i4 = i1;
            FriendListUtil.addFriend(localBaseServiceHelper, str6, (String)localObject1, localObject5, i3, i, localViewGroup1);
            AddFriendActivity localAddFriendActivity4 = this.jdField_a_of_type_A.a;
            ProgressDialog localProgressDialog = AddFriendActivity.access$000(this.jdField_a_of_type_A.a);
            AddFriendActivity.access$400(localAddFriendActivity4, localProgressDialog, "姝ｅ湪鍙�");
            break;
          case 1:
            EditText localEditText1 = (EditText)localView.findViewById(2131492870);
            localEditText1.setHint("璇疯緭鍏ユ坊�");
            AddFriendActivity localAddFriendActivity5 = this.jdField_a_of_type_A.a;
            AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localAddFriendActivity5).setTitle("娣诲").setView(localView);
            d locald = new d(this, (String)localObject1, localObject5, localEditText1);
            AlertDialog localAlertDialog3 = localBuilder1.setPositiveButton("鍙", locald).setNegativeButton("杩", localViewGroup1).create();
            localAlertDialog3.getWindow().setSoftInputMode(l);
            localAlertDialog3.show();
            break;
          case 2:
            AddFriendActivity localAddFriendActivity6 = this.jdField_a_of_type_A.a;
            AlertDialog localAlertDialog4 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
            AddFriendActivity.access$400(localAddFriendActivity6, localAlertDialog4, "瀵规柟鎷");
            break;
          case 3:
            String str7 = (String)localArrayList.get(i1);
            TextView localTextView2 = (TextView)localView.findViewById(2131492864);
            String str8 = "瀵规柟闇��" + str7;
            localTextView2.setText(str8);
            localTextView2.setVisibility(i1);
            EditText localEditText2 = (EditText)localView.findViewById(2131492870);
            localView.findViewById(2131492888);
            AddFriendActivity localAddFriendActivity7 = this.jdField_a_of_type_A.a;
            AddFriendActivity localAddFriendActivity8 = this.jdField_a_of_type_A.a;
            AlertDialog.Builder localBuilder2 = new AlertDialog.Builder(localAddFriendActivity8).setTitle("娣诲").setView(localView);
            e locale = new e(this, localEditText2, (String)localObject1, localObject5);
            AlertDialog localAlertDialog5 = localView.setPositiveButton("鍙", locale).setNegativeButton("杩", localViewGroup1).create();
            AddFriendActivity.access$502(localAddFriendActivity7, localAlertDialog5);
            AddFriendActivity.access$500(this.jdField_a_of_type_A.a).getWindow().setSoftInputMode(l);
            AddFriendActivity.access$500(this.jdField_a_of_type_A.a).show();
            break;
          case 4:
          }
          ViewGroup localViewGroup2 = (ViewGroup)localView.findViewById(2131492880);
          StringBuffer localStringBuffer = new StringBuffer();
          i = i1;
          while (true)
          {
            int i5 = localArrayList.size();
            if (i >= i5)
              break;
            String str9 = (String)localArrayList.get(i);
            int i6 = i * 2;
            TextView localTextView3 = (TextView)localViewGroup2.getChildAt(i6);
            localTextView3.setVisibility(i1);
            StringBuilder localStringBuilder = new StringBuilder();
            CharSequence localCharSequence = localTextView3.getText();
            String str10 = localCharSequence + ":" + str9;
            localTextView3.setText(str10);
            int i7 = i * 2;
            ++localObject2;
            ((EditText)localViewGroup2.getChildAt(i7)).setVisibility(i1);
            int i8 = i + 1;
            String str11 = "闂" + i8 + ":" + str9;
            localStringBuffer.append(str11);
            localStringBuffer.append("\n");
            localStringBuffer.append("鍥炵瓟:${ans");
            localStringBuffer.append("\n");
            int j;
            i += 1;
          }
          AddFriendActivity localAddFriendActivity9 = this.jdField_a_of_type_A.a;
          AlertDialog.Builder localBuilder3 = new AlertDialog.Builder(localAddFriendActivity9).setTitle("娣诲").setView(localView);
          b localb2 = this;
          Object localObject7 = localObject1;
          int i9 = localObject5;
          g localg = new g(localb2, localStringBuffer, localArrayList, localViewGroup2, localObject7, i9);
          AlertDialog localAlertDialog6 = localBuilder3.setPositiveButton("鍙", localg).setNegativeButton("杩", localViewGroup1).create();
          localAlertDialog6.getWindow().setSoftInputMode(l);
          localAlertDialog6.show();
        }
        AddFriendActivity localAddFriendActivity10 = this.jdField_a_of_type_A.a;
        AlertDialog localAlertDialog7 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
        AddFriendActivity.access$400(localAddFriendActivity10, localAlertDialog7, "璇锋�");
      }
      localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.serviceCmd;
      localObject3 = "friendlist.addFriend".equals(localObject2);
      if (localObject3 != 0)
      {
        Object localObject4 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.resultCode;
        if (localObject4 == localObject1)
        {
          localObject4 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getInt("setting");
          localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("uin");
          localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.extraData.getString("nickname");
          if (localObject1 == null)
            localObject1 = "";
          switch (localObject4)
          {
          case 2:
          default:
          case 0:
          case 3:
          case 1:
          case 4:
          }
          for (localObject4 = "璇锋眰�"; ; localObject4 = "鎮ㄧ殑濂藉弸娣诲姞璇锋�")
            while (true)
            {
              AddFriendActivity localAddFriendActivity11 = this.jdField_a_of_type_A.a;
              AlertDialog localAlertDialog8 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
              AddFriendActivity.access$400(localAddFriendActivity11, localAlertDialog8, (String)localObject4);
              break label455:
              localObject4 = "鎮ㄦ�" + (String)localObject1 + "(" + (String)localObject2 + ")涓�";
              localObject2 = this.jdField_a_of_type_A.a.a.a(ContactActivity.class);
              if (localObject2 == null)
                continue;
              ((Handler)localObject2).sendEmptyMessage(1005);
            }
        }
        if (AddFriendActivity.access$500(this.jdField_a_of_type_A.a) != null)
        {
          AddFriendActivity.access$500(this.jdField_a_of_type_A.a).findViewById(2131492888).setVisibility(i1);
          AddFriendActivity.access$500(this.jdField_a_of_type_A.a).getWindow().setSoftInputMode(l);
          AddFriendActivity.access$500(this.jdField_a_of_type_A.a).show();
        }
        AddFriendActivity localAddFriendActivity12 = this.jdField_a_of_type_A.a;
        AlertDialog localAlertDialog9 = AddFriendActivity.access$300(this.jdField_a_of_type_A.a);
        AddFriendActivity.access$400(localAddFriendActivity12, localAlertDialog9, "璇锋眰�");
      }
      String str12 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.serviceCmd;
      if (!"CImgService.GetUserDefineAvatar".equals(str12))
        continue;
      this = (BaseAdapter)AddFriendActivity.access$200(this.jdField_a_of_type_A.a).getAdapter();
      if (this == null)
        continue;
      super.notifyDataSetChanged();
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     b
 * JD-Core Version:    0.5.4
 */