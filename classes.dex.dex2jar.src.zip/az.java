import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.skin.SkinEngine;

public final class az
  implements View.OnClickListener
{
  public az(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    int i = 1065353216;
    float f1 = null;
    ChatWindowActivity localChatWindowActivity1 = this.a;
    String str = ChatWindowActivity.access$1202(this.a, null);
    ChatWindowActivity.access$1102(localChatWindowActivity1, str);
    ImageView localImageView1 = (ImageView)this.a.findViewById(2131493020);
    LinearLayout localLinearLayout1 = (LinearLayout)this.a.findViewById(2131492935);
    ChatWindowActivity localChatWindowActivity2 = this.a;
    LinearLayout localLinearLayout2 = ChatWindowActivity.access$1300(this.a);
    float f2 = -ChatWindowActivity.access$1600(this.a).getWidth();
    float f3 = f1;
    float f4 = f1;
    int j = i;
    ChatWindowActivity.access$1800(localChatWindowActivity2, localLinearLayout2, f1, f2, f3, f4, i, j);
    int k = ChatWindowActivity.access$2100(this.a);
    int l = ChatWindowActivity.access$2400(this.a);
    if (k != l)
    {
      if (ChatWindowActivity.access$2400(this.a) != 1)
        break label255;
      ChatWindowActivity.access$1700(this.a).setImageResource(2130837918);
    }
    while (true)
    {
      ChatWindowActivity.access$1500(this.a, localImageView1, i, f1);
      ChatWindowActivity.access$1500(this.a, localLinearLayout1, i, f1);
      ChatWindowActivity localChatWindowActivity3 = this.a;
      LinearLayout localLinearLayout3 = ChatWindowActivity.access$1400(this.a);
      ChatWindowActivity.access$1500(localChatWindowActivity3, localLinearLayout3, i, f1);
      ChatWindowActivity localChatWindowActivity4 = this.a;
      ImageView localImageView2 = ChatWindowActivity.access$1600(this.a);
      ChatWindowActivity.access$1500(localChatWindowActivity4, localImageView2, i, f1);
      ChatWindowActivity localChatWindowActivity5 = this.a;
      ImageView localImageView3 = ChatWindowActivity.access$1700(this.a);
      ChatWindowActivity.access$1500(localChatWindowActivity5, localImageView3, f1, i);
      return;
      label255: ChatWindowActivity.access$1700(this.a).setImageResource(2130837539);
      int i1 = ChatWindowActivity.access$1700(this.a).getId();
      Drawable localDrawable1 = ChatWindowActivity.access$1700(this.a).getDrawable();
      Drawable localDrawable2 = SkinEngine.getSkinDrawable(i1, "src", localDrawable1);
      ChatWindowActivity.access$1700(this.a).setImageDrawable(localDrawable2);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     az
 * JD-Core Version:    0.5.4
 */