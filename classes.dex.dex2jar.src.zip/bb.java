import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bb
  implements View.OnClickListener
{
  public bb(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity localChatWindowActivity = this.a;
    EditText localEditText = ChatWindowActivity.access$2600(this.a);
    ChatWindowActivity.access$2700(localChatWindowActivity, localEditText);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bb
 * JD-Core Version:    0.5.4
 */