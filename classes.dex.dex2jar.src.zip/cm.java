import com.tencent.mobileqq.activity.ContactActivity;

final class cm
  implements Runnable
{
  cm(ch paramch)
  {
  }

  public final void run()
  {
    ContactActivity.access$1800(this.a.a, null, null);
    ContactActivity.access$1700(this.a.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cm
 * JD-Core Version:    0.5.4
 */