import com.tencent.mobileqq.activity.AddFriendActivity;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.util.BaseActionListener;

public final class a extends BaseActionListener
{
  public a(AddFriendActivity paramAddFriendActivity)
  {
  }

  public final void onActionResult(FromServiceMsg paramFromServiceMsg)
  {
    AddFriendActivity localAddFriendActivity = this.a;
    b localb = new b(this, paramFromServiceMsg);
    localAddFriendActivity.runOnUiThread(localb);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     a
 * JD-Core Version:    0.5.4
 */