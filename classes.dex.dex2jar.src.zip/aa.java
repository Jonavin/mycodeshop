import android.text.Editable;
import android.text.TextWatcher;
import com.tencent.mobileqq.activity.ChatHistory;
import com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter;

public final class aa
  implements TextWatcher
{
  public aa(ChatHistory paramChatHistory)
  {
  }

  public final void afterTextChanged(Editable paramEditable)
  {
  }

  public final void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public final void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    if (paramCharSequence != null)
    {
      i = paramCharSequence.length();
      if (i == 0);
    }
    try
    {
      i = Integer.valueOf(paramCharSequence.toString()).intValue();
      label29: ChatHistory localChatHistory1 = this.a;
      int k = ChatHistory.access$1300(this.a);
      if (i >= k)
        break label149;
      ChatHistory.access$702(localChatHistory1, i);
      ChatHistory localChatHistory2 = this.a;
      int l = (ChatHistory.access$700(this.a) - 1) * 8;
      ChatHistory.access$802(localChatHistory2, l);
      ChatHistory.ChatHistoryAdapter localChatHistoryAdapter = ChatHistory.access$1100(this.a);
      String str = ChatHistory.access$900(this.a);
      int i1 = ChatHistory.access$1000(this.a);
      int i2 = ChatHistory.access$800(this.a);
      localChatHistoryAdapter.a(str, i1, i2);
      label149: return;
    }
    catch (Exception j)
    {
      int j = ChatHistory.access$1300(this.a);
      break label29:
      j = ChatHistory.access$1300(this.a);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     aa
 * JD-Core Version:    0.5.4
 */