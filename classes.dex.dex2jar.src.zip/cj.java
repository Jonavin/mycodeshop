import android.widget.Toast;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.qphone.base.remote.FromServiceMsg;

final class cj
  implements Runnable
{
  cj(ch paramch, FromServiceMsg paramFromServiceMsg)
  {
  }

  public final void run()
  {
    boolean bool = null;
    if (this.jdField_a_of_type_ComTencentQphoneBaseRemoteFromServiceMsg.resultCode == 1000)
      ContactActivity.access$2000(this.jdField_a_of_type_Ch.a, bool);
    while (true)
    {
      return;
      Toast.makeText(this.jdField_a_of_type_Ch.a, 2131296262, bool).show();
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cj
 * JD-Core Version:    0.5.4
 */