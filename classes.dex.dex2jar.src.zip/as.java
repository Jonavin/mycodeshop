import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.video.VideoController;

public final class as
  implements Runnable
{
  public as(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public final void run()
  {
    try
    {
      ChatVideoActivity localChatVideoActivity = this.a;
      ChatVideoActivity.access$000(localChatVideoActivity);
      VideoController.isVideoing = localChatVideoActivity;
      if (localChatVideoActivity == null)
      {
        VideoController localVideoController1 = ChatVideoActivity.access$000(this.a);
        long l1 = ChatVideoActivity.access$2400();
        Object localObject1;
        localVideoController1.b(localObject1);
        VideoController localVideoController2 = ChatVideoActivity.access$000(this.a);
        long l2 = ChatVideoActivity.access$2400();
        String str = this.a.getString(2131296442);
        Object localObject2;
        localVideoController2.a(localObject2, str);
      }
      return;
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     as
 * JD-Core Version:    0.5.4
 */