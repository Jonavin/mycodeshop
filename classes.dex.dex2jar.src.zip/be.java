import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class be
  implements View.OnTouchListener
{
  public be(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    Object localObject = null;
    if ((paramMotionEvent.getAction() == 1) || (paramMotionEvent.getAction() == 4))
    {
      this.a.b = localObject;
      this.a.c();
    }
    return localObject;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     be
 * JD-Core Version:    0.5.4
 */