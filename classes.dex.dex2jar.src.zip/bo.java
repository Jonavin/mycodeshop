import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bo
  implements Animation.AnimationListener
{
  public bo(ChatWindowActivity paramChatWindowActivity, float paramFloat)
  {
  }

  public final void onAnimationEnd(Animation paramAnimation)
  {
    if (this.jdField_a_of_type_Float >= null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.findViewById(2131493076).setVisibility(8);
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.findViewById(2131493075).setVisibility(0);
  }

  public final void onAnimationRepeat(Animation paramAnimation)
  {
  }

  public final void onAnimationStart(Animation paramAnimation)
  {
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bo
 * JD-Core Version:    0.5.4
 */