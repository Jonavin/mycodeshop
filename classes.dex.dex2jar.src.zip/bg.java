import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bg extends Handler
{
  public bg(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    ChatWindowActivity localChatWindowActivity = this.a;
    Intent localIntent = this.a.getIntent();
    ChatWindowActivity.access$000(localChatWindowActivity, localIntent);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bg
 * JD-Core Version:    0.5.4
 */