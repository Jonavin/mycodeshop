import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.utils.CacheUtils;
import java.util.Map;

public final class ce extends QQServiceEntry
{
  public ce(ChatWindowActivity paramChatWindowActivity, Context paramContext)
  {
    super(paramContext);
    a();
  }

  public final void onClick(View paramView)
  {
    int i = null;
    int j = 3;
    int k = 1065353216;
    float f1 = null;
    ChatWindowActivity localChatWindowActivity1 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
    ChatWindowActivity localChatWindowActivity2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
    Object localObject = null;
    String str = ChatWindowActivity.access$1202(localChatWindowActivity2, (String)localObject);
    ChatWindowActivity.access$1102(localChatWindowActivity1, str);
    View localView1 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.findViewById(2131493075);
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.findViewById(2131493076);
    QQServiceEntry.Tag localTag = (QQServiceEntry.Tag)paramView.getTag();
    if ((this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a.a.size() > 0) && (ChatWindowActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).getVisibility() == 0))
    {
      ChatWindowActivity.access$1400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(i);
      ChatWindowActivity localChatWindowActivity3 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      LinearLayout localLinearLayout1 = ChatWindowActivity.access$1400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ChatWindowActivity.access$1500(localChatWindowActivity3, localLinearLayout1, f1, k);
      ChatWindowActivity localChatWindowActivity4 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      ImageView localImageView1 = ChatWindowActivity.access$1600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ChatWindowActivity.access$1500(localChatWindowActivity4, localImageView1, k, f1);
      ChatWindowActivity localChatWindowActivity5 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      ImageView localImageView2 = ChatWindowActivity.access$1700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ChatWindowActivity.access$1500(localChatWindowActivity5, localImageView2, f1, k);
      ChatWindowActivity localChatWindowActivity6 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      LinearLayout localLinearLayout2 = ChatWindowActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i1 = this.jdField_a_of_type_Float;
      float f2 = 1108869120 * i;
      float f3 = f1;
      float f4 = f1;
      float f5 = f1;
      ChatWindowActivity.access$1800(localChatWindowActivity6, localLinearLayout2, f1, f2, i, f4, k, f5);
    }
    do
      while (true)
      {
        label253: return;
        if (localTag.a.getVisibility() != 0)
          break;
        ChatWindowActivity.access$1400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(i);
        ChatWindowActivity.access$1900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).removeMessages(j);
        float f6 = localTag.a.getHeight();
        ChatWindowActivity localChatWindowActivity7 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
        GridView localGridView1 = localTag.a;
        float f7 = f1 - f6;
        float f8 = f1;
        float f9 = f1;
        ChatWindowActivity.access$2000(localChatWindowActivity7, localGridView1, f1, f8, i, f7);
        float f10 = localView1.getHeight();
        ChatWindowActivity localChatWindowActivity8 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
        View localView2 = localView1;
        float f11 = f1;
        float f12 = f1;
        ChatWindowActivity.access$2000(localChatWindowActivity8, localView2, f1, f11, i, f12);
      }
    while (this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.jdField_a_of_type_JavaLangString.equals("10000"));
    ChatWindowActivity.access$1900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).removeMessages(j);
    float f13 = localView1.getHeight();
    ChatWindowActivity localChatWindowActivity9 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
    View localView3 = localView1;
    localObject = f1;
    float f14 = f1;
    ChatWindowActivity.access$2000(localChatWindowActivity9, localView3, f1, localObject, f14, f13);
    localView1.setVisibility(8);
    if (localTag.a.getHeight() == 0);
    for (int l = 1120403456; ; l = localTag.a.getHeight())
    {
      ChatWindowActivity localChatWindowActivity10 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      GridView localGridView2 = localTag.a;
      float f15 = f1 - l;
      float f16 = f1;
      float f17 = f1;
      ChatWindowActivity.access$2000(localChatWindowActivity10, localGridView2, f1, l, f15, f17);
      ChatWindowActivity.access$1900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).sendEmptyMessageDelayed(j, 5000L);
      super.onClick(paramView);
      break label253:
    }
  }

  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    ChatWindowActivity.access$1900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).removeMessages(3);
    ChatWindowActivity.access$1900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).sendEmptyMessage(3);
    super.onItemClick(paramAdapterView, paramView, paramInt, paramLong);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ce
 * JD-Core Version:    0.5.4
 */