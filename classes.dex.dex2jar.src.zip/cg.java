import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.service.friendlist.FriendListUtil;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseServiceHelper;
import java.util.TimerTask;

public final class cg extends TimerTask
{
  public cg(ContactActivity paramContactActivity)
  {
  }

  public final void run()
  {
    BaseServiceHelper localBaseServiceHelper = ContactActivity.access$600(this.a).a();
    String str = ContactActivity.access$600(this.a).a().getUin();
    FriendListUtil.getOnlineFriend(localBaseServiceHelper, str);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cg
 * JD-Core Version:    0.5.4
 */