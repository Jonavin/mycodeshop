import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.util.BaseActionListener;

public final class au extends BaseActionListener
{
  public au(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public final void onActionResult(FromServiceMsg paramFromServiceMsg)
  {
    if (paramFromServiceMsg.resultCode != 1000);
    while (true)
    {
      return;
      if ((!paramFromServiceMsg.serviceCmd.equals("MessageSvc.PushGroupMsg")) && (!paramFromServiceMsg.serviceCmd.equals("MessageSvc.GetGroupMsg")) && (!paramFromServiceMsg.serviceCmd.equals("MessageSvc.getmsg")))
        continue;
      Message localMessage = ChatVideoActivity.access$2600(this.a).obtainMessage(1);
      ChatVideoActivity.access$2700(this.a, localMessage);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     au
 * JD-Core Version:    0.5.4
 */