import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class ay
  implements View.OnClickListener
{
  public ay(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity localChatWindowActivity = this.a;
    String str = this.a.a;
    int i = ChatWindowActivity.access$2100(this.a);
    localChatWindowActivity.a(str, i);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ay
 * JD-Core Version:    0.5.4
 */