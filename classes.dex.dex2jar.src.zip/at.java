import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;
import com.tencent.mobileqq.utils.CacheUtils;
import java.util.Map;
import java.util.Vector;

public final class at extends Handler
{
  public at(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    int i = paramMessage.what;
    switch (i)
    {
    default:
    case 1:
    }
    label24: Object localObject1;
    do
    {
      return;
      i = 0;
      int j = this.a.a.a.a.size();
      if (j <= 0)
        continue;
      localObject1 = this.a.a.a.a;
      Object localObject2 = this.a.a.a.b.lastElement();
      localObject1 = (UnreadMsgFriendInfo)((Map)localObject1).get(localObject2);
    }
    while (localObject1 == 0);
    int k = ((UnreadMsgFriendInfo)localObject1).msgtype;
    if (k == 0);
    for (String str1 = ((UnreadMsgFriendInfo)localObject1).nick; ; str1 = ((UnreadMsgFriendInfo)localObject1).lastMemberNick)
    {
      StringBuilder localStringBuilder = new StringBuilder().append(str1).append(": ");
      String str2 = ((UnreadMsgFriendInfo)localObject1).lastMsg;
      str1.append((String)localObject1).toString();
      break label24:
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     at
 * JD-Core Version:    0.5.4
 */