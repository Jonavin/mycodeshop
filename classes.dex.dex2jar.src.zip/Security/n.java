package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class n extends JceStruct
{
  static byte[] d;
  public byte[] a = null;
  public String b = "";
  public String c = "";

  static
  {
    if (!n.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public n()
  {
    byte[] arrayOfByte = this.a;
    a(arrayOfByte);
    String str1 = this.b;
    a(str1);
    String str2 = this.c;
    b(str2);
  }

  public n(byte[] paramArrayOfByte, String paramString1, String paramString2)
  {
    a(paramArrayOfByte);
    a(paramString1);
    b(paramString2);
  }

  public String a()
  {
    return "Security.RespondAuth";
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(String paramString)
  {
    this.c = paramString;
  }

  public byte[] b()
  {
    return this.a;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte = this.a;
    localJceDisplayer.display(arrayOfByte, "vpic_bin");
    String str1 = this.b;
    localJceDisplayer.display(str1, "vpic_tips");
    String str2 = this.c;
    localJceDisplayer.display(str2, "vpic_sid");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (n)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      String str1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        String str2 = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str2);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    Object localObject = null;
    int i = 1;
    if (d == null)
    {
      d = (byte[])new byte[i];
      ((byte[])d)[localObject] = localObject;
    }
    byte[] arrayOfByte1 = d;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, i, i);
    a(arrayOfByte2);
    String str1 = paramJceInputStream.readString(2, i);
    a(str1);
    String str2 = paramJceInputStream.readString(3, i);
    b(str2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte = this.a;
    paramJceOutputStream.write(arrayOfByte, 1);
    String str1 = this.b;
    paramJceOutputStream.write(str1, 2);
    String str2 = this.c;
    paramJceOutputStream.write(str2, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.n
 * JD-Core Version:    0.5.4
 */