package Security;

public final class SIG_TYPE
{
  public static final int _SIG_TYPE_A2 = 0;
  public static final int _SIG_TYPE_A3 = 2;
  public static final int _SIG_TYPE_A8 = 3;
  public static final int _SIG_TYPE_AccessToken = 5;
  public static final int _SIG_TYPE_AccessTokenSecret = 6;
  public static final int _SIG_TYPE_D3 = 12;
  public static final int _SIG_TYPE_MiniA2 = 1;
  public static final int _SIG_TYPE_Qzone_accesstoken = 9;
  public static final int _SIG_TYPE_Qzone_ckey = 10;
  public static final int _SIG_TYPE_Qzone_openid = 11;
  public static final int _SIG_TYPE_SESSIONKEY = 4;
  public static final int _SIG_TYPE_STwxWeb = 8;
  public static final int _SIG_TYPE_TenpaySessionKey = 7;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.SIG_TYPE
 * JD-Core Version:    0.5.4
 */