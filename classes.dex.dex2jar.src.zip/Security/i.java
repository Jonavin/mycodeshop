package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class i extends JceStruct
{
  public int a = null;
  public int b = null;
  public int c = null;
  public int d = null;
  public String e = "";
  public int f = null;
  public String g = "";
  public String h = "";
  public int i = null;

  static
  {
    if (!i.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = j;
      return;
    }
  }

  public i()
  {
    int k = this.a;
    a(k);
    int l = this.b;
    b(l);
    int i1 = this.c;
    c(i1);
    int i2 = this.d;
    d(i2);
    String str1 = this.e;
    a(str1);
    int i3 = this.f;
    e(i3);
    String str2 = this.g;
    b(str2);
    String str3 = this.h;
    c(str3);
    int i4 = this.i;
    f(i4);
  }

  public i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString1, int paramInt5, String paramString2, String paramString3, int paramInt6)
  {
    a(paramInt1);
    b(paramInt2);
    c(paramInt3);
    d(paramInt4);
    a(paramString1);
    e(paramInt5);
    b(paramString2);
    c(paramString3);
    f(paramInt6);
  }

  public String a()
  {
    return "Security.RequestHeader";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(String paramString)
  {
    this.e = paramString;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public void b(String paramString)
  {
    this.g = paramString;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.c = paramInt;
  }

  public void c(String paramString)
  {
    this.h = paramString;
  }

  public Object clone()
  {
    int k = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      j = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void d(int paramInt)
  {
    this.d = paramInt;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int k = this.a;
    localJceDisplayer.display(k, "ver");
    int l = this.b;
    localJceDisplayer.display(l, "cmd");
    int i1 = this.c;
    localJceDisplayer.display(i1, "requestID");
    int i2 = this.d;
    localJceDisplayer.display(i2, "svrSeqNo");
    String str1 = this.e;
    localJceDisplayer.display(str1, "uin");
    int i3 = this.f;
    localJceDisplayer.display(i3, "bid");
    String str2 = this.g;
    localJceDisplayer.display(str2, "sbid");
    String str3 = this.h;
    localJceDisplayer.display(str3, "channel_id");
    int i4 = this.i;
    localJceDisplayer.display(i4, "key_4");
  }

  public int e()
  {
    return this.d;
  }

  public void e(int paramInt)
  {
    this.f = paramInt;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (i)paramObject;
    int k = this.a;
    int i6 = paramObject.a;
    boolean bool1 = JceUtil.equals(k, i6);
    int i5;
    if (bool1)
    {
      int l = this.b;
      int i7 = paramObject.b;
      boolean bool2 = JceUtil.equals(l, i7);
      if (bool2)
      {
        int i1 = this.c;
        int i8 = paramObject.c;
        boolean bool3 = JceUtil.equals(i1, i8);
        if (bool3)
        {
          int i2 = this.d;
          int i9 = paramObject.d;
          boolean bool4 = JceUtil.equals(i2, i9);
          if (bool4)
          {
            Object localObject1 = this.e;
            String str1 = paramObject.e;
            localObject1 = JceUtil.equals(localObject1, str1);
            if (localObject1 != 0)
            {
              int i3 = this.f;
              int i10 = paramObject.f;
              boolean bool5 = JceUtil.equals(i3, i10);
              if (bool5)
              {
                Object localObject2 = this.g;
                String str2 = paramObject.g;
                localObject2 = JceUtil.equals(localObject2, str2);
                if (localObject2 != 0)
                {
                  localObject2 = this.h;
                  String str3 = paramObject.h;
                  localObject2 = JceUtil.equals(localObject2, str3);
                  if (localObject2 != 0)
                  {
                    int i4 = this.i;
                    int i11 = paramObject.i;
                    boolean bool6 = JceUtil.equals(i4, i11);
                    if (bool6)
                      i5 = 1;
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i5;
      Object localObject3 = null;
    }
  }

  public String f()
  {
    return this.e;
  }

  public void f(int paramInt)
  {
    this.i = paramInt;
  }

  public int g()
  {
    return this.f;
  }

  public String h()
  {
    return this.g;
  }

  public String i()
  {
    return this.h;
  }

  public int j()
  {
    return this.i;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int k = this.a;
    int l = paramJceInputStream.read(k, 0, true);
    a(l);
    int i1 = this.b;
    int i2 = paramJceInputStream.read(i1, 1, true);
    b(i2);
    int i3 = this.c;
    int i4 = paramJceInputStream.read(i3, 2, true);
    c(i4);
    int i5 = this.d;
    int i6 = paramJceInputStream.read(i5, 3, true);
    d(i6);
    String str1 = paramJceInputStream.readString(4, true);
    a(str1);
    int i7 = this.f;
    int i8 = paramJceInputStream.read(i7, 5, true);
    e(i8);
    String str2 = paramJceInputStream.readString(6, true);
    b(str2);
    String str3 = paramJceInputStream.readString(7, true);
    c(str3);
    int i9 = this.i;
    int i10 = paramJceInputStream.read(i9, 8, true);
    f(i10);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int k = this.a;
    paramJceOutputStream.write(k, 0);
    int l = this.b;
    paramJceOutputStream.write(l, 1);
    int i1 = this.c;
    paramJceOutputStream.write(i1, 2);
    int i2 = this.d;
    paramJceOutputStream.write(i2, 3);
    String str1 = this.e;
    paramJceOutputStream.write(str1, 4);
    int i3 = this.f;
    paramJceOutputStream.write(i3, 5);
    String str2 = this.g;
    paramJceOutputStream.write(str2, 6);
    String str3 = this.h;
    paramJceOutputStream.write(str3, 7);
    int i4 = this.i;
    paramJceOutputStream.write(i4, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.i
 * JD-Core Version:    0.5.4
 */