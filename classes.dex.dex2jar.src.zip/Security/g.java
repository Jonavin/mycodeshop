package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class g extends JceStruct
{
  static byte[] g;
  static byte[] h;
  static byte[] i;
  public byte[] a = null;
  public int b = null;
  public int c = null;
  public byte[] d = null;
  public int e = null;
  public byte[] f = null;

  static
  {
    if (!g.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = j;
      return;
    }
  }

  public g()
  {
    byte[] arrayOfByte1 = this.a;
    a(arrayOfByte1);
    int k = this.b;
    a(k);
    int l = this.c;
    b(l);
    byte[] arrayOfByte2 = this.d;
    b(arrayOfByte2);
    int i1 = this.e;
    c(i1);
    byte[] arrayOfByte3 = this.f;
    c(arrayOfByte3);
  }

  public g(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte[] paramArrayOfByte3)
  {
    a(paramArrayOfByte1);
    a(paramInt1);
    b(paramInt2);
    b(paramArrayOfByte2);
    c(paramInt3);
    c(paramArrayOfByte3);
  }

  public String a()
  {
    return "Security.RequestAuthWlogin";
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.d = paramArrayOfByte;
  }

  public byte[] b()
  {
    return this.a;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.e = paramInt;
  }

  public void c(byte[] paramArrayOfByte)
  {
    this.f = paramArrayOfByte;
  }

  public Object clone()
  {
    int k = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      j = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.a;
    localJceDisplayer.display(arrayOfByte1, "A1");
    int k = this.b;
    localJceDisplayer.display(k, "vpic_type");
    int l = this.c;
    localJceDisplayer.display(l, "vpic_format");
    byte[] arrayOfByte2 = this.d;
    localJceDisplayer.display(arrayOfByte2, "ksid");
    int i1 = this.e;
    localJceDisplayer.display(i1, "TrafficBitmap");
    byte[] arrayOfByte3 = this.f;
    localJceDisplayer.display(arrayOfByte3, "SigSession");
  }

  public byte[] e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (g)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int i2;
    if (localObject1 != 0)
    {
      int k = this.b;
      int i3 = paramObject.b;
      boolean bool1 = JceUtil.equals(k, i3);
      if (bool1)
      {
        int l = this.c;
        int i4 = paramObject.c;
        boolean bool2 = JceUtil.equals(l, i4);
        if (bool2)
        {
          Object localObject2 = this.d;
          byte[] arrayOfByte2 = paramObject.d;
          localObject2 = JceUtil.equals(localObject2, arrayOfByte2);
          if (localObject2 != 0)
          {
            int i1 = this.e;
            int i5 = paramObject.e;
            boolean bool3 = JceUtil.equals(i1, i5);
            if (bool3)
            {
              Object localObject3 = this.f;
              byte[] arrayOfByte3 = paramObject.f;
              localObject3 = JceUtil.equals(localObject3, arrayOfByte3);
              if (localObject3 != 0)
                i2 = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return i2;
      Object localObject4 = null;
    }
  }

  public int f()
  {
    return this.e;
  }

  public byte[] g()
  {
    return this.f;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int k = null;
    int l = 1;
    if (g == null)
    {
      g = (byte[])new byte[l];
      ((byte[])g)[k] = k;
    }
    byte[] arrayOfByte1 = g;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, k, l);
    a(arrayOfByte2);
    int i1 = this.b;
    int i2 = paramJceInputStream.read(i1, l, l);
    a(i2);
    int i3 = this.c;
    int i4 = paramJceInputStream.read(i3, 2, l);
    b(i4);
    if (h == null)
    {
      h = (byte[])new byte[l];
      ((byte[])h)[k] = k;
    }
    byte[] arrayOfByte3 = h;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, 3, l);
    b(arrayOfByte4);
    int i5 = this.e;
    int i6 = paramJceInputStream.read(i5, 4, l);
    c(i6);
    if (i == null)
    {
      i = (byte[])new byte[l];
      ((byte[])i)[k] = k;
    }
    byte[] arrayOfByte5 = i;
    byte[] arrayOfByte6 = (byte[])paramJceInputStream.read(arrayOfByte5, 5, k);
    c(arrayOfByte6);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.a;
    paramJceOutputStream.write(arrayOfByte1, 0);
    int k = this.b;
    paramJceOutputStream.write(k, 1);
    int l = this.c;
    paramJceOutputStream.write(l, 2);
    byte[] arrayOfByte2 = this.d;
    paramJceOutputStream.write(arrayOfByte2, 3);
    int i1 = this.e;
    paramJceOutputStream.write(i1, 4);
    if (this.f == null)
      return;
    byte[] arrayOfByte3 = this.f;
    paramJceOutputStream.write(arrayOfByte3, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.g
 * JD-Core Version:    0.5.4
 */