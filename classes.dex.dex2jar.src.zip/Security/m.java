package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class m extends JceStruct
{
  public String a = "";
  public String b = "";

  static
  {
    if (!m.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = c;
      return;
    }
  }

  public m()
  {
    String str1 = this.a;
    a(str1);
    String str2 = this.b;
    b(str2);
  }

  public m(String paramString1, String paramString2)
  {
    a(paramString1);
    b(paramString2);
  }

  public String a()
  {
    return "Security.RequestVerifyPic";
  }

  public void a(String paramString)
  {
    this.a = paramString;
  }

  public String b()
  {
    return this.a;
  }

  public void b(String paramString)
  {
    this.b = paramString;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      c = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    String str1 = this.a;
    localJceDisplayer.display(str1, "sid");
    String str2 = this.b;
    localJceDisplayer.display(str2, "verifyCode");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (m)paramObject;
    Object localObject1 = this.a;
    String str1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, str1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      String str2 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str2);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    String str1 = paramJceInputStream.readString(0, true);
    a(str1);
    String str2 = paramJceInputStream.readString(1, true);
    b(str2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    String str1 = this.a;
    paramJceOutputStream.write(str1, 0);
    String str2 = this.b;
    paramJceOutputStream.write(str2, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.m
 * JD-Core Version:    0.5.4
 */