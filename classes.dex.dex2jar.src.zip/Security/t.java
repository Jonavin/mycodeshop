package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class t extends JceStruct
{
  static byte[] c;
  public byte[] a = null;
  public String b = "";

  static
  {
    if (!t.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = d;
      return;
    }
  }

  public t()
  {
    byte[] arrayOfByte = this.a;
    a(arrayOfByte);
    String str = this.b;
    a(str);
  }

  public t(byte[] paramArrayOfByte, String paramString)
  {
    a(paramArrayOfByte);
    a(paramString);
  }

  public String a()
  {
    return "Security.RespondVerifyPic";
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public byte[] b()
  {
    return this.a;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      d = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte = this.a;
    localJceDisplayer.display(arrayOfByte, "vpic_bin");
    String str = this.b;
    localJceDisplayer.display(str, "vpic_sid");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (t)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      String str = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    if (c == null)
    {
      c = (byte[])new byte[j];
      ((byte[])c)[i] = i;
    }
    byte[] arrayOfByte1 = c;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, i, j);
    a(arrayOfByte2);
    String str = paramJceInputStream.readString(j, j);
    a(str);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte = this.a;
    paramJceOutputStream.write(arrayOfByte, 0);
    String str = this.b;
    paramJceOutputStream.write(str, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.t
 * JD-Core Version:    0.5.4
 */