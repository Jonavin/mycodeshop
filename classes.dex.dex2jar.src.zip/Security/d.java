package Security;

public final class d
{
  public static final int a;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.d
 * JD-Core Version:    0.5.4
 */