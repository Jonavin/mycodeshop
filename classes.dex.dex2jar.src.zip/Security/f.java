package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class f extends JceStruct
{
  static byte[] d;
  public byte[] a = null;
  public int b = null;
  public int c = null;

  static
  {
    if (!f.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public f()
  {
    byte[] arrayOfByte = this.a;
    a(arrayOfByte);
    int i = this.b;
    a(i);
    int j = this.c;
    b(j);
  }

  public f(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    a(paramArrayOfByte);
    a(paramInt1);
    b(paramInt2);
  }

  public String a()
  {
    return "Security.RequestAuthMail";
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  public byte[] b()
  {
    return this.a;
  }

  public int c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte = this.a;
    localJceDisplayer.display(arrayOfByte, "pwd");
    int i = this.b;
    localJceDisplayer.display(i, "vpic_type");
    int j = this.c;
    localJceDisplayer.display(j, "vpic_format");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (f)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte);
    int k;
    if (localObject1 != 0)
    {
      int i = this.b;
      int l = paramObject.b;
      boolean bool1 = JceUtil.equals(i, l);
      if (bool1)
      {
        int j = this.c;
        int i1 = paramObject.c;
        boolean bool2 = JceUtil.equals(j, i1);
        if (bool2)
          k = 1;
      }
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    if (d == null)
    {
      d = (byte[])new byte[j];
      ((byte[])d)[i] = i;
    }
    byte[] arrayOfByte1 = d;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, i, j);
    a(arrayOfByte2);
    int k = this.b;
    int l = paramJceInputStream.read(k, j, j);
    a(l);
    int i1 = this.c;
    int i2 = paramJceInputStream.read(i1, 2, j);
    b(i2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte = this.a;
    paramJceOutputStream.write(arrayOfByte, 0);
    int i = this.b;
    paramJceOutputStream.write(i, 1);
    int j = this.c;
    paramJceOutputStream.write(j, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.f
 * JD-Core Version:    0.5.4
 */