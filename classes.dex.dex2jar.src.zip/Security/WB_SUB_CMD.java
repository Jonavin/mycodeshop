package Security;

public final class WB_SUB_CMD
{
  public static final int _WB_SUB_CMD_UIN_EXCHANGE_WB = 1;
  public static final int _WB_SUB_CMD_WB_EXCHANGE_UIN;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.WB_SUB_CMD
 * JD-Core Version:    0.5.4
 */