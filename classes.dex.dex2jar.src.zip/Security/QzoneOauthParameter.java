package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class QzoneOauthParameter extends JceStruct
{
  static byte[] cache_oauth_consumer_key;
  static byte[] cache_oauth_signature_method;
  static byte[] cache_oauth_token_secret;
  static byte[] cache_oauth_version;
  static byte[] cache_sid;
  public byte[] oauth_consumer_key = null;
  public byte[] oauth_signature_method = null;
  public byte[] oauth_token_secret = null;
  public byte[] oauth_version = null;
  public byte[] sid = null;

  static
  {
    if (!QzoneOauthParameter.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public QzoneOauthParameter()
  {
    byte[] arrayOfByte1 = this.oauth_consumer_key;
    setOauth_consumer_key(arrayOfByte1);
    byte[] arrayOfByte2 = this.oauth_token_secret;
    setOauth_token_secret(arrayOfByte2);
    byte[] arrayOfByte3 = this.oauth_signature_method;
    setOauth_signature_method(arrayOfByte3);
    byte[] arrayOfByte4 = this.oauth_version;
    setOauth_version(arrayOfByte4);
    byte[] arrayOfByte5 = this.sid;
    setSid(arrayOfByte5);
  }

  public QzoneOauthParameter(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5)
  {
    setOauth_consumer_key(paramArrayOfByte1);
    setOauth_token_secret(paramArrayOfByte2);
    setOauth_signature_method(paramArrayOfByte3);
    setOauth_version(paramArrayOfByte4);
    setSid(paramArrayOfByte5);
  }

  public String className()
  {
    return "Security.QzoneOauthParameter";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.oauth_consumer_key;
    localJceDisplayer.display(arrayOfByte1, "oauth_consumer_key");
    byte[] arrayOfByte2 = this.oauth_token_secret;
    localJceDisplayer.display(arrayOfByte2, "oauth_token_secret");
    byte[] arrayOfByte3 = this.oauth_signature_method;
    localJceDisplayer.display(arrayOfByte3, "oauth_signature_method");
    byte[] arrayOfByte4 = this.oauth_version;
    localJceDisplayer.display(arrayOfByte4, "oauth_version");
    byte[] arrayOfByte5 = this.sid;
    localJceDisplayer.display(arrayOfByte5, "sid");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (QzoneOauthParameter)paramObject;
    Object localObject1 = this.oauth_consumer_key;
    byte[] arrayOfByte1 = paramObject.oauth_consumer_key;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.oauth_token_secret;
      byte[] arrayOfByte2 = paramObject.oauth_token_secret;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
      if (localObject1 != 0)
      {
        localObject1 = this.oauth_signature_method;
        byte[] arrayOfByte3 = paramObject.oauth_signature_method;
        localObject1 = JceUtil.equals(localObject1, arrayOfByte3);
        if (localObject1 != 0)
        {
          localObject1 = this.oauth_version;
          byte[] arrayOfByte4 = paramObject.oauth_version;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte4);
          if (localObject1 != 0)
          {
            localObject1 = this.sid;
            byte[] arrayOfByte5 = paramObject.sid;
            localObject1 = JceUtil.equals(localObject1, arrayOfByte5);
            if (localObject1 != 0)
              i = 1;
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public byte[] getOauth_consumer_key()
  {
    return this.oauth_consumer_key;
  }

  public byte[] getOauth_signature_method()
  {
    return this.oauth_signature_method;
  }

  public byte[] getOauth_token_secret()
  {
    return this.oauth_token_secret;
  }

  public byte[] getOauth_version()
  {
    return this.oauth_version;
  }

  public byte[] getSid()
  {
    return this.sid;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = null;
    if (cache_oauth_consumer_key == null)
    {
      cache_oauth_consumer_key = (byte[])new byte[i];
      ((byte[])cache_oauth_consumer_key)[j] = j;
    }
    byte[] arrayOfByte1 = cache_oauth_consumer_key;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, j, i);
    setOauth_consumer_key(arrayOfByte2);
    if (cache_oauth_token_secret == null)
    {
      cache_oauth_token_secret = (byte[])new byte[i];
      ((byte[])cache_oauth_token_secret)[j] = j;
    }
    byte[] arrayOfByte3 = cache_oauth_token_secret;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, i, i);
    setOauth_token_secret(arrayOfByte4);
    if (cache_oauth_signature_method == null)
    {
      cache_oauth_signature_method = (byte[])new byte[i];
      ((byte[])cache_oauth_signature_method)[j] = j;
    }
    byte[] arrayOfByte5 = cache_oauth_signature_method;
    byte[] arrayOfByte6 = (byte[])paramJceInputStream.read(arrayOfByte5, 2, i);
    setOauth_signature_method(arrayOfByte6);
    if (cache_oauth_version == null)
    {
      cache_oauth_version = (byte[])new byte[i];
      ((byte[])cache_oauth_version)[j] = j;
    }
    byte[] arrayOfByte7 = cache_oauth_version;
    byte[] arrayOfByte8 = (byte[])paramJceInputStream.read(arrayOfByte7, 3, i);
    setOauth_version(arrayOfByte8);
    if (cache_sid == null)
    {
      cache_sid = (byte[])new byte[i];
      ((byte[])cache_sid)[j] = j;
    }
    byte[] arrayOfByte9 = cache_sid;
    byte[] arrayOfByte10 = (byte[])paramJceInputStream.read(arrayOfByte9, 4, i);
    setSid(arrayOfByte10);
  }

  public void setOauth_consumer_key(byte[] paramArrayOfByte)
  {
    this.oauth_consumer_key = paramArrayOfByte;
  }

  public void setOauth_signature_method(byte[] paramArrayOfByte)
  {
    this.oauth_signature_method = paramArrayOfByte;
  }

  public void setOauth_token_secret(byte[] paramArrayOfByte)
  {
    this.oauth_token_secret = paramArrayOfByte;
  }

  public void setOauth_version(byte[] paramArrayOfByte)
  {
    this.oauth_version = paramArrayOfByte;
  }

  public void setSid(byte[] paramArrayOfByte)
  {
    this.sid = paramArrayOfByte;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.oauth_consumer_key;
    paramJceOutputStream.write(arrayOfByte1, 0);
    byte[] arrayOfByte2 = this.oauth_token_secret;
    paramJceOutputStream.write(arrayOfByte2, 1);
    byte[] arrayOfByte3 = this.oauth_signature_method;
    paramJceOutputStream.write(arrayOfByte3, 2);
    byte[] arrayOfByte4 = this.oauth_version;
    paramJceOutputStream.write(arrayOfByte4, 3);
    byte[] arrayOfByte5 = this.sid;
    paramJceOutputStream.write(arrayOfByte5, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.QzoneOauthParameter
 * JD-Core Version:    0.5.4
 */