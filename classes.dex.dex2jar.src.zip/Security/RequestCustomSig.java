package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class RequestCustomSig extends JceStruct
{
  static byte[] cache_reserved;
  public byte[] reserved = null;
  public long ulCustumFlag = 0L;
  public long ulSType = 0L;

  static
  {
    if (!RequestCustomSig.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RequestCustomSig()
  {
    long l1 = this.ulCustumFlag;
    setUlCustumFlag(l1);
    long l2 = this.ulSType;
    setUlSType(l2);
    byte[] arrayOfByte = this.reserved;
    setReserved(arrayOfByte);
  }

  public RequestCustomSig(long paramLong1, long paramLong2, byte[] paramArrayOfByte)
  {
    setUlCustumFlag(paramLong1);
    setUlSType(???);
    setReserved(paramLong2);
  }

  public String className()
  {
    return "Security.RequestCustomSig";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.ulCustumFlag;
    localJceDisplayer.display(l1, "ulCustumFlag");
    long l2 = this.ulSType;
    localJceDisplayer.display(l2, "ulSType");
    byte[] arrayOfByte = this.reserved;
    localJceDisplayer.display(arrayOfByte, "reserved");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (RequestCustomSig)paramObject;
    long l1 = this.ulCustumFlag;
    long l2 = paramObject.ulCustumFlag;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      l1 = this.ulSType;
      long l3 = paramObject.ulSType;
      bool = JceUtil.equals(l1, l3);
      if (bool)
      {
        Object localObject1 = this.reserved;
        byte[] arrayOfByte = paramObject.reserved;
        localObject1 = JceUtil.equals(localObject1, arrayOfByte);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public byte[] getReserved()
  {
    return this.reserved;
  }

  public long getUlCustumFlag()
  {
    return this.ulCustumFlag;
  }

  public long getUlSType()
  {
    return this.ulSType;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.ulCustumFlag;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    setUlCustumFlag(localObject1);
    long l3 = this.ulSType;
    long l4 = paramJceInputStream.read(l3, j, j);
    Object localObject2;
    setUlSType(localObject2);
    if (cache_reserved == null)
    {
      cache_reserved = (byte[])new byte[j];
      ((byte[])cache_reserved)[i] = i;
    }
    byte[] arrayOfByte1 = cache_reserved;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 2, j);
    setReserved(arrayOfByte2);
  }

  public void setReserved(byte[] paramArrayOfByte)
  {
    this.reserved = paramArrayOfByte;
  }

  public void setUlCustumFlag(long paramLong)
  {
    this.ulCustumFlag = paramLong;
  }

  public void setUlSType(long paramLong)
  {
    this.ulSType = paramLong;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.ulCustumFlag;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.ulSType;
    paramJceOutputStream.write(l2, 1);
    byte[] arrayOfByte = this.reserved;
    paramJceOutputStream.write(arrayOfByte, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.RequestCustomSig
 * JD-Core Version:    0.5.4
 */