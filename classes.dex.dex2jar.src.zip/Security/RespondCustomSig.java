package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class RespondCustomSig extends JceStruct
{
  static ArrayList cache_SigList;
  static byte[] cache_reserved;
  public ArrayList SigList = null;
  public byte[] reserved = null;
  public long ulCustumFlag = 0L;
  public long ulSType = 0L;

  static
  {
    if (!RespondCustomSig.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RespondCustomSig()
  {
    long l1 = this.ulCustumFlag;
    setUlCustumFlag(l1);
    long l2 = this.ulSType;
    setUlSType(l2);
    ArrayList localArrayList = this.SigList;
    setSigList(localArrayList);
    byte[] arrayOfByte = this.reserved;
    setReserved(arrayOfByte);
  }

  public RespondCustomSig(long paramLong1, long paramLong2, ArrayList paramArrayList, byte[] paramArrayOfByte)
  {
    setUlCustumFlag(paramLong1);
    setUlSType(???);
    setSigList(paramLong2);
    setReserved(???);
  }

  public String className()
  {
    return "Security.RespondCustomSig";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.ulCustumFlag;
    localJceDisplayer.display(l1, "ulCustumFlag");
    long l2 = this.ulSType;
    localJceDisplayer.display(l2, "ulSType");
    ArrayList localArrayList = this.SigList;
    localJceDisplayer.display(localArrayList, "SigList");
    byte[] arrayOfByte = this.reserved;
    localJceDisplayer.display(arrayOfByte, "reserved");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (RespondCustomSig)paramObject;
    long l1 = this.ulCustumFlag;
    long l2 = paramObject.ulCustumFlag;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      l1 = this.ulSType;
      long l3 = paramObject.ulSType;
      bool = JceUtil.equals(l1, l3);
      if (bool)
      {
        Object localObject1 = this.SigList;
        ArrayList localArrayList = paramObject.SigList;
        localObject1 = JceUtil.equals(localObject1, localArrayList);
        if (localObject1 != 0)
        {
          localObject1 = this.reserved;
          byte[] arrayOfByte = paramObject.reserved;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte);
          if (localObject1 != 0)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public byte[] getReserved()
  {
    return this.reserved;
  }

  public ArrayList getSigList()
  {
    return this.SigList;
  }

  public long getUlCustumFlag()
  {
    return this.ulCustumFlag;
  }

  public long getUlSType()
  {
    return this.ulSType;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.ulCustumFlag;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    setUlCustumFlag(localObject1);
    long l3 = this.ulSType;
    long l4 = paramJceInputStream.read(l3, j, j);
    Object localObject2;
    setUlSType(localObject2);
    if (cache_SigList == null)
    {
      cache_SigList = new ArrayList();
      CustomSigContent localCustomSigContent = new CustomSigContent();
      cache_SigList.add(localCustomSigContent);
    }
    ArrayList localArrayList1 = cache_SigList;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 2, j);
    setSigList(localArrayList2);
    if (cache_reserved == null)
    {
      cache_reserved = (byte[])new byte[j];
      ((byte[])cache_reserved)[i] = i;
    }
    byte[] arrayOfByte1 = cache_reserved;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 3, j);
    setReserved(arrayOfByte2);
  }

  public void setReserved(byte[] paramArrayOfByte)
  {
    this.reserved = paramArrayOfByte;
  }

  public void setSigList(ArrayList paramArrayList)
  {
    this.SigList = paramArrayList;
  }

  public void setUlCustumFlag(long paramLong)
  {
    this.ulCustumFlag = paramLong;
  }

  public void setUlSType(long paramLong)
  {
    this.ulSType = paramLong;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.ulCustumFlag;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.ulSType;
    paramJceOutputStream.write(l2, 1);
    ArrayList localArrayList = this.SigList;
    paramJceOutputStream.write(localArrayList, 2);
    byte[] arrayOfByte = this.reserved;
    paramJceOutputStream.write(arrayOfByte, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.RespondCustomSig
 * JD-Core Version:    0.5.4
 */