package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class p extends JceStruct
{
  public int a = null;

  static
  {
    if (!p.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = b;
      return;
    }
  }

  public p()
  {
    int i = this.a;
    a(i);
  }

  public p(int paramInt)
  {
    a(paramInt);
  }

  public String a()
  {
    return "Security.RespondGetServerTime";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public int b()
  {
    return this.a;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      b = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "time_diff");
  }

  public boolean equals(Object paramObject)
  {
    p localp = (p)paramObject;
    int i = this.a;
    int j = paramObject.a;
    return JceUtil.equals(i, j);
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 0, true);
    a(j);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.p
 * JD-Core Version:    0.5.4
 */