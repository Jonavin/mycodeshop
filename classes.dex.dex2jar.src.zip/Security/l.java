package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class l extends JceStruct
{
  public int a = null;
  public int b = null;

  static
  {
    if (!l.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = c;
      return;
    }
  }

  public l()
  {
    int i = this.a;
    a(i);
    int j = this.b;
    b(j);
  }

  public l(int paramInt1, int paramInt2)
  {
    a(paramInt1);
    b(paramInt2);
  }

  public String a()
  {
    return "Security.RequestRefreshVPic";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public int c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      c = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "vpic_type");
    int j = this.b;
    localJceDisplayer.display(j, "vpic_format");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (l)paramObject;
    int i = this.a;
    int l = paramObject.a;
    boolean bool1 = JceUtil.equals(i, l);
    int k;
    if (bool1)
    {
      int j = this.b;
      int i1 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i1);
      if (bool2)
        k = 1;
    }
    while (true)
    {
      return k;
      Object localObject = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 0, true);
    a(j);
    int k = this.b;
    int l = paramJceInputStream.read(k, 1, true);
    b(l);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    int j = this.b;
    paramJceOutputStream.write(j, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.l
 * JD-Core Version:    0.5.4
 */