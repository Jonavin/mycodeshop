package Security;

public final class CMD_ID
{
  public static final int _CMD_ID_AUTH = 0;
  public static final int _CMD_ID_AUTH_AND_GET_KEY = 12;
  public static final int _CMD_ID_AUTH_MAIL = 5;
  public static final int _CMD_ID_AUTH_WLOGIN = 14;
  public static final int _CMD_ID_CUSTOM_SIG = 7;
  public static final int _CMD_ID_EMAIL_EXCHANGE_UIN = 10;
  public static final int _CMD_ID_FETCH_VPIC_CODE = 11;
  public static final int _CMD_ID_GET_SERVER_TIME = 15;
  public static final int _CMD_ID_LOGGED_STAT_CUSTOM_SIG = 9;
  public static final int _CMD_ID_NAME_EXCHANGE_UIN = 13;
  public static final int _CMD_ID_REFETCH_SID = 6;
  public static final int _CMD_ID_REFRESH_VPIC = 2;
  public static final int _CMD_ID_SYNC = 4;
  public static final int _CMD_ID_VERIFY_KEY = 3;
  public static final int _CMD_ID_VERIFY_PIC = 1;
  public static final int _CMD_ID_WB_EXCHANGE_UIN = 8;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.CMD_ID
 * JD-Core Version:    0.5.4
 */