package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class w extends JceStruct
{
  public short a = null;
  public String b = "";
  public String c = "";

  static
  {
    if (!w.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = d;
      return;
    }
  }

  public w()
  {
    short s = this.a;
    a(s);
    String str1 = this.b;
    a(str1);
    String str2 = this.c;
    b(str2);
  }

  public w(short paramShort, String paramString1, String paramString2)
  {
    a(paramShort);
    a(paramString1);
    b(paramString2);
  }

  public String a()
  {
    return "Security.TimeZone";
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public void a(short paramShort)
  {
    this.a = paramShort;
  }

  public short b()
  {
    return this.a;
  }

  public void b(String paramString)
  {
    this.c = paramString;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      d = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    short s = this.a;
    localJceDisplayer.display(s, "wTimeZoneVer");
    String str1 = this.b;
    localJceDisplayer.display(str1, "sLocaleID");
    String str2 = this.c;
    localJceDisplayer.display(str2, "sTimeZoneOffsetMin");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (w)paramObject;
    short s1 = this.a;
    short s2 = paramObject.a;
    boolean bool = JceUtil.equals(s1, s2);
    int i;
    if (bool)
    {
      Object localObject1 = this.b;
      String str1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        String str2 = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str2);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    short s1 = this.a;
    short s2 = paramJceInputStream.read(s1, 0, true);
    a(s2);
    String str1 = paramJceInputStream.readString(1, true);
    a(str1);
    String str2 = paramJceInputStream.readString(2, true);
    b(str2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    short s = this.a;
    paramJceOutputStream.write(s, 0);
    String str1 = this.b;
    paramJceOutputStream.write(str1, 1);
    String str2 = this.c;
    paramJceOutputStream.write(str2, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.w
 * JD-Core Version:    0.5.4
 */