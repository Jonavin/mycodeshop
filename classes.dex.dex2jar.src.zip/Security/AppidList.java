package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class AppidList extends JceStruct
{
  static ArrayList cache_AppidVector;
  public ArrayList AppidVector = null;
  public long nReserved = 0L;

  static
  {
    if (!AppidList.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public AppidList()
  {
    long l = this.nReserved;
    setNReserved(l);
    ArrayList localArrayList = this.AppidVector;
    setAppidVector(localArrayList);
  }

  public AppidList(long paramLong, ArrayList paramArrayList)
  {
    setNReserved(paramLong);
    setAppidVector(???);
  }

  public String className()
  {
    return "Security.AppidList";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.nReserved;
    localJceDisplayer.display(l, "nReserved");
    ArrayList localArrayList = this.AppidVector;
    localJceDisplayer.display(localArrayList, "AppidVector");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (AppidList)paramObject;
    long l1 = this.nReserved;
    long l2 = paramObject.nReserved;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      Object localObject1 = this.AppidVector;
      ArrayList localArrayList = paramObject.AppidVector;
      localObject1 = JceUtil.equals(localObject1, localArrayList);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public ArrayList getAppidVector()
  {
    return this.AppidVector;
  }

  public long getNReserved()
  {
    return this.nReserved;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    long l1 = this.nReserved;
    long l2 = paramJceInputStream.read(l1, 0, i);
    Object localObject;
    setNReserved(localObject);
    if (cache_AppidVector == null)
    {
      cache_AppidVector = new ArrayList();
      Long localLong = Long.valueOf(0L);
      cache_AppidVector.add(localLong);
    }
    ArrayList localArrayList1 = cache_AppidVector;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, i, i);
    setAppidVector(localArrayList2);
  }

  public void setAppidVector(ArrayList paramArrayList)
  {
    this.AppidVector = paramArrayList;
  }

  public void setNReserved(long paramLong)
  {
    this.nReserved = paramLong;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.nReserved;
    paramJceOutputStream.write(l, 0);
    ArrayList localArrayList = this.AppidVector;
    paramJceOutputStream.write(localArrayList, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.AppidList
 * JD-Core Version:    0.5.4
 */