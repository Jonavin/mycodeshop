package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class v extends JceStruct
{
  static byte[] f;
  static byte[] g;
  static byte[] h;
  public byte[] a = null;
  public String b = "";
  public String c = "";
  public byte[] d = null;
  public byte[] e = null;

  static
  {
    if (!v.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = i;
      return;
    }
  }

  public v()
  {
    byte[] arrayOfByte1 = this.a;
    a(arrayOfByte1);
    String str1 = this.b;
    a(str1);
    String str2 = this.c;
    b(str2);
    byte[] arrayOfByte2 = this.d;
    b(arrayOfByte2);
    byte[] arrayOfByte3 = this.e;
    c(arrayOfByte3);
  }

  public v(byte[] paramArrayOfByte1, String paramString1, String paramString2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    a(paramArrayOfByte1);
    a(paramString1);
    b(paramString2);
    b(paramArrayOfByte2);
    c(paramArrayOfByte3);
  }

  public String a()
  {
    return "Security.ResponseNameExchangeUin";
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(String paramString)
  {
    this.c = paramString;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.d = paramArrayOfByte;
  }

  public byte[] b()
  {
    return this.a;
  }

  public String c()
  {
    return this.b;
  }

  public void c(byte[] paramArrayOfByte)
  {
    this.e = paramArrayOfByte;
  }

  public Object clone()
  {
    int j = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      i = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.a;
    localJceDisplayer.display(arrayOfByte1, "vpic_bin");
    String str1 = this.b;
    localJceDisplayer.display(str1, "vpic_tips");
    String str2 = this.c;
    localJceDisplayer.display(str2, "vpic_sid");
    byte[] arrayOfByte2 = this.d;
    localJceDisplayer.display(arrayOfByte2, "ksid");
    byte[] arrayOfByte3 = this.e;
    localJceDisplayer.display(arrayOfByte3, "SigSession");
  }

  public byte[] e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (v)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int j;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      String str1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        String str2 = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str2);
        if (localObject1 != 0)
        {
          localObject1 = this.d;
          byte[] arrayOfByte2 = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
          if (localObject1 != 0)
          {
            localObject1 = this.e;
            byte[] arrayOfByte3 = paramObject.e;
            localObject1 = JceUtil.equals(localObject1, arrayOfByte3);
            if (localObject1 != 0)
              j = 1;
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public byte[] f()
  {
    return this.e;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int j = 1;
    int k = null;
    if (f == null)
    {
      f = (byte[])new byte[j];
      ((byte[])f)[k] = k;
    }
    byte[] arrayOfByte1 = f;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, k, j);
    a(arrayOfByte2);
    String str1 = paramJceInputStream.readString(j, j);
    a(str1);
    String str2 = paramJceInputStream.readString(2, j);
    b(str2);
    if (g == null)
    {
      g = (byte[])new byte[j];
      ((byte[])g)[k] = k;
    }
    byte[] arrayOfByte3 = g;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, 3, j);
    b(arrayOfByte4);
    if (h == null)
    {
      h = (byte[])new byte[j];
      ((byte[])h)[k] = k;
    }
    byte[] arrayOfByte5 = h;
    byte[] arrayOfByte6 = (byte[])paramJceInputStream.read(arrayOfByte5, 4, k);
    c(arrayOfByte6);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.a;
    paramJceOutputStream.write(arrayOfByte1, 0);
    String str1 = this.b;
    paramJceOutputStream.write(str1, 1);
    String str2 = this.c;
    paramJceOutputStream.write(str2, 2);
    byte[] arrayOfByte2 = this.d;
    paramJceOutputStream.write(arrayOfByte2, 3);
    if (this.e == null)
      return;
    byte[] arrayOfByte3 = this.e;
    paramJceOutputStream.write(arrayOfByte3, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.v
 * JD-Core Version:    0.5.4
 */