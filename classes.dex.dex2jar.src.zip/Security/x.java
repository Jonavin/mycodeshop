package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class x extends JceStruct
{
  static byte[] d;
  public long a = 0L;
  public int b = null;
  public byte[] c = null;

  static
  {
    if (!x.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public x()
  {
    long l = this.a;
    a(l);
    int i = this.b;
    a(i);
    byte[] arrayOfByte = this.c;
    a(arrayOfByte);
  }

  public x(long paramLong, int paramInt, byte[] paramArrayOfByte)
  {
    a(paramLong);
    a(???);
    a(paramInt);
  }

  public String a()
  {
    return "Security.UserMainAccount";
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(long paramLong)
  {
    this.a = paramLong;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.c = paramArrayOfByte;
  }

  public long b()
  {
    return this.a;
  }

  public int c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public byte[] d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.a;
    localJceDisplayer.display(l, "nFlag");
    int i = this.b;
    localJceDisplayer.display(i, "wNameLen");
    byte[] arrayOfByte = this.c;
    localJceDisplayer.display(arrayOfByte, "MainAccount");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (x)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      int i = this.b;
      int k = paramObject.b;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        Object localObject1 = this.c;
        byte[] arrayOfByte = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, arrayOfByte);
        if (localObject1 != 0)
          j = 1;
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject;
    a(localObject);
    int k = this.b;
    int l = paramJceInputStream.read(k, j, j);
    a(l);
    if (d == null)
    {
      d = (byte[])new byte[j];
      ((byte[])d)[i] = i;
    }
    byte[] arrayOfByte1 = d;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 2, j);
    a(arrayOfByte2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.a;
    paramJceOutputStream.write(l, 0);
    int i = this.b;
    paramJceOutputStream.write(i, 1);
    byte[] arrayOfByte = this.c;
    paramJceOutputStream.write(arrayOfByte, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.x
 * JD-Core Version:    0.5.4
 */