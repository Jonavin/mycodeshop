package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class b extends JceStruct
{
  static byte[] c;
  public int a = null;
  public byte[] b = null;

  static
  {
    if (!b.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = d;
      return;
    }
  }

  public b()
  {
    int i = this.a;
    a(i);
    byte[] arrayOfByte = this.b;
    a(arrayOfByte);
  }

  public b(int paramInt, byte[] paramArrayOfByte)
  {
    a(paramInt);
    a(paramArrayOfByte);
  }

  public String a()
  {
    return "Security.AuthandGetKeyResult";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.b = paramArrayOfByte;
  }

  public int b()
  {
    return this.a;
  }

  public byte[] c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      d = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "KeyType");
    byte[] arrayOfByte = this.b;
    localJceDisplayer.display(arrayOfByte, "KeyValue");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (b)paramObject;
    int i = this.a;
    int k = paramObject.a;
    boolean bool = JceUtil.equals(i, k);
    int j;
    if (bool)
    {
      Object localObject1 = this.b;
      byte[] arrayOfByte = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte);
      if (localObject1 != 0)
        j = 1;
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    int k = this.a;
    int l = paramJceInputStream.read(k, i, j);
    a(l);
    if (c == null)
    {
      c = (byte[])new byte[j];
      ((byte[])c)[i] = i;
    }
    byte[] arrayOfByte1 = c;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, j, j);
    a(arrayOfByte2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    byte[] arrayOfByte = this.b;
    paramJceOutputStream.write(arrayOfByte, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.b
 * JD-Core Version:    0.5.4
 */