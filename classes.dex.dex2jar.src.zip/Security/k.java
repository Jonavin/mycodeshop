package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class k extends JceStruct
{
  static byte[] c;
  static byte[] d;
  public byte[] a = null;
  public byte[] b = null;

  static
  {
    if (!k.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public k()
  {
    byte[] arrayOfByte1 = this.a;
    a(arrayOfByte1);
    byte[] arrayOfByte2 = this.b;
    b(arrayOfByte2);
  }

  public k(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    a(paramArrayOfByte1);
    b(paramArrayOfByte2);
  }

  public String a()
  {
    return "Security.RequestReFetchSid";
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.b = paramArrayOfByte;
  }

  public byte[] b()
  {
    return this.a;
  }

  public byte[] c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.a;
    localJceDisplayer.display(arrayOfByte1, "A3");
    byte[] arrayOfByte2 = this.b;
    localJceDisplayer.display(arrayOfByte2, "reserve");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (k)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      byte[] arrayOfByte2 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = null;
    if (c == null)
    {
      c = (byte[])new byte[i];
      ((byte[])c)[j] = j;
    }
    byte[] arrayOfByte1 = c;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, j, i);
    a(arrayOfByte2);
    if (d == null)
    {
      d = (byte[])new byte[i];
      ((byte[])d)[j] = j;
    }
    byte[] arrayOfByte3 = d;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, i, i);
    b(arrayOfByte4);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.a;
    paramJceOutputStream.write(arrayOfByte1, 0);
    byte[] arrayOfByte2 = this.b;
    paramJceOutputStream.write(arrayOfByte2, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.k
 * JD-Core Version:    0.5.4
 */