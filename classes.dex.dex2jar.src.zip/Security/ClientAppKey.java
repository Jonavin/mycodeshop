package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ClientAppKey extends JceStruct
{
  static byte[] cache_AppKey;
  static byte[] cache_AppSecret;
  public byte[] AppKey = null;
  public byte[] AppSecret = null;

  static
  {
    if (!ClientAppKey.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ClientAppKey()
  {
    byte[] arrayOfByte1 = this.AppKey;
    setAppKey(arrayOfByte1);
    byte[] arrayOfByte2 = this.AppSecret;
    setAppSecret(arrayOfByte2);
  }

  public ClientAppKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    setAppKey(paramArrayOfByte1);
    setAppSecret(paramArrayOfByte2);
  }

  public String className()
  {
    return "Security.ClientAppKey";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.AppKey;
    localJceDisplayer.display(arrayOfByte1, "AppKey");
    byte[] arrayOfByte2 = this.AppSecret;
    localJceDisplayer.display(arrayOfByte2, "AppSecret");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (ClientAppKey)paramObject;
    Object localObject1 = this.AppKey;
    byte[] arrayOfByte1 = paramObject.AppKey;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.AppSecret;
      byte[] arrayOfByte2 = paramObject.AppSecret;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public byte[] getAppKey()
  {
    return this.AppKey;
  }

  public byte[] getAppSecret()
  {
    return this.AppSecret;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = null;
    if (cache_AppKey == null)
    {
      cache_AppKey = (byte[])new byte[i];
      ((byte[])cache_AppKey)[j] = j;
    }
    byte[] arrayOfByte1 = cache_AppKey;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, j, i);
    setAppKey(arrayOfByte2);
    if (cache_AppSecret == null)
    {
      cache_AppSecret = (byte[])new byte[i];
      ((byte[])cache_AppSecret)[j] = j;
    }
    byte[] arrayOfByte3 = cache_AppSecret;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, i, i);
    setAppSecret(arrayOfByte4);
  }

  public void setAppKey(byte[] paramArrayOfByte)
  {
    this.AppKey = paramArrayOfByte;
  }

  public void setAppSecret(byte[] paramArrayOfByte)
  {
    this.AppSecret = paramArrayOfByte;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.AppKey;
    paramJceOutputStream.write(arrayOfByte1, 0);
    byte[] arrayOfByte2 = this.AppSecret;
    paramJceOutputStream.write(arrayOfByte2, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.ClientAppKey
 * JD-Core Version:    0.5.4
 */