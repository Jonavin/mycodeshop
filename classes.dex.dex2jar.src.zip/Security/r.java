package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class r extends JceStruct
{
  static byte[] d;
  static byte[] e;
  public int a = null;
  public byte[] b = null;
  public byte[] c = null;

  static
  {
    if (!r.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = f;
      return;
    }
  }

  public r()
  {
    int i = this.a;
    a(i);
    byte[] arrayOfByte1 = this.b;
    a(arrayOfByte1);
    byte[] arrayOfByte2 = this.c;
    b(arrayOfByte2);
  }

  public r(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    a(paramInt);
    a(paramArrayOfByte1);
    b(paramArrayOfByte2);
  }

  public String a()
  {
    return "Security.RespondReFetchSid";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.b = paramArrayOfByte;
  }

  public int b()
  {
    return this.a;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.c = paramArrayOfByte;
  }

  public byte[] c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      f = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public byte[] d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "result");
    byte[] arrayOfByte1 = this.b;
    localJceDisplayer.display(arrayOfByte1, "sid");
    byte[] arrayOfByte2 = this.c;
    localJceDisplayer.display(arrayOfByte2, "reserve");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (r)paramObject;
    int i = this.a;
    int k = paramObject.a;
    boolean bool = JceUtil.equals(i, k);
    int j;
    if (bool)
    {
      Object localObject1 = this.b;
      byte[] arrayOfByte1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        byte[] arrayOfByte2 = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
        if (localObject1 != 0)
          j = 1;
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    int k = this.a;
    int l = paramJceInputStream.read(k, i, j);
    a(l);
    if (d == null)
    {
      d = (byte[])new byte[j];
      ((byte[])d)[i] = i;
    }
    byte[] arrayOfByte1 = d;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, j, j);
    a(arrayOfByte2);
    if (e == null)
    {
      e = (byte[])new byte[j];
      ((byte[])e)[i] = i;
    }
    byte[] arrayOfByte3 = e;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, 2, j);
    b(arrayOfByte4);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    byte[] arrayOfByte1 = this.b;
    paramJceOutputStream.write(arrayOfByte1, 1);
    byte[] arrayOfByte2 = this.c;
    paramJceOutputStream.write(arrayOfByte2, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.r
 * JD-Core Version:    0.5.4
 */