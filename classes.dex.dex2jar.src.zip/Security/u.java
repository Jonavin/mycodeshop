package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class u extends JceStruct
{
  static byte[] e;
  static byte[] f;
  public byte[] a = null;
  public String b = "";
  public String c = "";
  public byte[] d = null;

  static
  {
    if (!u.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = g;
      return;
    }
  }

  public u()
  {
    byte[] arrayOfByte1 = this.a;
    a(arrayOfByte1);
    String str1 = this.b;
    a(str1);
    String str2 = this.c;
    b(str2);
    byte[] arrayOfByte2 = this.d;
    b(arrayOfByte2);
  }

  public u(byte[] paramArrayOfByte1, String paramString1, String paramString2, byte[] paramArrayOfByte2)
  {
    a(paramArrayOfByte1);
    a(paramString1);
    b(paramString2);
    b(paramArrayOfByte2);
  }

  public String a()
  {
    return "Security.ResponseAuthWlogin";
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.a = paramArrayOfByte;
  }

  public void b(String paramString)
  {
    this.c = paramString;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.d = paramArrayOfByte;
  }

  public byte[] b()
  {
    return this.a;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      g = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte[] arrayOfByte1 = this.a;
    localJceDisplayer.display(arrayOfByte1, "vpic_bin");
    String str1 = this.b;
    localJceDisplayer.display(str1, "vpic_tips");
    String str2 = this.c;
    localJceDisplayer.display(str2, "vpic_sid");
    byte[] arrayOfByte2 = this.d;
    localJceDisplayer.display(arrayOfByte2, "ksid");
  }

  public byte[] e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (u)paramObject;
    Object localObject1 = this.a;
    byte[] arrayOfByte1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.b;
      String str1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        String str2 = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str2);
        if (localObject1 != 0)
        {
          localObject1 = this.d;
          byte[] arrayOfByte2 = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
          if (localObject1 != 0)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    if (e == null)
    {
      e = (byte[])new byte[j];
      ((byte[])e)[i] = i;
    }
    byte[] arrayOfByte1 = e;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, i, j);
    a(arrayOfByte2);
    String str1 = paramJceInputStream.readString(j, j);
    a(str1);
    String str2 = paramJceInputStream.readString(2, j);
    b(str2);
    if (f == null)
    {
      f = (byte[])new byte[j];
      ((byte[])f)[i] = i;
    }
    byte[] arrayOfByte3 = f;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, 3, j);
    b(arrayOfByte4);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte[] arrayOfByte1 = this.a;
    paramJceOutputStream.write(arrayOfByte1, 0);
    String str1 = this.b;
    paramJceOutputStream.write(str1, 1);
    String str2 = this.c;
    paramJceOutputStream.write(str2, 2);
    byte[] arrayOfByte2 = this.d;
    paramJceOutputStream.write(arrayOfByte2, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.u
 * JD-Core Version:    0.5.4
 */