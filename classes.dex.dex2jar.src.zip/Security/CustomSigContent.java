package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class CustomSigContent extends JceStruct
{
  static byte[] cache_SigContent;
  public byte[] SigContent = null;
  public long length = 0L;
  public short sResult = null;
  public long ulSigType = 0L;

  static
  {
    if (!CustomSigContent.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public CustomSigContent()
  {
    long l1 = this.ulSigType;
    setUlSigType(l1);
    short s = this.sResult;
    setSResult(s);
    long l2 = this.length;
    setLength(l2);
    byte[] arrayOfByte = this.SigContent;
    setSigContent(arrayOfByte);
  }

  public CustomSigContent(long paramLong1, short paramShort, long paramLong2, byte[] paramArrayOfByte)
  {
    setUlSigType(paramLong1);
    setSResult(???);
    setLength(paramShort);
    setSigContent(paramLong2);
  }

  public String className()
  {
    return "Security.CustomSigContent";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.ulSigType;
    localJceDisplayer.display(l1, "ulSigType");
    short s = this.sResult;
    localJceDisplayer.display(s, "sResult");
    long l2 = this.length;
    localJceDisplayer.display(l2, "length");
    byte[] arrayOfByte = this.SigContent;
    localJceDisplayer.display(arrayOfByte, "SigContent");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (CustomSigContent)paramObject;
    long l1 = this.ulSigType;
    long l2 = paramObject.ulSigType;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      short s1 = this.sResult;
      short s2 = paramObject.sResult;
      boolean bool2 = JceUtil.equals(s1, s2);
      if (bool2)
      {
        l1 = this.length;
        long l3 = paramObject.length;
        bool2 = JceUtil.equals(l1, l3);
        if (bool2)
        {
          Object localObject1 = this.SigContent;
          byte[] arrayOfByte = paramObject.SigContent;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte);
          if (localObject1 != 0)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public long getLength()
  {
    return this.length;
  }

  public short getSResult()
  {
    return this.sResult;
  }

  public byte[] getSigContent()
  {
    return this.SigContent;
  }

  public long getUlSigType()
  {
    return this.ulSigType;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.ulSigType;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    setUlSigType(localObject1);
    short s1 = this.sResult;
    short s2 = paramJceInputStream.read(s1, j, j);
    setSResult(s2);
    long l3 = this.length;
    long l4 = paramJceInputStream.read(l3, 2, j);
    Object localObject2;
    setLength(localObject2);
    if (cache_SigContent == null)
    {
      cache_SigContent = (byte[])new byte[j];
      ((byte[])cache_SigContent)[i] = i;
    }
    byte[] arrayOfByte1 = cache_SigContent;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 3, j);
    setSigContent(arrayOfByte2);
  }

  public void setLength(long paramLong)
  {
    this.length = paramLong;
  }

  public void setSResult(short paramShort)
  {
    this.sResult = paramShort;
  }

  public void setSigContent(byte[] paramArrayOfByte)
  {
    this.SigContent = paramArrayOfByte;
  }

  public void setUlSigType(long paramLong)
  {
    this.ulSigType = paramLong;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.ulSigType;
    paramJceOutputStream.write(l1, 0);
    short s = this.sResult;
    paramJceOutputStream.write(s, 1);
    long l2 = this.length;
    paramJceOutputStream.write(l2, 2);
    byte[] arrayOfByte = this.SigContent;
    paramJceOutputStream.write(arrayOfByte, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.CustomSigContent
 * JD-Core Version:    0.5.4
 */