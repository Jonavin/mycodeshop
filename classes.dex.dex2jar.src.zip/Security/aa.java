package Security;

public final class aa
{
  public static final int a = 0;
  public static final int b = 1;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.aa
 * JD-Core Version:    0.5.4
 */