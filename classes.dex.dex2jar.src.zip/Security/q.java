package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class q extends JceStruct
{
  static byte[] k;
  static byte[] l;
  public int a = null;
  public int b = null;
  public int c = null;
  public String d = "";
  public int e = null;
  public int f = null;
  public byte[] g = null;
  public byte[] h = null;
  public int i = null;
  public int j = null;

  static
  {
    if (!q.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = m;
      return;
    }
  }

  public q()
  {
    int i1 = this.a;
    a(i1);
    int i2 = this.b;
    b(i2);
    int i3 = this.c;
    c(i3);
    String str = this.d;
    a(str);
    int i4 = this.e;
    d(i4);
    int i5 = this.f;
    e(i5);
    byte[] arrayOfByte1 = this.g;
    a(arrayOfByte1);
    byte[] arrayOfByte2 = this.h;
    b(arrayOfByte2);
    int i6 = this.i;
    f(i6);
    int i7 = this.j;
    g(i7);
  }

  public q(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4, int paramInt5, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt6, int paramInt7)
  {
    a(paramInt1);
    b(paramInt2);
    c(paramInt3);
    a(paramString);
    d(paramInt4);
    e(paramInt5);
    a(paramArrayOfByte1);
    b(paramArrayOfByte2);
    f(paramInt6);
    g(paramInt7);
  }

  public String a()
  {
    return "Security.RespondHeader";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(String paramString)
  {
    this.d = paramString;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.g = paramArrayOfByte;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public void b(byte[] paramArrayOfByte)
  {
    this.h = paramArrayOfByte;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.c = paramInt;
  }

  public Object clone()
  {
    int i1 = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      m = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void d(int paramInt)
  {
    this.e = paramInt;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i1 = this.a;
    localJceDisplayer.display(i1, "ver");
    int i2 = this.b;
    localJceDisplayer.display(i2, "cmd");
    int i3 = this.c;
    localJceDisplayer.display(i3, "requestID");
    String str = this.d;
    localJceDisplayer.display(str, "uin");
    int i4 = this.e;
    localJceDisplayer.display(i4, "svrSeqNo");
    int i5 = this.f;
    localJceDisplayer.display(i5, "result");
    byte[] arrayOfByte1 = this.g;
    localJceDisplayer.display(arrayOfByte1, "A3");
    byte[] arrayOfByte2 = this.h;
    localJceDisplayer.display(arrayOfByte2, "D1");
    int i6 = this.i;
    localJceDisplayer.display(i6, "key_4");
    int i7 = this.j;
    localJceDisplayer.display(i7, "sidLen");
  }

  public String e()
  {
    return this.d;
  }

  public void e(int paramInt)
  {
    this.f = paramInt;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (q)paramObject;
    int i1 = this.a;
    int i9 = paramObject.a;
    boolean bool1 = JceUtil.equals(i1, i9);
    int i8;
    if (bool1)
    {
      int i2 = this.b;
      int i10 = paramObject.b;
      boolean bool2 = JceUtil.equals(i2, i10);
      if (bool2)
      {
        int i3 = this.c;
        int i11 = paramObject.c;
        boolean bool3 = JceUtil.equals(i3, i11);
        if (bool3)
        {
          Object localObject1 = this.d;
          String str = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, str);
          if (localObject1 != 0)
          {
            int i4 = this.e;
            int i12 = paramObject.e;
            boolean bool4 = JceUtil.equals(i4, i12);
            if (bool4)
            {
              int i5 = this.f;
              int i13 = paramObject.f;
              boolean bool5 = JceUtil.equals(i5, i13);
              if (bool5)
              {
                Object localObject2 = this.g;
                byte[] arrayOfByte1 = paramObject.g;
                localObject2 = JceUtil.equals(localObject2, arrayOfByte1);
                if (localObject2 != 0)
                {
                  localObject2 = this.h;
                  byte[] arrayOfByte2 = paramObject.h;
                  localObject2 = JceUtil.equals(localObject2, arrayOfByte2);
                  if (localObject2 != 0)
                  {
                    int i6 = this.i;
                    int i14 = paramObject.i;
                    boolean bool6 = JceUtil.equals(i6, i14);
                    if (bool6)
                    {
                      int i7 = this.j;
                      int i15 = paramObject.j;
                      boolean bool7 = JceUtil.equals(i7, i15);
                      if (bool7)
                        i8 = 1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i8;
      Object localObject3 = null;
    }
  }

  public int f()
  {
    return this.e;
  }

  public void f(int paramInt)
  {
    this.i = paramInt;
  }

  public int g()
  {
    return this.f;
  }

  public void g(int paramInt)
  {
    this.j = paramInt;
  }

  public byte[] h()
  {
    return this.g;
  }

  public byte[] i()
  {
    return this.h;
  }

  public int j()
  {
    return this.i;
  }

  public int k()
  {
    return this.j;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i1 = null;
    int i2 = 1;
    int i3 = this.a;
    int i4 = paramJceInputStream.read(i3, i1, i2);
    a(i4);
    int i5 = this.b;
    int i6 = paramJceInputStream.read(i5, i2, i2);
    b(i6);
    int i7 = this.c;
    int i8 = paramJceInputStream.read(i7, 2, i2);
    c(i8);
    String str = paramJceInputStream.readString(3, i2);
    a(str);
    int i9 = this.e;
    int i10 = paramJceInputStream.read(i9, 4, i2);
    d(i10);
    int i11 = this.f;
    int i12 = paramJceInputStream.read(i11, 5, i2);
    e(i12);
    if (k == null)
    {
      k = (byte[])new byte[i2];
      ((byte[])k)[i1] = i1;
    }
    byte[] arrayOfByte1 = k;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 6, i2);
    a(arrayOfByte2);
    if (l == null)
    {
      l = (byte[])new byte[i2];
      ((byte[])l)[i1] = i1;
    }
    byte[] arrayOfByte3 = l;
    byte[] arrayOfByte4 = (byte[])paramJceInputStream.read(arrayOfByte3, 7, i2);
    b(arrayOfByte4);
    int i13 = this.i;
    int i14 = paramJceInputStream.read(i13, 8, i2);
    f(i14);
    int i15 = this.j;
    int i16 = paramJceInputStream.read(i15, 9, i1);
    g(i16);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i1 = this.a;
    paramJceOutputStream.write(i1, 0);
    int i2 = this.b;
    paramJceOutputStream.write(i2, 1);
    int i3 = this.c;
    paramJceOutputStream.write(i3, 2);
    String str = this.d;
    paramJceOutputStream.write(str, 3);
    int i4 = this.e;
    paramJceOutputStream.write(i4, 4);
    int i5 = this.f;
    paramJceOutputStream.write(i5, 5);
    byte[] arrayOfByte1 = this.g;
    paramJceOutputStream.write(arrayOfByte1, 6);
    byte[] arrayOfByte2 = this.h;
    paramJceOutputStream.write(arrayOfByte2, 7);
    int i6 = this.i;
    paramJceOutputStream.write(i6, 8);
    int i7 = this.j;
    paramJceOutputStream.write(i7, 9);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.q
 * JD-Core Version:    0.5.4
 */