package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class WbExchangeUinPara extends JceStruct
{
  public int dwSubCmd = null;

  static
  {
    if (!WbExchangeUinPara.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public WbExchangeUinPara()
  {
    int i = this.dwSubCmd;
    setDwSubCmd(i);
  }

  public WbExchangeUinPara(int paramInt)
  {
    setDwSubCmd(paramInt);
  }

  public String className()
  {
    return "Security.WbExchangeUinPara";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.dwSubCmd;
    localJceDisplayer.display(i, "dwSubCmd");
  }

  public boolean equals(Object paramObject)
  {
    WbExchangeUinPara localWbExchangeUinPara = (WbExchangeUinPara)paramObject;
    int i = this.dwSubCmd;
    int j = paramObject.dwSubCmd;
    return JceUtil.equals(i, j);
  }

  public int getDwSubCmd()
  {
    return this.dwSubCmd;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.dwSubCmd;
    int j = paramJceInputStream.read(i, 0, true);
    setDwSubCmd(j);
  }

  public void setDwSubCmd(int paramInt)
  {
    this.dwSubCmd = paramInt;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.dwSubCmd;
    paramJceOutputStream.write(i, 0);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.WbExchangeUinPara
 * JD-Core Version:    0.5.4
 */