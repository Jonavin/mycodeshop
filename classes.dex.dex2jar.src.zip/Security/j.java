package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class j extends JceStruct
{
  static byte[] d;
  public int a = null;
  public int b = null;
  public byte[] c = null;

  static
  {
    if (!j.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public j()
  {
    int i = this.a;
    a(i);
    int j = this.b;
    b(j);
    byte[] arrayOfByte = this.c;
    a(arrayOfByte);
  }

  public j(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    a(paramInt1);
    b(paramInt2);
    a(paramArrayOfByte);
  }

  public String a()
  {
    return "Security.RequestNameExchangeUin";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.c = paramArrayOfByte;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public int c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public byte[] d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "vpic_type");
    int j = this.b;
    localJceDisplayer.display(j, "vpic_format");
    byte[] arrayOfByte = this.c;
    localJceDisplayer.display(arrayOfByte, "ksid");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (j)paramObject;
    int i = this.a;
    int l = paramObject.a;
    boolean bool1 = JceUtil.equals(i, l);
    int k;
    if (bool1)
    {
      int j = this.b;
      int i1 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i1);
      if (bool2)
      {
        Object localObject1 = this.c;
        byte[] arrayOfByte = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, arrayOfByte);
        if (localObject1 != 0)
          k = 1;
      }
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    int k = this.a;
    int l = paramJceInputStream.read(k, i, j);
    a(l);
    int i1 = this.b;
    int i2 = paramJceInputStream.read(i1, j, j);
    b(i2);
    if (d == null)
    {
      d = (byte[])new byte[j];
      ((byte[])d)[i] = i;
    }
    byte[] arrayOfByte1 = d;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 2, j);
    a(arrayOfByte2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    int j = this.b;
    paramJceOutputStream.write(j, 1);
    byte[] arrayOfByte = this.c;
    paramJceOutputStream.write(arrayOfByte, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.j
 * JD-Core Version:    0.5.4
 */