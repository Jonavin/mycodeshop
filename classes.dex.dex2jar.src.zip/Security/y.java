package Security;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class y extends JceStruct
{
  static byte[] e;
  public int a = null;
  public int b = null;
  public int c = null;
  public byte[] d = null;

  static
  {
    if (!y.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = f;
      return;
    }
  }

  public y()
  {
    int i = this.a;
    a(i);
    int j = this.b;
    b(j);
    int k = this.c;
    c(k);
    byte[] arrayOfByte = this.d;
    a(arrayOfByte);
  }

  public y(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte)
  {
    a(paramInt1);
    b(paramInt2);
    c(paramInt3);
    a(paramArrayOfByte);
  }

  public String a()
  {
    return "Security.UserSimpleInfo";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(byte[] paramArrayOfByte)
  {
    this.d = paramArrayOfByte;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.c = paramInt;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      f = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "wFaceId");
    int j = this.b;
    localJceDisplayer.display(j, "cAge");
    int k = this.c;
    localJceDisplayer.display(k, "cGender");
    byte[] arrayOfByte = this.d;
    localJceDisplayer.display(arrayOfByte, "NickName");
  }

  public byte[] e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (y)paramObject;
    int i = this.a;
    int i1 = paramObject.a;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      int j = this.b;
      int i2 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i2);
      if (bool2)
      {
        int k = this.c;
        int i3 = paramObject.c;
        boolean bool3 = JceUtil.equals(k, i3);
        if (bool3)
        {
          Object localObject1 = this.d;
          byte[] arrayOfByte = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, arrayOfByte);
          if (localObject1 != 0)
            l = 1;
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    int k = this.a;
    int l = paramJceInputStream.read(k, i, j);
    a(l);
    int i1 = this.b;
    int i2 = paramJceInputStream.read(i1, j, j);
    b(i2);
    int i3 = this.c;
    int i4 = paramJceInputStream.read(i3, 2, j);
    c(i4);
    if (e == null)
    {
      e = (byte[])new byte[j];
      ((byte[])e)[i] = i;
    }
    byte[] arrayOfByte1 = e;
    byte[] arrayOfByte2 = (byte[])paramJceInputStream.read(arrayOfByte1, 3, j);
    a(arrayOfByte2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    int j = this.b;
    paramJceOutputStream.write(j, 1);
    int k = this.c;
    paramJceOutputStream.write(k, 2);
    byte[] arrayOfByte = this.d;
    paramJceOutputStream.write(arrayOfByte, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     Security.y
 * JD-Core Version:    0.5.4
 */