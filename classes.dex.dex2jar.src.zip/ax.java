import android.app.Activity;
import android.app.ActivityGroup;
import android.os.Handler;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ChatWindowActivity.MessageListView;
import com.tencent.mobileqq.adapter.ChatMessageListAdapter;

public final class ax
  implements ca
{
  public ax(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void a(int paramInt1, int paramInt2)
  {
    int i = 72;
    int j = 1;
    int k = 1120403456;
    Activity localActivity = ((ActivityGroup)this.a.getParent()).getCurrentActivity();
    ChatWindowActivity localChatWindowActivity = this.a;
    if (localActivity != localChatWindowActivity);
    while (true)
    {
      return;
      if (this.a.c)
        this.a.c = null;
      if ((paramInt1 < i) || (paramInt2 < i) || (paramInt2 == 0))
        continue;
      if (paramInt1 > paramInt2)
      {
        int l = paramInt1 - paramInt2;
        int i1 = (int)(ChatWindowActivity.access$2200(this.a) * k);
        if (l > i1)
          ChatWindowActivity.access$1900(this.a).sendEmptyMessage(6);
      }
      if (paramInt1 >= paramInt2)
        continue;
      int i2 = paramInt2 - paramInt1;
      int i3 = (int)(ChatWindowActivity.access$2200(this.a) * k);
      if (i2 <= i3)
        continue;
      int i4 = ChatWindowActivity.access$2300(this.a).getLastVisiblePosition();
      int i5 = ChatWindowActivity.access$100(this.a).getCount() - j;
      if (i4 >= i5)
      {
        ChatWindowActivity.MessageListView localMessageListView = ChatWindowActivity.access$2300(this.a);
        int i6 = ChatWindowActivity.access$100(this.a).getCount() - j;
        localMessageListView.setSelection(i6);
      }
      ChatWindowActivity.access$1900(this.a).sendEmptyMessage(5);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ax
 * JD-Core Version:    0.5.4
 */