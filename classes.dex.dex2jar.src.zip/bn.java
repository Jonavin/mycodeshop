import com.tencent.mobileqq.activity.ChatWindowActivity;

final class bn
  implements Runnable
{
  bn(bm parambm)
  {
  }

  public final void run()
  {
    ChatWindowActivity localChatWindowActivity = this.a.a;
    String str = this.a.a.a;
    int i = ChatWindowActivity.access$2100(this.a.a);
    ChatWindowActivity.access$4400(localChatWindowActivity, str, i, null);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bn
 * JD-Core Version:    0.5.4
 */