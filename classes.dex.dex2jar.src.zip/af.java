import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatHistory;
import com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter;
import com.tencent.mobileqq.activity.PhotoPreview;

public final class af
  implements View.OnClickListener
{
  public af(ChatHistory.ChatHistoryAdapter paramChatHistoryAdapter, Uri paramUri)
  {
  }

  public final void onClick(View paramView)
  {
    Context localContext = ChatHistory.ChatHistoryAdapter.access$2400(this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter);
    Intent localIntent = new Intent(localContext, PhotoPreview.class);
    Uri localUri = this.jdField_a_of_type_AndroidNetUri;
    localIntent.setData(localUri);
    localIntent.putExtra("requestType", 6);
    localIntent.putExtra("fromHistory", true);
    localIntent.setFlags(67108864);
    this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter.a.startActivityForResult(localIntent, 200);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     af
 * JD-Core Version:    0.5.4
 */