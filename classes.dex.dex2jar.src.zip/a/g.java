package a;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class g extends JceStruct
{
  public long a = 0L;
  public byte b = null;
  public String c = "";

  static
  {
    if (!g.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = d;
      return;
    }
  }

  public g()
  {
    long l = this.a;
    a(l);
    byte b1 = this.b;
    a(b1);
    String str = this.c;
    a(str);
  }

  public g(long paramLong, byte paramByte, String paramString)
  {
    a(paramLong);
    a(???);
    a(paramByte);
  }

  public String a()
  {
    return "QQService.SvcRespPush";
  }

  public void a(byte paramByte)
  {
    this.b = paramByte;
  }

  public void a(long paramLong)
  {
    this.a = paramLong;
  }

  public void a(String paramString)
  {
    this.c = paramString;
  }

  public long b()
  {
    return this.a;
  }

  public byte c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      d = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.a;
    localJceDisplayer.display(l, "lUin");
    byte b1 = this.b;
    localJceDisplayer.display(b1, "cReplyCode");
    String str = this.c;
    localJceDisplayer.display(str, "strResult");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (g)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.b;
      byte b2 = paramObject.b;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        Object localObject1 = this.c;
        String str = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    a(localObject);
    byte b1 = this.b;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    a(b2);
    String str = paramJceInputStream.readString(2, true);
    a(str);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.a;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.b;
    paramJceOutputStream.write(b1, 1);
    String str = this.c;
    paramJceOutputStream.write(str, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     a.g
 * JD-Core Version:    0.5.4
 */