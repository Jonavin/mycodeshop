package a;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.HashMap;
import java.util.Map;

public final class d extends JceStruct
{
  static Map d;
  public long a = 0L;
  public Map b = null;
  public String c = "";

  static
  {
    if (!d.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public d()
  {
    long l = this.a;
    a(l);
    Map localMap = this.b;
    a(localMap);
    String str = this.c;
    a(str);
  }

  public d(long paramLong, Map paramMap, String paramString)
  {
    a(paramLong);
    a(???);
    a(paramMap);
  }

  public String a()
  {
    return "QQService.SvcReqPush";
  }

  public void a(long paramLong)
  {
    this.a = paramLong;
  }

  public void a(String paramString)
  {
    this.c = paramString;
  }

  public void a(Map paramMap)
  {
    this.b = paramMap;
  }

  public long b()
  {
    return this.a;
  }

  public Map c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.a;
    localJceDisplayer.display(l, "lUin");
    Map localMap = this.b;
    localJceDisplayer.display(localMap, "mpMsgPush");
    String str = this.c;
    localJceDisplayer.display(str, "sOther");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (d)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      Object localObject1 = this.b;
      Map localMap = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, localMap);
      if (localObject1 != 0)
      {
        localObject1 = this.c;
        String str = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, i);
    Object localObject;
    a(localObject);
    if (d == null)
    {
      d = new HashMap();
      Long localLong = Long.valueOf(0L);
      b localb = new b();
      d.put(localLong, localb);
    }
    Map localMap1 = d;
    Map localMap2 = (Map)paramJceInputStream.read(localMap1, i, i);
    a(localMap2);
    String str = paramJceInputStream.readString(2, i);
    a(str);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.a;
    paramJceOutputStream.write(l, 0);
    Map localMap = this.b;
    paramJceOutputStream.write(localMap, 1);
    String str = this.c;
    paramJceOutputStream.write(str, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     a.d
 * JD-Core Version:    0.5.4
 */