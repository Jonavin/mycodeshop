package a;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class a extends JceStruct
{
  public long a = 0L;
  public int b = null;
  public int c = null;
  public String d = "";

  static
  {
    if (!a.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public a()
  {
    long l = this.a;
    a(l);
    int i = this.b;
    a(i);
    int j = this.c;
    b(j);
    String str = this.d;
    a(str);
  }

  public a(long paramLong, int paramInt1, int paramInt2, String paramString)
  {
    a(paramLong);
    a(???);
    b(paramInt1);
    a(paramInt2);
  }

  public String a()
  {
    return "QQService.SvcMsgInfo";
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(long paramLong)
  {
    this.a = paramLong;
  }

  public void a(String paramString)
  {
    this.d = paramString;
  }

  public long b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  public int c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.a;
    localJceDisplayer.display(l, "lFromUin");
    int i = this.b;
    localJceDisplayer.display(i, "tTimeStamp");
    int j = this.c;
    localJceDisplayer.display(j, "iMsgType");
    String str = this.d;
    localJceDisplayer.display(str, "strOther");
  }

  public String e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (a)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool1 = JceUtil.equals(l1, l2);
    int k;
    if (bool1)
    {
      int i = this.b;
      int l = paramObject.b;
      boolean bool2 = JceUtil.equals(i, l);
      if (bool2)
      {
        int j = this.c;
        int i1 = paramObject.c;
        boolean bool3 = JceUtil.equals(j, i1);
        if (bool3)
        {
          Object localObject1 = this.d;
          String str = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, str);
          if (localObject1 != 0)
            k = 1;
        }
      }
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    a(localObject);
    int i = this.b;
    int j = paramJceInputStream.read(i, 1, true);
    a(j);
    int k = this.c;
    int l = paramJceInputStream.read(k, 2, true);
    b(l);
    String str = paramJceInputStream.readString(3, true);
    a(str);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.a;
    paramJceOutputStream.write(l, 0);
    int i = this.b;
    paramJceOutputStream.write(i, 1);
    int j = this.c;
    paramJceOutputStream.write(j, 2);
    String str = this.d;
    paramJceOutputStream.write(str, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     a.a
 * JD-Core Version:    0.5.4
 */