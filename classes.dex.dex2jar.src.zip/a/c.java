package a;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class c extends JceStruct
{
  public long a = 0L;
  public long b = 0L;
  public String c = "";
  public int d = 11;

  static
  {
    if (!c.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public c()
  {
    long l1 = this.a;
    a(l1);
    long l2 = this.b;
    b(l2);
    String str = this.c;
    a(str);
    int i = this.d;
    a(i);
  }

  public c(long paramLong1, long paramLong2, String paramString, int paramInt)
  {
    a(paramLong1);
    b(???);
    a(paramLong2);
    a(???);
  }

  public String a()
  {
    return "QQService.SvcReqGet";
  }

  public void a(int paramInt)
  {
    this.d = paramInt;
  }

  public void a(long paramLong)
  {
    this.a = paramLong;
  }

  public void a(String paramString)
  {
    this.c = paramString;
  }

  public long b()
  {
    return this.a;
  }

  public void b(long paramLong)
  {
    this.b = paramLong;
  }

  public long c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public String d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.a;
    localJceDisplayer.display(l1, "lUin");
    long l2 = this.b;
    localJceDisplayer.display(l2, "lBid");
    String str = this.c;
    localJceDisplayer.display(str, "sOther");
    int i = this.d;
    localJceDisplayer.display(i, "iStatus");
  }

  public int e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (c)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      l1 = this.b;
      long l3 = paramObject.b;
      bool1 = JceUtil.equals(l1, l3);
      if (bool1)
      {
        Object localObject1 = this.c;
        String str = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          int i = this.d;
          int k = paramObject.d;
          boolean bool2 = JceUtil.equals(i, k);
          if (bool2)
            j = 1;
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    a(localObject1);
    long l3 = this.b;
    long l4 = paramJceInputStream.read(l3, 1, true);
    Object localObject2;
    b(localObject2);
    String str = paramJceInputStream.readString(2, true);
    a(str);
    int i = this.d;
    int j = paramJceInputStream.read(i, 3, null);
    a(j);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.a;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.b;
    paramJceOutputStream.write(l2, 1);
    String str = this.c;
    paramJceOutputStream.write(str, 2);
    int i = this.d;
    paramJceOutputStream.write(i, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     a.c
 * JD-Core Version:    0.5.4
 */