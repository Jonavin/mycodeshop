import android.os.Handler;
import android.os.Message;
import android.view.Window;
import com.tencent.mobileqq.activity.ChatVideoActivity;

public final class av extends Handler
{
  private av(ChatVideoActivity paramChatVideoActivity, byte paramByte)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 4:
    }
    while (true)
    {
      return;
      this.a.getWindow().clearFlags(128);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     av
 * JD-Core Version:    0.5.4
 */