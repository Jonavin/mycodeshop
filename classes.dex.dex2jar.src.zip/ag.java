import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter;

public final class ag
  implements View.OnClickListener
{
  public ag(ChatHistory.ChatHistoryAdapter paramChatHistoryAdapter, Button paramButton, String paramString, int paramInt)
  {
  }

  public final void onClick(View paramView)
  {
    new ah(this).run();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ag
 * JD-Core Version:    0.5.4
 */