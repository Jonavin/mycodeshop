import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;

public final class bp
  implements Animation.AnimationListener
{
  public bp(ChatWindowActivity paramChatWindowActivity, float paramFloat1, float paramFloat2)
  {
  }

  public final void onAnimationEnd(Animation paramAnimation)
  {
    int i = 0;
    int j = 8;
    int k = this.jdField_a_of_type_Float;
    int l = this.b;
    if (k > l)
    {
      ChatWindowActivity localChatWindowActivity1 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
      String str1 = ChatWindowActivity.access$4500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i1 = ChatWindowActivity.access$2400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      localChatWindowActivity1.b(str1, i1);
      ChatWindowActivity.access$4100(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ChatWindowActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(j);
      ChatWindowActivity.access$1600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(j);
      ChatWindowActivity.access$1400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(i);
      ChatWindowActivity.access$1700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(i);
    }
    while (true)
    {
      return;
      if (ChatWindowActivity.access$1100(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity) != null)
      {
        String str2 = ChatWindowActivity.access$1100(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        String str3 = ChatWindowActivity.access$1200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        if (!str2.equals(str3))
        {
          ChatWindowActivity localChatWindowActivity2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
          UnreadMsgFriendInfo localUnreadMsgFriendInfo = ChatWindowActivity.access$4600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
          localChatWindowActivity2.a(localUnreadMsgFriendInfo);
        }
      }
      ChatWindowActivity.access$1600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(j);
      ChatWindowActivity.access$1700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(i);
      ChatWindowActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setVisibility(j);
    }
  }

  public final void onAnimationRepeat(Animation paramAnimation)
  {
  }

  public final void onAnimationStart(Animation paramAnimation)
  {
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bp
 * JD-Core Version:    0.5.4
 */