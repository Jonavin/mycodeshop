import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.utils.Recorder;
import com.tencent.qphone.base.util.QLog;

public final class br extends Handler
{
  public br(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    int i = 1200;
    ChatWindowActivity localChatWindowActivity1 = 200;
    ChatWindowActivity localChatWindowActivity2 = 1;
    int j = 0;
    Object localObject1 = ChatWindowActivity.access$2500(this.a);
    Object localObject2 = ((cb)localObject1).a;
    if (localObject2 != null)
      localObject1 = ((cb)localObject1).a.a();
    while (true)
    {
      int k;
      localObject1 /= 10;
      localObject2 = "wdc";
      String str = "amplitude: " + k;
      QLog.v((String)localObject2, str);
      label94: ChatWindowActivity localChatWindowActivity3;
      if (k > i)
      {
        k = i;
        localObject2 = this.a;
        int i2 = this.a.f;
        k = k * i2 / 1200;
        ((ChatWindowActivity)localObject2).g = k;
        localObject2 = new StringBuilder().append("AniEndY: ");
        int i3 = this.a.g;
        localObject2 = i3;
        QLog.v("wdc", (String)localObject2);
        localChatWindowActivity3 = this.a;
        localChatWindowActivity5 = this.a.g;
        if (localChatWindowActivity5 != 0)
          break label286;
      }
      label286: int i1;
      for (ChatWindowActivity localChatWindowActivity5 = localChatWindowActivity2; ; i1 = this.a.g)
      {
        localChatWindowActivity3.a(localChatWindowActivity5);
        sendEmptyMessageDelayed(j, 300L);
        return;
        ChatWindowActivity localChatWindowActivity4;
        if (localChatWindowActivity3 > localChatWindowActivity1)
        {
          localChatWindowActivity5 = 500;
          if (localChatWindowActivity3 < localChatWindowActivity5)
            localChatWindowActivity4 = localChatWindowActivity3 / 10 + 600;
        }
        ChatWindowActivity localChatWindowActivity6 = 30;
        if ((localChatWindowActivity4 > localChatWindowActivity6) && (localChatWindowActivity4 < localChatWindowActivity1))
          l = localChatWindowActivity4 / 10 + 500;
        if (l <= 0);
        l = localChatWindowActivity2;
        break label94:
      }
      int l = j;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     br
 * JD-Core Version:    0.5.4
 */