import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;

final class an
  implements View.OnClickListener
{
  an(al paramal)
  {
  }

  public final void onClick(View paramView)
  {
    ChatVideoActivity.access$1400(this.a.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     an
 * JD-Core Version:    0.5.4
 */