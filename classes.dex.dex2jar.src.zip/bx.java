import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bx
  implements View.OnClickListener
{
  public bx(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity localChatWindowActivity = this.a;
    int i = ChatWindowActivity.access$800(this.a);
    if (i == 0);
    for (int j = 1; ; j = 0)
    {
      ChatWindowActivity.access$802(localChatWindowActivity, j);
      ChatWindowActivity.access$900(this.a);
      return;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bx
 * JD-Core Version:    0.5.4
 */