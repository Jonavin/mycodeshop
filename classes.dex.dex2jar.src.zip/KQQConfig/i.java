package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class i extends JceStruct
{
  static ArrayList b;
  public ArrayList a = null;

  static
  {
    if (!i.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = c;
      return;
    }
  }

  public i()
  {
    ArrayList localArrayList = this.a;
    a(localArrayList);
  }

  public i(ArrayList paramArrayList)
  {
    a(paramArrayList);
  }

  public String a()
  {
    return "KQQConfig.SDKUpgradeRes";
  }

  public void a(ArrayList paramArrayList)
  {
    this.a = paramArrayList;
  }

  public ArrayList b()
  {
    return this.a;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      c = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    ArrayList localArrayList = this.a;
    localJceDisplayer.display(localArrayList, "vUpgradeInfo");
  }

  public boolean equals(Object paramObject)
  {
    i locali = (i)paramObject;
    ArrayList localArrayList1 = this.a;
    ArrayList localArrayList2 = paramObject.a;
    return JceUtil.equals(localArrayList1, localArrayList2);
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    if (b == null)
    {
      b = new ArrayList();
      j localj = new j();
      b.add(localj);
    }
    ArrayList localArrayList1 = b;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, i, i);
    a(localArrayList2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    ArrayList localArrayList = this.a;
    paramJceOutputStream.write(localArrayList, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.i
 * JD-Core Version:    0.5.4
 */