package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class c extends JceStruct
{
  public int a = null;
  public String b = "";

  static
  {
    if (!c.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = c;
      return;
    }
  }

  public c()
  {
    int i = this.a;
    a(i);
    String str = this.b;
    a(str);
  }

  public c(int paramInt, String paramString)
  {
    a(paramInt);
    a(paramString);
  }

  public String a()
  {
    return "KQQConfig.GrayUinCheckReq";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(String paramString)
  {
    this.b = paramString;
  }

  public int b()
  {
    return this.a;
  }

  public String c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      c = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "appid");
    String str = this.b;
    localJceDisplayer.display(str, "uin");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (c)paramObject;
    int i = this.a;
    int k = paramObject.a;
    boolean bool = JceUtil.equals(i, k);
    int j;
    if (bool)
    {
      Object localObject1 = this.b;
      String str = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
        j = 1;
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 1, true);
    a(j);
    String str = paramJceInputStream.readString(2, true);
    a(str);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 1);
    String str = this.b;
    paramJceOutputStream.write(str, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.c
 * JD-Core Version:    0.5.4
 */