package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class f extends JceStruct
{
  static ArrayList e;
  public int a = null;
  public int b = null;
  public ArrayList c = null;
  public int d = null;

  static
  {
    if (!f.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = f;
      return;
    }
  }

  public f()
  {
    int i = this.a;
    a(i);
    int j = this.b;
    b(j);
    ArrayList localArrayList = this.c;
    a(localArrayList);
    int k = this.d;
    c(k);
  }

  public f(int paramInt1, int paramInt2, ArrayList paramArrayList, int paramInt3)
  {
    a(paramInt1);
    b(paramInt2);
    a(paramArrayList);
    c(paramInt3);
  }

  public String a()
  {
    return "KQQConfig.SDKConfReq";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(ArrayList paramArrayList)
  {
    this.c = paramArrayList;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.d = paramInt;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      f = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public ArrayList d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "iConfVersion");
    int j = this.b;
    localJceDisplayer.display(j, "iGetSdkLastTime");
    ArrayList localArrayList = this.c;
    localJceDisplayer.display(localArrayList, "sUin");
    int k = this.d;
    localJceDisplayer.display(k, "iGetEspLastTime");
  }

  public int e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (f)paramObject;
    int i = this.a;
    int i1 = paramObject.a;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      int j = this.b;
      int i2 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i2);
      if (bool2)
      {
        Object localObject1 = this.c;
        ArrayList localArrayList = paramObject.c;
        localObject1 = JceUtil.equals(localObject1, localArrayList);
        if (localObject1 != 0)
        {
          int k = this.d;
          int i3 = paramObject.d;
          boolean bool3 = JceUtil.equals(k, i3);
          if (bool3)
            l = 1;
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    boolean bool = null;
    int i = this.a;
    int j = paramJceInputStream.read(i, 1, bool);
    a(j);
    int k = this.b;
    int l = paramJceInputStream.read(k, 2, bool);
    b(l);
    if (e == null)
    {
      e = new ArrayList();
      e.add("");
    }
    ArrayList localArrayList1 = e;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 3, bool);
    a(localArrayList2);
    int i1 = this.d;
    int i2 = paramJceInputStream.read(i1, 4, bool);
    c(i2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 1);
    int j = this.b;
    paramJceOutputStream.write(j, 2);
    if (this.c != null)
    {
      ArrayList localArrayList = this.c;
      paramJceOutputStream.write(localArrayList, 3);
    }
    int k = this.d;
    paramJceOutputStream.write(k, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.f
 * JD-Core Version:    0.5.4
 */