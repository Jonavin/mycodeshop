package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class g extends JceStruct
{
  public int a = null;
  public int b = null;
  public int c = null;
  public String d = "";
  public int e = null;
  public String f = "";

  static
  {
    if (!g.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = g;
      return;
    }
  }

  public g()
  {
    int i = this.a;
    a(i);
    int j = this.b;
    b(j);
    int k = this.c;
    c(k);
    String str1 = this.d;
    a(str1);
    int l = this.e;
    d(l);
    String str2 = this.f;
    b(str2);
  }

  public g(int paramInt1, int paramInt2, int paramInt3, String paramString1, int paramInt4, String paramString2)
  {
    a(paramInt1);
    b(paramInt2);
    c(paramInt3);
    a(paramString1);
    d(paramInt4);
    b(paramString2);
  }

  public String a()
  {
    return "KQQConfig.SDKConfRes";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(String paramString)
  {
    this.d = paramString;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.b = paramInt;
  }

  public void b(String paramString)
  {
    this.f = paramString;
  }

  public int c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.c = paramInt;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      g = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void d(int paramInt)
  {
    this.e = paramInt;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "iUpdateType");
    int j = this.b;
    localJceDisplayer.display(j, "iGetSdkNewTime");
    int k = this.c;
    localJceDisplayer.display(k, "iNewConfVersion");
    String str1 = this.d;
    localJceDisplayer.display(str1, "sConf");
    int l = this.e;
    localJceDisplayer.display(l, "iEspConfTime");
    String str2 = this.f;
    localJceDisplayer.display(str2, "sEspConf");
  }

  public String e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (g)paramObject;
    int i = this.a;
    int i2 = paramObject.a;
    boolean bool1 = JceUtil.equals(i, i2);
    int i1;
    if (bool1)
    {
      int j = this.b;
      int i3 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i3);
      if (bool2)
      {
        int k = this.c;
        int i4 = paramObject.c;
        boolean bool3 = JceUtil.equals(k, i4);
        if (bool3)
        {
          Object localObject1 = this.d;
          String str1 = paramObject.d;
          localObject1 = JceUtil.equals(localObject1, str1);
          if (localObject1 != 0)
          {
            int l = this.e;
            int i5 = paramObject.e;
            boolean bool4 = JceUtil.equals(l, i5);
            if (bool4)
            {
              Object localObject2 = this.f;
              String str2 = paramObject.f;
              localObject2 = JceUtil.equals(localObject2, str2);
              if (localObject2 != 0)
                i1 = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return i1;
      Object localObject3 = null;
    }
  }

  public int f()
  {
    return this.e;
  }

  public String g()
  {
    return this.f;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 1, true);
    a(j);
    int k = this.b;
    int l = paramJceInputStream.read(k, 2, null);
    b(l);
    int i1 = this.c;
    int i2 = paramJceInputStream.read(i1, 3, null);
    c(i2);
    String str1 = paramJceInputStream.readString(4, null);
    a(str1);
    int i3 = this.e;
    int i4 = paramJceInputStream.read(i3, 5, null);
    d(i4);
    String str2 = paramJceInputStream.readString(6, null);
    b(str2);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 1);
    int j = this.b;
    paramJceOutputStream.write(j, 2);
    int k = this.c;
    paramJceOutputStream.write(k, 3);
    if (this.d != null)
    {
      String str1 = this.d;
      paramJceOutputStream.write(str1, 4);
    }
    int l = this.e;
    paramJceOutputStream.write(l, 5);
    if (this.f == null)
      return;
    String str2 = this.f;
    paramJceOutputStream.write(str2, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.g
 * JD-Core Version:    0.5.4
 */