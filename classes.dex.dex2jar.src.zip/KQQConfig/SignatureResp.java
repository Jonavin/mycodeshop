package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SignatureResp extends JceStruct
{
  public int status = null;

  static
  {
    if (!SignatureResp.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SignatureResp()
  {
    int i = this.status;
    setStatus(i);
  }

  public SignatureResp(int paramInt)
  {
    setStatus(paramInt);
  }

  public String className()
  {
    return "KQQConfig.SignatureResp";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.status;
    localJceDisplayer.display(i, "status");
  }

  public boolean equals(Object paramObject)
  {
    SignatureResp localSignatureResp = (SignatureResp)paramObject;
    int i = this.status;
    int j = paramObject.status;
    return JceUtil.equals(i, j);
  }

  public int getStatus()
  {
    return this.status;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.status;
    int j = paramJceInputStream.read(i, 1, true);
    setStatus(j);
  }

  public void setStatus(int paramInt)
  {
    this.status = paramInt;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.status;
    paramJceOutputStream.write(i, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.SignatureResp
 * JD-Core Version:    0.5.4
 */