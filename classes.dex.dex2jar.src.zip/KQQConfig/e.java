package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class e extends JceStruct
{
  public String a = "";
  public int b = null;
  public byte c = null;
  public String d = "";
  public byte e = 1;
  public byte f = 1;

  static
  {
    if (!e.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = g;
      return;
    }
  }

  public e()
  {
    String str1 = this.a;
    a(str1);
    int i = this.b;
    a(i);
    byte b1 = this.c;
    a(b1);
    String str2 = this.d;
    b(str2);
    byte b2 = this.e;
    b(b2);
    byte b3 = this.f;
    c(b3);
  }

  public e(String paramString1, int paramInt, byte paramByte1, String paramString2, byte paramByte2, byte paramByte3)
  {
    a(paramString1);
    a(paramInt);
    a(paramByte1);
    b(paramString2);
    b(paramByte2);
    c(paramByte3);
  }

  public String a()
  {
    return "KQQConfig.MeasureInfo";
  }

  public void a(byte paramByte)
  {
    this.c = paramByte;
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(String paramString)
  {
    this.a = paramString;
  }

  public String b()
  {
    return this.a;
  }

  public void b(byte paramByte)
  {
    this.e = paramByte;
  }

  public void b(String paramString)
  {
    this.d = paramString;
  }

  public int c()
  {
    return this.b;
  }

  public void c(byte paramByte)
  {
    this.f = paramByte;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      g = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public byte d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    String str1 = this.a;
    localJceDisplayer.display(str1, "sIP");
    int i = this.b;
    localJceDisplayer.display(i, "iPort");
    byte b1 = this.c;
    localJceDisplayer.display(b1, "bLinkType");
    String str2 = this.d;
    localJceDisplayer.display(str2, "sImsi");
    byte b2 = this.e;
    localJceDisplayer.display(b2, "bProxy");
    byte b3 = this.f;
    localJceDisplayer.display(b3, "bDefault");
  }

  public String e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (e)paramObject;
    Object localObject1 = this.a;
    String str1 = paramObject.a;
    localObject1 = JceUtil.equals(localObject1, str1);
    int j;
    if (localObject1 != 0)
    {
      int i = this.b;
      int k = paramObject.b;
      boolean bool1 = JceUtil.equals(i, k);
      if (bool1)
      {
        byte b1 = this.c;
        byte b4 = paramObject.c;
        boolean bool2 = JceUtil.equals(b1, b4);
        if (bool2)
        {
          Object localObject2 = this.d;
          String str2 = paramObject.d;
          localObject2 = JceUtil.equals(localObject2, str2);
          if (localObject2 != 0)
          {
            byte b2 = this.e;
            byte b5 = paramObject.e;
            boolean bool3 = JceUtil.equals(b2, b5);
            if (bool3)
            {
              byte b3 = this.f;
              byte b6 = paramObject.f;
              boolean bool4 = JceUtil.equals(b3, b6);
              if (bool4)
                j = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public byte f()
  {
    return this.e;
  }

  public byte g()
  {
    return this.f;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    String str1 = paramJceInputStream.readString(1, true);
    a(str1);
    int i = this.b;
    int j = paramJceInputStream.read(i, 2, true);
    a(j);
    byte b1 = this.c;
    byte b2 = paramJceInputStream.read(b1, 3, true);
    a(b2);
    String str2 = paramJceInputStream.readString(4, null);
    b(str2);
    byte b3 = this.e;
    byte b4 = paramJceInputStream.read(b3, 5, null);
    b(b4);
    byte b5 = this.f;
    byte b6 = paramJceInputStream.read(b5, 6, null);
    c(b6);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    String str1 = this.a;
    paramJceOutputStream.write(str1, 1);
    int i = this.b;
    paramJceOutputStream.write(i, 2);
    byte b1 = this.c;
    paramJceOutputStream.write(b1, 3);
    if (this.d != null)
    {
      String str2 = this.d;
      paramJceOutputStream.write(str2, 4);
    }
    byte b2 = this.e;
    paramJceOutputStream.write(b2, 5);
    byte b3 = this.f;
    paramJceOutputStream.write(b3, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.e
 * JD-Core Version:    0.5.4
 */