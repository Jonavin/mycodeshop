package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class b extends JceStruct
{
  static ArrayList d;
  public int a = null;
  public ArrayList b = null;
  public int c = null;

  static
  {
    if (!b.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = e;
      return;
    }
  }

  public b()
  {
    int i = this.a;
    a(i);
    ArrayList localArrayList = this.b;
    a(localArrayList);
    int j = this.c;
    b(j);
  }

  public b(int paramInt1, ArrayList paramArrayList, int paramInt2)
  {
    a(paramInt1);
    a(paramArrayList);
    b(paramInt2);
  }

  public String a()
  {
    return "KQQConfig.GetServerListRes";
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(ArrayList paramArrayList)
  {
    this.b = paramArrayList;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  public ArrayList c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      e = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "iResult");
    ArrayList localArrayList = this.b;
    localJceDisplayer.display(localArrayList, "vServerListInfo");
    int j = this.c;
    localJceDisplayer.display(j, "iTime");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (b)paramObject;
    int i = this.a;
    int l = paramObject.a;
    boolean bool1 = JceUtil.equals(i, l);
    int k;
    if (bool1)
    {
      Object localObject1 = this.b;
      ArrayList localArrayList = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, localArrayList);
      if (localObject1 != 0)
      {
        int j = this.c;
        int i1 = paramObject.c;
        boolean bool2 = JceUtil.equals(j, i1);
        if (bool2)
          k = 1;
      }
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = this.a;
    int k = paramJceInputStream.read(j, i, i);
    a(k);
    if (d == null)
    {
      d = new ArrayList();
      e locale = new e();
      d.add(locale);
    }
    ArrayList localArrayList1 = d;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 2, i);
    a(localArrayList2);
    int l = this.c;
    int i1 = paramJceInputStream.read(l, 3, i);
    b(i1);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 1);
    ArrayList localArrayList = this.b;
    paramJceOutputStream.write(localArrayList, 2);
    int j = this.c;
    paramJceOutputStream.write(j, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.b
 * JD-Core Version:    0.5.4
 */