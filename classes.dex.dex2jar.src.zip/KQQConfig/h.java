package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class h extends JceStruct
{
  static ArrayList e;
  static ArrayList f;
  public byte a = null;
  public ArrayList b = null;
  public boolean c = true;
  public ArrayList d = null;

  static
  {
    if (!h.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = g;
      return;
    }
  }

  public h()
  {
    byte b1 = this.a;
    a(b1);
    ArrayList localArrayList1 = this.b;
    a(localArrayList1);
    boolean bool = this.c;
    a(bool);
    ArrayList localArrayList2 = this.d;
    b(localArrayList2);
  }

  public h(byte paramByte, ArrayList paramArrayList1, boolean paramBoolean, ArrayList paramArrayList2)
  {
    a(paramByte);
    a(paramArrayList1);
    a(paramBoolean);
    b(paramArrayList2);
  }

  public String a()
  {
    return "KQQConfig.SDKUpgradeReq";
  }

  public void a(byte paramByte)
  {
    this.a = paramByte;
  }

  public void a(ArrayList paramArrayList)
  {
    this.b = paramArrayList;
  }

  public void a(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }

  public byte b()
  {
    return this.a;
  }

  public void b(ArrayList paramArrayList)
  {
    this.d = paramArrayList;
  }

  public ArrayList c()
  {
    return this.b;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      g = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public boolean d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.a;
    localJceDisplayer.display(b1, "cProtocolVer");
    ArrayList localArrayList1 = this.b;
    localJceDisplayer.display(localArrayList1, "vUin");
    boolean bool = this.c;
    localJceDisplayer.display(bool, "bSdkUpdateFlag");
    ArrayList localArrayList2 = this.d;
    localJceDisplayer.display(localArrayList2, "vAppid");
  }

  public ArrayList e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (h)paramObject;
    byte b1 = this.a;
    byte b2 = paramObject.a;
    boolean bool1 = JceUtil.equals(b1, b2);
    int i;
    if (bool1)
    {
      Object localObject1 = this.b;
      ArrayList localArrayList1 = paramObject.b;
      localObject1 = JceUtil.equals(localObject1, localArrayList1);
      if (localObject1 != 0)
      {
        boolean bool2 = this.c;
        boolean bool4 = paramObject.c;
        boolean bool3 = JceUtil.equals(bool2, bool4);
        if (bool3)
        {
          Object localObject2 = this.d;
          ArrayList localArrayList2 = paramObject.d;
          localObject2 = JceUtil.equals(localObject2, localArrayList2);
          if (localObject2 != 0)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject3 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = 0;
    byte b1 = this.a;
    byte b2 = paramJceInputStream.read(b1, i, i);
    a(b2);
    if (e == null)
    {
      e = new ArrayList();
      e.add("");
    }
    ArrayList localArrayList1 = e;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 2, i);
    a(localArrayList2);
    boolean bool1 = this.c;
    boolean bool2 = paramJceInputStream.read(bool1, 3, j);
    a(bool2);
    if (f == null)
    {
      f = new ArrayList();
      Integer localInteger = Integer.valueOf(j);
      f.add(localInteger);
    }
    ArrayList localArrayList3 = f;
    ArrayList localArrayList4 = (ArrayList)paramJceInputStream.read(localArrayList3, 4, j);
    b(localArrayList4);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.a;
    paramJceOutputStream.write(b1, 1);
    ArrayList localArrayList1 = this.b;
    paramJceOutputStream.write(localArrayList1, 2);
    boolean bool = this.c;
    paramJceOutputStream.write(bool, 3);
    if (this.d == null)
      return;
    ArrayList localArrayList2 = this.d;
    paramJceOutputStream.write(localArrayList2, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.h
 * JD-Core Version:    0.5.4
 */