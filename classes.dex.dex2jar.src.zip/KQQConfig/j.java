package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class j extends JceStruct
{
  public int a = null;
  public byte b = null;
  public int c = null;
  public int d = null;
  public String e = "";
  public String f = "";
  public String g = "";

  static
  {
    if (!j.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = h;
      return;
    }
  }

  public j()
  {
    int i = this.a;
    a(i);
    byte b1 = this.b;
    a(b1);
    int j = this.c;
    b(j);
    int k = this.d;
    c(k);
    String str1 = this.e;
    a(str1);
    String str2 = this.f;
    b(str2);
    String str3 = this.g;
    c(str3);
  }

  public j(int paramInt1, byte paramByte, int paramInt2, int paramInt3, String paramString1, String paramString2, String paramString3)
  {
    a(paramInt1);
    a(paramByte);
    b(paramInt2);
    c(paramInt3);
    a(paramString1);
    b(paramString2);
    c(paramString3);
  }

  public String a()
  {
    return "KQQConfig.UpgradeInfo";
  }

  public void a(byte paramByte)
  {
    this.b = paramByte;
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(String paramString)
  {
    this.e = paramString;
  }

  public int b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }

  public void b(String paramString)
  {
    this.f = paramString;
  }

  public byte c()
  {
    return this.b;
  }

  public void c(int paramInt)
  {
    this.d = paramInt;
  }

  public void c(String paramString)
  {
    this.g = paramString;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      h = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public int d()
  {
    return this.c;
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "iAppid");
    byte b1 = this.b;
    localJceDisplayer.display(b1, "bAppType");
    int j = this.c;
    localJceDisplayer.display(j, "iUpgradeType");
    int k = this.d;
    localJceDisplayer.display(k, "iUpgradeSdkId");
    String str1 = this.e;
    localJceDisplayer.display(str1, "strTitle");
    String str2 = this.f;
    localJceDisplayer.display(str2, "strUpgradeDesc");
    String str3 = this.g;
    localJceDisplayer.display(str3, "strUrl");
  }

  public int e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (j)paramObject;
    int i = this.a;
    int i1 = paramObject.a;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      byte b1 = this.b;
      byte b2 = paramObject.b;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        int j = this.c;
        int i2 = paramObject.c;
        boolean bool3 = JceUtil.equals(j, i2);
        if (bool3)
        {
          int k = this.d;
          int i3 = paramObject.d;
          boolean bool4 = JceUtil.equals(k, i3);
          if (bool4)
          {
            Object localObject1 = this.e;
            String str1 = paramObject.e;
            localObject1 = JceUtil.equals(localObject1, str1);
            if (localObject1 != 0)
            {
              localObject1 = this.f;
              String str2 = paramObject.f;
              localObject1 = JceUtil.equals(localObject1, str2);
              if (localObject1 != 0)
              {
                localObject1 = this.g;
                String str3 = paramObject.g;
                localObject1 = JceUtil.equals(localObject1, str3);
                if (localObject1 != 0)
                  l = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public String f()
  {
    return this.e;
  }

  public String g()
  {
    return this.f;
  }

  public String h()
  {
    return this.g;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 1, true);
    a(j);
    byte b1 = this.b;
    byte b2 = paramJceInputStream.read(b1, 2, true);
    a(b2);
    int k = this.c;
    int l = paramJceInputStream.read(k, 3, true);
    b(l);
    int i1 = this.d;
    int i2 = paramJceInputStream.read(i1, 4, true);
    c(i2);
    String str1 = paramJceInputStream.readString(5, null);
    a(str1);
    String str2 = paramJceInputStream.readString(6, null);
    b(str2);
    String str3 = paramJceInputStream.readString(7, null);
    c(str3);
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 1);
    byte b1 = this.b;
    paramJceOutputStream.write(b1, 2);
    int j = this.c;
    paramJceOutputStream.write(j, 3);
    int k = this.d;
    paramJceOutputStream.write(k, 4);
    if (this.e != null)
    {
      String str1 = this.e;
      paramJceOutputStream.write(str1, 5);
    }
    if (this.f != null)
    {
      String str2 = this.f;
      paramJceOutputStream.write(str2, 6);
    }
    if (this.g == null)
      return;
    String str3 = this.g;
    paramJceOutputStream.write(str3, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.j
 * JD-Core Version:    0.5.4
 */