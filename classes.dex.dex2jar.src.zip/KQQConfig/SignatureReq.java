package KQQConfig;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SignatureReq extends JceStruct
{
  static ArrayList cache_signatures;
  static ArrayList cache_uins;
  public byte base = null;
  public int lcid = null;
  public ArrayList signatures = null;
  public ArrayList uins = null;

  static
  {
    if (!SignatureReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SignatureReq()
  {
    ArrayList localArrayList1 = this.signatures;
    setSignatures(localArrayList1);
    int i = this.lcid;
    setLcid(i);
    ArrayList localArrayList2 = this.uins;
    setUins(localArrayList2);
    byte b = this.base;
    setBase(b);
  }

  public SignatureReq(ArrayList paramArrayList1, int paramInt, ArrayList paramArrayList2, byte paramByte)
  {
    setSignatures(paramArrayList1);
    setLcid(paramInt);
    setUins(paramArrayList2);
    setBase(paramByte);
  }

  public String className()
  {
    return "KQQConfig.SignatureReq";
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    ArrayList localArrayList1 = this.signatures;
    localJceDisplayer.display(localArrayList1, "signatures");
    int i = this.lcid;
    localJceDisplayer.display(i, "lcid");
    ArrayList localArrayList2 = this.uins;
    localJceDisplayer.display(localArrayList2, "uins");
    byte b = this.base;
    localJceDisplayer.display(b, "base");
  }

  public boolean equals(Object paramObject)
  {
    paramObject = (SignatureReq)paramObject;
    Object localObject1 = this.signatures;
    ArrayList localArrayList1 = paramObject.signatures;
    localObject1 = JceUtil.equals(localObject1, localArrayList1);
    int j;
    if (localObject1 != 0)
    {
      int i = this.lcid;
      int k = paramObject.lcid;
      boolean bool1 = JceUtil.equals(i, k);
      if (bool1)
      {
        Object localObject2 = this.uins;
        ArrayList localArrayList2 = paramObject.uins;
        localObject2 = JceUtil.equals(localObject2, localArrayList2);
        if (localObject2 != 0)
        {
          byte b1 = this.base;
          byte b2 = paramObject.base;
          boolean bool2 = JceUtil.equals(b1, b2);
          if (bool2)
            j = 1;
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public byte getBase()
  {
    return this.base;
  }

  public int getLcid()
  {
    return this.lcid;
  }

  public ArrayList getSignatures()
  {
    return this.signatures;
  }

  public ArrayList getUins()
  {
    return this.uins;
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    if (cache_signatures == null)
    {
      cache_signatures = new ArrayList();
      cache_signatures.add("");
    }
    ArrayList localArrayList1 = cache_signatures;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, i, i);
    setSignatures(localArrayList2);
    int j = this.lcid;
    int k = paramJceInputStream.read(j, 2, i);
    setLcid(k);
    if (cache_uins == null)
    {
      cache_uins = new ArrayList();
      cache_uins.add("");
    }
    ArrayList localArrayList3 = cache_uins;
    ArrayList localArrayList4 = (ArrayList)paramJceInputStream.read(localArrayList3, 3, i);
    setUins(localArrayList4);
    byte b1 = this.base;
    byte b2 = paramJceInputStream.read(b1, 4, i);
    setBase(b2);
  }

  public void setBase(byte paramByte)
  {
    this.base = paramByte;
  }

  public void setLcid(int paramInt)
  {
    this.lcid = paramInt;
  }

  public void setSignatures(ArrayList paramArrayList)
  {
    this.signatures = paramArrayList;
  }

  public void setUins(ArrayList paramArrayList)
  {
    this.uins = paramArrayList;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    ArrayList localArrayList1 = this.signatures;
    paramJceOutputStream.write(localArrayList1, 1);
    int i = this.lcid;
    paramJceOutputStream.write(i, 2);
    ArrayList localArrayList2 = this.uins;
    paramJceOutputStream.write(localArrayList2, 3);
    byte b = this.base;
    paramJceOutputStream.write(b, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQConfig.SignatureReq
 * JD-Core Version:    0.5.4
 */