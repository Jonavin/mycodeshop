import android.os.PowerManager.WakeLock;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.utils.Recorder;

public final class cb
{
  public PowerManager.WakeLock a;
  public Recorder a;

  public cb(ChatWindowActivity paramChatWindowActivity)
  {
    this.jdField_a_of_type_ComTencentMobileqqUtilsRecorder = null;
    this.jdField_a_of_type_AndroidOsPowerManager$WakeLock = null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cb
 * JD-Core Version:    0.5.4
 */