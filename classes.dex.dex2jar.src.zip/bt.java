import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bt
  implements View.OnClickListener
{
  public bt(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity.access$400(this.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bt
 * JD-Core Version:    0.5.4
 */