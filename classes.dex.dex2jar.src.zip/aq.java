import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.video.VideoController;

public final class aq
  implements DialogInterface.OnClickListener
{
  public aq(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    VideoController localVideoController1 = ChatVideoActivity.access$000(this.a);
    long l1 = ChatVideoActivity.access$2400();
    Object localObject1;
    localVideoController1.b(localObject1);
    VideoController localVideoController2 = ChatVideoActivity.access$000(this.a);
    long l2 = ChatVideoActivity.access$2400();
    Object localObject2;
    localVideoController2.a(localObject2, null);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     aq
 * JD-Core Version:    0.5.4
 */