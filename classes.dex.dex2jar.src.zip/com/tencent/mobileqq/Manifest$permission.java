package com.tencent.mobileqq;

public final class Manifest$permission
{
  public static final String pushnotify = "com.tencent.msg.permission.pushnotify";
  public static final String sync = "com.tencent.msf.permission.account.sync";
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.Manifest.permission
 * JD-Core Version:    0.5.4
 */