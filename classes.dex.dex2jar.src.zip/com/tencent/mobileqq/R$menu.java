package com.tencent.mobileqq;

public final class R$menu
{
  public static final int chatwindow = 2131427328;
  public static final int chatwindow_context = 2131427329;
  public static final int chatwindow_ptt = 2131427330;
  public static final int friendlist = 2131427331;
  public static final int login = 2131427332;
  public static final int recentlist = 2131427333;
  public static final int trooplist = 2131427334;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.menu
 * JD-Core Version:    0.5.4
 */