package com.tencent.mobileqq.content;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.RecentUser;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.QLog;
import java.util.Iterator;
import java.util.List;

public class MessageProvider extends ContentProvider
  implements Message
{
  public static final int MATCH_MESSAGE_RECORD = 1000;
  public static final int MATCH_RECENT_LIST = 1001;
  public static final int MATCH_RECENT_MESSAGE = 1002;
  public static final String TAG = "MessageProvider";
  private final UriMatcher jdField_a_of_type_AndroidContentUriMatcher;
  public SQLiteDatabase a;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;
  private String jdField_a_of_type_JavaLangString;

  public MessageProvider()
  {
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.jdField_a_of_type_AndroidContentUriMatcher = localUriMatcher;
  }

  private String a(String paramString)
  {
    int i = 3;
    int j = 2;
    int k = 1;
    Object localObject1 = paramString.split("/", 4);
    int l = localObject1.length;
    Object localObject2;
    if (l > j)
    {
      boolean bool = localObject1[j].equals("friend");
      if (bool)
      {
        localObject2 = new StringBuilder().append("mr_friend_");
        String str1 = localObject1[i];
        localObject2 = str1;
        label75: Object localObject3 = localObject1[k];
        this.jdField_a_of_type_JavaLangString = localObject3;
        if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() != null)
        {
          Object localObject4 = localObject1[k];
          String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
          if (localObject4 == str2)
            break label226;
        }
        EntityManagerFactory localEntityManagerFactory = QQApplication.getEntityManagerFactory(localObject1[k]);
        localObject1 = localObject1[k];
        localObject1 = localEntityManagerFactory.build((String)localObject1).getReadableDatabase();
        this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase = ((SQLiteDatabase)localObject1);
      }
    }
    for (localObject1 = localObject2; ; localObject1 = "")
    {
      label159: return localObject1;
      localObject2 = localObject1[j].equals("troop");
      if (localObject2 != 0)
      {
        localObject2 = new StringBuilder().append("mr_troop_");
        String str3 = localObject1[i];
        localObject2 = str3;
      }
      localObject2 = localObject1[j];
      break label75:
      label226: localObject1 = QQApplication.getSQLiteOpenHelper(localObject1[k]).getReadableDatabase();
      this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase = ((SQLiteDatabase)localObject1);
      break label159:
    }
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    int i = this.jdField_a_of_type_AndroidContentUriMatcher.match(paramUri);
    String str1 = paramUri.getPath();
    str1 = a(str1);
    switch (i)
    {
    default:
    case 1000:
    case 1001:
    }
    while (true)
    {
      return null;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str2 = super.getClass().getName();
      String str3 = str2 + " MATCH_MESSAGE_RECORD";
      QLog.d("delete", str3);
      this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase.delete(str1, paramString, paramArrayOfString);
      continue;
      try
      {
        StringBuilder localStringBuilder2 = new StringBuilder();
        String str4 = super.getClass().getName();
        String str5 = str4 + " MATCH_RECENT_LIST";
        QLog.d("delete", str5);
        this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase.delete(str1, paramString, paramArrayOfString);
      }
      catch (Exception localException)
      {
      }
    }
  }

  public String getType(Uri paramUri)
  {
    return null;
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    return null;
  }

  public boolean onCreate()
  {
    QQApplication localQQApplication = (QQApplication)getContext().getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.message", "#/friend/*", 1000);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.message", "#/troop/*", 1000);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.message", "#/RecentUser", 1001);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.message", "#/RecentMsg", 1002);
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    int i = 0;
    int j = this.jdField_a_of_type_AndroidContentUriMatcher.match(paramUri);
    switch (j)
    {
    default:
    case 1000:
    case 1001:
    }
    while (true)
    {
      label36: label40: String str2;
      Object localObject3;
      Object localObject4;
      Object localObject2;
      label477: String[] arrayOfString6;
      String[] arrayOfString7;
      String str16;
      for (Object localObject1 = i; ; localObject2 = ((SQLiteDatabase)localObject2).query(null, str2, arrayOfString6, (String)localObject4, arrayOfString7, null, null, str16, (String)localObject3))
      {
        while (true)
        {
          return localObject1;
          localObject1 = null;
          String str1 = paramUri.getPath();
          str2 = a(str1);
          if (paramString1 != null)
          {
            String str3 = paramString1;
            String str4 = "@limit";
            if (str3.contains(str4))
            {
              String str5 = paramString1;
              String str6 = "@limit";
              int k = str5.indexOf(str6);
              String str7 = paramString1;
              int l = 0;
              int i1 = k;
              localObject1 = str7.substring(l, i1).trim();
              String str8 = paramString1;
              String str9 = "@limit";
              int i2 = str8.indexOf(str9);
              int i3 = "@limit".length();
              int i4 = i2 + i3;
              String str10 = paramString1;
              int i5 = i4;
              localObject3 = str10.substring(i5);
            }
          }
          for (localObject4 = localObject1; ; localObject4 = paramString1)
          {
            StringBuilder localStringBuilder = new StringBuilder();
            String str11 = super.getClass().getName();
            String str12 = str11 + " MATCH_MESSAGE_RECORD";
            QLog.d("query", str12);
            localObject1 = str2.indexOf("mr_troop_");
            if (localObject1 == -1)
              break label477;
            if (paramArrayOfString1 == null)
              break;
            localObject1 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase;
            String[] arrayOfString1 = paramArrayOfString1;
            String[] arrayOfString2 = paramArrayOfString2;
            String str13 = paramString2;
            localObject1 = ((SQLiteDatabase)localObject1).query(null, str2, arrayOfString1, (String)localObject4, arrayOfString2, null, null, str13, (String)localObject3);
            break label40:
            localObject3 = localObject1;
          }
          localObject1 = new StringBuilder("select * from ");
          ((StringBuilder)localObject1).append(str2);
          ((StringBuilder)localObject1).append(" t left join TroopMemberInfo m on t.senderuin=m.memberuin and t.frienduin=m.troopuin");
          if ((localObject4 != null) && (((String)localObject4).length() > 0))
          {
            ((StringBuilder)localObject1).append(" where ");
            ((StringBuilder)localObject1).append((String)localObject4);
          }
          if ((paramString2 != null) && (paramString2.length() > 0))
          {
            ((StringBuilder)localObject1).append(" order by ");
            Object localObject5 = localObject1;
            String str14 = paramString2;
            localObject5.append(str14);
          }
          ((StringBuilder)localObject1).append(" limit ");
          ((StringBuilder)localObject1).append((String)localObject3);
          try
          {
            SQLiteDatabase localSQLiteDatabase1 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase;
            localObject1 = ((StringBuilder)localObject1).toString();
            SQLiteDatabase localSQLiteDatabase2 = localSQLiteDatabase1;
            Object localObject6 = localObject1;
            String[] arrayOfString3 = paramArrayOfString2;
            localObject1 = localSQLiteDatabase2.rawQuery(localObject6, arrayOfString3);
          }
          catch (SQLException localObject2)
          {
            localObject2 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase;
            String[] arrayOfString4 = paramArrayOfString1;
            String[] arrayOfString5 = paramArrayOfString2;
            String str15 = paramString2;
            localObject2 = ((SQLiteDatabase)localObject2).query(null, str2, arrayOfString4, (String)localObject4, arrayOfString5, null, null, str15, (String)localObject3);
          }
        }
        localObject2 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase;
        arrayOfString6 = paramArrayOfString1;
        arrayOfString7 = paramArrayOfString2;
        str16 = paramString2;
      }
      try
      {
        localObject2 = paramUri.getPath();
        a((String)localObject2);
        Object localObject7 = new StringBuilder();
        str2 = super.getClass().getName();
        localObject7 = str2 + " MATCH_RECENT_LIST";
        QLog.d("query", (String)localObject7);
        localObject2 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase;
        boolean bool = true;
        str2 = "RecentUser";
        String str17 = null;
        String str18 = null;
        if (paramString2 == null)
        {
          str19 = " tm DESC, seq DESC";
          String[] arrayOfString8 = paramArrayOfString1;
          String str20 = paramString1;
          String[] arrayOfString9 = paramArrayOfString2;
          localObject2 = ((SQLiteDatabase)localObject2).query(bool, str2, arrayOfString8, str20, arrayOfString9, str17, str18, str19, null);
        }
        String str19 = paramString2;
      }
      catch (Exception localException)
      {
        break label36:
      }
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    Object localObject1 = null;
    ContentObserver localContentObserver1 = null;
    int i = this.jdField_a_of_type_AndroidContentUriMatcher.match(paramUri);
    switch (i)
    {
    case 1001:
    default:
      localObject2 = localObject1;
    case 1000:
      while (true)
      {
        label48: return localObject2;
        localObject2 = paramUri.getPath();
        localObject2 = a((String)localObject2);
        localObject2 = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase.update((String)localObject2, paramContentValues, paramString, paramArrayOfString);
        if (localObject2 <= 0)
          continue;
        ContentResolver localContentResolver = getContext().getContentResolver();
        Uri localUri1 = Message.MSG_RECORD_URI_PREFIX;
        localContentResolver.notifyChange(localUri1, localContentObserver1);
      }
    case 1002:
    }
    Object localObject2 = QQApplication.getEntityManagerFactory(this.jdField_a_of_type_JavaLangString).createEntityManager();
    Object localObject3 = localContentObserver1;
    Object localObject4 = localContentObserver1;
    ContentObserver localContentObserver2 = localContentObserver1;
    localObject2 = ((EntityManager)localObject2).a(RecentUser.class, localContentObserver1, localObject3, (String)localObject4, localContentObserver2);
    Iterator localIterator = ((List)localObject2).iterator();
    localObject3 = localContentObserver1;
    localObject4 = localObject1;
    label169: localObject2 = localIterator.hasNext();
    long l1;
    if (localObject2 != 0)
    {
      localObject2 = (RecentUser)localIterator.next();
      if (((RecentUser)localObject2).type == 0)
      {
        localObject3 = new StringBuilder().append("mr_friend_");
        l1 = ((RecentUser)localObject2).uin;
      }
    }
    for (localObject2 = l1; ; localObject2 = localObject3)
    {
      int j;
      while (true)
      {
        j = this.jdField_a_of_type_AndroidDatabaseSqliteSQLiteDatabase.update((String)localObject2, paramContentValues, paramString, paramArrayOfString) + localObject4;
        localObject3 = localObject2;
        break label169:
        if (((RecentUser)localObject2).type != 1)
          break label336;
        localObject3 = new StringBuilder().append("mr_troop_");
        long l2 = ((RecentUser)localObject2).uin;
        localObject2 = l2;
      }
      localObject2 = getContext().getContentResolver();
      Uri localUri2 = Message.MSG_RECORD_URI_PREFIX;
      ((ContentResolver)localObject2).notifyChange(localUri2, localContentObserver1);
      localObject2 = j;
      label336: break label48:
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.MessageProvider
 * JD-Core Version:    0.5.4
 */