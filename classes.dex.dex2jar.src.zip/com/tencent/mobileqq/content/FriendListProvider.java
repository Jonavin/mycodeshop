package com.tencent.mobileqq.content;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.FriendMore;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.Groups;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.data.VideoAbility;
import com.tencent.mobileqq.service.friendlist.storage.StorageTroopSelfInfo;
import com.tencent.qphone.base.util.QLog;
import java.util.List;

public class FriendListProvider extends ContentProvider
  implements FriendList
{
  public static final int MATCH_FRIEND_LIST = 1001;
  public static final int MATCH_GROUP = 1000;
  public static final int MATCH_TROOP_INFO = 1003;
  public static final int MATCH_TROOP_LIST = 1002;
  public static final int MATCH_TROOP_NAME = 1004;
  public static final String TAG = "FriendListProvider";
  private final UriMatcher jdField_a_of_type_AndroidContentUriMatcher;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;

  public FriendListProvider()
  {
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.jdField_a_of_type_AndroidContentUriMatcher = localUriMatcher;
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    return null;
  }

  public String getType(Uri paramUri)
  {
    return null;
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    return null;
  }

  public boolean onCreate()
  {
    QQApplication localQQApplication = (QQApplication)getContext().getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.friendlist", "group", 1000);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.friendlist", "friendlist", 1001);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.friendlist", "trooplist", 1002);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.friendlist", "troopinfo", 1003);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.friendlist", "troopname/#", 1004);
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    int i = 2;
    int j = 1;
    boolean bool = null;
    int k = 0;
    int l = this.jdField_a_of_type_AndroidContentUriMatcher.match(paramUri);
    String str1 = "[query] match=" + l;
    QLog.i("FriendListProvider", str1);
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    if (localObject2 == null)
    {
      localObject2 = k;
      label69: return localObject2;
    }
    localObject2 = ((SQLiteOpenHelper)localObject2).getReadableDatabase();
    switch (l)
    {
    default:
    case 1000:
    case 1001:
    case 1002:
    case 1003:
    case 1004:
    }
    label120: Object localObject3;
    List localList;
    String str19;
    String[] arrayOfString5;
    String[] arrayOfString6;
    Object localObject13;
    for (localObject2 = k; ; localObject3 = ((SQLiteDatabase)localObject3).query(bool, str19, arrayOfString5, "troopuin=?", arrayOfString6, k, localList, j, localObject13))
    {
      while (true)
      {
        if (localObject2 != null);
        ContentResolver localContentResolver = getContext().getContentResolver();
        ((Cursor)localObject2).setNotificationUri(localContentResolver, paramUri);
        break label69:
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str2 = super.getClass().getName();
        String str3 = str2 + " MATCH_GROUP";
        QLog.d("query", str3);
        String str4 = new Groups().getTableName();
        String[] arrayOfString1 = new String[4];
        arrayOfString1[bool] = "group_name";
        arrayOfString1[j] = "group_online_friend_count";
        arrayOfString1[i] = "group_friend_count";
        arrayOfString1[3] = "group_id";
        String str5 = paramString1;
        String[] arrayOfString2 = paramArrayOfString2;
        Object localObject4 = k;
        String str6 = paramString2;
        Object localObject5 = k;
        localObject2 = ((SQLiteDatabase)localObject2).query(bool, str4, arrayOfString1, str5, i, k, localObject4, j, localObject5);
        continue;
        localObject2 = "query";
        Object localObject1 = new StringBuilder();
        String str7 = super.getClass().getName();
        localObject1 = str7 + " MATCH_FRIEND_LIST";
        QLog.d((String)localObject2, (String)localObject1);
        if ((paramString1 != null) && (paramArrayOfString2 != null))
        {
          int i1 = paramArrayOfString2.length;
          localObject1 = paramString1;
          while (bool < i1)
          {
            String str8 = paramArrayOfString2[bool];
            localObject1 = ((String)localObject1).replaceFirst("\\?", str8);
            ++bool;
          }
        }
        for (localObject3 = " where " + (String)localObject1; ; localObject3 = "")
        {
          StringBuilder localStringBuilder2 = new StringBuilder().append("select * from ");
          String str9 = new Friends().getTableName();
          StringBuilder localStringBuilder3 = localStringBuilder2.append(str9).append(" f left join ");
          String str10 = new FriendMore().getTableName();
          StringBuilder localStringBuilder4 = localStringBuilder3.append(str10).append(" m on f.uin=m.uin left join ");
          String str11 = new VideoAbility().getTableName();
          localObject3 = str11 + " v on m.uin=v.uin " + (String)localObject3 + " order by " + paramString2;
          localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getReadableDatabase().rawQuery((String)localObject3, k);
          break label120:
        }
        StringBuilder localStringBuilder5 = new StringBuilder();
        String str12 = super.getClass().getName();
        String str13 = str12 + " MATCH_TROOP_LIST";
        QLog.d("query", str13);
        String str14 = StorageTroopSelfInfo.TABLE_TROOPSELF_INFO;
        Object localObject6 = k;
        String str15 = paramString1;
        String[] arrayOfString3 = paramArrayOfString2;
        Object localObject7 = k;
        String str16 = paramString2;
        Object localObject8 = k;
        localObject3 = ((SQLiteDatabase)localObject3).query(bool, str14, localObject6, str15, arrayOfString3, k, localObject7, str16, localObject8);
        continue;
        Object localObject9 = k;
        String str17 = paramString1;
        String[] arrayOfString4 = paramArrayOfString2;
        Object localObject10 = k;
        String str18 = paramString2;
        Object localObject11 = k;
        localObject3 = ((SQLiteDatabase)localObject3).query(bool, "msf_troopinfo", localObject9, str17, arrayOfString4, k, localObject10, str18, localObject11);
      }
      localList = paramUri.getPathSegments();
      if (localList.size() >= i);
      str19 = new TroopInfo().getTableName();
      arrayOfString5 = new String[j];
      arrayOfString5[bool] = "troopname";
      arrayOfString6 = new String[j];
      String str20 = (String)localList.get(j);
      arrayOfString6[bool] = localList;
      Object localObject12 = k;
      String str21 = paramString2;
      localObject13 = k;
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    return null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.FriendListProvider
 * JD-Core Version:    0.5.4
 */