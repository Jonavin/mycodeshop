package com.tencent.mobileqq.content;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.qphone.base.util.QLog;

public class ProfileProvider extends ContentProvider
  implements AppConstants, Profile
{
  public static final int MATCH_FULL = 10001;
  public static final int MATCH_INFO = 1000;
  public static final String TAG = "ProfileProvider";
  private final UriMatcher jdField_a_of_type_AndroidContentUriMatcher;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;

  public ProfileProvider()
  {
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.jdField_a_of_type_AndroidContentUriMatcher = localUriMatcher;
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.profile", "info", 1000);
    this.jdField_a_of_type_AndroidContentUriMatcher.addURI("qq.profile", "full", 10001);
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    return null;
  }

  public String getType(Uri paramUri)
  {
    return null;
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    return null;
  }

  public boolean onCreate()
  {
    QQApplication localQQApplication = (QQApplication)getContext().getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    int i = 0;
    int j = this.jdField_a_of_type_AndroidContentUriMatcher.match(paramUri);
    String str1 = "[query] match=" + j;
    QLog.i("ProfileProvider", str1);
    Object localObject1;
    switch (j)
    {
    default:
      localObject1 = i;
    case 1000:
    case 10001:
    }
    while (true)
    {
      return localObject1;
      StringBuilder localStringBuilder = new StringBuilder();
      String str2 = super.getClass().getName();
      String str3 = str2 + " MATCH_FULL";
      QLog.d("query", str3);
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getReadableDatabase();
      String str4 = new Friends().getTableName();
      Object localObject2 = i;
      Object localObject3 = i;
      Object localObject4 = i;
      Object localObject5 = i;
      Object localObject6 = i;
      Object localObject7 = i;
      localObject1 = ((SQLiteDatabase)localObject1).query(null, str4, i, localObject2, localObject3, localObject4, localObject5, localObject6, localObject7);
      if (localObject1 == null)
        continue;
      ContentResolver localContentResolver = getContext().getContentResolver();
      ((Cursor)localObject1).setNotificationUri(localContentResolver, paramUri);
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    return null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.ProfileProvider
 * JD-Core Version:    0.5.4
 */