package com.tencent.mobileqq.content;

import android.net.Uri;

public abstract interface FriendList
{
  public static final String AUTHORITY = "qq.friendlist";
  public static final Uri FRIEND_LIST_CONTENT_URI;
  public static final Uri GROUP_LIST_CONTENT_URI = Uri.parse("content://qq.friendlist/group");
  public static final String PATH_FRIEND_LIST = "friendlist";
  public static final String PATH_GROUP = "group";
  public static final String PATH_TROOP_INFO = "troopinfo";
  public static final String PATH_TROOP_LIST = "trooplist";
  public static final String PATH_TROOP_NAME = "troopname/";
  public static final Uri TROOP_INFO_URI;
  public static final Uri TROOP_LIST_URI;
  public static final Uri TROOP_NAME_URI;

  static
  {
    FRIEND_LIST_CONTENT_URI = Uri.parse("content://qq.friendlist/friendlist");
    TROOP_LIST_URI = Uri.parse("content://qq.friendlist/trooplist");
    TROOP_INFO_URI = Uri.parse("content://qq.friendlist/troopinfo");
    TROOP_NAME_URI = Uri.parse("content://qq.friendlist/troopname/");
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.FriendList
 * JD-Core Version:    0.5.4
 */