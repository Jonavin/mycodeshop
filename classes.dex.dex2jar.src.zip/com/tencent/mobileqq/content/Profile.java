package com.tencent.mobileqq.content;

import android.net.Uri;

public abstract interface Profile
{
  public static final String AUTHORITY = "qq.profile";
  public static final Uri FULL_INFO_CONTENT_URI;
  public static final Uri INFO_CONTENT_URI = Uri.parse("content://qq.profile/info");
  public static final String PATH_FULL = "full";
  public static final String PATH_INFO = "info";
  public static final String PATH_REFRESH = "refresh";

  static
  {
    FULL_INFO_CONTENT_URI = Uri.parse("content://qq.profile/full");
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.Profile
 * JD-Core Version:    0.5.4
 */