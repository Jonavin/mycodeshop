package com.tencent.mobileqq.content;

import android.net.Uri;

public abstract interface Message
{
  public static final String AUTHORITY = "qq.message";
  public static final Uri MSG_RECORD_URI_PREFIX = Uri.parse("content://qq.message/");
  public static final String PATH_RECENT_LIST = "RecentUser";
  public static final Uri RECENT_LIST_URI = Uri.parse("content://qq.message/");
  public static final String uriPrefix = "content://qq.message/";
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.content.Message
 * JD-Core Version:    0.5.4
 */