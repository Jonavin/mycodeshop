package com.tencent.mobileqq;

public final class R$attr
{
  public static final int skintype = 2130771968;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.attr
 * JD-Core Version:    0.5.4
 */