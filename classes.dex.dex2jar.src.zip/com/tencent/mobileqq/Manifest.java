package com.tencent.mobileqq;

public final class Manifest
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.Manifest
 * JD-Core Version:    0.5.4
 */