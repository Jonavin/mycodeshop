package com.tencent.mobileqq;

public final class R$anim
{
  public static final int alpha_fade_in = 2130968576;
  public static final int alpha_fade_out = 2130968577;
  public static final int chatlist_trans = 2130968578;
  public static final int msg_tip_scale = 2130968579;
  public static final int scale_and_fade_in = 2130968580;
  public static final int scale_and_fade_out = 2130968581;
  public static final int waitting = 2130968582;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.anim
 * JD-Core Version:    0.5.4
 */