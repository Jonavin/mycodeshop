package com.tencent.mobileqq;

public final class R$array
{
  public static final int add_friend = 2131165184;
  public static final int custemotion_selected_item = 2131165187;
  public static final int del_dialog_items = 2131165185;
  public static final int del_selected_item = 2131165186;
  public static final int pic_select_dialog_items = 2131165188;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.array
 * JD-Core Version:    0.5.4
 */