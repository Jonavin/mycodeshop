package com.tencent.mobileqq;

public final class R$layout
{
  public static final int account_list_item = 2130903040;
  public static final int act_set_trafficstat = 2130903041;
  public static final int add_friend = 2130903042;
  public static final int add_friend_list_item = 2130903043;
  public static final int add_friend_verification = 2130903044;
  public static final int add_request = 2130903045;
  public static final int alert_dialog_text_entry = 2130903046;
  public static final int chat = 2130903047;
  public static final int chat_emotion = 2130903048;
  public static final int chat_emotion_uint = 2130903049;
  public static final int chat_photo_preview = 2130903050;
  public static final int chat_recorder = 2130903051;
  public static final int chathistory = 2130903052;
  public static final int chathistoryitem = 2130903053;
  public static final int chatlistheader = 2130903054;
  public static final int chatvideo = 2130903055;
  public static final int chatwindow = 2130903056;
  public static final int chatwindowitem = 2130903057;
  public static final int chatwindowtip = 2130903058;
  public static final int contact_list = 2130903059;
  public static final int contact_list_header = 2130903060;
  public static final int contact_list_item = 2130903061;
  public static final int custom_title = 2130903062;
  public static final int dialog_body_account_clear = 2130903063;
  public static final int dialog_body_delmsghistory = 2130903064;
  public static final int doodle = 2130903065;
  public static final int emotion = 2130903066;
  public static final int emotion_tab = 2130903067;
  public static final int empty_contact_group_view = 2130903068;
  public static final int empty_conversation_group_view = 2130903069;
  public static final int group_view = 2130903070;
  public static final int header = 2130903071;
  public static final int header_chat = 2130903072;
  public static final int info_bottom = 2130903073;
  public static final int info_friend = 2130903074;
  public static final int info_self = 2130903075;
  public static final int info_troop = 2130903076;
  public static final int login = 2130903077;
  public static final int nf_running_in_bg = 2130903078;
  public static final int recent_list_item = 2130903079;
  public static final int screenshot = 2130903080;
  public static final int search_result = 2130903081;
  public static final int searchlocal = 2130903082;
  public static final int service_entry_item = 2130903083;
  public static final int splash = 2130903084;
  public static final int tabs_bg = 2130903085;
  public static final int test = 2130903086;
  public static final int textview = 2130903087;
  public static final int themelist = 2130903088;
  public static final int themelist_item = 2130903089;
  public static final int trafic_table = 2130903090;
  public static final int troop_member_list_item = 2130903091;
  public static final int troop_memberlist = 2130903092;
  public static final int userguide = 2130903093;
  public static final int verification = 2130903094;
  public static final int verify_dlg = 2130903095;
  public static final int video_request_notify = 2130903096;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.layout
 * JD-Core Version:    0.5.4
 */