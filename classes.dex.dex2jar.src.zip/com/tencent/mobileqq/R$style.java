package com.tencent.mobileqq;

public final class R$style
{
  public static final int CustomWindowTitleBackground = 2131361792;
  public static final int Default = 2131361809;
  public static final int Default_NoTitleBar = 2131361808;
  public static final int DialogStyle = 2131361803;
  public static final int TextViewHaptic = 2131361802;
  public static final int customAutoCompleteTextView = 2131361797;
  public static final int customCheckBox = 2131361793;
  public static final int customEditText = 2131361796;
  public static final int customExpandableListView = 2131361798;
  public static final int customListView = 2131361795;
  public static final int customProgressBar = 2131361799;
  public static final int customProgressBar1 = 2131361800;
  public static final int customRadioButton = 2131361794;
  public static final int photoPreviewProgressBar = 2131361801;
  public static final int videoDlgBg = 2131361807;
  public static final int videoDlgTipText = 2131361806;
  public static final int videoNoButton = 2131361804;
  public static final int videoOkButton = 2131361805;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.style
 * JD-Core Version:    0.5.4
 */