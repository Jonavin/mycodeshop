package com.tencent.mobileqq;

public final class R$xml
{
  public static final int preferences = 2131034112;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.xml
 * JD-Core Version:    0.5.4
 */