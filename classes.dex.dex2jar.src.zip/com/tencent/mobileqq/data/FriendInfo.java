package com.tencent.mobileqq.data;

import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.ParcelableObject.CreatorImpl;
import com.tencent.mobileqq.persistence.unique;

public class FriendInfo extends Entity
{
  public String city;
  public String comment;
  public String country;
  public byte day;

  @unique
  public String frienduin;
  public byte gender;
  public byte month;
  public String nickname;
  public String province;
  public short year;

  static
  {
    CREATOR = new ParcelableObject.CreatorImpl(FriendInfo.class);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.FriendInfo
 * JD-Core Version:    0.5.4
 */