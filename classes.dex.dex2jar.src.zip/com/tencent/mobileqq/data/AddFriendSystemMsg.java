package com.tencent.mobileqq.data;

public class AddFriendSystemMsg
{
  public int cVession;
  public String message;
  public String sMsg;

  // ERROR //
  public static AddFriendSystemMsg decode(String paramString1, String paramString2, int paramInt)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: invokevirtual 23	java/lang/String:getBytes	()[B
    //   6: astore 4
    //   8: new 25	java/io/ByteArrayInputStream
    //   11: dup
    //   12: aload 4
    //   14: invokespecial 28	java/io/ByteArrayInputStream:<init>	([B)V
    //   17: astore 5
    //   19: new 30	java/io/DataInputStream
    //   22: dup
    //   23: aload 5
    //   25: invokespecial 33	java/io/DataInputStream:<init>	(Ljava/io/InputStream;)V
    //   28: astore 4
    //   30: iload_2
    //   31: tableswitch	default:+33 -> 64, 187:+35->66, 188:+134->165, 189:+175->206, 190:+216->247, 191:+320->351
    //   65: areturn
    //   66: new 2	com/tencent/mobileqq/data/AddFriendSystemMsg
    //   69: dup
    //   70: invokespecial 34	com/tencent/mobileqq/data/AddFriendSystemMsg:<init>	()V
    //   73: astore 5
    //   75: aload 4
    //   77: invokevirtual 38	java/io/DataInputStream:readUnsignedByte	()I
    //   80: astore_3
    //   81: aload 5
    //   83: iload_3
    //   84: putfield 40	com/tencent/mobileqq/data/AddFriendSystemMsg:cVession	I
    //   87: aload 4
    //   89: invokevirtual 38	java/io/DataInputStream:readUnsignedByte	()I
    //   92: newarray byte
    //   94: astore_3
    //   95: aload 4
    //   97: aload_3
    //   98: invokevirtual 44	java/io/DataInputStream:read	([B)I
    //   101: pop
    //   102: new 19	java/lang/String
    //   105: dup
    //   106: aload_3
    //   107: invokespecial 45	java/lang/String:<init>	([B)V
    //   110: astore 6
    //   112: aload 5
    //   114: aload 4
    //   116: putfield 47	com/tencent/mobileqq/data/AddFriendSystemMsg:sMsg	Ljava/lang/String;
    //   119: new 49	java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   126: aload_1
    //   127: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: ldc 56
    //   132: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: astore_3
    //   136: aload 5
    //   138: getfield 47	com/tencent/mobileqq/data/AddFriendSystemMsg:sMsg	Ljava/lang/String;
    //   141: astore 7
    //   143: aload_3
    //   144: aload 4
    //   146: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: astore_3
    //   153: aload 5
    //   155: aload_3
    //   156: putfield 62	com/tencent/mobileqq/data/AddFriendSystemMsg:message	Ljava/lang/String;
    //   159: aload 5
    //   161: astore_3
    //   162: goto -98 -> 64
    //   165: new 2	com/tencent/mobileqq/data/AddFriendSystemMsg
    //   168: dup
    //   169: invokespecial 34	com/tencent/mobileqq/data/AddFriendSystemMsg:<init>	()V
    //   172: astore 4
    //   174: new 49	java/lang/StringBuilder
    //   177: dup
    //   178: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   181: aload_1
    //   182: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: ldc 64
    //   187: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   193: astore_3
    //   194: aload 4
    //   196: aload_3
    //   197: putfield 62	com/tencent/mobileqq/data/AddFriendSystemMsg:message	Ljava/lang/String;
    //   200: aload 4
    //   202: astore_3
    //   203: goto -139 -> 64
    //   206: new 2	com/tencent/mobileqq/data/AddFriendSystemMsg
    //   209: dup
    //   210: invokespecial 34	com/tencent/mobileqq/data/AddFriendSystemMsg:<init>	()V
    //   213: astore 4
    //   215: new 49	java/lang/StringBuilder
    //   218: dup
    //   219: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   222: aload_1
    //   223: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: ldc 66
    //   228: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   231: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   234: astore_3
    //   235: aload 4
    //   237: aload_3
    //   238: putfield 62	com/tencent/mobileqq/data/AddFriendSystemMsg:message	Ljava/lang/String;
    //   241: aload 4
    //   243: astore_3
    //   244: goto -180 -> 64
    //   247: new 2	com/tencent/mobileqq/data/AddFriendSystemMsg
    //   250: dup
    //   251: invokespecial 34	com/tencent/mobileqq/data/AddFriendSystemMsg:<init>	()V
    //   254: astore 5
    //   256: aload 4
    //   258: invokevirtual 38	java/io/DataInputStream:readUnsignedByte	()I
    //   261: astore_3
    //   262: aload 5
    //   264: iload_3
    //   265: putfield 40	com/tencent/mobileqq/data/AddFriendSystemMsg:cVession	I
    //   268: aload 4
    //   270: invokevirtual 38	java/io/DataInputStream:readUnsignedByte	()I
    //   273: newarray byte
    //   275: astore_3
    //   276: aload 4
    //   278: aload_3
    //   279: invokevirtual 44	java/io/DataInputStream:read	([B)I
    //   282: pop
    //   283: new 19	java/lang/String
    //   286: dup
    //   287: aload_3
    //   288: invokespecial 45	java/lang/String:<init>	([B)V
    //   291: astore 8
    //   293: aload 5
    //   295: aload 4
    //   297: putfield 47	com/tencent/mobileqq/data/AddFriendSystemMsg:sMsg	Ljava/lang/String;
    //   300: new 49	java/lang/StringBuilder
    //   303: dup
    //   304: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   307: aload_1
    //   308: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   311: ldc 68
    //   313: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: ldc 70
    //   318: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: astore_3
    //   322: aload 5
    //   324: getfield 47	com/tencent/mobileqq/data/AddFriendSystemMsg:sMsg	Ljava/lang/String;
    //   327: astore 9
    //   329: aload_3
    //   330: aload 4
    //   332: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   335: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   338: astore_3
    //   339: aload 5
    //   341: aload_3
    //   342: putfield 62	com/tencent/mobileqq/data/AddFriendSystemMsg:message	Ljava/lang/String;
    //   345: aload 5
    //   347: astore_3
    //   348: goto -284 -> 64
    //   351: new 2	com/tencent/mobileqq/data/AddFriendSystemMsg
    //   354: dup
    //   355: invokespecial 34	com/tencent/mobileqq/data/AddFriendSystemMsg:<init>	()V
    //   358: astore 4
    //   360: new 49	java/lang/StringBuilder
    //   363: dup
    //   364: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   367: aload_1
    //   368: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   371: ldc 72
    //   373: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   379: astore_3
    //   380: aload 4
    //   382: aload_3
    //   383: putfield 62	com/tencent/mobileqq/data/AddFriendSystemMsg:message	Ljava/lang/String;
    //   386: aload 4
    //   388: astore_3
    //   389: goto -325 -> 64
    //   392: astore 10
    //   394: goto -330 -> 64
    //   397: astore_3
    //   398: aload 5
    //   400: astore_3
    //   401: goto -337 -> 64
    //   404: astore_3
    //   405: aload 4
    //   407: astore_3
    //   408: goto -344 -> 64
    //   411: astore_3
    //   412: aload 4
    //   414: astore_3
    //   415: goto -351 -> 64
    //   418: astore_3
    //   419: aload 5
    //   421: astore_3
    //   422: goto -358 -> 64
    //   425: astore_3
    //   426: aload 4
    //   428: astore_3
    //   429: goto -365 -> 64
    //
    // Exception table:
    //   from	to	target	type
    //   66	75	392	java/io/IOException
    //   165	174	392	java/io/IOException
    //   206	215	392	java/io/IOException
    //   247	256	392	java/io/IOException
    //   351	360	392	java/io/IOException
    //   75	159	397	java/io/IOException
    //   174	200	404	java/io/IOException
    //   215	241	411	java/io/IOException
    //   256	345	418	java/io/IOException
    //   360	386	425	java/io/IOException
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.AddFriendSystemMsg
 * JD-Core Version:    0.5.4
 */