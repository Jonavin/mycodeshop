package com.tencent.mobileqq.data;

import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.unique;

public class Groups extends Entity
{
  public long datetime;
  public int group_friend_count;

  @unique
  public int group_id;
  public String group_name;
  public int group_online_friend_count;
  public byte seqid;
  public int sqqOnLine_count;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.Groups
 * JD-Core Version:    0.5.4
 */