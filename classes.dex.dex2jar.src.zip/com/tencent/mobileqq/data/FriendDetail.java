package com.tencent.mobileqq.data;

public class FriendDetail
{
  private short faceid;
  private byte groupid = -1;
  private String name = "";
  private String pyAll = "";
  private String pyFirst = "";
  private String selfuin = "";
  private byte status;
  private String uin = "";

  public short getFaceid()
  {
    return this.faceid;
  }

  public String getName()
  {
    return this.name;
  }

  public String getPyAll()
  {
    return this.pyAll;
  }

  public String getPyFirst()
  {
    return this.pyFirst;
  }

  public byte getStatus()
  {
    return this.status;
  }

  public String getUin()
  {
    return this.uin;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPyAll(String paramString)
  {
    this.pyAll = paramString;
  }

  public void setPyFirst(String paramString)
  {
    this.pyFirst = paramString;
  }

  public void setStatus(byte paramByte)
  {
    this.status = paramByte;
  }

  public void setUin(String paramString)
  {
    this.uin = paramString;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.FriendDetail
 * JD-Core Version:    0.5.4
 */