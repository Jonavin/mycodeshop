package com.tencent.mobileqq.data;

import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.ParcelableObject.CreatorImpl;
import com.tencent.mobileqq.persistence.unique;

public class Friends extends Entity
{
  public long datetime;
  public byte detalStatusFlag;
  public short faceid;
  public byte groupid = -1;
  public boolean isMqqOnLine;
  public byte memberLevel;
  public String name;
  public byte sqqOnLineState;
  public byte sqqtype;
  public byte status = 20;

  @unique
  public String uin;

  static
  {
    CREATOR = new ParcelableObject.CreatorImpl(Friends.class);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.Friends
 * JD-Core Version:    0.5.4
 */