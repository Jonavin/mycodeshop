package com.tencent.mobileqq.data;

import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.unique;

public class FriendMore extends Entity
{
  public String signature;

  @unique
  public String uin;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.FriendMore
 * JD-Core Version:    0.5.4
 */