package com.tencent.mobileqq.data;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.qphone.base.util.BaseApplication;
import ic;

public class QQEntityManagerFactory extends EntityManagerFactory
{
  private SQLiteOpenHelper dbHelper;
  private int dbVersion = 1;
  public final String name;

  public QQEntityManagerFactory(String paramString)
  {
    super(paramString);
    this.name = paramString;
  }

  public SQLiteOpenHelper build(String paramString)
  {
    if (this.dbHelper == null);
    try
    {
      Context localContext = BaseApplication.getContext();
      PackageManager localPackageManager = localContext.getPackageManager();
      String str1 = localContext.getPackageName();
      int i = ((Integer)localPackageManager.getApplicationInfo(str1, 128).metaData.get("DBVersion")).intValue();
      this.dbVersion = i;
      String str2 = paramString + ".db";
      int j = this.dbVersion;
      ic localic = new ic(this, str2, j);
      this.dbHelper = localic;
      return this.dbHelper;
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.data.QQEntityManagerFactory
 * JD-Core Version:    0.5.4
 */