package com.tencent.mobileqq.utils;

public abstract interface Recorder$OnStateChangedListener
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.utils.Recorder.OnStateChangedListener
 * JD-Core Version:    0.5.4
 */