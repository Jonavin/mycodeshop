package com.tencent.mobileqq.skin;

public abstract interface SkinListener
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.skin.SkinListener
 * JD-Core Version:    0.5.4
 */