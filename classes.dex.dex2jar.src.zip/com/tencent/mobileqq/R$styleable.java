package com.tencent.mobileqq;

public final class R$styleable
{
  public static final int[] Gallery1;
  public static final int Gallery1_android_galleryItemBackground;
  public static final int[] TencentSkin;
  public static final int TencentSkin_skintype;

  static
  {
    int[] arrayOfInt1 = new int[1];
    arrayOfInt1[0] = 16842828;
    Gallery1 = arrayOfInt1;
    int[] arrayOfInt2 = new int[1];
    arrayOfInt2[0] = 2130771968;
    TencentSkin = arrayOfInt2;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.styleable
 * JD-Core Version:    0.5.4
 */