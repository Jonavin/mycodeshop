package com.tencent.mobileqq.persistence;

import java.lang.reflect.Field;
import java.util.Set;

public abstract class Entity extends ParcelableObject
{
  public static final int DETACHED = 1002;
  public static final int MANAGED = 1001;
  public static final int NEW = 1000;
  public static final int REMOVED = 1003;
  long _id = 65535L;
  int _status = 1000;
  Set enabledFields;

  public long getId()
  {
    return this._id;
  }

  public String getTableName()
  {
    return super.getClass().getSimpleName();
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = this._status;
    label44: Object localObject1;
    Object localObject2;
    label92: Object localObject3;
    String str;
    switch (i)
    {
    default:
      localObject1 = new StringBuilder().append("_id=");
      long l = this._id;
      localObject1 = l;
      localStringBuilder.append((String)localObject1);
      localObject1 = super.getClass().getDeclaredFields();
      int j = localObject1.length;
      localObject2 = null;
      if (localObject2 >= j)
        break label224;
      localObject3 = localObject1[localObject2];
      boolean bool1 = localObject3.isAccessible();
      if (!bool1)
      {
        boolean bool2 = true;
        localObject3.setAccessible(bool2);
      }
      str = localObject3.getName();
    case 1000:
    case 1001:
    case 1002:
    case 1003:
    }
    try
    {
      localObject3 = localObject3.get(this);
      localStringBuilder.append(',');
      localStringBuilder.append(str);
      localStringBuilder.append('=');
      localStringBuilder.append(localObject3);
      ++localObject2;
      break label92:
      localObject1 = "NEW,";
      localStringBuilder.append((String)localObject1);
      break label44:
      localObject1 = "MANAGED,";
      localStringBuilder.append((String)localObject1);
      break label44:
      localObject1 = "DETACHED,";
      localStringBuilder.append((String)localObject1);
      break label44:
      localObject1 = "REMOVED,";
      localStringBuilder.append((String)localObject1);
      break label44:
      label224: return localStringBuilder.toString();
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.persistence.Entity
 * JD-Core Version:    0.5.4
 */