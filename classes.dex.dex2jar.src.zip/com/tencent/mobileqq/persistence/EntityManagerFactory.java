package com.tencent.mobileqq.persistence;

import android.database.sqlite.SQLiteOpenHelper;

public abstract class EntityManagerFactory
{
  private static final String CLOSE_EXCEPTION_MSG = "The EntityManagerFactory has been already closed";
  private boolean closed;
  private final SQLiteOpenHelper dbHelper;

  public EntityManagerFactory(String paramString)
  {
    SQLiteOpenHelper localSQLiteOpenHelper = build(paramString);
    this.dbHelper = localSQLiteOpenHelper;
  }

  public abstract SQLiteOpenHelper build(String paramString);

  public void close()
  {
    if (this.closed)
      throw new IllegalStateException("The EntityManagerFactory has been already closed");
    this.closed = true;
    this.dbHelper.close();
  }

  public EntityManager createEntityManager()
  {
    if (this.closed)
      throw new IllegalStateException("The EntityManagerFactory has been already closed");
    SQLiteOpenHelper localSQLiteOpenHelper = this.dbHelper;
    EntityManager localEntityManager = new EntityManager(localSQLiteOpenHelper);
    this.closed = null;
    return localEntityManager;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.persistence.EntityManagerFactory
 * JD-Core Version:    0.5.4
 */