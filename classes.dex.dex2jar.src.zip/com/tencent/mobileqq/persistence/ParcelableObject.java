package com.tencent.mobileqq.persistence;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import ii;
import java.lang.reflect.Field;
import java.util.List;

public abstract class ParcelableObject
  implements Parcelable
{
  public static Parcelable.Creator CREATOR;

  public int describeContents()
  {
    return null;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ParcelableObject.CreatorImpl localCreatorImpl = (ParcelableObject.CreatorImpl)CREATOR;
    ParcelableObject.CreatorImpl.access$000(localCreatorImpl).clear();
    super.getClass();
    Field[] arrayOfField = super.getClass().getDeclaredFields();
    int i = arrayOfField.length;
    Object localObject1 = null;
    Object localObject4 = localObject1;
    if (localObject4 >= i)
      return;
    localObject1 = arrayOfField[localObject4];
    boolean bool1 = ((Field)localObject1).isAccessible();
    if (!bool1)
    {
      boolean bool2 = true;
      ((Field)localObject1).setAccessible(bool2);
    }
    ((Field)localObject1).getName();
    Class localClass1 = ((Field)localObject1).getType();
    ii localii = new ii(this);
    localii.jdField_a_of_type_JavaLangReflectField = ((Field)localObject1);
    localii.jdField_a_of_type_JavaLangClass = localClass1;
    try
    {
      Class localClass2 = Integer.TYPE;
      label163: Object localObject2;
      if (localClass1 == localClass2)
      {
        localObject1 = ((Integer)((Field)localObject1).get(this)).intValue();
        paramParcel.writeInt(localObject1);
        localObject1 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject1).add(localii);
        localObject2 = localObject4 + 1;
        localObject4 = localObject2;
      }
      Class localClass3 = Long.TYPE;
      if (localClass1 != localClass3)
        break label232;
      long l = ((Long)localObject2.get(this)).longValue();
      Object localObject5;
      paramParcel.writeLong(localObject5);
      List localList = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
      label232: localList.add(localii);
    }
    catch (Exception localObject3)
    {
      break label163:
      if (localClass1 == String.class)
      {
        localObject3 = (String)localException.get(this);
        paramParcel.writeString((String)localObject3);
        localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject3).add(localii);
      }
      int j;
      if (localClass1 == [B.class)
      {
        localObject3 = (byte[])((Field)localObject3).get(this);
        j = localObject3.length;
        localii.jdField_a_of_type_Int = j;
        paramParcel.writeByteArray(localObject3);
        localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject3).add(localii);
      }
      Class localClass4 = Short.TYPE;
      if (j == localClass4)
      {
        localObject3 = ((Short)((Field)localObject3).get(this)).shortValue();
        paramParcel.writeInt(localObject3);
        localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject3).add(localii);
      }
      Class localClass5 = Byte.TYPE;
      if (j == localClass5)
      {
        localObject3 = ((Byte)((Field)localObject3).get(this)).byteValue();
        paramParcel.writeByte(localObject3);
        localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject3).add(localii);
      }
      Class localClass6 = Float.TYPE;
      if (j == localClass6)
      {
        localObject3 = ((Float)((Field)localObject3).get(this)).floatValue();
        paramParcel.writeFloat(localObject3);
        localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
        ((List)localObject3).add(localii);
      }
      Class localClass7 = Double.TYPE;
      if (j == localClass7);
      double d = ((Double)((Field)localObject3).get(this)).doubleValue();
      Object localObject6;
      paramParcel.writeDouble(localObject6);
      Object localObject3 = ParcelableObject.CreatorImpl.access$000(localCreatorImpl);
      ((List)localObject3).add(localii);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.persistence.ParcelableObject
 * JD-Core Version:    0.5.4
 */