package com.tencent.mobileqq.app;

public abstract interface BrandingResourceIDs
{
  public static final int DRAWABLE_BLOCK = 201;
  public static final int DRAWABLE_CHAT_WATERMARK = 202;
  public static final int DRAWABLE_LOGO = 100;
  public static final int DRAWABLE_PRESENCE_AWAY = 104;
  public static final int DRAWABLE_PRESENCE_BUSY = 103;
  public static final int DRAWABLE_PRESENCE_INVISIBLE = 105;
  public static final int DRAWABLE_PRESENCE_OFFLINE = 106;
  public static final int DRAWABLE_PRESENCE_ONLINE = 102;
  public static final int DRAWABLE_READ_CHAT = 203;
  public static final int DRAWABLE_SPLASH_SCREEN = 200;
  public static final int DRAWABLE_UNREAD_CHAT = 204;
  public static final int STRING_ADD_CONTACT_TITLE = 312;
  public static final int STRING_ARRAY_SMILEY_NAMES = 302;
  public static final int STRING_ARRAY_SMILEY_TEXTS = 303;
  public static final int STRING_BUDDY_LIST_TITLE = 301;
  public static final int STRING_BUTTON_ADD_CONTACT = 314;
  public static final int STRING_CONTACT_INFO_TITLE = 315;
  public static final int STRING_LABEL_INPUT_CONTACT = 313;
  public static final int STRING_LABEL_SIGN_UP = 326;
  public static final int STRING_LABEL_USERNAME = 310;
  public static final int STRING_MENU_ADD_CONTACT = 316;
  public static final int STRING_MENU_BLOCK_CONTACT = 320;
  public static final int STRING_MENU_CONTACT_LIST = 107;
  public static final int STRING_MENU_DELETE_CONTACT = 321;
  public static final int STRING_MENU_END_CHAT = 319;
  public static final int STRING_MENU_INSERT_SMILEY = 322;
  public static final int STRING_MENU_START_CHAT = 317;
  public static final int STRING_MENU_SWITCH_CHATS = 323;
  public static final int STRING_MENU_VIEW_PROFILE = 318;
  public static final int STRING_ONGOING_CONVERSATION = 311;
  public static final int STRING_PRESENCE_AVAILABLE = 304;
  public static final int STRING_PRESENCE_AWAY = 305;
  public static final int STRING_PRESENCE_BUSY = 306;
  public static final int STRING_PRESENCE_IDLE = 307;
  public static final int STRING_PRESENCE_INVISIBLE = 308;
  public static final int STRING_PRESENCE_OFFLINE = 309;
  public static final int STRING_TOAST_CHECK_AUTO_SIGN_IN = 324;
  public static final int STRING_TOAST_CHECK_SAVE_PASSWORD = 325;
  public static final int STRING_TOU_ACCEPT = 329;
  public static final int STRING_TOU_DECLINE = 330;
  public static final int STRING_TOU_MESSAGE = 327;
  public static final int STRING_TOU_TITLE = 328;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.BrandingResourceIDs
 * JD-Core Version:    0.5.4
 */