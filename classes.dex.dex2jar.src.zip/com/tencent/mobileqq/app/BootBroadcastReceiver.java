package com.tencent.mobileqq.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.tencent.qphone.base.util.QLog;

public class BootBroadcastReceiver extends BroadcastReceiver
{
  QQApplication a;

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    QQApplication localQQApplication = (QQApplication)paramContext.getApplicationContext();
    this.a = localQQApplication;
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    String str1 = paramContext.getString(2131296349);
    boolean bool = localSharedPreferences.getBoolean(str1, null);
    String str2 = "canBoot:" + bool;
    QLog.i("System.out", str2);
    if (bool)
      return;
    this.a.a(null);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.BootBroadcastReceiver
 * JD-Core Version:    0.5.4
 */