package com.tencent.mobileqq.app;

import android.widget.GridView;

public class QQServiceEntry$Tag
{
  public int a;
  public GridView a;
  public String a;
  public int b;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.QQServiceEntry.Tag
 * JD-Core Version:    0.5.4
 */