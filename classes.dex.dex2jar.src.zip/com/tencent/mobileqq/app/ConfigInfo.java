package com.tencent.mobileqq.app;

public class ConfigInfo
{
  public static boolean showMsfTip;

  static
  {
    boolean bool = showMsfTip;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.ConfigInfo
 * JD-Core Version:    0.5.4
 */