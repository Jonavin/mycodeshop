package com.tencent.mobileqq.app;

import android.text.format.Time;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileLog
{
  private static FileOutputStream out = null;

  public static void Writelog(String paramString)
  {
    Object localObject;
    try
    {
      localObject = out;
      if (localObject == null)
      {
        localObject = new FileOutputStream("/sdcard/liteqqlog.txt", true);
        label94: out = (FileOutputStream)localObject;
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      try
      {
        localObject = new StringBuilder();
        String str = getMessageDateTime(System.currentTimeMillis());
        localObject = str + " : " + paramString + "\r\n";
        if (out != null)
        {
          FileOutputStream localFileOutputStream = out;
          byte[] arrayOfByte = ((String)localObject).getBytes();
          localFileOutputStream.write(localObject);
        }
      }
      catch (IOException localIOException2)
      {
        while (true)
          try
          {
            if (out != null)
              out.flush();
            return;
          }
          catch (IOException localIOException1)
          {
            break label94:
            localIOException2 = localIOException2;
          }
        localFileNotFoundException = localFileNotFoundException;
      }
    }
  }

  private static String getMessageDateTime(long paramLong)
  {
    Object localObject = new Time();
    Time localTime = new Time();
    ((Time)localObject).set(paramLong);
    localTime.setToNow();
    int i = ((Time)localObject).year;
    int j = localTime.year;
    if (i != j);
    for (localObject = ((Time)localObject).format("%Y-%m-%d %H:%M:%S"); ; localObject = ((Time)localObject).format("%H:%M:%S"))
      while (true)
      {
        return localObject;
        int k = ((Time)localObject).yearDay;
        int l = localTime.yearDay;
        if (k == localTime)
          break;
        localObject = ((Time)localObject).format("%m-%d %H:%M:%S");
      }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.FileLog
 * JD-Core Version:    0.5.4
 */