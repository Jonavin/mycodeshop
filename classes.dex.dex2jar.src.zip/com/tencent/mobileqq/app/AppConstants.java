package com.tencent.mobileqq.app;

import android.os.Environment;
import java.io.File;

public abstract interface AppConstants
{
  public static final String APP_NAME = "mobileQQ";
  public static final int GROUP_BLACK_LIST_ID = 64534;
  public static final int GROUP_ONLINE_ID = 64536;
  public static final int GROUP_STRANGER_ID = 64535;
  public static final String PATH_CUSTOM_HEAD;
  public static final String SDCARD_DATABASE;
  public static final String SDCARD_IMG_SAVE;
  public static final String SDCARD_PATH;
  public static final String SDCARD_ROOT = Environment.getExternalStorageDirectory().getAbsolutePath();
  public static final String SERVICE_ID = "mobileqq.service";

  static
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = SDCARD_ROOT;
    SDCARD_PATH = str1 + "/Tencent/MobileQQ/";
    StringBuilder localStringBuilder2 = new StringBuilder();
    String str2 = SDCARD_ROOT;
    SDCARD_IMG_SAVE = str2 + "/Tencent/MobileQQImgSave/";
    StringBuilder localStringBuilder3 = new StringBuilder();
    String str3 = SDCARD_PATH;
    PATH_CUSTOM_HEAD = str3 + "/head/";
    StringBuilder localStringBuilder4 = new StringBuilder();
    String str4 = SDCARD_PATH;
    SDCARD_DATABASE = str4 + "data/";
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppConstants
 * JD-Core Version:    0.5.4
 */