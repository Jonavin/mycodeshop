package com.tencent.mobileqq.app;

public abstract interface AppConstants$Config
{
  public static final long FETCH_FRIENDLIST_AND_SIGANATURE_DURATION = 7200000L;
  public static final long FETCH_ONLINE_STATUS_DURATION = 180000L;
  public static final int FETCH_SIGNATURE_COUNT_ONE_TIME = 50;
  public static final long FETCH_TROOP_FRIEND_DURATION = 259200000L;
  public static final long UPDATE_HEAD_IMAGE_DURATION = 2592000000L;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppConstants.Config
 * JD-Core Version:    0.5.4
 */