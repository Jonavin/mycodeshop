package com.tencent.mobileqq.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Rect;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import ht;
import hu;
import hv;
import hw;
import hx;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

public class ScreenShot
{
  public static final String SAVED_PATH;
  private static Uri mLastScreenShot;
  private int jdField_a_of_type_Int;
  private Dialog jdField_a_of_type_AndroidAppDialog;
  private final Context jdField_a_of_type_AndroidContentContext;
  private Bitmap jdField_a_of_type_AndroidGraphicsBitmap;
  private View jdField_a_of_type_AndroidViewView;
  private Window jdField_a_of_type_AndroidViewWindow;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private final hx jdField_a_of_type_Hx;
  private Bitmap jdField_b_of_type_AndroidGraphicsBitmap;
  private Button jdField_b_of_type_AndroidWidgetButton;
  private ImageView jdField_b_of_type_AndroidWidgetImageView;
  private Bitmap c;

  static
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str = AppConstants.SDCARD_PATH;
    SAVED_PATH = str + "screenshot/";
    System.loadLibrary("snapcore");
  }

  public ScreenShot(Context paramContext, Window paramWindow)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    boolean bool = this.jdField_a_of_type_AndroidContentContext instanceof Activity;
    Activity localActivity;
    if (bool)
    {
      for (localActivity = (Activity)this.jdField_a_of_type_AndroidContentContext; localActivity.getParent() != null; localActivity = localActivity.getParent());
      Window localWindow = localActivity.getWindow();
    }
    for (this.jdField_a_of_type_AndroidViewWindow = localActivity; ; this.jdField_a_of_type_AndroidViewWindow = paramWindow)
    {
      ViewGroup localViewGroup = (ViewGroup)((LayoutInflater)this.jdField_a_of_type_AndroidContentContext.getSystemService("layout_inflater")).inflate(2130903080, null);
      Context localContext1 = this.jdField_a_of_type_AndroidContentContext;
      hx localhx1 = new hx(this, localContext1);
      this.jdField_a_of_type_Hx = localhx1;
      hx localhx2 = this.jdField_a_of_type_Hx;
      localViewGroup.addView(localhx2, null);
      View localView = localViewGroup.findViewById(2131493112);
      this.jdField_a_of_type_AndroidViewView = localView;
      ImageView localImageView1 = (ImageView)localViewGroup.findViewById(2131493113);
      this.jdField_a_of_type_AndroidWidgetImageView = localImageView1;
      Button localButton1 = (Button)localViewGroup.findViewById(2131493114);
      this.jdField_a_of_type_AndroidWidgetButton = localButton1;
      ImageView localImageView2 = (ImageView)localViewGroup.findViewById(2131492903);
      this.jdField_b_of_type_AndroidWidgetImageView = localImageView2;
      Button localButton2 = (Button)localViewGroup.findViewById(2131493111);
      this.jdField_b_of_type_AndroidWidgetButton = localButton2;
      ImageView localImageView3 = this.jdField_a_of_type_AndroidWidgetImageView;
      ht localht = new ht(this);
      localImageView3.setOnClickListener(localht);
      Button localButton3 = this.jdField_a_of_type_AndroidWidgetButton;
      hu localhu = new hu(this);
      localButton3.setOnClickListener(localhu);
      Context localContext2 = this.jdField_a_of_type_AndroidContentContext.getApplicationContext();
      Dialog localDialog = new Dialog(localContext2, 16973831);
      this.jdField_a_of_type_AndroidAppDialog = localDialog;
      ImageView localImageView4 = this.jdField_b_of_type_AndroidWidgetImageView;
      hv localhv = new hv(this);
      localImageView4.setOnClickListener(localhv);
      Button localButton4 = this.jdField_b_of_type_AndroidWidgetButton;
      hw localhw = new hw(this);
      localButton4.setOnClickListener(localhw);
      this.jdField_a_of_type_AndroidAppDialog.getWindow().addFlags(256);
      this.jdField_a_of_type_AndroidAppDialog.getWindow().setType(2003);
      this.jdField_a_of_type_AndroidAppDialog.setContentView(localViewGroup);
      return;
    }
  }

  private Bitmap a()
  {
    Throwable localThrowable1 = 1;
    Throwable localThrowable2 = 0;
    int i = this.jdField_a_of_type_AndroidContentContext.getResources().getDisplayMetrics().widthPixels;
    Throwable localThrowable4 = this.jdField_a_of_type_AndroidContentContext.getResources().getDisplayMetrics().heightPixels;
    int k = this.jdField_a_of_type_AndroidContentContext.getResources().getConfiguration().orientation;
    int l = 2;
    if (k == l);
    while (true)
    {
      label58: k = localThrowable4 * i * 4;
      try
      {
        ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(k);
        Object localObject = localByteBuffer.getClass();
        Class[] arrayOfClass = new Class[null];
        localObject = ((Class)localObject).getDeclaredMethod("getAddress", arrayOfClass);
        ((Method)localObject).setAccessible(true);
        Object[] arrayOfObject = new Object[null];
        this = (Integer)((Method)localObject).invoke(localByteBuffer, arrayOfObject);
        localObject = super.intValue();
        int i2 = localThrowable4 * i;
        localObject = snapScreen(localObject, i2);
        if (localObject <= 0)
        {
          localObject = Runtime.getRuntime().exec("su");
          OutputStream localOutputStream = ((Process)localObject).getOutputStream();
          DataOutputStream localDataOutputStream = new DataOutputStream(localOutputStream);
          localDataOutputStream.writeBytes("chmod 666 /dev/graphics/fb0\n");
          localDataOutputStream.writeBytes("exit\n");
          localDataOutputStream.flush();
          ((Process)localObject).waitFor();
          localObject = super.intValue();
          int i3 = localThrowable4 * i;
          localObject = snapScreen(localObject, i3);
        }
        if (localObject <= 0)
          break label293;
        localObject = Bitmap.Config.ARGB_8888;
        Bitmap localBitmap = Bitmap.createBitmap(localThrowable4, i, (Bitmap.Config)localObject);
        localBitmap.copyPixelsFromBuffer(localByteBuffer);
        localThrowable4 = localThrowable2;
        int i1 = 4;
        if (localThrowable4 >= i1)
          break label298;
        byte b1 = localByteBuffer.get(localThrowable4);
        if (b1 != 0)
        {
          localThrowable4 = localThrowable1;
          label279: if (localThrowable4 == 0)
            break label293;
          label284: return localBitmap;
        }
        label293: label298: ++localThrowable4;
      }
      catch (Throwable localThrowable3)
      {
        localThrowable3 = null;
        break label284:
        localThrowable4 = localThrowable2;
        break label279:
        Throwable localThrowable5 = localThrowable4;
        int j = localThrowable3;
        localThrowable3 = localThrowable5;
        break label58:
      }
    }
  }

  public static final Uri getLastScreenShot()
  {
    return mLastScreenShot;
  }

  public static native int snapScreen(int paramInt1, int paramInt2);

  public final void a()
  {
    int i = 0;
    int j = this.jdField_a_of_type_AndroidContentContext.getResources().getConfiguration().orientation;
    this.jdField_a_of_type_Int = j;
    this.jdField_a_of_type_Hx.k = i;
    this.jdField_a_of_type_Hx.a.setEmpty();
    Bitmap localBitmap = a();
    this.jdField_a_of_type_AndroidGraphicsBitmap = localBitmap;
    this.c = localBitmap;
    this.jdField_b_of_type_AndroidGraphicsBitmap = null;
    this.jdField_b_of_type_AndroidWidgetButton.setVisibility(i);
    this.jdField_a_of_type_AndroidViewView.setVisibility(4);
    if ((((QQApplication)this.jdField_a_of_type_AndroidContentContext.getApplicationContext()).a) && (this.jdField_a_of_type_AndroidGraphicsBitmap == null))
      return;
    this.jdField_a_of_type_AndroidAppDialog.show();
    Toast.makeText(this.jdField_a_of_type_AndroidContentContext, 2131296470, i).show();
  }

  public final boolean a()
  {
    return this.jdField_a_of_type_AndroidAppDialog.isShowing();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.ScreenShot
 * JD-Core Version:    0.5.4
 */