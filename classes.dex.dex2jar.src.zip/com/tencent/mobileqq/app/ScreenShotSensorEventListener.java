package com.tencent.mobileqq.app;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.view.Window;

public class ScreenShotSensorEventListener
  implements SensorEventListener
{
  private float jdField_a_of_type_Float;
  int jdField_a_of_type_Int = null;
  private long jdField_a_of_type_Long;
  public Activity a;
  private ScreenShot jdField_a_of_type_ComTencentMobileqqAppScreenShot;
  private float jdField_b_of_type_Float;
  private long jdField_b_of_type_Long;
  private float jdField_c_of_type_Float;
  private long jdField_c_of_type_Long;
  private float jdField_d_of_type_Float;
  private long jdField_d_of_type_Long;
  private float e;

  private void a()
  {
    this.jdField_b_of_type_Long = 0L;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_d_of_type_Long = 0L;
    this.jdField_a_of_type_Float = null;
    this.jdField_b_of_type_Float = null;
    this.jdField_c_of_type_Float = null;
    this.jdField_d_of_type_Float = null;
    this.e = null;
  }

  public void onAccuracyChanged(Sensor paramSensor, int paramInt)
  {
  }

  public void onSensorChanged(SensorEvent paramSensorEvent)
  {
    int i = 1;
    Object localObject1 = null;
    Object localObject2 = null;
    int j = paramSensorEvent.sensor.getType();
    int k;
    if (j == i)
    {
      j = paramSensorEvent.values[localObject1];
      k = paramSensorEvent.values[i];
      i = paramSensorEvent.values[2];
      long l1 = System.currentTimeMillis();
      Object localObject3;
      this.jdField_a_of_type_Long = localObject3;
      long l2 = this.jdField_a_of_type_Long;
      long l3 = this.jdField_b_of_type_Long;
      if (l2 - l3 > 100L)
      {
        long l4 = this.jdField_a_of_type_Long;
        long l5 = this.jdField_b_of_type_Long;
        long l6 = l4 - l5;
        this.jdField_c_of_type_Long = l6;
        if ((this.jdField_a_of_type_Float != localObject2) || (this.jdField_b_of_type_Float != localObject2) || (this.jdField_c_of_type_Float != localObject2))
          break label353;
        long l7 = System.currentTimeMillis();
        Object localObject4;
        this.jdField_d_of_type_Long = localObject4;
      }
    }
    while (true)
    {
      int l = this.e;
      int i1 = this.jdField_d_of_type_Float;
      float f1 = l + i1;
      this.e = f1;
      if (this.jdField_a_of_type_Int > 10)
      {
        a();
        this.jdField_a_of_type_Int = localObject1;
      }
      if ((this.e > 1120403456) && (this.jdField_a_of_type_Int >= 3))
      {
        if (this.jdField_a_of_type_ComTencentMobileqqAppScreenShot == null)
        {
          Activity localActivity1 = this.jdField_a_of_type_AndroidAppActivity;
          Window localWindow1 = this.jdField_a_of_type_AndroidAppActivity.getWindow();
          ScreenShot localScreenShot1 = new ScreenShot(localActivity1, localWindow1);
          this.jdField_a_of_type_ComTencentMobileqqAppScreenShot = localScreenShot1;
        }
        if (!this.jdField_a_of_type_ComTencentMobileqqAppScreenShot.a())
        {
          Activity localActivity2 = this.jdField_a_of_type_AndroidAppActivity;
          Window localWindow2 = this.jdField_a_of_type_AndroidAppActivity.getWindow();
          ScreenShot localScreenShot2 = new ScreenShot(localActivity2, localWindow2);
          this.jdField_a_of_type_ComTencentMobileqqAppScreenShot = localScreenShot2;
          this.jdField_a_of_type_ComTencentMobileqqAppScreenShot.a();
        }
        this.jdField_a_of_type_Int = localObject1;
        a();
      }
      int i2 = this.jdField_a_of_type_Int;
      int i3;
      ++i3;
      this.jdField_a_of_type_Int = i2;
      this.jdField_a_of_type_Float = j;
      this.jdField_b_of_type_Float = k;
      this.jdField_c_of_type_Float = i;
      long l8 = this.jdField_a_of_type_Long;
      Object localObject5;
      this.jdField_b_of_type_Long = localObject5;
      return;
      label353: int i4 = this.jdField_a_of_type_Float;
      float f2 = Math.abs(j - i4);
      int i5 = this.jdField_b_of_type_Float;
      float f3 = Math.abs(k - i5);
      float f4 = f2 + f3;
      int i6 = this.jdField_c_of_type_Float;
      float f5 = Math.abs(i - i6);
      float f6 = f4 + f5;
      this.jdField_d_of_type_Float = f6;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.ScreenShotSensorEventListener
 * JD-Core Version:    0.5.4
 */