package com.tencent.mobileqq.app;

import I;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.widget.RemoteViews;
import android.widget.Toast;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.activity.HomeActivity;
import com.tencent.mobileqq.content.FriendList;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.QQEntityManagerFactory;
import com.tencent.mobileqq.data.SigInfo;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.data.TroopMemberInfo;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;
import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.friendlist.FriendListUtil;
import com.tencent.mobileqq.service.message.MessageCache;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.mobileqq.transfile.TransFileController;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.utils.Chatter;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.mobileqq.utils.TrafficData;
import com.tencent.mobileqq.utils.httputils.HttpCommunicator;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.sync.AccountSyncHelper;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseApplication;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.HelperCallbacker;
import com.tencent.qphone.base.util.LoginHelper;
import com.tencent.qphone.base.util.PushHelper;
import com.tencent.qphone.base.util.QLog;
import com.tencent.qq.video.NativeGipsVoiceEngine;
import com.tencent.qq.video.VcController;
import hg;
import hi;
import hj;
import hk;
import hl;
import hm;
import hn;
import ho;
import hp;
import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class QQApplication extends BaseApplication
  implements AppConstants
{
  public static final String LOG_TAG = "QQlite";
  public static final long[] VIBRATOR_PATTERN;
  private static Map factoryMap;
  private static VcController mBoundService;
  int jdField_a_of_type_Int;
  private Context jdField_a_of_type_AndroidContentContext;
  private ServiceConnection jdField_a_of_type_AndroidContentServiceConnection;
  ContentObserver jdField_a_of_type_AndroidDatabaseContentObserver;
  private MediaPlayer jdField_a_of_type_AndroidMediaMediaPlayer;
  public Handler a;
  private android.os.Message jdField_a_of_type_AndroidOsMessage;
  public Toast a;
  private MessageController jdField_a_of_type_ComTencentMobileqqAppMessageController;
  private SigInfo jdField_a_of_type_ComTencentMobileqqDataSigInfo;
  EntityManagerFactory jdField_a_of_type_ComTencentMobileqqPersistenceEntityManagerFactory;
  private TransFileController jdField_a_of_type_ComTencentMobileqqTransfileTransFileController;
  public CacheUtils a;
  public final TrafficData a;
  private HttpCommunicator jdField_a_of_type_ComTencentMobileqqUtilsHttputilsHttpCommunicator;
  private VideoController jdField_a_of_type_ComTencentMobileqqVideoVideoController;
  private SimpleAccount jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
  private final BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private BaseServiceHelper jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
  HelperCallbacker jdField_a_of_type_ComTencentQphoneBaseUtilHelperCallbacker;
  public PushHelper a;
  public String a;
  private HashMap jdField_a_of_type_JavaUtilHashMap;
  private List jdField_a_of_type_JavaUtilList;
  private final Map jdField_a_of_type_JavaUtilMap;
  private ThreadPoolExecutor jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor;
  public boolean a;
  public Intent[] a;
  public Handler b;
  private HashMap b;
  public boolean b;
  private Handler jdField_c_of_type_AndroidOsHandler;
  private final HashMap jdField_c_of_type_JavaUtilHashMap;
  private boolean jdField_c_of_type_Boolean;
  private final HashMap d;

  static
  {
    int tmp1_0 = 5;
    tmp1_0[0] = 100L;
    int tmp7_1 = tmp1_0;
    tmp7_1[1] = 200L;
    int tmp13_7 = tmp7_1;
    tmp13_7[2] = 200L;
    int tmp19_13 = tmp13_7;
    tmp19_13[3] = 200L;
    int tmp25_19 = tmp19_13;
    tmp25_19[4] = 100L;
    VIBRATOR_PATTERN = tmp25_19;
    factoryMap = new Hashtable();
  }

  public QQApplication()
  {
    CacheUtils localCacheUtils = new CacheUtils(this);
    this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils = localCacheUtils;
    HashMap localHashMap1 = new HashMap();
    this.jdField_a_of_type_JavaUtilHashMap = localHashMap1;
    HashMap localHashMap2 = new HashMap();
    this.jdField_b_of_type_JavaUtilHashMap = localHashMap2;
    Intent[] arrayOfIntent = new Intent[2];
    this.jdField_a_of_type_ArrayOfAndroidContentIntent = arrayOfIntent;
    hp localhp = new hp(this);
    ThreadPoolExecutor localThreadPoolExecutor = (ThreadPoolExecutor)Executors.newFixedThreadPool(3, localhp);
    this.jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor = localThreadPoolExecutor;
    HashMap localHashMap3 = new HashMap();
    this.jdField_c_of_type_JavaUtilHashMap = localHashMap3;
    HashMap localHashMap4 = new HashMap();
    this.d = localHashMap4;
    this.jdField_a_of_type_Boolean = true;
    this.jdField_b_of_type_Boolean = null;
    HashMap localHashMap5 = new HashMap();
    this.jdField_a_of_type_JavaUtilMap = localHashMap5;
    SigInfo localSigInfo = new SigInfo();
    this.jdField_a_of_type_ComTencentMobileqqDataSigInfo = localSigInfo;
    hg localhg = new hg(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localhg;
    Handler localHandler = new Handler();
    hm localhm = new hm(this, localHandler);
    this.jdField_a_of_type_AndroidDatabaseContentObserver = localhm;
    this.jdField_a_of_type_Int = null;
    hn localhn = new hn(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilHelperCallbacker = localhn;
    TrafficData localTrafficData = new TrafficData(this);
    this.jdField_a_of_type_ComTencentMobileqqUtilsTrafficData = localTrafficData;
    ho localho = new ho(this);
    this.jdField_a_of_type_AndroidContentServiceConnection = localho;
  }

  public static VcController GetVideoService()
  {
    return mBoundService;
  }

  private Drawable a(File paramFile)
  {
    String str1 = paramFile.getPath();
    Object localObject = this.jdField_c_of_type_JavaUtilHashMap;
    String str2 = paramFile.getPath();
    localObject = (WeakReference)((HashMap)localObject).get(str2);
    int i = 0;
    if (localObject != null);
    Bitmap localBitmap;
    for (localObject = (Drawable)((WeakReference)localObject).get(); ; localObject = localBitmap)
    {
      if (localObject == 0)
      {
        boolean bool = paramFile.exists();
        if (bool)
        {
          localBitmap = BitmapFactory.decodeFile(paramFile.getPath());
          if (localBitmap != null)
          {
            localObject = new BitmapDrawable(localBitmap);
            HashMap localHashMap = this.jdField_c_of_type_JavaUtilHashMap;
            WeakReference localWeakReference = new WeakReference(localObject);
            localBitmap.put(str1, localWeakReference);
          }
        }
      }
      return localObject;
    }
  }

  public static EntityManagerFactory createEntityManagerFactory(String paramString)
  {
    return (EntityManagerFactory)factoryMap.get(paramString);
  }

  private static int getAndroidInternalId(String paramString)
  {
    Object localObject1 = null;
    try
    {
      Object localObject2 = Class.forName("com.android.internal.R").getDeclaredClasses();
      int i = localObject2.length;
      Object localObject4 = localObject1;
      if (localObject4 >= i)
        break label66;
      Object localObject5 = localObject2[localObject4];
      String str = localObject5.getSimpleName();
      if ("id".equals(str))
      {
        localObject2 = localObject5.getDeclaredField(paramString).getInt(null);
        label57: return localObject2;
      }
      label66: ++localObject4;
    }
    catch (Exception localObject3)
    {
      Object localObject3 = localObject1;
      break label57:
    }
  }

  public static EntityManagerFactory getEntityManagerFactory(String paramString)
  {
    if (!factoryMap.containsKey(paramString))
    {
      Map localMap = factoryMap;
      QQEntityManagerFactory localQQEntityManagerFactory = new QQEntityManagerFactory(paramString);
      localMap.put(paramString, localQQEntityManagerFactory);
    }
    return (EntityManagerFactory)factoryMap.get(paramString);
  }

  public static SQLiteOpenHelper getSQLiteOpenHelper(String paramString)
  {
    return getEntityManagerFactory(paramString).build(paramString);
  }

  public final int a()
  {
    return ((AudioManager)getSystemService("audio")).getRingerMode();
  }

  // ERROR //
  public final int a(int paramInt, String paramString, boolean paramBoolean)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aconst_null
    //   4: astore 5
    //   6: iload_1
    //   7: ifne +42 -> 49
    //   10: aload_0
    //   11: getfield 69	com/tencent/mobileqq/app/QQApplication:jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils	Lcom/tencent/mobileqq/utils/CacheUtils;
    //   14: getfield 299	com/tencent/mobileqq/utils/CacheUtils:jdField_c_of_type_JavaUtilHashMap	Ljava/util/HashMap;
    //   17: astore 6
    //   19: iload_3
    //   20: ifeq +48 -> 68
    //   23: aload 6
    //   25: aload_2
    //   26: invokevirtual 300	java/util/HashMap:containsKey	(Ljava/lang/Object;)Z
    //   29: ifeq +32 -> 61
    //   32: aload 6
    //   34: aload_2
    //   35: invokevirtual 157	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   38: checkcast 302	java/lang/Integer
    //   41: invokevirtual 305	java/lang/Integer:intValue	()I
    //   44: astore 6
    //   46: aload 6
    //   48: ireturn
    //   49: aload_0
    //   50: getfield 69	com/tencent/mobileqq/app/QQApplication:jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils	Lcom/tencent/mobileqq/utils/CacheUtils;
    //   53: getfield 306	com/tencent/mobileqq/utils/CacheUtils:d	Ljava/util/HashMap;
    //   56: astore 6
    //   58: goto -39 -> 19
    //   61: aload 5
    //   63: astore 6
    //   65: goto -19 -> 46
    //   68: iload_1
    //   69: ifne +188 -> 257
    //   72: new 308	java/lang/StringBuilder
    //   75: dup
    //   76: invokespecial 309	java/lang/StringBuilder:<init>	()V
    //   79: astore 7
    //   81: ldc_w 311
    //   84: astore 8
    //   86: aload 7
    //   88: aload 8
    //   90: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: aload_2
    //   94: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: invokevirtual 318	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   100: astore 7
    //   102: aload_0
    //   103: getfield 216	com/tencent/mobileqq/app/QQApplication:jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount	Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   106: astore 8
    //   108: aload 8
    //   110: ifnull +180 -> 290
    //   113: aload_0
    //   114: invokevirtual 321	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/mobileqq/persistence/EntityManagerFactory;
    //   117: astore 8
    //   119: aload_0
    //   120: getfield 216	com/tencent/mobileqq/app/QQApplication:jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount	Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   123: invokevirtual 326	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   126: astore 9
    //   128: aload 8
    //   130: aload 9
    //   132: invokevirtual 285	com/tencent/mobileqq/persistence/EntityManagerFactory:build	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteOpenHelper;
    //   135: astore 8
    //   137: aload 8
    //   139: invokevirtual 332	android/database/sqlite/SQLiteOpenHelper:getReadableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   142: astore 8
    //   144: new 308	java/lang/StringBuilder
    //   147: dup
    //   148: invokespecial 309	java/lang/StringBuilder:<init>	()V
    //   151: ldc_w 334
    //   154: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: astore 10
    //   159: aload_0
    //   160: invokevirtual 340	java/lang/Object:getClass	()Ljava/lang/Class;
    //   163: invokevirtual 343	java/lang/Class:getName	()Ljava/lang/String;
    //   166: astore 11
    //   168: aload 10
    //   170: aload 11
    //   172: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: ldc_w 345
    //   178: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: invokevirtual 318	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   184: astore 12
    //   186: ldc_w 347
    //   189: aload 12
    //   191: invokestatic 352	com/tencent/qphone/base/util/QLog:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   194: new 308	java/lang/StringBuilder
    //   197: dup
    //   198: invokespecial 309	java/lang/StringBuilder:<init>	()V
    //   201: ldc_w 354
    //   204: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: aload 7
    //   209: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: ldc_w 356
    //   215: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   218: invokevirtual 318	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   221: astore 7
    //   223: aload 8
    //   225: aload 7
    //   227: aconst_null
    //   228: invokevirtual 362	android/database/sqlite/SQLiteDatabase:rawQuery	(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   231: astore 7
    //   233: aload 7
    //   235: ifnonnull +62 -> 297
    //   238: aload 7
    //   240: ifnull +10 -> 250
    //   243: aload 7
    //   245: invokeinterface 367 1 0
    //   250: aload 5
    //   252: astore 6
    //   254: goto -208 -> 46
    //   257: new 308	java/lang/StringBuilder
    //   260: dup
    //   261: invokespecial 309	java/lang/StringBuilder:<init>	()V
    //   264: astore 7
    //   266: ldc_w 369
    //   269: astore 8
    //   271: aload 7
    //   273: aload 8
    //   275: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: aload_2
    //   279: invokevirtual 315	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: invokevirtual 318	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   285: astore 7
    //   287: goto -185 -> 102
    //   290: aload 4
    //   292: astore 8
    //   294: goto -157 -> 137
    //   297: aload 7
    //   299: invokeinterface 372 1 0
    //   304: astore 8
    //   306: iload 8
    //   308: ifeq +136 -> 444
    //   311: aload 7
    //   313: iconst_0
    //   314: invokeinterface 375 2 0
    //   319: astore 8
    //   321: iload 8
    //   323: invokestatic 379	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   326: astore 13
    //   328: aload 6
    //   330: aload_2
    //   331: aload 13
    //   333: invokevirtual 186	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   336: pop
    //   337: iload 8
    //   339: istore 6
    //   341: aload 7
    //   343: ifnull -297 -> 46
    //   346: aload 7
    //   348: invokeinterface 367 1 0
    //   353: goto -307 -> 46
    //   356: astore 6
    //   358: aload 4
    //   360: astore 6
    //   362: aload 5
    //   364: astore 7
    //   366: aload 6
    //   368: ifnull +69 -> 437
    //   371: aload 6
    //   373: invokeinterface 367 1 0
    //   378: aload 7
    //   380: astore 6
    //   382: goto -336 -> 46
    //   385: astore 6
    //   387: aload 4
    //   389: astore 7
    //   391: aload 7
    //   393: ifnull +10 -> 403
    //   396: aload 7
    //   398: invokeinterface 367 1 0
    //   403: aload 6
    //   405: athrow
    //   406: astore 6
    //   408: goto -17 -> 391
    //   411: astore 6
    //   413: aload 7
    //   415: astore 6
    //   417: aload 5
    //   419: astore 7
    //   421: goto -55 -> 366
    //   424: astore 6
    //   426: aload 7
    //   428: astore 6
    //   430: iload 8
    //   432: istore 7
    //   434: goto -68 -> 366
    //   437: aload 7
    //   439: astore 6
    //   441: goto -395 -> 46
    //   444: aload 5
    //   446: astore 6
    //   448: goto -107 -> 341
    //
    // Exception table:
    //   from	to	target	type
    //   102	233	356	java/lang/Exception
    //   102	233	385	finally
    //   297	321	406	finally
    //   321	337	406	finally
    //   297	321	411	java/lang/Exception
    //   321	337	424	java/lang/Exception
  }

  public final int a(Boolean paramBoolean)
  {
    boolean bool1 = paramBoolean.booleanValue();
    label25: int i;
    if (bool1)
    {
      boolean bool2 = null;
      Iterator localIterator = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.jdField_a_of_type_JavaUtilVector.iterator();
      boolean bool4 = bool2;
      boolean bool3;
      while (true)
      {
        bool2 = localIterator.hasNext();
        if (!bool2)
          break label175;
        Object localObject1 = (Chatter)localIterator.next();
        if (((Chatter)localObject1).jdField_a_of_type_Int != 0)
          break;
        HashMap localHashMap1 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.jdField_c_of_type_JavaUtilHashMap;
        String str2 = ((Chatter)localObject1).jdField_a_of_type_JavaLangString;
        if (!localHashMap1.containsKey(str2))
          break label186;
        HashMap localHashMap2 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.jdField_c_of_type_JavaUtilHashMap;
        localObject1 = ((Chatter)localObject1).jdField_a_of_type_JavaLangString;
        bool3 = ((Integer)localHashMap2.get(localObject1)).intValue() + bool4;
        bool4 = bool3;
      }
      HashMap localHashMap3 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.d;
      String str3 = bool3.jdField_a_of_type_JavaLangString;
      if (!localHashMap3.containsKey(str3))
        break label186;
      HashMap localHashMap4 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.d;
      String str1 = bool3.jdField_a_of_type_JavaLangString;
      i = ((Integer)localHashMap4.get(str1)).intValue() + bool4;
    }
    while (true)
    {
      Object localObject3 = i;
      break label25:
      label175: this.jdField_a_of_type_Int = localObject3;
      return this.jdField_a_of_type_Int;
      label186: Object localObject2 = localObject3;
    }
  }

  public final SQLiteDatabase a()
  {
    Object localObject1 = null;
    try
    {
      Object localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
      if (localObject2 != null)
      {
        localObject2 = this.jdField_a_of_type_ComTencentMobileqqPersistenceEntityManagerFactory;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str1 = SDCARD_DATABASE;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
        String str2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        String str3 = str2;
        localObject2 = ((EntityManagerFactory)localObject2).build(str3);
        localObject2 = ((SQLiteOpenHelper)localObject2).getWritableDatabase();
        label70: return localObject2;
      }
      localObject2 = localObject1;
    }
    catch (Exception localObject3)
    {
      Object localObject3 = localObject1;
      break label70:
    }
  }

  public final SQLiteOpenHelper a()
  {
    Object localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
    if (localObject != null)
    {
      localObject = a();
      String str = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
      localObject = ((EntityManagerFactory)localObject).build(str);
    }
    while (true)
    {
      return localObject;
      int i = 0;
    }
  }

  public final Drawable a(int paramInt, String paramString, boolean paramBoolean)
  {
    int i = 1;
    int j = 0;
    Object localObject1;
    if (paramString != null)
    {
      Object localObject4 = new StringBuilder();
      String str1 = AppConstants.PATH_CUSTOM_HEAD;
      localObject4 = str1 + paramString + ".png";
      localObject1 = new File((String)localObject4);
      localObject1 = a((File)localObject1);
      localObject4 = paramString.equals("10000");
      if (localObject4 != 0)
      {
        localObject1 = ((BitmapDrawable)getResources().getDrawable(2130838047)).getBitmap();
        localObject1 = new BitmapDrawable((Bitmap)localObject1);
        label108: return localObject1;
      }
      if (paramBoolean)
      {
        localObject4 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
        String str2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        byte[] arrayOfByte = LoginHelper.getA2(this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin());
        ProfileUtil.getCustomHead((BaseServiceHelper)localObject4, str2, paramString, arrayOfByte);
      }
    }
    label186: Object localObject2;
    if (localObject1 == 0)
    {
      int k = paramInt / 3;
      if (++k >= 0)
      {
        int l = 138;
        if (k < l)
          break label186;
      }
      k = i;
      localObject5 = getResources();
      k = k + 2130837749 - i;
      localObject2 = ((Resources)localObject5).getDrawable(k);
    }
    Object localObject3;
    for (Object localObject5 = localObject2; ; localObject5 = localObject3)
    {
      localObject2 = this.jdField_c_of_type_JavaUtilHashMap.containsKey(paramString);
      if (localObject2 != 0)
      {
        localObject2 = ((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(paramString)).get();
        if (localObject2 != null)
          localObject2 = (Drawable)((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(paramString)).get();
      }
      boolean bool = localObject5 instanceof BitmapDrawable;
      if (bool)
      {
        localObject3 = ((BitmapDrawable)localObject5).getBitmap();
        BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject3);
        localObject3 = this.jdField_c_of_type_JavaUtilHashMap;
        WeakReference localWeakReference = new WeakReference(localObject5);
        ((HashMap)localObject3).put(paramString, localWeakReference);
        localObject3 = localObject5;
      }
      localObject3 = localObject5;
      break label108:
    }
  }

  public final Drawable a(int paramInt, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = 1;
    int j = -1;
    int k = 1073741824;
    int l = 0;
    Object localObject1;
    if (paramString != null)
    {
      Object localObject4 = new StringBuilder();
      String str1 = AppConstants.PATH_CUSTOM_HEAD;
      localObject4 = ((StringBuilder)localObject4).append(str1).append(paramString);
      str1 = ".png";
      localObject4 = str1;
      localObject1 = new File((String)localObject4);
      localObject1 = a((File)localObject1);
      localObject4 = paramString.equals("10000");
      if (localObject4 != 0)
      {
        localObject1 = ((BitmapDrawable)getResources().getDrawable(2130838047)).getBitmap();
        float f1 = getResources().getDisplayMetrics().density * k;
        localObject1 = ImageUtil.round((Bitmap)localObject1, f1, j);
        localObject1 = new BitmapDrawable((Bitmap)localObject1);
        label151: return localObject1;
      }
      if (paramBoolean2)
      {
        localObject4 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
        str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        byte[] arrayOfByte = LoginHelper.getA2(this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin());
        ProfileUtil.getCustomHead((BaseServiceHelper)localObject4, str1, paramString, arrayOfByte);
      }
    }
    label230: Object localObject2;
    if (localObject1 == 0)
    {
      int i1 = paramInt / 3;
      if (++i1 >= 0)
      {
        int i2 = 138;
        if (i1 < i2)
          break label230;
      }
      i1 = i;
      localObject5 = getResources();
      int i3 = 2130837749;
      i1 = i1 + i3 - i;
      localObject2 = ((Resources)localObject5).getDrawable(i1);
    }
    Object localObject3;
    for (Object localObject5 = localObject2; ; localObject5 = localObject3)
    {
      String str2 = paramString + paramBoolean1;
      localObject2 = this.jdField_c_of_type_JavaUtilHashMap.containsKey(str2);
      if (localObject2 != 0)
      {
        localObject2 = ((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(str2)).get();
        if (localObject2 != null)
          localObject2 = (Drawable)((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(str2)).get();
      }
      boolean bool = localObject5 instanceof BitmapDrawable;
      if (bool)
      {
        localObject3 = ((BitmapDrawable)localObject5).getBitmap();
        if (paramBoolean1)
          localObject3 = ImageUtil.grey((Bitmap)localObject3);
        float f2 = getResources().getDisplayMetrics().density * k;
        localObject3 = ImageUtil.round((Bitmap)localObject3, f2, j);
        BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject3);
        localObject3 = this.jdField_c_of_type_JavaUtilHashMap;
        WeakReference localWeakReference = new WeakReference(localBitmapDrawable);
        ((HashMap)localObject3).put(str2, localWeakReference);
        localObject3 = localBitmapDrawable;
      }
      localObject3 = localObject5;
      break label151:
    }
  }

  public final Drawable a(Uri paramUri)
  {
    String str = paramUri.toString();
    Object localObject1 = (WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(str);
    int i = 0;
    if (localObject1 != null)
    {
      localObject1 = (Drawable)((WeakReference)localObject1).get();
      label32: if (localObject1 != 0);
    }
    Bitmap localBitmap;
    BitmapDrawable localBitmapDrawable;
    try
    {
      localBitmap = BitmapFactory.decodeFile(str);
      if (localBitmap != null)
      {
        Resources localResources = getResources();
        label93: localBitmapDrawable = new BitmapDrawable(localResources, localBitmap);
      }
    }
    catch (Exception localException2)
    {
      try
      {
        localObject1 = this.jdField_c_of_type_JavaUtilHashMap;
        WeakReference localWeakReference = new WeakReference(localBitmapDrawable);
        ((HashMap)localObject1).put(str, localWeakReference);
        localObject1 = localBitmapDrawable;
        return localObject1;
        localException2 = localException2;
      }
      catch (Exception localObject2)
      {
        Object localObject2 = localBitmapDrawable;
        break label93:
        localObject2 = localBitmap;
        break label32:
      }
    }
  }

  public final Drawable a(boolean paramBoolean)
  {
    int i;
    Object localObject2;
    if (paramBoolean)
    {
      localObject1 = "troop_face_block";
      i = 2130837735;
      localObject2 = localObject1;
      label15: localObject1 = this.jdField_c_of_type_JavaUtilHashMap.containsKey(localObject2);
      if (localObject1 == 0)
        break label84;
      localObject1 = ((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(localObject2)).get();
      if (localObject1 == null)
        break label84;
    }
    for (Object localObject1 = (Drawable)((WeakReference)this.jdField_c_of_type_JavaUtilHashMap.get(localObject2)).get(); ; localObject1 = i)
    {
      return localObject1;
      localObject1 = "troop_face";
      i = 2130837734;
      localObject2 = localObject1;
      break label15:
      label84: localObject1 = BitmapFactory.decodeResource(getResources(), i);
      int j = getResources().getDisplayMetrics().density;
      float f = 1073741824 * j;
      localObject1 = ImageUtil.round((Bitmap)localObject1, i, -1);
      BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject1);
      localObject1 = this.jdField_c_of_type_JavaUtilHashMap;
      WeakReference localWeakReference = new WeakReference(i);
      ((HashMap)localObject1).put(localObject2, localWeakReference);
    }
  }

  public final Handler a(Class paramClass)
  {
    return (Handler)this.jdField_a_of_type_JavaUtilMap.get(paramClass);
  }

  public final SigInfo a()
  {
    return this.jdField_a_of_type_ComTencentMobileqqDataSigInfo;
  }

  public final EntityManagerFactory a()
  {
    Thread localThread1 = Thread.currentThread();
    Thread localThread2 = Looper.getMainLooper().getThread();
    if (localThread1 != localThread2)
      RuntimeException localRuntimeException = new RuntimeException("getEntityManagerFactory must be run on UI Thread!!!");
    Map localMap = factoryMap;
    String str = this.jdField_a_of_type_JavaLangString;
    return (EntityManagerFactory)localMap.get(str);
  }

  public final TransFileController a()
  {
    return this.jdField_a_of_type_ComTencentMobileqqTransfileTransFileController;
  }

  public final HttpCommunicator a()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqUtilsHttputilsHttpCommunicator == null)
    {
      HttpCommunicator localHttpCommunicator = new HttpCommunicator(this);
      this.jdField_a_of_type_ComTencentMobileqqUtilsHttputilsHttpCommunicator = localHttpCommunicator;
      this.jdField_a_of_type_ComTencentMobileqqUtilsHttputilsHttpCommunicator.a();
    }
    return this.jdField_a_of_type_ComTencentMobileqqUtilsHttputilsHttpCommunicator;
  }

  public final VideoController a()
  {
    return this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
  }

  public final SimpleAccount a()
  {
    return this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
  }

  public final BaseActionListener a()
  {
    return this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  }

  public final BaseServiceHelper a()
  {
    return this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
  }

  public final String a(String paramString)
  {
    Object localObject1 = 1;
    Object localObject2 = 0;
    int i = 0;
    Object localObject3 = a().createEntityManager();
    String[] arrayOfString = new String[2];
    arrayOfString[localObject2] = paramString;
    arrayOfString[localObject1] = "0";
    Object localObject4 = i;
    Object localObject5 = ((EntityManager)localObject3).a(TroopMemberInfo.class, "troopuin=? and memberuin=?", arrayOfString, i, localObject4);
    if (localObject5 != null)
      this = (TroopMemberInfo)((List)localObject5).get(localObject2);
    for (localObject5 = this; ; localObject5 = i)
    {
      this = (TroopInfo)((EntityManager)localObject3).a(TroopInfo.class, paramString);
      ((EntityManager)localObject3).a();
      if (localObject5 != 0)
      {
        long l1 = ((TroopMemberInfo)localObject5).datetime < 0L;
        if (localObject3 > 0)
        {
          l1 = ((TroopMemberInfo)localObject5).datetime + 259200000L;
          long l2 = System.currentTimeMillis();
          Object localObject6;
          l1 <= localObject6;
          if (localObject3 > 0)
            break label190;
        }
        localObject3 = localObject1;
        label147: if ((localObject3 == 0) || (this == null))
          break label202;
        localObject3 = this.troopcode;
        if (localObject3 == null)
          break label202;
        localObject3 = this.troopcode.length();
        if (localObject3 <= 0)
          break label202;
      }
      for (localObject3 = this.troopcode; ; localObject3 = i)
      {
        return localObject3;
        label190: localObject3 = localObject2;
        break label147:
        localObject3 = localObject1;
        label202: break label147:
      }
    }
  }

  public final String a(String paramString1, String paramString2)
  {
    long l = 0L;
    int i = 2;
    int j = 1;
    int k = 0;
    int i1 = 0;
    EntityManager localEntityManager = a().createEntityManager();
    String[] arrayOfString1 = new String[i];
    arrayOfString1[k] = paramString1;
    arrayOfString1[j] = paramString2;
    Object localObject1 = i1;
    Object localObject2 = localEntityManager.a(TroopMemberInfo.class, "troopuin=? and memberuin=?", arrayOfString1, i1, localObject1);
    if (localObject2 != null);
    for (localObject2 = (TroopMemberInfo)((List)localObject2).get(k); ; localObject2 = i1)
    {
      if (localObject2 != 0)
        if ((((TroopMemberInfo)localObject2).troopnick == null) || (((TroopMemberInfo)localObject2).troopnick.trim().length() <= 0));
      for (Object localObject3 = ((TroopMemberInfo)localObject2).troopnick; ; localObject3 = i1)
      {
        if ((localObject2 == 0) || (localObject3 == 0))
        {
          label120: String[] arrayOfString2 = new String[i];
          arrayOfString2[k] = paramString1;
          arrayOfString2[j] = "0";
          Object localObject4 = i1;
          localObject2 = localEntityManager.a(TroopMemberInfo.class, "troopuin=? and memberuin=?", arrayOfString2, i1, localObject4);
          if (localObject2 == null)
            break label271;
        }
        for (localObject2 = (TroopMemberInfo)((List)localObject2).get(k); ; localObject2 = i1)
        {
          if (localObject2 == 0)
          {
            TroopMemberInfo localTroopMemberInfo = new TroopMemberInfo();
            localTroopMemberInfo.troopuin = paramString1;
            localTroopMemberInfo.memberuin = "0";
            localTroopMemberInfo.datetime = l;
            localEntityManager.a(localTroopMemberInfo, k);
          }
          while (true)
          {
            localEntityManager.a();
            return localObject3;
            localObject3 = ((TroopMemberInfo)localObject2).friendnick;
            break label120:
            ((TroopMemberInfo)localObject2).datetime = l;
            label271: localEntityManager.a((Entity)localObject2);
          }
        }
      }
    }
  }

  public final List a()
  {
    Vector localVector1 = new Vector();
    Object localObject1 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils;
    synchronized (((CacheUtils)localObject1).b)
    {
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.b;
      Iterator localIterator = ((Vector)localObject1).iterator();
      do
      {
        localObject1 = localIterator.hasNext();
        if (localObject1 == 0)
          break label103;
        localObject1 = (Chatter)localIterator.next();
        localObject1 = (UnreadMsgFriendInfo)this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.jdField_a_of_type_JavaUtilMap.get(localObject1);
      }
      while ((localObject1 == null) || (((UnreadMsgFriendInfo)localObject1).isRead));
      localVector1.add(0, localObject1);
    }
    label103: monitorexit;
    return (List)localVector1;
  }

  public final void a()
  {
    if ((this.jdField_a_of_type_AndroidMediaMediaPlayer == null) || (!this.jdField_a_of_type_AndroidMediaMediaPlayer.isPlaying()))
      return;
    this.jdField_a_of_type_AndroidMediaMediaPlayer.stop();
  }

  /** @deprecated */
  public final void a(int paramInt1, String paramString, int paramInt2)
  {
    monitorenter;
    if (paramInt1 == 0);
    HashMap localHashMap2;
    Integer localInteger2;
    try
    {
      HashMap localHashMap1 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.jdField_c_of_type_JavaUtilHashMap;
      Integer localInteger1 = Integer.valueOf(paramInt2);
      localHashMap1.put(paramString, localInteger1);
      return;
      localHashMap2 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.d;
      localInteger2 = Integer.valueOf(paramInt2);
    }
    finally
    {
      monitorexit;
    }
  }

  public final void a(int paramInt, boolean paramBoolean)
  {
    QLog.v("QQlite", "mediaPalyerStart");
    if ((this.jdField_a_of_type_AndroidMediaMediaPlayer != null) && (this.jdField_a_of_type_AndroidMediaMediaPlayer.isPlaying()));
    while (true)
    {
      return;
      MediaPlayer localMediaPlayer = MediaPlayer.create(getApplicationContext(), paramInt);
      this.jdField_a_of_type_AndroidMediaMediaPlayer = localMediaPlayer;
      try
      {
        if (this.jdField_a_of_type_AndroidMediaMediaPlayer != null);
        this.jdField_a_of_type_AndroidMediaMediaPlayer.start();
        this.jdField_a_of_type_AndroidMediaMediaPlayer.setLooping(paramBoolean);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
    }
  }

  public final void a(Context paramContext)
  {
    CharSequence localCharSequence = null;
    int i = 2130837938;
    boolean bool = true;
    float f1 = null;
    int j = 0;
    if (paramContext == null);
    do
    {
      label19: return;
      QLog.i("System.out", "application work in background.");
      this.jdField_a_of_type_AndroidContentContext = paramContext;
      this.jdField_a_of_type_Boolean = bool;
      localObject2 = PreferenceManager.getDefaultSharedPreferences(this);
      localObject3 = getString(2131296357);
      localObject2 = ((SharedPreferences)localObject2).getBoolean((String)localObject3, bool);
    }
    while (localObject2 == 0);
    Object localObject2 = paramContext.getClass();
    Object localObject3 = new Intent(this, (Class)localObject2);
    localObject2 = ((Activity)paramContext).getIntent().getExtras();
    if (localObject2 != null)
    {
      ((Bundle)localObject2).remove("single");
      localObject1 = "selfuin";
      ((Bundle)localObject2).remove((String)localObject1);
      ((Intent)localObject3).putExtras((Bundle)localObject2);
    }
    ((Intent)localObject3).addFlags(536870912).addFlags(67108864);
    Object localObject1 = PendingIntent.getActivity(this, j, (Intent)localObject3, j);
    localObject2 = (NotificationManager)getSystemService("notification");
    long l1 = System.currentTimeMillis();
    Object localObject7;
    Notification localNotification = new Notification(i, localCharSequence, localObject7);
    int k = localNotification.flags | 0x32;
    localNotification.flags = k;
    Object localObject4 = this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils;
    String str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    localObject4 = ((CacheUtils)localObject4).a(str1);
    str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    Object localObject8 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    localObject8 = getSharedPreferences((String)localObject8, j);
    String str2 = "getProfileStatus";
    long l2 = ((SharedPreferences)localObject8).getLong(str2, 11L) < 41L;
    int i1;
    label295: Object localObject9;
    label365: Object localObject6;
    Object localObject5;
    if (localObject8 == 0)
    {
      i1 = 2130838038;
      if (localObject4 == null)
        break label643;
      int i2 = paramContext.getResources().getDisplayMetrics().density;
      int l = (int)(1082130432 * i2);
      localObject9 = ((Friends)localObject4).name;
      if (localObject9 == null)
        break label633;
      String str3 = ((Friends)localObject4).name.trim();
      localObject9 = "".equals(str3);
      if (localObject9 != 0)
        break label633;
      localObject9 = ((Friends)localObject4).name;
      int i3 = ((Friends)localObject4).faceid;
      localObject4 = ((Friends)localObject4).uin;
      localObject4 = ((BitmapDrawable)a(i3, (String)localObject4, j, j)).getBitmap();
      Bitmap localBitmap1 = BitmapFactory.decodeResource(getResources(), i1);
      int i4 = ((Bitmap)localObject4).getWidth();
      int i5 = ((Bitmap)localObject4).getHeight();
      Bitmap.Config localConfig = ((Bitmap)localObject4).getConfig();
      Bitmap localBitmap2 = Bitmap.createBitmap(i4, i5, j);
      Canvas localCanvas = new Canvas(localBitmap2);
      Paint localPaint = new Paint();
      localCanvas.drawBitmap((Bitmap)localObject4, f1, f1, j);
      int i6 = ((Bitmap)localObject4).getWidth();
      int i7 = i1.getWidth();
      float f3 = j - f1 + l;
      localObject4 = ((Bitmap)localObject4).getHeight();
      int i8 = i1.getHeight();
      float f2 = localObject4 - f1 + l;
      localObject6 = new Paint();
      localCanvas.drawBitmap(i1, j, f2, (Paint)localObject6);
      localObject5 = localBitmap2;
      localObject6 = localObject9;
    }
    while (true)
    {
      String str4 = getString(2131296260);
      localNotification.setLatestEventInfo(this, (CharSequence)localObject6, str4, (PendingIntent)localObject1);
      if (localObject5 != null)
      {
        localObject1 = getAndroidInternalId("icon");
        if (localObject1 > 0)
          localNotification.contentView.setImageViewBitmap(localObject1, (Bitmap)localObject5);
      }
      localNotification.icon = i;
      ((NotificationManager)localObject2).notify(2130837895, localNotification);
      break label19:
      i1 = 2130838040;
      break label295:
      label633: localObject9 = ((Friends)localObject5).uin;
      break label365:
      label643: localObject5 = localCharSequence;
    }
  }

  public final void a(Handler paramHandler, android.os.Message paramMessage)
  {
    this.jdField_c_of_type_AndroidOsHandler = paramHandler;
    this.jdField_a_of_type_AndroidOsMessage = paramMessage;
  }

  public final void a(UnreadMsgFriendInfo paramUnreadMsgFriendInfo)
  {
    int i = 2130837939;
    int j = 2130837895;
    int k = 1;
    Object localObject1 = this.jdField_a_of_type_ArrayOfAndroidContentIntent[k];
    String str1 = paramUnreadMsgFriendInfo.uin;
    ((Intent)localObject1).putExtra("uin", str1);
    localObject1 = this.jdField_a_of_type_ArrayOfAndroidContentIntent[k];
    int l = paramUnreadMsgFriendInfo.type;
    ((Intent)localObject1).putExtra("uin type", l);
    localObject1 = getContentResolver();
    Object localObject4 = com.tencent.mobileqq.content.Message.MSG_RECORD_URI_PREFIX;
    Object localObject2 = this.jdField_a_of_type_AndroidDatabaseContentObserver;
    ((ContentResolver)localObject1).registerContentObserver((Uri)localObject4, k, (ContentObserver)localObject2);
    localObject1 = new Intent(this, HomeActivity.class);
    localObject2 = paramUnreadMsgFriendInfo.uin;
    localObject1 = ((Intent)localObject1).putExtra("uin", (String)localObject2);
    int i1 = paramUnreadMsgFriendInfo.type;
    localObject4 = ((Intent)localObject1).putExtra("uin type", i1).addCategory("android.intent.category.CHAT").addFlags(536870912).addFlags(67108864);
    localObject1 = paramUnreadMsgFriendInfo.nick;
    if (localObject1 != null)
    {
      localObject3 = ((String)localObject1).trim();
      str2 = "";
      localObject3 = ((String)localObject3).equals(str2);
      if (localObject3 == 0)
        break label201;
    }
    localObject1 = paramUnreadMsgFriendInfo.uin;
    label201: Object localObject3 = (String)localObject1 + ":";
    String str2 = paramUnreadMsgFriendInfo.lastMsg;
    localObject3 = (String)localObject3 + str2;
    int i2 = paramUnreadMsgFriendInfo.unReadNum;
    int i3;
    if (i2 > k)
    {
      StringBuilder localStringBuilder = new StringBuilder().append((String)localObject1).append(" (");
      i3 = paramUnreadMsgFriendInfo.unReadNum;
    }
    for (Object localObject5 = i3 + "鏉℃�"; ; localObject5 = localObject1)
    {
      NotificationManager localNotificationManager = (NotificationManager)getSystemService("notification");
      localNotificationManager.cancel(j);
      PendingIntent localPendingIntent = PendingIntent.getActivity(this, 0, (Intent)localObject4, 134217728);
      long l1 = System.currentTimeMillis();
      Object localObject6;
      Notification localNotification = new Notification(i, (CharSequence)localObject3, localObject6);
      int i4 = localNotification.flags | 0x31;
      localNotification.flags = ((I)localObject3);
      localNotification.ledARGB = -16711936;
      localNotification.ledOffMS = 300;
      localNotification.ledOnMS = 1000;
      localNotification.icon = i;
      localNotification.setLatestEventInfo(this, (CharSequence)localObject5, str2, (PendingIntent)localObject4);
      localNotificationManager.notify(j, localNotification);
      return;
    }
  }

  /** @deprecated */
  public final void a(SimpleAccount paramSimpleAccount)
  {
    monitorenter;
    Object localObject1 = null;
    label308: EntityManagerFactory localEntityManagerFactory2;
    try
    {
      this.jdField_a_of_type_Int = localObject1;
      String str1;
      if (paramSimpleAccount != null)
      {
        this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount = paramSimpleAccount;
        str1 = paramSimpleAccount.getUin();
        if (factoryMap.containsKey(str1))
          break label308;
        Map localMap1 = factoryMap;
        QQEntityManagerFactory localQQEntityManagerFactory1 = new QQEntityManagerFactory(str1);
        localMap1.put(str1, localQQEntityManagerFactory1);
        StringBuilder localStringBuilder = new StringBuilder();
        String str2 = SDCARD_DATABASE;
        String str3 = str2 + str1;
        QQEntityManagerFactory localQQEntityManagerFactory2 = new QQEntityManagerFactory(str3);
        this.jdField_a_of_type_ComTencentMobileqqPersistenceEntityManagerFactory = localQQEntityManagerFactory2;
        Map localMap2 = factoryMap;
        String str4 = "sd" + str1;
        EntityManagerFactory localEntityManagerFactory1 = this.jdField_a_of_type_ComTencentMobileqqPersistenceEntityManagerFactory;
        localMap2.put(str4, localEntityManagerFactory1);
        a();
        String str5 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        int i = getSharedPreferences(str5, 0).getInt("getlastMessageTime", 0);
        String str6 = "set last message time" + i;
        QLog.d("wdc", str6);
        MessageCache.setLastGetMsgSeq(i);
        String str7 = this.jdField_a_of_type_JavaLangString;
        if (!str1.equals(str7))
        {
          this.jdField_a_of_type_JavaLangString = str1;
          this.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a();
        }
        this.jdField_a_of_type_ComTencentMobileqqAppMessageController.f();
        String str8 = "setCurrentAccount curUin" + str1;
        QLog.v("System.out", str1);
        hi localhi = new hi(this);
        new Thread(str1).start();
      }
      return;
      Map localMap3 = factoryMap;
      String str9 = "sd" + str1;
      localEntityManagerFactory2 = (EntityManagerFactory)localMap3.get(str9);
    }
    finally
    {
      monitorexit;
    }
  }

  public final void a(BaseActionListener paramBaseActionListener)
  {
    if (this.jdField_a_of_type_JavaUtilList.contains(paramBaseActionListener))
      return;
    this.jdField_a_of_type_JavaUtilList.add(paramBaseActionListener);
  }

  public final void a(Class paramClass)
  {
    this.jdField_a_of_type_JavaUtilMap.remove(paramClass);
  }

  public final void a(Class paramClass, Handler paramHandler)
  {
    this.jdField_a_of_type_JavaUtilMap.put(paramClass, paramHandler);
  }

  public final void a(Runnable paramRunnable)
  {
    this.jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor.execute(paramRunnable);
  }

  /** @deprecated */
  public final void a(String paramString)
  {
    Object localObject1 = 1;
    monitorenter;
    Object localObject2 = null;
    Object localObject3;
    try
    {
      localObject3 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper.getUserList();
      if (localObject3 != null)
      {
        localObject3 = (List)((FromServiceMsg)localObject3).getAttribute("baseSdk.auth.getAllSimpleUser");
        Iterator localIterator = ((List)localObject3).iterator();
        do
        {
          localObject3 = localIterator.hasNext();
          if (localObject3 == 0)
            break label229;
          localObject3 = (SimpleAccount)localIterator.next();
        }
        while (!((SimpleAccount)localObject3).getUin().equals(paramString));
        StringBuilder localStringBuilder = new StringBuilder().append("[enter] ");
        String str1 = ((SimpleAccount)localObject3).getUin();
        String str2 = str1;
        QLog.i("System.out", str2);
        a((SimpleAccount)localObject3);
        localObject3 = localObject1;
        if ((localObject3 != null) && (HomeActivity.instance != null))
        {
          Intent localIntent1 = new Intent("tencent.notify.activity.actived");
          localIntent1.putExtra("selfuin", paramString);
          sendBroadcast(localIntent1, "com.tencent.msg.permission.pushnotify");
        }
        if (localObject3 == null)
        {
          if (HomeActivity.instance != null)
          {
            HomeActivity.instance.finish();
            HomeActivity.instance = null;
          }
          Intent localIntent2 = new Intent(this, HomeActivity.class).putExtra("need login", true).addFlags(268435456);
          startActivity(localIntent2);
        }
        label229: return;
      }
    }
    catch (RemoteException localObject4)
    {
    }
    finally
    {
      Object localObject4;
      monitorexit;
    }
  }

  public final void a(String paramString1, String paramString2)
  {
    BaseServiceHelper localBaseServiceHelper1 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
    String str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    FriendListUtil.getTroopMemberList(localBaseServiceHelper1, str1, true, paramString1, paramString2);
    BaseServiceHelper localBaseServiceHelper2 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
    String str2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    FriendListUtil.getTroopRemarkList(localBaseServiceHelper2, str2, true, paramString1, paramString2);
  }

  public final void a(boolean paramBoolean)
  {
    int i = 0;
    int j = 0;
    this.jdField_a_of_type_ComTencentMobileqqUtilsTrafficData.a();
    Object localObject1 = new Intent("tencent.notify.activity.destroyed");
    String str = this.jdField_a_of_type_JavaLangString;
    ((Intent)localObject1).putExtra("selfuin", str);
    Object localObject3 = "com.tencent.msg.permission.pushnotify";
    sendBroadcast((Intent)localObject1, (String)localObject3);
    localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
    long l;
    if (localObject1 != null)
    {
      localObject1 = isNetSupport();
      if (localObject1 != 0)
      {
        localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
        localObject3 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        ProfileUtil.SvcReqRegister((BaseServiceHelper)localObject1, (String)localObject3, j);
        l = 500L;
      }
    }
    try
    {
      Thread.sleep(l);
      label107: localObject1 = this.jdField_a_of_type_JavaUtilList;
      ((List)localObject1).clear();
      if (paramBoolean)
      {
        localObject1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
        if (localObject1 != null)
        {
          this.jdField_a_of_type_ComTencentMobileqqAppMessageController.a();
          localObject3 = this.jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor;
          str = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
          this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount = i;
          suspend();
          boolean bool = this.jdField_c_of_type_Boolean;
          if (bool)
          {
            localObject2 = this.jdField_a_of_type_AndroidContentServiceConnection;
            unbindService((ServiceConnection)localObject2);
            localObject2 = new Intent("com.tencent.qq.video.VcController");
            stopService((Intent)localObject2);
            this.jdField_c_of_type_Boolean = j;
          }
          hp localhp = new hp(this);
          Object localObject2 = (ThreadPoolExecutor)Executors.newFixedThreadPool(3, localhp);
          this.jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor = ((ThreadPoolExecutor)localObject2);
          localObject2 = new hj(this, (ThreadPoolExecutor)localObject3, str);
          ((hj)localObject2).start();
          ConfigInfo.showMsfTip = localObject2;
          if ((localObject2 != 0) && (this.jdField_a_of_type_AndroidWidgetToast != null))
          {
            this.jdField_a_of_type_AndroidWidgetToast.cancel();
            this.jdField_a_of_type_AndroidWidgetToast = i;
          }
          return;
        }
      }
      int k = 1;
      this.jdField_a_of_type_Boolean = k;
    }
    catch (InterruptedException localInterruptedException)
    {
      break label107:
    }
  }

  public final int[] a(String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    long l1 = 1L;
    long l2 = 0L;
    Object localObject1 = 0;
    String str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
    SharedPreferences localSharedPreferences = getSharedPreferences(str1, localObject1);
    SharedPreferences.Editor localEditor = localSharedPreferences.edit();
    int[] arrayOfInt = new int[paramArrayOfString.length];
    int i = localObject1;
    label50: int j = paramArrayOfString.length;
    if (i < j)
    {
      Object localObject2 = new StringBuilder().append(str1);
      String str2 = paramArrayOfString[i];
      localObject2 = str2;
      long l3 = localSharedPreferences.getLong((String)localObject2, l1) < l2;
      label116: Object localObject3;
      long l4;
      if (localObject2 == 0)
      {
        int k = 1;
        arrayOfInt[i] = k;
        localObject3 = new StringBuilder().append(str1);
        str2 = paramArrayOfString[i];
        localObject3 = str2;
        int l = paramArrayOfInt[i];
        if (l != 0)
          break label194;
        l4 = l1;
      }
      while (true)
      {
        localEditor.putLong((String)localObject3, l4);
        ++i;
        break label50:
        localObject3 = localObject1;
        break label116:
        label194: l4 = l2;
      }
    }
    localEditor.commit();
    return (I)(I)(I)arrayOfInt;
  }

  public final String[] a()
  {
    String[] arrayOfString1 = 0;
    int i = 0;
    Object localObject1;
    Object localObject4;
    Object localObject5;
    Object localObject6;
    try
    {
      localObject1 = getContentResolver();
      localObject4 = FriendList.TROOP_LIST_URI;
      localObject5 = null;
      localObject6 = null;
      String[] arrayOfString2 = null;
      Object localObject7 = null;
      localObject1 = ((ContentResolver)localObject1).query((Uri)localObject4, localObject5, (String)localObject6, arrayOfString2, (String)localObject7);
      if (localObject1 != null)
      {
        localObject4 = ((Cursor)localObject1).getCount();
        if (localObject4 > 0)
        {
          localObject4 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
          localObject5 = getSharedPreferences((String)localObject4, 0);
          localObject6 = new String[((Cursor)localObject1).getCount()];
          ((Cursor)localObject1).moveToFirst();
          arrayOfString2 = arrayOfString1;
          do
          {
            localObject7 = ((Cursor)localObject1).getColumnIndex("troopuin");
            localObject7 = ((Cursor)localObject1).getString(localObject7);
            String str = (String)localObject4 + (String)localObject7;
            if (((SharedPreferences)localObject5).getLong(str, 0L) == 1L)
            {
              localObject6[arrayOfString2] = localObject7;
              ++arrayOfString2;
            }
            localObject7 = ((Cursor)localObject1).moveToNext();
          }
          while (localObject7 != 0);
          if (arrayOfString2 > 0)
          {
            localObject4 = new String[arrayOfString2];
            localObject5 = arrayOfString1;
            label197: label227: if (localObject5 >= arrayOfString2)
              break label227;
          }
        }
      }
    }
    catch (Exception localObject3)
    {
      try
      {
        Object localObject8 = localObject6[localObject5];
        localObject4[localObject5] = localObject8;
        ++localObject5;
        break label197:
        localObject4 = i;
        if (localObject1 != null)
          ((Cursor)localObject1).close();
        localObject1 = localObject4;
        return localObject1;
        localException1 = localException1;
        Object localObject2 = i;
      }
      catch (Exception localObject3)
      {
        Object localObject3 = localObject4;
      }
    }
  }

  public final int b()
  {
    long l1 = 1L;
    Object localObject1 = null;
    Object localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
    String str = ((SimpleAccount)localObject2).getUin();
    Object localObject6;
    Object localObject7;
    Object localObject8;
    try
    {
      localObject2 = getContentResolver();
      localObject6 = FriendList.TROOP_LIST_URI;
      localObject7 = null;
      localObject8 = null;
      localObject2 = ((ContentResolver)localObject2).query((Uri)localObject6, localObject7, (String)localObject8, null, null);
      localObject6 = ((Cursor)localObject2).getCount();
      if ((localObject2 != null) && (localObject6 > 0))
      {
        localObject6 = getSharedPreferences(str, 0);
        ((Cursor)localObject2).moveToFirst();
        label177: label193: localObject7 = localObject1;
      }
    }
    catch (Exception localObject5)
    {
      try
      {
        do
        {
          localObject8 = ((Cursor)localObject2).getColumnIndex("troopuin");
          localObject8 = ((Cursor)localObject2).getString(localObject8);
          localObject8 = str + (String)localObject8;
          long l2 = ((SharedPreferences)localObject6).getLong((String)localObject8, 1L) < l1;
          if (localObject8 == 0)
            ++localObject7;
          localObject8 = ((Cursor)localObject2).moveToNext();
        }
        while (localObject8 != 0);
        localObject6 = localObject7;
        if (localObject2 == null);
      }
      catch (Exception localObject5)
      {
        try
        {
          ((Cursor)localObject2).close();
          Object localObject3;
          for (localObject2 = localObject6; ; localObject3 = localObject1)
          {
            if (localObject2 == null)
              localObject2 = localObject1;
            while (true)
            {
              return localObject2;
              int i = 1;
            }
            localException1 = localException1;
          }
          localException2 = localException2;
          Object localObject4 = localObject7;
        }
        catch (Exception localObject5)
        {
          Object localObject5 = localObject6;
          break label193:
          localObject6 = localObject1;
          break label177:
        }
      }
    }
  }

  public final Drawable b(int paramInt, String paramString, boolean paramBoolean)
  {
    int i = 1;
    int j = 0;
    String str1 = paramString + paramBoolean;
    boolean bool = this.d.containsKey(str1);
    if (bool)
    {
      localObject1 = ((WeakReference)this.d.get(str1)).get();
      if (localObject1 == null);
    }
    for (Object localObject1 = (Drawable)((WeakReference)this.d.get(str1)).get(); ; localObject1 = getResources().getDrawable(2130838047))
    {
      label84: return localObject1;
      if (paramString == null)
        break label297;
      localObject1 = paramString.equals("10000");
      if (localObject1 == 0)
        break;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    String str2 = AppConstants.PATH_CUSTOM_HEAD;
    String str3 = str2 + paramString + ".png";
    localObject1 = new File(str3);
    Object localObject2;
    for (localObject1 = a((File)localObject1); ; localObject2 = j)
    {
      if (localObject1 == 0)
      {
        int k = paramInt / 3;
        if ((++k < 0) || (k >= 138))
          k = i;
        Resources localResources = getResources();
        k = k + 2130837749 - i;
        localObject2 = localResources.getDrawable(k);
      }
      localObject2 = ((BitmapDrawable)localObject2).getBitmap();
      if (paramBoolean)
        localObject2 = ImageUtil.grey((Bitmap)localObject2);
      BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject2);
      localObject2 = this.d;
      WeakReference localWeakReference = new WeakReference(localBitmapDrawable);
      ((HashMap)localObject2).put(str1, localWeakReference);
      localObject2 = localBitmapDrawable;
      label297: break label84:
    }
  }

  public final String b(String paramString)
  {
    int i = 0;
    boolean bool = this.jdField_a_of_type_JavaUtilHashMap.containsKey(paramString);
    if (bool);
    String str;
    for (Object localObject = (String)this.jdField_a_of_type_JavaUtilHashMap.get(paramString); ; localObject = str)
      while (true)
      {
        return localObject;
        EntityManager localEntityManager = a().createEntityManager();
        localObject = (TroopInfo)localEntityManager.a(TroopInfo.class, paramString);
        localEntityManager.a();
        if ((localObject == null) || (((TroopInfo)localObject).troopname == null))
          break;
        str = ((TroopInfo)localObject).troopname;
        if ((paramString != null) && (str != null))
          this.jdField_a_of_type_JavaUtilHashMap.put(paramString, str);
        localObject = ((TroopInfo)localObject).troopname;
      }
  }

  public final void b()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqAppMessageController == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppMessageController.c();
  }

  public final void b(BaseActionListener paramBaseActionListener)
  {
    this.jdField_a_of_type_JavaUtilList.remove(paramBaseActionListener);
  }

  public final void b(String paramString)
  {
    if (this.jdField_c_of_type_JavaUtilHashMap.containsKey(paramString))
      this.jdField_c_of_type_JavaUtilHashMap.remove(paramString);
    if (!this.d.containsKey(paramString))
      return;
    this.d.remove(paramString);
  }

  public final void b(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString2 == null))
      return;
    this.jdField_a_of_type_JavaUtilHashMap.put(paramString1, paramString2);
  }

  public final String c(String paramString)
  {
    int i = 0;
    boolean bool = this.jdField_b_of_type_JavaUtilHashMap.containsKey(paramString);
    if (bool);
    String str;
    for (Object localObject = (String)this.jdField_b_of_type_JavaUtilHashMap.get(paramString); ; localObject = str)
      while (true)
      {
        return localObject;
        EntityManager localEntityManager = a().createEntityManager();
        localObject = (TroopInfo)localEntityManager.a(TroopInfo.class, paramString);
        localEntityManager.a();
        if ((localObject == null) || (((TroopInfo)localObject).troopmemo == null))
          break;
        str = ((TroopInfo)localObject).troopmemo;
        if ((paramString != null) && (str != null))
          this.jdField_b_of_type_JavaUtilHashMap.put(paramString, str);
        localObject = ((TroopInfo)localObject).troopmemo;
      }
  }

  public final void c()
  {
    Context localContext = this.jdField_a_of_type_AndroidContentContext;
    a(localContext);
  }

  public final void c(String paramString)
  {
    int i;
    ConfigInfo.showMsfTip = i;
    if (i == 0)
      label8: return;
    if (this.jdField_a_of_type_AndroidWidgetToast == null)
    {
      Toast localToast = Toast.makeText(this, paramString, 0);
      this.jdField_a_of_type_AndroidWidgetToast = localToast;
    }
    while (true)
    {
      this.jdField_a_of_type_AndroidWidgetToast.show();
      break label8:
      this.jdField_a_of_type_AndroidWidgetToast.setText(paramString);
    }
  }

  public final void c(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString2 == null))
      return;
    this.jdField_b_of_type_JavaUtilHashMap.put(paramString1, paramString2);
  }

  public final void d()
  {
    try
    {
      ((NotificationManager)getSystemService("notification")).cancel(2130837895);
      this.jdField_a_of_type_Boolean = null;
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public final void e()
  {
    Boolean localBoolean = Boolean.valueOf(true);
    a(localBoolean);
  }

  public final void f()
  {
    Object localObject = getContentResolver();
    Uri localUri = FriendList.GROUP_LIST_CONTENT_URI;
    String str1 = null;
    String[] arrayOfString = null;
    String str2 = null;
    localObject = ((ContentResolver)localObject).query(localUri, null, str1, arrayOfString, str2);
    if (localObject == null);
    while (true)
    {
      return;
      if (((Cursor)localObject).getCount() == 0)
      {
        String str3 = "first loading groupCursor: " + localObject;
        QLog.v("push", str3);
        ((Cursor)localObject).close();
      }
      ((Cursor)localObject).close();
      QLog.v("push", "get logined offline message");
      this.jdField_a_of_type_ComTencentMobileqqAppMessageController.b();
      this.jdField_a_of_type_ComTencentMobileqqAppMessageController.d();
      this.jdField_a_of_type_ComTencentMobileqqAppMessageController.c();
    }
  }

  public final void g()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqAppMessageController == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppMessageController.a(10000L);
  }

  public int getAppid()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqVideoVideoController == null)
    {
      VideoController localVideoController = new VideoController(this);
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = localVideoController;
    }
    if ((this.jdField_a_of_type_ComTencentMobileqqVideoVideoController == null) || (!VideoController.bDeviceSupport()))
      AppSetting.APP_ID = AppSetting.APP_ID2;
    return AppSetting.APP_ID;
  }

  /** @deprecated */
  public ExecutorService getCallbackerThreadPool()
  {
    monitorenter;
    try
    {
      ThreadPoolExecutor localThreadPoolExecutor = this.jdField_a_of_type_JavaUtilConcurrentThreadPoolExecutor;
      monitorexit;
      return localThreadPoolExecutor;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  public HelperCallbacker getHelpCallbacker()
  {
    return this.jdField_a_of_type_ComTencentQphoneBaseUtilHelperCallbacker;
  }

  public ArrayList needInitSubServie()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add("mobileqq.service");
    return localArrayList;
  }

  public void onCreate()
  {
    int i = 1;
    super.onCreate();
    QLog.i("System.out", "QQApplication oncreate");
    int j = QLog.isLogToFile;
    StringBuilder localStringBuilder = new StringBuilder().append("QQApp Service DoBind ");
    VcController localVcController = mBoundService;
    String str = localVcController;
    QLog.i("LocalService", str);
    Object localObject1 = new Intent("com.tencent.qq.video.VcController");
    startService((Intent)localObject1);
    localObject1 = new Intent("com.tencent.qq.video.VcController");
    ServiceConnection localServiceConnection = this.jdField_a_of_type_AndroidContentServiceConnection;
    bindService((Intent)localObject1, localServiceConnection, i);
    this.jdField_c_of_type_Boolean = i;
    localObject1 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
    if (localObject1 == null)
    {
      localObject1 = new VideoController(this);
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = ((VideoController)localObject1);
    }
    localObject1 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
    if (localObject1 != null)
    {
      localObject1 = VideoController.bDeviceSupport();
      if (localObject1 == 0)
      {
        k = AppSetting.APP_ID2;
        AppSetting.APP_ID = k;
      }
    }
    int k = AppSetting.APP_ID;
    BaseActionListener localBaseActionListener1 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    BaseServiceHelper localBaseServiceHelper = BaseServiceHelper.getBaseServiceHelper(k, localBaseActionListener1);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper = localBaseServiceHelper;
    int l = AppSetting.APP_ID;
    BaseActionListener localBaseActionListener2 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    Object localObject2 = PushHelper.getBaseServiceHelper(l, localBaseActionListener2);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper = ((PushHelper)localObject2);
    localObject2 = new Vector();
    this.jdField_a_of_type_JavaUtilList = ((List)localObject2);
    localObject2 = MediaPlayer.create(getApplicationContext(), 2131099649);
    this.jdField_a_of_type_AndroidMediaMediaPlayer = ((MediaPlayer)localObject2);
    localObject2 = this.jdField_a_of_type_AndroidMediaMediaPlayer;
    if (localObject2 != null)
    {
      localObject2 = this.jdField_a_of_type_AndroidMediaMediaPlayer;
      hk localhk = new hk(this);
      ((MediaPlayer)localObject2).setOnCompletionListener(localhk);
      localObject2 = this.jdField_a_of_type_AndroidMediaMediaPlayer;
      hl localhl = new hl(this);
      ((MediaPlayer)localObject2).setOnErrorListener(localhl);
    }
    localObject2 = new MessageController(this);
    this.jdField_a_of_type_ComTencentMobileqqAppMessageController = ((MessageController)localObject2);
    localObject2 = new TransFileController(this);
    this.jdField_a_of_type_ComTencentMobileqqTransfileTransFileController = ((TransFileController)localObject2);
    localObject2 = getSharedPreferences("mobileQQ", j).getString("currentAccount", null);
    if (localObject2 != null)
      a((String)localObject2);
    setSyncServiceName("mobileqq.service");
    AccountSyncHelper.registerAccountSyncReceiver();
    Intent[] arrayOfIntent1 = this.jdField_a_of_type_ArrayOfAndroidContentIntent;
    Intent localIntent1 = new Intent(this, ContactActivity.class);
    arrayOfIntent1[j] = localIntent1;
    Intent[] arrayOfIntent2 = this.jdField_a_of_type_ArrayOfAndroidContentIntent;
    Intent localIntent2 = new Intent(this, ChatWindowActivity.class).setFlags(536870912);
    arrayOfIntent2[i] = localIntent2;
    NativeGipsVoiceEngine.NativeInit(this);
  }

  public void onTerminate()
  {
    super.onTerminate();
    NativeGipsVoiceEngine.NativeTerminate();
    QLog.i("System.out", "QQApplication onTerminate");
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.QQApplication
 * JD-Core Version:    0.5.4
 */