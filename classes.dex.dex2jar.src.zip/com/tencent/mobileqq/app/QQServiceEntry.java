package com.tencent.mobileqq.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.activity.InfoActivity;
import com.tencent.mobileqq.service.message.MessageUtil;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.QLog;
import hq;
import hr;
import hs;
import java.util.List;

public class QQServiceEntry
  implements View.OnClickListener, AdapterView.OnItemClickListener
{
  public static final int SERVICE_ALL = 13;
  public static final int SERVICE_INFO = 1;
  public static final int SERVICE_MAIL = 8;
  public static final int SERVICE_MICRO_BLOG = 16;
  public static final int SERVICE_QZONE = 4;
  public static final int SERVICE_STATUS = 128;
  public static final int SERVICE_TROOP_RECEIVE = 32;
  public static final int SERVICE_TROOP_SHIELD = 64;
  private static final hr[] services;
  public float a;
  private int jdField_a_of_type_Int;
  public Context a;
  private QQServiceEntry.Tag jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
  private List jdField_a_of_type_JavaUtilList;
  private boolean jdField_a_of_type_Boolean;
  private int b;
  private int c;

  static
  {
    hr[] arrayOfhr1 = new hr[6];
    services = arrayOfhr1;
    hr localhr1 = new hr();
    arrayOfhr1[0] = localhr1;
    services[null].jdField_a_of_type_Int = 128;
    services[null].b = 2130837959;
    hr[] arrayOfhr2 = services;
    hr localhr2 = new hr();
    arrayOfhr2[1] = localhr2;
    services[1].jdField_a_of_type_Int = 1;
    services[1].b = 2130837961;
    services[1].jdField_a_of_type_JavaLangString = "璧";
    hr[] arrayOfhr3 = services;
    hr localhr3 = new hr();
    arrayOfhr3[2] = localhr3;
    services[2].jdField_a_of_type_Int = 4;
    services[2].b = 2130837963;
    services[2].jdField_a_of_type_JavaLangString = "绌";
    hr[] arrayOfhr4 = services;
    hr localhr4 = new hr();
    arrayOfhr4[3] = localhr4;
    services[3].jdField_a_of_type_Int = 8;
    services[3].b = 2130837962;
    services[3].jdField_a_of_type_JavaLangString = "閭";
    hr[] arrayOfhr5 = services;
    hr localhr5 = new hr();
    arrayOfhr5[4] = localhr5;
    services[4].jdField_a_of_type_Int = 32;
    services[4].b = 2130837964;
    services[4].jdField_a_of_type_JavaLangString = "缇�";
    hr[] arrayOfhr6 = services;
    hr localhr6 = new hr();
    arrayOfhr6[5] = localhr6;
    services[5].jdField_a_of_type_Int = 64;
    services[5].b = 2130837965;
    services[5].jdField_a_of_type_JavaLangString = "缇�";
  }

  public QQServiceEntry(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    int i = this.jdField_a_of_type_AndroidContentContext.getResources().getDisplayMetrics().density;
    this.jdField_a_of_type_Float = i;
  }

  public final QQServiceEntry.Tag a()
  {
    return this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
  }

  public final void a()
  {
    this.jdField_a_of_type_Boolean = true;
  }

  public final void b()
  {
    if ((this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag == null) || (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView == null))
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setVisibility(8);
  }

  public void onClick(View paramView)
  {
    int i = 8;
    int j = 0;
    QQServiceEntry.Tag localTag1 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
    Object localObject = paramView.getTag();
    if ((localTag1 == localObject) && (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.getVisibility() == 0))
      if (!this.jdField_a_of_type_Boolean)
        this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setVisibility(i);
    while (true)
    {
      return;
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag != null)
        this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setVisibility(i);
      QQServiceEntry.Tag localTag2 = (QQServiceEntry.Tag)paramView.getTag();
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag = localTag2;
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString.equals("10000"))
        continue;
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setFocusable(j);
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setFocusableInTouchMode(j);
      int k = this.jdField_a_of_type_Float;
      int l = (int)(1112539136 * k);
      this.jdField_a_of_type_Int = l;
      int i1 = this.jdField_a_of_type_Float;
      int i2 = (int)(1108869120 * i1);
      this.b = i2;
      int i3 = this.jdField_a_of_type_Float;
      int i4 = (int)(1084227584 * i3);
      this.c = i4;
      GridView localGridView1 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView;
      int i5 = this.jdField_a_of_type_Int;
      localGridView1.setColumnWidth(i5);
      GridView localGridView2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView;
      int i6 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.b;
      hs localhs = new hs(this, i6);
      localGridView2.setAdapter(localhs);
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setOnItemClickListener(this);
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.setVisibility(j);
      hq localhq = new hq(this);
      paramView.post(localhq);
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i = 1003;
    int j = null;
    int k = 1;
    Object localObject1 = new StringBuilder().append("you click ");
    String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
    localObject1 = str1;
    QLog.i("System.out", (String)localObject1);
    int i1 = 0;
    Object localObject4 = (QQApplication)this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.getContext().getApplicationContext();
    int l = ((hr)this.jdField_a_of_type_JavaUtilList.get(paramInt)).jdField_a_of_type_Int;
    label144: label148: Object localObject2;
    Object localObject3;
    switch (l)
    {
    default:
    case 1:
    case 4:
      for (localObject4 = i1; ; localObject4 = new Intent("android.intent.action.VIEW", (Uri)localObject4))
      {
        if (localObject4 != 0)
          this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.getContext().startActivity((Intent)localObject4);
        while (true)
        {
          return;
          Context localContext = paramView.getContext();
          localObject4 = new Intent(localContext, InfoActivity.class);
          int i2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_Int;
          localObject4 = ((Intent)localObject4).putExtra("infowhose", i2);
          String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
          localObject4 = ((Intent)localObject4).putExtra("infouin", str2);
          if (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_Int == k)
          {
            String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
            ((Intent)localObject4).putExtra("infouin", str3);
          }
          if (this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_Int == 0)
            ((Activity)this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.getContext()).startActivityForResult((Intent)localObject4, 100);
          this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_AndroidWidgetGridView.getContext().startActivity((Intent)localObject4);
        }
        StringBuilder localStringBuilder1 = new StringBuilder().append("http://z.qq.com/blog.jsp?B_UID=");
        String str4 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str4).append("&sid=");
        localObject4 = ((QQApplication)localObject4).a().getSid();
        localObject4 = Uri.parse((String)localObject4);
      }
    case 8:
      localObject2 = new StringBuilder().append("http://fwd.z.qq.com:8080/forward.jsp?bid=255&g_f=5471&3g_sid=");
      localObject3 = ((QQApplication)localObject4).a().getSid();
      localObject2 = (String)localObject3;
      localObject3 = new StringBuilder().append("&sb=1&to=");
      String str5 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      localObject3 = str5 + "@qq.com";
      localObject4 = ((QQApplication)localObject4).a().getUin();
      String str6 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      localObject4 = ((String)localObject4).equals(str6);
      if (localObject4 == 0)
        break label934;
    case 32:
    case 64:
    }
    for (localObject4 = ""; ; localObject4 = localObject3)
    {
      localObject4 = Uri.parse((String)localObject2 + (String)localObject4);
      localObject4 = new Intent("android.intent.action.VIEW", (Uri)localObject4);
      break label148:
      String str7 = ((QQApplication)localObject4).a().getUin();
      SharedPreferences.Editor localEditor1 = this.jdField_a_of_type_AndroidContentContext.getSharedPreferences(str7, j).edit();
      StringBuilder localStringBuilder3 = new StringBuilder().append(str7);
      String str8 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      String str9 = str8;
      localEditor1.putLong(str9, 1L);
      BaseServiceHelper localBaseServiceHelper1 = ((QQApplication)localObject4).a();
      BaseActionListener localBaseActionListener1 = ((QQApplication)localObject4).a();
      String str10 = ((QQApplication)localObject4).a().getUin();
      String str11 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      MessageUtil.setGroupFilter(localBaseServiceHelper1, localBaseActionListener1, str10, str11, j);
      localEditor1.commit();
      this.jdField_a_of_type_JavaUtilList.remove(k);
      List localList1 = this.jdField_a_of_type_JavaUtilList;
      hr localhr1 = services[4];
      localList1.add(localhr1);
      localObject4 = ((QQApplication)localObject4).a(ContactActivity.class);
      if (localObject4 != null);
      ((Handler)localObject4).sendEmptyMessage(i);
      localObject4 = localObject3;
      break label148:
      String str12 = ((QQApplication)localObject4).a().getUin();
      SharedPreferences.Editor localEditor2 = this.jdField_a_of_type_AndroidContentContext.getSharedPreferences(str12, j).edit();
      StringBuilder localStringBuilder4 = new StringBuilder().append(str12);
      String str13 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      String str14 = str13;
      localEditor2.putLong(str14, 0L);
      BaseServiceHelper localBaseServiceHelper2 = ((QQApplication)localObject4).a();
      BaseActionListener localBaseActionListener2 = ((QQApplication)localObject4).a();
      String str15 = ((QQApplication)localObject4).a().getUin();
      String str16 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString;
      MessageUtil.setGroupFilter(localBaseServiceHelper2, localBaseActionListener2, str15, str16, k);
      localEditor2.commit();
      this.jdField_a_of_type_JavaUtilList.remove(k);
      List localList2 = this.jdField_a_of_type_JavaUtilList;
      hr localhr2 = services[3];
      localList2.add(localhr2);
      localObject4 = ((QQApplication)localObject4).a(ContactActivity.class);
      if (localObject4 != null);
      ((Handler)localObject4).sendEmptyMessage(i);
      label934: break label144:
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.QQServiceEntry
 * JD-Core Version:    0.5.4
 */