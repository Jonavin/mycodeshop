package com.tencent.mobileqq.app;

public abstract interface AppConstants$Preferences
{
  public static final String CURRENT_ACCOUNT = "currentAccount";
  public static final String FIRST_TIME_RUN = "firstTimeRun";
  public static final String GET_LAST_MESSAGE_TIME = "getlastMessageTime";
  public static final String GET_PROFILE_STATUS = "getProfileStatus";
  public static final String GET_SIGNATURE_TIME = "getSignatureTime";
  public static final String LOGIN_AUTO = "login_auto";
  public static final String LOGIN_RECEIVE = "login_receive";
  public static final String LOGIN_SILENCE = "login_silence";
  public static final String QQ_VERSION = "qq_version";
  public static final String RECEIVE_ALL_TROOPSNEWS = "receiveAllTroopsnews";
  public static final String SHOW_DIALOG_WHEN_EXIT = "showDialogExit";
  public static final String TRAFFIC_DATA = "TrafficData";
  public static final String TROOP_NICK = "troopNick";
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppConstants.Preferences
 * JD-Core Version:    0.5.4
 */