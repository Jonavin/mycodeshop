package com.tencent.mobileqq.app;

import PushNotifyPack.RequestPushGroupMsg;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.qq.jce.wup.UniPacket;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.activity.HomeActivity;
import com.tencent.mobileqq.service.friendlist.storage.StorageUnreadMsgFriendInfo;
import com.tencent.mobileqq.service.message.MessageCache;
import com.tencent.mobileqq.service.message.MessageUtil;
import com.tencent.mobileqq.service.message.remote.MessageRecordInfo;
import com.tencent.mobileqq.service.message.storage.StoreRecentUser;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.sync.AccountSyncHelper;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import hf;
import java.util.Iterator;
import java.util.List;

public class PushBroadcastReceiver extends BroadcastReceiver
{
  Handler jdField_a_of_type_AndroidOsHandler;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;

  public PushBroadcastReceiver()
  {
    hf localhf = new hf(this);
    this.jdField_a_of_type_AndroidOsHandler = localhf;
  }

  /** @deprecated */
  // ERROR //
  private long a(String paramString, RequestPushGroupMsg paramRequestPushGroupMsg)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: new 23	java/util/ArrayList
    //   7: dup
    //   8: invokespecial 24	java/util/ArrayList:<init>	()V
    //   11: astore 4
    //   13: aload_2
    //   14: getfield 29	PushNotifyPack/RequestPushGroupMsg:jdField_a_of_type_ArrayOfByte	[B
    //   17: arraylength
    //   18: istore 5
    //   20: iload_3
    //   21: iload 5
    //   23: if_icmpeq +207 -> 230
    //   26: new 31	com/tencent/mobileqq/service/message/storage/StorageMessage
    //   29: dup
    //   30: invokespecial 32	com/tencent/mobileqq/service/message/storage/StorageMessage:<init>	()V
    //   33: astore 5
    //   35: aload 5
    //   37: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   40: aload_1
    //   41: putfield 40	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   44: aload 5
    //   46: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   49: astore 6
    //   51: aload_2
    //   52: getfield 44	PushNotifyPack/RequestPushGroupMsg:jdField_b_of_type_Long	J
    //   55: invokestatic 50	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   58: astore 7
    //   60: aload 6
    //   62: aload 7
    //   64: putfield 52	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_b_of_type_JavaLangString	Ljava/lang/String;
    //   67: aload 5
    //   69: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   72: astore 8
    //   74: aload_2
    //   75: getfield 55	PushNotifyPack/RequestPushGroupMsg:c	J
    //   78: invokestatic 50	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   81: astore 9
    //   83: aload 8
    //   85: aload 9
    //   87: putfield 57	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_c_of_type_JavaLangString	Ljava/lang/String;
    //   90: aload 5
    //   92: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   95: astore 10
    //   97: aload_2
    //   98: getfield 60	PushNotifyPack/RequestPushGroupMsg:jdField_a_of_type_Int	I
    //   101: istore 11
    //   103: aload 10
    //   105: iload 11
    //   107: putfield 61	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_a_of_type_Int	I
    //   110: aload 5
    //   112: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   115: astore 12
    //   117: aload_2
    //   118: getfield 64	PushNotifyPack/RequestPushGroupMsg:jdField_b_of_type_Byte	B
    //   121: i2s
    //   122: istore 13
    //   124: aload 12
    //   126: iload 13
    //   128: putfield 67	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_a_of_type_Short	S
    //   131: aload 5
    //   133: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   136: aconst_null
    //   137: putfield 70	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_a_of_type_Boolean	Z
    //   140: aload 5
    //   142: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   145: aconst_null
    //   146: putfield 72	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_b_of_type_Boolean	Z
    //   149: aload 5
    //   151: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   154: astore 14
    //   156: aload_2
    //   157: getfield 60	PushNotifyPack/RequestPushGroupMsg:jdField_a_of_type_Int	I
    //   160: istore 15
    //   162: aload 14
    //   164: iload 15
    //   166: invokevirtual 75	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:a	(I)V
    //   169: aload 5
    //   171: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   174: astore 16
    //   176: aload_2
    //   177: getfield 78	PushNotifyPack/RequestPushGroupMsg:d	J
    //   180: l2i
    //   181: istore 17
    //   183: aload 16
    //   185: iload 17
    //   187: invokevirtual 80	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:b	(I)V
    //   190: aload 5
    //   192: getfield 35	com/tencent/mobileqq/service/message/storage/StorageMessage:a	Lcom/tencent/mobileqq/service/message/remote/MessageRecordInfo;
    //   195: iconst_1
    //   196: putfield 82	com/tencent/mobileqq/service/message/remote/MessageRecordInfo:jdField_c_of_type_Boolean	Z
    //   199: aload_2
    //   200: getfield 29	PushNotifyPack/RequestPushGroupMsg:jdField_a_of_type_ArrayOfByte	[B
    //   203: aload 5
    //   205: iload_3
    //   206: invokestatic 88	com/tencent/mobileqq/grouptransfile/GroupPicProcessor:transTroopPhotoToMsg	([BLcom/tencent/mobileqq/service/message/storage/StorageMessage;I)I
    //   209: astore_3
    //   210: aload 4
    //   212: aload 5
    //   214: invokeinterface 94 2 0
    //   219: pop
    //   220: goto -207 -> 13
    //   223: astore 18
    //   225: aload_0
    //   226: monitorexit
    //   227: aload 18
    //   229: athrow
    //   230: aload_1
    //   231: invokestatic 100	com/tencent/mobileqq/service/storageutil/StorageManager:instance	(Ljava/lang/String;)Lcom/tencent/mobileqq/service/storageutil/StorageManager;
    //   234: aload 4
    //   236: invokevirtual 103	com/tencent/mobileqq/service/storageutil/StorageManager:a	(Ljava/util/List;)J
    //   239: astore 4
    //   241: aload_0
    //   242: monitorexit
    //   243: lload 19
    //   245: lreturn
    //   246: astore 21
    //   248: goto -38 -> 210
    //
    // Exception table:
    //   from	to	target	type
    //   4	199	223	finally
    //   199	210	223	finally
    //   210	220	223	finally
    //   230	241	223	finally
    //   199	210	246	java/lang/Exception
  }

  private void a(Intent paramIntent)
  {
    Object localObject1 = null;
    Object localObject2 = 1;
    String str1 = paramIntent.getExtras().getString("selfuin");
    Object localObject3 = paramIntent.getAction();
    String str2 = "tencent.notify.friend.message";
    localObject3 = ((String)localObject3).equals(str2);
    if (localObject3 != 0)
    {
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.resume();
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      MessageUtil.getMessage(localBaseServiceHelper, localBaseActionListener, str1);
    }
    do
    {
      label73: return;
      localObject3 = paramIntent.getAction();
      str2 = "tencent.notify.troop.message";
      localObject3 = ((String)localObject3).equals(str2);
    }
    while (localObject3 == 0);
    localObject3 = ((FromServiceMsg)paramIntent.getExtras().getParcelable("FromServiceMsg")).getWupBuffer();
    str2 = "req_PushGroupMsg";
    RequestPushGroupMsg localRequestPushGroupMsg = decodeGroupPushPacket(localObject3, str2);
    Object localObject5;
    Object localObject4;
    if (localRequestPushGroupMsg != null)
    {
      localObject3 = String.valueOf(localRequestPushGroupMsg.jdField_a_of_type_Long);
      a((String)localObject3, localRequestPushGroupMsg);
      localObject3 = String.valueOf(localRequestPushGroupMsg.jdField_a_of_type_Long);
      str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      localObject3 = ((String)localObject3).equals(str2);
      if (localObject3 != 0)
      {
        localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a;
        if (localObject3 != null)
        {
          localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a;
          str2 = String.valueOf(localRequestPushGroupMsg.jdField_b_of_type_Long);
          long l1 = localRequestPushGroupMsg.d;
          ((MessageCache)localObject3).a(str2, l1);
        }
      }
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      localObject3 = str1.equals(localObject3);
      if (localObject3 != 0)
      {
        localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        str2 = String.valueOf(localRequestPushGroupMsg.jdField_b_of_type_Long);
        localObject5 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        String str3 = String.valueOf(localRequestPushGroupMsg.jdField_b_of_type_Long);
        localObject5 = ((QQApplication)localObject5).a(localObject2, str3, localObject2);
        ((QQApplication)localObject3).a(localObject2, str2, ++localObject5);
        localObject3 = new MessageRecordInfo();
        ((MessageRecordInfo)localObject3).jdField_a_of_type_JavaLangString = str1;
        str2 = String.valueOf(localRequestPushGroupMsg.jdField_b_of_type_Long);
        ((MessageRecordInfo)localObject3).jdField_b_of_type_JavaLangString = str2;
        str2 = String.valueOf(localRequestPushGroupMsg.c);
        ((MessageRecordInfo)localObject3).jdField_c_of_type_JavaLangString = str2;
        int i = localRequestPushGroupMsg.jdField_a_of_type_Int;
        ((MessageRecordInfo)localObject3).jdField_a_of_type_Int = i;
        i = (short)localRequestPushGroupMsg.jdField_b_of_type_Byte;
        ((MessageRecordInfo)localObject3).jdField_a_of_type_Short = i;
        ((MessageRecordInfo)localObject3).jdField_a_of_type_Boolean = localObject1;
        ((MessageRecordInfo)localObject3).jdField_b_of_type_Boolean = localObject1;
        ((MessageRecordInfo)localObject3).jdField_c_of_type_Boolean = localObject2;
        localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils;
        localObject5 = String.valueOf(localRequestPushGroupMsg.jdField_b_of_type_Long);
        byte[] arrayOfByte = localRequestPushGroupMsg.jdField_a_of_type_ArrayOfByte;
        ((CacheUtils)localObject4).a((String)localObject5, localObject2, (MessageRecordInfo)localObject3, arrayOfByte);
      }
      localObject3 = new Intent("tencent.notify.troop.message.received");
      localObject5 = String.valueOf(localRequestPushGroupMsg.jdField_a_of_type_Long);
      ((Intent)localObject3).putExtra("selfuin", (String)localObject5);
      localObject5 = String.valueOf(localRequestPushGroupMsg.c);
      ((Intent)localObject3).putExtra("uin", (String)localObject5);
      localObject5 = StorageUnreadMsgFriendInfo.getUnreadMessage(localRequestPushGroupMsg.jdField_a_of_type_ArrayOfByte, localObject2);
      ((Intent)localObject3).putExtra("msg", (String)localObject5);
      localObject4 = "notified";
      localObject5 = HomeActivity.instance;
      if (localObject5 == null)
        break label715;
      localObject5 = localObject2;
    }
    while (true)
    {
      ((Intent)localObject3).putExtra((String)localObject4, localObject5);
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.sendBroadcast((Intent)localObject3, "com.tencent.msg.permission.pushnotify");
      Context localContext = QQApplication.getContext();
      localObject3 = new StoreRecentUser((Context)localObject4);
      long l2 = localRequestPushGroupMsg.jdField_b_of_type_Long;
      int j = localRequestPushGroupMsg.jdField_a_of_type_Int;
      ((StoreRecentUser)localObject3).a(str1, localObject4, localObject2, localRequestPushGroupMsg);
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      if (localObject3 != null);
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin().equals(str1);
      if (localObject3 != 0);
      MessageController.receivedMsgNotification(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication);
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(ChatWindowActivity.class);
      if (localObject3 != null)
      {
        Message localMessage = ((Handler)localObject3).obtainMessage(localObject2);
        ((Handler)localObject3).sendMessage(localMessage);
      }
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(ContactActivity.class);
      if (localObject3 != null);
      ((Handler)localObject3).sendEmptyMessageDelayed(1003, 500L);
      break label73:
      label715: localObject5 = localObject1;
    }
  }

  private boolean a(String paramString)
  {
    int i = 1;
    try
    {
      Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUserList();
      Object localObject1;
      if (localObject2 != null)
      {
        Object localObject3 = "baseSdk.auth.getAllSimpleUser";
        localObject2 = ((List)((FromServiceMsg)localObject2).getAttribute((String)localObject3)).iterator();
        do
        {
          localObject3 = ((Iterator)localObject2).hasNext();
          if (localObject3 != 0)
            localObject3 = ((SimpleAccount)((Iterator)localObject2).next()).getUin().equals(paramString);
        }
        while (localObject3 == 0);
        localObject1 = null;
      }
      return localObject1;
    }
    catch (Exception localException)
    {
    }
  }

  private static RequestPushGroupMsg decodeGroupPushPacket(byte[] paramArrayOfByte, String paramString)
  {
    int i = 0;
    Object localObject1;
    if (paramArrayOfByte == null)
      localObject1 = i;
    while (true)
    {
      return localObject1;
      localObject1 = new UniPacket();
      try
      {
        ((UniPacket)localObject1).setEncodeName("utf-8");
        ((UniPacket)localObject1).decode(paramArrayOfByte);
        localObject1 = (RequestPushGroupMsg)((UniPacket)localObject1).get(paramString);
      }
      catch (RuntimeException localObject2)
      {
        Object localObject2 = i;
      }
      catch (Exception localObject3)
      {
        Object localObject3 = i;
      }
    }
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Object localObject = (QQApplication)paramContext.getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = ((QQApplication)localObject);
    localObject = paramIntent.getExtras().getString("selfuin");
    String str = paramIntent.getExtras().getString("AccountInfoSync");
    if (a((String)localObject))
    {
      Message localMessage = Message.obtain(this.jdField_a_of_type_AndroidOsHandler, 0, paramIntent);
      QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
      localQQApplication.a(localHandler, localMessage);
    }
    try
    {
      AccountSyncHelper.sendSyncAccountReq(str, (String)localObject);
      return;
      a(paramIntent);
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.PushBroadcastReceiver
 * JD-Core Version:    0.5.4
 */