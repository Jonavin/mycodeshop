package com.tencent.mobileqq.app;

public abstract interface ScreenShotDisableListener
{
  public abstract void a();
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.ScreenShotDisableListener
 * JD-Core Version:    0.5.4
 */