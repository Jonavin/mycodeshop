package com.tencent.mobileqq.app;

public abstract interface AppConstants$Key
{
  public static final String FORCE_LOGIN = "need login";
  public static final String UIN = "uin";
  public static final String UIN_TYPE = "uin type";
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppConstants.Key
 * JD-Core Version:    0.5.4
 */