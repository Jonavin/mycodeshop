package com.tencent.mobileqq.app;

public abstract interface AppConstants$VALUE
{
  public static final int UIN_TYPE_FRIEND = 0;
  public static final int UIN_TYPE_FRIENDGROUP = 2;
  public static final int UIN_TYPE_TROOP = 1;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppConstants.VALUE
 * JD-Core Version:    0.5.4
 */