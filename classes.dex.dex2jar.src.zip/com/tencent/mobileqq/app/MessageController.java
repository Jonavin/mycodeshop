package com.tencent.mobileqq.app;

import Z;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import com.tencent.mobileqq.content.FriendList;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;
import com.tencent.mobileqq.service.message.MessageCache;
import com.tencent.mobileqq.service.message.MessageUtil;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.PushHelper;
import com.tencent.qphone.base.util.QLog;
import hc;
import hd;
import he;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MessageController
{
  private static String ACTION_GET_MESSAGE;
  private static String ACTION_KEEP_PUSH;
  private static final int RETRYTIMECOUNT = 3000;
  static final long[] VIBRATOR_PATTERN;
  public static boolean isRegPushSuccess;
  public static boolean isRegTroopPushSuccess;
  static boolean msgGetting;
  static boolean msgNew;
  private int jdField_a_of_type_Int;
  private long jdField_a_of_type_Long;
  private BroadcastReceiver jdField_a_of_type_AndroidContentBroadcastReceiver;
  public QQApplication a;
  private Timer jdField_a_of_type_JavaUtilTimer;
  int[] jdField_a_of_type_ArrayOfInt;
  private int jdField_b_of_type_Int;
  private Timer jdField_b_of_type_JavaUtilTimer;

  static
  {
    int tmp1_0 = 4;
    tmp1_0[0] = 100L;
    int tmp7_1 = tmp1_0;
    tmp7_1[1] = 200L;
    int tmp13_7 = tmp7_1;
    tmp13_7[2] = 200L;
    int tmp19_13 = tmp13_7;
    tmp19_13[3] = 100L;
    VIBRATOR_PATTERN = tmp19_13;
    ACTION_GET_MESSAGE = "com.tencent.mobile.action.GetMessage";
    ACTION_KEEP_PUSH = "com.tencent.mobile.action.KeepPush";
  }

  public MessageController(QQApplication paramQQApplication)
  {
    int[] arrayOfInt = new int[null];
    this.jdField_a_of_type_ArrayOfInt = arrayOfInt;
    com.tencent.qphone.base.BaseConstants.waitDataIntervTime = 65535L;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = paramQQApplication;
  }

  private void a(String paramString)
  {
    if (paramString == null)
      return;
    int i = paramString.length();
    if (i <= 0)
      return;
    String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(paramString);
    if (str == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(paramString, str);
  }

  private void a(String paramString, long paramLong)
  {
    Intent localIntent = new Intent(paramString);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(QQApplication.getContext(), 0, localIntent, 0);
    AlarmManager localAlarmManager = (AlarmManager)this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getSystemService("alarm");
    long l = System.currentTimeMillis() + paramLong;
    super.set(0, l, localPendingIntent);
  }

  private void b(String paramString)
  {
    Intent localIntent = new Intent(paramString);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(QQApplication.getContext(), 0, localIntent, 0);
    ((AlarmManager)this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getSystemService("alarm")).cancel(localPendingIntent);
  }

  public static void onDisconnect()
  {
    boolean bool1 = isRegPushSuccess;
    boolean bool2 = isRegTroopPushSuccess;
  }

  public static void receivedMsgNotification(QQApplication paramQQApplication)
  {
    int i = null;
    Object localObject1 = PreferenceManager.getDefaultSharedPreferences(paramQQApplication);
    Object localObject2 = (Vibrator)paramQQApplication.getSystemService("vibrator");
    Object localObject3 = paramQQApplication.getString(2131296353);
    localObject3 = ((SharedPreferences)localObject1).getBoolean((String)localObject3, true);
    Object localObject4 = paramQQApplication.getString(2131296351);
    localObject4 = ((SharedPreferences)localObject1).getBoolean((String)localObject4, true);
    localObject1 = paramQQApplication.a();
    int j;
    if ((localObject1 != null) && (((List)localObject1).size() > 0))
    {
      localObject1 = (UnreadMsgFriendInfo)((List)localObject1).get(i);
      if (paramQQApplication.jdField_a_of_type_Boolean)
        paramQQApplication.a((UnreadMsgFriendInfo)localObject1);
      if (paramQQApplication.a() != 0)
      {
        if (localObject3 != 0)
        {
          long[] arrayOfLong = VIBRATOR_PATTERN;
          ((Vibrator)localObject2).vibrate(arrayOfLong, -1);
        }
        if (localObject4 != 0)
        {
          String str = ((UnreadMsgFriendInfo)localObject1).uin;
          localObject2 = "10000".equals(localObject1);
          if (localObject2 == 0)
            break label153;
          j = 2131099650;
          label146: paramQQApplication.a(j, i);
        }
      }
    }
    while (true)
    {
      return;
      label153: j = 2131099649;
      break label146:
      paramQQApplication.c();
    }
  }

  private static void resetGetMsgFlag()
  {
    boolean bool1 = msgGetting;
    boolean bool2 = msgNew;
  }

  public final void a()
  {
    Exception localException1 = msgGetting;
    localException1 = msgNew;
    Object localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    localObject1 = ((QQApplication)localObject1).getSharedPreferences(str1, localException1);
    SharedPreferences.Editor localEditor = ((SharedPreferences)localObject1).edit();
    int j = MessageCache.getLastGetMsgSeq();
    localEditor.putInt("getlastMessageTime", j);
    localEditor.commit();
    MessageCache.clearAllSeq();
    StringBuilder localStringBuilder1 = new StringBuilder().append("save last msg time");
    localObject1 = ((SharedPreferences)localObject1).getInt("getlastMessageTime", localException1);
    localObject1 = localObject1;
    QLog.v("push", (String)localObject1);
    try
    {
      StringBuilder localStringBuilder2 = new StringBuilder().append("unRegisterPush getUin():");
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      String str3 = str2;
      QLog.i("push", str3);
      boolean bool = isRegPushSuccess;
      bool = isRegTroopPushSuccess;
      Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper;
      String str4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      localObject2 = ((PushHelper)localObject2).unRegisterPush(str4, 1L);
      localObject2 = "unRegisterPush:" + localObject2;
      QLog.i("push", (String)localObject2);
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper;
      String str5 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      ((PushHelper)localObject2).unRegisterPush(str5, "MessageSvc.PushNotify");
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper;
      String str6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      ((PushHelper)localObject2).unRegisterPush(str6, "MessageSvc.PushGroupMsg");
      int i = 1;
      if (i != 0)
        QLog.i("push", "unRegisterPush success");
      String str7 = ACTION_GET_MESSAGE;
      b(str7);
      String str8 = ACTION_KEEP_PUSH;
      b(str8);
      if (this.jdField_a_of_type_AndroidContentBroadcastReceiver != null)
      {
        QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        BroadcastReceiver localBroadcastReceiver = this.jdField_a_of_type_AndroidContentBroadcastReceiver;
        localQQApplication.unregisterReceiver(localBroadcastReceiver);
        this.jdField_a_of_type_AndroidContentBroadcastReceiver = null;
      }
      return;
    }
    catch (Exception localException2)
    {
      QLog.i("push", "unRegisterPush fail");
      localException2 = localException1;
    }
  }

  public final void a(long paramLong)
  {
    this.jdField_a_of_type_Long = paramLong;
    String str1 = ACTION_GET_MESSAGE;
    b(str1);
    String str2 = ACTION_GET_MESSAGE;
    a(str2, paramLong);
  }

  public final boolean a(FromServiceMsg paramFromServiceMsg)
  {
    int i = -1;
    int j = 0;
    Object localObject1 = 1000;
    Object localObject2 = 1;
    Object localObject3 = 0;
    Object localObject4 = paramFromServiceMsg.serviceCmd;
    Object localObject13 = "MessageSvc";
    localObject4 = ((String)localObject4).contains((CharSequence)localObject13);
    if (localObject4 != 0)
    {
      localObject4 = "push";
      localObject13 = new StringBuilder().append("cmd :");
      localObject14 = paramFromServiceMsg.serviceCmd;
      localObject13 = (String)localObject14;
      QLog.w((String)localObject4, (String)localObject13);
    }
    localObject4 = paramFromServiceMsg.serviceCmd;
    localObject13 = "MessageSvc.getmsg";
    localObject4 = ((String)localObject4).equals(localObject13);
    if (localObject4 != 0)
    {
      int k = paramFromServiceMsg.resultCode;
      if (k == 1002)
      {
        MessageCache.curGetMsgSeq = i;
        resetGetMsgFlag();
        localObject5 = this.jdField_a_of_type_JavaUtilTimer;
        if (localObject5 == null)
        {
          localObject5 = new Timer(localObject2);
          this.jdField_a_of_type_JavaUtilTimer = ((Timer)localObject5);
        }
        localObject5 = new hc(this);
        int i4 = this.jdField_a_of_type_Int;
        int i5 = i4 + 1;
        this.jdField_a_of_type_Int = i5;
        if (i4 > 2)
        {
          localObject5 = this.jdField_a_of_type_JavaUtilTimer;
          if (localObject5 != null)
          {
            localObject5 = this.jdField_a_of_type_JavaUtilTimer;
            ((Timer)localObject5).cancel();
            this.jdField_a_of_type_JavaUtilTimer = j;
            this.jdField_a_of_type_Int = localObject3;
          }
        }
      }
      for (Object localObject5 = localObject2; ; ??? = localObject3)
      {
        label226: label230: return localObject5;
        this.jdField_a_of_type_JavaUtilTimer.schedule((TimerTask)localObject5, 3000L);
        break label226:
        int l = paramFromServiceMsg.resultCode;
        if (l == localObject1)
          break;
        MessageCache.curGetMsgSeq = i;
        resetGetMsgFlag();
        ??? = this.jdField_a_of_type_JavaUtilTimer;
        if (??? == null)
          continue;
        ??? = this.jdField_a_of_type_JavaUtilTimer;
        ((Timer)???).cancel();
        this.jdField_a_of_type_JavaUtilTimer = j;
        this.jdField_a_of_type_Int = localObject3;
      }
      ??? = this.jdField_a_of_type_JavaUtilTimer;
      if (??? != null)
      {
        ??? = this.jdField_a_of_type_JavaUtilTimer;
        ((Timer)???).cancel();
        this.jdField_a_of_type_JavaUtilTimer = j;
        this.jdField_a_of_type_Int = localObject3;
      }
      ??? = paramFromServiceMsg.extraData;
      if (??? != null)
      {
        ??? = paramFromServiceMsg.extraData.getBoolean("ignoreNotify");
        if (??? == 0)
        {
          ??? = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          receivedMsgNotification((QQApplication)???);
        }
      }
    }
    do
    {
      label419: int i3;
      do
      {
        while (true)
        {
          synchronized (this.jdField_a_of_type_ArrayOfInt)
          {
            boolean bool2 = msgGetting;
            msgNew = bool2;
            if (bool2)
            {
              QLog.i("push", "friend message is more");
              b();
            }
            ??? = localObject3;
          }
          localObject13 = "MessageSvc.PushNotify";
          ??? = ((String)???).equals(localObject13);
          if (??? != 0)
          {
            int i1 = paramFromServiceMsg.resultCode;
            if (i1 == localObject1)
              QLog.v("push", "friend push notify");
          }
          synchronized (this.jdField_a_of_type_ArrayOfInt)
          {
            boolean bool3 = msgNew;
            b();
            ??? = localObject2;
          }
          localObject13 = "MessageSvc.PushGroupMsg";
          ??? = ((String)???).equals(localObject13);
          if (??? != 0)
          {
            int i2 = paramFromServiceMsg.resultCode;
            if (i2 != localObject1)
              continue;
            localObject8 = paramFromServiceMsg.extraData.getString("groupuin");
            a((String)localObject8);
            localObject8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            receivedMsgNotification((QQApplication)localObject8);
          }
          localObject8 = paramFromServiceMsg.serviceCmd;
          localObject13 = "MessageSvc.GetGroupMsg";
          localObject8 = ((String)localObject8).equals(localObject13);
          if (localObject8 == 0)
            break;
          localObject8 = paramFromServiceMsg.extraData.getString("groupuin");
          if (paramFromServiceMsg.resultCode == 1002)
          {
            MessageCache.addCurGroupSeq((String)localObject8, 0L);
            localObject8 = this.jdField_b_of_type_JavaUtilTimer;
            if (localObject8 == null)
            {
              localObject8 = new Timer(localObject2);
              this.jdField_b_of_type_JavaUtilTimer = ((Timer)localObject8);
            }
            localObject8 = new hd(this);
            int i6 = this.jdField_b_of_type_Int;
            int i7 = i6 + 1;
            this.jdField_b_of_type_Int = i7;
            if (i6 > 2)
            {
              localObject8 = this.jdField_b_of_type_JavaUtilTimer;
              if (localObject8 != null)
              {
                localObject8 = this.jdField_b_of_type_JavaUtilTimer;
                ((Timer)localObject8).cancel();
                this.jdField_b_of_type_JavaUtilTimer = j;
                this.jdField_b_of_type_Int = localObject3;
              }
            }
            while (true)
            {
              localObject8 = localObject2;
              break label230:
              this.jdField_b_of_type_JavaUtilTimer.schedule((TimerTask)localObject8, 3000L);
            }
          }
          if (paramFromServiceMsg.resultCode != localObject1)
          {
            MessageCache.addCurGroupSeq((String)localObject8, 0L);
            localObject8 = this.jdField_b_of_type_JavaUtilTimer;
            if (localObject8 != null)
            {
              localObject8 = this.jdField_b_of_type_JavaUtilTimer;
              ((Timer)localObject8).cancel();
              this.jdField_b_of_type_JavaUtilTimer = j;
              this.jdField_b_of_type_Int = localObject3;
            }
            localObject8 = localObject3;
          }
          a((String)localObject8);
          localObject8 = this.jdField_b_of_type_JavaUtilTimer;
          if (localObject8 != null)
          {
            localObject8 = this.jdField_b_of_type_JavaUtilTimer;
            ((Timer)localObject8).cancel();
            this.jdField_b_of_type_JavaUtilTimer = j;
            this.jdField_b_of_type_Int = localObject3;
          }
          isRegTroopPushSuccess = (Z)localObject8;
          if (localObject8 == null)
            e();
          localObject8 = paramFromServiceMsg.extraData;
          if (localObject8 != null)
          {
            localObject8 = paramFromServiceMsg.extraData.getBoolean("nonemsg");
            if (localObject8 != 0)
              localObject8 = localObject2;
          }
          localObject8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          receivedMsgNotification((QQApplication)localObject8);
        }
        Object localObject8 = paramFromServiceMsg.serviceCmd;
        localObject13 = "MessageSvc.GetGroupMsgNum";
        localObject8 = ((String)localObject8).equals(localObject13);
        if (localObject8 == 0)
        {
          localObject8 = paramFromServiceMsg.serviceCmd;
          localObject13 = "MessageSvc.GetGroupUnRead";
          localObject8 = ((String)localObject8).equals(localObject13);
          if (localObject8 == 0)
            break label1240;
        }
        i3 = paramFromServiceMsg.resultCode;
      }
      while (i3 != localObject1);
      localObject9 = paramFromServiceMsg.extraData;
    }
    while (localObject9 == null);
    localObject13 = paramFromServiceMsg.extraData.getStringArrayList("groupuin");
    Object localObject9 = paramFromServiceMsg.extraData;
    Object localObject14 = ((Bundle)localObject9).getIntegerArrayList("msgnum");
    if (localObject13 != null)
    {
      localObject9 = ((List)localObject13).size();
      if (localObject9 > 0)
      {
        localObject9 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        if (localObject9 != null)
        {
          localObject1 = localObject3;
          for (localObject2 = localObject3; ; localObject2 = localObject10)
          {
            localObject9 = ((List)localObject13).size();
            if (localObject1 >= localObject9)
              break;
            if (localObject14 == null)
              break;
            localObject9 = ((Integer)((ArrayList)localObject14).get(localObject1)).intValue();
            if (localObject9 <= 0)
              break;
            BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
            localObject9 = (String)((List)localObject13).get(localObject1);
            MessageUtil.getGroupMessage(localBaseServiceHelper, localBaseActionListener, str1, (String)localObject9);
            localObject10 = ((Integer)((ArrayList)localObject14).get(localObject1)).intValue() + localObject2;
            label1174: ++localObject1;
          }
        }
      }
    }
    label1240: Object localObject12;
    for (Object localObject10 = localObject2; ; localObject12 = localObject3)
    {
      String str2 = "group msg count:" + localObject10;
      QLog.v("push", str2);
      if (localObject10 == 0);
      isRegTroopPushSuccess = localObject10;
      if (localObject10 == 0);
      e();
      break label419:
      boolean bool1 = paramFromServiceMsg.serviceCmd.equals("MessageSvc.reqPushGroup");
      if (bool1)
      {
        QLog.i("push", "Register troop push success");
        localObject11 = paramFromServiceMsg.resultCode;
        if (localObject11 == localObject1);
        boolean bool4 = isRegTroopPushSuccess;
      }
      Object localObject11 = paramFromServiceMsg.serviceCmd.equals("MessageSvc.SetGroupFilter");
      if (localObject11 != 0);
      QLog.v("push", "troop list filter change");
      localObject12 = paramFromServiceMsg.resultCode;
      if (localObject12 == localObject1);
      isRegTroopPushSuccess = localObject12;
      if (localObject12 == 0);
      e();
      break label419:
      localObject12 = localObject2;
      break label1174:
    }
  }

  public final void b()
  {
    ??? = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    if (??? == null)
      return;
    synchronized (this.jdField_a_of_type_ArrayOfInt)
    {
      int i;
      msgGetting = i;
      if (i == 0)
      {
        boolean bool1 = msgGetting;
        boolean bool2 = msgNew;
        QLog.i("push", "start get friend message");
        BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        MessageUtil.getMessage((BaseServiceHelper)???, localBaseActionListener, str);
      }
      QLog.i("push", "is getting friend message");
    }
  }

  public final void c()
  {
    Object localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    if (localObject == null);
    while (true)
    {
      return;
      localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str1 = "start get troop message groupUin:" + localObject;
      QLog.i("push", str1);
      if (localObject == null)
        continue;
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      MessageUtil.getGroupMsgNumAndOnline(localBaseServiceHelper, localBaseActionListener, str2, localObject);
    }
  }

  public final void d()
  {
    long l1 = 11L;
    long l2 = 0L;
    String[] arrayOfString1 = null;
    Object localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getContentResolver();
    Object localObject2 = FriendList.GROUP_LIST_CONTENT_URI;
    String[] arrayOfString2 = arrayOfString1;
    Object localObject3 = arrayOfString1;
    Object localObject4 = arrayOfString1;
    localObject1 = ((ContentResolver)localObject1).query((Uri)localObject2, arrayOfString1, arrayOfString2, localObject3, (String)localObject4);
    if (localObject1 == null);
    while (true)
    {
      return;
      localObject2 = ((Cursor)localObject1).getCount();
      if (localObject2 == 0)
      {
        QLog.v("push", "first loading");
        ((Cursor)localObject1).close();
      }
      ((Cursor)localObject1).close();
      Object localObject5;
      long l4;
      try
      {
        localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper;
        localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        long l3 = 1L;
        localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getSharedPreferences((String)localObject3, 0).getLong("getProfileStatus", 0L);
        String str1 = "status:" + localObject5;
        QLog.v("wdc", str1);
        if (localObject5 != l2)
          break label368;
        localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getSharedPreferences((String)localObject3, 0).edit();
        ((SharedPreferences.Editor)localObject3).putLong("getProfileStatus", 11L);
        ((SharedPreferences.Editor)localObject3).commit();
        l4 = l1;
        label240: int i = (int)l4;
        BaseActionListener localBaseActionListener1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        ((PushHelper)localObject1).registerPush((String)localObject2, l3, localObject3, localBaseActionListener1);
        PushHelper localPushHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentQphoneBaseUtilPushHelper;
        String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        BaseActionListener localBaseActionListener2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        ((PushHelper)localObject1).registerPush((String)localObject2, "MessageSvc.PushNotify", localBaseActionListener2);
        label309: boolean bool1 = isRegPushSuccess;
        StringBuilder localStringBuilder = new StringBuilder().append("Register friend Push success = ");
        isRegPushSuccess = "Register friend Push success = ";
        String str3 = "Register friend Push success = ";
        label368: QLog.i("push", str3);
      }
      catch (Exception localException)
      {
        boolean bool2 = isRegPushSuccess;
        break label309:
        l4 = localObject5;
        break label240:
      }
    }
  }

  public final void e()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
      QLog.i("push", "no filter group uin is null");
    while (true)
    {
      return;
      StringBuilder localStringBuilder = new StringBuilder().append("start register troop push isRegTroopPushSuccess:");
      isRegTroopPushSuccess = "start register troop push isRegTroopPushSuccess:";
      String str1 = "start register troop push isRegTroopPushSuccess:";
      QLog.v("push", str1);
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      int i = AppSetting.APP_ID;
      MessageUtil.registerGroupPush(localBaseServiceHelper, localBaseActionListener, str2, i);
    }
  }

  public final void f()
  {
    long l = -5536L;
    QLog.v("push", "registerGetMessageReceiver");
    if (this.jdField_a_of_type_AndroidContentBroadcastReceiver == null)
    {
      he localhe = new he(this);
      this.jdField_a_of_type_AndroidContentBroadcastReceiver = localhe;
    }
    IntentFilter localIntentFilter = new IntentFilter();
    String str1 = ACTION_GET_MESSAGE;
    localIntentFilter.addAction(str1);
    String str2 = ACTION_KEEP_PUSH;
    localIntentFilter.addAction(str2);
    localIntentFilter.addAction("android.intent.action.SCREEN_ON");
    localIntentFilter.addAction("android.intent.action.SCREEN_OFF");
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BroadcastReceiver localBroadcastReceiver = this.jdField_a_of_type_AndroidContentBroadcastReceiver;
    localQQApplication.registerReceiver(localBroadcastReceiver, localIntentFilter);
    this.jdField_a_of_type_Long = l;
    String str3 = ACTION_GET_MESSAGE;
    b(str3);
    String str4 = ACTION_GET_MESSAGE;
    a(str4, l);
    String str5 = ACTION_KEEP_PUSH;
    b(str5);
    String str6 = ACTION_KEEP_PUSH;
    a(str6, 600000L);
  }

  public final void g()
  {
    String str1 = ACTION_KEEP_PUSH;
    b(str1);
    String str2 = ACTION_KEEP_PUSH;
    a(str2, 600000L);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.MessageController
 * JD-Core Version:    0.5.4
 */