package com.tencent.mobileqq.app;

public class AppSetting
{
  public static int APP_ID = 0;
  public static int APP_ID2 = 0;
  public static String LC1 = "83B2F5A4D09C2249";
  public static String LC2 = "CAA5B148AF5A075D";
  public static final String ProductID = "130";
  public static final String buildNum = "0072";
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.app.AppSetting
 * JD-Core Version:    0.5.4
 */