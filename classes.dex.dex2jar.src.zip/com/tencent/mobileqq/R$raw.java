package com.tencent.mobileqq;

public final class R$raw
{
  public static final int about = 2131099648;
  public static final int msg = 2131099649;
  public static final int system = 2131099650;
  public static final int video_incoming = 2131099651;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.raw
 * JD-Core Version:    0.5.4
 */