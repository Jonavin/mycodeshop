package com.tencent.mobileqq.adapter;

import android.app.Activity;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.QLog;
import java.util.ArrayList;
import java.util.List;

public final class FriendListAdapter$QueryHandler extends AsyncQueryHandler
{
  public FriendListAdapter$QueryHandler(FriendListAdapter paramFriendListAdapter, Context paramContext)
  {
    super(localContentResolver);
  }

  public final void onQueryComplete(int paramInt, Object paramObject, Cursor paramCursor)
  {
    int i = 1;
    int j = 0;
    if (paramCursor == null)
      label10: return;
    label40: int k;
    int l;
    switch (paramInt)
    {
    default:
      k = this.a.getGroupCount();
      FriendListAdapter localFriendListAdapter2 = this.a;
      i1 = k - i;
      l = (int)localFriendListAdapter2.getGroupId(i1);
    case -1:
    case -1000:
    }
    for (int i1 = j; ; ++i1)
    {
      if (i1 < k);
      long l1 = this.a.getGroupId(i1);
      long l2 = paramInt;
      Object localObject2;
      if (localObject2 != l2)
        continue;
      if (i1 == 0)
        FriendListAdapter.access$802(this.a, j);
      if (localObject2 != 64536L)
      {
        FriendListAdapter localFriendListAdapter3 = this.a;
        int i2 = paramCursor.getCount();
        FriendListAdapter.access$812(localFriendListAdapter3, i2);
      }
      long l3 = l;
      if (localObject2 == l3)
      {
        FriendListAdapter localFriendListAdapter4 = this.a;
        int i3 = FriendListAdapter.access$800(this.a);
        FriendListAdapter.access$702(localFriendListAdapter4, i3);
      }
      this.a.setChildrenCursor(i1, paramCursor);
      break label10:
      FriendListAdapter.access$002(this.a, paramCursor);
      Object localObject1 = new ArrayList();
      do
      {
        if (!paramCursor.moveToNext())
          break;
        String str1 = paramCursor.getString(l1);
        ((List)localObject1).add(str1);
      }
      while (((List)localObject1).size() < 50);
      if (((List)localObject1).size() > 0)
      {
        QQApplication localQQApplication = (QQApplication)FriendListAdapter.access$100(this.a).getApplicationContext();
        String[] arrayOfString = new String[((List)localObject1).size()];
        ((List)localObject1).toArray(arrayOfString);
        BaseServiceHelper localBaseServiceHelper = localQQApplication.a();
        String str2 = localQQApplication.a().getUin();
        ProfileUtil.getSignature((BaseServiceHelper)localObject1, str2, arrayOfString);
        StringBuilder localStringBuilder = new StringBuilder().append("fetch signature limit ");
        int i4 = arrayOfString.length;
        String str3 = i4;
        QLog.i("System.out", (String)localObject1);
        FriendListAdapter localFriendListAdapter5 = this.a;
        int i5 = arrayOfString.length;
        FriendListAdapter.access$212(localFriendListAdapter5, localObject1);
      }
      QLog.i("System.out", "all signature update complete.");
      Activity localActivity = FriendListAdapter.access$100(this.a);
      String str4 = FriendListAdapter.access$300(this.a);
      SharedPreferences.Editor localEditor = localActivity.getSharedPreferences(str4, j).edit();
      long l4 = System.currentTimeMillis();
      Object localObject3;
      localEditor.putLong("getSignatureTime", localObject3);
      localEditor.commit();
      FriendListAdapter.access$000(this.a).close();
      FriendListAdapter.access$002(this.a, null);
      FriendListAdapter.access$402(this.a, j);
      FriendListAdapter.access$500(this.a);
      break label10:
      FriendListAdapter localFriendListAdapter1 = this.a;
      localObject1 = paramCursor.getCount();
      FriendListAdapter.access$602(localFriendListAdapter1, localObject1);
      localFriendListAdapter1 = this.a;
      localObject1 = FriendListAdapter.access$600(this.a);
      i1 = FriendListAdapter.access$700(this.a);
      localObject1 = Math.max(localObject1, i1);
      FriendListAdapter.access$702(localFriendListAdapter1, localObject1);
      break label40:
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.adapter.FriendListAdapter.QueryHandler
 * JD-Core Version:    0.5.4
 */