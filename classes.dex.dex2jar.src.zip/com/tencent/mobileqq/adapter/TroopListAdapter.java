package com.tencent.mobileqq.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.drawable.BG1;
import com.tencent.mobileqq.utils.ViewUtils;
import com.tencent.qphone.base.remote.SimpleAccount;

public class TroopListAdapter extends ResourceCursorAdapter
{
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;
  private QQServiceEntry jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;

  public TroopListAdapter(Context paramContext, QQServiceEntry paramQQServiceEntry, Cursor paramCursor)
  {
    super(paramContext, 2130903061, paramCursor);
    QQApplication localQQApplication = (QQApplication)paramContext.getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry = paramQQServiceEntry;
  }

  public void bindView(View paramView, Context paramContext, Cursor paramCursor)
  {
    long l1 = 1L;
    int i = null;
    int j = 1;
    int k = paramCursor.getColumnIndex("troopuin");
    String str = paramCursor.getString(k);
    Object localObject1 = (TextView)paramView.findViewById(16908308);
    Object localObject2 = (TextView)paramView.findViewById(16908309);
    Object localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    Object localObject4 = paramContext.getSharedPreferences((String)localObject3, i);
    localObject3 = (String)localObject3 + str;
    localObject4 = ((SharedPreferences)localObject4).getLong((String)localObject3, l1);
    localObject3 = (ImageView)paramView.findViewById(2131492873);
    Object localObject5 = null;
    ((ImageView)localObject3).setImageBitmap((Bitmap)localObject5);
    Object localObject6;
    long l2 = localObject6 < l1;
    if (localObject3 == 0)
    {
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(i);
      localObject5 = localObject3;
      label158: localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.b(str);
      if (localObject3 == null)
        break label464;
      ((TextView)localObject1).setText((CharSequence)localObject3);
      label181: localObject3 = ((TextView)localObject1).getText().toString();
      ViewUtils.adjustWidth(paramContext, (TextView)localObject1, (String)localObject3, 50);
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.c(str);
      if (localObject1 == null)
        break label474;
      ((TextView)localObject2).setText((CharSequence)localObject1);
      label224: localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(j, str, j);
      localObject1 = (TextView)paramView.findViewById(2131493031);
      if (localObject2 <= 0)
        break label488;
      localObject2 = String.valueOf(localObject2);
      ((TextView)localObject1).setText((CharSequence)localObject2);
      ((TextView)localObject1).setVisibility(i);
      label276: localObject1 = (ImageView)paramView.findViewById(16908294);
      localObject2 = (GridView)paramView.findViewById(2131493033);
      localObject3 = ((GridView)localObject2).getBackground();
      if (localObject3 == null)
      {
        int i1 = ((GridView)localObject2).getPaddingTop();
        localObject3 = new BG1((View)localObject1, i1);
        ((GridView)localObject2).setBackgroundDrawable((Drawable)localObject3);
      }
      ((GridView)localObject2).setVisibility(8);
      localObject3 = (QQServiceEntry.Tag)((ImageView)localObject1).getTag();
      if (localObject3 == null)
        localObject3 = new QQServiceEntry.Tag();
      ((QQServiceEntry.Tag)localObject3).jdField_a_of_type_JavaLangString = str;
      ((QQServiceEntry.Tag)localObject3).jdField_a_of_type_Int = j;
      ((QQServiceEntry.Tag)localObject3).jdField_a_of_type_AndroidWidgetGridView = ((GridView)localObject2);
      long l3 = localObject6 < l1;
      if (localObject2 != 0)
        break label501;
    }
    for (int l = 64; ; l = 32)
    {
      int i2 = l | 0x1;
      ((QQServiceEntry.Tag)localObject3).b = l;
      ((ImageView)localObject1).setTag(localObject3);
      ((ImageView)localObject1).setImageDrawable((Drawable)localObject5);
      QQServiceEntry localQQServiceEntry = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
      ((ImageView)localObject1).setOnClickListener(l);
      return;
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(j);
      localObject5 = localObject3;
      break label158:
      label464: ((TextView)localObject1).setText(str);
      break label181:
      label474: localObject1 = "";
      l.setText((CharSequence)localObject1);
      break label224:
      label488: l = 4;
      ((TextView)localObject1).setVisibility(l);
      label501: break label276:
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.adapter.TroopListAdapter
 * JD-Core Version:    0.5.4
 */