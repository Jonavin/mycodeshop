package com.tencent.mobileqq.adapter;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ResourceCursorTreeAdapter;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.content.FriendList;
import com.tencent.mobileqq.utils.ViewUtils;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import gz;
import hb;
import java.util.HashSet;
import java.util.Set;

public class FriendListAdapter extends ResourceCursorTreeAdapter
  implements AbsListView.OnScrollListener, ExpandableListView.OnGroupExpandListener
{
  private static final String SQL_ORDER_BY = "status,name";
  private static final int TOKEN_UPDATE_SIGNATURE = 255;
  public int a;
  private final Activity jdField_a_of_type_AndroidAppActivity;
  private Cursor jdField_a_of_type_AndroidDatabaseCursor;
  private Handler jdField_a_of_type_AndroidOsHandler;
  private Message jdField_a_of_type_AndroidOsMessage;
  public FriendListAdapter.QueryHandler a;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;
  private QQServiceEntry jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
  public final BaseActionListener a;
  private final String jdField_a_of_type_JavaLangString;
  private Set jdField_a_of_type_JavaUtilSet;
  private int jdField_b_of_type_Int;
  private Set jdField_b_of_type_JavaUtilSet;
  private int c;
  private int d;
  private int e;

  public FriendListAdapter(Activity paramActivity, QQServiceEntry paramQQServiceEntry, Cursor paramCursor, Message paramMessage)
  {
    super(paramActivity, paramCursor, 2130903070, 2130903061);
    gz localgz = new gz(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localgz;
    hb localhb = new hb(this);
    this.jdField_a_of_type_AndroidOsHandler = localhb;
    this.jdField_a_of_type_AndroidAppActivity = paramActivity;
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry = paramQQServiceEntry;
    this.jdField_a_of_type_AndroidOsMessage = paramMessage;
    QQApplication localQQApplication = (QQApplication)paramActivity.getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    this.jdField_a_of_type_JavaLangString = str;
    FriendListAdapter.QueryHandler localQueryHandler = new FriendListAdapter.QueryHandler(this, paramActivity);
    this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter$QueryHandler = localQueryHandler;
    HashSet localHashSet1 = new HashSet();
    this.jdField_a_of_type_JavaUtilSet = localHashSet1;
    HashSet localHashSet2 = new HashSet();
    this.jdField_b_of_type_JavaUtilSet = localHashSet2;
    a();
  }

  private void a()
  {
    int i = 1;
    int j = 64536;
    int k = 0;
    Object localObject1 = null;
    int l = k;
    label13: int i1 = getGroupCount();
    if (l >= i1)
      return;
    int i2 = (int)getGroupId(l);
    Object localObject2;
    if (i2 == j)
    {
      FriendListAdapter.QueryHandler localQueryHandler1 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter$QueryHandler;
      Uri localUri1 = FriendList.FRIEND_LIST_CONTENT_URI;
      String[] arrayOfString1 = new String[2];
      arrayOfString1[k] = "10";
      arrayOfString1[i] = "11";
      localObject2 = localObject1;
      localQueryHandler1.startQuery(j, localObject1, localUri1, localObject2, "status=? or status=?", arrayOfString1, "status,name");
    }
    while (true)
    {
      l += 1;
      break label13:
      FriendListAdapter.QueryHandler localQueryHandler2 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter$QueryHandler;
      Uri localUri2 = FriendList.FRIEND_LIST_CONTENT_URI;
      String[] arrayOfString2 = new String[i];
      String str = String.valueOf(localObject2);
      arrayOfString2[k] = str;
      Object localObject3 = localObject1;
      Object localObject4 = localObject1;
      localQueryHandler2.startQuery(localObject2, localObject3, localUri2, localObject4, "groupid=?", arrayOfString2, "status,name");
    }
  }

  protected void bindChildView(View paramView, Context paramContext, Cursor paramCursor, boolean paramBoolean)
  {
    paramBoolean = (TextView)paramView.findViewById(16908308);
    int i = paramCursor.getColumnIndex("name");
    Object localObject1 = paramCursor.getString(i);
    String str1 = paramCursor.getString(1);
    int i8 = paramCursor.getColumnIndex("isSupportVideo");
    i8 = paramCursor.getInt(i8);
    int i12 = 1;
    label73: int i10;
    label131: label147: int i13;
    label272: Object localObject13;
    label442: int i14;
    Object localObject14;
    if (i8 == i12)
    {
      int i9 = 1;
      paramView.setTag(str1);
      Object localObject12 = this.jdField_a_of_type_JavaUtilSet;
      ((Set)localObject12).add(paramView);
      if (localObject1 == null)
        break label606;
      localObject12 = ((String)localObject1).trim();
      String str2 = "";
      localObject12 = ((String)localObject12).equals(str2);
      if (localObject12 != 0)
        break label606;
      paramBoolean.setText((CharSequence)localObject1);
      localObject1 = paramView.findViewById(2131493030);
      if (i9 == null)
        break label616;
      i9 = null;
      ((View)localObject1).setVisibility(i9);
      localObject1 = paramBoolean.getText().toString();
      ViewUtils.adjustWidth(paramContext, paramBoolean, (String)localObject1, 50);
      paramContext = (TextView)paramView.findViewById(16908309);
      localObject1 = paramCursor.getColumnIndex("signature");
      localObject1 = paramCursor.getString(localObject1);
      paramContext.setText((CharSequence)localObject1);
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      boolean bool = true;
      localObject1 = ((QQApplication)localObject1).a(null, str1, bool);
      i9 = 2131493031;
      paramContext = (TextView)paramView.findViewById(i9);
      if (localObject1 <= 0)
        break label623;
      localObject1 = String.valueOf(localObject1);
      paramContext.setText((CharSequence)localObject1);
      int j = 0;
      paramContext.setVisibility(j);
      int k = paramCursor.getColumnIndex("faceid");
      i10 = paramCursor.getInt(k);
      k = paramCursor.getColumnIndex("status");
      i13 = paramCursor.getInt(k);
      paramContext = (ImageView)paramView.findViewById(16908294);
      paramBoolean = (GridView)paramView.findViewById(2131493033);
      paramBoolean.setVisibility(8);
      Object localObject2 = (QQServiceEntry.Tag)paramContext.getTag();
      if (localObject2 == null)
        localObject2 = new QQServiceEntry.Tag();
      ((QQServiceEntry.Tag)localObject2).jdField_a_of_type_JavaLangString = str1;
      ((QQServiceEntry.Tag)localObject2).jdField_a_of_type_Int = null;
      ((QQServiceEntry.Tag)localObject2).jdField_a_of_type_AndroidWidgetGridView = paramBoolean;
      ((QQServiceEntry.Tag)localObject2).jdField_b_of_type_Int = 13;
      paramContext.setTag(localObject2);
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
      paramContext.setOnClickListener((View.OnClickListener)localObject2);
      localObject2 = paramCursor.getColumnIndex("isMqqOnLine");
      localObject2 = paramCursor.getInt(localObject2);
      localObject13 = 1;
      if (localObject2 != localObject13)
        break label635;
      int l = 1;
      localObject13 = paramCursor.getColumnIndex("sqqOnLineState");
      localObject13 = paramCursor.getInt(localObject13);
      i14 = paramCursor.getColumnIndex("memberLevel");
      paramCursor.getInt(i14);
      i14 = paramCursor.getColumnIndex("sqqtype");
      paramCursor.getInt(i14);
      i14 = paramCursor.getColumnIndex("detalStatusFlag");
      i14 = paramCursor.getInt(i14);
      paramView = (ImageView)paramView.findViewById(2131492873);
      paramView.setImageDrawable(null);
      localObject14 = null;
      if (i13 != 10)
        break label748;
      if (l == null)
        break label655;
      l = 31;
      if (i14 != l)
        break label641;
      paramView.setImageResource(2130838039);
    }
    label606: label616: label623: label635: Object localObject10;
    for (Object localObject3 = localObject14; ; localObject10 = localObject14)
      while (true)
      {
        Drawable localDrawable = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(i10, str1, localObject3, null);
        paramContext.setImageDrawable(localObject3);
        return;
        Object localObject11 = null;
        break label73:
        paramBoolean.setText(str1);
        break label131:
        int i11 = 8;
        break label147:
        int i1 = 4;
        paramContext.setVisibility(i1);
        break label272:
        Object localObject4 = null;
        break label442:
        label641: paramView.setImageResource(2130837931);
        localObject4 = localObject14;
        continue;
        label655: int i2 = 30;
        if (i14 == i2)
        {
          paramView.setImageResource(2130838039);
          Object localObject5 = localObject14;
        }
        int i3 = 50;
        if (i14 == i3)
        {
          paramView.setImageResource(2130838037);
          Object localObject6 = localObject14;
        }
        int i4 = 60;
        if (i14 == i4)
        {
          paramView.setImageResource(2130838041);
          Object localObject7 = localObject14;
        }
        int i5 = 70;
        if (i14 != i5)
          break;
        Object localObject8 = localObject14;
        continue;
        label748: int i6 = 11;
        if (i13 == i6)
        {
          paramView.setImageResource(2130837931);
          Object localObject9 = localObject14;
        }
        int i7 = 20;
        if (i13 == i7)
        {
          i7 = 1;
          if (localObject13 == i7)
            break;
        }
        i7 = 1;
      }
  }

  protected void bindGroupView(View paramView, Context paramContext, Cursor paramCursor, boolean paramBoolean)
  {
    TextView localTextView = (TextView)paramView.findViewById(2131493072);
    String str1 = paramCursor.getString(0);
    localTextView.setText(str1);
    localTextView = (TextView)paramView.findViewById(2131493073);
    if (paramCursor.isFirst())
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("[");
      int i = this.c;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append("/");
      int j = this.d;
      String str2 = j + "]";
      localTextView.setText(str2);
    }
    while (true)
    {
      paramView.setTag("");
      return;
      StringBuilder localStringBuilder3 = new StringBuilder().append("[");
      String str3 = paramCursor.getString(1);
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str3).append("/");
      String str4 = paramCursor.getString(2);
      String str5 = str4 + "]";
      localTextView.setText(str5);
    }
  }

  public long getChildId(int paramInt1, int paramInt2)
  {
    return 0L;
  }

  protected Cursor getChildrenCursor(Cursor paramCursor)
  {
    return null;
  }

  public long getGroupId(int paramInt)
  {
    Object localObject1 = getCursor();
    Object localObject2 = null;
    int i;
    if (((Cursor)localObject1).moveToPosition(paramInt))
      i = ((Cursor)localObject1).getColumnIndex("group_id");
    for (localObject1 = ((Cursor)localObject1).getInt(i); ; localObject1 = localObject2)
      return localObject1;
  }

  public void onGroupCollapsed(int paramInt)
  {
  }

  public void onGroupExpand(int paramInt)
  {
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(0, 1000L);
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    int i = 0;
    if (paramInt == 0)
      this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(i, 1000L);
    while (true)
    {
      return;
      this.jdField_a_of_type_AndroidOsHandler.removeMessages(i);
    }
  }

  public void setChildrenCursor(int paramInt, Cursor paramCursor)
  {
    super.onGroupCollapsed(paramInt);
    super.setChildrenCursor(paramInt, paramCursor);
  }

  public void setGroupCursor(Cursor paramCursor)
  {
    super.setGroupCursor(paramCursor);
    a();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.adapter.FriendListAdapter
 * JD-Core Version:    0.5.4
 */