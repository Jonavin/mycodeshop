package com.tencent.mobileqq.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.data.FriendInfo;
import com.tencent.mobileqq.data.FriendMore;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;
import com.tencent.mobileqq.drawable.BG1;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.message.EmoWindow;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.utils.Chatter;
import com.tencent.mobileqq.utils.ViewUtils;

public class RecentListAdapter extends ResourceCursorAdapter
{
  private float jdField_a_of_type_Float;
  private Context jdField_a_of_type_AndroidContentContext;
  private View.OnClickListener jdField_a_of_type_AndroidViewView$OnClickListener;
  private View.OnLongClickListener jdField_a_of_type_AndroidViewView$OnLongClickListener;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;
  private QQServiceEntry jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;

  public RecentListAdapter(Context paramContext, QQServiceEntry paramQQServiceEntry, Cursor paramCursor, View.OnClickListener paramOnClickListener, View.OnLongClickListener paramOnLongClickListener)
  {
    super(paramContext, 2130903079, paramCursor);
    QQApplication localQQApplication = (QQApplication)paramContext.getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry = paramQQServiceEntry;
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    int i = paramContext.getResources().getDisplayMetrics().density;
    this.jdField_a_of_type_Float = i;
    this.jdField_a_of_type_AndroidViewView$OnClickListener = paramOnClickListener;
    this.jdField_a_of_type_AndroidViewView$OnLongClickListener = paramOnLongClickListener;
  }

  private static String getMessageDateTime(long paramLong)
  {
    Object localObject = new Time();
    Time localTime = new Time();
    ((Time)localObject).set(paramLong);
    localTime.setToNow();
    int i = ((Time)localObject).year;
    int j = localTime.year;
    if (i != j);
    for (localObject = ((Time)localObject).format("%Y-%m-%d"); ; localObject = ((Time)localObject).format("%H:%M"))
      while (true)
      {
        return localObject;
        int k = ((Time)localObject).yearDay;
        int l = localTime.yearDay;
        if (k == localTime)
          break;
        localObject = ((Time)localObject).format("%m-%d");
      }
  }

  public void bindView(View paramView, Context paramContext, Cursor paramCursor)
  {
    Cursor localCursor1 = paramCursor;
    String str1 = "uin";
    int i = localCursor1.getColumnIndex(str1);
    Cursor localCursor2 = paramCursor;
    String str3 = "type";
    int j = localCursor2.getColumnIndex(str3);
    Cursor localCursor3 = paramCursor;
    int k = j;
    int l = localCursor3.getInt(k);
    View localView1 = paramView;
    int i1 = 2131493110;
    Object localObject1 = (LinearLayout)localView1.findViewById(i1);
    Object localObject2 = Integer.valueOf(paramCursor.getPosition());
    ((LinearLayout)localObject1).setTag(localObject2);
    localObject2 = this.jdField_a_of_type_AndroidViewView$OnClickListener;
    ((LinearLayout)localObject1).setOnClickListener((View.OnClickListener)localObject2);
    localObject2 = this.jdField_a_of_type_AndroidViewView$OnLongClickListener;
    ((LinearLayout)localObject1).setOnLongClickListener((View.OnLongClickListener)localObject2);
    View localView2 = paramView;
    int i4 = 16908308;
    localObject1 = (TextView)localView2.findViewById(i4);
    View localView3 = paramView;
    int i5 = 16908309;
    localObject2 = (TextView)localView3.findViewById(i5);
    View localView4 = paramView;
    int i6 = 16908294;
    ImageView localImageView = (ImageView)localView4.findViewById(i6);
    View localView5 = paramView;
    int i7 = 2131493032;
    Object localObject4 = (TextView)localView5.findViewById(i7);
    ((TextView)localObject4).setVisibility(8);
    View localView6 = paramView;
    int i8 = 2131492873;
    ((ImageView)localView6.findViewById(i8)).setImageBitmap(null);
    View localView7 = paramView;
    int i9 = 2131493033;
    GridView localGridView = (GridView)localView7.findViewById(i9);
    Object localObject5 = localGridView.getBackground();
    if (localObject5 == null)
    {
      int i10 = localGridView.getPaddingTop();
      localObject5 = new BG1(localImageView, i10);
      localGridView.setBackgroundDrawable((Drawable)localObject5);
    }
    localGridView.setVisibility(8);
    Object localObject6 = null;
    localObject5 = (QQServiceEntry.Tag)localImageView.getTag();
    if (localObject5 == null)
      localObject5 = new QQServiceEntry.Tag();
    Cursor localCursor4 = paramCursor;
    int i11 = i;
    String str2 = localCursor4.getString(i11);
    Object localObject7 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils;
    Object localObject8 = new Chatter(str2, l);
    localObject7 = ((CacheUtils)localObject7).a((Chatter)localObject8);
    FriendMore localFriendMore1;
    int i14;
    int i12;
    Object localObject10;
    if (l == 0)
    {
      localObject8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a(str2);
      int i13 = -1;
      Object localObject11 = localObject2;
      String str4 = "";
      localObject11.setText(str4);
      localFriendMore1 = null;
      if (localObject8 == null)
        break label1962;
      localObject6 = ((Friends)localObject8).name;
      i13 = ((Friends)localObject8).faceid;
      i14 = ((Friends)localObject8).status;
      View localView8 = paramView;
      int i15 = 2131492873;
      paramCursor = (ImageView)localView8.findViewById(i15);
      int i16 = i14;
      int i17 = 10;
      if (i16 == i17)
        if (((Friends)localObject8).isMqqOnLine)
        {
          i12 = ((Friends)localObject8).detalStatusFlag;
          int i18 = i12;
          int i19 = 31;
          if (i18 == i19)
          {
            Cursor localCursor5 = paramCursor;
            int i20 = 2130838039;
            localCursor5.setImageResource(i20);
            i12 = i13;
            localObject10 = localObject6;
          }
        }
    }
    label518: label669: label721: label1384: label1512: String str5;
    for (localObject6 = localFriendMore1; ; localObject6 = str5)
    {
      while (true)
      {
        CacheUtils localCacheUtils = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils;
        String str7 = str2;
        localFriendMore1 = localCacheUtils.a(str7);
        if (localFriendMore1 != null)
        {
          String str8 = localFriendMore1.signature;
          Object localObject12 = localObject2;
          FriendMore localFriendMore2 = localFriendMore1;
          localObject12.setText(localFriendMore2);
        }
        if ((localObject7 != null) && (((UnreadMsgFriendInfo)localObject7).lastMsg != null) && (!((UnreadMsgFriendInfo)localObject7).lastMsg.equals("")))
        {
          int i21 = ((UnreadMsgFriendInfo)localObject7).lastMsg.charAt(0);
          int i22 = 22;
          if (i21 != i22)
          {
            String str9 = ((UnreadMsgFriendInfo)localObject7).lastMsg;
            String str10 = AppConstants.SDCARD_PATH;
            if (!str9.startsWith(str10))
              break label1298;
          }
          Context localContext1 = paramContext;
          int i23 = 2131296272;
          String str11 = localContext1.getString(i23);
          Object localObject13 = localObject2;
          String str12 = str11;
          localObject13.setText(str12);
          localObject2 = getMessageDateTime(((UnreadMsgFriendInfo)localObject7).lastTime * 1000L);
          ((TextView)localObject4).setText((CharSequence)localObject2);
          localObject2 = null;
          ((TextView)localObject4).setVisibility(localObject2);
        }
        localObject2 = str2.equals("10000");
        if (localObject2 != 0)
        {
          localObject2 = "绯荤";
          if (localObject2 != null)
          {
            localObject4 = ((String)localObject2).trim().length();
            if (localObject4 != 0)
              break label801;
          }
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
          localObject4 = FriendInfo.class;
          paramCursor = (FriendInfo)((EntityManager)localObject2).a((Class)localObject4, str2);
          if (paramCursor == null)
            break label1384;
          localObject4 = paramCursor.nickname;
          if (localObject4 == null)
            break label1384;
          localObject4 = paramCursor.nickname;
          label792: ((EntityManager)localObject2).a();
          localObject2 = localObject4;
          label801: localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(i12, str2, localObject6, null);
          ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_JavaLangString = str2;
          ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_Int = null;
          ((QQServiceEntry.Tag)localObject5).b = 13;
          label837: ((TextView)localObject1).setText((CharSequence)localObject2);
          Context localContext2 = paramContext;
          Object localObject14 = localObject1;
          Object localObject15 = localObject2;
          int i24 = 80;
          ViewUtils.adjustWidth(localContext2, localObject14, localObject15, i24);
          localImageView.setImageDrawable((Drawable)localObject4);
          ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_AndroidWidgetGridView = localGridView;
          localImageView.setTag(localObject5);
          localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
          localImageView.setOnClickListener((View.OnClickListener)localObject1);
          localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          String str13 = ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_JavaLangString;
          localObject1 = ((QQApplication)localObject1).a(l, (String)localObject2, true);
          View localView9 = paramView;
          int i25 = 2131493031;
          this = (TextView)localView9.findViewById(i25);
          if (localObject1 <= 0)
            break label1930;
          if (localObject1 <= 99)
            break label1906;
          RecentListAdapter localRecentListAdapter1 = this;
          String str14 = "n";
          localRecentListAdapter1.setText(str14);
          label975: RecentListAdapter localRecentListAdapter2 = this;
          int i26 = null;
          localRecentListAdapter2.setVisibility(i26);
        }
        while (true)
        {
          return;
          Cursor localCursor6 = paramCursor;
          int i27 = 2130837931;
          localCursor6.setImageResource(i27);
          i12 = localObject10;
          localObject10 = localObject6;
          localObject6 = localFriendMore1;
          break label518:
          int i28 = i12.detalStatusFlag;
          int i29 = 30;
          if (i28 == i29)
          {
            Cursor localCursor7 = paramCursor;
            int i30 = 2130838039;
            localCursor7.setImageResource(i30);
            i12 = localObject10;
            localObject10 = localObject6;
            localObject6 = localFriendMore1;
          }
          int i31 = i12.detalStatusFlag;
          int i32 = 50;
          if (i31 == i32)
          {
            Cursor localCursor8 = paramCursor;
            int i33 = 2130838037;
            localCursor8.setImageResource(i33);
            i12 = localObject10;
            localObject10 = localObject6;
            localObject6 = localFriendMore1;
          }
          int i34 = i12.detalStatusFlag;
          int i35 = 60;
          if (i34 == i35)
          {
            Cursor localCursor9 = paramCursor;
            int i36 = 2130838041;
            localCursor9.setImageResource(i36);
            i12 = localObject10;
            localObject10 = localObject6;
            localObject6 = localFriendMore1;
          }
          i12 = i12.detalStatusFlag;
          int i37 = i12;
          int i38 = 70;
          if (i37 != i38)
            break;
          i12 = localObject10;
          localObject10 = localObject6;
          localObject6 = localFriendMore1;
          break label518:
          int i39 = i14;
          int i40 = 11;
          if (i39 == i40)
          {
            Cursor localCursor10 = paramCursor;
            int i41 = 2130837931;
            localCursor10.setImageResource(i41);
            i12 = localObject10;
            localObject10 = localObject6;
            localObject6 = localFriendMore1;
          }
          int i42 = i14;
          int i43 = 20;
          if (i42 == i43)
          {
            i12 = i12.sqqOnLineState;
            int i44 = i12;
            int i45 = 1;
            if (i44 == i45)
              break;
          }
          Object localObject16 = 1;
          i12 = localObject10;
          localObject10 = localObject6;
          localObject6 = localObject16;
          break label518:
          label1298: String str15 = ((UnreadMsgFriendInfo)localObject7).lastMsg;
          Context localContext3 = this.jdField_a_of_type_AndroidContentContext;
          int i46 = this.jdField_a_of_type_Float;
          float f1 = 1077936128 * i46 / 1082130432;
          String str16 = str15.trim();
          Context localContext4 = localContext3;
          int i47 = f1;
          String str17 = str16;
          SpannableString localSpannableString1 = EmoWindow.toShownEmoSpanMsg(localContext4, i47, str17);
          Object localObject17 = localObject2;
          SpannableString localSpannableString2 = localSpannableString1;
          localObject17.setText(localSpannableString2);
          break label669:
          localObject2 = localObject10;
          break label721:
          localObject4 = str2;
          break label792:
          localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
          Context localContext5 = paramContext;
          Object localObject18 = localObject6;
          int i48 = 0;
          localObject9 = localContext5.getSharedPreferences(localObject18, i48);
          localObject6 = (String)localObject6 + str2;
          Object localObject19 = localObject9;
          Object localObject20 = localObject6;
          long l1 = 1L;
          localObject9 = localObject19.getLong(localObject20, l1);
          long l2 = 0L;
          Object localObject21;
          long l3 = localObject21 < l2;
          label1553: String str6;
          if (localObject6 == 0)
          {
            localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            boolean bool1 = true;
            Object localObject22 = localObject6;
            boolean bool3 = bool1;
            localObject6 = localObject22.a(bool3);
            QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            String str18 = str2;
            str5 = localQQApplication1.b(str18);
            if (str5 == null)
              break label1776;
            boolean bool2 = str5.trim().equals("");
            if (bool2)
              break label1776;
            QQApplication localQQApplication2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            String str19 = str2;
            str6 = localQQApplication2.c(str19);
            if ((localObject7 == null) || (((UnreadMsgFriendInfo)localObject7).lastMsg == null))
              break label1862;
            int i49 = ((UnreadMsgFriendInfo)localObject7).lastMsg.charAt(null);
            int i50 = 22;
            if (i49 != i50)
            {
              String str20 = ((UnreadMsgFriendInfo)localObject7).lastMsg;
              String str21 = AppConstants.SDCARD_PATH;
              if (!str20.startsWith(str21))
                break label1783;
            }
            Context localContext6 = paramContext;
            int i51 = 2131296272;
            String str22 = localContext6.getString(i51);
            Object localObject23 = localObject2;
            String str23 = str22;
            localObject23.setText(str23);
            label1661: localObject2 = getMessageDateTime(((UnreadMsgFriendInfo)localObject7).lastTime * 1000L);
            ((TextView)localObject4).setText((CharSequence)localObject2);
            localObject2 = null;
            ((TextView)localObject4).setVisibility(localObject2);
            label1693: ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_JavaLangString = str2;
            ((QQServiceEntry.Tag)localObject5).jdField_a_of_type_Int = 1;
            long l4 = localObject21 < 1L;
            if (localObject2 != 0)
              break label1899;
          }
          label1776: label1783: int i3;
          for (int i2 = 64; ; i3 = 32)
          {
            i2 |= 1;
            ((QQServiceEntry.Tag)localObject5).b = i2;
            Object localObject3 = str5;
            localObject4 = localObject6;
            break label837:
            localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            str5 = null;
            Object localObject24 = localObject6;
            String str24 = str5;
            localObject6 = localObject24.a(str24);
            break label1512:
            str5 = str2;
            break label1553:
            String str25 = ((UnreadMsgFriendInfo)localObject7).lastMsg;
            Context localContext7 = this.jdField_a_of_type_AndroidContentContext;
            int i52 = this.jdField_a_of_type_Float;
            float f2 = 1077936128 * i52 / 1082130432;
            String str26 = str25.trim();
            Context localContext8 = localContext7;
            int i53 = f2;
            String str27 = str26;
            SpannableString localSpannableString3 = EmoWindow.toShownEmoSpanMsg(localContext8, i53, str27);
            Object localObject25 = localObject3;
            SpannableString localSpannableString4 = localSpannableString3;
            localObject25.setText(localSpannableString4);
            break label1661:
            if (str6 != null)
            {
              label1862: Object localObject26 = localObject3;
              String str28 = str6;
              localObject26.setText(str28);
            }
            localObject4 = "";
            localObject3.setText((CharSequence)localObject4);
            label1899: break label1693:
          }
          label1906: String str29 = String.valueOf(localObject1);
          RecentListAdapter localRecentListAdapter3 = this;
          Object localObject27 = localObject1;
          localRecentListAdapter3.setText(localObject27);
          break label975:
          label1930: RecentListAdapter localRecentListAdapter4 = this;
          int i54 = 8;
          localRecentListAdapter4.setVisibility(i54);
        }
        localObject9 = localObject10;
        localObject10 = localObject6;
        localObject6 = str5;
      }
      label1962: Object localObject9 = localObject10;
      localObject10 = localObject6;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.adapter.RecentListAdapter
 * JD-Core Version:    0.5.4
 */