package com.tencent.mobileqq;

public final class R$color
{
  public static final int CustomedTabWidget = 2131230765;
  public static final int button_selected = 2131230727;
  public static final int button_text_color = 2131230776;
  public static final int button_unselected = 2131230726;
  public static final int chat_background = 2131230730;
  public static final int chat_close_bg = 2131230741;
  public static final int chat_close_press = 2131230742;
  public static final int chat_contact = 2131230724;
  public static final int chat_edit_bg = 2131230745;
  public static final int chat_edit_bg_press = 2131230746;
  public static final int chat_edit_bg_solid = 2131230747;
  public static final int chat_emotion_unit_bg_solid = 2131230762;
  public static final int chat_emotion_unit_bg_stroke = 2131230761;
  public static final int chat_emotion_unit_press = 2131230763;
  public static final int chat_extra_item_bg_solid = 2131230752;
  public static final int chat_friend_item_bg_solid = 2131230751;
  public static final int chat_friend_item_bg_stroke = 2131230750;
  public static final int chat_friend_text_bg = 2131230738;
  public static final int chat_history_msg_text = 2131230760;
  public static final int chat_history_time_text = 2131230759;
  public static final int chat_list_header_bg = 2131230753;
  public static final int chat_list_header_bg_press = 2131230754;
  public static final int chat_list_header_text = 2131230755;
  public static final int chat_message_tip_bg = 2131230756;
  public static final int chat_message_tip_num = 2131230758;
  public static final int chat_message_tip_text = 2131230757;
  public static final int chat_self_item_bg_solid = 2131230749;
  public static final int chat_self_item_bg_stroke = 2131230748;
  public static final int chat_self_text_bg = 2131230737;
  public static final int chat_send_bg = 2131230743;
  public static final int chat_send_press = 2131230744;
  public static final int chat_text = 2131230739;
  public static final int chat_time = 2131230740;
  public static final int chat_title_bg = 2131230731;
  public static final int chat_title_name = 2131230733;
  public static final int chat_win_title_bg = 2131230732;
  public static final int color_divider = 2131230773;
  public static final int extrainfo = 2131230774;
  public static final int headerFore = 2131230764;
  public static final int info_panel_bg = 2131230775;
  public static final int login_background = 2131230722;
  public static final int nonchat_contact = 2131230723;
  public static final int qq_normal = 2131230766;
  public static final int scrollbar_tbumb_bg = 2131230729;
  public static final int textfield_unselected = 2131230725;
  public static final int title_bg = 2131230721;
  public static final int traffic_bg = 2131230734;
  public static final int traffic_data = 2131230736;
  public static final int traffic_txt = 2131230735;
  public static final int transparent = 2131230728;
  public static final int video_bg_color = 2131230768;
  public static final int video_button_press = 2131230771;
  public static final int video_button_release = 2131230772;
  public static final int video_dlg_cover_color = 2131230770;
  public static final int video_edge_color = 2131230769;
  public static final int white = 2131230767;
  public static final int window_bg = 2131230720;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R.color
 * JD-Core Version:    0.5.4
 */