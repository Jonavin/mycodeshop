package com.tencent.mobileqq.widget;

public abstract interface Workspace$OnScreenChangeListener
{
  public abstract void a(int paramInt);

  public abstract void b(int paramInt);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.widget.Workspace.OnScreenChangeListener
 * JD-Core Version:    0.5.4
 */