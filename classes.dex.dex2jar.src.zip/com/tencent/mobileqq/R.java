package com.tencent.mobileqq;

public final class R
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.R
 * JD-Core Version:    0.5.4
 */