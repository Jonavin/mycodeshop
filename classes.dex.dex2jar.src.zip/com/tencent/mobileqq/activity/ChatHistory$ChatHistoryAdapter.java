package com.tencent.mobileqq.activity;

import af;
import ag;
import ai;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.content.Message;
import com.tencent.mobileqq.data.AddFriendSystemMsg;
import com.tencent.mobileqq.service.message.EmoWindow;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.mobileqq.utils.Recorder;
import java.io.File;

public class ChatHistory$ChatHistoryAdapter extends CursorAdapter
{
  private int jdField_a_of_type_Int = 1000;
  private ai jdField_a_of_type_Ai;
  private Context jdField_a_of_type_AndroidContentContext;
  private LayoutInflater jdField_a_of_type_AndroidViewLayoutInflater;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;

  public ChatHistory$ChatHistoryAdapter(ChatHistory paramChatHistory, Context paramContext)
  {
    super(paramContext, null);
    LayoutInflater localLayoutInflater = (LayoutInflater)paramContext.getSystemService("layout_inflater");
    this.jdField_a_of_type_AndroidViewLayoutInflater = localLayoutInflater;
    ai localai = new ai(this, paramContext);
    this.jdField_a_of_type_Ai = localai;
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    QQApplication localQQApplication = (QQApplication)paramContext.getApplicationContext();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
  }

  private static String getMessageDateTime(long paramLong)
  {
    Object localObject = new Time();
    Time localTime = new Time();
    ((Time)localObject).set(paramLong);
    localTime.setToNow();
    int i = ((Time)localObject).year;
    int j = localTime.year;
    if (i != j);
    for (localObject = ((Time)localObject).format("%Y-%m-%d %H:%M:%S"); ; localObject = ((Time)localObject).format("%H:%M:%S"))
      while (true)
      {
        return localObject;
        int k = ((Time)localObject).yearDay;
        int l = localTime.yearDay;
        if (k == localTime)
          break;
        localObject = ((Time)localObject).format("%m-%d %H:%M:%S");
      }
  }

  public final void a(String paramString, int paramInt1, int paramInt2)
  {
    char c = '/';
    Object localObject1 = null;
    StringBuilder localStringBuilder = new StringBuilder().append("friendUin=? AND extraflag=?@limit").append(paramInt2).append(",");
    Object localObject2 = String.valueOf(8);
    String str = (String)localObject2;
    localStringBuilder = new StringBuilder();
    localObject2 = Message.MSG_RECORD_URI_PREFIX;
    localStringBuilder.append(localObject2);
    localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a;
    localStringBuilder.append((String)localObject2);
    localStringBuilder.append(c);
    if (paramInt1 == 0);
    for (localObject2 = "friend"; ; localObject2 = "troop")
    {
      localStringBuilder.append((String)localObject2);
      localStringBuilder.append(c);
      localStringBuilder.append(paramString);
      Uri localUri = Uri.parse(localStringBuilder.toString());
      ai localai = this.jdField_a_of_type_Ai;
      int i = this.jdField_a_of_type_Int;
      String[] arrayOfString = new String[2];
      arrayOfString[0] = paramString;
      arrayOfString[1] = "0";
      Object localObject3 = localObject1;
      Object localObject4 = localObject1;
      localStringBuilder.startQuery(localObject2, localObject1, c, localObject3, str, arrayOfString, localObject4);
      return;
    }
  }

  public void bindView(View paramView, Context paramContext, Cursor paramCursor)
  {
    View localView1 = paramView;
    int i = 2131492952;
    Object localObject1 = (TextView)localView1.findViewById(i);
    View localView2 = paramView;
    int k = 2131492953;
    TextView localTextView1 = (TextView)localView2.findViewById(k);
    View localView3 = paramView;
    int i1 = 2131492954;
    TextView localTextView2 = (TextView)localView3.findViewById(i1);
    View localView4 = paramView;
    int i2 = 2131492955;
    ImageView localImageView1 = (ImageView)localView4.findViewById(i2);
    View localView5 = paramView;
    int i3 = 2131492956;
    ImageView localImageView2 = (ImageView)localView5.findViewById(i3);
    View localView6 = paramView;
    int i4 = 2131492957;
    paramView = (Button)localView6.findViewById(i4);
    Cursor localCursor1 = paramCursor;
    int i5 = 0;
    long l1 = localCursor1.getLong(i5);
    Cursor localCursor2 = paramCursor;
    String str2 = "frienduin";
    int i6 = localCursor2.getColumnIndex(str2);
    Cursor localCursor3 = paramCursor;
    int i12 = i6;
    String str3 = localCursor3.getString(i12);
    Cursor localCursor4 = paramCursor;
    String str4 = "istroop";
    i6 = localCursor4.getColumnIndex(str4);
    Cursor localCursor5 = paramCursor;
    int i13 = i6;
    i6 = localCursor5.getInt(i13);
    label210: int i14;
    String str8;
    Object localObject4;
    label410: label417: long l3;
    int i21;
    if (i6 == 0)
    {
      int i7 = null;
      Cursor localCursor6 = paramCursor;
      String str5 = "issend";
      i14 = localCursor6.getColumnIndex(str5);
      Cursor localCursor7 = paramCursor;
      int i15 = i14;
      i14 = localCursor7.getInt(i15);
      Cursor localCursor8 = paramCursor;
      String str6 = "time";
      int i16 = localCursor8.getColumnIndex(str6);
      Cursor localCursor9 = paramCursor;
      int i17 = i16;
      i16 = localCursor9.getInt(i17);
      Cursor localCursor10 = paramCursor;
      String str7 = "msg";
      int i18 = localCursor10.getColumnIndex(str7);
      Cursor localCursor11 = paramCursor;
      int i19 = i18;
      str8 = localCursor11.getString(i19);
      if (i7 == null)
        break label624;
      Cursor localCursor12 = paramCursor;
      String str9 = "senderuin";
      i7 = localCursor12.getColumnIndex(str9);
      Cursor localCursor13 = paramCursor;
      int i20 = i7;
      String str10 = localCursor13.getString(i20);
      if (i14 != 0)
        break label612;
      QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      localObject4 = ChatHistory.access$900((ChatHistory)this.jdField_a_of_type_AndroidContentContext);
      QQApplication localQQApplication2 = localQQApplication1;
      Object localObject8 = localObject4;
      String str11 = str10;
      localObject4 = localQQApplication2.a(localObject8, str11);
      if (localObject4 == null)
        break label605;
      ((TextView)localObject1).setText((CharSequence)localObject4);
      l3 = i16 * 1000L;
      localObject1 = new Time();
      localObject4 = new Time();
      Object localObject9 = localObject1;
      long l4 = l3;
      localObject9.set(l4);
      ((Time)localObject4).setToNow();
      int i22 = ((Time)localObject1).year;
      i21 = ((Time)localObject4).year;
      int i23 = i16;
      int i24 = i21;
      if (i23 == i24)
        break label660;
      localObject4 = "%Y-%m-%d %H:%M:%S";
    }
    label598: label605: label612: label624: Object localObject6;
    for (localObject1 = ((Time)localObject1).format((String)localObject4); ; localObject2 = ((Time)localObject2).format((String)localObject6))
    {
      while (true)
      {
        localTextView1.setText((CharSequence)localObject1);
        Cursor localCursor14 = paramCursor;
        String str12 = "extraflag";
        localObject1 = localCursor14.getColumnIndex(str12);
        Cursor localCursor15 = paramCursor;
        int i25 = localObject1;
        localCursor15.getInt(i25);
        localImageView1.setVisibility(8);
        localTextView2.setVisibility(0);
        localImageView2.setVisibility(8);
        int j = 8;
        View localView7 = paramView;
        int i26 = j;
        localView7.setVisibility(i26);
        if (str8 != null)
          break label713;
        localTextView2.setText("");
        return;
        int i8 = 1;
        break label210:
        Object localObject5 = i21;
        break label410:
        localObject5 = this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory.b;
        break label410:
        if (i14 == 0);
        for (localObject5 = this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory.a; ; localObject5 = this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory.b)
        {
          j.setText((CharSequence)localObject5);
          break label417:
        }
        label660: int i27 = j.yearDay;
        int i9 = ((Time)localObject5).yearDay;
        if (i27 == i9)
          break;
        localObject6 = "%m-%d %H:%M:%S";
        localObject2 = j.format((String)localObject6);
      }
      localObject6 = "%H:%M:%S";
    }
    label713: String str13 = str8;
    int i28 = 20;
    Object localObject2 = str13.indexOf(i28);
    Object localObject3 = -1;
    if (localObject2 != localObject3)
    {
      localObject2 = EmoWindow.EmoCode2Symbol(str8).replace("\r\n", "\n").replace("\r", "\n");
      localObject3 = this.jdField_a_of_type_AndroidContentContext;
      localObject6 = ChatHistory.access$2300(this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory);
      localObject2 = ((String)localObject2).trim();
    }
    for (localObject2 = EmoWindow.toShownEmoSpanMsg((Context)localObject3, localObject6, (String)localObject2); ; localObject2 = str8)
    {
      localObject3 = ((CharSequence)localObject2).charAt(null);
      Object localObject7 = 22;
      if (localObject3 == localObject7)
      {
        String str14 = str8;
        String str15 = "\026";
        localObject2 = str14.split(str15)[1].split("\\|");
        localObject3 = localObject2[null];
        int i10 = localObject2.length;
        if (i10 < 2)
        {
          i10 = 1;
          label861: l3 = 0L;
          if (localObject2 != null)
          {
            int i29 = localObject2.length;
            int i30 = 1;
            if (i29 > i30)
              if (localObject2[1] != null)
                break label1029;
          }
        }
        for (localObject2 = "0"; ; localObject2 = localObject2[1])
        {
          long l2 = Long.parseLong((String)localObject2);
          localObject2 = Uri.parse((String)localObject3);
          localTextView2.setVisibility(8);
          switch (i10)
          {
          case 0:
          default:
            break;
          case 1:
            localImageView1.setVisibility(0);
            localObject3 = AppConstants.SDCARD_ROOT;
            String str16 = str8;
            Object localObject10 = localObject3;
            localObject3 = str16.indexOf(localObject10);
            if (localObject3 >= 0)
            {
              l5 = l3 < 0L;
              if (localObject3 > 0)
                break;
            }
            localImageView1.setImageResource(2130837533);
            localImageView1.setOnClickListener(null);
            break label598:
            int i11 = Integer.valueOf(localObject2[2]).intValue();
            label1029: break label861:
          case 2:
          }
        }
        long l5 = l3 < 0L;
        if (localObject3 == 0)
        {
          int l = 0;
          localImageView2.setVisibility(l);
        }
        Context localContext = paramContext;
        Object localObject11 = localObject2;
        String str1 = ImageUtil.getThumbPath(localContext, localObject11);
        if (new File(str1).exists())
        {
          QQApplication localQQApplication3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          Uri localUri = Uri.parse(str1);
          Drawable localDrawable1 = localQQApplication3.a(str1);
          localImageView1.setImageDrawable(str1);
          af localaf = new af;
          String str17 = str1;
          ChatHistoryAdapter localChatHistoryAdapter1 = this;
          Object localObject12 = localObject2;
          str17.<init>(localChatHistoryAdapter1, localObject12);
          localImageView1.setOnClickListener(str1);
        }
        localImageView1.setImageResource(2130837533);
        localImageView1.setOnClickListener(null);
        break label598:
        Object localObject13;
        localObject2 = str1 + str3 + localObject13;
        View localView8 = paramView;
        Object localObject14 = localObject2;
        localView8.setTag(localObject14);
        View localView9 = paramView;
        int i31 = 0;
        localView9.setVisibility(i31);
        localObject2 = Recorder.getAmrFilePlayTime(str1);
        String str18 = AppConstants.SDCARD_PATH;
        if ((!str1.startsWith(str18)) || (localObject2 < 0))
        {
          View localView10 = paramView;
          Drawable localDrawable2 = null;
          Drawable localDrawable3 = null;
          Drawable localDrawable4 = null;
          Drawable localDrawable5 = null;
          localView10.setCompoundDrawables(localDrawable2, localDrawable3, localDrawable4, localDrawable5);
          View localView11 = paramView;
          String str19 = "[璇煶�";
          localView11.setText(str19);
          View localView12 = paramView;
          View.OnClickListener localOnClickListener = null;
          localView12.setOnClickListener(localOnClickListener);
        }
        StringBuilder localStringBuilder = new StringBuilder();
        String str20 = String.valueOf(localObject2);
        String str21 = str20 + "s";
        View localView13 = paramView;
        String str22 = str21;
        localView13.setText(str22);
        if ((!ChatHistory.access$600(this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory)) && (ChatHistory.access$2500(this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory) != null))
        {
          Object localObject15 = paramView.getTag();
          Object localObject16 = ChatHistory.access$2600(this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory);
          if (localObject15.equals(localObject16))
          {
            Drawable localDrawable6 = this.jdField_a_of_type_AndroidContentContext.getResources().getDrawable(2130837934);
            int i32 = localDrawable6.getMinimumWidth();
            int i33 = localDrawable6.getMinimumHeight();
            localDrawable6.setBounds(0, 0, i32, i33);
            View localView14 = paramView;
            Drawable localDrawable7 = localDrawable6;
            Drawable localDrawable8 = null;
            Drawable localDrawable9 = null;
            Drawable localDrawable10 = null;
            localView14.setCompoundDrawables(localDrawable7, localDrawable8, localDrawable9, localDrawable10);
          }
        }
        while (true)
        {
          int i34 = localObject2 * 98 / 60;
          localObject2 += 12;
          View localView15 = paramView;
          int i35 = localObject2;
          localView15.setCompoundDrawablePadding(i35);
          ag localag = new ag;
          Object localObject17 = localObject2;
          ChatHistoryAdapter localChatHistoryAdapter2 = this;
          View localView16 = paramView;
          String str23 = str1;
          int i36 = i14;
          localObject17.<init>(localChatHistoryAdapter2, localView16, str23, i36);
          View localView17 = paramView;
          Object localObject18 = localObject2;
          localView17.setOnClickListener(localObject18);
          break label598:
          Drawable localDrawable11 = this.jdField_a_of_type_AndroidContentContext.getResources().getDrawable(2130838036);
          int i37 = localDrawable11.getMinimumWidth();
          int i38 = localDrawable11.getMinimumHeight();
          localDrawable11.setBounds(0, 0, i37, i38);
          View localView18 = paramView;
          Drawable localDrawable12 = localDrawable11;
          Drawable localDrawable13 = null;
          Drawable localDrawable14 = null;
          Drawable localDrawable15 = null;
          localView18.setCompoundDrawables(localDrawable12, localDrawable13, localDrawable14, localDrawable15);
        }
      }
      if ("10000".equals(str3))
      {
        Cursor localCursor16 = paramCursor;
        String str24 = "senderuin";
        localObject2 = localCursor16.getColumnIndex(str24);
        Cursor localCursor17 = paramCursor;
        int i39 = localObject2;
        localObject2 = localCursor17.getString(i39);
        Cursor localCursor18 = paramCursor;
        String str25 = "msgtype";
        int i40 = localCursor18.getColumnIndex(str25);
        Cursor localCursor19 = paramCursor;
        int i41 = i40;
        int i42 = localCursor19.getInt(i41);
        String str26 = str8;
        Object localObject19 = localObject2;
        int i43 = i42;
        localObject2 = AddFriendSystemMsg.decode(str26, localObject19, i43);
        if (localObject2 != null);
        String str27 = ((AddFriendSystemMsg)localObject2).message;
        localTextView2.setText((CharSequence)localObject2);
      }
      localTextView2.setText((CharSequence)localObject2);
      break label598:
    }
  }

  public void changeCursor(Cursor paramCursor)
  {
    if (paramCursor == null)
      return;
    if (getCursor() != null)
      getCursor().deactivate();
    super.changeCursor(paramCursor);
    notifyDataSetChanged();
  }

  public View newView(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup)
  {
    return this.jdField_a_of_type_AndroidViewLayoutInflater.inflate(2130903053, paramViewGroup, null);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter
 * JD-Core Version:    0.5.4
 */