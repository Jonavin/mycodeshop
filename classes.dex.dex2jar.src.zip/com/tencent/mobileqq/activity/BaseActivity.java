package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.ScreenShotSensorEventListener;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.mobileqq.skin.SkinFactory;
import com.tencent.mobileqq.skin.SkinHashMap;
import com.tencent.mobileqq.skin.SkinListener;
import com.tencent.mobileqq.skin.SkinUtil;
import com.tencent.qphone.base.util.QLog;
import java.io.File;

public class BaseActivity extends Activity
  implements SkinListener
{
  static Object lock = new Object();
  public static ScreenShotSensorEventListener sensorEventListener;
  public QQApplication a;
  private SkinEngine jdField_a_of_type_ComTencentMobileqqSkinSkinEngine;
  private SkinFactory jdField_a_of_type_ComTencentMobileqqSkinSkinFactory;
  private String jdField_a_of_type_JavaLangString;
  private String b;

  public BaseActivity()
  {
    String str = super.getClass().getSimpleName();
    this.jdField_a_of_type_JavaLangString = str;
  }

  private void a()
  {
    String str1 = getSharedPreferences("skin", 0).getString("skin", "qq_skin_blue");
    this.b = str1;
    if (SkinHashMap.skinId.trim().length() != 0)
    {
      String str2 = this.b.trim();
      String str3 = SkinHashMap.skinId.trim();
      if (str2.equals(str3))
        break label192;
    }
    Context localContext = getApplicationContext();
    StringBuilder localStringBuilder1 = new StringBuilder().append("skin/");
    String str4 = this.b;
    String str5 = str4 + ".zip";
    StringBuilder localStringBuilder2 = new StringBuilder();
    String str6 = getBaseContext().getFilesDir().toString();
    String str7 = str6 + "/Skin/";
    SkinUtil.Unzip(localContext, str5, str7);
    SkinHashMap.clearFilterMap();
    StringBuilder localStringBuilder3 = new StringBuilder();
    String str8 = getBaseContext().getFilesDir().toString();
    SkinUtil.ParseSkinXml(str8 + "/Skin/", "skinmain.xml");
    label192: this.jdField_a_of_type_ComTencentMobileqqSkinSkinFactory.a();
  }

  public static boolean isMoveTaskToBack(Context paramContext, Intent paramIntent)
  {
    Object localObject1 = 1;
    Object localObject2 = paramIntent.getComponent();
    if (localObject2 == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      localObject2 = paramIntent.getComponent().getPackageName();
      String str = paramContext.getPackageName();
      localObject2 = ((String)localObject2).equals(str);
      if (localObject2 == 0)
        localObject2 = localObject1;
      localObject2 = null;
    }
  }

  public final void a(String paramString)
  {
    SkinEngine localSkinEngine = this.jdField_a_of_type_ComTencentMobileqqSkinSkinEngine;
    String str = SkinHashMap.skinId;
    if (paramString == str)
      return;
    ((BaseActivity)localSkinEngine.a).a();
  }

  protected boolean a()
  {
    return null;
  }

  protected void onCreate(Bundle paramBundle)
  {
    int i = 0;
    super.onCreate(paramBundle);
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onCreate";
    QLog.i("System.out", str2);
    QQApplication localQQApplication = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    setVolumeControlStream(3);
    SkinEngine localSkinEngine = new SkinEngine(this);
    this.jdField_a_of_type_ComTencentMobileqqSkinSkinEngine = localSkinEngine;
    String str3 = getSharedPreferences("skin", i).getString("skin", "qq_skin_blue");
    this.b = str3;
    if (SkinHashMap.skinId.trim().length() != 0)
    {
      String str4 = this.b.trim();
      String str5 = SkinHashMap.skinId.trim();
      if (str4.equals(str5))
        break label278;
    }
    Context localContext = getApplicationContext();
    StringBuilder localStringBuilder2 = new StringBuilder().append("skin/");
    String str6 = this.b;
    String str7 = str6 + ".zip";
    StringBuilder localStringBuilder3 = new StringBuilder();
    String str8 = getBaseContext().getFilesDir().toString();
    String str9 = str8 + "/Skin/";
    SkinUtil.Unzip(localContext, str7, str9);
    SkinHashMap.clearFilterMap();
    StringBuilder localStringBuilder4 = new StringBuilder();
    String str10 = getBaseContext().getFilesDir().toString();
    SkinUtil.ParseSkinXml(str10 + "/Skin/", "skinmain.xml");
    label278: SkinFactory localSkinFactory1 = new SkinFactory();
    this.jdField_a_of_type_ComTencentMobileqqSkinSkinFactory = localSkinFactory1;
    LayoutInflater localLayoutInflater = getLayoutInflater();
    SkinFactory localSkinFactory2 = this.jdField_a_of_type_ComTencentMobileqqSkinSkinFactory;
    localLayoutInflater.setFactory(localSkinFactory2);
    if (sensorEventListener == null)
      sensorEventListener = new ScreenShotSensorEventListener();
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    String str11 = getString(2131296371);
    if (!localSharedPreferences.getBoolean(str11, i))
      return;
    SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
    ScreenShotSensorEventListener localScreenShotSensorEventListener = sensorEventListener;
    Sensor localSensor = super.getDefaultSensor(1);
    super.registerListener(localScreenShotSensorEventListener, localSensor, i);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass = super.getClass();
    localQQApplication.a(localClass);
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onDestroy ";
    QLog.i("System.out", str2);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    int i = 4;
    int j;
    if (paramInt == i)
    {
      boolean bool1 = a();
      if (bool1)
        j = 1;
    }
    while (true)
    {
      return j;
      boolean bool2 = super.onKeyDown(paramInt, paramKeyEvent);
      continue;
      bool2 = super.onKeyDown(paramInt, paramKeyEvent);
    }
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    return super.onKeyUp(paramInt, paramKeyEvent);
  }

  protected void onPause()
  {
    super.onPause();
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onPause";
    QLog.i("System.out", str2);
  }

  protected void onRestoreInstanceState(Bundle paramBundle)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onRestoreInstanceState " + paramBundle;
    QLog.i("System.out", str2);
    super.onRestoreInstanceState(paramBundle);
  }

  protected void onResume()
  {
    int i = 1;
    super.onResume();
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onResume";
    QLog.i("System.out", str2);
    sensorEventListener.a = this;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.d();
    int j = getRequestedOrientation();
    if (j != 0)
    {
      Object localObject = PreferenceManager.getDefaultSharedPreferences(this);
      String str3 = getString(2131296356);
      localObject = ((SharedPreferences)localObject).getBoolean(str3, i);
      if (localObject == 0)
        break label184;
      int k = 2;
      setRequestedOrientation(k);
    }
    while (true)
    {
      SkinEngine localSkinEngine = this.jdField_a_of_type_ComTencentMobileqqSkinSkinEngine;
      String str4 = ((BaseActivity)localSkinEngine.a).getSharedPreferences("skin", 0).getString("skin", "qq_skin_blue");
      String str5 = ((BaseActivity)localSkinEngine.a).b.trim();
      String str6 = str4.trim();
      if (!str5.equals(str6))
        ((BaseActivity)localSkinEngine.a).a();
      return;
      label184: setRequestedOrientation(i);
    }
  }

  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onSaveInstanceState " + paramBundle;
    QLog.i("System.out", str2);
  }

  protected void onStart()
  {
    super.onStart();
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onStart";
    QLog.i("System.out", str2);
  }

  protected void onStop()
  {
    super.onStop();
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onStop";
    QLog.i("System.out", str2);
  }

  protected void onUserLeaveHint()
  {
    super.onUserLeaveHint();
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onUserLeaveHint ";
    QLog.i("System.out", str2);
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(this);
  }

  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if (!isMoveTaskToBack(this, paramIntent))
      paramIntent.addFlags(262144);
    super.startActivityForResult(paramIntent, paramInt);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.BaseActivity
 * JD-Core Version:    0.5.4
 */