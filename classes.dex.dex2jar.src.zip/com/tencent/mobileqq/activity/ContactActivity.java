package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.hardware.SensorManager;
import android.net.Uri;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cg;
import ch;
import com.tencent.mobileqq.adapter.FriendListAdapter;
import com.tencent.mobileqq.adapter.FriendListAdapter.QueryHandler;
import com.tencent.mobileqq.adapter.RecentListAdapter;
import com.tencent.mobileqq.adapter.TroopListAdapter;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.app.ScreenShotSensorEventListener;
import com.tencent.mobileqq.content.FriendList;
import com.tencent.mobileqq.content.MessageProvider;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.RecentUser;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.data.TroopSelfInfo;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.friendlist.FriendListUtil;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.utils.Chatter;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.mobileqq.widget.CustomDrawable1;
import com.tencent.mobileqq.widget.CustomedTabWidget;
import com.tencent.mobileqq.widget.Workspace;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseApplication;
import com.tencent.qphone.base.util.BaseServiceHelper;
import cs;
import ct;
import cu;
import cv;
import cw;
import cx;
import cy;
import cz;
import dg;
import dh;
import di;
import dj;
import dk;
import dl;
import dm;
import dn;
import do;
import dp;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.Vector;

public class ContactActivity extends BaseActivity
  implements View.OnClickListener, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener, ExpandableListView.OnChildClickListener, AppConstants
{
  private static final int DIALOG_YES_EXIT_LONG_MESSAGE = 3;
  private static final int DIALOG_YES_NO_LONG_MESSAGE = 2;
  private static final int MSG_BACK = 10002;
  public static final int MSG_CHECK_SWITCH_RECENT = 1006;
  public static final int MSG_REFRESH_FRIENDLIST = 1007;
  public static final int MSG_UPDATE_FRIENDLIST = 1005;
  public static final int MSG_UPDATE_HEADER = 10000;
  public static final int MSG_UPDATE_ITEM = 1003;
  public static final int MSG_UPDATE_STATUS_INFO = 10001;
  private static final int MSG_UPDATE_TROOP = 1004;
  private float jdField_a_of_type_Float;
  private int jdField_a_of_type_Int;
  public long a;
  public WifiManager.WifiLock a;
  public Handler a;
  public View a;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private ExpandableListView jdField_a_of_type_AndroidWidgetExpandableListView;
  private ImageButton jdField_a_of_type_AndroidWidgetImageButton;
  public ImageView a;
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  public ListView a;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  public FriendListAdapter a;
  private QQServiceEntry jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
  public VideoController a;
  private CustomedTabWidget jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget;
  public Workspace a;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  public String a;
  private Timer jdField_a_of_type_JavaUtilTimer;
  public boolean a;
  Bitmap[] jdField_a_of_type_ArrayOfAndroidGraphicsBitmap;
  private int jdField_b_of_type_Int;
  public long b;
  View jdField_b_of_type_AndroidViewView;
  private Button jdField_b_of_type_AndroidWidgetButton;
  ImageView jdField_b_of_type_AndroidWidgetImageView;
  private LinearLayout jdField_b_of_type_AndroidWidgetLinearLayout;
  public ListView b;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  public QQApplication b;
  public String b;
  boolean jdField_b_of_type_Boolean;
  private View jdField_c_of_type_AndroidViewView;
  ImageView jdField_c_of_type_AndroidWidgetImageView;
  private TextView jdField_c_of_type_AndroidWidgetTextView;
  public String c;
  public boolean c;
  private ImageView jdField_d_of_type_AndroidWidgetImageView;
  private TextView jdField_d_of_type_AndroidWidgetTextView;
  public String d;
  private boolean jdField_d_of_type_Boolean;
  private String e;
  private String f;

  public ContactActivity()
  {
    String str = super.getClass().getSimpleName();
    this.e = str;
    Bitmap[] arrayOfBitmap = new Bitmap[2];
    this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap = arrayOfBitmap;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_c_of_type_JavaLangString = "";
    this.jdField_b_of_type_Boolean = null;
    this.jdField_c_of_type_Boolean = null;
    do localdo = new do(this);
    this.jdField_a_of_type_AndroidOsHandler = localdo;
    ch localch = new ch(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localch;
    this.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock = null;
  }

  private void a(int paramInt)
  {
    boolean bool = true;
    int i = 0;
    Object localObject1 = LayoutInflater.from(this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.getContext());
    Object localObject4 = null;
    localObject1 = (ViewGroup)((LayoutInflater)localObject1).inflate(2130903085, (ViewGroup)localObject4);
    ImageView localImageView = (ImageView)((ViewGroup)localObject1).getChildAt(paramInt);
    ((ViewGroup)localObject1).removeAllViews();
    int l = 2;
    Object localObject5;
    int k;
    float f2;
    float f3;
    Canvas localCanvas;
    Paint localPaint;
    Object localObject6;
    Object localObject3;
    if (paramInt == l)
    {
      this.jdField_b_of_type_AndroidWidgetImageView = localImageView;
      Object localObject2 = this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap;
      localObject4 = BitmapFactory.decodeResource(getResources(), 2130838053);
      localObject2[i] = localObject4;
      localObject4 = this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap;
      localObject2 = this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap[i];
      localObject5 = Bitmap.Config.ARGB_8888;
      localObject5 = ((Bitmap)localObject2).copy((Bitmap.Config)localObject5, bool);
      ((Bitmap)localObject5).getWidth();
      ((Bitmap)localObject5).getHeight();
      int j = this.jdField_a_of_type_Float;
      k = (int)(1082130432 * j);
      float f1 = ((Bitmap)localObject5).getWidth();
      f2 = k;
      f2 = f1 - f2;
      f1 = k;
      int i1 = this.jdField_a_of_type_Float;
      f3 = 1073741824 * i1 + f1;
      localCanvas = new Canvas((Bitmap)localObject5);
      localPaint = new Paint();
      localObject6 = 39168;
      localObject3 = (Integer)SkinEngine.getSkinData("codecolor_tab_balloon", "codecolor");
      if (localObject3 == null)
        break label280;
      localObject3 = ((Integer)localObject3).intValue();
    }
    while (true)
    {
      localPaint.setColor(localObject3);
      float f4 = k;
      localCanvas.drawCircle(f2, f3, localObject3, localPaint);
      localObject4[bool] = localObject5;
      View localView = findViewById(16908292);
      this.jdField_b_of_type_AndroidViewView = ((View)localObject3);
      this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.addView(localImageView);
      return;
      label280: localObject3 = localObject6;
    }
  }

  private void a(String paramString, int paramInt)
  {
    this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1].putExtra("uin", paramString);
    this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1].putExtra("uin type", paramInt);
    Intent localIntent = new Intent(this, HomeActivity.class).addCategory("android.intent.category.CHAT").addFlags(536870912);
    startActivity(localIntent);
  }

  // ERROR //
  private void b(boolean paramBoolean)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: invokevirtual 563	com/tencent/mobileqq/activity/ContactActivity:getContentResolver	()Landroid/content/ContentResolver;
    //   6: astore_3
    //   7: getstatic 569	com/tencent/mobileqq/content/FriendList:TROOP_LIST_URI	Landroid/net/Uri;
    //   10: astore 4
    //   12: aconst_null
    //   13: astore 5
    //   15: aconst_null
    //   16: astore 6
    //   18: aconst_null
    //   19: astore 7
    //   21: aload_3
    //   22: aload 4
    //   24: aconst_null
    //   25: aload 5
    //   27: aload 6
    //   29: aload 7
    //   31: invokevirtual 575	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   34: astore_3
    //   35: aload_3
    //   36: ifnull +16 -> 52
    //   39: aload_3
    //   40: invokeinterface 381 1 0
    //   45: astore 4
    //   47: iload 4
    //   49: ifgt +4 -> 53
    //   52: return
    //   53: aload_3
    //   54: invokeinterface 381 1 0
    //   59: astore 4
    //   61: iload 4
    //   63: anewarray 577	java/lang/String
    //   66: astore 5
    //   68: aload_3
    //   69: invokeinterface 385 1 0
    //   74: pop
    //   75: iload_2
    //   76: istore 4
    //   78: aload_3
    //   79: invokeinterface 580 1 0
    //   84: ifne +91 -> 175
    //   87: aload_3
    //   88: ldc_w 582
    //   91: invokeinterface 586 2 0
    //   96: astore 8
    //   98: aload_3
    //   99: iload 8
    //   101: invokeinterface 587 2 0
    //   106: astore 9
    //   108: aload 5
    //   110: iload 4
    //   112: aload 9
    //   114: aastore
    //   115: iinc 4 1
    //   118: aload_3
    //   119: invokeinterface 402 1 0
    //   124: pop
    //   125: goto -47 -> 78
    //   128: astore 4
    //   130: aload_3
    //   131: invokeinterface 590 1 0
    //   136: aload 5
    //   138: arraylength
    //   139: newarray int
    //   141: astore 6
    //   143: iload_2
    //   144: istore_3
    //   145: aload 6
    //   147: arraylength
    //   148: istore 4
    //   150: iload_3
    //   151: iload 4
    //   153: if_icmpge +48 -> 201
    //   156: iload_1
    //   157: ifeq +38 -> 195
    //   160: iload_2
    //   161: istore 4
    //   163: aload 6
    //   165: iload_3
    //   166: iload 4
    //   168: iastore
    //   169: iinc 3 1
    //   172: goto -27 -> 145
    //   175: aload_3
    //   176: invokeinterface 590 1 0
    //   181: goto -45 -> 136
    //   184: astore 10
    //   186: aload_3
    //   187: invokeinterface 590 1 0
    //   192: aload 10
    //   194: athrow
    //   195: iconst_1
    //   196: istore 4
    //   198: goto -35 -> 163
    //   201: aload_0
    //   202: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   205: aload 5
    //   207: aload 6
    //   209: invokevirtual 593	com/tencent/mobileqq/app/QQApplication:a	([Ljava/lang/String;[I)[I
    //   212: astore 11
    //   214: aload_0
    //   215: getfield 105	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_AndroidOsHandler	Landroid/os/Handler;
    //   218: sipush 1004
    //   221: invokevirtual 597	android/os/Handler:sendEmptyMessage	(I)Z
    //   224: pop
    //   225: aload_0
    //   226: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   229: invokevirtual 600	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/util/BaseServiceHelper;
    //   232: astore 12
    //   234: aload_0
    //   235: getfield 110	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener	Lcom/tencent/qphone/base/util/BaseActionListener;
    //   238: astore 13
    //   240: aload_0
    //   241: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   244: invokevirtual 603	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   247: invokevirtual 608	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   250: astore 14
    //   252: aload 12
    //   254: aload 13
    //   256: aload 14
    //   258: aload 5
    //   260: aload 6
    //   262: aload 11
    //   264: invokestatic 614	com/tencent/mobileqq/service/profile/ProfileUtil:SvcRequestBatchSetGroupFilter	(Lcom/tencent/qphone/base/util/BaseServiceHelper;Lcom/tencent/qphone/base/util/BaseActionListener;Ljava/lang/String;[Ljava/lang/String;[I[I)V
    //   267: goto -215 -> 52
    //
    // Exception table:
    //   from	to	target	type
    //   68	125	128	java/lang/Exception
    //   68	125	184	finally
  }

  private void c()
  {
    b();
    if (this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter != null)
      this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter.notifyDataSetChanged(null);
    if (this.jdField_b_of_type_AndroidWidgetListView.getAdapter() == null)
      return;
    ((CursorAdapter)this.jdField_b_of_type_AndroidWidgetListView.getAdapter()).notifyDataSetChanged();
  }

  private static boolean checkAbility()
  {
    return true;
  }

  private void d()
  {
    ImageView localImageView = (ImageView)findViewById(2131493078);
    if (this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a() == null);
    while (true)
    {
      return;
      String str = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      if (getSharedPreferences(str, 0).getLong("getProfileStatus", 11L) == 41L)
        localImageView.setImageResource(2130838038);
      localImageView.setImageResource(2130838040);
    }
  }

  private void e()
  {
    Object localObject1 = this.jdField_a_of_type_AndroidWidgetListView.getAdapter();
    if (localObject1 == null);
    while (true)
    {
      return;
      this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a.clear();
      localObject1 = ((CursorAdapter)this.jdField_a_of_type_AndroidWidgetListView.getAdapter()).getCursor();
      if (localObject1 != null)
      {
        int i = ((Cursor)localObject1).getColumnIndex("uin");
        int j = ((Cursor)localObject1).getColumnIndex("type");
        int k = ((Cursor)localObject1).getCount();
        ((Cursor)localObject1).moveToFirst();
        Object localObject2 = null;
        while (localObject2 < k)
        {
          int l = ((Cursor)localObject1).getInt(j);
          String str = ((Cursor)localObject1).getString(i);
          Vector localVector = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a;
          Chatter localChatter = new Chatter(str, l);
          localVector.add(localChatter);
          ++localObject2;
        }
      }
      QQApplication localQQApplication = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      Boolean localBoolean = Boolean.valueOf(true);
      localQQApplication.a(localBoolean);
    }
  }

  // ERROR //
  private void f()
  {
    // Byte code:
    //   0: ldc2_w 680
    //   3: lstore_1
    //   4: sipush 1004
    //   7: istore_3
    //   8: iconst_0
    //   9: istore 4
    //   11: aload_0
    //   12: invokevirtual 563	com/tencent/mobileqq/activity/ContactActivity:getContentResolver	()Landroid/content/ContentResolver;
    //   15: astore 5
    //   17: getstatic 569	com/tencent/mobileqq/content/FriendList:TROOP_LIST_URI	Landroid/net/Uri;
    //   20: astore 6
    //   22: aconst_null
    //   23: astore 7
    //   25: aconst_null
    //   26: astore 8
    //   28: aconst_null
    //   29: astore 9
    //   31: aload 5
    //   33: aload 6
    //   35: aconst_null
    //   36: aload 7
    //   38: aload 8
    //   40: aload 9
    //   42: invokevirtual 575	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   45: astore 5
    //   47: aload 5
    //   49: ifnull +17 -> 66
    //   52: aload 5
    //   54: invokeinterface 381 1 0
    //   59: astore 6
    //   61: iload 6
    //   63: ifgt +4 -> 67
    //   66: return
    //   67: aload 5
    //   69: invokeinterface 381 1 0
    //   74: astore 6
    //   76: iload 6
    //   78: anewarray 577	java/lang/String
    //   81: astore 7
    //   83: aload 5
    //   85: invokeinterface 385 1 0
    //   90: pop
    //   91: iload 4
    //   93: istore 6
    //   95: aload 5
    //   97: invokeinterface 580 1 0
    //   102: ifne +139 -> 241
    //   105: aload 5
    //   107: ldc_w 582
    //   110: invokeinterface 586 2 0
    //   115: astore 10
    //   117: aload 5
    //   119: iload 10
    //   121: invokeinterface 587 2 0
    //   126: astore 11
    //   128: aload 7
    //   130: iload 6
    //   132: aload 11
    //   134: aastore
    //   135: iinc 6 1
    //   138: aload 5
    //   140: invokeinterface 402 1 0
    //   145: pop
    //   146: goto -51 -> 95
    //   149: astore 12
    //   151: aload 5
    //   153: invokeinterface 590 1 0
    //   158: aload_0
    //   159: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   162: invokevirtual 603	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   165: invokevirtual 608	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   168: astore 5
    //   170: aload_0
    //   171: aload 5
    //   173: iload 4
    //   175: invokevirtual 627	com/tencent/mobileqq/activity/ContactActivity:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   178: astore 13
    //   180: aload 13
    //   182: ldc_w 683
    //   185: lload_1
    //   186: invokeinterface 636 4 0
    //   191: astore 5
    //   193: ldc2_w 684
    //   196: lstore 14
    //   198: lload 16
    //   200: lload 14
    //   202: lcmp
    //   203: ifne +167 -> 370
    //   206: aload 7
    //   208: arraylength
    //   209: newarray int
    //   211: astore 8
    //   213: iload 4
    //   215: istore 5
    //   217: aload 8
    //   219: arraylength
    //   220: istore 18
    //   222: iload 5
    //   224: iload 18
    //   226: if_icmpge +37 -> 263
    //   229: aload 8
    //   231: iload 5
    //   233: iconst_1
    //   234: iastore
    //   235: iinc 5 1
    //   238: goto -21 -> 217
    //   241: aload 5
    //   243: invokeinterface 590 1 0
    //   248: goto -90 -> 158
    //   251: astore 19
    //   253: aload 5
    //   255: invokeinterface 590 1 0
    //   260: aload 19
    //   262: athrow
    //   263: aload_0
    //   264: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   267: aload 7
    //   269: aload 8
    //   271: invokevirtual 593	com/tencent/mobileqq/app/QQApplication:a	([Ljava/lang/String;[I)[I
    //   274: astore 20
    //   276: aload_0
    //   277: getfield 105	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_AndroidOsHandler	Landroid/os/Handler;
    //   280: iload_3
    //   281: invokevirtual 597	android/os/Handler:sendEmptyMessage	(I)Z
    //   284: pop
    //   285: aload_0
    //   286: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   289: invokevirtual 600	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/util/BaseServiceHelper;
    //   292: astore 21
    //   294: aload_0
    //   295: getfield 110	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener	Lcom/tencent/qphone/base/util/BaseActionListener;
    //   298: astore 22
    //   300: aload_0
    //   301: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   304: invokevirtual 603	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   307: invokevirtual 608	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   310: astore 23
    //   312: aload 21
    //   314: aload 22
    //   316: aload 23
    //   318: aload 7
    //   320: aload 8
    //   322: aload 20
    //   324: invokestatic 614	com/tencent/mobileqq/service/profile/ProfileUtil:SvcRequestBatchSetGroupFilter	(Lcom/tencent/qphone/base/util/BaseServiceHelper;Lcom/tencent/qphone/base/util/BaseActionListener;Ljava/lang/String;[Ljava/lang/String;[I[I)V
    //   327: ldc_w 687
    //   330: ldc_w 689
    //   333: invokestatic 695	com/tencent/qphone/base/util/QLog:v	(Ljava/lang/String;Ljava/lang/String;)V
    //   336: aload 13
    //   338: invokeinterface 699 1 0
    //   343: astore 24
    //   345: aload 24
    //   347: ldc_w 683
    //   350: ldc2_w 700
    //   353: invokeinterface 707 4 0
    //   358: pop
    //   359: aload 24
    //   361: invokeinterface 710 1 0
    //   366: pop
    //   367: goto -301 -> 66
    //   370: aload_0
    //   371: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   374: invokevirtual 712	com/tencent/mobileqq/app/QQApplication:b	()I
    //   377: ifne +126 -> 503
    //   380: lload 16
    //   382: lload_1
    //   383: lcmp
    //   384: lstore 16
    //   386: iload 5
    //   388: ifne +115 -> 503
    //   391: aload 7
    //   393: arraylength
    //   394: newarray int
    //   396: astore 8
    //   398: iload 4
    //   400: istore 5
    //   402: aload 8
    //   404: arraylength
    //   405: istore 25
    //   407: iload 5
    //   409: iload 25
    //   411: if_icmpge +16 -> 427
    //   414: aload 8
    //   416: iload 5
    //   418: iload 4
    //   420: iastore
    //   421: iinc 5 1
    //   424: goto -22 -> 402
    //   427: aload_0
    //   428: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   431: aload 7
    //   433: aload 8
    //   435: invokevirtual 593	com/tencent/mobileqq/app/QQApplication:a	([Ljava/lang/String;[I)[I
    //   438: astore 26
    //   440: aload_0
    //   441: getfield 105	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_AndroidOsHandler	Landroid/os/Handler;
    //   444: iload_3
    //   445: invokevirtual 597	android/os/Handler:sendEmptyMessage	(I)Z
    //   448: pop
    //   449: aload_0
    //   450: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   453: invokevirtual 600	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/util/BaseServiceHelper;
    //   456: astore 27
    //   458: aload_0
    //   459: getfield 110	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener	Lcom/tencent/qphone/base/util/BaseActionListener;
    //   462: astore 28
    //   464: aload_0
    //   465: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   468: invokevirtual 603	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   471: invokevirtual 608	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   474: astore 29
    //   476: aload 27
    //   478: aload 28
    //   480: aload 29
    //   482: aload 7
    //   484: aload 8
    //   486: aload 26
    //   488: invokestatic 614	com/tencent/mobileqq/service/profile/ProfileUtil:SvcRequestBatchSetGroupFilter	(Lcom/tencent/qphone/base/util/BaseServiceHelper;Lcom/tencent/qphone/base/util/BaseActionListener;Ljava/lang/String;[Ljava/lang/String;[I[I)V
    //   491: ldc_w 687
    //   494: ldc_w 714
    //   497: invokestatic 695	com/tencent/qphone/base/util/QLog:v	(Ljava/lang/String;Ljava/lang/String;)V
    //   500: goto -164 -> 336
    //   503: aload_0
    //   504: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   507: invokevirtual 600	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/util/BaseServiceHelper;
    //   510: astore 30
    //   512: aload_0
    //   513: getfield 110	com/tencent/mobileqq/activity/ContactActivity:jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener	Lcom/tencent/qphone/base/util/BaseActionListener;
    //   516: astore 31
    //   518: aload_0
    //   519: getfield 221	com/tencent/mobileqq/activity/ContactActivity:jdField_b_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   522: invokevirtual 603	com/tencent/mobileqq/app/QQApplication:a	()Lcom/tencent/qphone/base/remote/SimpleAccount;
    //   525: invokevirtual 608	com/tencent/qphone/base/remote/SimpleAccount:getUin	()Ljava/lang/String;
    //   528: astore 32
    //   530: aload 30
    //   532: aload 31
    //   534: aload 32
    //   536: aload 7
    //   538: invokestatic 718	com/tencent/mobileqq/service/profile/ProfileUtil:SvcRequestBatchGetGroupFilter	(Lcom/tencent/qphone/base/util/BaseServiceHelper;Lcom/tencent/qphone/base/util/BaseActionListener;Ljava/lang/String;[Ljava/lang/String;)V
    //   541: ldc_w 687
    //   544: ldc_w 720
    //   547: invokestatic 695	com/tencent/qphone/base/util/QLog:v	(Ljava/lang/String;Ljava/lang/String;)V
    //   550: goto -214 -> 336
    //
    // Exception table:
    //   from	to	target	type
    //   83	146	149	java/lang/Exception
    //   83	146	251	finally
  }

  private static void initNomediaFile()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = AppConstants.SDCARD_PATH;
    String str2 = str1 + ".nomedia";
    File localFile = new File(str2);
    if (!localFile.exists());
    try
    {
      localFile.createNewFile();
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  private static void startTranslateAnimaion(View paramView, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    AccelerateDecelerateInterpolator localAccelerateDecelerateInterpolator = new AccelerateDecelerateInterpolator();
    localTranslateAnimation.setInterpolator(localAccelerateDecelerateInterpolator);
    localTranslateAnimation.setDuration(500L);
    paramView.startAnimation(localTranslateAnimation);
  }

  public final void a()
  {
    boolean bool = null;
    ImageView localImageView = this.jdField_b_of_type_AndroidWidgetImageView;
    Bitmap localBitmap1;
    Object localObject2;
    if (localImageView != null)
    {
      int i = this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.jdField_a_of_type_Int;
      int j = 2;
      if (i != j)
        break label50;
      localObject1 = this.jdField_b_of_type_AndroidWidgetImageView;
      localBitmap1 = this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap[bool];
      localObject2 = localObject1;
    }
    label50: Bitmap localBitmap2;
    for (Object localObject1 = localBitmap1; ; localObject1 = localBitmap2)
    {
      ((ImageView)localObject2).setImageBitmap((Bitmap)localObject1);
      return;
      localObject1 = this.jdField_b_of_type_AndroidWidgetImageView;
      localObject2 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      Boolean localBoolean = Boolean.valueOf(bool);
      localObject2 = ((QQApplication)localObject2).a(localBoolean);
      if (localObject2 > 0);
      localBitmap2 = this.jdField_a_of_type_ArrayOfAndroidGraphicsBitmap[1];
      localObject2 = localObject1;
    }
  }

  public final void a(int paramInt, boolean paramBoolean)
  {
    this.jdField_b_of_type_Int = paramInt;
    if (paramBoolean)
      this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.a(paramInt);
    while (true)
    {
      return;
      this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.setCurrentScreen(paramInt);
      this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.setCurrentTab(paramInt);
    }
  }

  public final void a(boolean paramBoolean)
  {
    int i = null;
    String[] arrayOfString1 = null;
    if (!paramBoolean)
    {
      Object localObject = getContentResolver();
      Uri localUri = FriendList.TROOP_LIST_URI;
      String[] arrayOfString2 = arrayOfString1;
      String[] arrayOfString3 = arrayOfString1;
      String[] arrayOfString4 = arrayOfString1;
      localObject = ((ContentResolver)localObject).query(localUri, arrayOfString1, arrayOfString2, arrayOfString3, arrayOfString4);
      if ((localObject != null) && (((Cursor)localObject).getCount() > 0))
      {
        if (this.jdField_b_of_type_AndroidWidgetListView.getAdapter() != null)
          break label183;
        QQServiceEntry localQQServiceEntry = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
        TroopListAdapter localTroopListAdapter = new TroopListAdapter(this, localQQServiceEntry, (Cursor)localObject);
        this.jdField_b_of_type_AndroidWidgetListView.setAdapter(localTroopListAdapter);
        f();
        localObject = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        localObject = getSharedPreferences((String)localObject, i);
        if (!((SharedPreferences)localObject).getBoolean("troopNick", i))
        {
          QQApplication localQQApplication1 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
          cs localcs1 = new cs(this);
          localQQApplication1.a(localcs1);
          ((SharedPreferences)localObject).edit().putBoolean("troopNick", true).commit();
        }
      }
    }
    while (true)
    {
      return;
      label183: f();
      ((CursorAdapter)this.jdField_b_of_type_AndroidWidgetListView.getAdapter()).getCursor().requery();
      QQApplication localQQApplication2 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      cs localcs2 = new cs(this);
      localQQApplication2.a(localcs2);
      continue;
      BaseServiceHelper localBaseServiceHelper = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a();
      String str = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      FriendListUtil.getTroopList(localBaseServiceHelper, arrayOfString1, str, paramBoolean);
    }
  }

  public final void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    long l1 = 0L;
    int i = 0;
    String[] arrayOfString1 = null;
    Object localObject1;
    if (!paramBoolean1)
    {
      localObject1 = getContentResolver();
      Object localObject2 = FriendList.GROUP_LIST_CONTENT_URI;
      String[] arrayOfString2 = arrayOfString1;
      String[] arrayOfString3 = arrayOfString1;
      localObject1 = ((ContentResolver)localObject1).query((Uri)localObject2, arrayOfString1, arrayOfString2, arrayOfString3, "seqid");
      if (localObject1 != null)
      {
        localObject2 = ((Cursor)localObject1).getCount();
        if (localObject2 > 0)
        {
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter;
          if (localObject2 != null)
            break label381;
          QQServiceEntry localQQServiceEntry = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
          Message localMessage = this.jdField_a_of_type_AndroidOsHandler.obtainMessage(10001);
          localObject2 = new FriendListAdapter(this, localQQServiceEntry, (Cursor)localObject1, localMessage);
          this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter = ((FriendListAdapter)localObject2);
          ExpandableListView localExpandableListView1 = this.jdField_a_of_type_AndroidWidgetExpandableListView;
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter;
          ((ExpandableListView)localObject1).setAdapter((ExpandableListAdapter)localObject2);
          ExpandableListView localExpandableListView2 = this.jdField_a_of_type_AndroidWidgetExpandableListView;
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter;
          ((ExpandableListView)localObject1).setOnScrollListener((AbsListView.OnScrollListener)localObject2);
          ExpandableListView localExpandableListView3 = this.jdField_a_of_type_AndroidWidgetExpandableListView;
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter;
          ((ExpandableListView)localObject1).setOnGroupExpandListener((ExpandableListView.OnGroupExpandListener)localObject2);
          EntityManager localEntityManager = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
          String[] arrayOfString4 = arrayOfString1;
          localObject2 = ((EntityManager)localObject1).a(Friends.class, arrayOfString1, arrayOfString4, "datetime desc", "1");
          ((EntityManager)localObject1).a();
          if (this.jdField_a_of_type_JavaUtilTimer != null)
          {
            dp localdp = new dp(this);
            if (localObject2 != null)
            {
              long l2 = ((Friends)((List)localObject2).get(i)).datetime + -8960L;
              long l3 = System.currentTimeMillis();
              Object localObject3;
              long l4 = l2 - localObject3;
              Math.max(l1, l4);
            }
            cg localcg = new cg(this);
            Timer localTimer = this.jdField_a_of_type_JavaUtilTimer;
            long l5 = l1;
            localTimer.schedule(localcg, l5, -16608L);
          }
          if (paramBoolean2)
          {
            label312: FriendListAdapter localFriendListAdapter = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter;
            localFriendListAdapter.jdField_a_of_type_Int = i;
            FriendListAdapter.QueryHandler localQueryHandler = localFriendListAdapter.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter$QueryHandler;
            Uri localUri = FriendList.FRIEND_LIST_CONTENT_URI;
            String[] arrayOfString5 = new String[1];
            arrayOfString5[i] = "0";
            String[] arrayOfString6 = arrayOfString1;
            localQueryHandler.startQuery(-1, arrayOfString1, localUri, arrayOfString6, "groupid>=?", arrayOfString5, "status,name");
          }
        }
      }
    }
    while (true)
    {
      return;
      label381: this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter.setGroupCursor((Cursor)localObject1);
      break label312:
      BaseServiceHelper localBaseServiceHelper = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a();
      String str = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      FriendListUtil.getFriendGroupList(localBaseServiceHelper, str, paramBoolean1);
    }
  }

  protected final boolean a()
  {
    Object localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry.a();
    if ((localObject != null) && (((QQServiceEntry.Tag)localObject).a.getVisibility() == 0))
      ((QQServiceEntry.Tag)localObject).a.setVisibility(8);
    while (true)
    {
      return true;
      localObject = getParent();
      if ((localObject == null) || (!((Activity)localObject).moveTaskToBack(null)))
        continue;
      this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a((Context)localObject);
    }
  }

  public final void b()
  {
    String[] arrayOfString1 = null;
    if (this.jdField_a_of_type_AndroidWidgetListView.getAdapter() == null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Uri localUri1 = MessageProvider.RECENT_LIST_URI;
      localStringBuilder.append(localUri1);
      String str = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      localStringBuilder.append(str);
      localStringBuilder.append('/');
      localStringBuilder.append("RecentUser");
      ContentResolver localContentResolver = getContentResolver();
      Uri localUri2 = Uri.parse(localStringBuilder.toString());
      Object localObject = arrayOfString1;
      String[] arrayOfString2 = arrayOfString1;
      String[] arrayOfString3 = arrayOfString1;
      localObject = localContentResolver.query(localUri2, arrayOfString1, (String)localObject, arrayOfString2, arrayOfString3);
      if ((localObject != null) && (((Cursor)localObject).getCount() > 0))
      {
        QQServiceEntry localQQServiceEntry = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry;
        dm localdm = new dm(this);
        dn localdn = new dn(this);
        ContactActivity localContactActivity = this;
        RecentListAdapter localRecentListAdapter = new RecentListAdapter(localContactActivity, localQQServiceEntry, (Cursor)localObject, localdm, localdn);
        this.jdField_a_of_type_AndroidWidgetListView.setAdapter(localRecentListAdapter);
      }
      label173: if ((this.jdField_a_of_type_AndroidWidgetListView.getAdapter() == null) || (this.jdField_a_of_type_AndroidWidgetListView.getCount() <= 0))
        break label228;
      this.jdField_b_of_type_AndroidViewView.setVisibility(4);
    }
    while (true)
    {
      e();
      return;
      ((CursorAdapter)this.jdField_a_of_type_AndroidWidgetListView.getAdapter()).getCursor().requery();
      break label173:
      label228: this.jdField_b_of_type_AndroidViewView.setVisibility(0);
    }
  }

  public boolean onChildClick(ExpandableListView paramExpandableListView, View paramView, int paramInt1, int paramInt2, long paramLong)
  {
    String str = this.jdField_a_of_type_ComTencentMobileqqAdapterFriendListAdapter.getChild(paramInt1, paramInt2).getString(1);
    a(str, 0);
    this.jdField_d_of_type_Boolean = true;
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(1006, 500L);
    return true;
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131493028:
    case 2131493029:
    case 2131493027:
    }
    while (true)
    {
      return;
      this.jdField_b_of_type_Boolean = true;
      Intent localIntent1 = new Intent("android.intent.action.SEARCH").setType("qq/friend");
      startActivity(localIntent1);
      continue;
      Intent localIntent2 = new Intent(this, AddFriendActivity.class);
      startActivity(localIntent2);
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    ViewGroup localViewGroup = null;
    int i = 2131493024;
    int j = 2131493023;
    int k = 2131492865;
    int l = 1;
    super.onCreate(paramBundle);
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = AppConstants.SDCARD_PATH;
    String str2 = str1 + ".nomedia";
    File localFile = new File(str2);
    if (!localFile.exists());
    try
    {
      localFile.createNewFile();
      QQApplication localQQApplication1 = (QQApplication)getApplication();
      this.jdField_b_of_type_ComTencentMobileqqAppQQApplication = localQQApplication1;
      QQServiceEntry localQQServiceEntry = new QQServiceEntry(this);
      this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry = localQQServiceEntry;
      Timer localTimer = new Timer(l);
      this.jdField_a_of_type_JavaUtilTimer = localTimer;
      QQApplication localQQApplication2 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
      localQQApplication2.a(localBaseActionListener);
      setContentView(2130903059);
      int i1 = getResources().getDisplayMetrics().density;
      this.jdField_a_of_type_Float = i1;
      ImageView localImageView1 = (ImageView)findViewById(k);
      CustomDrawable1 localCustomDrawable1 = new CustomDrawable1(this);
      localImageView1.setImageDrawable(localCustomDrawable1);
      View localView1 = findViewById(2131492938);
      this.jdField_c_of_type_AndroidViewView = localView1;
      View localView2 = findViewById(2131493075);
      this.jdField_a_of_type_AndroidViewView = localView2;
      TextView localTextView1 = (TextView)findViewById(16908308);
      this.jdField_a_of_type_AndroidWidgetTextView = localTextView1;
      TextView localTextView2 = (TextView)findViewById(16908309);
      this.jdField_b_of_type_AndroidWidgetTextView = localTextView2;
      ImageView localImageView2 = (ImageView)findViewById(16908294);
      this.jdField_a_of_type_AndroidWidgetImageView = localImageView2;
      LinearLayout localLinearLayout1 = (LinearLayout)findViewById(2131493077);
      this.jdField_a_of_type_AndroidWidgetLinearLayout = localLinearLayout1;
      LinearLayout localLinearLayout2 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
      cz localcz = new cz(this);
      localLinearLayout2.setOnClickListener(localcz);
      ExpandableListView localExpandableListView1 = (ExpandableListView)findViewById(i);
      this.jdField_a_of_type_AndroidWidgetExpandableListView = localExpandableListView1;
      View localView3 = getLayoutInflater().inflate(2130903060, localViewGroup);
      ImageButton localImageButton = (ImageButton)localView3.findViewById(2131493027);
      this.jdField_a_of_type_AndroidWidgetImageButton = localImageButton;
      this.jdField_a_of_type_AndroidWidgetImageButton.setOnClickListener(this);
      ((TextView)localView3.findViewById(2131493028)).setOnClickListener(this);
      ImageView localImageView3 = (ImageView)localView3.findViewById(2131493029);
      this.jdField_c_of_type_AndroidWidgetImageView = localImageView3;
      this.jdField_c_of_type_AndroidWidgetImageView.setOnClickListener(this);
      this.jdField_a_of_type_AndroidWidgetExpandableListView.addHeaderView(localView3);
      ListView localListView1 = (ListView)findViewById(2131493026);
      this.jdField_a_of_type_AndroidWidgetListView = localListView1;
      this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this);
      this.jdField_a_of_type_AndroidWidgetListView.setOnItemLongClickListener(this);
      ListView localListView2 = (ListView)findViewById(j);
      this.jdField_b_of_type_AndroidWidgetListView = localListView2;
      this.jdField_b_of_type_AndroidWidgetListView.setOnItemClickListener(this);
      this.jdField_a_of_type_AndroidWidgetExpandableListView.setOnChildClickListener(this);
      ExpandableListView localExpandableListView2 = this.jdField_a_of_type_AndroidWidgetExpandableListView;
      dj localdj = new dj(this);
      localExpandableListView2.setOnItemLongClickListener(localdj);
      CustomedTabWidget localCustomedTabWidget1 = (CustomedTabWidget)findViewById(2131493022);
      this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget = localCustomedTabWidget1;
      findViewById(j);
      a(0);
      findViewById(i);
      a(l);
      findViewById(2131493025);
      a(2);
      Workspace localWorkspace = (Workspace)findViewById(16908305);
      this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace = localWorkspace;
      CustomedTabWidget localCustomedTabWidget2 = this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget;
      dk localdk = new dk(this);
      localCustomedTabWidget2.setSwitchTabCallback(localdk);
      TextView localTextView3 = (TextView)findViewById(2131492939);
      this.jdField_c_of_type_AndroidWidgetTextView = localTextView3;
      ImageView localImageView4 = (ImageView)findViewById(k);
      this.jdField_d_of_type_AndroidWidgetImageView = localImageView4;
      QQApplication localQQApplication3 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      dl localdl = new dl(this);
      localQQApplication3.jdField_a_of_type_AndroidOsHandler = localdl;
      QQApplication localQQApplication4 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
      Class localClass = super.getClass();
      Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
      localQQApplication4.a(localClass, localHandler);
      this.jdField_a_of_type_AndroidOsHandler.obtainMessage(10001, localViewGroup).sendToTarget();
      VideoController localVideoController = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a();
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = localVideoController;
      TextView localTextView4 = (TextView)findViewById(2131492982);
      this.jdField_d_of_type_AndroidWidgetTextView = localTextView4;
      Button localButton1 = (Button)findViewById(2131492983);
      this.jdField_a_of_type_AndroidWidgetButton = localButton1;
      Button localButton2 = (Button)findViewById(2131492984);
      this.jdField_b_of_type_AndroidWidgetButton = localButton2;
      LinearLayout localLinearLayout3 = (LinearLayout)findViewById(2131492979);
      this.jdField_b_of_type_AndroidWidgetLinearLayout = localLinearLayout3;
      this.jdField_d_of_type_AndroidWidgetTextView.setText(2131296419);
      Button localButton3 = this.jdField_a_of_type_AndroidWidgetButton;
      dh localdh = new dh(this);
      localButton3.setOnClickListener(localdh);
      Button localButton4 = this.jdField_b_of_type_AndroidWidgetButton;
      di localdi = new di(this);
      localButton4.setOnClickListener(localdi);
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i = 2131296395;
    switch (paramInt)
    {
    default:
      int j = 0;
      label30: return j;
    case 2:
    case 3:
    }
    Object localObject = new AlertDialog.Builder(this);
    String str1 = this.jdField_a_of_type_JavaLangString;
    localObject = ((AlertDialog.Builder)localObject).setTitle(str1);
    String str2 = this.jdField_b_of_type_JavaLangString;
    localObject = ((AlertDialog.Builder)localObject).setMessage(str2);
    if (paramInt == 3)
    {
      cv localcv = new cv(this);
      ((AlertDialog.Builder)localObject).setPositiveButton(i, localcv);
      cw localcw = new cw(this);
      ((AlertDialog.Builder)localObject).setNegativeButton(2131296397, i);
    }
    while (true)
    {
      localObject = ((AlertDialog.Builder)localObject).create();
      break label30:
      cx localcx = new cx(this);
      ((AlertDialog.Builder)localObject).setPositiveButton(i, localcx);
      cy localcy = new cy(this);
      ((AlertDialog.Builder)localObject).setNegativeButton(2131296396, i);
    }
  }

  protected void onDestroy()
  {
    ExpandableListAdapter localExpandableListAdapter = null;
    QQApplication localQQApplication1 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication1.b(localBaseActionListener);
    QQApplication localQQApplication2 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass1 = super.getClass();
    localQQApplication2.a(localClass1);
    this.jdField_a_of_type_JavaUtilTimer.cancel();
    this.jdField_a_of_type_JavaUtilTimer.purge();
    this.jdField_a_of_type_JavaUtilTimer = localExpandableListAdapter;
    if (this.jdField_a_of_type_AndroidWidgetExpandableListView.getExpandableListAdapter() != null)
    {
      ((FriendListAdapter)this.jdField_a_of_type_AndroidWidgetExpandableListView.getExpandableListAdapter()).getCursor().close();
      this.jdField_a_of_type_AndroidWidgetExpandableListView.setAdapter(localExpandableListAdapter);
    }
    if (this.jdField_a_of_type_AndroidWidgetListView.getAdapter() != null)
    {
      ((CursorAdapter)this.jdField_a_of_type_AndroidWidgetListView.getAdapter()).getCursor().close();
      this.jdField_a_of_type_AndroidWidgetListView.setAdapter(localExpandableListAdapter);
    }
    if (this.jdField_b_of_type_AndroidWidgetListView.getAdapter() != null)
    {
      ((CursorAdapter)this.jdField_b_of_type_AndroidWidgetListView.getAdapter()).getCursor().close();
      this.jdField_b_of_type_AndroidWidgetListView.setAdapter(localExpandableListAdapter);
    }
    super.onDestroy();
    QQApplication localQQApplication3 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass2 = super.getClass();
    localQQApplication3.a(localClass2);
    this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.jdField_b_of_type_Boolean = null;
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i = 1;
    int j = 0;
    Object localObject1 = (Cursor)((CursorAdapter)paramAdapterView.getAdapter()).getItem(paramInt);
    EntityManager localEntityManager = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    ListView localListView = this.jdField_a_of_type_AndroidWidgetListView;
    if (paramAdapterView == localListView)
    {
      long l1 = ((Cursor)localObject1).getLong(j);
      Object localObject2;
      localObject1 = (RecentUser)localEntityManager.a(RecentUser.class, localObject2);
      if (localObject1 != null)
      {
        if (((RecentUser)localObject1).type != 0)
          break label129;
        String str1 = String.valueOf(((RecentUser)localObject1).uin);
        a((String)localObject1, j);
      }
    }
    while (true)
    {
      localEntityManager.a();
      this.jdField_d_of_type_Boolean = i;
      this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(1006, 500L);
      return;
      label129: String str2 = String.valueOf(((RecentUser)localObject1).uin);
      a((String)localObject1, i);
      continue;
      long l2 = ((Cursor)localObject1).getLong(j);
      Object localObject3;
      localObject1 = (TroopSelfInfo)localEntityManager.a(TroopSelfInfo.class, localObject3);
      if (localObject1 == null)
        continue;
      String str3 = String.valueOf(((TroopSelfInfo)localObject1).troopuin);
      a((String)localObject1, i);
    }
  }

  public boolean onItemLongClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    Object localObject2 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    long l = ((Cursor)((CursorAdapter)paramAdapterView.getAdapter()).getItem(paramInt)).getLong(0);
    Object localObject3;
    Object localObject1 = (RecentUser)((EntityManager)localObject2).a(RecentUser.class, localObject3);
    if (((RecentUser)localObject1).type == 0)
    {
      String str1 = String.valueOf(((RecentUser)localObject1).uin);
      localObject2 = (Friends)((EntityManager)localObject2).a(Friends.class, str1);
      if (((RecentUser)localObject1).uin != 10000L);
    }
    for (localObject1 = "绯荤"; ; localObject1 = ((TroopInfo)localObject2).troopname)
      while (true)
      {
        this.f = ((String)localObject1);
        this.jdField_a_of_type_Int = paramInt;
        AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(this);
        String str2 = this.f;
        AlertDialog.Builder localBuilder2 = ((AlertDialog.Builder)localObject1).setTitle(str2);
        dg localdg = new dg(this);
        ((AlertDialog.Builder)localObject1).setItems(2131165186, localdg).create().show();
        return true;
        if (localObject2 == null)
          localObject1 = String.valueOf(((RecentUser)localObject1).uin);
        localObject1 = ((Friends)localObject2).name;
        continue;
        String str3 = String.valueOf(((RecentUser)localObject1).uin);
        localObject2 = (TroopInfo)((EntityManager)localObject2).a(TroopInfo.class, str3);
        if (localObject2 != null)
          break;
        localObject1 = String.valueOf(((RecentUser)localObject1).uin);
      }
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    int i = 2131296286;
    int j = 2131296261;
    int k = 10001;
    int l = 0;
    int i1 = 1;
    int i2 = paramMenuItem.getItemId();
    switch (i2)
    {
    case 2131493163:
    case 2131493164:
    case 2131493165:
    case 2131493166:
    default:
    case 2131493168:
    case 2131493167:
    case 2131493169:
    case 2131493160:
    case 2131493161:
    case 2131493162:
    case 2131493170:
    }
    while (true)
    {
      return i1;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(this).setTitle(2131296305).setMessage(2131296306);
      cu localcu = new cu(this);
      AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131296380, localcu);
      ct localct = new ct(this);
      localBuilder2.setNegativeButton(2131296382, localct).create().show();
      continue;
      if (!BaseApplication.isNetSupport())
        Toast.makeText(this, i, l).show();
      Handler localHandler1 = this.jdField_a_of_type_AndroidOsHandler;
      String str1 = getString(j);
      localHandler1.obtainMessage(k, j).sendToTarget();
      a(i1, l);
      continue;
      if (!BaseApplication.isNetSupport())
        Toast.makeText(this, i, l).show();
      Handler localHandler2 = this.jdField_a_of_type_AndroidOsHandler;
      String str2 = getString(j);
      localHandler2.obtainMessage(k, j).sendToTarget();
      a(i1);
      continue;
      Intent localIntent1 = new Intent(this, SettingActivity.class);
      startActivity(localIntent1);
      continue;
      finish();
      Intent localIntent2 = new Intent(this, HomeActivity.class).putExtra("need login", i1);
      startActivity(localIntent2);
      continue;
      SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
      ScreenShotSensorEventListener localScreenShotSensorEventListener = BaseActivity.sensorEventListener;
      localSensorManager.unregisterListener(localScreenShotSensorEventListener);
      finish();
      continue;
      boolean bool = QQApplication.isNetSupport();
      if (bool)
      {
        int i3 = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.b();
        if (i3 == i1)
          b(l);
        if (i3 != 0)
          continue;
        b(i1);
      }
      Toast.makeText(this, 2131296302, l).show();
    }
  }

  protected void onPause()
  {
    super.onPause();
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry.b();
  }

  protected void onPostResume()
  {
    super.onPostResume();
    this.jdField_d_of_type_Boolean = null;
    c();
    a();
    d();
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(10000);
  }

  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    int i = null;
    int j = 1;
    paramMenu.clear();
    MenuInflater localMenuInflater = getMenuInflater();
    int k = this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.jdField_a_of_type_Int;
    switch (k)
    {
    default:
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      return j;
      localMenuInflater.inflate(2131427334, paramMenu);
      int l = this.jdField_b_of_type_ComTencentMobileqqAppQQApplication.b();
      MenuItem localMenuItem = paramMenu.getItem(j);
      if (localMenuInflater == j)
      {
        localMenuItem.setTitle(2131296340);
        localMenuItem.setIcon(2130837928);
      }
      localMenuItem.setTitle(2131296339);
      localMenuItem.setIcon(2130837925);
      continue;
      localMenuInflater.inflate(2131427331, paramMenu);
      continue;
      localMenuInflater.inflate(2131427333, paramMenu);
      if ((this.jdField_a_of_type_AndroidWidgetListView.getAdapter() != null) && (this.jdField_a_of_type_AndroidWidgetListView.getCount() > 0))
        continue;
      paramMenu.getItem(i).setEnabled(i);
    }
  }

  protected void onResume()
  {
    super.onResume();
    if (this.jdField_c_of_type_AndroidWidgetImageView != null)
    {
      int i = this.jdField_c_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable1 = this.jdField_c_of_type_AndroidWidgetImageView.getDrawable();
      Drawable localDrawable2 = SkinEngine.getSkinDrawable(i, "src", localDrawable1);
      this.jdField_c_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable2);
    }
    this.jdField_a_of_type_ComTencentMobileqqWidgetCustomedTabWidget.setColorFilterForSelectBar();
    this.jdField_b_of_type_Boolean = null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ContactActivity
 * JD-Core Version:    0.5.4
 */