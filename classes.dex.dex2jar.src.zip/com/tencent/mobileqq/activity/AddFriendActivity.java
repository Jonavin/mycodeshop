package com.tencent.mobileqq.activity;

import a;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.TroopMemberInfo;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.friendlist.FriendListUtil;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;

public class AddFriendActivity extends BaseActivity
  implements View.OnClickListener, AdapterView.OnItemClickListener
{
  private AlertDialog jdField_a_of_type_AndroidAppAlertDialog;
  private ProgressDialog jdField_a_of_type_AndroidAppProgressDialog;
  private InputMethodManager jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private ListView jdField_a_of_type_AndroidWidgetListView;
  private final Friends jdField_a_of_type_ComTencentMobileqqDataFriends;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private AlertDialog b;

  public AddFriendActivity()
  {
    Friends localFriends = new Friends();
    this.jdField_a_of_type_ComTencentMobileqqDataFriends = localFriends;
    a locala = new a(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = locala;
  }

  private void a(Dialog paramDialog, String paramString)
  {
    this.jdField_a_of_type_AndroidAppProgressDialog.dismiss();
    this.jdField_a_of_type_AndroidAppAlertDialog.dismiss();
    AlertDialog localAlertDialog = this.jdField_a_of_type_AndroidAppAlertDialog;
    if (paramDialog == localAlertDialog)
    {
      this.jdField_a_of_type_AndroidAppAlertDialog.setMessage(paramString);
      this.jdField_a_of_type_AndroidAppAlertDialog.show();
    }
    while (true)
    {
      return;
      this.jdField_a_of_type_AndroidAppProgressDialog.setMessage(paramString);
      this.jdField_a_of_type_AndroidAppProgressDialog.show();
    }
  }

  private void b(String paramString)
  {
    EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Friends localFriends = (Friends)localEntityManager.a(Friends.class, paramString);
    localEntityManager.a();
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin().equals(paramString))
    {
      AlertDialog localAlertDialog1 = this.jdField_a_of_type_AndroidAppAlertDialog;
      a(localAlertDialog1, "鎮ㄤ笉鑳芥");
    }
    while (true)
    {
      return;
      if ((localFriends != null) && (localFriends.groupid >= 0))
      {
        AlertDialog localAlertDialog2 = this.jdField_a_of_type_AndroidAppAlertDialog;
        a(localAlertDialog2, "姝よ仈绯讳汉宸叉�");
      }
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      FriendListUtil.getUserAddFriendSetting(localBaseServiceHelper, str, paramString);
      ProgressDialog localProgressDialog = this.jdField_a_of_type_AndroidAppProgressDialog;
      a(localProgressDialog, "姝ｅ湪鎷夊�");
    }
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if ((paramInt1 != 1000) || (paramInt2 != -1))
      return;
    String str = this.jdField_a_of_type_ComTencentMobileqqDataFriends.uin;
    b(str);
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131492869:
    case 2131492877:
    }
    while (true)
    {
      return;
      String str1 = this.jdField_a_of_type_AndroidWidgetEditText.getEditableText().toString();
      ProgressDialog localProgressDialog = this.jdField_a_of_type_AndroidAppProgressDialog;
      a(localProgressDialog, "姝ｅ湪鏌�");
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      ProfileUtil.getSimpleInfo(localBaseServiceHelper, str2, str1, true);
      InputMethodManager localInputMethodManager = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
      IBinder localIBinder = paramView.getWindowToken();
      localInputMethodManager.hideSoftInputFromWindow(localIBinder, 0);
      continue;
      String str3 = (String)paramView.getTag();
      b(str3);
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
    Object localObject1 = (Button)findViewById(2131492869);
    Object localObject2 = (ImageView)findViewById(2131492871);
    this.jdField_a_of_type_AndroidWidgetImageView = ((ImageView)localObject2);
    localObject2 = (EditText)findViewById(2131492870);
    this.jdField_a_of_type_AndroidWidgetEditText = ((EditText)localObject2);
    localObject2 = (ListView)findViewById(2131492872);
    this.jdField_a_of_type_AndroidWidgetListView = ((ListView)localObject2);
    ((Button)localObject1).setOnClickListener(this);
    this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this);
    localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    localObject2 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    ((QQApplication)localObject1).a((BaseActionListener)localObject2);
    localObject1 = new ProgressDialog(this);
    this.jdField_a_of_type_AndroidAppProgressDialog = ((ProgressDialog)localObject1);
    localObject1 = new AlertDialog.Builder(this).setTitle("娣诲").setNegativeButton("纭", null).create();
    this.jdField_a_of_type_AndroidAppAlertDialog = ((AlertDialog)localObject1);
    localObject1 = (InputMethodManager)getSystemService("input_method");
    this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager = ((InputMethodManager)localObject1);
    localObject2 = getIntent().getStringExtra("uin");
    localObject1 = getIntent().getStringExtra("troopuin");
    if ((localObject2 == null) || (localObject1 == null))
      return;
    EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    String[] arrayOfString = new String[2];
    arrayOfString[0] = localObject1;
    arrayOfString[1] = localObject2;
    localObject1 = (TroopMemberInfo)localEntityManager.a(TroopMemberInfo.class, arrayOfString);
    localEntityManager.a();
    this.jdField_a_of_type_ComTencentMobileqqDataFriends.uin = ((String)localObject2);
    if (localObject1 != null)
    {
      Friends localFriends = this.jdField_a_of_type_ComTencentMobileqqDataFriends;
      String str = ((TroopMemberInfo)localObject1).friendnick;
      localFriends.name = ((String)localObject1);
    }
    b((String)localObject2);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.b(localBaseActionListener);
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str = ((TextView)paramView.findViewById(2131492864)).getText().toString();
    Intent localIntent = new Intent(this, InfoActivity.class).putExtra("infowhose", 0).putExtra("infouin", str).putExtra("addFriend", true);
    startActivityForResult(localIntent, 1000);
  }

  protected void onResume()
  {
    super.onResume();
    if (this.jdField_a_of_type_AndroidWidgetImageView == null)
      return;
    int i = this.jdField_a_of_type_AndroidWidgetImageView.getId();
    Drawable localDrawable1 = this.jdField_a_of_type_AndroidWidgetImageView.getDrawable();
    Drawable localDrawable2 = SkinEngine.getSkinDrawable(i, "src", localDrawable1);
    this.jdField_a_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.AddFriendActivity
 * JD-Core Version:    0.5.4
 */