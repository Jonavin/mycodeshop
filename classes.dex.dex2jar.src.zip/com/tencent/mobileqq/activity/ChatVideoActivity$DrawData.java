package com.tencent.mobileqq.activity;

public final class ChatVideoActivity$DrawData
{
  public int a;
  public byte[] a;

  public ChatVideoActivity$DrawData(ChatVideoActivity paramChatVideoActivity, byte[] paramArrayOfByte, int paramInt)
  {
    this.jdField_a_of_type_ArrayOfByte = paramArrayOfByte;
    this.jdField_a_of_type_Int = paramInt;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatVideoActivity.DrawData
 * JD-Core Version:    0.5.4
 */