package com.tencent.mobileqq.activity;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;
import ca;

public class ChatWindowActivity$MessageListView extends ListView
{
  ca a;

  public ChatWindowActivity$MessageListView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public ChatWindowActivity$MessageListView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    this.a.a(paramInt2, paramInt4);
  }

  public void setOnSizeChangedListener(ca paramca)
  {
    this.a = paramca;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatWindowActivity.MessageListView
 * JD-Core Version:    0.5.4
 */