package com.tencent.mobileqq.activity;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Time;
import android.view.Display;
import android.view.GestureDetector;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.gif.GIFDrawable;
import com.tencent.mobileqq.grouptransfile.GroupPicProcessor;
import com.tencent.mobileqq.service.message.MessageUtil;
import com.tencent.mobileqq.service.message.remote.MessageRecordInfo;
import com.tencent.mobileqq.service.message.storage.StorageMessage;
import com.tencent.mobileqq.service.message.storage.StorageMessageManager;
import com.tencent.mobileqq.service.storageutil.StorageManager;
import com.tencent.mobileqq.service.storageutil.Storageable;
import com.tencent.mobileqq.transfile.TransFileController;
import com.tencent.mobileqq.transfile.TransFileProcessor;
import com.tencent.mobileqq.transfile.TransfileUtile;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.mobileqq.widget.ImageSwitcherTouch;
import com.tencent.mobileqq.widget.ImageViewTouchBase;
import com.tencent.mobileqq.widget.ImageViewTouche;
import com.tencent.mobileqq.widget.RotateBitmap;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseApplication;
import com.tencent.qphone.base.util.BaseServiceHelper;
import fk;
import fl;
import fm;
import fo;
import fq;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PhotoPreview extends BaseActivity
  implements View.OnClickListener
{
  private static final int EXCEPTION_WHAT = 1;
  public static final int MAX_GROUPPIC_HEIGHT = 800;
  public static final int MAX_GROUPPIC_WIDTH = 600;
  public static final int MAX_THUMB_HEIGHT = 240;
  public static final int MAX_THUMB_WIDTH = 180;
  private static final int SUCCESS_WHAT = 0;
  public static final int TIMEOUT = 0;
  public static final int TIMEOUT_INT = 5000;
  public static final String TYPE = "type";
  public int a;
  private long jdField_a_of_type_Long;
  private Uri jdField_a_of_type_AndroidNetUri;
  private Handler jdField_a_of_type_AndroidOsHandler;
  public GestureDetector a;
  private View jdField_a_of_type_AndroidViewView;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  private ProgressBar jdField_a_of_type_AndroidWidgetProgressBar;
  private RelativeLayout jdField_a_of_type_AndroidWidgetRelativeLayout;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  public GIFDrawable a;
  private ImageSwitcherTouch jdField_a_of_type_ComTencentMobileqqWidgetImageSwitcherTouch;
  public ImageViewTouche a;
  fo jdField_a_of_type_Fo;
  public String a;
  private final ExecutorService jdField_a_of_type_JavaUtilConcurrentExecutorService;
  public boolean a;
  public int b;
  private long jdField_b_of_type_Long;
  private Button jdField_b_of_type_AndroidWidgetButton;
  private LinearLayout jdField_b_of_type_AndroidWidgetLinearLayout;
  private ProgressBar jdField_b_of_type_AndroidWidgetProgressBar;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  private String jdField_b_of_type_JavaLangString;
  public boolean b;
  private int jdField_c_of_type_Int;
  private Button jdField_c_of_type_AndroidWidgetButton;
  private LinearLayout jdField_c_of_type_AndroidWidgetLinearLayout;
  private String jdField_c_of_type_JavaLangString;
  private int jdField_d_of_type_Int;
  private Button jdField_d_of_type_AndroidWidgetButton;
  private String jdField_d_of_type_JavaLangString;
  private int jdField_e_of_type_Int;
  private Button jdField_e_of_type_AndroidWidgetButton;
  private Button f;
  private Button g;
  private Button h;
  private Button i;
  private Button j;
  private Button k;

  public PhotoPreview()
  {
    ExecutorService localExecutorService = Executors.newFixedThreadPool(2);
    this.jdField_a_of_type_JavaUtilConcurrentExecutorService = localExecutorService;
    this.jdField_d_of_type_Int = null;
    this.jdField_e_of_type_Int = null;
    fk localfk = new fk(this);
    this.jdField_a_of_type_AndroidOsHandler = localfk;
    this.jdField_a_of_type_Boolean = null;
    this.jdField_a_of_type_ComTencentMobileqqGifGIFDrawable = null;
  }

  private void a()
  {
    Intent localIntent1 = getIntent();
    localIntent1.putExtra("requestType", 12);
    String str = this.jdField_c_of_type_JavaLangString;
    localIntent1.putExtra("filePath", str);
    Intent localIntent2 = getIntent();
    setResult(-1, localIntent2);
  }

  private void b()
  {
    long l1 = 0L;
    int l = -1;
    boolean bool1 = null;
    int i1 = 1;
    Intent localIntent = new Intent();
    int i2 = this.jdField_d_of_type_Int;
    if (i2 != 0);
    try
    {
      Object localObject1 = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a().jdField_a_of_type_AndroidGraphicsBitmap;
      int i4 = ((Bitmap)localObject1).getWidth();
      int i5 = ((Bitmap)localObject1).getHeight();
      Object localObject3 = new Matrix();
      float f1 = this.jdField_d_of_type_Int;
      ((Matrix)localObject3).setRotate(f1);
      localObject1 = Bitmap.createBitmap((Bitmap)localObject1, 0, 0, i4, i5, (Matrix)localObject3, true);
      Object localObject5 = this.jdField_c_of_type_JavaLangString;
      FileOutputStream localFileOutputStream = new FileOutputStream((String)localObject5);
      localObject5 = Bitmap.CompressFormat.JPEG;
      ((Bitmap)localObject1).compress((Bitmap.CompressFormat)localObject5, 80, localFileOutputStream);
      label132: localObject1 = getIntent().getExtras().getInt("requestType", l);
      Object localObject4 = 9;
      if (localObject1 != localObject4)
      {
        int i3 = this.jdField_c_of_type_Int;
        long l3;
        if (i3 == i1)
        {
          localObject4 = this.jdField_c_of_type_JavaLangString;
          long l2 = new File((String)localObject4).length();
          l3 = 1048576L;
          Object localObject7;
          long l4;
          localObject7 <= l3;
          if (l2 > 0)
          {
            localObject2 = new StringBuilder();
            localObject4 = AppConstants.SDCARD_PATH;
            localObject2 = ((StringBuilder)localObject2).append((String)localObject4).append("photo/");
            localObject4 = String.valueOf(System.currentTimeMillis());
            localObject2 = (String)localObject4 + ".jpg";
            localObject4 = this.jdField_c_of_type_JavaLangString;
            int i6 = 800;
            ImageUtil.compressImagetoSize(this, (String)localObject4, (String)localObject2, i6, 600);
            this.jdField_c_of_type_JavaLangString = ((String)localObject2);
            localObject2 = Uri.parse(this.jdField_c_of_type_JavaLangString);
            this.jdField_a_of_type_AndroidNetUri = ((Uri)localObject2);
          }
        }
        Object localObject2 = this.jdField_c_of_type_JavaLangString;
        if (localObject2 != null)
        {
          localObject3 = TransfileUtile.makeTransFileProtocolData(this.jdField_c_of_type_JavaLangString, l1, i1, i1);
          localObject2 = new StorageMessage();
          localObject4 = ((StorageMessage)localObject2).a;
          Object localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
          ((MessageRecordInfo)localObject4).jdField_a_of_type_JavaLangString = ((String)localObject6);
          localObject4 = ((StorageMessage)localObject2).a;
          localObject6 = this.jdField_a_of_type_JavaLangString;
          ((MessageRecordInfo)localObject4).jdField_b_of_type_JavaLangString = ((String)localObject6);
          localObject4 = ((StorageMessage)localObject2).a;
          localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
          ((MessageRecordInfo)localObject4).jdField_c_of_type_JavaLangString = ((String)localObject6);
          ((StorageMessage)localObject2).a.jdField_d_of_type_JavaLangString = ((String)localObject3);
          localObject4 = ((StorageMessage)localObject2).a;
          localObject6 = System.currentTimeMillis();
          l1 = 1000L;
          int i7 = (int)(l3 / l1);
          ((MessageRecordInfo)localObject4).jdField_a_of_type_Int = i7;
          ((StorageMessage)localObject2).a.jdField_a_of_type_Boolean = i1;
          ((StorageMessage)localObject2).a.jdField_b_of_type_Boolean = i1;
          localObject4 = ((StorageMessage)localObject2).a;
          i7 = this.jdField_c_of_type_Int;
          if (i7 != i1)
            break label721;
          i7 = i1;
          ((MessageRecordInfo)localObject4).jdField_c_of_type_Boolean = i7;
          long l5 = StorageManager.instance(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).a((Storageable)localObject2);
          BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
          BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
          String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
          int i8 = this.jdField_c_of_type_Int;
          String str2 = this.jdField_a_of_type_JavaLangString;
          MessageUtil.sendSaveFileMsg((BaseServiceHelper)localObject2, (BaseActionListener)localObject4, i7, i8, str2, (String)localObject3);
        }
        long l6 = l1;
        localIntent.putExtra("fileId", l6);
      }
      String str3 = this.jdField_c_of_type_JavaLangString;
      Uri localUri = this.jdField_a_of_type_AndroidNetUri;
      String str4 = ImageUtil.getThumbPath(this, localUri);
      ImageUtil.compressImagetoSize(this, str3, str4, 180, 240);
      localIntent.putExtra("custEmo", bool1);
      long l7 = this.jdField_a_of_type_Long;
      localIntent.putExtra("fileSize", l7);
      String str5 = this.jdField_b_of_type_JavaLangString;
      localIntent.putExtra("fileType", str5);
      String str6 = this.jdField_c_of_type_JavaLangString;
      localIntent.putExtra("filePath", str6);
      if (!localIntent.getExtras().containsKey("fileId"))
      {
        long l8 = this.jdField_b_of_type_Long;
        localIntent.putExtra("fileId", l8);
      }
      setResult(l, localIntent);
      return;
      label721: boolean bool2 = bool1;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      break label132:
    }
  }

  private void c()
  {
    int l = 0;
    Object localObject1 = AppConstants.SDCARD_IMG_SAVE;
    new File((String)localObject1).mkdirs();
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqGifGIFDrawable;
    if (localObject2 == null)
    {
      localObject2 = new StringBuilder();
      localObject1 = AppConstants.SDCARD_IMG_SAVE;
      localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
      localObject1 = this.jdField_a_of_type_JavaLangString;
      localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
      localObject1 = getSavePicDateTime();
      localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
      localObject1 = ".jpg";
      localObject2 = (String)localObject1;
      label79: localObject1 = new File((String)localObject2).exists();
      if (localObject1 != 0)
        break label305;
    }
    try
    {
      localObject1 = new FileOutputStream((String)localObject2);
      GIFDrawable localGIFDrawable = this.jdField_a_of_type_ComTencentMobileqqGifGIFDrawable;
      if (localGIFDrawable == null)
      {
        Bitmap localBitmap = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a().jdField_a_of_type_AndroidGraphicsBitmap;
        Bitmap.CompressFormat localCompressFormat = Bitmap.CompressFormat.JPEG;
        localBitmap.compress(localCompressFormat, 80, (OutputStream)localObject1);
      }
      while (true)
      {
        Toast.makeText(this, "鍥剧�", null).show();
        finish();
        label158: Uri localUri = Uri.parse("file://" + (String)localObject2);
        Intent localIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", (Uri)localObject2);
        sendBroadcast(localIntent);
        return;
        localObject2 = new StringBuilder();
        localObject1 = AppConstants.SDCARD_IMG_SAVE;
        localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
        localObject1 = this.jdField_a_of_type_JavaLangString;
        localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
        localObject1 = getSavePicDateTime();
        localObject2 = ((StringBuilder)localObject2).append((String)localObject1);
        localObject1 = ".gif";
        localObject2 = (String)localObject1;
        break label79:
        localGIFDrawable = this.jdField_a_of_type_ComTencentMobileqqGifGIFDrawable;
        try
        {
          byte[] arrayOfByte = localGIFDrawable.a;
          ((OutputStream)localObject1).write(localGIFDrawable);
          label305: ((OutputStream)localObject1).flush();
        }
        catch (IOException localIOException)
        {
        }
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      Toast.makeText(this, "鍥剧墖", l).show();
      break label158:
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this).setTitle("淇濆").setMessage("璇ュ浘鐗囧凡�");
      fm localfm = new fm(this);
      localBuilder.setPositiveButton("鏇", localfm).setNegativeButton("�", null).create().show();
      break label158:
    }
  }

  private void d()
  {
    int l = 0;
    if (this.jdField_a_of_type_AndroidNetUri == null);
    while (true)
    {
      return;
      this.jdField_a_of_type_AndroidWidgetProgressBar.setVisibility(l);
      fo localfo1 = new fo(this);
      this.jdField_a_of_type_Fo = localfo1;
      ExecutorService localExecutorService = this.jdField_a_of_type_JavaUtilConcurrentExecutorService;
      fo localfo2 = this.jdField_a_of_type_Fo;
      localExecutorService.execute(localfo2);
      this.jdField_e_of_type_Int = l;
    }
  }

  private static void deleteTempPic()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = AppConstants.SDCARD_PATH;
    String str2 = str1 + "thumb/" + "temp.jpg";
    File localFile = new File(str2);
    if (!localFile.exists())
      return;
    localFile.delete();
  }

  private static String getSavePicDateTime()
  {
    Time localTime = new Time();
    localTime.setToNow();
    return localTime.format("%Y%m%d%H%M%S");
  }

  public void onClick(View paramView)
  {
    Object localObject1 = 6;
    int l = 4;
    int i1 = 0;
    int i2 = 1;
    int i3 = -1;
    int i4 = paramView.getId();
    switch (i4)
    {
    case 2131492908:
    case 2131492909:
    case 2131492910:
    case 2131492911:
    case 2131492912:
    case 2131492913:
    case 2131492914:
    case 2131492915:
    case 2131492916:
    case 2131492917:
    case 2131492918:
    case 2131492919:
    case 2131492920:
    case 2131492925:
    case 2131492929:
    default:
    case 2131492907:
    case 2131492926:
    case 2131492927:
    case 2131492928:
    case 2131492930:
    case 2131492931:
    case 2131492932:
    case 2131492921:
    case 2131492922:
    case 2131492923:
    case 2131492924:
    }
    while (true)
    {
      label140: return;
      Intent localIntent1;
      if (getIntent().getExtras().getInt("requestType", i3) == 10)
      {
        localIntent1 = new Intent();
        if (this.jdField_d_of_type_Int == 0);
      }
      try
      {
        while (true)
        {
          String str1 = this.jdField_c_of_type_JavaLangString;
          File localFile = new File(str1);
          Bitmap localBitmap1 = BitmapFactory.decodeStream(new FileInputStream(localFile));
          int i6 = localBitmap1.getWidth();
          int i7 = localBitmap1.getHeight();
          Matrix localMatrix1 = new Matrix();
          float f1 = this.jdField_d_of_type_Int;
          localMatrix1.setRotate(f1);
          Bitmap localBitmap2 = Bitmap.createBitmap(localBitmap1, 0, 0, i6, i7, localMatrix1, true);
          String str2 = this.jdField_c_of_type_JavaLangString;
          FileOutputStream localFileOutputStream1 = new FileOutputStream(str2);
          Bitmap.CompressFormat localCompressFormat1 = Bitmap.CompressFormat.JPEG;
          localBitmap2.compress(localCompressFormat1, 80, localFileOutputStream1);
          label294: localIntent1.putExtra("custEmo", i2);
          String str3 = this.jdField_c_of_type_JavaLangString;
          localIntent1.putExtra("filePath", str3);
          setResult(i3, localIntent1);
          while (true)
          {
            finish();
            break label140:
            b();
          }
          i4 = getIntent().getExtras().getInt("requestType", i3);
          int i8 = 5;
          TransFileController localTransFileController;
          String str4;
          if (i4 == i8)
          {
            i4 = this.jdField_c_of_type_Int;
            if (i4 == i2)
            {
              localTransFileController = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
              str4 = this.jdField_a_of_type_JavaLangString;
              String str5 = this.jdField_d_of_type_JavaLangString;
              long l1 = this.jdField_b_of_type_Long;
              str4 = str4 + str5 + l1;
              if (localTransFileController.a.containsKey(str4))
              {
                GroupPicProcessor localGroupPicProcessor1 = (GroupPicProcessor)localTransFileController.a.get(str4);
                localTransFileController.d();
                localTransFileController.a(i1);
              }
            }
          }
          while (true)
          {
            Intent localIntent2 = getIntent();
            setResult(i3, localIntent2);
            finish();
            break label140:
            localTransFileController = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            str4 = this.jdField_a_of_type_JavaLangString;
            String str6 = this.jdField_d_of_type_JavaLangString;
            long l2 = this.jdField_b_of_type_Long;
            str4 = str4 + str6 + l2;
            if (!localTransFileController.a.containsKey(str4))
              continue;
            TransFileProcessor localTransFileProcessor1 = (TransFileProcessor)localTransFileController.a.get(str4);
            localTransFileController.b();
            localTransFileController.a(2004);
            continue;
            Object localObject3 = 7;
            if (localTransFileController != localObject3)
              continue;
            int i5 = this.jdField_c_of_type_Int;
            if (i5 == i2)
            {
              localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
              localObject3 = this.jdField_a_of_type_JavaLangString;
              String str7 = this.jdField_d_of_type_JavaLangString;
              long l3 = this.jdField_b_of_type_Long;
              localObject3 = (String)localObject3 + str7 + l3;
              if (!((TransFileController)localObject2).a.containsKey(localObject3))
                continue;
              GroupPicProcessor localGroupPicProcessor2 = (GroupPicProcessor)((TransFileController)localObject2).a.get(localObject3);
              ((GroupPicProcessor)localObject2).d();
              ((GroupPicProcessor)localObject2).a(i2);
            }
            localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            localObject3 = this.jdField_a_of_type_JavaLangString;
            String str8 = this.jdField_d_of_type_JavaLangString;
            long l4 = this.jdField_b_of_type_Long;
            localObject3 = (String)localObject3 + str8 + l4;
            if (!((TransFileController)localObject2).a.containsKey(localObject3))
              continue;
            TransFileProcessor localTransFileProcessor2 = (TransFileProcessor)((TransFileController)localObject2).a.get(localObject3);
            ((TransFileProcessor)localObject2).b();
            ((TransFileProcessor)localObject2).a(1004);
          }
          Object localObject2 = getIntent().getExtras().getInt("requestType", i3);
          if (localObject2 == 9)
          {
            Context localContext = BaseApplication.getContext();
            Uri localUri1 = this.jdField_a_of_type_AndroidNetUri;
            String str9 = ImageUtil.getThumbPath(localContext, localUri1);
            localObject2 = new File(str9);
            if (((File)localObject2).exists())
              ((File)localObject2).delete();
            StorageMessageManager localStorageMessageManager = new StorageMessageManager();
            String str10 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
            String str11 = this.jdField_a_of_type_JavaLangString;
            long l5 = getIntent().getExtras().getLong("_id");
            int i9 = this.jdField_c_of_type_Int;
            Object localObject4;
            localStorageMessageManager.a(str10, str11, localObject4, i9);
          }
          while (true)
          {
            finish();
            break label140:
            if (localObject2 != localObject1)
              continue;
            a();
          }
          c();
          break label140:
          if (this.jdField_e_of_type_AndroidWidgetButton.getText().equals("鍙"))
            b();
          while (true)
          {
            finish();
            break label140:
            c();
          }
          Intent localIntent3 = new Intent();
          localIntent3.putExtra("phototodoodle", i2);
          String str12 = this.jdField_c_of_type_JavaLangString;
          localIntent3.putExtra("photofilepath", str12);
          int i10 = this.jdField_e_of_type_Int;
          localIntent3.putExtra("rotation", i10);
          setResult(i3, localIntent3);
          finish();
          break label140:
          if (this.g.getText().equals("鍔犱"))
            a();
          finish();
          break label140:
          if (!this.jdField_b_of_type_AndroidWidgetProgressBar.isShown())
            this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(8);
          if (!this.jdField_a_of_type_AndroidWidgetLinearLayout.isShown())
            this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
          this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(l);
          break label140:
          int i11 = this.jdField_e_of_type_Int;
          ++localObject2;
          this.jdField_e_of_type_Int = i11;
          if (this.jdField_e_of_type_Int >= l)
            this.jdField_e_of_type_Int = i1;
          int i12 = this.jdField_d_of_type_Int;
          localObject2 += 90;
          this.jdField_d_of_type_Int = i12;
          if (this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a().jdField_a_of_type_AndroidGraphicsBitmap != null)
          {
            RotateBitmap localRotateBitmap1 = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a();
            int i13 = this.jdField_d_of_type_Int;
            localRotateBitmap1.jdField_a_of_type_Int = i13;
            ImageViewTouche localImageViewTouche = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche;
            RotateBitmap localRotateBitmap2 = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a();
            localImageViewTouche.setImageRotateBitmapResetBase(localRotateBitmap2, i2);
          }
          if ((getIntent().getExtras().getInt("requestType", i3) == localObject1) || (getIntent().getExtras().getInt("requestType", i3) == 8));
          try
          {
            Matrix localMatrix2 = new Matrix();
            float f2 = this.jdField_d_of_type_Int;
            localMatrix2.setRotate(f2);
            Bitmap localBitmap3 = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.a().jdField_a_of_type_AndroidGraphicsBitmap;
            int i14 = localBitmap3.getWidth();
            int i15 = localBitmap3.getHeight();
            Bitmap localBitmap4 = Bitmap.createBitmap(localBitmap3, 0, 0, i14, i15, localMatrix2, true);
            String str13 = this.jdField_c_of_type_JavaLangString;
            FileOutputStream localFileOutputStream2 = new FileOutputStream(str13);
            Bitmap.CompressFormat localCompressFormat2 = Bitmap.CompressFormat.JPEG;
            localBitmap4.compress(localCompressFormat2, 80, localFileOutputStream2);
            Uri localUri2 = Uri.parse(this.jdField_c_of_type_JavaLangString);
            String str14 = ImageUtil.getThumbPath(this, localUri2);
            String str15 = this.jdField_c_of_type_JavaLangString;
            ImageUtil.compressImagetoSize(this, str15, str14, 180, 240);
            QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
            String str16 = Uri.parse(str14).toString();
            localQQApplication.b(str16);
          }
          catch (FileNotFoundException localFileNotFoundException1)
          {
          }
        }
        break label140:
        this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.c();
        break label140:
        this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.b();
      }
      catch (FileNotFoundException localFileNotFoundException2)
      {
        break label294:
      }
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche.setImageBitmapResetBase(null, true);
    d();
  }

  protected void onCreate(Bundle paramBundle)
  {
    int l = 4;
    int i1 = 8;
    int i2 = 0;
    super.onCreate(paramBundle);
    setContentView(2130903050);
    Display localDisplay = getWindowManager().getDefaultDisplay();
    int i4 = localDisplay.getWidth();
    this.jdField_a_of_type_Int = i4;
    int i3 = localDisplay.getHeight() - 150;
    this.jdField_b_of_type_Int = i3;
    Object localObject1 = (ImageSwitcherTouch)findViewById(2131492913);
    this.jdField_a_of_type_ComTencentMobileqqWidgetImageSwitcherTouch = ((ImageSwitcherTouch)localObject1);
    localObject1 = new ImageViewTouche(this);
    this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche = ((ImageViewTouche)localObject1);
    localObject1 = new FrameLayout.LayoutParams(-1, -1);
    ((FrameLayout.LayoutParams)localObject1).gravity = 17;
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqWidgetImageSwitcherTouch;
    ImageViewTouche localImageViewTouche = this.jdField_a_of_type_ComTencentMobileqqWidgetImageViewTouche;
    ((ImageSwitcherTouch)localObject2).addView(localImageViewTouche, i2, (ViewGroup.LayoutParams)localObject1);
    localObject1 = (ProgressBar)findViewById(2131492914);
    this.jdField_a_of_type_AndroidWidgetProgressBar = ((ProgressBar)localObject1);
    localObject1 = (LinearLayout)findViewById(2131492916);
    this.jdField_a_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject1);
    localObject1 = (TextView)findViewById(2131492917);
    this.jdField_a_of_type_AndroidWidgetTextView = ((TextView)localObject1);
    localObject1 = (TextView)findViewById(2131492918);
    this.jdField_b_of_type_AndroidWidgetTextView = ((TextView)localObject1);
    localObject1 = (RelativeLayout)findViewById(2131492925);
    this.jdField_a_of_type_AndroidWidgetRelativeLayout = ((RelativeLayout)localObject1);
    localObject1 = (LinearLayout)findViewById(2131492929);
    this.jdField_b_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject1);
    localObject1 = (Button)findViewById(2131492907);
    this.jdField_a_of_type_AndroidWidgetButton = ((Button)localObject1);
    this.jdField_a_of_type_AndroidWidgetButton.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492926);
    this.jdField_b_of_type_AndroidWidgetButton = ((Button)localObject1);
    this.jdField_b_of_type_AndroidWidgetButton.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492927);
    this.jdField_c_of_type_AndroidWidgetButton = ((Button)localObject1);
    this.jdField_c_of_type_AndroidWidgetButton.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492928);
    this.jdField_d_of_type_AndroidWidgetButton = ((Button)localObject1);
    this.jdField_d_of_type_AndroidWidgetButton.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492930);
    this.jdField_e_of_type_AndroidWidgetButton = ((Button)localObject1);
    this.jdField_e_of_type_AndroidWidgetButton.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492931);
    this.f = ((Button)localObject1);
    this.f.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492932);
    this.g = ((Button)localObject1);
    this.g.setOnClickListener(this);
    localObject1 = (LinearLayout)findViewById(2131492920);
    this.jdField_c_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject1);
    localObject1 = (Button)findViewById(2131492921);
    this.h = ((Button)localObject1);
    this.h.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492922);
    this.i = ((Button)localObject1);
    this.i.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492923);
    this.j = ((Button)localObject1);
    this.j.setOnClickListener(this);
    localObject1 = (Button)findViewById(2131492924);
    this.k = ((Button)localObject1);
    this.k.setOnClickListener(this);
    localObject1 = (ProgressBar)findViewById(2131492915);
    this.jdField_b_of_type_AndroidWidgetProgressBar = ((ProgressBar)localObject1);
    localObject1 = findViewById(2131492912);
    this.jdField_a_of_type_AndroidViewView = ((View)localObject1);
    localObject1 = this.jdField_a_of_type_AndroidViewView;
    fq localfq = new fq(this);
    localObject2 = new GestureDetector(this, localfq);
    this.jdField_a_of_type_AndroidViewGestureDetector = ((GestureDetector)localObject2);
    localObject2 = new fl(this);
    ((View)localObject1).setOnTouchListener((View.OnTouchListener)localObject2);
    localObject1 = getIntent().getExtras().getInt("requestType", -1);
    localObject2 = getIntent().getExtras().getLong("_id");
    Object localObject3;
    this.jdField_b_of_type_Long = localObject3;
    localObject2 = getIntent().getExtras().getString("friendUin");
    this.jdField_a_of_type_JavaLangString = ((String)localObject2);
    localObject2 = getIntent().getExtras().getInt("curType");
    this.jdField_c_of_type_Int = localObject2;
    localObject2 = getIntent().getExtras().getString("url");
    this.jdField_d_of_type_JavaLangString = ((String)localObject2);
    localObject2 = getIntent().getData();
    this.jdField_a_of_type_AndroidNetUri = ((Uri)localObject2);
    localObject2 = getIntent().getExtras().getBoolean("home", i2);
    if (localObject2 != 0)
    {
      localObject2 = getSharedPreferences("sp", i2);
      if (localObject2 != null)
      {
        localObject2 = Uri.parse(((SharedPreferences)localObject2).getString("savedUri", null));
        this.jdField_a_of_type_AndroidNetUri = ((Uri)localObject2);
      }
    }
    localObject2 = getIntent().getExtras().getInt("progress", i2);
    switch (localObject1)
    {
    default:
    case 1:
    case 2:
    case 5:
    case 7:
    case 6:
    case 8:
    case 9:
    case 10:
    case 102:
    }
    while (true)
    {
      if (this.jdField_a_of_type_AndroidNetUri != null)
      {
        Uri localUri = this.jdField_a_of_type_AndroidNetUri;
        String str = ImageUtil.getRealPathFromContentURI(this, localUri);
        this.jdField_c_of_type_JavaLangString = str;
      }
      d();
      return;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(l);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      Handler localHandler1 = this.jdField_a_of_type_AndroidOsHandler;
      TransFileProcessor.setHandler(localHandler1);
      GroupPicProcessor.setHandler(localHandler1);
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetButton.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetButton.setText("鍙栨");
      this.jdField_c_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_d_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(i2);
      this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(l);
      ImageSwitcherTouch localImageSwitcherTouch = this.jdField_a_of_type_ComTencentMobileqqWidgetImageSwitcherTouch;
      Bitmap localBitmap = ((BitmapDrawable)getResources().getDrawable(2130837573)).getBitmap();
      localImageSwitcherTouch.setImageBitmap(localBitmap);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setProgress(localObject2);
      continue;
      Handler localHandler2 = this.jdField_a_of_type_AndroidOsHandler;
      TransFileProcessor.setHandler(localHandler2);
      GroupPicProcessor.setHandler(localHandler2);
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetButton.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetButton.setText("鍙栨");
      this.jdField_c_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_d_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(i2);
      this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(l);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setProgress(localObject2);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(l);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(l);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i2);
      this.jdField_a_of_type_AndroidWidgetButton.setText("閲嶆");
      this.jdField_b_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_c_of_type_AndroidWidgetButton.setVisibility(i2);
      this.jdField_c_of_type_AndroidWidgetButton.setText("鍒犻");
      this.jdField_d_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i2);
      this.jdField_a_of_type_AndroidWidgetButton.setCompoundDrawablesWithIntrinsicBounds(2130837969, i2, i2, i2);
      this.jdField_a_of_type_AndroidWidgetButton.setText("鍔犱");
      this.jdField_b_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_c_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_d_of_type_AndroidWidgetButton.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      continue;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i2);
      this.jdField_b_of_type_AndroidWidgetProgressBar.setVisibility(l);
      this.jdField_e_of_type_AndroidWidgetButton.setVisibility(i1);
      this.f.setVisibility(i2);
    }
  }

  protected void onDestroy()
  {
    int l = 0;
    boolean bool = this.jdField_a_of_type_AndroidOsHandler.hasMessages(l);
    if (bool)
    {
      localObject = this.jdField_a_of_type_AndroidOsHandler;
      ((Handler)localObject).removeMessages(l);
    }
    Object localObject = getSharedPreferences("sp", l).edit();
    if (this.jdField_a_of_type_AndroidNetUri != null)
    {
      String str1 = this.jdField_a_of_type_AndroidNetUri.toString();
      ((SharedPreferences.Editor)localObject).putString("savedUri", str1);
      ((SharedPreferences.Editor)localObject).commit();
    }
    StringBuilder localStringBuilder = new StringBuilder();
    String str2 = AppConstants.SDCARD_PATH;
    String str3 = str2 + "thumb/" + "temp.jpg";
    localObject = new File(str3);
    if (((File)localObject).exists())
      ((File)localObject).delete();
    super.onDestroy();
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.PhotoPreview
 * JD-Core Version:    0.5.4
 */