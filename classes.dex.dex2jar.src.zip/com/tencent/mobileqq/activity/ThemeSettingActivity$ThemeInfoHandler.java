package com.tencent.mobileqq.activity;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class ThemeSettingActivity$ThemeInfoHandler extends DefaultHandler
{
  private final String a = "skinname";
  private final String b = "iconname";
  private final String c = "skinid";
  private final String d = "skininfo";
  private String e = "";
  private String f = "";
  private String g = "";
  private String h = "";

  public ThemeSettingActivity$ThemeInfoHandler(String paramString)
  {
    this.e = paramString;
  }

  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
  }

  public void endDocument()
  {
    super.endDocument();
  }

  public void endElement(String paramString1, String paramString2, String paramString3)
  {
    if (!paramString2.equals("skininfo"))
      return;
    String str1 = this.g;
    String str2 = this.f;
    String str3 = this.h;
    String str4 = this.e;
    ThemeSettingActivity.access$300(str1, str2, str3, str4);
    this.g = "";
    this.f = "";
    this.h = "";
  }

  public void startDocument()
  {
  }

  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes)
  {
    String str = paramAttributes.getValue("data");
    if (paramString2.equals("skinname"))
      this.f = str;
    while (true)
    {
      return;
      if (paramString2.equals("iconname"))
        this.g = str;
      if (!paramString2.equals("skinid"))
        continue;
      this.h = str;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ThemeSettingActivity.ThemeInfoHandler
 * JD-Core Version:    0.5.4
 */