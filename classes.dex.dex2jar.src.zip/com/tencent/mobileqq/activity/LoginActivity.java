package com.tencent.mobileqq.activity;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.ScreenShotSensorEventListener;
import com.tencent.mobileqq.data.QQEntityManagerFactory;
import com.tencent.mobileqq.data.RecentUser;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.persistence.TableBuilder;
import com.tencent.mobileqq.widget.DropdownView;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseApplication;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.MD5;
import ey;
import ez;
import fa;
import fb;
import fc;
import fe;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class LoginActivity extends BaseActivity
  implements DialogInterface.OnClickListener, TextWatcher, View.OnClickListener
{
  private static final int DIALOG_CLEAR_ACCOUNT = 1;
  private static final int DIALOG_PROGRESS = 0;
  private static final String FAKE_PASSWORD = "!@#ewaGbhkc$!!=B";
  private int jdField_a_of_type_Int = -1;
  private InputMethodManager jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
  private AutoCompleteTextView jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
  private CheckBox jdField_a_of_type_AndroidWidgetCheckBox;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private SimpleAccount jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private BaseServiceHelper jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
  private List jdField_a_of_type_JavaUtilList;
  private CheckBox b;
  private CheckBox c;
  private CheckBox d;
  private CheckBox e;

  public LoginActivity()
  {
    fc localfc = new fc(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localfc;
  }

  private void a(SimpleAccount paramSimpleAccount)
  {
    CharSequence localCharSequence = null;
    int i = null;
    this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount = paramSimpleAccount;
    SharedPreferences localSharedPreferences = getSharedPreferences("mobileQQ", i);
    if (this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount != null)
    {
      String str1 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
      if ((localSharedPreferences.getBoolean(str1, i)) && (this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.isLogined()))
      {
        AutoCompleteTextView localAutoCompleteTextView1 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        String str2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount.getUin();
        localAutoCompleteTextView1.setText(str2);
        this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.selectAll();
        this.jdField_a_of_type_AndroidWidgetEditText.setText("!@#ewaGbhkc$!!=B");
        this.jdField_a_of_type_AndroidWidgetEditText.addTextChangedListener(this);
      }
    }
    while (true)
    {
      return;
      if (paramSimpleAccount != null)
      {
        AutoCompleteTextView localAutoCompleteTextView2 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        String str3 = paramSimpleAccount.getUin();
        localAutoCompleteTextView2.setText(str3);
      }
      this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount = localCharSequence;
      this.jdField_a_of_type_AndroidWidgetEditText.setText(localCharSequence);
    }
  }

  private void b(String paramString)
  {
    int i = null;
    Object localObject1 = 1;
    SharedPreferences localSharedPreferences;
    Object localObject2;
    label74: Object localObject3;
    if (paramString != null)
    {
      int j = paramString.trim().length();
      if (j > 0)
      {
        localSharedPreferences = getSharedPreferences(paramString, i);
        if (localSharedPreferences != null)
        {
          long l1 = 11L;
          long l2 = localSharedPreferences.getLong("getProfileStatus", l1) < 41L;
          int k;
          if (k != 0)
            break label164;
          localObject2 = this.b;
          ((CheckBox)localObject2).setChecked(localObject1);
          localObject2 = PreferenceManager.getDefaultSharedPreferences(this);
          localObject3 = getString(2131296351);
          localObject2 = ((SharedPreferences)localObject2).getBoolean((String)localObject3, localObject1);
          localObject3 = this.c;
          if (localObject2 != 0)
            break label179;
          localObject2 = localObject1;
        }
      }
    }
    while (true)
    {
      ((CheckBox)localObject3).setChecked(localObject2);
      boolean bool1 = localSharedPreferences.getBoolean("login_auto", localObject1);
      this.jdField_a_of_type_AndroidWidgetCheckBox.setChecked(localObject2);
      boolean bool2 = localSharedPreferences.getBoolean("login_receive", localObject1);
      this.d.setChecked(localSharedPreferences);
      return;
      label164: localObject2 = this.b;
      ((CheckBox)localObject2).setChecked(i);
      break label74:
      label179: localObject2 = i;
    }
  }

  public void afterTextChanged(Editable paramEditable)
  {
  }

  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    int i = -1;
    int j = this.jdField_a_of_type_Int;
    Object localObject2;
    Object localObject3;
    Object localObject1;
    if (j != i)
    {
      localObject2 = (fe)this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getAdapter();
      i = this.jdField_a_of_type_Int;
      localObject3 = access$100(((fe)localObject2).a);
      localObject1 = ((SimpleAccount)((List)localObject3).get(i)).getUin();
    }
    try
    {
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().removeUser((String)localObject1);
      localObject3 = this.jdField_a_of_type_JavaUtilList;
      int k = this.jdField_a_of_type_Int;
      ((List)localObject3).remove(k);
      this.jdField_a_of_type_Int = -1;
      localObject3 = this.jdField_a_of_type_JavaUtilList.isEmpty();
      if (localObject3 == 0)
      {
        localObject3 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getText().toString();
        localObject3 = ((String)localObject1).equals(localObject3);
        if (localObject3 == 0)
          break label158;
      }
      this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.setText(null);
      localObject3 = this.jdField_a_of_type_AndroidWidgetEditText;
      ((EditText)localObject3).setText(null);
      label158: ((fe)localObject2).notifyDataSetChanged();
      localObject2 = this.e.isChecked();
      if (localObject2 == 0)
        break label241;
      localObject2 = new QQEntityManagerFactory((String)localObject1);
      localObject1 = ((EntityManagerFactory)localObject2).build((String)localObject1).getWritableDatabase();
      localObject3 = ((SQLiteDatabase)localObject1).rawQuery("select name from sqlite_master where type=\"table\" and name like \"mr_%\"", null);
      if (!((Cursor)localObject3).moveToNext())
        break label242;
      String str1 = TableBuilder.dropSQLStatement(((Cursor)localObject3).getString(0));
      label241: label242: ((SQLiteDatabase)localObject1).execSQL(str1);
    }
    catch (Exception localException)
    {
      while (true)
      {
        return;
        String str2 = TableBuilder.dropSQLStatement(new RecentUser().getTableName());
        ((SQLiteDatabase)localObject1).execSQL(str2);
        ((EntityManagerFactory)localObject2).close();
      }
    }
  }

  public void onClick(View paramView)
  {
    int i = 2;
    int j = 0;
    int k = paramView.getId();
    switch (k)
    {
    default:
    case 2131493107:
    }
    while (true)
    {
      return;
      Object localObject1 = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
      Object localObject2 = paramView.getWindowToken();
      ((InputMethodManager)localObject1).hideSoftInputFromWindow((IBinder)localObject2, j);
      localObject1 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getText().toString();
      localObject2 = this.jdField_a_of_type_AndroidWidgetEditText.getText().toString();
      if (((String)localObject1).trim().length() == 0)
      {
        Toast.makeText(this, 2131296287, j).show();
        this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.requestFocus();
        InputMethodManager localInputMethodManager1 = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
        AutoCompleteTextView localAutoCompleteTextView1 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        localInputMethodManager1.showSoftInput(localAutoCompleteTextView1, i);
      }
      if (((String)localObject2).length() <= 0)
      {
        Toast.makeText(this, 2131296289, j).show();
        this.jdField_a_of_type_AndroidWidgetEditText.requestFocus();
        InputMethodManager localInputMethodManager2 = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
        EditText localEditText = this.jdField_a_of_type_AndroidWidgetEditText;
        localInputMethodManager2.showSoftInput(localEditText, i);
      }
      if (((String)localObject1).startsWith("0"))
      {
        Toast.makeText(this, 2131296290, j).show();
        this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.requestFocus();
        InputMethodManager localInputMethodManager3 = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
        AutoCompleteTextView localAutoCompleteTextView2 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        localInputMethodManager3.showSoftInput(localAutoCompleteTextView2, i);
      }
      if (this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount != null)
      {
        showDialog(j);
        new fb(this).start();
      }
      if (BaseApplication.isNetSupport())
      {
        showDialog(j);
        try
        {
          this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.resume();
          QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
          localQQApplication.a(localBaseActionListener);
          BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
          byte[] arrayOfByte = MD5.toMD5Byte((String)localObject2);
          localBaseServiceHelper.login((String)localObject1, localObject2, true, true);
        }
        catch (Exception localException)
        {
        }
      }
      Toast.makeText(this, 2131296286, j).show();
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903077);
    Object localObject1 = ((DropdownView)findViewById(2131493100)).a;
    this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView = ((AutoCompleteTextView)localObject1);
    localObject1 = (EditText)findViewById(2131493102);
    this.jdField_a_of_type_AndroidWidgetEditText = ((EditText)localObject1);
    localObject1 = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = ((QQApplication)localObject1);
    ((Button)findViewById(2131493107)).setOnClickListener(this);
    localObject1 = (TextView)findViewById(2131493108);
    Object localObject2 = LinkMovementMethod.getInstance();
    ((TextView)localObject1).setMovementMethod((MovementMethod)localObject2);
    localObject1 = (InputMethodManager)getSystemService("input_method");
    this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager = ((InputMethodManager)localObject1);
    localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper = ((BaseServiceHelper)localObject1);
    localObject1 = getSharedPreferences("mobileQQ", 0);
    localObject2 = "currentAccount";
    Object localObject3 = null;
    String str1 = ((SharedPreferences)localObject1).getString((String)localObject2, (String)localObject3);
    try
    {
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUserList();
      if (localObject1 == null)
        break label349;
      localObject1 = (List)((FromServiceMsg)localObject1).getAttribute("baseSdk.auth.getAllSimpleUser");
      localObject2 = new ey(this);
      Collections.sort((List)localObject1, (Comparator)localObject2);
      localObject2 = ((List)localObject1).size();
      if (localObject2 <= 0)
        break label535;
      localObject2 = (SimpleAccount)((List)localObject1).get(0);
      Iterator localIterator = ((List)localObject1).iterator();
      do
      {
        localObject3 = localIterator.hasNext();
        if (localObject3 != 0)
          localObject3 = (SimpleAccount)localIterator.next();
      }
      while (!((SimpleAccount)localObject3).getUin().equals(str1));
      localObject2 = ((List)localObject1).remove(localObject3);
      if (localObject2 == 0)
        break label574;
      ((List)localObject1).add(0, localObject3);
      localObject2 = localObject3;
      label282: a((SimpleAccount)localObject2);
      if (((List)localObject1).size() <= 3)
        break label535;
      int i = ((List)localObject1).size() - 1;
      SimpleAccount localSimpleAccount = (SimpleAccount)((List)localObject1).remove(i);
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str2 = localSimpleAccount.getUin();
      label535: label574: label349: localBaseServiceHelper.removeUser(str2);
    }
    catch (Exception localException)
    {
      if (this.jdField_a_of_type_JavaUtilList != null)
      {
        AutoCompleteTextView localAutoCompleteTextView1 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        fe localfe = new fe(this, this);
        localAutoCompleteTextView1.setAdapter(localfe);
        AutoCompleteTextView localAutoCompleteTextView2 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView;
        ez localez = new ez(this);
        localAutoCompleteTextView2.setOnItemClickListener(localez);
      }
      this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.addTextChangedListener(this);
      CheckBox localCheckBox1 = (CheckBox)findViewById(2131493103);
      this.jdField_a_of_type_AndroidWidgetCheckBox = localCheckBox1;
      CheckBox localCheckBox2 = (CheckBox)findViewById(2131493104);
      this.b = localCheckBox2;
      CheckBox localCheckBox3 = (CheckBox)findViewById(2131493105);
      this.c = localCheckBox3;
      CheckBox localCheckBox4 = (CheckBox)findViewById(2131493106);
      this.d = localCheckBox4;
      CheckBox localCheckBox5 = this.c;
      fa localfa = new fa(this);
      localCheckBox5.setOnClickListener(localfa);
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() != null)
      {
        String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        b(str3);
      }
      while (true)
      {
        return;
        this.jdField_a_of_type_JavaUtilList = ((List)localObject1);
        break label349:
        if (this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getText() == null)
          continue;
        String str4 = this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getText().toString();
        b(str4);
      }
      localObject2 = localObject3;
      break label282:
    }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    }
    for (Object localObject = i; ; localObject = new AlertDialog.Builder(this).setTitle(2131296291).setPositiveButton(17039370, this).setNegativeButton(17039360, i).setView((View)localObject).create())
    {
      while (true)
      {
        return localObject;
        localObject = new ProgressDialog(this);
        String str = getString(2131296283);
        ((ProgressDialog)localObject).setMessage(str);
        ((ProgressDialog)localObject).setIndeterminate(true);
      }
      localObject = getLayoutInflater().inflate(2130903063, i);
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131427332, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    super.onDestroy();
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.b(localBaseActionListener);
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    case 2131493161:
    default:
    case 2131493160:
    case 2131493162:
    }
    while (true)
    {
      return true;
      Intent localIntent = new Intent(this, SettingActivity.class);
      startActivity(localIntent);
      continue;
      SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
      ScreenShotSensorEventListener localScreenShotSensorEventListener = BaseActivity.sensorEventListener;
      localSensorManager.unregisterListener(localScreenShotSensorEventListener);
      finish();
    }
  }

  protected void onPrepareDialog(int paramInt, Dialog paramDialog)
  {
    int i = 1;
    if (paramInt == i)
    {
      TextView localTextView = (TextView)paramDialog.findViewById(2131492864);
      String str1 = getString(2131296292);
      fe localfe = (fe)this.jdField_a_of_type_AndroidWidgetAutoCompleteTextView.getAdapter();
      if (this.jdField_a_of_type_Int != -1)
      {
        int j = this.jdField_a_of_type_Int;
        String str2 = ((SimpleAccount)access$100(localfe.a).get(j)).getUin();
        String str3 = str1.replace("${account}", localfe);
        localTextView.setText(localfe);
      }
      CheckBox localCheckBox = (CheckBox)paramDialog.findViewById(2131493035);
      this.e = localCheckBox;
    }
    super.onPrepareDialog(paramInt, paramDialog);
  }

  protected void onRestoreInstanceState(Bundle paramBundle)
  {
    super.onRestoreInstanceState(paramBundle);
    SimpleAccount localSimpleAccount = (SimpleAccount)paramBundle.get("account");
    this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount = localSimpleAccount;
    int i = paramBundle.getInt("position", -1);
    this.jdField_a_of_type_Int = i;
  }

  protected void onResume()
  {
    Object localObject1 = 1;
    super.onResume();
    Object localObject2 = PreferenceManager.getDefaultSharedPreferences(this);
    Object localObject3 = getString(2131296351);
    localObject2 = ((SharedPreferences)localObject2).getBoolean((String)localObject3, localObject1);
    localObject3 = this.c;
    if (localObject2 == 0)
      localObject2 = localObject1;
    while (true)
    {
      ((CheckBox)localObject3).setChecked(localObject2);
      return;
      localObject2 = null;
    }
  }

  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    SimpleAccount localSimpleAccount = this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount;
    paramBundle.putParcelable("account", localSimpleAccount);
    int i = this.jdField_a_of_type_Int;
    paramBundle.putInt("position", i);
  }

  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.jdField_a_of_type_ComTencentQphoneBaseRemoteSimpleAccount != null)
      a(null);
    this.jdField_a_of_type_AndroidWidgetEditText.removeTextChangedListener(this);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getAction() == 1)
    {
      InputMethodManager localInputMethodManager = this.jdField_a_of_type_AndroidViewInputmethodInputMethodManager;
      IBinder localIBinder = getWindow().getDecorView().getWindowToken();
      localInputMethodManager.hideSoftInputFromWindow(localIBinder, 0);
    }
    return super.onTouchEvent(paramMotionEvent);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.LoginActivity
 * JD-Core Version:    0.5.4
 */