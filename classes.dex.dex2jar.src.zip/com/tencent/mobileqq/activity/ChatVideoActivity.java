package com.tencent.mobileqq.activity;

import I;
import ak;
import al;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OrientationEventListener;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import aq;
import ar;
import as;
import at;
import au;
import av;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.video.VcCamera;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.mobileqq.video.surfaceview.Preview;
import com.tencent.mobileqq.video.surfaceview.RemoteView;
import com.tencent.qphone.base.util.BaseActionListener;
import java.util.Vector;

public class ChatVideoActivity extends BaseActivity
{
  private static final int CLEAR_SCREEN_DELAY = 4;
  public static final int RESULT_SHUT_DOWN = 555;
  private static final int SCREEN_DELAY = 120000;
  public static long uin;
  public int a;
  private Bitmap jdField_a_of_type_AndroidGraphicsBitmap = null;
  public AudioManager a;
  Handler jdField_a_of_type_AndroidOsHandler;
  public OrientationEventListener a;
  public Chronometer a;
  private FrameLayout jdField_a_of_type_AndroidWidgetFrameLayout;
  public ImageView a;
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  public TextView a;
  private ChatVideoActivity.BroadcastsHandler jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler;
  private VcCamera jdField_a_of_type_ComTencentMobileqqVideoVcCamera;
  public VideoController a;
  private Preview jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview;
  private RemoteView jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  Runnable jdField_a_of_type_JavaLangRunnable;
  public Thread a;
  public Vector a;
  public boolean a;
  private byte[] jdField_a_of_type_ArrayOfByte;
  private int jdField_b_of_type_Int;
  private Bitmap jdField_b_of_type_AndroidGraphicsBitmap = null;
  private final Handler jdField_b_of_type_AndroidOsHandler;
  private FrameLayout jdField_b_of_type_AndroidWidgetFrameLayout;
  public ImageView b;
  private LinearLayout jdField_b_of_type_AndroidWidgetLinearLayout;
  public TextView b;
  public boolean b;
  private int jdField_c_of_type_Int;
  private Bitmap jdField_c_of_type_AndroidGraphicsBitmap = null;
  private Handler jdField_c_of_type_AndroidOsHandler;
  private ImageView jdField_c_of_type_AndroidWidgetImageView;
  private int jdField_d_of_type_Int;
  private ImageView jdField_d_of_type_AndroidWidgetImageView;
  private int e;
  private int f = null;
  private int g;
  private int h;

  public ChatVideoActivity()
  {
    this.jdField_a_of_type_Boolean = null;
    this.jdField_b_of_type_Boolean = null;
    Vector localVector = new Vector();
    this.jdField_a_of_type_JavaUtilVector = localVector;
    this.jdField_a_of_type_AndroidViewOrientationEventListener = null;
    this.jdField_a_of_type_ArrayOfByte = null;
    this.g = null;
    this.h = 270;
    this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler = null;
    this.jdField_a_of_type_AndroidMediaAudioManager = null;
    this.jdField_a_of_type_Int = null;
    ak localak = new ak(this);
    this.jdField_a_of_type_JavaLangThread = localak;
    av localav = new av(this);
    this.jdField_b_of_type_AndroidOsHandler = localav;
    Handler localHandler = new Handler();
    this.jdField_a_of_type_AndroidOsHandler = localHandler;
    as localas = new as(this);
    this.jdField_a_of_type_JavaLangRunnable = localas;
    at localat = new at(this);
    this.jdField_c_of_type_AndroidOsHandler = localat;
    au localau = new au(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localau;
  }

  private void a()
  {
    int i = this.f;
    if (i != 0);
    while (true)
    {
      return;
      i = this.f;
      this.f = (++i);
      Object localObject = new AlertDialog.Builder(this).setTitle(2131296448);
      String str1 = getString(2131296449);
      localObject = ((AlertDialog.Builder)localObject).setMessage(str1);
      String str2 = getString(2131296271);
      aq localaq = new aq(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(str2, localaq).setNegativeButton(2131296270, null).create();
      ((AlertDialog)localObject).show();
      if (!isFinishing())
        ((AlertDialog)localObject).show();
      ar localar = new ar(this);
      ((AlertDialog)localObject).setOnDismissListener(localar);
    }
  }

  private void a(boolean paramBoolean)
  {
    int i = 1;
    Object localObject = this.jdField_a_of_type_AndroidMediaAudioManager;
    int j = this.jdField_a_of_type_Int;
    localObject = ((AudioManager)localObject).getStreamMaxVolume(j);
    if (paramBoolean)
    {
      AudioManager localAudioManager1 = this.jdField_a_of_type_AndroidMediaAudioManager;
      int k = this.jdField_a_of_type_Int;
      localAudioManager1.adjustStreamVolume(k, i, i);
      label45: AudioManager localAudioManager2 = this.jdField_a_of_type_AndroidMediaAudioManager;
      int l = this.jdField_a_of_type_Int;
      int i1 = localAudioManager2.getStreamVolume(l);
      int i2 = i1 * 255 / localObject;
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(localObject);
      if (i1 != 0)
        break label125;
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(i);
    }
    while (true)
    {
      return;
      AudioManager localAudioManager3 = this.jdField_a_of_type_AndroidMediaAudioManager;
      int i3 = this.jdField_a_of_type_Int;
      localAudioManager3.adjustStreamVolume(i3, -1, i);
      break label45:
      label125: this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(null);
    }
  }

  public static boolean checkVersion()
  {
    int i = getVersion();
    Object localObject;
    if (i < 4)
      localObject = null;
    while (true)
    {
      return localObject;
      int j = 1;
    }
  }

  public static int getVersion()
  {
    return Integer.parseInt(Build.VERSION.SDK);
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  protected void onCreate(Bundle paramBundle)
  {
    int i = 4;
    int j = 1;
    int k = 128;
    int l = 10;
    int i1 = 0;
    super.onCreate(paramBundle);
    boolean bool1 = checkVersion();
    if (!bool1)
      finish();
    while (true)
    {
      return;
      requestWindowFeature(j);
      getWindow().setFlags(k, k);
      getWindow().addFlags(k);
      Object localObject = getWindow();
      k = 1024;
      int i2 = 1024;
      ((Window)localObject).setFlags(k, i2);
      setRequestedOrientation(i1);
      localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = ((VideoController)localObject);
      localObject = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
      if (localObject == null)
        finish();
      localObject = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a();
      this.jdField_a_of_type_ComTencentMobileqqVideoVcCamera = ((VcCamera)localObject);
      setContentView(2130903055);
      int i4 = getResources().getDisplayMetrics().density;
      Display localDisplay = getWindowManager().getDefaultDisplay();
      localObject = (LinearLayout)findViewById(2131492972);
      this.jdField_a_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject);
      localObject = (LinearLayout)findViewById(2131492970);
      this.jdField_b_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject);
      localObject = (ImageView)findViewById(2131492962);
      this.jdField_a_of_type_AndroidWidgetImageView = ((ImageView)localObject);
      localObject = (ImageView)findViewById(2131492967);
      this.jdField_b_of_type_AndroidWidgetImageView = ((ImageView)localObject);
      localObject = (ImageView)findViewById(2131492973);
      this.jdField_c_of_type_AndroidWidgetImageView = ((ImageView)localObject);
      localObject = (ImageView)findViewById(2131492971);
      this.jdField_d_of_type_AndroidWidgetImageView = ((ImageView)localObject);
      localObject = (TextView)findViewById(2131492963);
      this.jdField_a_of_type_AndroidWidgetTextView = ((TextView)localObject);
      localObject = (TextView)findViewById(2131492968);
      this.jdField_b_of_type_AndroidWidgetTextView = ((TextView)localObject);
      localObject = (Chronometer)findViewById(2131492969);
      this.jdField_a_of_type_AndroidWidgetChronometer = ((Chronometer)localObject);
      localObject = (FrameLayout)findViewById(2131492961);
      this.jdField_a_of_type_AndroidWidgetFrameLayout = ((FrameLayout)localObject);
      localObject = (FrameLayout)findViewById(2131492966);
      this.jdField_b_of_type_AndroidWidgetFrameLayout = ((FrameLayout)localObject);
      localObject = (RelativeLayout)findViewById(2131492960);
      RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(2131492965);
      int i5 = localDisplay.getHeight() * 5 / 160;
      int i3 = localDisplay.getWidth();
      int i6 = i5 * 3;
      i6 = i3 - i6;
      i3 = localDisplay.getHeight();
      int i7 = i5 * 2;
      i7 = i3 - i7;
      RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.jdField_a_of_type_AndroidWidgetFrameLayout.getLayoutParams();
      int i8 = i6 * 7 / 10;
      localLayoutParams1.width = i8;
      int i9 = localLayoutParams1.width * 3 / 4;
      localLayoutParams1.height = i9;
      if (localLayoutParams1.height > i7)
      {
        localLayoutParams1.height = i7;
        int i10 = i7 * 4 / 3;
        localLayoutParams1.width = i7;
      }
      this.jdField_a_of_type_AndroidWidgetFrameLayout.setLayoutParams(localLayoutParams1);
      int i11 = (int)(i4 * 1077936128 + 1056964608);
      ((RelativeLayout)localObject).setPadding(i11, i11, i11, i11);
      RelativeLayout.LayoutParams localLayoutParams2 = (RelativeLayout.LayoutParams)((RelativeLayout)localObject).getLayoutParams();
      int i12 = localLayoutParams1.width;
      int i13 = i11 * 2;
      int i14 = i12 + i13;
      i4.width = i14;
      int i15 = localLayoutParams1.height;
      int i16 = i11 * 2;
      int i17 = i15 + i16;
      i4.height = i17;
      int i18 = localDisplay.getHeight();
      int i19 = i4.height;
      int i20 = (i18 - i19) / 2;
      localDisplay.getHeight();
      i4.topMargin = i20;
      i4.bottomMargin = i20;
      i4.leftMargin = i5;
      i4.rightMargin = i5;
      ((RelativeLayout)localObject).setLayoutParams(i4);
      int i21 = i4.height;
      this.jdField_d_of_type_Int = ((I)localObject);
      int i22 = i4.width;
      this.jdField_b_of_type_Int = ((I)localObject);
      RelativeLayout.LayoutParams localLayoutParams3 = (RelativeLayout.LayoutParams)this.jdField_a_of_type_AndroidWidgetImageView.getLayoutParams();
      int i23 = localLayoutParams1.width;
      ((RelativeLayout.LayoutParams)localObject).width = i4;
      int i24 = localLayoutParams1.height;
      ((RelativeLayout.LayoutParams)localObject).height = localLayoutParams1;
      this.jdField_a_of_type_AndroidWidgetImageView.setBackgroundResource(2130838064);
      this.jdField_a_of_type_AndroidWidgetImageView.setLayoutParams((ViewGroup.LayoutParams)localObject);
      RelativeLayout.LayoutParams localLayoutParams4 = (RelativeLayout.LayoutParams)this.jdField_b_of_type_AndroidWidgetFrameLayout.getLayoutParams();
      int i25 = this.jdField_b_of_type_Int;
      int i26 = i6 - localLayoutParams1;
      int i27 = i11 * 2;
      int i28 = localLayoutParams1 - i4;
      ((RelativeLayout.LayoutParams)localObject).width = localLayoutParams1;
      int i29 = ((RelativeLayout.LayoutParams)localObject).width * 3 / 4;
      ((RelativeLayout.LayoutParams)localObject).height = localLayoutParams1;
      this.jdField_b_of_type_AndroidWidgetFrameLayout.setLayoutParams((ViewGroup.LayoutParams)localObject);
      RelativeLayout.LayoutParams localLayoutParams5 = (RelativeLayout.LayoutParams)this.jdField_b_of_type_AndroidWidgetImageView.getLayoutParams();
      int i30 = ((RelativeLayout.LayoutParams)localObject).width;
      localLayoutParams1.width = i4;
      int i31 = ((RelativeLayout.LayoutParams)localObject).height;
      localLayoutParams1.height = i4;
      this.jdField_b_of_type_AndroidWidgetImageView.setBackgroundResource(2130838043);
      this.jdField_b_of_type_AndroidWidgetImageView.setLayoutParams(localLayoutParams1);
      this.jdField_b_of_type_AndroidWidgetImageView.setVisibility(i);
      this.jdField_b_of_type_AndroidWidgetTextView.setVisibility(i);
      localRelativeLayout.setPadding(i11, i11, i11, i11);
      RelativeLayout.LayoutParams localLayoutParams6 = (RelativeLayout.LayoutParams)localRelativeLayout.getLayoutParams();
      int i32 = ((RelativeLayout.LayoutParams)localObject).width;
      int i33 = i11 * 2;
      int i34 = i4 + localDisplay;
      localLayoutParams1.width = i4;
      int i35 = ((RelativeLayout.LayoutParams)localObject).height;
      int i36 = i11 * 2;
      int i37 = localObject + i4;
      localLayoutParams1.height = ((I)localObject);
      localLayoutParams1.topMargin = i20;
      localLayoutParams1.bottomMargin = 20;
      localLayoutParams1.rightMargin = i5;
      localLayoutParams1.leftMargin = i1;
      localRelativeLayout.setLayoutParams(localLayoutParams1);
      int i38 = localLayoutParams1.height;
      this.e = ((I)localObject);
      int i39 = localLayoutParams1.width;
      this.jdField_c_of_type_Int = ((I)localObject);
      int i40 = this.jdField_d_of_type_Int;
      int i41 = this.e;
      int i42 = localObject - localRelativeLayout - 20;
      RelativeLayout.LayoutParams localLayoutParams7 = (RelativeLayout.LayoutParams)this.jdField_a_of_type_AndroidWidgetLinearLayout.getLayoutParams();
      int i43 = this.jdField_c_of_type_Int;
      ((RelativeLayout.LayoutParams)localObject).width = localLayoutParams1;
      int i44 = localRelativeLayout * 4 / 11;
      ((RelativeLayout.LayoutParams)localObject).height = localLayoutParams1;
      ((RelativeLayout.LayoutParams)localObject).rightMargin = l;
      ((RelativeLayout.LayoutParams)localObject).leftMargin = l;
      this.jdField_a_of_type_AndroidWidgetLinearLayout.setLayoutParams((ViewGroup.LayoutParams)localObject);
      RelativeLayout.LayoutParams localLayoutParams8 = (RelativeLayout.LayoutParams)this.jdField_b_of_type_AndroidWidgetLinearLayout.getLayoutParams();
      int i45 = this.jdField_c_of_type_Int;
      ((RelativeLayout.LayoutParams)localObject).width = localLayoutParams1;
      int i46 = localRelativeLayout * 4 / 11;
      ((RelativeLayout.LayoutParams)localObject).height = localLayoutParams1;
      ((RelativeLayout.LayoutParams)localObject).rightMargin = l;
      ((RelativeLayout.LayoutParams)localObject).leftMargin = l;
      ((RelativeLayout.LayoutParams)localObject).bottomMargin = j;
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setLayoutParams((ViewGroup.LayoutParams)localObject);
      RelativeLayout.LayoutParams localLayoutParams9 = (RelativeLayout.LayoutParams)this.jdField_a_of_type_AndroidWidgetChronometer.getLayoutParams();
      int i47 = this.jdField_c_of_type_Int;
      ((RelativeLayout.LayoutParams)localObject).width = localLayoutParams1;
      int i48 = localRelativeLayout * 3 / 11;
      ((RelativeLayout.LayoutParams)localObject).height = localRelativeLayout;
      ((RelativeLayout.LayoutParams)localObject).rightMargin = l;
      ((RelativeLayout.LayoutParams)localObject).leftMargin = l;
      this.jdField_a_of_type_AndroidWidgetChronometer.setLayoutParams((ViewGroup.LayoutParams)localObject);
      this.jdField_a_of_type_AndroidWidgetChronometer.setGravity(17);
      this.jdField_a_of_type_AndroidWidgetChronometer.setText("00:00:00");
      uin = getIntent().getLongExtra("UID", 0L);
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(this);
      ChatVideoActivity.BroadcastsHandler localBroadcastsHandler1 = new ChatVideoActivity.BroadcastsHandler(this);
      this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler = ((ChatVideoActivity.BroadcastsHandler)localObject);
      ChatVideoActivity.BroadcastsHandler localBroadcastsHandler2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler;
      IntentFilter localIntentFilter = new IntentFilter("android.intent.action.HEADSET_PLUG");
      registerReceiver((BroadcastReceiver)localObject, localRelativeLayout);
      FrameLayout localFrameLayout1 = this.jdField_b_of_type_AndroidWidgetFrameLayout;
      FrameLayout localFrameLayout2 = this.jdField_a_of_type_AndroidWidgetFrameLayout;
      Preview localPreview1 = new Preview(this);
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview = ((Preview)localObject);
      RemoteView localRemoteView1 = new RemoteView(this);
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView = ((RemoteView)localObject);
      RemoteView localRemoteView2 = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView;
      localLayoutParams1.addView((View)localObject);
      Preview localPreview2 = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview;
      localRelativeLayout.addView((View)localObject);
      AudioManager localAudioManager = (AudioManager)getSystemService("audio");
      this.jdField_a_of_type_AndroidMediaAudioManager = ((AudioManager)localObject);
      this.jdField_a_of_type_Int = 3;
      int i49 = this.jdField_a_of_type_Int;
      setVolumeControlStream(localObject);
      boolean bool2 = VideoController.RejectSignalReceived;
      new al(this, localRelativeLayout, localLayoutParams1).start();
    }
  }

  protected void onDestroy()
  {
    int i = 0;
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.b(localBaseActionListener);
    if (this.jdField_a_of_type_AndroidMediaAudioManager != null)
    {
      AudioManager localAudioManager = this.jdField_a_of_type_AndroidMediaAudioManager;
      int j = this.jdField_a_of_type_Int;
      localAudioManager.setStreamSolo(j, null);
    }
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(i);
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b();
    try
    {
      this.jdField_a_of_type_JavaLangThread.stop();
      if (this.jdField_a_of_type_AndroidViewOrientationEventListener != null)
      {
        this.jdField_a_of_type_AndroidViewOrientationEventListener.disable();
        this.jdField_a_of_type_AndroidViewOrientationEventListener = i;
      }
      this.jdField_a_of_type_JavaLangThread = i;
      if (this.jdField_a_of_type_JavaUtilVector != null)
      {
        this.jdField_a_of_type_JavaUtilVector.clear();
        this.jdField_a_of_type_JavaUtilVector = i;
      }
      if (this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler != null)
      {
        ChatVideoActivity.BroadcastsHandler localBroadcastsHandler = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler;
        unregisterReceiver(localBroadcastsHandler);
        this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity$BroadcastsHandler = i;
      }
      Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
      Runnable localRunnable = this.jdField_a_of_type_JavaLangRunnable;
      localHandler.removeCallbacks(localRunnable);
      this.jdField_a_of_type_JavaLangRunnable = i;
      this.jdField_a_of_type_AndroidOsHandler = i;
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview.destroyDrawingCache();
      Preview localPreview = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview;
      SurfaceHolder localSurfaceHolder1 = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview.getHolder();
      localPreview.surfaceDestroyed(localSurfaceHolder1);
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewPreview = i;
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView.destroyDrawingCache();
      RemoteView localRemoteView = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView;
      SurfaceHolder localSurfaceHolder2 = this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView.getHolder();
      localRemoteView.surfaceDestroyed(localSurfaceHolder2);
      this.jdField_a_of_type_ComTencentMobileqqVideoSurfaceviewRemoteView = i;
      this.jdField_a_of_type_AndroidWidgetLinearLayout = i;
      this.jdField_b_of_type_AndroidWidgetLinearLayout = i;
      this.jdField_a_of_type_AndroidWidgetImageView = i;
      this.jdField_c_of_type_AndroidWidgetImageView = i;
      this.jdField_d_of_type_AndroidWidgetImageView = i;
      this.jdField_b_of_type_AndroidGraphicsBitmap = i;
      this.jdField_c_of_type_AndroidGraphicsBitmap = i;
      this.jdField_a_of_type_AndroidWidgetTextView = i;
      this.jdField_b_of_type_AndroidWidgetTextView = i;
      this.jdField_a_of_type_AndroidWidgetChronometer = i;
      this.jdField_a_of_type_ArrayOfByte = i;
      this.jdField_a_of_type_AndroidGraphicsBitmap.recycle();
      this.jdField_a_of_type_AndroidGraphicsBitmap = i;
      this.jdField_a_of_type_AndroidWidgetFrameLayout = i;
      this.jdField_b_of_type_AndroidWidgetFrameLayout = i;
      super.onDestroy();
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool1 = true;
    boolean bool2;
    switch (paramInt)
    {
    default:
      bool2 = super.onKeyDown(paramInt, paramKeyEvent);
    case 4:
    case 84:
    case 82:
    case 25:
    case 24:
    }
    while (true)
    {
      return bool2;
      a();
      bool2 = bool1;
      continue;
      bool2 = bool1;
      continue;
      bool2 = bool1;
      continue;
      a(null);
      bool2 = bool1;
      continue;
      a(bool1);
      bool2 = bool1;
    }
  }

  public void onPause()
  {
    getWindow().getDecorView().setVisibility(8);
    AudioManager localAudioManager = this.jdField_a_of_type_AndroidMediaAudioManager;
    int i = this.jdField_a_of_type_Int;
    localAudioManager.setStreamSolo(i, null);
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a().a();
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b(true);
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a().c();
    this.jdField_b_of_type_AndroidOsHandler.removeMessages(4);
    getWindow().clearFlags(128);
    super.onPause();
  }

  public void onResume()
  {
    int i = 4;
    boolean bool = true;
    super.onResume();
    setRequestedOrientation(0);
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b(null);
    AudioManager localAudioManager = this.jdField_a_of_type_AndroidMediaAudioManager;
    int j = this.jdField_a_of_type_Int;
    localAudioManager.setStreamSolo(j, bool);
    if (!this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a().b())
    {
      VideoController.notifyVideoChatEvent(2, 0L);
      VideoController localVideoController1 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
      long l1 = uin;
      localVideoController1.b(l1);
      finish();
    }
    while (true)
    {
      return;
      if (!this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a().c())
      {
        VideoController localVideoController2 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
        long l2 = uin;
        localVideoController2.b(l2);
        VideoController localVideoController3 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
        long l3 = uin;
        localVideoController3.a(l3, null);
      }
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setClickable(bool);
      this.jdField_b_of_type_AndroidWidgetFrameLayout.setClickable(bool);
      Handler localHandler1 = this.jdField_a_of_type_AndroidOsHandler;
      Runnable localRunnable1 = this.jdField_a_of_type_JavaLangRunnable;
      localHandler1.removeCallbacks(localRunnable1);
      Handler localHandler2 = this.jdField_a_of_type_AndroidOsHandler;
      Runnable localRunnable2 = this.jdField_a_of_type_JavaLangRunnable;
      localHandler2.postDelayed(localRunnable2, -16608L);
      this.jdField_b_of_type_AndroidOsHandler.removeMessages(i);
      getWindow().addFlags(128);
      this.jdField_b_of_type_AndroidOsHandler.sendEmptyMessageDelayed(i, -11072L);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatVideoActivity
 * JD-Core Version:    0.5.4
 */