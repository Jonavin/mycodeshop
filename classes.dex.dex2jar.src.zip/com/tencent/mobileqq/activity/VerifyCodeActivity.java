package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.qphone.base.remote.ToServiceMsg;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.QLog;
import gi;
import gj;
import gk;

public class VerifyCodeActivity extends Activity
{
  private static final String tag = "VerifyCodeActivity";
  int jdField_a_of_type_Int;
  private Bitmap jdField_a_of_type_AndroidGraphicsBitmap;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  private ToServiceMsg jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg;
  private BaseServiceHelper jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper;
  String jdField_a_of_type_JavaLangString;
  boolean jdField_a_of_type_Boolean;
  int jdField_b_of_type_Int;
  private Button jdField_b_of_type_AndroidWidgetButton;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  String jdField_b_of_type_JavaLangString;
  int jdField_c_of_type_Int;
  String jdField_c_of_type_JavaLangString;

  protected void onCreate(Bundle paramBundle)
  {
    int i = 0;
    super.onCreate(paramBundle);
    Object localObject = getIntent();
    String str1 = VerifyCodeActivity.class.getName();
    localObject = (ToServiceMsg)((Intent)localObject).getParcelableExtra(str1);
    this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg = ((ToServiceMsg)localObject);
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.extraData.getByteArray("pic");
    if (localObject != null)
    {
      int l = localObject.length;
      localObject = BitmapFactory.decodeByteArray(localObject, i, l);
      this.jdField_a_of_type_AndroidGraphicsBitmap = ((Bitmap)localObject);
    }
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.extraData.getString("verifySid");
    this.jdField_a_of_type_JavaLangString = ((String)localObject);
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.extraData.getInt("verifyAppSeq");
    this.jdField_a_of_type_Int = localObject;
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.extraData.getInt("wupRequestId");
    this.jdField_b_of_type_Int = localObject;
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.extraData.getString("notestr");
    this.jdField_b_of_type_JavaLangString = ((String)localObject);
    localObject = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.getRequestSsoSeq();
    this.jdField_c_of_type_Int = localObject;
    StringBuilder localStringBuilder1 = new StringBuilder().append("rece businessVerifyCode seq:");
    int i1 = this.jdField_c_of_type_Int;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i1).append(" uin:");
    String str2 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.uin;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" cmd:");
    String str3 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.getServiceCmd();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str3).append(" seqNo:");
    int i2 = this.jdField_a_of_type_Int;
    StringBuilder localStringBuilder5 = localStringBuilder4.append(i2).append(" sid:");
    String str4 = this.jdField_a_of_type_JavaLangString;
    StringBuilder localStringBuilder6 = localStringBuilder5.append(str4).append(" wupSeq:");
    int i3 = this.jdField_b_of_type_Int;
    String str5 = i3;
    QLog.d("VerifyCodeActivity", str5);
    localObject = this.jdField_a_of_type_JavaLangString;
    label309: int k;
    if (localObject == null)
    {
      int j = 1;
      this.jdField_a_of_type_Boolean = j;
      k = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.serviceCmd.indexOf(".");
      if (k <= 0)
        break label607;
      String str6 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.serviceCmd.substring(i, k);
    }
    label607: String str8;
    for (this.jdField_c_of_type_JavaLangString = k; ; this.jdField_c_of_type_JavaLangString = str8)
    {
      setContentView(2130903095);
      ImageView localImageView1 = (ImageView)findViewById(2131493145);
      this.jdField_a_of_type_AndroidWidgetImageView = localImageView1;
      ImageView localImageView2 = this.jdField_a_of_type_AndroidWidgetImageView;
      Bitmap localBitmap = this.jdField_a_of_type_AndroidGraphicsBitmap;
      localImageView2.setImageBitmap(localBitmap);
      EditText localEditText = (EditText)findViewById(2131493147);
      this.jdField_a_of_type_AndroidWidgetEditText = localEditText;
      Button localButton1 = (Button)findViewById(2131493149);
      this.jdField_a_of_type_AndroidWidgetButton = localButton1;
      Button localButton2 = (Button)findViewById(2131493148);
      this.jdField_b_of_type_AndroidWidgetButton = localButton2;
      TextView localTextView1 = (TextView)findViewById(2131493146);
      this.jdField_a_of_type_AndroidWidgetTextView = localTextView1;
      TextView localTextView2 = (TextView)findViewById(2131493144);
      this.jdField_b_of_type_AndroidWidgetTextView = localTextView2;
      TextView localTextView3 = this.jdField_b_of_type_AndroidWidgetTextView;
      String str7 = this.jdField_b_of_type_JavaLangString;
      localTextView3.setText(str7);
      int i4 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.getAppId();
      BaseActionListener localBaseActionListener = (BaseActionListener)this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.getActionListener();
      BaseServiceHelper localBaseServiceHelper = BaseServiceHelper.getBaseServiceHelper(i4, localBaseActionListener);
      this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseServiceHelper = localBaseServiceHelper;
      Button localButton3 = this.jdField_a_of_type_AndroidWidgetButton;
      gi localgi = new gi(this);
      localButton3.setOnClickListener(localgi);
      Button localButton4 = this.jdField_b_of_type_AndroidWidgetButton;
      gj localgj = new gj(this);
      localButton4.setOnClickListener(localgj);
      TextView localTextView4 = this.jdField_a_of_type_AndroidWidgetTextView;
      gk localgk = new gk(this);
      localTextView4.setOnClickListener(localgk);
      return;
      k = i;
      break label309:
      str8 = this.jdField_a_of_type_ComTencentQphoneBaseRemoteToServiceMsg.serviceCmd;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.VerifyCodeActivity
 * JD-Core Version:    0.5.4
 */