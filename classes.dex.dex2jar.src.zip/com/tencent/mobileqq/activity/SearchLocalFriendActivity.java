package com.tencent.mobileqq.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.data.FriendDetail;
import com.tencent.mobileqq.skin.SkinEngine;
import fr;
import ft;
import fu;
import java.util.ArrayList;
import java.util.List;

public class SearchLocalFriendActivity extends BaseActivity
  implements AdapterView.OnItemClickListener, AppConstants
{
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private ListView jdField_a_of_type_AndroidWidgetListView;
  private ft jdField_a_of_type_Ft;
  private List jdField_a_of_type_JavaUtilList;
  private List b;

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    this.jdField_a_of_type_AndroidWidgetEditText.setImeOptions(268435456);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903082);
    ImageView localImageView = (ImageView)findViewById(2131492865);
    this.jdField_a_of_type_AndroidWidgetImageView = localImageView;
    EditText localEditText1 = (EditText)findViewById(2131493119);
    this.jdField_a_of_type_AndroidWidgetEditText = localEditText1;
    EditText localEditText2 = this.jdField_a_of_type_AndroidWidgetEditText;
    fu localfu = new fu(this);
    localEditText2.addTextChangedListener(localfu);
    this.jdField_a_of_type_AndroidWidgetEditText.setSelection(0);
    ListView localListView1 = (ListView)findViewById(2131493120);
    this.jdField_a_of_type_AndroidWidgetListView = localListView1;
    ArrayList localArrayList1 = new ArrayList();
    this.jdField_a_of_type_JavaUtilList = localArrayList1;
    ArrayList localArrayList2 = new ArrayList();
    this.b = localArrayList2;
    List localList = this.b;
    ft localft1 = new ft(this, this, localList);
    this.jdField_a_of_type_Ft = localft1;
    ListView localListView2 = this.jdField_a_of_type_AndroidWidgetListView;
    ft localft2 = this.jdField_a_of_type_Ft;
    localListView2.setAdapter(localft2);
    this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this);
    fr localfr = new fr(this);
    new Thread(localfr).start();
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str = ((FriendDetail)this.b.get(paramInt)).getUin();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a[1].putExtra("uin", str);
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a[1].putExtra("uin type", 0);
    Intent localIntent = new Intent(this, HomeActivity.class).addCategory("android.intent.category.CHAT").addFlags(536870912).addFlags(67108864);
    startActivity(localIntent);
    finish();
  }

  protected void onResume()
  {
    super.onResume();
    if (this.jdField_a_of_type_AndroidWidgetImageView == null)
      return;
    int i = this.jdField_a_of_type_AndroidWidgetImageView.getId();
    Drawable localDrawable1 = this.jdField_a_of_type_AndroidWidgetImageView.getDrawable();
    Drawable localDrawable2 = SkinEngine.getSkinDrawable(i, "src", localDrawable1);
    this.jdField_a_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.SearchLocalFriendActivity
 * JD-Core Version:    0.5.4
 */