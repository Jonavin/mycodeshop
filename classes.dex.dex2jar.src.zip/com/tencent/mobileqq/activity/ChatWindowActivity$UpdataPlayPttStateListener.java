package com.tencent.mobileqq.activity;

public abstract interface ChatWindowActivity$UpdataPlayPttStateListener
{
  public abstract void a();
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatWindowActivity.UpdataPlayPttStateListener
 * JD-Core Version:    0.5.4
 */