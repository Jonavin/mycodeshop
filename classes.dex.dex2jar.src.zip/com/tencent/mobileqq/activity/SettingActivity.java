package com.tencent.mobileqq.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.util.DisplayMetrics;
import android.view.Window;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.ScreenShotDisableListener;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.qphone.base.remote.SimpleAccount;
import fv;
import fw;
import java.io.File;

public class SettingActivity extends PreferenceActivity
  implements ScreenShotDisableListener
{
  private SensorManager jdField_a_of_type_AndroidHardwareSensorManager;
  private CheckBoxPreference jdField_a_of_type_AndroidPreferenceCheckBoxPreference;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;

  private void b()
  {
    int i = 0;
    Object localObject1 = "background";
    Object localObject2 = (String)SkinEngine.getSkinData("contact_list_pic", (String)localObject1);
    if (localObject2 == null)
      return;
    localObject1 = ((String)localObject2).length();
    if (localObject1 == 0)
      return;
    StringBuilder localStringBuilder = new StringBuilder();
    String str = getBaseContext().getFilesDir().toString();
    localObject2 = str + "/Skin/" + (String)localObject2;
    localObject2 = new BitmapDrawable((String)localObject2).getBitmap();
    int k = getResources().getDisplayMetrics().density;
    int j = (int)(1110966272 * k);
    if (getResources().getDisplayMetrics().density < 1065353216)
      j = 46;
    int l = ((Bitmap)localObject2).getWidth();
    Bitmap localBitmap = Bitmap.createBitmap((Bitmap)localObject2, i, i, l, j);
    BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject2);
    ((TextView)findViewById(2131493034)).setBackgroundDrawable(j);
  }

  public final void a()
  {
    this.jdField_a_of_type_AndroidPreferenceCheckBoxPreference.setChecked(null);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    addPreferencesFromResource(2131034112);
    QQApplication localQQApplication = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
    this.jdField_a_of_type_AndroidHardwareSensorManager = localSensorManager;
    String str = getString(2131296356);
    CheckBoxPreference localCheckBoxPreference1 = (CheckBoxPreference)findPreference(str);
    fv localfv = new fv(this);
    localCheckBoxPreference1.setOnPreferenceChangeListener(localfv);
    getSharedPreferences("skin", 0).getString("skin", "qq_skin_blue");
    b();
    setVolumeControlStream(3);
    CheckBoxPreference localCheckBoxPreference2 = (CheckBoxPreference)((PreferenceGroup)getPreferenceScreen().getPreference(3)).getPreference(0);
    this.jdField_a_of_type_AndroidPreferenceCheckBoxPreference = localCheckBoxPreference2;
    CheckBoxPreference localCheckBoxPreference3 = this.jdField_a_of_type_AndroidPreferenceCheckBoxPreference;
    fw localfw = new fw(this);
    localCheckBoxPreference3.setOnPreferenceChangeListener(localfw);
  }

  protected void onResume()
  {
    int i = 1;
    super.onResume();
    BaseActivity.sensorEventListener.a = this;
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    String str = getString(2131296356);
    if (localSharedPreferences.getBoolean(str, i))
      setRequestedOrientation(2);
    while (true)
    {
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.d();
      getSharedPreferences("skin", 0).getString("skin", "qq_skin_blue");
      b();
      return;
      setRequestedOrientation(i);
    }
  }

  protected void onUserLeaveHint()
  {
    super.onUserLeaveHint();
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(this);
  }

  public void setContentView(int paramInt)
  {
    requestWindowFeature(7);
    super.setContentView(paramInt);
    getWindow().setFeatureInt(7, 2130903062);
  }

  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    boolean bool = BaseActivity.isMoveTaskToBack(this, paramIntent);
    if (!bool)
    {
      int i = 262144;
      paramIntent.addFlags(i);
    }
    Uri localUri1 = paramIntent.getData();
    if ((localUri1 != null) && (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() != null))
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = localUri1.toString();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(localUri1).append("&sid=");
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getSid();
      Uri localUri2 = Uri.parse(str2);
      paramIntent.setData(localUri1);
    }
    super.startActivityForResult(paramIntent, paramInt);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.SettingActivity
 * JD-Core Version:    0.5.4
 */