package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.service.MobileQQService;
import com.tencent.mobileqq.utils.TrafficData;
import com.tencent.mobileqq.widget.Workspace;
import com.tencent.mobileqq.widget.Workspace.OnScreenChangeListener;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.QLog;
import eh;
import ei;
import ej;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Set;

public class HomeActivity extends ActivityGroup
  implements Workspace.OnScreenChangeListener
{
  public static final String CATEGORY_CHAT = "android.intent.category.CHAT";
  public static final String CATEGORY_CONTACT = "android.intent.category.CONTACT";
  public static final int CHANGE_ACCOUNT = 65537;
  private static final int REQUEST_LOGIN = 1000;
  private static final int SCREEN_CHAT = 1;
  private static final int SCREEN_CONTACT_LIST;
  public static HomeActivity instance;
  public static boolean isRestart;
  private int jdField_a_of_type_Int;
  private QQApplication jdField_a_of_type_ComTencentMobileqqAppQQApplication;
  private Workspace jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
  private String jdField_a_of_type_JavaLangString;
  private boolean jdField_a_of_type_Boolean;
  private String jdField_b_of_type_JavaLangString;
  private boolean jdField_b_of_type_Boolean;
  private String jdField_c_of_type_JavaLangString;
  private boolean jdField_c_of_type_Boolean;
  private boolean d;

  public HomeActivity()
  {
    String str = super.getClass().getSimpleName();
    this.jdField_a_of_type_JavaLangString = str;
    this.jdField_a_of_type_Int = null;
    this.jdField_b_of_type_Boolean = true;
    this.d = null;
  }

  private void a()
  {
    AttributeSet localAttributeSet = null;
    int i = 1;
    int j = 0;
    boolean bool = this.jdField_a_of_type_Boolean;
    if (bool);
    while (true)
    {
      return;
      SharedPreferences localSharedPreferences = getSharedPreferences("mobileQQ", j);
      localSharedPreferences.edit();
      String str1 = localSharedPreferences.getString("qq_version", "");
      if ((str1.length() == 0) || (!str1.equals("0072")))
      {
        SharedPreferences.Editor localEditor = localSharedPreferences.edit();
        localSharedPreferences.putString("qq_version", "0072");
        localSharedPreferences.commit();
        Intent localIntent1 = new Intent(this, UserguideActivity.class);
        startActivity(localSharedPreferences);
      }
      Intent localIntent2 = new Intent(this, MobileQQService.class);
      startService(localIntent2);
      if ((this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace == null) || (this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.getChildCount() == 0))
      {
        Workspace localWorkspace1 = new Workspace(this, localAttributeSet);
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace = localWorkspace1;
        LocalActivityManager localLocalActivityManager = getLocalActivityManager();
        Intent localIntent3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
        Window localWindow = localLocalActivityManager.startActivity("0", localIntent3);
        localWindow.setBackgroundDrawable(localAttributeSet);
        Workspace localWorkspace2 = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
        View localView = localWindow.getDecorView();
        localWorkspace2.addView(localView);
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.setOnScreenChangeListener(this);
        Workspace localWorkspace3 = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
        setContentView(localWorkspace3);
      }
      this.jdField_a_of_type_Int = i;
      Intent localIntent4 = getIntent();
      b(localIntent4);
      this.jdField_a_of_type_Int = j;
      this.jdField_a_of_type_Boolean = i;
      if (!this.d)
        continue;
      Intent localIntent5 = new Intent(this, TroopMemberlistActivity.class);
      String str2 = this.jdField_c_of_type_JavaLangString;
      Intent localIntent6 = localIntent5.putExtra("groupUin", str2);
      startActivity(localIntent6);
      this.d = j;
    }
  }

  private void a(Intent paramIntent)
  {
    boolean bool = true;
    Object localObject = paramIntent.getExtras();
    if (localObject != null)
    {
      String str1 = ((Bundle)localObject).getString("selfuin");
      this.jdField_b_of_type_JavaLangString = str1;
      localObject = ((Bundle)localObject).getString("groupUin");
      this.jdField_c_of_type_JavaLangString = ((String)localObject);
      localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      if (localObject == null)
        break label110;
      localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      if (this.jdField_b_of_type_JavaLangString != null)
      {
        if (this.jdField_b_of_type_JavaLangString.equals(localObject))
          break label85;
        showDialog(65537);
      }
    }
    while (true)
    {
      return;
      label85: if ((this.jdField_c_of_type_JavaLangString == null) || (this.jdField_c_of_type_JavaLangString.length() == 0))
        continue;
      this.d = bool;
      continue;
      label110: if (this.jdField_b_of_type_JavaLangString == null)
        continue;
      QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      String str2 = this.jdField_b_of_type_JavaLangString;
      localQQApplication.a(str2);
      SharedPreferences.Editor localEditor = getSharedPreferences("mobileQQ", 0).edit();
      String str3 = this.jdField_b_of_type_JavaLangString;
      localEditor.putString("currentAccount", str3);
      String str4 = this.jdField_b_of_type_JavaLangString;
      localEditor.putBoolean(str4, bool);
      localEditor.commit();
      if ((this.jdField_c_of_type_JavaLangString == null) || (this.jdField_c_of_type_JavaLangString.length() == 0))
        continue;
      this.d = bool;
    }
  }

  private void b(Intent paramIntent)
  {
    int i = 0;
    int j = 1;
    Bundle localBundle = paramIntent.getExtras();
    Set localSet = paramIntent.getCategories();
    if (localSet != null)
      if (localSet.contains("android.intent.category.CONTACT"))
      {
        this.jdField_b_of_type_Boolean = i;
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.a(i);
        if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler != null)
          this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(i);
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.getChildAt(i).requestFocus();
      }
    while (true)
    {
      label80: return;
      if (!localSet.contains("android.intent.category.CHAT"))
        continue;
      this.jdField_b_of_type_Boolean = i;
      if (localBundle != null)
      {
        if (localBundle.getString("uin") != null)
        {
          Intent localIntent1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
          String str1 = localBundle.getString("uin");
          localIntent1.putExtra("uin", str1);
          Intent localIntent2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
          int k = localBundle.getInt("uin type");
          localIntent2.putExtra("uin type", k);
        }
        Intent localIntent3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
        boolean bool = localBundle.getBoolean("single");
        localIntent3.putExtra("single", bool);
        Intent localIntent4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
        String str2 = localBundle.getString("selfuin");
        localIntent4.putExtra("selfuin", localBundle);
      }
      if (this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.getChildCount() == j)
      {
        LocalActivityManager localLocalActivityManager = getLocalActivityManager();
        Intent localIntent5 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[j];
        Window localWindow = localLocalActivityManager.startActivity("1", localIntent5);
        Workspace localWorkspace = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
        View localView = localWindow.getDecorView();
        localWorkspace.addView(localView);
        this.jdField_c_of_type_Boolean = i;
      }
      if (this.jdField_a_of_type_Int == j)
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.setCurrentScreen(j);
      while (true)
      {
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.getChildAt(j).requestFocus();
        if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.b != null);
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.b.sendEmptyMessage(i);
        break label80:
        this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.a(j);
      }
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler == null)
        continue;
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(i);
    }
  }

  private void c(int paramInt)
  {
    if ((paramInt == 0) && (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler != null))
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(0);
    if (this.jdField_c_of_type_Boolean)
    {
      LocalActivityManager localLocalActivityManager = getLocalActivityManager();
      String str = String.valueOf(paramInt);
      Intent localIntent = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[paramInt];
      localLocalActivityManager.startActivity(str, localIntent);
    }
    this.jdField_c_of_type_Boolean = true;
  }

  public final void a(int paramInt)
  {
    if (this.jdField_b_of_type_Boolean)
      return;
    c(paramInt);
  }

  public final void b(int paramInt)
  {
    if (this.jdField_b_of_type_Boolean)
      c(paramInt);
    this.jdField_b_of_type_Boolean = true;
  }

  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    Activity localActivity = getCurrentActivity();
    int j;
    if (localActivity instanceof ChatWindowActivity)
    {
      boolean bool1 = ((ChatWindowActivity)localActivity).jdField_b_of_type_Boolean;
      if (bool1)
      {
        int i = paramMotionEvent.getAction();
        if (i != 0)
        {
          i = paramMotionEvent.getAction();
          if (i != 2)
            break label47;
        }
        j = 1;
      }
    }
    while (true)
    {
      return j;
      label47: boolean bool2 = super.dispatchTouchEvent(paramMotionEvent);
    }
  }

  public void finishFromChild(Activity paramActivity)
  {
    int i = 1;
    int j = 0;
    int i1 = j;
    label7: int k = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.getChildCount();
    String str;
    Object localObject;
    if (i1 < k)
    {
      str = String.valueOf(i1);
      localObject = getLocalActivityManager().getActivity(str);
      if ((localObject == paramActivity) && (i1 > 0))
      {
        localObject = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
        int i2 = i1 - i;
        ((Workspace)localObject).a(i);
      }
    }
    try
    {
      localObject = getLocalActivityManager().getClass().getDeclaredField("mActivities");
      if (!((Field)localObject).isAccessible())
        ((Field)localObject).setAccessible(true);
      LocalActivityManager localLocalActivityManager = getLocalActivityManager();
      localObject = (HashMap)((Field)localObject).get(localLocalActivityManager);
      if (localObject != null)
      {
        getLocalActivityManager().destroyActivity(str, true);
        ((HashMap)localObject).remove(str);
      }
      Handler localHandler = new Handler();
      ej localej = new ej(this, i1);
      localHandler.postDelayed(localej, 500L);
      return;
      int l = i1 + 1;
      i1 = l;
      break label7:
      super.finishFromChild(paramActivity);
    }
    catch (Exception localException)
    {
    }
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 1000)
    {
      if (paramInt2 != -1)
        break label47;
      a();
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler != null)
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(0);
    }
    while (true)
    {
      return;
      label47: finish();
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    Activity localActivity = getCurrentActivity();
    if (localActivity == null)
      return;
    localActivity.onConfigurationChanged(paramConfiguration);
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool1 = null;
    super.onCreate(paramBundle);
    instance = this;
    Object localObject1 = "HomeActivity onCreate " + paramBundle;
    QLog.i("System.out", (String)localObject1);
    Object localObject3 = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = ((QQApplication)localObject3);
    localObject3 = getIntent();
    localObject1 = ((Intent)localObject3).getBooleanExtra("restart", bool1);
    boolean bool2 = isRestart;
    a((Intent)localObject3);
    boolean bool3 = ((Intent)localObject3).getBooleanExtra("need login", bool1);
    label100: Object localObject2;
    if ((bool3) && (paramBundle == null))
    {
      int i = 1;
      ((Intent)localObject3).removeExtra("need login");
      localObject3 = getSharedPreferences("mobileQQ", bool1);
      if (i != null)
        break label176;
      localObject2 = ((SharedPreferences)localObject3).getString("currentAccount", null);
      if ((localObject2 == null) || (!((SharedPreferences)localObject3).getBoolean((String)localObject2, bool1)))
        break label176;
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a((String)localObject2);
      a();
    }
    while (true)
    {
      return;
      localObject2 = bool1;
      break label100:
      label176: Intent localIntent = new Intent("com.tencent.mobileqq.action.LOGIN").addFlags(262144);
      startActivityForResult(localIntent, 1000);
    }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    default:
      i = 0;
    case 65537:
    }
    while (true)
    {
      return i;
      Object localObject = new AlertDialog.Builder(this).setTitle("鍒囨").setMessage("");
      ei localei = new ei(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton("鍒", localei);
      eh localeh = new eh(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton("鍙", localeh).create();
    }
  }

  protected void onDestroy()
  {
    boolean bool1 = null;
    super.onDestroy();
    int i;
    isRestart = i;
    if (i != 0)
      label14: return;
    HomeActivity localHomeActivity = instance;
    if (localHomeActivity == this)
    {
      int j = 0;
      instance = j;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.jdField_a_of_type_JavaLangString;
    String str2 = str1 + " onDestroy ";
    QLog.i("System.out", str2);
    Object localObject = PreferenceManager.getDefaultSharedPreferences(this);
    String str3 = getString(2131296349);
    localObject = ((SharedPreferences)localObject).getBoolean(str3, bool1);
    int k;
    if (localObject == 0)
      k = 1;
    while (true)
    {
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(k);
      if (k != null);
      Intent localIntent = new Intent(this, MobileQQService.class);
      stopService(localIntent);
      break label14:
      boolean bool2 = bool1;
    }
  }

  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    setIntent(paramIntent);
    a(paramIntent);
    if (!this.jdField_a_of_type_Boolean)
      a();
    while (true)
    {
      if (this.d)
      {
        Intent localIntent1 = new Intent(this, TroopMemberlistActivity.class);
        String str = this.jdField_c_of_type_JavaLangString;
        Intent localIntent2 = localIntent1.putExtra("groupUin", str);
        startActivity(localIntent2);
        this.d = null;
      }
      return;
      b(paramIntent);
    }
  }

  protected void onPrepareDialog(int paramInt, Dialog paramDialog)
  {
    if (65537 != paramInt)
      return;
    AlertDialog localAlertDialog = (AlertDialog)paramDialog;
    Object[] arrayOfObject = new Object[2];
    String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    arrayOfObject[0] = str1;
    String str2 = this.jdField_b_of_type_JavaLangString;
    arrayOfObject[1] = str2;
    String str3 = String.format("鎵嬫満QQ鍘熸湁甯愬彿%s灏嗚", arrayOfObject);
    paramDialog.setMessage(str3);
  }

  protected void onResume()
  {
    super.onResume();
    Bundle localBundle = getIntent().getExtras();
    Activity localActivity = getCurrentActivity();
    if ((!localActivity instanceof ContactActivity) || (localBundle == null))
      return;
    int i = getIntent().getExtras().getInt("TabPosition");
    ((ContactActivity)localActivity).a(i, true);
  }

  protected void onStop()
  {
    super.onStop();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsTrafficData.a();
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
      return;
    Intent localIntent = new Intent("tencent.notify.activity.stopped");
    String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
    localIntent.putExtra("selfuin", str);
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Boolean localBoolean = Boolean.valueOf(null);
    int i = localQQApplication.a(localBoolean);
    localIntent.putExtra("unreadmsg", i);
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.sendBroadcast(localIntent, "com.tencent.msg.permission.pushnotify");
  }

  protected void onUserLeaveHint()
  {
    super.onUserLeaveHint();
    Object localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    if (localObject != null)
    {
      localObject = getCurrentActivity();
      if ((!localObject instanceof ContactActivity) || (!((ContactActivity)localObject).jdField_b_of_type_Boolean))
        break label39;
    }
    while (true)
    {
      return;
      label39: this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(this);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.HomeActivity
 * JD-Core Version:    0.5.4
 */