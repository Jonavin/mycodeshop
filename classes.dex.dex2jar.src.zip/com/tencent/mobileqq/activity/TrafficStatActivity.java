package com.tencent.mobileqq.activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.utils.FileUtils;
import com.tencent.mobileqq.utils.TrafficData;
import com.tencent.qphone.base.util.BaseApplication;
import gb;
import gc;

public class TrafficStatActivity extends BaseActivity
{
  Handler a;

  public TrafficStatActivity()
  {
    gc localgc = new gc(this);
    this.a = localgc;
  }

  private void a()
  {
    int i = 2131493124;
    int j = 10;
    long[] arrayOfLong1 = 2;
    long[] arrayOfLong2 = 0;
    Object localObject = ((QQApplication)getApplication()).a;
    ((TrafficData)localObject).b();
    long[] arrayOfLong3 = BaseApplication.getCurrentDataCount(arrayOfLong2);
    long[] arrayOfLong4 = ((TrafficData)localObject).a;
    long l1 = arrayOfLong3[arrayOfLong2];
    arrayOfLong4[arrayOfLong2] = l1;
    arrayOfLong4 = ((TrafficData)localObject).a;
    l1 = arrayOfLong3[1];
    arrayOfLong4[1] = l1;
    arrayOfLong4 = ((TrafficData)localObject).a;
    l1 = arrayOfLong3[arrayOfLong1];
    arrayOfLong4[j] = l1;
    arrayOfLong4 = ((TrafficData)localObject).a;
    int i1 = 11;
    long l2 = arrayOfLong3[3];
    arrayOfLong4[i1] = l2;
    for (arrayOfLong3 = arrayOfLong2; arrayOfLong3 < arrayOfLong1; ++arrayOfLong3)
      for (arrayOfLong4 = arrayOfLong2; arrayOfLong4 < arrayOfLong1; ++arrayOfLong4)
      {
        i1 = arrayOfLong2;
        for (int i3 = arrayOfLong2; i3 < 4; ++i3)
        {
          long l3 = i1;
          long[] arrayOfLong5 = ((TrafficData)localObject).a;
          int i5 = (arrayOfLong3 * 5 + i3) * 2 + arrayOfLong4;
          long l4 = arrayOfLong5[i5];
          i2 = (int)(l3 + l4);
        }
        long[] arrayOfLong6 = ((TrafficData)localObject).a;
        int i6 = arrayOfLong3 * 5;
        int i4 = (i3 + i6) * 2 + arrayOfLong4;
        long l5 = i2;
        arrayOfLong6[i4] = l5;
      }
    arrayOfLong4 = ((TrafficData)localObject).a;
    localObject = (ViewGroup)findViewById(2131492866);
    for (int i2 = arrayOfLong2; i2 < j; i2 = l)
    {
      int k = i + i2;
      TextView localTextView1 = (TextView)((ViewGroup)localObject).findViewById(k);
      String str1 = FileUtils.byteCountToDisplaySize(arrayOfLong4[i2]);
      localTextView1.setText(str1);
      l = i2 + 1;
    }
    this = (ViewGroup)findViewById(2131492867);
    int l = arrayOfLong2;
    while (l < j)
    {
      int i7 = i + l;
      TextView localTextView2 = (TextView)super.findViewById(i7);
      int i8 = l + 10;
      String str2 = FileUtils.byteCountToDisplaySize(arrayOfLong4[i8]);
      localTextView2.setText(str2);
      l += 1;
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    Button localButton = (Button)findViewById(2131492868);
    gb localgb = new gb(this);
    localButton.setOnClickListener(localgb);
  }

  protected void onPause()
  {
    this.a.removeMessages(0);
    super.onPause();
  }

  protected void onResume()
  {
    super.onResume();
    this.a.sendEmptyMessageDelayed(0, -5536L);
    a();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.TrafficStatActivity
 * JD-Core Version:    0.5.4
 */