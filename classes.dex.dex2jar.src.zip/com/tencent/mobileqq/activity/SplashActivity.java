package com.tencent.mobileqq.activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.log.ExceptionHandler;
import fx;

public class SplashActivity extends BaseActivity
{
  private Handler jdField_a_of_type_AndroidOsHandler;
  private Runnable jdField_a_of_type_JavaLangRunnable;

  public SplashActivity()
  {
    fx localfx = new fx(this);
    this.jdField_a_of_type_JavaLangRunnable = localfx;
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    getWindow().addFlags(1024);
    setContentView(2130903084);
    Handler localHandler1 = new Handler();
    this.jdField_a_of_type_AndroidOsHandler = localHandler1;
    Handler localHandler2 = this.jdField_a_of_type_AndroidOsHandler;
    Runnable localRunnable = this.jdField_a_of_type_JavaLangRunnable;
    localHandler2.postDelayed(localRunnable, 2000L);
    ExceptionHandler.register((QQApplication)getApplication());
  }

  protected void onDestroy()
  {
    super.onDestroy();
    Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
    Runnable localRunnable = this.jdField_a_of_type_JavaLangRunnable;
    localHandler.removeCallbacks(localRunnable);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.SplashActivity
 * JD-Core Version:    0.5.4
 */