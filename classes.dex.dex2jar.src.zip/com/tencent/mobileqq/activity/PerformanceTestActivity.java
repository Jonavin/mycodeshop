package com.tencent.mobileqq.activity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import com.tencent.mobileqq.app.QQApplication;
import fg;
import fh;
import fj;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

public class PerformanceTestActivity extends BaseActivity
{
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903086);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    paramMenu.add("start");
    paramMenu.add("end");
    paramMenu.add("test transaction");
    return true;
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    Object localObject1 = paramMenuItem.getTitle();
    Object localObject2 = "start";
    localObject1 = localObject1.equals(localObject2);
    if (localObject1 != 0)
    {
      QQApplication localQQApplication = this.a;
      fg localfg = new fg(this);
      localQQApplication.a(localfg);
    }
    do
    {
      return true;
      localObject2 = paramMenuItem.getTitle();
      localObject1 = "test transaction".equals(localObject2);
    }
    while (localObject1 == 0);
    localObject2 = new fh(this);
    localObject1 = new Timer();
    ((Timer)localObject1).schedule((TimerTask)localObject2, 0L, 10L);
    localObject2 = new Vector();
    Object localObject3 = null;
    while (localObject3 < 13)
    {
      fj localfj = new fj(this, (List)localObject2, (Timer)localObject1);
      ((List)localObject2).add(localfj);
      ++localObject3;
    }
    localObject1 = ((List)localObject2).iterator();
    while (true)
    {
      if (((Iterator)localObject1).hasNext());
      ((Thread)((Iterator)localObject1).next()).start();
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.PerformanceTestActivity
 * JD-Core Version:    0.5.4
 */