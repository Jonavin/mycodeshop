package com.tencent.mobileqq.activity;

import aa;
import ab;
import ac;
import ad;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.FriendInfo;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.utils.Recorder;
import com.tencent.mobileqq.utils.ShapeUtils;
import com.tencent.mobileqq.widget.CustomDrawable1;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import p;
import w;
import y;
import z;

public class ChatHistory extends BaseActivity
{
  private static final int DELROAMMSG_FAIL_HANDLER = 5;
  public static final int ENTER_PHOTO_PRIVIEW_CODE = 200;
  private static final String FWD_URL_GROUPROAMMSG = "http://kiss.3g.qq.com/activeQQ/mqq/groupMsg_wap20.jsp?bid=591&sid=%s&groupName=%s&groupCode=%s";
  private static final int GETROAMMSG_FAIL_HANDLER = 1;
  private static final int GETROAMMSG_SUC_HANDLER = 0;
  private static final int MSG_UPDATE_STATUS_INFO = 4;
  private static final int SETROAMMSGALLUSER_FAIL_HANDLER = 3;
  private static final int SETROAMMSGALLUSER_SUC_HANDLER = 2;
  private static final int SEVEN_DAYS = 604800;
  private static Toast mToast;
  private float jdField_a_of_type_Float;
  public int a;
  private Dialog jdField_a_of_type_AndroidAppDialog;
  private Handler jdField_a_of_type_AndroidOsHandler;
  public View a;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private ImageButton jdField_a_of_type_AndroidWidgetImageButton;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private ListView jdField_a_of_type_AndroidWidgetListView;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  private ChatHistory.ChatHistoryAdapter jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter;
  public Recorder a;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  public Object a;
  public String a;
  private StringBuffer jdField_a_of_type_JavaLangStringBuffer;
  public boolean a;
  private int jdField_b_of_type_Int;
  private Dialog jdField_b_of_type_AndroidAppDialog;
  private View jdField_b_of_type_AndroidViewView;
  private Button jdField_b_of_type_AndroidWidgetButton;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  public String b;
  private int jdField_c_of_type_Int;
  private TextView jdField_c_of_type_AndroidWidgetTextView;
  private final String jdField_c_of_type_JavaLangString = "ChatHistory";
  private int jdField_d_of_type_Int;
  private String jdField_d_of_type_JavaLangString;
  private int e;
  private final int f;
  private int g;
  private final int h;
  private final int i;
  private final int j;

  public ChatHistory()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    this.jdField_a_of_type_JavaLangStringBuffer = localStringBuffer;
    this.e = 1;
    this.f = 8;
    this.g = null;
    this.jdField_a_of_type_ComTencentMobileqqUtilsRecorder = null;
    this.jdField_a_of_type_AndroidViewView = null;
    this.jdField_a_of_type_Int = -1;
    this.jdField_a_of_type_Boolean = true;
    this.h = 12;
    this.i = 110;
    this.j = 60;
    p localp = new p(this);
    this.jdField_a_of_type_AndroidOsHandler = localp;
    w localw = new w(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localw;
  }

  private int a(String paramString, int paramInt)
  {
    String str1 = null;
    Object localObject1 = null;
    Object localObject2;
    Object localObject3;
    if (paramInt == 0)
    {
      localObject2 = "mr_friend_" + paramString;
      localObject3 = localObject2;
      label34: localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
      String str2 = str1;
      String str3 = str1;
      String str4 = str1;
      localObject3 = ((EntityManager)localObject2).a((String)localObject3, str1, str2, str3, str4);
      if (localObject3 == null)
        break label132;
      int k = ((Cursor)localObject3).getCount();
      ((Cursor)localObject3).close();
      localObject3 = k;
    }
    while (true)
    {
      ((EntityManager)localObject2).a();
      return localObject3;
      localObject2 = "mr_troop_" + paramString;
      localObject3 = localObject2;
      break label34:
      label132: localObject3 = localObject1;
    }
  }

  private String a()
  {
    String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getNickName();
    if ((str != null) && (!str.trim().equals("")));
    while (true)
    {
      return str;
      str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    }
  }

  private void b()
  {
    int k = 2131296378;
    int l = 2131296377;
    int i1 = 1;
    Object localObject1 = 0;
    int i2 = 13;
    Object localObject2 = (ImageView)findViewById(16908294);
    ((ImageView)localObject2).setClickable(localObject1);
    TextView localTextView = (TextView)findViewById(16908308);
    Object localObject3 = (TextView)findViewById(16908309);
    this.jdField_b_of_type_AndroidWidgetTextView = ((TextView)localObject3);
    localObject3 = (ImageView)findViewById(2131493078);
    int i9 = 4;
    ((ImageView)localObject3).setVisibility(i9);
    int i3 = this.jdField_b_of_type_Int;
    if (i3 == 0)
    {
      EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
      Object localObject7 = this.jdField_d_of_type_JavaLangString;
      Object localObject4 = (Friends)localEntityManager.a(Friends.class, (String)localObject7);
      if (localObject4 == null)
      {
        localObject4 = this.jdField_d_of_type_JavaLangString.equals("10000");
        if (localObject4 != 0)
        {
          localObject4 = getResources().getDrawable(2130838047);
          ((ImageView)localObject2).setImageDrawable((Drawable)localObject4);
          label173: localObject2 = this.jdField_a_of_type_JavaLangString;
          if (localObject2 != null)
          {
            localObject2 = this.jdField_a_of_type_JavaLangString.trim().length();
            if (localObject2 != 0)
              break label272;
          }
          localObject4 = this.jdField_d_of_type_JavaLangString;
          localObject2 = (FriendInfo)localEntityManager.a(FriendInfo.class, (String)localObject4);
          if (localObject2 == null)
            break label501;
          localObject4 = ((FriendInfo)localObject2).nickname;
          if (localObject4 == null)
            break label501;
          localObject4 = ((FriendInfo)localObject2).nickname.trim().equals("");
          if (localObject4 != 0)
            break label501;
          localObject2 = ((FriendInfo)localObject2).nickname;
        }
      }
      for (this.jdField_a_of_type_JavaLangString = ((String)localObject2); ; this.jdField_a_of_type_JavaLangString = ((String)localObject2))
      {
        while (true)
        {
          label272: localEntityManager.a();
          localObject2 = this.jdField_d_of_type_JavaLangString;
          localObject4 = "10000";
          localObject2 = ((String)localObject2).equals(localObject4);
          if (localObject2 == 0)
            break label555;
          localObject2 = "绯荤";
          label307: localTextView.setText((CharSequence)localObject2);
          StringBuilder localStringBuilder2 = new StringBuilder();
          String str1 = getString(2131296388);
          StringBuilder localStringBuilder3 = ((StringBuilder)localObject2).append(localTextView);
          int i10 = this.jdField_c_of_type_Int;
          StringBuilder localStringBuilder4 = ((StringBuilder)localObject2).append(localTextView);
          String str2 = getString(2131296389);
          String str3 = localTextView;
          this.jdField_b_of_type_AndroidWidgetTextView.setText((CharSequence)localObject2);
          String str4 = a();
          this.jdField_b_of_type_JavaLangString = ((String)localObject2);
          return;
          localObject4 = getResources().getDrawable(2130837749);
          ((ImageView)localObject2).setImageDrawable((Drawable)localObject4);
          break label173:
          localObject7 = ((Friends)localObject4).name;
          this.jdField_a_of_type_JavaLangString = ((String)localObject7);
          localObject7 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
          int i11 = ((Friends)localObject4).faceid;
          String str5 = this.jdField_d_of_type_JavaLangString;
          int i4 = ((Friends)localObject4).status;
          if (i4 != 10);
          for (i4 = i1; ; localObject5 = localObject1)
          {
            localObject5 = ((QQApplication)localObject7).a(i11, str5, i4, i1);
            ((ImageView)localObject2).setImageDrawable((Drawable)localObject5);
            break label173:
          }
          label501: localObject2 = this.jdField_d_of_type_JavaLangString;
          Object localObject5 = "10000";
          localObject2 = ((String)localObject2).equals(localObject5);
          if (localObject2 == 0)
            break;
          localObject2 = "绯荤";
          this.jdField_a_of_type_JavaLangString = ((String)localObject2);
        }
        localObject2 = this.jdField_d_of_type_JavaLangString;
      }
      label555: localObject2 = null;
      int i5 = this.jdField_a_of_type_JavaLangString.getBytes().length;
      if (i5 > i2)
      {
        i5 = getResources().getConfiguration().orientation;
        if (i5 == i1)
        {
          localObject2 = this.jdField_a_of_type_JavaLangString;
          int i6 = ((String)localObject2).toCharArray().length;
          if (i6 > i2);
          for (i6 = i2; i6 > 0; --i6)
          {
            localObject2 = ((String)localObject2).substring(localObject1, i6);
            if (((String)localObject2).getBytes().length <= i2)
              break;
          }
        }
      }
      localObject6 = new StringBuilder();
      String str6 = getResources().getString(l);
      localObject6 = ((StringBuilder)localObject6).append(str6);
      if (localObject2 == null);
      for (localObject2 = this.jdField_a_of_type_JavaLangString; ; localObject2 = (String)localObject2 + "...")
      {
        localObject2 = ((StringBuilder)localObject6).append((String)localObject2);
        String str7 = getResources().getString(k);
        localObject2 = (String)localObject6;
        break label307:
      }
    }
    Object localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    String str8 = this.jdField_d_of_type_JavaLangString;
    localObject6 = ((QQApplication)localObject6).b(str8);
    this.jdField_a_of_type_JavaLangString = ((String)localObject6);
    localObject6 = this.jdField_a_of_type_JavaLangString;
    if (localObject6 != null)
    {
      localObject6 = this.jdField_a_of_type_JavaLangString.trim().equals("");
      if (localObject6 == 0)
        break label819;
    }
    localObject6 = this.jdField_d_of_type_JavaLangString;
    this.jdField_a_of_type_JavaLangString = ((String)localObject6);
    label819: localObject6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getResources().getDrawable(2130837734);
    ((ImageView)localObject2).setImageDrawable((Drawable)localObject6);
    localObject2 = null;
    int i7 = this.jdField_a_of_type_JavaLangString.getBytes().length;
    if (i7 > i2)
    {
      i7 = getResources().getConfiguration().orientation;
      if (i7 == i1)
      {
        localObject2 = this.jdField_a_of_type_JavaLangString;
        int i8 = ((String)localObject2).toCharArray().length;
        if (i8 > i2);
        for (i8 = i2; i8 > 0; --i8)
        {
          localObject2 = ((String)localObject2).substring(localObject1, i8);
          if (((String)localObject2).getBytes().length <= i2)
            break;
        }
      }
    }
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str9 = getResources().getString(l);
    localStringBuilder1 = localStringBuilder1.append(str9);
    if (localObject2 == null);
    for (localObject2 = this.jdField_a_of_type_JavaLangString; ; localObject2 = (String)localObject2 + "...")
    {
      localObject2 = localStringBuilder1.append((String)localObject2);
      String str10 = getResources().getString(k);
      localObject2 = localStringBuilder1;
      break label307:
    }
  }

  private static void cancelToastTip()
  {
    if (mToast == null)
      return;
    mToast.cancel();
    mToast = null;
  }

  private static String getExportMsgTime(long paramLong)
  {
    Locale localLocale = Locale.SIMPLIFIED_CHINESE;
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("", localLocale);
    localSimpleDateFormat.applyPattern("yyyy-MM-dd HH:mm:ss");
    Long localLong = Long.valueOf(paramLong);
    return localSimpleDateFormat.format(localLong);
  }

  public static boolean isValidFileName(String paramString)
  {
    Object localObject1 = 1;
    boolean bool1 = false;
    if (paramString != null)
    {
      bool2 = paramString.trim().equals("");
      if (!bool2)
        break label26;
    }
    label26: Object localObject2;
    for (boolean bool2 = bool1; ; localObject2 = bool1)
      while (true)
      {
        return bool2;
        localObject2 = Pattern.compile("^[+,./=_-]+");
        String str = paramString.substring(bool1, localObject1);
        localObject2 = ((Pattern)localObject2).matcher(str).matches();
        if (localObject2 != 0)
          break;
        localObject2 = localObject1;
      }
  }

  public final void a()
  {
    int k = 0;
    Drawable localDrawable1 = null;
    if (this.jdField_a_of_type_AndroidViewView != null)
    {
      Object localObject1 = this.jdField_a_of_type_AndroidViewView.getTag();
      Object localObject2 = this.jdField_a_of_type_JavaLangObject;
      if (localObject1.equals(localObject2))
      {
        Drawable localDrawable2 = getResources().getDrawable(2130838036);
        int l = localDrawable2.getMinimumWidth();
        int i1 = localDrawable2.getMinimumHeight();
        localDrawable2.setBounds(k, k, l, i1);
        ((Button)this.jdField_a_of_type_AndroidViewView).setCompoundDrawables(localDrawable2, localDrawable1, localDrawable1, localDrawable1);
      }
    }
    this.jdField_a_of_type_AndroidViewView = localDrawable1;
    this.jdField_a_of_type_Boolean = true;
    this.jdField_a_of_type_Int = -1;
    if (this.jdField_a_of_type_ComTencentMobileqqUtilsRecorder == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqUtilsRecorder.b();
  }

  public void finish()
  {
    super.finish();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    switch (paramInt1)
    {
    default:
    case 200:
    }
    while (true)
    {
      return;
      this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter.getCursor().requery();
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    b();
  }

  protected void onCreate(Bundle paramBundle)
  {
    int k = 2131230730;
    int l = 1;
    int i1 = 1093664768;
    int i2 = 1091567616;
    super.onCreate(paramBundle);
    int i3 = getResources().getDisplayMetrics().density;
    this.jdField_a_of_type_Float = i3;
    setContentView(2130903052);
    Object localObject = getIntent().getExtras();
    String str1 = ((Bundle)localObject).getString("uin");
    this.jdField_d_of_type_JavaLangString = str1;
    localObject = ((Bundle)localObject).getInt("uin type");
    this.jdField_b_of_type_Int = localObject;
    localObject = this.jdField_d_of_type_JavaLangString;
    int i5 = this.jdField_b_of_type_Int;
    localObject = a((String)localObject, i5);
    this.jdField_c_of_type_Int = localObject;
    int i4 = this.jdField_c_of_type_Int;
    i5 = 8;
    if (i4 < i5)
      i4 = l;
    for (ChatHistory localChatHistory = this; ; localChatHistory = this)
    {
      while (true)
      {
        localChatHistory.jdField_d_of_type_Int = i4;
        int i6 = this.jdField_d_of_type_Int;
        this.e = i4;
        int i7 = (this.e - l) * 8;
        this.g = i4;
        b();
        String str2 = this.jdField_d_of_type_JavaLangString;
        int i8 = this.jdField_b_of_type_Int;
        ChatHistory.ChatHistoryAdapter localChatHistoryAdapter1 = new ChatHistory.ChatHistoryAdapter(this, this);
        this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter = i4;
        ListView localListView1 = (ListView)findViewById(2131492937);
        this.jdField_a_of_type_AndroidWidgetListView = i4;
        ListView localListView2 = this.jdField_a_of_type_AndroidWidgetListView;
        ChatHistory.ChatHistoryAdapter localChatHistoryAdapter2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter;
        i4.setAdapter(localChatHistoryAdapter2);
        ChatHistory.ChatHistoryAdapter localChatHistoryAdapter3 = this.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter;
        int i9 = this.g;
        i4.a(localChatHistory, l, i9);
        ImageView localImageView1 = (ImageView)findViewById(2131492941);
        int i10 = getResources().getColor(k);
        ShapeDrawable localShapeDrawable1 = (ShapeDrawable)ShapeUtils.getTriangleDrawable(4, l);
        int i11 = (int)(this.jdField_a_of_type_Float * i1);
        localChatHistory.setIntrinsicHeight(l);
        int i12 = (int)(this.jdField_a_of_type_Float * i2);
        localChatHistory.setIntrinsicWidth(l);
        i4.setImageDrawable(localChatHistory);
        y localy = new y(this);
        i4.setOnClickListener(localChatHistory);
        ImageView localImageView2 = (ImageView)findViewById(2131492948);
        int i13 = getResources().getColor(k);
        ShapeDrawable localShapeDrawable2 = (ShapeDrawable)ShapeUtils.getTriangleDrawable(3, l);
        int i14 = (int)(this.jdField_a_of_type_Float * i1);
        localChatHistory.setIntrinsicHeight(l);
        int i15 = (int)(this.jdField_a_of_type_Float * i2);
        localChatHistory.setIntrinsicWidth(l);
        i4.setImageDrawable(localChatHistory);
        z localz = new z(this);
        i4.setOnClickListener(localChatHistory);
        TextView localTextView1 = (TextView)findViewById(2131492947);
        this.jdField_a_of_type_AndroidWidgetTextView = i4;
        TextView localTextView2 = this.jdField_a_of_type_AndroidWidgetTextView;
        String str3 = String.valueOf(this.jdField_d_of_type_Int);
        i4.setText(localChatHistory);
        EditText localEditText1 = (EditText)findViewById(2131492945);
        this.jdField_a_of_type_AndroidWidgetEditText = i4;
        EditText localEditText2 = this.jdField_a_of_type_AndroidWidgetEditText;
        String str4 = String.valueOf(this.e);
        i4.setText(localChatHistory);
        EditText localEditText3 = this.jdField_a_of_type_AndroidWidgetEditText;
        aa localaa = new aa(this);
        i4.addTextChangedListener(localChatHistory);
        Button localButton1 = (Button)findViewById(2131492950);
        this.jdField_a_of_type_AndroidWidgetButton = i4;
        Button localButton2 = this.jdField_a_of_type_AndroidWidgetButton;
        ab localab = new ab(this);
        i4.setOnClickListener(localChatHistory);
        Button localButton3 = (Button)findViewById(2131492949);
        this.jdField_b_of_type_AndroidWidgetButton = i4;
        Button localButton4 = this.jdField_b_of_type_AndroidWidgetButton;
        ac localac = new ac(this);
        i4.setOnClickListener(localChatHistory);
        ImageButton localImageButton1 = (ImageButton)findViewById(2131492936);
        this.jdField_a_of_type_AndroidWidgetImageButton = i4;
        ImageButton localImageButton2 = this.jdField_a_of_type_AndroidWidgetImageButton;
        ad localad = new ad(this);
        i4.setOnClickListener(localChatHistory);
        View localView = findViewById(2131492938);
        this.jdField_b_of_type_AndroidViewView = i4;
        TextView localTextView3 = (TextView)findViewById(2131492939);
        this.jdField_c_of_type_AndroidWidgetTextView = i4;
        ImageView localImageView3 = (ImageView)findViewById(2131492865);
        this.jdField_a_of_type_AndroidWidgetImageView = i4;
        ImageView localImageView4 = this.jdField_a_of_type_AndroidWidgetImageView;
        CustomDrawable1 localCustomDrawable1 = new CustomDrawable1(this);
        i4.setImageDrawable(localChatHistory);
        return;
        i4 = this.jdField_c_of_type_Int % 8;
        if (i4 != 0)
          break;
        i4 = this.jdField_c_of_type_Int / 8;
        localChatHistory = this;
      }
      i4 = this.jdField_c_of_type_Int / 8;
      ++i4;
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    if (mToast != null)
    {
      mToast.cancel();
      mToast = null;
    }
    if (this.jdField_a_of_type_Boolean)
      return;
    a();
  }

  protected void onPause()
  {
    if (!this.jdField_a_of_type_Boolean)
      a();
    super.onPause();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatHistory
 * JD-Core Version:    0.5.4
 */