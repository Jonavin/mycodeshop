package com.tencent.mobileqq.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.TroopMemberInfo;
import com.tencent.mobileqq.data.TroopSelfInfo;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.widget.CustomDrawable1;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.QLog;
import gd;
import gf;
import gg;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TroopMemberlistActivity extends BaseActivity
  implements AdapterView.OnItemClickListener
{
  private long jdField_a_of_type_Long;
  private Handler jdField_a_of_type_AndroidOsHandler;
  private ListView jdField_a_of_type_AndroidWidgetListView;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private gg jdField_a_of_type_Gg;
  public String a;
  public List a;
  public boolean a;

  public TroopMemberlistActivity()
  {
    ArrayList localArrayList = new ArrayList();
    this.jdField_a_of_type_JavaUtilList = localArrayList;
    this.jdField_a_of_type_Gg = null;
    this.jdField_a_of_type_Long = 11L;
    this.jdField_a_of_type_Boolean = null;
    gd localgd = new gd(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localgd;
    gf localgf = new gf(this);
    this.jdField_a_of_type_AndroidOsHandler = localgf;
  }

  private void b(String paramString)
  {
    Object localObject;
    long l1;
    long l2;
    if (paramString != null)
    {
      int i = paramString.length();
      if (i > 0)
      {
        EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
        localObject = (TroopSelfInfo)localEntityManager.a(TroopSelfInfo.class, paramString);
        localEntityManager.a();
        l1 = 0L;
        if (localObject == null)
          break label81;
        l2 = ((TroopSelfInfo)localObject).troopCode;
      }
    }
    while (true)
    {
      localObject = String.valueOf(l2);
      if ((localObject != null) && (((String)localObject).length() != 0))
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(paramString, (String)localObject);
      return;
      label81: l2 = l1;
    }
  }

  private void c(String paramString)
  {
    long l1 = 11L;
    Object localObject1 = null;
    String[] arrayOfString1 = 0;
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Object localObject3 = TroopMemberInfo.class;
    String[] arrayOfString3 = new String[1];
    arrayOfString3[arrayOfString1] = paramString;
    Object localObject5 = localObject1;
    List localList2 = ((EntityManager)localObject2).a((Class)localObject3, "troopuin=? ", arrayOfString3, (String)localObject1, (String)localObject5);
    if (localList2 != null)
    {
      arrayOfString3 = arrayOfString1;
      label68: localObject3 = localList2.size();
      if (arrayOfString3 < localObject3)
      {
        localObject3 = (TroopMemberInfo)localList2.get(arrayOfString3);
        if (localObject3 != null)
        {
          localObject1 = ((TroopMemberInfo)localObject3).memberuin;
          if (localObject1 != null)
          {
            localObject1 = ((TroopMemberInfo)localObject3).memberuin.trim().length();
            if (localObject1 > 0)
            {
              localObject1 = ((TroopMemberInfo)localObject3).memberuin.trim();
              localObject5 = String.valueOf(arrayOfString1);
              localObject1 = ((String)localObject1).equalsIgnoreCase((String)localObject5);
              if (localObject1 == 0)
              {
                localObject1 = ((TroopMemberInfo)localObject3).memberuin.trim();
                localObject5 = ((TroopMemberInfo)localObject3).troopnick;
                if (localObject5 == null)
                  break label378;
                localObject5 = ((TroopMemberInfo)localObject3).troopnick.trim().length();
                if (localObject5 <= 0)
                  break label378;
              }
            }
          }
        }
        String[] arrayOfString2;
        for (localObject5 = ((TroopMemberInfo)localObject3).troopnick; ; localObject5 = arrayOfString2.friendnick)
        {
          StringBuilder localStringBuilder = new StringBuilder().append("---p.status = ");
          int i = ((TroopMemberInfo)localObject3).status;
          String str1 = i + "---stnick = " + (String)localObject5 + "---stuin" + (String)localObject1;
          QLog.d("gene", str1);
          short s2 = ((TroopMemberInfo)localObject3).faceid;
          short s1 = (short)((TroopMemberInfo)localObject3).status;
          HashMap localHashMap1 = new HashMap();
          Object localObject4 = Short.valueOf(s1);
          localHashMap1.put("status", localObject4);
          Short localShort1 = Short.valueOf(s2);
          localHashMap1.put("face", localShort1);
          localHashMap1.put("nickname", localObject5);
          localHashMap1.put("uin", localObject1);
          localObject4 = this.jdField_a_of_type_JavaUtilList;
          ((List)localObject4).add(localHashMap1);
          arrayOfString2 = arrayOfString3 + 1;
          arrayOfString3 = arrayOfString2;
          label378: break label68:
        }
      }
    }
    ((EntityManager)localObject2).a();
    localObject2 = this.jdField_a_of_type_JavaUtilList.size();
    if (localObject2 == 0)
      return;
    label736: List localList1;
    for (localList2 = arrayOfString1; ; localList2 = localList1)
    {
      localObject2 = this.jdField_a_of_type_JavaUtilList.size();
      if (localList2 >= localObject2)
        return;
      localObject2 = ((Short)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("status")).shortValue();
      if ((localObject2 != 10) && (localObject2 != l1))
      {
        String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        localObject2 = (String)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("uin");
        localObject2 = str2.equals(localObject2);
        if (localObject2 == 0)
          break label736;
        long l2 = this.jdField_a_of_type_Long < l1;
        if (localObject2 != 0)
          break label736;
      }
      short s3 = ((Short)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("face")).shortValue();
      short s4 = ((Short)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("status")).shortValue();
      localObject2 = (String)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("nickname");
      String str3 = (String)((HashMap)this.jdField_a_of_type_JavaUtilList.get(localList2)).get("uin");
      HashMap localHashMap2 = new HashMap();
      Short localShort2 = Short.valueOf(s4);
      localHashMap2.put("status", localShort2);
      Short localShort3 = Short.valueOf(s3);
      localHashMap2.put("face", localShort3);
      localHashMap2.put("nickname", localObject2);
      localHashMap2.put("uin", str3);
      this.jdField_a_of_type_JavaUtilList.add(arrayOfString1, localHashMap2);
      localObject2 = this.jdField_a_of_type_JavaUtilList;
      int j = localList2 + 1;
      ((List)localObject2).remove(j);
      localList1 = localList2 + 1;
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  protected void onCreate(Bundle paramBundle)
  {
    int i = 2131492938;
    int j = 0;
    super.onCreate(paramBundle);
    setContentView(2130903092);
    ListView localListView1 = (ListView)findViewById(2131493134);
    this.jdField_a_of_type_AndroidWidgetListView = localListView1;
    this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this);
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.a(localBaseActionListener);
    String str1 = getIntent().getExtras().getString("groupUin");
    this.jdField_a_of_type_JavaLangString = str1;
    PreferenceManager.getDefaultSharedPreferences(this);
    String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    long l = getSharedPreferences(str2, j).getLong("getProfileStatus", 11L);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    QLog.d("gene", "oncreate getTroopMemberFromdb");
    String str3 = this.jdField_a_of_type_JavaLangString;
    c(str3);
    if (this.jdField_a_of_type_JavaUtilList.size() != 0)
    {
      gg localgg1 = new gg(this);
      this.jdField_a_of_type_Gg = localgg1;
      ListView localListView2 = this.jdField_a_of_type_AndroidWidgetListView;
      gg localgg2 = this.jdField_a_of_type_Gg;
      localListView2.setAdapter(localgg2);
      this.jdField_a_of_type_AndroidWidgetListView.setVisibility(j);
      findViewById(i).setVisibility(8);
      String str4 = this.jdField_a_of_type_JavaLangString;
      b(str4);
    }
    while (true)
    {
      return;
      findViewById(i).setVisibility(j);
      TextView localTextView = (TextView)findViewById(2131492939);
      ImageView localImageView = (ImageView)findViewById(2131492865);
      CustomDrawable1 localCustomDrawable1 = new CustomDrawable1(this);
      localImageView.setImageDrawable(localCustomDrawable1);
      localTextView.setText("姝ｅ湪鎼滅");
      String str5 = this.jdField_a_of_type_JavaLangString;
      b(str5);
    }
  }

  protected void onDestroy()
  {
    int i = 0;
    super.onDestroy();
    if (this.jdField_a_of_type_AndroidOsHandler.hasMessages(i))
      this.jdField_a_of_type_AndroidOsHandler.removeMessages(i);
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.b(localBaseActionListener);
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str1 = ((TextView)paramView.findViewById(2131493073)).getText().toString();
    Intent localIntent = new Intent(this, InfoActivity.class);
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin().equals(str1))
      localIntent.putExtra("infowhose", 2);
    while (true)
    {
      localIntent.putExtra("infouin", str1);
      String str2 = this.jdField_a_of_type_JavaLangString;
      localIntent.putExtra("troopuin", str2);
      startActivity(localIntent);
      return;
      localIntent.putExtra("infowhose", 0);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.TroopMemberlistActivity
 * JD-Core Version:    0.5.4
 */