package com.tencent.mobileqq.activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.FriendInfo;
import com.tencent.mobileqq.data.FriendMore;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.persistence.Entity;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.widget.MyCheckBox;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import ek;
import eo;
import ep;
import eq;
import es;
import et;
import eu;
import ew;

public class InfoActivity extends BaseActivity
  implements View.OnClickListener, AppConstants
{
  public static final String INFO_ADD_FRIEND = "addFriend";
  public static final int INFO_ERROR_COMMENT = 3;
  public static final int INFO_ERROR_SIGNATURE = 4;
  public static final String INFO_FINDUIN = "uin";
  public static final int INFO_FRIEND = 0;
  public static final String INFO_GROUPUIN = "troopuin";
  public static final String INFO_HANDLER = "handler";
  public static final int INFO_SELF = 2;
  public static final int INFO_TROOP = 1;
  public static final String INFO_UIN = "infouin";
  public static final int INFO_UPDATE_STATUS = 5;
  public static final String INFO_WHOSE = "infowhose";
  public static final int REQUEST_FOR_ADD_FRIEND = 1000;
  public static short[] field;
  private static String lastcomment;
  private static String lastsignature;
  private int jdField_a_of_type_Int;
  private long jdField_a_of_type_Long;
  private AlertDialog jdField_a_of_type_AndroidAppAlertDialog = null;
  private Handler jdField_a_of_type_AndroidOsHandler;
  private View jdField_a_of_type_AndroidViewView;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private String jdField_a_of_type_JavaLangString;
  private boolean jdField_a_of_type_Boolean = null;
  private long b;

  static
  {
    6[0] = 20002;
    6[1] = 20031;
    6[2] = 20009;
    6[3] = 20003;
    6[4] = 20004;
    6[5] = 20020;
    field = 6;
  }

  public InfoActivity()
  {
    ek localek = new ek(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localek;
    eo localeo = new eo(this);
    this.jdField_a_of_type_AndroidOsHandler = localeo;
  }

  private void a()
  {
    ImageView localImageView = (ImageView)findViewById(2131492889);
    TextView localTextView1 = (TextView)findViewById(2131492878);
    TextView localTextView2 = (TextView)findViewById(2131492890);
    TextView localTextView3 = (TextView)findViewById(2131493094);
    TextView localTextView4 = (TextView)findViewById(2131493095);
    EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    String str1 = this.jdField_a_of_type_JavaLangString;
    TroopInfo localTroopInfo = (TroopInfo)localEntityManager.a(TroopInfo.class, str1);
    localEntityManager.a();
    localImageView.setImageResource(2130837734);
    String str2 = this.jdField_a_of_type_JavaLangString;
    localTextView2.setText(str2);
    if (localTroopInfo == null)
      return;
    if (localTroopInfo.troopname != null)
    {
      String str3 = localTroopInfo.troopname;
      localTextView1.setText(str3);
    }
    if (localTroopInfo.fingertroopmemo != null)
    {
      String str4 = localTroopInfo.fingertroopmemo;
      localTextView3.setText(str4);
    }
    if (localTroopInfo.troopmemo == null)
      return;
    String str5 = localTroopInfo.troopmemo;
    localTextView4.setText(str5);
  }

  private void a(boolean paramBoolean)
  {
    InfoActivity localInfoActivity1 = this;
    int i = 2131492889;
    Object localObject1 = (ImageView)localInfoActivity1.findViewById(i);
    InfoActivity localInfoActivity2 = this;
    int i5 = 2131492878;
    TextView localTextView1 = (TextView)localInfoActivity2.findViewById(i5);
    InfoActivity localInfoActivity3 = this;
    int i6 = 2131492890;
    TextView localTextView2 = (TextView)localInfoActivity3.findViewById(i6);
    InfoActivity localInfoActivity4 = this;
    int i7 = 2131493084;
    TextView localTextView3 = (TextView)localInfoActivity4.findViewById(i7);
    InfoActivity localInfoActivity5 = this;
    int i8 = 2131493086;
    TextView localTextView4 = (TextView)localInfoActivity5.findViewById(i8);
    InfoActivity localInfoActivity6 = this;
    int i9 = 2131493087;
    TextView localTextView5 = (TextView)localInfoActivity6.findViewById(i9);
    InfoActivity localInfoActivity7 = this;
    int i10 = 2131492891;
    TextView localTextView6 = (TextView)localInfoActivity7.findViewById(i10);
    InfoActivity localInfoActivity8 = this;
    int i11 = 2131492892;
    TextView localTextView7 = (TextView)localInfoActivity8.findViewById(i11);
    InfoActivity localInfoActivity9 = this;
    int i12 = 2131493080;
    TextView localTextView8 = (TextView)localInfoActivity9.findViewById(i12);
    InfoActivity localInfoActivity10 = this;
    int i13 = 2131493081;
    TextView localTextView9 = (TextView)localInfoActivity10.findViewById(i13);
    InfoActivity localInfoActivity11 = this;
    int i14 = 2131493082;
    TextView localTextView10 = (TextView)localInfoActivity11.findViewById(i14);
    InfoActivity localInfoActivity12 = this;
    int i15 = 2131493083;
    TextView localTextView11 = (TextView)localInfoActivity12.findViewById(i15);
    InfoActivity localInfoActivity13 = this;
    int i16 = 2131493088;
    ImageView localImageView1 = (ImageView)localInfoActivity13.findViewById(i16);
    InfoActivity localInfoActivity14 = this;
    int i17 = 2131493089;
    TextView localTextView12 = (TextView)localInfoActivity14.findViewById(i17);
    InfoActivity localInfoActivity15 = this;
    int i18 = 2131492880;
    LinearLayout localLinearLayout1 = (LinearLayout)localInfoActivity15.findViewById(i18);
    EntityManager localEntityManager1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Object localObject5 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager2 = localEntityManager1;
    Friends localFriends1 = Friends.class;
    Object localObject6 = localObject5;
    Friends localFriends2 = (Friends)localEntityManager2.a(localFriends1, localObject6);
    Object localObject7 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager3 = localEntityManager1;
    FriendInfo localFriendInfo = FriendInfo.class;
    Object localObject8 = localObject7;
    localObject5 = (FriendInfo)localEntityManager3.a(localFriendInfo, localObject8);
    String str4 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager4 = localEntityManager1;
    FriendMore localFriendMore = FriendMore.class;
    String str5 = str4;
    localObject7 = (FriendMore)localEntityManager4.a(localFriendMore, str5);
    localEntityManager1.a();
    label446: label721: label747: Object localObject4;
    if ((localFriends2 != null) && (localFriends2.groupid >= 0))
    {
      int i19 = 1;
      this.jdField_a_of_type_Boolean = i19;
      ImageView localImageView2 = localImageView1;
      int i20 = 2130837576;
      localImageView2.setImageResource(i20);
      TextView localTextView13 = localTextView12;
      int i21 = 2131296336;
      localTextView13.setText(i21);
      ep localep1 = new ep;
      ep localep2 = localep1;
      InfoActivity localInfoActivity16 = this;
      localep2.<init>(localInfoActivity16);
      LinearLayout localLinearLayout2 = localLinearLayout1;
      ep localep3 = localep1;
      localLinearLayout2.setOnClickListener(localep3);
      String str6 = this.jdField_a_of_type_JavaLangString;
      TextView localTextView14 = localTextView2;
      String str7 = str6;
      localTextView14.setText(str7);
      if (localFriends2 != null)
      {
        QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        int i22 = localFriends2.faceid;
        String str8 = this.jdField_a_of_type_JavaLangString;
        QQApplication localQQApplication2 = localQQApplication1;
        int i23 = i22;
        String str9 = str8;
        boolean bool1 = null;
        boolean bool2 = paramBoolean;
        Drawable localDrawable = localQQApplication2.a(i23, str9, bool1, bool2);
        ((ImageView)localObject1).setImageDrawable(localDrawable);
      }
      if (localObject7 != null)
      {
        localObject1 = ((FriendMore)localObject7).signature;
        if (localObject1 != null)
        {
          localObject1 = ((FriendMore)localObject7).signature;
          localTextView3.setText((CharSequence)localObject1);
        }
      }
      int j = 2131493085;
      InfoActivity localInfoActivity17 = this;
      int i24 = j;
      paramBoolean = (LinearLayout)localInfoActivity17.findViewById(i24);
      if (localFriends2 == null)
        break label1141;
      j = localFriends2.groupid;
      if (j < 0)
        break label1141;
      j = 0;
      boolean bool3 = paramBoolean;
      int i25 = j;
      bool3.setVisibility(i25);
      if (localObject5 != null)
      {
        localObject2 = ((FriendInfo)localObject5).comment;
        if (localObject2 == null)
          break label1111;
        localObject2 = ((FriendInfo)localObject5).comment;
        localTextView4.setText((CharSequence)localObject2);
      }
      label683: InfoActivity localInfoActivity18 = this;
      int i26 = 2131492901;
      Object localObject2 = ((EditText)localInfoActivity18.findViewById(i26)).getVisibility();
      if (localObject2 != 0)
        break label1126;
      int k = 2131296380;
      localTextView5.setText(k);
      Object localObject3 = new eq;
      Object localObject9 = localObject3;
      InfoActivity localInfoActivity19 = this;
      localObject9.<init>(localInfoActivity19);
      localTextView5.setOnClickListener((AppConstants)localObject3);
      if (localObject5 == null)
      {
        localObject3 = "-";
        localTextView1.setText((CharSequence)localObject3);
      }
      if (localObject5 != null)
      {
        localObject3 = ((FriendInfo)localObject5).nickname;
        if (localObject3 == null)
          break label1162;
        localObject3 = ((FriendInfo)localObject5).nickname;
        localTextView1.setText((CharSequence)localObject3);
        label794: int l = ((FriendInfo)localObject5).gender;
        if (l != 1)
          break label1176;
        localObject4 = "�";
        localTextView6.setText((CharSequence)localObject4);
      }
    }
    while (true)
    {
      localObject4 = new Time("GMT+8");
      ((Time)localObject4).setToNow();
      if ((((FriendInfo)localObject5).year > 0) && (((FriendInfo)localObject5).month > 0) && (((FriendInfo)localObject5).day > 0))
      {
        int i1 = ((Time)localObject4).year;
        int i27 = ((FriendInfo)localObject5).year;
        i1 -= i27;
        int i2;
        if (i1 < 0)
          i2 = null;
        String str10 = String.valueOf(i2);
        localTextView7.setText(i2);
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str11 = String.valueOf(((FriendInfo)localObject5).year);
        StringBuilder localStringBuilder2 = i2.append(str11).append("�");
        String str12 = String.valueOf(((FriendInfo)localObject5).month);
        StringBuilder localStringBuilder3 = i2.append(str12).append("�");
        String str13 = String.valueOf(((FriendInfo)localObject5).day);
        String str14 = str13 + "�";
        localTextView8.setText(i2);
      }
      if (((FriendInfo)localObject5).city != null)
      {
        String str15 = ((FriendInfo)localObject5).city;
        localTextView9.setText(str15);
      }
      if (((FriendInfo)localObject5).province != null)
      {
        String str16 = ((FriendInfo)localObject5).province;
        localTextView10.setText(str16);
      }
      if (((FriendInfo)localObject5).country != null)
      {
        String str17 = ((FriendInfo)localObject5).country;
        TextView localTextView15 = localTextView11;
        String str18 = str17;
        localTextView15.setText(str18);
      }
      return;
      Object localObject10 = null;
      this.jdField_a_of_type_Boolean = localObject10;
      ImageView localImageView3 = localImageView1;
      int i28 = 2130837514;
      localImageView3.setImageResource(i28);
      TextView localTextView16 = localTextView12;
      int i29 = 2131296335;
      localTextView16.setText(i29);
      break label446:
      label1111: String str1 = "";
      localTextView4.setText(str1);
      break label683:
      label1126: int i3 = 2131296334;
      localTextView5.setText(i3);
      break label721:
      label1141: i3 = 8;
      boolean bool4 = paramBoolean;
      int i30 = i3;
      bool4.setVisibility(i30);
      break label747:
      label1162: String str2 = "-";
      localTextView1.setText(str2);
      break label794:
      label1176: int i4 = ((FriendInfo)localObject5).gender;
      if (i4 != 2)
        continue;
      String str3 = "�";
      localTextView6.setText(str3);
    }
  }

  private void b(boolean paramBoolean)
  {
    InfoActivity localInfoActivity1 = this;
    int i = 2131492889;
    Object localObject1 = (ImageView)localInfoActivity1.findViewById(i);
    InfoActivity localInfoActivity2 = this;
    int i3 = 2131492878;
    TextView localTextView1 = (TextView)localInfoActivity2.findViewById(i3);
    InfoActivity localInfoActivity3 = this;
    int i4 = 2131492890;
    TextView localTextView2 = (TextView)localInfoActivity3.findViewById(i4);
    InfoActivity localInfoActivity4 = this;
    int i5 = 2131493084;
    TextView localTextView3 = (TextView)localInfoActivity4.findViewById(i5);
    InfoActivity localInfoActivity5 = this;
    int i6 = 2131493091;
    TextView localTextView4 = (TextView)localInfoActivity5.findViewById(i6);
    InfoActivity localInfoActivity6 = this;
    int i7 = 2131493092;
    TextView localTextView5 = (TextView)localInfoActivity6.findViewById(i7);
    InfoActivity localInfoActivity7 = this;
    int i8 = 2131493093;
    TextView localTextView6 = (TextView)localInfoActivity7.findViewById(i8);
    InfoActivity localInfoActivity8 = this;
    int i9 = 2131492891;
    TextView localTextView7 = (TextView)localInfoActivity8.findViewById(i9);
    InfoActivity localInfoActivity9 = this;
    int i10 = 2131492892;
    TextView localTextView8 = (TextView)localInfoActivity9.findViewById(i10);
    InfoActivity localInfoActivity10 = this;
    int i11 = 2131493080;
    TextView localTextView9 = (TextView)localInfoActivity10.findViewById(i11);
    InfoActivity localInfoActivity11 = this;
    int i12 = 2131493081;
    TextView localTextView10 = (TextView)localInfoActivity11.findViewById(i12);
    InfoActivity localInfoActivity12 = this;
    int i13 = 2131493082;
    TextView localTextView11 = (TextView)localInfoActivity12.findViewById(i13);
    InfoActivity localInfoActivity13 = this;
    int i14 = 2131493083;
    TextView localTextView12 = (TextView)localInfoActivity13.findViewById(i14);
    EntityManager localEntityManager1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Object localObject4 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager2 = localEntityManager1;
    Friends localFriends1 = Friends.class;
    Object localObject5 = localObject4;
    Friends localFriends2 = (Friends)localEntityManager2.a(localFriends1, localObject5);
    Object localObject6 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager3 = localEntityManager1;
    FriendInfo localFriendInfo = FriendInfo.class;
    Object localObject7 = localObject6;
    localObject4 = (FriendInfo)localEntityManager3.a(localFriendInfo, localObject7);
    String str3 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager4 = localEntityManager1;
    FriendMore localFriendMore = FriendMore.class;
    String str4 = str3;
    localObject6 = (FriendMore)localEntityManager4.a(localFriendMore, str4);
    localEntityManager1.a();
    String str5 = this.jdField_a_of_type_JavaLangString;
    TextView localTextView13 = localTextView2;
    String str6 = str5;
    localTextView13.setText(str6);
    if (localFriends2 != null)
    {
      QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      int i15 = localFriends2.faceid;
      String str7 = this.jdField_a_of_type_JavaLangString;
      QQApplication localQQApplication2 = localQQApplication1;
      Friends localFriends3 = localFriends2;
      String str8 = str7;
      boolean bool1 = null;
      boolean bool2 = paramBoolean;
      Drawable localDrawable = localQQApplication2.a(localFriends3, str8, bool1, bool2);
      ((ImageView)localObject1).setImageDrawable(localDrawable);
    }
    if (localObject6 != null)
    {
      localObject1 = ((FriendMore)localObject6).signature;
      if (localObject1 != null)
      {
        localObject1 = ((FriendMore)localObject6).signature;
        localTextView3.setText((CharSequence)localObject1);
      }
    }
    InfoActivity localInfoActivity14 = this;
    int i16 = 2131492901;
    localObject1 = ((EditText)localInfoActivity14.findViewById(i16)).getVisibility();
    label513: label615: Object localObject3;
    if (localObject1 == 0)
    {
      int j = 2131296380;
      localTextView4.setText(j);
      Object localObject2 = new eu;
      Object localObject8 = localObject2;
      InfoActivity localInfoActivity15 = this;
      localObject8.<init>(localInfoActivity15);
      localTextView4.setOnClickListener((AppConstants)localObject2);
      localObject2 = this.jdField_a_of_type_JavaLangString;
      InfoActivity localInfoActivity16 = this;
      Object localObject9 = localObject2;
      int i17 = 0;
      long l1 = localInfoActivity16.getSharedPreferences(localObject9, i17).getLong("getProfileStatus", 11L);
      this.jdField_a_of_type_Long = l1;
      long l2 = this.jdField_a_of_type_Long < 11L;
      if (localObject2 != 0)
        break label992;
      InfoActivity localInfoActivity17 = this;
      int i18 = 2131296328;
      localObject2 = localInfoActivity17.getString(i18);
      localTextView5.setText((CharSequence)localObject2);
      localObject2 = new ew;
      Object localObject10 = localObject2;
      InfoActivity localInfoActivity18 = this;
      localObject10.<init>(localInfoActivity18);
      localTextView6.setOnClickListener((AppConstants)localObject2);
      if (localObject4 == null)
      {
        localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getNickName();
        if (localObject2 != null)
          break label1012;
        localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        localTextView1.setText((CharSequence)localObject2);
      }
      if (localObject4 != null)
      {
        label689: localObject2 = ((FriendInfo)localObject4).nickname;
        if (localObject2 == null)
          break label1034;
        localObject2 = ((FriendInfo)localObject4).nickname;
        localTextView1.setText((CharSequence)localObject2);
        label720: int k = ((FriendInfo)localObject4).gender;
        if (k != 1)
          break label1056;
        localObject3 = "�";
        localTextView7.setText((CharSequence)localObject3);
      }
    }
    while (true)
    {
      localObject3 = new Time("GMT+8");
      ((Time)localObject3).setToNow();
      int l = ((Time)localObject3).year;
      int i19 = ((FriendInfo)localObject4).year;
      l -= i19;
      if (l < 0)
        i1 = null;
      String str9 = String.valueOf(i1);
      localTextView8.setText(i1);
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str10 = String.valueOf(((FriendInfo)localObject4).year);
      StringBuilder localStringBuilder2 = i1.append(str10).append("�");
      String str11 = String.valueOf(((FriendInfo)localObject4).month);
      StringBuilder localStringBuilder3 = i1.append(str11).append("�");
      String str12 = String.valueOf(((FriendInfo)localObject4).day);
      String str13 = str12 + "�";
      localTextView9.setText(i1);
      if (((FriendInfo)localObject4).city != null)
      {
        String str14 = ((FriendInfo)localObject4).city;
        localTextView10.setText(str14);
      }
      if (((FriendInfo)localObject4).province != null)
      {
        String str15 = ((FriendInfo)localObject4).province;
        TextView localTextView14 = localTextView11;
        String str16 = str15;
        localTextView14.setText(str16);
      }
      if (((FriendInfo)localObject4).country != null)
      {
        String str17 = ((FriendInfo)localObject4).country;
        TextView localTextView15 = localTextView12;
        String str18 = str17;
        localTextView15.setText(str18);
      }
      return;
      int i1 = 2131296334;
      localTextView4.setText(i1);
      break label513:
      label992: InfoActivity localInfoActivity19 = this;
      int i20 = 2131296330;
      String str1 = localInfoActivity19.getString(i20);
      break label615:
      label1012: str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getNickName();
      localTextView1.setText(str1);
      break label689:
      label1034: str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      localTextView1.setText(str1);
      break label720:
      label1056: int i2 = ((FriendInfo)localObject4).gender;
      if (i2 != 2)
        continue;
      String str2 = "�";
      localTextView7.setText(str2);
    }
  }

  public final void a(String paramString1, String paramString2)
  {
    Object localObject1 = QQApplication.createEntityManagerFactory(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin());
    EntityManager localEntityManager;
    Object localObject2;
    if (localObject1 != null)
    {
      localEntityManager = ((EntityManagerFactory)localObject1).createEntityManager();
      localObject1 = (Friends)localEntityManager.a(Friends.class, paramString1);
      if (localObject1 != null)
      {
        if (paramString2 == null)
          break label157;
        boolean bool = paramString2.trim().equals("");
        if (bool)
          break label157;
        ((Friends)localObject1).name = paramString2;
        localObject2 = paramString2;
        label69: CacheUtils localCacheUtils = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a;
        String str = ((Friends)localObject1).uin;
        localCacheUtils.a(str, (Friends)localObject1);
        localEntityManager.a((Entity)localObject1);
        localObject1 = (FriendInfo)localEntityManager.a(FriendInfo.class, paramString1);
        if (localObject1 == null)
          break label196;
        ((FriendInfo)localObject1).comment = ((String)localObject2);
        localEntityManager.a((Entity)localObject1);
      }
    }
    while (true)
    {
      localEntityManager.a();
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(ContactActivity.class);
      if (localObject1 != null)
        ((Handler)localObject1).sendEmptyMessage(1005);
      return;
      label157: localObject2 = (FriendInfo)localEntityManager.a(FriendInfo.class, paramString1);
      if (localObject2 != null)
      {
        localObject2 = ((FriendInfo)localObject2).nickname;
        ((Friends)localObject1).name = ((String)localObject2);
      }
      localObject2 = "";
      break label69:
      label196: localObject1 = new FriendInfo();
      ((FriendInfo)localObject1).frienduin = paramString1;
      ((FriendInfo)localObject1).comment = ((String)localObject2);
      localEntityManager.a((Entity)localObject1, null);
    }
  }

  public final void b(String paramString)
  {
    Object localObject1 = QQApplication.createEntityManagerFactory(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin());
    if (localObject1 == null)
      return;
    localObject1 = ((EntityManagerFactory)localObject1).createEntityManager();
    Object localObject2 = new FriendMore();
    ((FriendMore)localObject2).signature = paramString;
    String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    ((FriendMore)localObject2).uin = str1;
    ((EntityManager)localObject1).a((Entity)localObject2, true);
    CacheUtils localCacheUtils = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a;
    String str2 = ((FriendMore)localObject2).uin;
    localCacheUtils.a(str2, (FriendMore)localObject2);
    localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(ContactActivity.class);
    if (localObject2 != null)
      ((Handler)localObject2).sendEmptyMessage(10000);
    ((EntityManager)localObject1).a();
  }

  public void onClick(View paramView)
  {
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  protected void onCreate(Bundle paramBundle)
  {
    long l1 = 1L;
    int i = 2;
    Object localObject1 = null;
    Object localObject2 = 0;
    Object localObject3 = 1;
    super.onCreate(paramBundle);
    lastcomment = localObject1;
    lastsignature = localObject1;
    int j = getIntent().getIntExtra("infowhose", i);
    this.jdField_a_of_type_Int = j;
    Object localObject4 = getIntent().getStringExtra("infouin");
    this.jdField_a_of_type_JavaLangString = ((String)localObject4);
    localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Object localObject5 = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    ((QQApplication)localObject4).a((BaseActionListener)localObject5);
    localObject4 = this.jdField_a_of_type_JavaLangString;
    int k;
    if (localObject4 != null)
    {
      localObject4 = this.jdField_a_of_type_JavaLangString.length();
      if (localObject4 > 0)
      {
        k = this.jdField_a_of_type_Int;
        if (k != 0)
          break label306;
        setContentView(2130903074);
        a(localObject3);
        BaseServiceHelper localBaseServiceHelper1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        String[] arrayOfString = new String[localObject3];
        String str2 = this.jdField_a_of_type_JavaLangString;
        arrayOfString[localObject2] = str2;
        ProfileUtil.getFullInfo(localBaseServiceHelper1, str1, arrayOfString, localObject3);
        BaseServiceHelper localBaseServiceHelper2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        String str4 = this.jdField_a_of_type_JavaLangString;
        short[] arrayOfShort1 = field;
        ProfileUtil.getFriendInfoReq(localBaseServiceHelper2, str3, localObject3, str4, arrayOfShort1);
      }
    }
    while (true)
    {
      label232: View localView = findViewById(2131492938);
      this.jdField_a_of_type_AndroidViewView = localView;
      TextView localTextView = (TextView)findViewById(2131492939);
      this.jdField_a_of_type_AndroidWidgetTextView = localTextView;
      QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      Class localClass = super.getClass();
      Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
      localQQApplication.a(localClass, localHandler);
      this.jdField_a_of_type_AndroidOsHandler.obtainMessage(5, localObject1).sendToTarget();
      return;
      label306: k = this.jdField_a_of_type_Int;
      if (k == localObject3)
      {
        setContentView(2130903076);
        a();
        MyCheckBox localMyCheckBox = (MyCheckBox)findViewById(2131493097);
        localObject5 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        SharedPreferences localSharedPreferences = getSharedPreferences((String)localObject5, localObject2);
        localObject5 = new StringBuilder().append((String)localObject5);
        String str5 = this.jdField_a_of_type_JavaLangString;
        localObject5 = str5;
        long l2 = localSharedPreferences.getLong((String)localObject5, l1) < l1;
        if (localObject5 == 0);
        for (localObject5 = localObject3; ; localObject5 = localObject2)
        {
          localMyCheckBox.setChecked(localObject5);
          es locales = new es(this);
          localMyCheckBox.setOnClickListener((AppConstants)localObject5);
          LinearLayout localLinearLayout = (LinearLayout)findViewById(2131492880);
          et localet = new et(this);
          localMyCheckBox.setOnClickListener((AppConstants)localObject5);
          BaseServiceHelper localBaseServiceHelper3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
          String str6 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
          String str7 = this.jdField_a_of_type_JavaLangString;
          ProfileUtil.getGroupInfoReq(localMyCheckBox, (String)localObject5, localObject3, str7);
          break label232:
        }
      }
      if (this.jdField_a_of_type_Int != i)
        continue;
      setContentView(2130903075);
      b(localObject3);
      BaseServiceHelper localBaseServiceHelper4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      String str9 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      short[] arrayOfShort2 = field;
      ProfileUtil.getFriendInfoReq(localBaseServiceHelper4, str8, localObject3, str9, arrayOfShort2);
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication1.b(localBaseActionListener);
    QQApplication localQQApplication2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass = super.getClass();
    localQQApplication2.a(localClass);
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.InfoActivity
 * JD-Core Version:    0.5.4
 */