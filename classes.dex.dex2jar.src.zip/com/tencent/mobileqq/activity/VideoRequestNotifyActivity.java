package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.video.VideoController;
import gl;
import gm;
import gn;
import java.util.Timer;
import java.util.TimerTask;

public class VideoRequestNotifyActivity extends Activity
  implements View.OnClickListener
{
  Dialog jdField_a_of_type_AndroidAppDialog;
  WifiManager.WifiLock jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock = null;
  public QQApplication a;
  VideoController jdField_a_of_type_ComTencentMobileqqVideoVideoController;
  String jdField_a_of_type_JavaLangString;

  private static boolean checkAbility()
  {
    return true;
  }

  public final void a()
  {
    if ((this.jdField_a_of_type_AndroidAppDialog != null) && (!this.jdField_a_of_type_AndroidAppDialog.isShowing()))
      this.jdField_a_of_type_AndroidAppDialog.show();
    while (true)
    {
      return;
      if (this.jdField_a_of_type_AndroidAppDialog == null)
        continue;
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog.show();
    }
  }

  public void onClick(View paramView)
  {
    int i = 2131296271;
    Object localObject1 = 1;
    DialogInterface.OnClickListener localOnClickListener = null;
    int k = paramView.getId();
    switch (k)
    {
    default:
    case 2131493155:
    case 2131493156:
    case 2131493157:
    }
    while (true)
    {
      label44: return;
      boolean bool = ChatVideoActivity.checkVersion();
      if (!bool)
      {
        AlertDialog.Builder localBuilder = new AlertDialog.Builder(this).setTitle(2131296455);
        String str1 = getString(2131296456);
        localBuilder.setMessage(str1).setNegativeButton(i, localOnClickListener).create().show();
      }
      bool = ChatVideoActivity.checkVersion();
      Object localObject3;
      label155: Object localObject2;
      Object localObject4;
      if (!bool)
      {
        localObject3 = new AlertDialog.Builder(this).setTitle(2131296443);
        String str2 = getString(2131296444);
        ((AlertDialog.Builder)localObject3).setMessage(str2).setNegativeButton(i, localOnClickListener).create().show();
        localObject3 = null;
        if (localObject3 != null)
        {
          localObject3 = ((ConnectivityManager)getSystemService("connectivity")).getActiveNetworkInfo();
          if (localObject3 != null)
          {
            localObject3 = ((NetworkInfo)localObject3).getType();
            if (localObject3 == localObject1)
            {
              localObject3 = (WifiManager)getSystemService("wifi");
              if (localObject3 != null)
              {
                localObject3 = ((WifiManager)localObject3).createWifiLock(localObject1, "video wifi lock");
                this.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock = ((WifiManager.WifiLock)localObject3);
                localObject3 = this.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock;
                ((WifiManager.WifiLock)localObject3).acquire();
              }
            }
          }
          localObject3 = Long.parseLong(this.jdField_a_of_type_JavaLangString);
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
          if (localObject2 == null)
            break label315;
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b(localObject4);
          label263: if (localObject2 == 0)
            break label321;
          String str3 = getString(2131296454);
          VideoController.addVideoMsg(localObject4, str3);
        }
      }
      while (true)
      {
        this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b();
        this.jdField_a_of_type_AndroidAppDialog.dismiss();
        this.jdField_a_of_type_AndroidAppDialog = localOnClickListener;
        finish();
        break label44:
        localObject3 = localObject2;
        break label155:
        label315: int j = -1;
        break label263:
        label321: Intent localIntent = new Intent(this, ChatVideoActivity.class);
        localIntent.putExtra("UID", localObject4);
        startActivityForResult(localIntent, 20);
      }
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b();
      VideoController localVideoController = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
      long l = Long.parseLong(this.jdField_a_of_type_JavaLangString);
      Object localObject5;
      localVideoController.a(localObject5);
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog = localOnClickListener;
      finish();
      continue;
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.b();
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog = localOnClickListener;
      finish();
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    boolean bool = null;
    super.onCreate(paramBundle);
    Object localObject1 = getIntent().getExtras();
    Object localObject2 = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = ((QQApplication)localObject2);
    localObject2 = String.valueOf(((Bundle)localObject1).getLong("senderUin"));
    this.jdField_a_of_type_JavaLangString = ((String)localObject2);
    localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = ((VideoController)localObject2);
    String str = this.jdField_a_of_type_JavaLangString;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Friends localFriends = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a.a(str);
    localObject2 = (RelativeLayout)((LayoutInflater)getSystemService("layout_inflater")).inflate(2130903096, null);
    localObject1 = (ImageView)((RelativeLayout)localObject2).findViewById(2131493152);
    TextView localTextView1 = (TextView)((RelativeLayout)localObject2).findViewById(2131493154);
    TextView localTextView2 = (TextView)((RelativeLayout)localObject2).findViewById(2131493153);
    ((Button)((RelativeLayout)localObject2).findViewById(2131493155)).setOnClickListener(this);
    ((Button)((RelativeLayout)localObject2).findViewById(2131493156)).setOnClickListener(this);
    ((Button)((RelativeLayout)localObject2).findViewById(2131493157)).setOnClickListener(this);
    if (localFriends == null)
    {
      Drawable localDrawable1 = getResources().getDrawable(2130837749);
      ((ImageView)localObject1).setImageDrawable(localDrawable1);
    }
    for (localObject1 = str; ; localObject1 = str)
      do
      {
        localTextView2.setText((CharSequence)localObject1);
        localTextView1.setText("璇锋眰涓庢");
        Dialog localDialog1 = new Dialog(this);
        this.jdField_a_of_type_AndroidAppDialog = ((Dialog)localObject1);
        this.jdField_a_of_type_AndroidAppDialog.requestWindowFeature(1);
        this.jdField_a_of_type_AndroidAppDialog.setContentView((View)localObject2);
        Dialog localDialog2 = this.jdField_a_of_type_AndroidAppDialog;
        gn localgn = new gn(this);
        ((Dialog)localObject2).setOnKeyListener((DialogInterface.OnKeyListener)localObject1);
        Timer localTimer = new Timer();
        gl localgl = new gl(this);
        gm localgm = new gm(this);
        new Handler().postDelayed(localTextView1, 200L);
        ((Timer)localObject2).schedule((TimerTask)localObject1, 30000L);
        this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(this);
        return;
        QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        int i = localFriends.faceid;
        Drawable localDrawable2 = localQQApplication.a(i, str, bool, bool);
        ((ImageView)localObject1).setImageDrawable(localDrawable2);
        localObject1 = localFriends.name;
      }
      while (((String)localObject1).trim().length() != 0);
  }

  protected void onDestroy()
  {
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(null);
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    if (this.jdField_a_of_type_AndroidAppDialog == null)
      return;
    this.jdField_a_of_type_AndroidAppDialog.dismiss();
  }

  protected void onResume()
  {
    super.onResume();
    a();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.VideoRequestNotifyActivity
 * JD-Core Version:    0.5.4
 */