package com.tencent.mobileqq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.widget.Workspace;
import gh;

public class UserguideActivity extends Activity
{
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  protected QQApplication a;
  private Workspace jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;

  private void a(int paramInt)
  {
    int i = 0;
    int j = this.jdField_a_of_type_AndroidWidgetLinearLayout.getChildCount();
    for (int k = i; k < j; ++k)
      this.jdField_a_of_type_AndroidWidgetLinearLayout.getChildAt(k).setEnabled(true);
    View localView = this.jdField_a_of_type_AndroidWidgetLinearLayout.getChildAt(paramInt);
    if (localView == null)
      return;
    localView.setEnabled(i);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903093);
    Workspace localWorkspace1 = (Workspace)findViewById(2131492908);
    this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace = localWorkspace1;
    this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace.setAlloweffect(null);
    LinearLayout localLinearLayout = (LinearLayout)findViewById(2131493141);
    this.jdField_a_of_type_AndroidWidgetLinearLayout = localLinearLayout;
    a(0);
    QQApplication localQQApplication = (QQApplication)getApplication();
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication = localQQApplication;
    Workspace localWorkspace2 = this.jdField_a_of_type_ComTencentMobileqqWidgetWorkspace;
    gh localgh = new gh(this);
    localWorkspace2.setOnScreenChangeListener(localgh);
  }

  protected void onUserLeaveHint()
  {
    super.onUserLeaveHint();
    if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a() == null)
      return;
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(this);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.UserguideActivity
 * JD-Core Version:    0.5.4
 */