package com.tencent.mobileqq.activity;

import I;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.SensorManager;
import android.net.Uri;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.StatFs;
import android.text.ClipboardManager;
import android.text.SpannableString;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import aw;
import ax;
import ay;
import az;
import ba;
import bb;
import bc;
import bd;
import be;
import bg;
import bk;
import bl;
import bm;
import bp;
import bq;
import br;
import bs;
import bt;
import bu;
import bv;
import bw;
import bx;
import by;
import cb;
import cc;
import ce;
import com.tencent.mobileqq.adapter.ChatMessageListAdapter;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.AppSetting;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.app.QQServiceEntry.Tag;
import com.tencent.mobileqq.app.ScreenShotSensorEventListener;
import com.tencent.mobileqq.data.CustomEmotionData;
import com.tencent.mobileqq.data.FriendInfo;
import com.tencent.mobileqq.data.FriendMore;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.data.SigInfo;
import com.tencent.mobileqq.data.TroopInfo;
import com.tencent.mobileqq.data.UnreadMsgFriendInfo;
import com.tencent.mobileqq.data.VideoAbility;
import com.tencent.mobileqq.grouptransfile.GroupPicProcessor;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.message.EmoWindow;
import com.tencent.mobileqq.service.message.MessageUtil;
import com.tencent.mobileqq.service.message.remote.MessageRecordInfo;
import com.tencent.mobileqq.service.message.storage.StorageMessage;
import com.tencent.mobileqq.service.message.storage.StorageMessageManager;
import com.tencent.mobileqq.service.storageutil.StorageManager;
import com.tencent.mobileqq.service.storageutil.Storageable;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.mobileqq.transfile.TransFileController;
import com.tencent.mobileqq.transfile.TransFileProcessor;
import com.tencent.mobileqq.transfile.TransfileUtile;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.mobileqq.utils.Recorder;
import com.tencent.mobileqq.utils.httputils.PkgTools;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseApplication;
import com.tencent.qphone.base.util.BaseServiceHelper;
import com.tencent.qphone.base.util.LoginHelper;
import com.tencent.qphone.base.util.QLog;
import java.io.File;
import java.util.List;

public class ChatWindowActivity extends BaseActivity
  implements AppConstants
{
  public static final boolean ACCEPT_VIDEO_ROOM = false;
  public static final int ADD_CUSTOMEMOTION_FFROM_DOWNlOAD = 12;
  public static final int ADD_CUSTOMEMOTION_PREVIEW = 11;
  public static final int ADD_CUSTOMEMOTION_REQUEST = 10;
  private static final int AUDIO_MODE = 1;
  private static final int BOTTOM_PANNEL_CLOSE = 6;
  private static final int BOTTOM_PANNEL_OPEN = 5;
  private static final int CUSTOM_EMOTIONS_COLUM_NUM = 4;
  private static final int CUSTOM_EMOTIONS_COLUM_NUM_LAND = 6;
  public static final int DOODLE_REQUEST = 102;
  public static final int DOWNLOADING = 5;
  public static final int DOWNLOAD_FINISHED = 6;
  private static final int EMOTIONS_COLUM_NUM = 7;
  private static final int EMOTIONS_COLUM_NUM_LAND = 11;
  public static final int ENTER_HISTORY_REQUEST = 0;
  public static final int INFO_FRIEND_CODE = 100;
  private static final int LIST_VIEW_SELECT_BOTTOM = 7;
  static final int MAX_MEM_MESSAGE_TABLE_SAVE_NUMBER = 1000;
  static final int MOVE_MEM_MESSAGE_TO_SDCARD_NUMBER = 100;
  static final int MaxAmplitude = 1200;
  static final int MidAmplitude = 500;
  static final int MinAmplitude = 4;
  public static final boolean OPEN_VIDEO_ROOM = true;
  private static final int PTT_SHOWWINDOW = 1;
  private static final int PTT_TIMEOUT = 0;
  public static final int RECEIVED_MESSAGE_HANDLER = 1;
  public static final int REUPLOAD = 9;
  private static final int SENDED_MESSAGE_HANDLER = 0;
  private static final int SERVICE_JUNM_BACK_HANDLER = 3;
  private static final int TEXT_MODE = 0;
  private static final int UPDATE_HEAD_HANDLER = 4;
  public static final int UPLOADING = 7;
  public static final int UPLOAD_FINISHED = 8;
  public static final int UPLOAD_LOCALPHOTO_REQUEST = 2;
  public static final int UPLOAD_PREVIEWPHOTO_REQUEST = 4;
  public static final int UPLOAD_SHOTPHOTO_REQUEST = 1;
  public static final int VIDEO_REQUEST = 20;
  public static final int VIEW = 101;
  private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
  public float a;
  public int a;
  private Dialog jdField_a_of_type_AndroidAppDialog;
  private Uri jdField_a_of_type_AndroidNetUri;
  public WifiManager.WifiLock a;
  public Handler a;
  private View jdField_a_of_type_AndroidViewView;
  public WindowManager a;
  private Animation jdField_a_of_type_AndroidViewAnimationAnimation;
  private AnimationSet jdField_a_of_type_AndroidViewAnimationAnimationSet;
  private Button jdField_a_of_type_AndroidWidgetButton;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private GridView jdField_a_of_type_AndroidWidgetGridView;
  public ImageView a;
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  private RelativeLayout jdField_a_of_type_AndroidWidgetRelativeLayout;
  TabHost jdField_a_of_type_AndroidWidgetTabHost;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  private cb jdField_a_of_type_Cb;
  private ce jdField_a_of_type_Ce;
  public ChatWindowActivity.MessageListView a;
  public ChatWindowActivity.UpdataPlayPttStateListener a;
  private ChatMessageListAdapter jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
  private QQServiceEntry.Tag jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
  private TroopInfo jdField_a_of_type_ComTencentMobileqqDataTroopInfo;
  private UnreadMsgFriendInfo jdField_a_of_type_ComTencentMobileqqDataUnreadMsgFriendInfo;
  public VideoController a;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private Object jdField_a_of_type_JavaLangObject;
  public String a;
  public boolean a;
  public int b;
  private Handler jdField_b_of_type_AndroidOsHandler;
  private View jdField_b_of_type_AndroidViewView;
  private Animation jdField_b_of_type_AndroidViewAnimationAnimation;
  public ImageView b;
  private LinearLayout jdField_b_of_type_AndroidWidgetLinearLayout;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  String jdField_b_of_type_JavaLangString;
  public boolean b;
  public int c;
  private Handler jdField_c_of_type_AndroidOsHandler;
  private ImageView jdField_c_of_type_AndroidWidgetImageView;
  private LinearLayout jdField_c_of_type_AndroidWidgetLinearLayout;
  private TextView jdField_c_of_type_AndroidWidgetTextView;
  public String c;
  public boolean c;
  public int d;
  private Handler jdField_d_of_type_AndroidOsHandler;
  private ImageView jdField_d_of_type_AndroidWidgetImageView;
  private TextView jdField_d_of_type_AndroidWidgetTextView;
  private final String jdField_d_of_type_JavaLangString = "ChatWindowActivity";
  public int e;
  private ImageView jdField_e_of_type_AndroidWidgetImageView;
  private String jdField_e_of_type_JavaLangString;
  public int f;
  private ImageView jdField_f_of_type_AndroidWidgetImageView;
  private String jdField_f_of_type_JavaLangString;
  public int g;
  private ImageView jdField_g_of_type_AndroidWidgetImageView;
  private String jdField_g_of_type_JavaLangString;
  private int jdField_h_of_type_Int;
  private ImageView jdField_h_of_type_AndroidWidgetImageView;
  private String jdField_h_of_type_JavaLangString;
  private int i;
  private int j = null;
  private int k;
  private int l;
  private int m;
  private int n;
  private int o;
  private int p;
  private int q;
  private int r;
  private int s;
  private int t;
  private int u;
  private int v;
  private final int w;
  private final int x;
  private int y;

  public ChatWindowActivity()
  {
    this.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock = null;
    ba localba = new ba(this);
    this.jdField_b_of_type_AndroidOsHandler = localba;
    this.jdField_b_of_type_JavaLangString = "";
    bk localbk = new bk(this);
    this.jdField_c_of_type_AndroidOsHandler = localbk;
    bm localbm = new bm(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localbm;
    bq localbq = new bq(this);
    this.jdField_d_of_type_AndroidOsHandler = localbq;
    this.w = 1;
    this.x = 2;
    this.jdField_e_of_type_Int = 150;
    this.jdField_f_of_type_Int = 150;
    this.jdField_g_of_type_Int = 150;
    br localbr = new br(this);
    this.jdField_a_of_type_AndroidOsHandler = localbr;
    this.jdField_c_of_type_JavaLangString = "";
    this.jdField_b_of_type_AndroidViewView = null;
    this.y = -1;
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$UpdataPlayPttStateListener = null;
  }

  private int a(String paramString, int paramInt)
  {
    Object localObject1 = null;
    Object localObject2;
    Object localObject4;
    if (paramInt == 0)
    {
      localObject2 = "mr_friend_" + paramString;
      localObject4 = localObject2;
    }
    while (true)
    {
      localObject2 = (QQApplication)getApplicationContext();
      try
      {
        localObject2 = ((QQApplication)localObject2).a().getReadableDatabase();
        StringBuilder localStringBuilder = new StringBuilder().append("[rawQuery]");
        String str1 = super.getClass().getName();
        String str2 = str1 + " getMessageNumber";
        QLog.d("query", str2);
        localObject4 = "select count(*) from " + (String)localObject4;
        localObject2 = ((SQLiteDatabase)localObject2).rawQuery((String)localObject4, null);
        if (localObject2 == null)
          break label209;
        localObject4 = ((Cursor)localObject2).moveToFirst();
        if (localObject4 == 0)
          break label209;
        localObject4 = ((Cursor)localObject2).getInt(0);
        ((Cursor)localObject2).close();
        localObject2 = localObject4;
        label169: return localObject2;
        localObject2 = "mr_troop_" + paramString;
        label209: localObject4 = localObject2;
      }
      catch (Exception localObject3)
      {
        Object localObject3 = localObject1;
        break label169:
        localObject3 = localObject1;
        break label169:
      }
    }
  }

  private void a(Intent paramIntent)
  {
    int i1 = 240;
    int i2 = 180;
    String str1 = paramIntent.getExtras().getString("filePath");
    Object localObject1 = Uri.parse(str1);
    localObject1 = ImageUtil.getThumbPath(this, (Uri)localObject1);
    File localFile = new File((String)localObject1);
    if ((!localFile.exists()) || (localFile.length() > 20480L))
      ImageUtil.compressImagetoSize(BaseApplication.getContext(), str1, (String)localObject1, i1, i2);
    StringBuilder localStringBuilder = new StringBuilder().append("thumbFile.length");
    long l1 = localFile.length();
    Object localObject2;
    String str2 = localObject2;
    QLog.v("wdc", localFile);
    if (!new File((String)localObject1).exists())
      ImageUtil.compressImagetoSize(BaseApplication.getContext(), str1, (String)localObject1, i1, i2);
    EntityManager localEntityManager = QQApplication.createEntityManagerFactory(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).createEntityManager();
    CustomEmotionData localCustomEmotionData = new CustomEmotionData();
    String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
    localCustomEmotionData.uin = str3;
    int i3 = this.v;
    localCustomEmotionData.emoId = i3;
    localCustomEmotionData.emoPath = str1;
    localEntityManager.a(localCustomEmotionData, null);
    localEntityManager.a();
  }

  private void a(View paramView, float paramFloat)
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(paramFloat, null, null, null);
    this.jdField_a_of_type_AndroidViewAnimationAnimation = localTranslateAnimation;
    this.jdField_a_of_type_AndroidViewAnimationAnimation.setDuration(500L);
    AlphaAnimation localAlphaAnimation = new AlphaAnimation(1056964608, 1065353216);
    this.jdField_b_of_type_AndroidViewAnimationAnimation = localAlphaAnimation;
    this.jdField_b_of_type_AndroidViewAnimationAnimation.setDuration(500L);
    AnimationSet localAnimationSet1 = new AnimationSet(true);
    this.jdField_a_of_type_AndroidViewAnimationAnimationSet = localAnimationSet1;
    AnimationSet localAnimationSet2 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    Animation localAnimation1 = this.jdField_b_of_type_AndroidViewAnimationAnimation;
    localAnimationSet2.addAnimation(localAnimation1);
    AnimationSet localAnimationSet3 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    Animation localAnimation2 = this.jdField_a_of_type_AndroidViewAnimationAnimation;
    localAnimationSet3.addAnimation(localAnimation2);
    AnimationSet localAnimationSet4 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    DecelerateInterpolator localDecelerateInterpolator = new DecelerateInterpolator();
    localAnimationSet4.setInterpolator(localDecelerateInterpolator);
    AnimationSet localAnimationSet5 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    paramView.startAnimation(localAnimationSet5);
  }

  private void a(View paramView, float paramFloat1, float paramFloat2)
  {
    AlphaAnimation localAlphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    this.jdField_b_of_type_AndroidViewAnimationAnimation = localAlphaAnimation;
    Animation localAnimation1 = this.jdField_b_of_type_AndroidViewAnimationAnimation;
    DecelerateInterpolator localDecelerateInterpolator = new DecelerateInterpolator();
    localAnimation1.setInterpolator(localDecelerateInterpolator);
    this.jdField_b_of_type_AndroidViewAnimationAnimation.setDuration(500L);
    Animation localAnimation2 = this.jdField_b_of_type_AndroidViewAnimationAnimation;
    paramView.startAnimation(localAnimation2);
  }

  private void a(View paramView, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    this.jdField_a_of_type_AndroidViewAnimationAnimation = localTranslateAnimation;
    this.jdField_a_of_type_AndroidViewAnimationAnimation.setDuration(500L);
    AlphaAnimation localAlphaAnimation = new AlphaAnimation(paramFloat5, paramFloat6);
    this.jdField_b_of_type_AndroidViewAnimationAnimation = localAlphaAnimation;
    this.jdField_b_of_type_AndroidViewAnimationAnimation.setDuration(500L);
    AnimationSet localAnimationSet1 = new AnimationSet(true);
    this.jdField_a_of_type_AndroidViewAnimationAnimationSet = localAnimationSet1;
    AnimationSet localAnimationSet2 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    Animation localAnimation1 = this.jdField_b_of_type_AndroidViewAnimationAnimation;
    localAnimationSet2.addAnimation(localAnimation1);
    AnimationSet localAnimationSet3 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    Animation localAnimation2 = this.jdField_a_of_type_AndroidViewAnimationAnimation;
    localAnimationSet3.addAnimation(localAnimation2);
    AnimationSet localAnimationSet4 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    DecelerateInterpolator localDecelerateInterpolator = new DecelerateInterpolator();
    localAnimationSet4.setInterpolator(localDecelerateInterpolator);
    AnimationSet localAnimationSet5 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    bp localbp = new bp(this, paramFloat1, paramFloat2);
    localAnimationSet5.setAnimationListener(localbp);
    AnimationSet localAnimationSet6 = this.jdField_a_of_type_AndroidViewAnimationAnimationSet;
    paramView.startAnimation(localAnimationSet6);
  }

  private void a(String paramString, int paramInt, boolean paramBoolean)
  {
    int i1 = 2131492958;
    int i2 = 0;
    int i4;
    if (!this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_Boolean)
    {
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      MessageUtil.setMessageReaded(localBaseServiceHelper, localBaseActionListener, str, paramString, paramInt);
      this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a(paramInt, paramString, i2);
      this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter.a(paramString, paramInt, paramBoolean);
      int i5 = this.jdField_h_of_type_Int;
      int i3 = 1;
      if (i5 == i3)
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.g();
      i4 = a(paramString, paramInt);
      if (i4 <= 0)
        break label164;
      ((Button)this.jdField_a_of_type_AndroidViewView.findViewById(i1)).setVisibility(i2);
    }
    while (true)
    {
      if (i4 > 1000)
      {
        bl localbl = new bl(this);
        new Thread(localbl).start();
      }
      return;
      label164: ((Button)this.jdField_a_of_type_AndroidViewView.findViewById(i1)).setVisibility(8);
    }
  }

  private void a(boolean paramBoolean, String paramString, int paramInt)
  {
    Intent localIntent = new Intent(this, DoodleActivity.class);
    localIntent.putExtra("doodletype", paramBoolean);
    int i1 = this.jdField_h_of_type_Int;
    localIntent.putExtra("friendtype", i1);
    String str = this.jdField_a_of_type_JavaLangString;
    localIntent.putExtra("frienduin", str);
    localIntent.putExtra("photofilepath", paramString);
    localIntent.putExtra("rotation", paramInt);
    localIntent.setFlags(67108864);
    startActivityForResult(localIntent, 4);
  }

  private void b(int paramInt)
  {
    long l1 = 0L;
    String str1 = null;
    int i1 = null;
    int i2 = 1;
    Object localObject1 = QQApplication.createEntityManagerFactory(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).createEntityManager();
    Object localObject2 = "emoId=?";
    String[] arrayOfString = new String[i2];
    String str2 = String.valueOf(paramInt);
    arrayOfString[i1] = str2;
    str2 = str1;
    Object localObject3 = ((EntityManager)localObject1).a(CustomEmotionData.class, (String)localObject2, arrayOfString, str1, str2);
    ((EntityManager)localObject1).a();
    if (localObject3 == null);
    label85: String str3;
    do
    {
      return;
      localObject1 = (CustomEmotionData)((List)localObject3).get(i1);
      str3 = ((CustomEmotionData)localObject1).emoPath;
    }
    while (str3 == null);
    str1 = this.jdField_a_of_type_JavaLangString;
    if (str3 != null)
    {
      str2 = TransfileUtile.makeTransFileProtocolData(str3, l1, i2, i2);
      localObject1 = new StorageMessage();
      localObject3 = ((StorageMessage)localObject1).a;
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      ((MessageRecordInfo)localObject3).jdField_a_of_type_JavaLangString = ((String)localObject2);
      ((StorageMessage)localObject1).a.jdField_b_of_type_JavaLangString = str1;
      localObject3 = ((StorageMessage)localObject1).a;
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      ((MessageRecordInfo)localObject3).jdField_c_of_type_JavaLangString = ((String)localObject2);
      ((StorageMessage)localObject1).a.jdField_d_of_type_JavaLangString = str2;
      localObject3 = ((StorageMessage)localObject1).a;
      localObject2 = System.currentTimeMillis();
      l1 = 1000L;
      Object localObject4;
      int i3 = (int)(localObject4 / l1);
      ((MessageRecordInfo)localObject3).jdField_a_of_type_Int = i3;
      ((StorageMessage)localObject1).a.jdField_a_of_type_Boolean = i2;
      ((StorageMessage)localObject1).a.jdField_b_of_type_Boolean = i2;
      localObject3 = ((StorageMessage)localObject1).a;
      i3 = this.jdField_h_of_type_Int;
      if (i3 != i2)
        break label435;
      i3 = i2;
      label284: ((MessageRecordInfo)localObject3).jdField_c_of_type_Boolean = i3;
      long l2 = StorageManager.instance(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).a((Storageable)localObject1);
      BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      int i5 = this.jdField_h_of_type_Int;
      MessageUtil.sendSaveFileMsg((BaseServiceHelper)localObject1, (BaseActionListener)localObject3, i3, i5, str1, str2);
    }
    long l3 = l1;
    if (this.jdField_h_of_type_Int == 0)
    {
      TransFileController localTransFileController1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str5 = this.jdField_a_of_type_JavaLangString;
      localTransFileController1.a(str5, str3, l3);
    }
    while (true)
    {
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      ChatMessageListAdapter localChatMessageListAdapter = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
      String str6 = this.jdField_a_of_type_JavaLangString;
      int i6 = this.jdField_h_of_type_Int;
      localChatMessageListAdapter.a(str6, i6, i2);
      break label85:
      label435: int i4 = i1;
      break label284:
      TransFileController localTransFileController2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str7 = this.jdField_a_of_type_JavaLangString;
      String str8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      String str9 = str3;
      localTransFileController2.a(str7, str8, str9, l3);
    }
  }

  private void b(Intent paramIntent)
  {
    int i1 = 8;
    int i2 = 0;
    int i3 = 1;
    Bundle localBundle = paramIntent.getExtras();
    if (localBundle != null)
    {
      boolean bool = localBundle.getBoolean("single");
      this.jdField_a_of_type_Boolean = bool;
    }
    Object localObject = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    int i4 = this.jdField_h_of_type_Int;
    String str1 = this.jdField_a_of_type_JavaLangString;
    localObject = ((QQApplication)localObject).a(i4, str1, i3);
    if ((localBundle != null) && (localObject == 0) && (localBundle.getString("uin") != null))
    {
      String str2 = localBundle.getString("uin");
      String str3 = this.jdField_a_of_type_JavaLangString;
      if (str2.equals(str3))
      {
        int i5 = localBundle.getInt("uin type");
        int i6 = this.jdField_h_of_type_Int;
        if (i5 == i6)
        {
          String str4 = this.jdField_a_of_type_JavaLangString;
          int i7 = this.jdField_h_of_type_Int;
          d(str4, i7);
        }
      }
    }
    while (true)
    {
      return;
      if (localBundle != null)
      {
        if (this.jdField_a_of_type_JavaLangString != null)
        {
          String str5 = this.jdField_a_of_type_JavaLangString;
          String str6 = localBundle.getString("uin");
          if (str5.equals(str6))
          {
            int i8 = this.jdField_h_of_type_Int;
            int i9 = localBundle.getInt("uin type");
            if (i8 == i9)
              break label329;
          }
        }
        String str7 = this.jdField_a_of_type_JavaLangString;
        this.jdField_e_of_type_JavaLangString = str7;
        String str8 = localBundle.getString("uin");
        this.jdField_a_of_type_JavaLangString = str8;
        int i10 = localBundle.getInt("uin type");
        this.jdField_h_of_type_Int = localBundle;
        this.jdField_a_of_type_AndroidWidgetEditText.setText("");
        Intent localIntent1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[i3];
        String str9 = this.jdField_a_of_type_JavaLangString;
        localBundle.putExtra("uin", str9);
        Intent localIntent2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[i3];
        int i11 = this.jdField_h_of_type_Int;
        localBundle.putExtra("uin type", i11);
        label329: StringBuilder localStringBuilder1 = new StringBuilder().append("curFriendUin:");
        String str10 = this.jdField_a_of_type_JavaLangString;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str10).append("curType:");
        int i12 = this.jdField_h_of_type_Int;
        String str11 = i12;
        QLog.v("ChatWindowActivity", str11);
        String str12 = this.jdField_a_of_type_JavaLangString;
        int i13 = this.jdField_h_of_type_Int;
        c(str12, i13);
      }
      if (this.jdField_a_of_type_JavaLangString == null)
        continue;
      String str13 = this.jdField_a_of_type_JavaLangString;
      int i14 = this.jdField_h_of_type_Int;
      d(str13, i14);
      String str14 = this.jdField_a_of_type_JavaLangString;
      int i15 = this.jdField_h_of_type_Int;
      a(str14, i15, i3);
      f();
      d();
      h();
      if (this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().signature == null)
      {
        BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str15 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        int i16 = AppSetting.APP_ID;
        byte[] arrayOfByte = LoginHelper.getA2(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin());
        MessageUtil.sendGetSig(localBaseServiceHelper, localBaseActionListener, str15, i3, i16, 4, arrayOfByte);
      }
      this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
      this.jdField_f_of_type_AndroidWidgetImageView.setVisibility(i1);
      this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i2);
      this.jdField_d_of_type_AndroidWidgetImageView.setVisibility(i2);
    }
  }

  private void c(Intent paramIntent)
  {
    if ((paramIntent == null) || (paramIntent.getExtras() == null))
      QLog.e("photo", "onSendPicture data null");
    while (true)
    {
      return;
      String str1 = paramIntent.getExtras().getString("filePath");
      long l1 = paramIntent.getExtras().getLong("fileSize");
      String str2 = paramIntent.getExtras().getString("fileType");
      long l2 = paramIntent.getExtras().getLong("fileId");
      Object localObject1;
      String str3 = "onSendPicture path: " + str1 + " size: " + localObject1 + " type: " + str2;
      QLog.v("photo", str3);
      TransFileController localTransFileController = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str4 = this.jdField_a_of_type_JavaLangString;
      Object localObject2;
      localTransFileController.a(str4, str1, localObject2);
    }
  }

  private void c(String paramString, int paramInt)
  {
    if (paramString == null)
    {
      QLog.e("ChatWindowActivity", "initMessageTable fail uin null");
      label12: return;
    }
    while (true)
    {
      try
      {
        StorageMessage localStorageMessage = new StorageMessage();
        MessageRecordInfo localMessageRecordInfo = localStorageMessage.a;
        String str = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
        localMessageRecordInfo.jdField_a_of_type_JavaLangString = str;
        localStorageMessage.a.jdField_b_of_type_JavaLangString = paramString;
        localMessageRecordInfo = localStorageMessage.a;
        if (paramInt != 0)
          break label99;
        str = null;
        localMessageRecordInfo.jdField_c_of_type_Boolean = str;
        StorageManager.instance(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin()).a(localStorageMessage);
      }
      catch (Exception localException)
      {
      }
      break label12:
      label99: int i1 = 1;
    }
  }

  private static boolean checkAbility()
  {
    return true;
  }

  // ERROR //
  private static void clearBottomLine(android.widget.TabWidget paramTabWidget)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   4: ldc_w 1070
    //   7: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   10: astore_1
    //   11: aload_1
    //   12: invokevirtual 1079	java/lang/reflect/Field:isAccessible	()Z
    //   15: ifne +8 -> 23
    //   18: aload_1
    //   19: iconst_1
    //   20: invokevirtual 1082	java/lang/reflect/Field:setAccessible	(Z)V
    //   23: new 1084	android/graphics/drawable/ColorDrawable
    //   26: dup
    //   27: invokespecial 1085	android/graphics/drawable/ColorDrawable:<init>	()V
    //   30: astore_2
    //   31: aload_1
    //   32: aload_0
    //   33: aload_2
    //   34: invokevirtual 1089	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   37: aload_0
    //   38: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   41: ldc_w 1091
    //   44: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   47: astore_1
    //   48: aload_1
    //   49: invokevirtual 1079	java/lang/reflect/Field:isAccessible	()Z
    //   52: ifne +8 -> 60
    //   55: aload_1
    //   56: iconst_1
    //   57: invokevirtual 1082	java/lang/reflect/Field:setAccessible	(Z)V
    //   60: new 1084	android/graphics/drawable/ColorDrawable
    //   63: dup
    //   64: invokespecial 1085	android/graphics/drawable/ColorDrawable:<init>	()V
    //   67: astore_3
    //   68: aload_1
    //   69: aload_0
    //   70: aload_3
    //   71: invokevirtual 1089	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   74: return
    //   75: astore_1
    //   76: aload_0
    //   77: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   80: ldc_w 1093
    //   83: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   86: astore_1
    //   87: goto -76 -> 11
    //   90: astore_1
    //   91: aload_0
    //   92: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   95: ldc_w 1095
    //   98: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   101: astore_1
    //   102: goto -54 -> 48
    //   105: astore 4
    //   107: goto -33 -> 74
    //
    // Exception table:
    //   from	to	target	type
    //   0	11	75	java/lang/NoSuchFieldException
    //   37	48	90	java/lang/NoSuchFieldException
    //   0	11	105	java/lang/Exception
    //   11	37	105	java/lang/Exception
    //   37	48	105	java/lang/Exception
    //   48	102	105	java/lang/Exception
  }

  private void d()
  {
    EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    String str = this.jdField_a_of_type_JavaLangString;
    localEntityManager.a(VideoAbility.class, str);
    localEntityManager.a();
  }

  private void d(String paramString, int paramInt)
  {
    int i1 = 2131493075;
    int i2 = 16908294;
    int i3 = 1;
    int i4 = 0;
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
    if (localObject2 != null)
    {
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString.compareTo(paramString);
      if (localObject2 == 0)
      {
        int i5 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_Int;
        if (i5 == paramInt)
          break label223;
      }
    }
    findViewById(i1).setVisibility(i4);
    Object localObject3 = new QQServiceEntry.Tag();
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag = ((QQServiceEntry.Tag)localObject3);
    localObject3 = (ImageView)findViewById(i2);
    Object localObject4 = (GridView)findViewById(2131493076);
    ((GridView)localObject4).setVisibility(8);
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag.jdField_a_of_type_Int = paramInt;
    QQServiceEntry.Tag localTag = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
    localTag.jdField_a_of_type_AndroidWidgetGridView = ((GridView)localObject4);
    label164: label223: TextView localTextView;
    Object localObject1;
    if (paramInt == 0)
    {
      localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
      int i6 = 13;
      ((QQServiceEntry.Tag)localObject4).b = i6;
      localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
      ((ImageView)localObject3).setTag(localObject4);
      localObject4 = this.jdField_a_of_type_Ce;
      ((ImageView)localObject3).setOnClickListener((View.OnClickListener)localObject4);
      localObject3 = findViewById(i1);
      localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
      ((View)localObject3).setTag(localObject4);
      localObject4 = this.jdField_a_of_type_Ce;
      ((View)localObject3).setOnClickListener((View.OnClickListener)localObject4);
      localObject3 = (ImageView)findViewById(i2);
      localObject4 = (TextView)findViewById(16908308);
      ((TextView)localObject4).setVisibility(i4);
      localTextView = (TextView)findViewById(16908309);
      localTextView.setVisibility(i4);
      localObject1 = (LinearLayout)findViewById(2131493074);
      this.jdField_b_of_type_AndroidWidgetLinearLayout = ((LinearLayout)localObject1);
      if (paramInt != 0)
        break label667;
      i1 = 0;
      EntityManager localEntityManager1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
      localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a(paramString);
      if (localObject1 != null)
        break label586;
      localObject1 = paramString.equals("10000");
      if (localObject1 == 0)
        break label561;
      Drawable localDrawable1 = getResources().getDrawable(2130838047);
      localObject1 = (BitmapDrawable)localDrawable1;
      ((BitmapDrawable)localObject1).getBitmap();
      ((ImageView)localObject3).setImageDrawable(localDrawable1);
      localObject3 = i1;
      label375: localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ComTencentMobileqqUtilsCacheUtils.a(paramString);
      if (localObject1 == null)
        break label651;
      String str1 = ((FriendMore)localObject1).signature;
      localTextView.setText((CharSequence)localObject1);
      if ((localObject3 == null) || (((String)localObject3).trim().length() == 0))
      {
        label407: localObject3 = (FriendInfo)localEntityManager1.a(FriendInfo.class, paramString);
        if ((localObject3 == null) || (((FriendInfo)localObject3).nickname == null))
          break label661;
        localObject3 = ((FriendInfo)localObject3).nickname;
      }
      if (paramString.equals("10000"))
        label457: localObject3 = "绯荤";
      ((TextView)localObject4).setText((CharSequence)localObject3);
      localEntityManager1.a();
      label484: ImageView localImageView1 = (ImageView)findViewById(2131492975);
      this.jdField_d_of_type_AndroidWidgetImageView = localImageView1;
      if (this.jdField_h_of_type_Int != i3)
        break label828;
      this.jdField_d_of_type_AndroidWidgetImageView.setImageResource(2130837918);
    }
    while (true)
    {
      ImageView localImageView2 = this.jdField_d_of_type_AndroidWidgetImageView;
      aw localaw = new aw(this);
      localImageView2.setOnClickListener(localaw);
      return;
      localObject4 = this.jdField_a_of_type_ComTencentMobileqqAppQQServiceEntry$Tag;
      ((QQServiceEntry.Tag)localObject4).b = i3;
      break label164:
      label561: localObject1 = getResources().getDrawable(2130837749);
      ((ImageView)localObject3).setImageDrawable((Drawable)localObject1);
      localObject3 = i1;
      break label375:
      label586: QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      int i7 = ((Friends)localObject1).faceid;
      int i8 = ((Friends)localObject1).status;
      int i9 = ((Friends)localObject1).sqqOnLineState;
      boolean bool = isOffline(i8, i9);
      Drawable localDrawable2 = localQQApplication.b(i7, paramString, bool);
      ((ImageView)localObject3).setImageDrawable(localDrawable2);
      localObject3 = ((Friends)localObject1).name;
      break label375:
      label651: localTextView.setText("");
      break label407:
      label661: localObject3 = paramString;
      break label457:
      label667: EntityManager localEntityManager2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
      TroopInfo localTroopInfo = (TroopInfo)localEntityManager2.a(TroopInfo.class, paramString);
      this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo = localTroopInfo;
      localEntityManager2.a();
      Drawable localDrawable3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getResources().getDrawable(2130837734);
      ((ImageView)localObject3).setImageDrawable(localDrawable3);
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo;
      if (localObject3 == null)
      {
        ((TextView)localObject4).setText(paramString);
        localTextView.setText("");
      }
      localObject3 = this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo.troopname;
      if (localObject3 != null)
      {
        localObject3 = this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo.troopname.trim().length();
        if (localObject3 <= 0);
      }
      for (localObject3 = this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo.troopname; ; localObject3 = paramString)
      {
        ((TextView)localObject4).setText((CharSequence)localObject3);
        String str2 = this.jdField_a_of_type_ComTencentMobileqqDataTroopInfo.troopmemo;
        localTextView.setText((CharSequence)localObject3);
        break label484:
      }
      label828: this.jdField_d_of_type_AndroidWidgetImageView.setImageResource(2130837539);
      int i10 = this.jdField_d_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable4 = this.jdField_d_of_type_AndroidWidgetImageView.getDrawable();
      Drawable localDrawable5 = SkinEngine.getSkinDrawable(i10, "src", localDrawable4);
      this.jdField_d_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable5);
    }
  }

  // ERROR //
  private void e()
  {
    // Byte code:
    //   0: bipush 17
    //   2: istore_1
    //   3: ldc_w 374
    //   6: istore_2
    //   7: iconst_0
    //   8: istore_3
    //   9: iconst_1
    //   10: istore 4
    //   12: aconst_null
    //   13: astore 5
    //   15: aload_0
    //   16: ldc_w 1229
    //   19: invokevirtual 1233	com/tencent/mobileqq/activity/ChatWindowActivity:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   22: checkcast 1235	android/view/LayoutInflater
    //   25: astore 6
    //   27: aload_0
    //   28: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   31: astore 7
    //   33: aload 7
    //   35: ifnull +1219 -> 1254
    //   38: aload_0
    //   39: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   42: invokevirtual 1242	android/widget/TabHost:getCurrentTab	()I
    //   45: astore 7
    //   47: iload 7
    //   49: istore 8
    //   51: aload_0
    //   52: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   55: astore 7
    //   57: aload 7
    //   59: ifnull +1189 -> 1248
    //   62: aload_0
    //   63: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   66: invokevirtual 1244	android/widget/GridView:getLastVisiblePosition	()I
    //   69: bipush 15
    //   71: isub
    //   72: istore 7
    //   74: iload 7
    //   76: ifge +6 -> 82
    //   79: iload_3
    //   80: istore 7
    //   82: iload 7
    //   84: istore 9
    //   86: ldc_w 1245
    //   89: istore 7
    //   91: aload 6
    //   93: iload 7
    //   95: aload 5
    //   97: invokevirtual 1249	android/view/LayoutInflater:inflate	(ILandroid/view/ViewGroup;)Landroid/view/View;
    //   100: checkcast 1239	android/widget/TabHost
    //   103: astore 6
    //   105: aload_0
    //   106: aload 6
    //   108: putfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   111: aload_0
    //   112: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   115: invokevirtual 1252	android/widget/TabHost:setup	()V
    //   118: aload_0
    //   119: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   122: fload_2
    //   123: fcmpl
    //   124: fstore 6
    //   126: iload 6
    //   128: ifle +1029 -> 1157
    //   131: bipush 14
    //   133: istore 6
    //   135: aload_0
    //   136: iload 6
    //   138: putfield 808	com/tencent/mobileqq/activity/ChatWindowActivity:m	I
    //   141: aload_0
    //   142: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   145: fload_2
    //   146: fcmpg
    //   147: fstore 6
    //   149: iload 6
    //   151: ifge +13 -> 164
    //   154: bipush 255
    //   156: istore 6
    //   158: aload_0
    //   159: iload 6
    //   161: putfield 808	com/tencent/mobileqq/activity/ChatWindowActivity:m	I
    //   164: aload_0
    //   165: invokevirtual 750	com/tencent/mobileqq/activity/ChatWindowActivity:getResources	()Landroid/content/res/Resources;
    //   168: invokevirtual 1256	android/content/res/Resources:getConfiguration	()Landroid/content/res/Configuration;
    //   171: astore 7
    //   173: aload 7
    //   175: getfield 1261	android/content/res/Configuration:orientation	I
    //   178: istore 6
    //   180: iload 6
    //   182: iload 4
    //   184: if_icmpne +979 -> 1163
    //   187: bipush 7
    //   189: istore 6
    //   191: aload_0
    //   192: iload 6
    //   194: putfield 1263	com/tencent/mobileqq/activity/ChatWindowActivity:p	I
    //   197: aload_0
    //   198: getfield 808	com/tencent/mobileqq/activity/ChatWindowActivity:m	I
    //   201: iconst_2
    //   202: imul
    //   203: istore 6
    //   205: iinc 6 30
    //   208: aload_0
    //   209: iload 6
    //   211: putfield 802	com/tencent/mobileqq/activity/ChatWindowActivity:k	I
    //   214: aload_0
    //   215: getfield 808	com/tencent/mobileqq/activity/ChatWindowActivity:m	I
    //   218: iconst_2
    //   219: imul
    //   220: istore 6
    //   222: iinc 6 30
    //   225: aload_0
    //   226: iload 6
    //   228: putfield 805	com/tencent/mobileqq/activity/ChatWindowActivity:l	I
    //   231: aload_0
    //   232: getfield 802	com/tencent/mobileqq/activity/ChatWindowActivity:k	I
    //   235: istore 6
    //   237: aload_0
    //   238: getfield 1263	com/tencent/mobileqq/activity/ChatWindowActivity:p	I
    //   241: istore 10
    //   243: iload 6
    //   245: iload 10
    //   247: imul
    //   248: i2f
    //   249: fstore 6
    //   251: aload_0
    //   252: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   255: istore 11
    //   257: ldc_w 1264
    //   260: fload 11
    //   262: fmul
    //   263: fstore 12
    //   265: fload 6
    //   267: fload 12
    //   269: fadd
    //   270: fstore 6
    //   272: aload_0
    //   273: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   276: fload_2
    //   277: fmul
    //   278: fstore 13
    //   280: fload 6
    //   282: fload 13
    //   284: fadd
    //   285: f2i
    //   286: istore 6
    //   288: aload_0
    //   289: iload 6
    //   291: putfield 1266	com/tencent/mobileqq/activity/ChatWindowActivity:n	I
    //   294: aload 7
    //   296: getfield 1261	android/content/res/Configuration:orientation	I
    //   299: istore 6
    //   301: iload 6
    //   303: iload 4
    //   305: if_icmpne +865 -> 1170
    //   308: aload_0
    //   309: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   312: istore 14
    //   314: ldc_w 1267
    //   317: fload 14
    //   319: fmul
    //   320: f2i
    //   321: istore 6
    //   323: aload_0
    //   324: iload 6
    //   326: putfield 1269	com/tencent/mobileqq/activity/ChatWindowActivity:o	I
    //   329: aload_0
    //   330: getfield 1269	com/tencent/mobileqq/activity/ChatWindowActivity:o	I
    //   333: istore 6
    //   335: aload_0
    //   336: getfield 1269	com/tencent/mobileqq/activity/ChatWindowActivity:o	I
    //   339: istore 15
    //   341: aload_0
    //   342: getfield 805	com/tencent/mobileqq/activity/ChatWindowActivity:l	I
    //   345: istore 16
    //   347: iload 15
    //   349: iload 16
    //   351: irem
    //   352: istore 17
    //   354: iload 6
    //   356: iload 17
    //   358: iadd
    //   359: istore 6
    //   361: aload_0
    //   362: iload 6
    //   364: putfield 1269	com/tencent/mobileqq/activity/ChatWindowActivity:o	I
    //   367: aload_0
    //   368: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   371: ldc_w 1270
    //   374: invokevirtual 1271	android/widget/TabHost:findViewById	(I)Landroid/view/View;
    //   377: checkcast 1111	android/widget/GridView
    //   380: astore 6
    //   382: new 1273	bf
    //   385: dup
    //   386: aload_0
    //   387: invokespecial 1274	bf:<init>	(Lcom/tencent/mobileqq/activity/ChatWindowActivity;)V
    //   390: astore 18
    //   392: aload 6
    //   394: aload 18
    //   396: invokevirtual 1278	android/widget/GridView:setOnItemClickListener	(Landroid/widget/AdapterView$OnItemClickListener;)V
    //   399: aload_0
    //   400: getfield 1263	com/tencent/mobileqq/activity/ChatWindowActivity:p	I
    //   403: istore 19
    //   405: aload 6
    //   407: iload 19
    //   409: invokevirtual 1281	android/widget/GridView:setNumColumns	(I)V
    //   412: aload_0
    //   413: getfield 802	com/tencent/mobileqq/activity/ChatWindowActivity:k	I
    //   416: istore 20
    //   418: aload 6
    //   420: iload 20
    //   422: invokevirtual 1284	android/widget/GridView:setColumnWidth	(I)V
    //   425: new 1286	bz
    //   428: dup
    //   429: aload_0
    //   430: aload_0
    //   431: invokespecial 1289	bz:<init>	(Lcom/tencent/mobileqq/activity/ChatWindowActivity;Landroid/content/Context;)V
    //   434: astore 21
    //   436: aload 6
    //   438: aload 21
    //   440: invokevirtual 1293	android/widget/GridView:setAdapter	(Landroid/widget/ListAdapter;)V
    //   443: aload 7
    //   445: getfield 1261	android/content/res/Configuration:orientation	I
    //   448: istore 6
    //   450: iload 6
    //   452: iload 4
    //   454: if_icmpne +734 -> 1188
    //   457: iconst_4
    //   458: istore 6
    //   460: aload_0
    //   461: iload 6
    //   463: putfield 1295	com/tencent/mobileqq/activity/ChatWindowActivity:s	I
    //   466: aload_0
    //   467: getfield 1266	com/tencent/mobileqq/activity/ChatWindowActivity:n	I
    //   470: istore 6
    //   472: aload_0
    //   473: getfield 1295	com/tencent/mobileqq/activity/ChatWindowActivity:s	I
    //   476: istore 7
    //   478: iload 6
    //   480: iload 7
    //   482: idiv
    //   483: istore 6
    //   485: aload_0
    //   486: iload 6
    //   488: putfield 811	com/tencent/mobileqq/activity/ChatWindowActivity:q	I
    //   491: aload_0
    //   492: getfield 811	com/tencent/mobileqq/activity/ChatWindowActivity:q	I
    //   495: i2f
    //   496: fstore 6
    //   498: aload_0
    //   499: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   502: istore 22
    //   504: ldc_w 1296
    //   507: fload 22
    //   509: fmul
    //   510: fstore 7
    //   512: fload 6
    //   514: fload 7
    //   516: fadd
    //   517: f2i
    //   518: istore 6
    //   520: aload_0
    //   521: iload 6
    //   523: putfield 814	com/tencent/mobileqq/activity/ChatWindowActivity:r	I
    //   526: aload_0
    //   527: getfield 321	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_ComTencentMobileqqAppQQApplication	Lcom/tencent/mobileqq/app/QQApplication;
    //   530: getfield 323	com/tencent/mobileqq/app/QQApplication:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   533: invokestatic 327	com/tencent/mobileqq/app/QQApplication:createEntityManagerFactory	(Ljava/lang/String;)Lcom/tencent/mobileqq/persistence/EntityManagerFactory;
    //   536: invokevirtual 333	com/tencent/mobileqq/persistence/EntityManagerFactory:createEntityManager	()Lcom/tencent/mobileqq/persistence/EntityManager;
    //   539: astore 6
    //   541: ldc_w 335
    //   544: astore 7
    //   546: aload 5
    //   548: astore 23
    //   550: aload 5
    //   552: astore 24
    //   554: aload 5
    //   556: astore 25
    //   558: aload 6
    //   560: aload 7
    //   562: aload 5
    //   564: aload 23
    //   566: aload 24
    //   568: aload 25
    //   570: invokevirtual 780	com/tencent/mobileqq/persistence/EntityManager:a	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;
    //   573: astore 6
    //   575: aload 6
    //   577: ifnonnull +618 -> 1195
    //   580: iload_3
    //   581: istore 6
    //   583: aload_0
    //   584: iload 6
    //   586: putfield 732	com/tencent/mobileqq/activity/ChatWindowActivity:t	I
    //   589: aload_0
    //   590: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   593: ldc_w 1297
    //   596: invokevirtual 1271	android/widget/TabHost:findViewById	(I)Landroid/view/View;
    //   599: checkcast 1111	android/widget/GridView
    //   602: astore 6
    //   604: aload_0
    //   605: aload 6
    //   607: putfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   610: aload_0
    //   611: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   614: astore 6
    //   616: new 1299	bh
    //   619: dup
    //   620: aload_0
    //   621: invokespecial 1300	bh:<init>	(Lcom/tencent/mobileqq/activity/ChatWindowActivity;)V
    //   624: astore 7
    //   626: aload 6
    //   628: aload 7
    //   630: invokevirtual 1278	android/widget/GridView:setOnItemClickListener	(Landroid/widget/AdapterView$OnItemClickListener;)V
    //   633: aload_0
    //   634: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   637: astore 6
    //   639: new 1302	bi
    //   642: dup
    //   643: aload_0
    //   644: invokespecial 1303	bi:<init>	(Lcom/tencent/mobileqq/activity/ChatWindowActivity;)V
    //   647: astore 7
    //   649: aload 6
    //   651: aload 7
    //   653: invokevirtual 1307	android/widget/GridView:setOnItemLongClickListener	(Landroid/widget/AdapterView$OnItemLongClickListener;)V
    //   656: aload_0
    //   657: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   660: astore 6
    //   662: aload_0
    //   663: getfield 1295	com/tencent/mobileqq/activity/ChatWindowActivity:s	I
    //   666: istore 7
    //   668: aload 6
    //   670: iload 7
    //   672: invokevirtual 1281	android/widget/GridView:setNumColumns	(I)V
    //   675: aload_0
    //   676: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   679: astore 6
    //   681: aload_0
    //   682: getfield 811	com/tencent/mobileqq/activity/ChatWindowActivity:q	I
    //   685: istore 7
    //   687: aload 6
    //   689: iload 7
    //   691: invokevirtual 1284	android/widget/GridView:setColumnWidth	(I)V
    //   694: new 1309	cd
    //   697: dup
    //   698: aload_0
    //   699: aload_0
    //   700: invokespecial 1310	cd:<init>	(Lcom/tencent/mobileqq/activity/ChatWindowActivity;Landroid/content/Context;)V
    //   703: astore 6
    //   705: aload_0
    //   706: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   709: astore 7
    //   711: aload 7
    //   713: aload 6
    //   715: invokevirtual 1293	android/widget/GridView:setAdapter	(Landroid/widget/ListAdapter;)V
    //   718: aload_0
    //   719: getfield 1243	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetGridView	Landroid/widget/GridView;
    //   722: iload 9
    //   724: invokevirtual 1313	android/widget/GridView:setSelection	(I)V
    //   727: aload_0
    //   728: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   731: astore 6
    //   733: aload 6
    //   735: ifnull +14 -> 749
    //   738: aload_0
    //   739: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   742: astore 6
    //   744: aload 6
    //   746: invokevirtual 796	android/app/Dialog:dismiss	()V
    //   749: new 793	android/app/Dialog
    //   752: dup
    //   753: aload_0
    //   754: invokespecial 1314	android/app/Dialog:<init>	(Landroid/content/Context;)V
    //   757: astore 6
    //   759: aload_0
    //   760: aload 6
    //   762: putfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   765: aload_0
    //   766: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   769: invokevirtual 1318	android/app/Dialog:getWindow	()Landroid/view/Window;
    //   772: iload 4
    //   774: invokevirtual 1324	android/view/Window:requestFeature	(I)Z
    //   777: pop
    //   778: aload_0
    //   779: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   782: invokevirtual 1318	android/app/Dialog:getWindow	()Landroid/view/Window;
    //   785: ldc_w 1325
    //   788: invokevirtual 1328	android/view/Window:setBackgroundDrawableResource	(I)V
    //   791: aload_0
    //   792: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   795: astore 6
    //   797: aload_0
    //   798: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   801: ldc_w 1330
    //   804: invokevirtual 1334	android/widget/TabHost:newTabSpec	(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    //   807: ldc_w 1336
    //   810: aload 5
    //   812: invokevirtual 1342	android/widget/TabHost$TabSpec:setIndicator	(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;)Landroid/widget/TabHost$TabSpec;
    //   815: ldc_w 1270
    //   818: invokevirtual 1346	android/widget/TabHost$TabSpec:setContent	(I)Landroid/widget/TabHost$TabSpec;
    //   821: astore 7
    //   823: aload 6
    //   825: aload 7
    //   827: invokevirtual 1350	android/widget/TabHost:addTab	(Landroid/widget/TabHost$TabSpec;)V
    //   830: aload_0
    //   831: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   834: astore 6
    //   836: aload_0
    //   837: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   840: ldc_w 1352
    //   843: invokevirtual 1334	android/widget/TabHost:newTabSpec	(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    //   846: ldc_w 1336
    //   849: aload 5
    //   851: invokevirtual 1342	android/widget/TabHost$TabSpec:setIndicator	(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;)Landroid/widget/TabHost$TabSpec;
    //   854: ldc_w 1297
    //   857: invokevirtual 1346	android/widget/TabHost$TabSpec:setContent	(I)Landroid/widget/TabHost$TabSpec;
    //   860: astore 7
    //   862: aload 6
    //   864: aload 7
    //   866: invokevirtual 1350	android/widget/TabHost:addTab	(Landroid/widget/TabHost$TabSpec;)V
    //   869: aload_0
    //   870: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   873: astore 6
    //   875: ldc_w 1353
    //   878: istore 7
    //   880: aload 6
    //   882: iload 7
    //   884: invokevirtual 1271	android/widget/TabHost:findViewById	(I)Landroid/view/View;
    //   887: checkcast 1355	android/widget/TabWidget
    //   890: astore 6
    //   892: aload 6
    //   894: invokevirtual 1358	android/widget/TabWidget:removeAllViews	()V
    //   897: aload 6
    //   899: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   902: ldc_w 1070
    //   905: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   908: astore 7
    //   910: aload 7
    //   912: invokevirtual 1079	java/lang/reflect/Field:isAccessible	()Z
    //   915: ifne +9 -> 924
    //   918: aload 7
    //   920: iconst_1
    //   921: invokevirtual 1082	java/lang/reflect/Field:setAccessible	(Z)V
    //   924: new 1084	android/graphics/drawable/ColorDrawable
    //   927: dup
    //   928: invokespecial 1085	android/graphics/drawable/ColorDrawable:<init>	()V
    //   931: astore 26
    //   933: aload 7
    //   935: aload 6
    //   937: aload 26
    //   939: invokevirtual 1089	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   942: aload 6
    //   944: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   947: ldc_w 1091
    //   950: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   953: astore 7
    //   955: aload 7
    //   957: invokevirtual 1079	java/lang/reflect/Field:isAccessible	()Z
    //   960: ifne +9 -> 969
    //   963: aload 7
    //   965: iconst_1
    //   966: invokevirtual 1082	java/lang/reflect/Field:setAccessible	(Z)V
    //   969: new 1084	android/graphics/drawable/ColorDrawable
    //   972: dup
    //   973: invokespecial 1085	android/graphics/drawable/ColorDrawable:<init>	()V
    //   976: astore 27
    //   978: aload 7
    //   980: aload 6
    //   982: aload 27
    //   984: invokevirtual 1089	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   987: new 1131	android/widget/TextView
    //   990: dup
    //   991: aload_0
    //   992: invokespecial 1359	android/widget/TextView:<init>	(Landroid/content/Context;)V
    //   995: astore 28
    //   997: aload 28
    //   999: ldc_w 1361
    //   1002: invokevirtual 1162	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   1005: aload 28
    //   1007: iload_1
    //   1008: invokevirtual 1364	android/widget/TextView:setGravity	(I)V
    //   1011: aload_0
    //   1012: invokevirtual 750	com/tencent/mobileqq/activity/ChatWindowActivity:getResources	()Landroid/content/res/Resources;
    //   1015: ldc_w 1365
    //   1018: invokevirtual 1144	android/content/res/Resources:getDrawable	(I)Landroid/graphics/drawable/Drawable;
    //   1021: astore 29
    //   1023: aload 28
    //   1025: aload 29
    //   1027: invokevirtual 1368	android/widget/TextView:setBackgroundDrawable	(Landroid/graphics/drawable/Drawable;)V
    //   1030: aload 6
    //   1032: aload 28
    //   1034: invokevirtual 1372	android/widget/TabWidget:addView	(Landroid/view/View;)V
    //   1037: new 1131	android/widget/TextView
    //   1040: dup
    //   1041: aload_0
    //   1042: invokespecial 1359	android/widget/TextView:<init>	(Landroid/content/Context;)V
    //   1045: astore 30
    //   1047: aload 30
    //   1049: ldc_w 1374
    //   1052: invokevirtual 1162	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   1055: aload 30
    //   1057: iload_1
    //   1058: invokevirtual 1364	android/widget/TextView:setGravity	(I)V
    //   1061: aload_0
    //   1062: invokevirtual 750	com/tencent/mobileqq/activity/ChatWindowActivity:getResources	()Landroid/content/res/Resources;
    //   1065: ldc_w 1375
    //   1068: invokevirtual 1144	android/content/res/Resources:getDrawable	(I)Landroid/graphics/drawable/Drawable;
    //   1071: astore 31
    //   1073: aload 30
    //   1075: aload 31
    //   1077: invokevirtual 1368	android/widget/TextView:setBackgroundDrawable	(Landroid/graphics/drawable/Drawable;)V
    //   1080: aload 6
    //   1082: aload 30
    //   1084: invokevirtual 1372	android/widget/TabWidget:addView	(Landroid/view/View;)V
    //   1087: aload_0
    //   1088: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   1091: iload 8
    //   1093: invokevirtual 1378	android/widget/TabHost:setCurrentTab	(I)V
    //   1096: aload 6
    //   1098: iload 8
    //   1100: invokevirtual 1379	android/widget/TabWidget:setCurrentTab	(I)V
    //   1103: aload_0
    //   1104: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   1107: astore 32
    //   1109: aload_0
    //   1110: getfield 1237	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidWidgetTabHost	Landroid/widget/TabHost;
    //   1113: astore 33
    //   1115: aload_0
    //   1116: getfield 1266	com/tencent/mobileqq/activity/ChatWindowActivity:n	I
    //   1119: istore 34
    //   1121: aload_0
    //   1122: getfield 1269	com/tencent/mobileqq/activity/ChatWindowActivity:o	I
    //   1125: istore 35
    //   1127: new 1381	android/widget/FrameLayout$LayoutParams
    //   1130: dup
    //   1131: iload 34
    //   1133: iload 35
    //   1135: invokespecial 1384	android/widget/FrameLayout$LayoutParams:<init>	(II)V
    //   1138: astore 36
    //   1140: aload 6
    //   1142: aload 33
    //   1144: aload 36
    //   1146: invokevirtual 1388	android/app/Dialog:setContentView	(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   1149: aload_0
    //   1150: getfield 704	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_AndroidAppDialog	Landroid/app/Dialog;
    //   1153: invokevirtual 1389	android/app/Dialog:show	()V
    //   1156: return
    //   1157: iconst_3
    //   1158: istore 6
    //   1160: goto -1025 -> 135
    //   1163: bipush 11
    //   1165: istore 6
    //   1167: goto -976 -> 191
    //   1170: aload_0
    //   1171: getfield 612	com/tencent/mobileqq/activity/ChatWindowActivity:jdField_a_of_type_Float	F
    //   1174: istore 37
    //   1176: ldc_w 1390
    //   1179: fload 37
    //   1181: fmul
    //   1182: f2i
    //   1183: istore 6
    //   1185: goto -862 -> 323
    //   1188: bipush 6
    //   1190: istore 6
    //   1192: goto -732 -> 460
    //   1195: aload 6
    //   1197: invokeinterface 785 1 0
    //   1202: astore 6
    //   1204: goto -621 -> 583
    //   1207: astore 7
    //   1209: aload 6
    //   1211: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   1214: ldc_w 1093
    //   1217: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   1220: astore 7
    //   1222: goto -312 -> 910
    //   1225: astore 7
    //   1227: aload 6
    //   1229: invokevirtual 222	java/lang/Object:getClass	()Ljava/lang/Class;
    //   1232: ldc_w 1095
    //   1235: invokevirtual 1074	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   1238: astore 7
    //   1240: goto -285 -> 955
    //   1243: astore 38
    //   1245: goto -258 -> 987
    //   1248: iload_3
    //   1249: istore 9
    //   1251: goto -1165 -> 86
    //   1254: iload_3
    //   1255: istore 8
    //   1257: goto -1206 -> 51
    //
    // Exception table:
    //   from	to	target	type
    //   897	910	1207	java/lang/NoSuchFieldException
    //   942	955	1225	java/lang/NoSuchFieldException
    //   897	910	1243	java/lang/Exception
    //   910	942	1243	java/lang/Exception
    //   942	955	1243	java/lang/Exception
    //   955	987	1243	java/lang/Exception
    //   1209	1240	1243	java/lang/Exception
  }

  private void f()
  {
    int i1 = 1;
    int i2 = 8;
    int i3 = 0;
    this.j = i3;
    this.jdField_a_of_type_AndroidWidgetEditText.setVisibility(i3);
    this.jdField_a_of_type_AndroidWidgetEditText.setText("");
    this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i3);
    this.jdField_a_of_type_AndroidWidgetTextView.setVisibility(i2);
    this.jdField_g_of_type_AndroidWidgetImageView.setClickable(i1);
    this.jdField_g_of_type_AndroidWidgetImageView.setImageResource(2130837900);
    int i4 = this.jdField_g_of_type_AndroidWidgetImageView.getId();
    Drawable localDrawable1 = this.jdField_g_of_type_AndroidWidgetImageView.getDrawable();
    Drawable localDrawable2 = SkinEngine.getSkinDrawable(i4, "src", localDrawable1);
    this.jdField_g_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable2);
    this.jdField_c_of_type_AndroidWidgetImageView.setClickable(i1);
    this.jdField_c_of_type_AndroidWidgetImageView.setImageResource(2130837549);
    int i5 = this.jdField_c_of_type_AndroidWidgetImageView.getId();
    Drawable localDrawable3 = this.jdField_c_of_type_AndroidWidgetImageView.getDrawable();
    Drawable localDrawable4 = SkinEngine.getSkinDrawable(i5, "src", localDrawable3);
    this.jdField_c_of_type_AndroidWidgetImageView.setImageDrawable(localDrawable4);
    String str = this.jdField_a_of_type_JavaLangString;
    if ("10000".equals(str))
    {
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i2);
      this.jdField_c_of_type_AndroidWidgetLinearLayout.setVisibility(i2);
    }
    while (true)
    {
      return;
      this.jdField_a_of_type_AndroidWidgetRelativeLayout.setVisibility(i3);
      this.jdField_c_of_type_AndroidWidgetLinearLayout.setVisibility(i3);
      if (this.jdField_h_of_type_Int == i1)
        this.jdField_h_of_type_AndroidWidgetImageView.setVisibility(i2);
      this.jdField_h_of_type_AndroidWidgetImageView.setVisibility(i3);
    }
  }

  private void g()
  {
    int i1 = 2130837549;
    int i2 = 1;
    int i3 = 8;
    int i4 = 0;
    int i5 = this.j;
    Object localObject;
    if (i5 == 0)
    {
      this.jdField_a_of_type_AndroidWidgetEditText.setVisibility(i4);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i4);
      this.jdField_a_of_type_AndroidWidgetTextView.setVisibility(i3);
      this.jdField_g_of_type_AndroidWidgetImageView.setImageResource(2130837900);
      int i6 = this.jdField_g_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable1 = this.jdField_g_of_type_AndroidWidgetImageView.getDrawable();
      localObject = SkinEngine.getSkinDrawable(i6, "src", localDrawable1);
      this.jdField_g_of_type_AndroidWidgetImageView.setImageDrawable((Drawable)localObject);
      this.jdField_c_of_type_AndroidWidgetImageView.setClickable(i2);
      this.jdField_c_of_type_AndroidWidgetImageView.setImageResource(i1);
      localObject = this.jdField_c_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable2 = this.jdField_c_of_type_AndroidWidgetImageView.getDrawable();
      localObject = SkinEngine.getSkinDrawable(localObject, "src", localDrawable2);
      this.jdField_c_of_type_AndroidWidgetImageView.setImageDrawable((Drawable)localObject);
    }
    while (true)
    {
      localObject = (Button)findViewById(2131492958);
      if (((Button)localObject).getVisibility() == 0)
      {
        int i7 = ((Button)localObject).getId();
        Drawable localDrawable3 = ((Button)localObject).getBackground();
        Drawable localDrawable4 = SkinEngine.getSkinDrawable(i7, "background", localDrawable3);
        ((Button)localObject).setBackgroundDrawable(localDrawable4);
      }
      if (this.jdField_h_of_type_Int == i2)
        this.jdField_d_of_type_AndroidWidgetImageView.setImageResource(2130837918);
      return;
      this.jdField_a_of_type_AndroidWidgetEditText.setVisibility(i3);
      this.jdField_a_of_type_AndroidWidgetButton.setVisibility(i3);
      this.jdField_a_of_type_AndroidWidgetTextView.setVisibility(i4);
      this.jdField_g_of_type_AndroidWidgetImageView.setImageResource(2130837902);
      localObject = this.jdField_g_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable5 = this.jdField_g_of_type_AndroidWidgetImageView.getDrawable();
      localObject = SkinEngine.getSkinDrawable(localObject, "src", localDrawable5);
      this.jdField_g_of_type_AndroidWidgetImageView.setImageDrawable((Drawable)localObject);
      this.jdField_c_of_type_AndroidWidgetImageView.setClickable(i4);
      this.jdField_c_of_type_AndroidWidgetImageView.setImageResource(i1);
      localObject = this.jdField_c_of_type_AndroidWidgetImageView.getId();
      Drawable localDrawable6 = this.jdField_c_of_type_AndroidWidgetImageView.getDrawable();
      localObject = SkinEngine.getSkinDrawable(localObject, "disclickable", localDrawable6);
      this.jdField_c_of_type_AndroidWidgetImageView.setImageDrawable((Drawable)localObject);
    }
  }

  private static WindowManager.LayoutParams getWinLayParams(int paramInt)
  {
    WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams(-1, -1);
    localLayoutParams.dimAmount = 1056964608;
    localLayoutParams.flags = 8;
    int i1 = localLayoutParams.flags | 0x40000;
    localLayoutParams.flags = i1;
    int i2 = localLayoutParams.flags | 0x200;
    localLayoutParams.flags = i2;
    localLayoutParams.type = 2003;
    localLayoutParams.width = -1;
    localLayoutParams.height = -1;
    localLayoutParams.gravity = 17;
    localLayoutParams.format = -1;
    return localLayoutParams;
  }

  private void h()
  {
    if (this.jdField_a_of_type_ComTencentMobileqqVideoVideoController == null)
    {
      VideoController localVideoController1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = localVideoController1;
    }
    VideoController localVideoController2 = this.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
    String str = this.jdField_a_of_type_JavaLangString;
    if ((!localVideoController2.a(str)) && (this.jdField_h_of_type_Int == 0))
      this.jdField_h_of_type_AndroidWidgetImageView.setVisibility(0);
    while (true)
    {
      return;
      this.jdField_h_of_type_AndroidWidgetImageView.setVisibility(8);
    }
  }

  private static boolean isOffline(int paramInt1, int paramInt2)
  {
    int i1 = 1;
    Object localObject = null;
    int i2;
    if ((paramInt1 != 10) && (paramInt1 != 11) && (((paramInt1 != 20) || (paramInt2 != i1))))
      i2 = i1;
    return i2;
  }

  private static Bitmap makeSrc(int paramInt1, int paramInt2, int paramInt3)
  {
    Bitmap.Config localConfig = Bitmap.Config.ARGB_8888;
    Bitmap localBitmap = Bitmap.createBitmap(paramInt1, paramInt2, localConfig);
    Canvas localCanvas = new Canvas(localBitmap);
    Paint localPaint = new Paint(1);
    localPaint.setColor(-9189889);
    float f1 = paramInt1;
    float f2 = paramInt2;
    float f3 = null;
    localCanvas.drawRect(null, f3, f1, f2, localPaint);
    return localBitmap;
  }

  public final void a()
  {
    int i1 = 0;
    Drawable localDrawable1 = null;
    int i2 = this.jdField_c_of_type_JavaLangString.length();
    Object localObject;
    if (i2 > 0)
    {
      i2 = this.y;
      if (i2 != 0)
        break label129;
      Drawable localDrawable2 = getResources().getDrawable(2130838036);
      i2 = localDrawable2.getMinimumWidth();
      int i5 = localDrawable2.getMinimumHeight();
      localDrawable2.setBounds(i1, i1, i2, i5);
      localObject = (Button)this.jdField_b_of_type_AndroidViewView;
      ((Button)localObject).setCompoundDrawables(localDrawable2, localDrawable1, localDrawable1, localDrawable1);
    }
    while (true)
    {
      this.jdField_b_of_type_AndroidViewView = localDrawable1;
      this.jdField_c_of_type_JavaLangString = "";
      this.y = -1;
      localObject = this.jdField_a_of_type_Cb;
      if (((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder == null)
      {
        Recorder localRecorder = new Recorder();
        ((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder = localRecorder;
      }
      ((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder.b();
      return;
      label129: int i3 = this.y;
      if (i3 != 1)
        continue;
      Drawable localDrawable3 = getResources().getDrawable(2130837933);
      int i4 = localDrawable3.getMinimumWidth();
      int i6 = localDrawable3.getMinimumHeight();
      localDrawable3.setBounds(i1, i1, i4, i6);
      Button localButton = (Button)this.jdField_b_of_type_AndroidViewView;
      localButton.setCompoundDrawables(localDrawable3, localDrawable1, localDrawable1, localDrawable1);
    }
  }

  public final void a(int paramInt)
  {
    Bitmap localBitmap1 = BitmapFactory.decodeResource(getResources(), 2130837563);
    int i1 = this.jdField_f_of_type_Int;
    Bitmap.Config localConfig1 = Bitmap.Config.ARGB_8888;
    Bitmap localBitmap2 = Bitmap.createBitmap(i1, paramInt, localConfig1);
    Canvas localCanvas1 = new Canvas(localBitmap2);
    Paint localPaint1 = new Paint(1);
    localPaint1.setColor(-9189889);
    float f1 = i1;
    float f2 = paramInt;
    float f3 = null;
    localCanvas1.drawRect(null, f3, f1, f2, localPaint1);
    int i2 = this.jdField_f_of_type_Int;
    int i3 = this.jdField_f_of_type_Int;
    Bitmap.Config localConfig2 = Bitmap.Config.ARGB_8888;
    Bitmap localBitmap3 = Bitmap.createBitmap(i2, i3, localConfig2);
    Canvas localCanvas2 = new Canvas(localBitmap3);
    Paint localPaint2 = new Paint(1);
    localCanvas2.drawBitmap(localBitmap1, null, null, localPaint2);
    PorterDuff.Mode localMode = PorterDuff.Mode.SRC_IN;
    PorterDuffXfermode localPorterDuffXfermode = new PorterDuffXfermode(localMode);
    localPaint2.setXfermode(localPorterDuffXfermode);
    float f4 = this.jdField_f_of_type_Int - paramInt;
    localCanvas2.drawBitmap(localBitmap2, null, f4, localPaint2);
    this.jdField_b_of_type_AndroidWidgetImageView.setImageBitmap(localBitmap3);
  }

  public final void a(UnreadMsgFriendInfo paramUnreadMsgFriendInfo)
  {
    int i1 = 1108869120;
    int i2 = 1065353216;
    float f1 = null;
    int i3 = 8;
    int i4 = 0;
    this.jdField_a_of_type_AndroidWidgetLinearLayout.setVisibility(i4);
    this.jdField_f_of_type_AndroidWidgetImageView.setVisibility(i4);
    this.jdField_b_of_type_AndroidWidgetLinearLayout.setVisibility(i3);
    this.jdField_d_of_type_AndroidWidgetImageView.setVisibility(i3);
    int i5 = paramUnreadMsgFriendInfo.type;
    Friends localFriends;
    label141: label192: String str6;
    if (i5 == 0)
    {
      EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
      String str1 = paramUnreadMsgFriendInfo.uin;
      localFriends = (Friends)localEntityManager.a(Friends.class, str1);
      if (localFriends == null)
        if (paramUnreadMsgFriendInfo.uin.equals("10000"))
        {
          ImageView localImageView1 = this.jdField_e_of_type_AndroidWidgetImageView;
          Drawable localDrawable1 = getResources().getDrawable(2130838047);
          localImageView1.setImageDrawable(localDrawable1);
          localEntityManager.a();
          TextView localTextView1 = this.jdField_c_of_type_AndroidWidgetTextView;
          StringBuilder localStringBuilder1 = new StringBuilder();
          String str2 = paramUnreadMsgFriendInfo.nick;
          String str3 = str2 + ":";
          localTextView1.setText(localEntityManager);
          float f2 = this.jdField_a_of_type_Float / 1067030938;
          String str4 = paramUnreadMsgFriendInfo.lastMsg;
          SpannableString localSpannableString = EmoWindow.toShownEmoSpanMsg(this, f2, str4);
          this.jdField_b_of_type_AndroidWidgetTextView.setText(localSpannableString);
          if (paramUnreadMsgFriendInfo.unReadNum <= 1)
            break label593;
          TextView localTextView2 = this.jdField_d_of_type_AndroidWidgetTextView;
          StringBuilder localStringBuilder2 = new StringBuilder().append("(");
          int i6 = paramUnreadMsgFriendInfo.unReadNum;
          String str5 = i6 + ")";
          localTextView2.setText(str5);
          this.jdField_d_of_type_AndroidWidgetTextView.setVisibility(i4);
          label296: if (this.jdField_f_of_type_JavaLangString != null)
            break label605;
          LinearLayout localLinearLayout1 = this.jdField_b_of_type_AndroidWidgetLinearLayout;
          a(localLinearLayout1, i2, f1);
          ImageView localImageView2 = this.jdField_d_of_type_AndroidWidgetImageView;
          a(localImageView2, i2, f1);
          ImageView localImageView3 = this.jdField_f_of_type_AndroidWidgetImageView;
          a(localImageView3, f1, i2);
          LinearLayout localLinearLayout2 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
          float f3 = this.jdField_a_of_type_Float * i1;
          a(localLinearLayout2, f3);
          str6 = this.jdField_g_of_type_JavaLangString;
        }
    }
    label593: label605: String str12;
    for (this.jdField_f_of_type_JavaLangString = str6; ; this.jdField_f_of_type_JavaLangString = str12)
    {
      String str10;
      String str11;
      do
      {
        ((GridView)findViewById(2131493076)).setVisibility(i3);
        findViewById(2131493075).setVisibility(i4);
        this.jdField_c_of_type_AndroidOsHandler.removeMessages(3);
        return;
        ImageView localImageView4 = this.jdField_e_of_type_AndroidWidgetImageView;
        Drawable localDrawable2 = getResources().getDrawable(2130837749);
        localImageView4.setImageDrawable(localDrawable2);
        break label141:
        QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
        int i7 = localFriends.faceid;
        String str7 = localFriends.uin;
        int i8 = localFriends.status;
        int i9 = localFriends.sqqOnLineState;
        boolean bool = isOffline(i8, localFriends);
        Drawable localDrawable3 = localQQApplication.a(i7, str7, localFriends, i4);
        this.jdField_e_of_type_AndroidWidgetImageView.setImageDrawable(localFriends);
        break label141:
        ImageView localImageView5 = this.jdField_e_of_type_AndroidWidgetImageView;
        Drawable localDrawable4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.getResources().getDrawable(2130837734);
        localImageView5.setImageDrawable(localDrawable4);
        TextView localTextView3 = this.jdField_c_of_type_AndroidWidgetTextView;
        StringBuilder localStringBuilder3 = new StringBuilder();
        String str8 = paramUnreadMsgFriendInfo.lastMemberNick;
        String str9 = str8 + ":";
        localTextView3.setText(str9);
        break label192:
        this.jdField_d_of_type_AndroidWidgetTextView.setVisibility(i3);
        break label296:
        str10 = this.jdField_g_of_type_JavaLangString;
        str11 = this.jdField_f_of_type_JavaLangString;
      }
      while (str10.equals(str11));
      LinearLayout localLinearLayout3 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
      float f4 = this.jdField_a_of_type_Float * i1;
      a(localLinearLayout3, f4);
      str12 = this.jdField_g_of_type_JavaLangString;
    }
  }

  public final void a(String paramString, int paramInt)
  {
    Intent localIntent = new Intent(this, ChatHistory.class);
    localIntent.addFlags(536870912);
    localIntent.putExtra("uin", paramString);
    localIntent.putExtra("uin type", paramInt);
    startActivityForResult(localIntent, 0);
  }

  public final void a(String paramString, View paramView, int paramInt)
  {
    int i1 = this.jdField_c_of_type_JavaLangString.length();
    if (i1 > 0)
    {
      boolean bool = this.jdField_c_of_type_JavaLangString.equals(paramString);
      if (!bool)
      {
        localObject = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
        ((ChatMessageListAdapter)localObject).notifyDataSetChanged();
      }
    }
    String str1 = "view: " + paramView;
    Log.v("gene", str1);
    Object localObject = this.jdField_a_of_type_Cb;
    if (((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder == null)
    {
      Recorder localRecorder1 = new Recorder();
      ((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder = localRecorder1;
    }
    access$202(((cb)localObject).jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity, paramView);
    ((cb)localObject).jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.jdField_c_of_type_JavaLangString = paramString;
    StringBuilder localStringBuilder = new StringBuilder().append("mpptView = ");
    int i2 = access$200(((cb)localObject).jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).hashCode();
    String str2 = i2;
    Log.d("gene", str2);
    access$302(((cb)localObject).jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity, paramInt);
    ((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder.b(paramString);
    Recorder localRecorder2 = ((cb)localObject).jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
    ChatWindowActivity.UpdataPlayPttStateListener localUpdataPlayPttStateListener = ((cb)localObject).jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$UpdataPlayPttStateListener;
    localRecorder2.a((ChatWindowActivity.UpdataPlayPttStateListener)localObject);
  }

  public final void a(String paramString1, String paramString2, int paramInt)
  {
    int i1 = 1;
    StorageMessage localStorageMessage = new StorageMessage();
    if (paramInt == i1);
    while (true)
    {
      String str1 = StorageMessage.getDBTableName(paramString2, i1);
      StorageManager localStorageManager = StorageManager.instance(paramString1);
      SQLiteDatabase localSQLiteDatabase = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str2 = String.valueOf(100);
      localStorageManager.a(i1, localStorageMessage, localSQLiteDatabase, str2);
      return;
      Object localObject = null;
    }
  }

  protected final boolean a()
  {
    Object localObject1 = 1;
    boolean bool = this.jdField_a_of_type_Boolean;
    if (bool)
    {
      localObject2 = getParent();
      if ((localObject2 != null) && (((Activity)localObject2).moveTaskToBack(null)))
        this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a((Context)localObject2);
    }
    for (Object localObject2 = localObject1; ; localObject2 = localObject1)
    {
      return localObject2;
      localObject2 = new Intent(this, HomeActivity.class).setFlags(67108864).addCategory("android.intent.category.CONTACT").addFlags(536870912);
      startActivity((Intent)localObject2);
    }
  }

  public final boolean a(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("curp: ");
    String str1 = this.jdField_c_of_type_JavaLangString;
    String str2 = str1 + " ptt: " + paramString;
    Log.v("chaos", str2);
    boolean bool = this.jdField_c_of_type_JavaLangString.equals(paramString);
    int i1;
    if (bool)
      i1 = 1;
    while (true)
    {
      return i1;
      Object localObject = null;
    }
  }

  public final void b()
  {
    int i1 = 0;
    int i2 = 0;
    int i3 = 1;
    Object localObject1 = new StringBuilder().append("start mppt");
    View localView = this.jdField_b_of_type_AndroidViewView;
    localObject1 = localView;
    Log.v("gene", (String)localObject1);
    this.jdField_b_of_type_Boolean = i3;
    this.jdField_a_of_type_AndroidWidgetTextView.setText("鏉惧");
    Object localObject2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
    int i4 = 2;
    localObject2 = TransFileProcessor.getTransferFilePath((String)localObject2, i2, i4, i2);
    this.jdField_b_of_type_JavaLangString = ((String)localObject2);
    localObject2 = this.jdField_a_of_type_Cb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
    if (localObject2 != null)
    {
      localObject2 = this.jdField_a_of_type_Cb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder.a();
      if (localObject2 != 0)
      {
        localObject2 = this.jdField_c_of_type_JavaLangString.length();
        if (localObject2 > 0)
        {
          this.jdField_b_of_type_AndroidViewView = i2;
          this.jdField_c_of_type_JavaLangString = "";
          this.y = -1;
          localObject2 = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
          ((ChatMessageListAdapter)localObject2).notifyDataSetChanged();
        }
      }
    }
    cb localcb = this.jdField_a_of_type_Cb;
    localObject2 = this.jdField_b_of_type_JavaLangString;
    if (Environment.getExternalStorageState().equals("mounted"))
    {
      String str = Environment.getExternalStorageDirectory().getAbsolutePath();
      if (new StatFs(str).getAvailableBlocks() > i3)
      {
        if (localcb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder == null)
        {
          Recorder localRecorder1 = new Recorder();
          localcb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder = localRecorder1;
          Recorder localRecorder2 = localcb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
          cc localcc = new cc(localcb);
          localRecorder2.a(localcc);
        }
        localcb.jdField_a_of_type_ComTencentMobileqqUtilsRecorder.a((String)localObject2);
        if (localcb.jdField_a_of_type_AndroidOsPowerManager$WakeLock == null)
        {
          PowerManager.WakeLock localWakeLock = ((PowerManager)localcb.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getSystemService("power")).newWakeLock(6, "SoundRecorder");
          localcb.jdField_a_of_type_AndroidOsPowerManager$WakeLock = localWakeLock;
          localcb.jdField_a_of_type_AndroidOsPowerManager$WakeLock.acquire();
        }
      }
    }
    while (true)
    {
      this.jdField_b_of_type_AndroidOsHandler.sendEmptyMessageDelayed(i3, 400L);
      this.jdField_b_of_type_AndroidOsHandler.sendEmptyMessageDelayed(i1, -5536L);
      return;
      Toast.makeText(localcb.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity, "sdcard涓�", i1).show();
    }
  }

  public final void b(String paramString, int paramInt)
  {
    String str1 = this.jdField_a_of_type_JavaLangString;
    this.jdField_e_of_type_JavaLangString = str1;
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_h_of_type_Int = paramInt;
    String str2 = this.jdField_a_of_type_JavaLangString;
    int i1 = this.jdField_h_of_type_Int;
    d(str2, i1);
    c(paramString, paramInt);
    String str3 = this.jdField_a_of_type_JavaLangString;
    int i2 = this.jdField_h_of_type_Int;
    a(str3, i2, true);
    f();
    EntityManager localEntityManager = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    String str4 = this.jdField_a_of_type_JavaLangString;
    localEntityManager.a(VideoAbility.class, str4);
    localEntityManager.a();
    Intent localIntent1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1];
    String str5 = this.jdField_h_of_type_JavaLangString;
    localIntent1.putExtra("uin", str5);
    Intent localIntent2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1];
    int i3 = this.i;
    localIntent2.putExtra("uin type", i3);
  }

  public final void c()
  {
    int i1 = 3;
    long l1 = 0L;
    int i2 = 0;
    int i4 = 1;
    int i5 = 0;
    boolean bool = this.jdField_b_of_type_AndroidOsHandler.hasMessages(i5);
    if (bool)
    {
      localObject2 = this.jdField_b_of_type_AndroidOsHandler;
      ((Handler)localObject2).removeMessages(i5);
    }
    Object localObject2 = this.jdField_a_of_type_AndroidWidgetTextView;
    Object localObject3 = "鎸変";
    ((TextView)localObject2).setText((CharSequence)localObject3);
    localObject2 = this.jdField_a_of_type_AndroidViewWindowManager;
    if (localObject2 != null)
    {
      localObject2 = this.jdField_a_of_type_AndroidWidgetImageView;
      if (localObject2 != null)
      {
        localObject2 = this.jdField_a_of_type_AndroidViewWindowManager;
        localObject3 = this.jdField_a_of_type_AndroidWidgetImageView;
        ((WindowManager)localObject2).removeViewImmediate((View)localObject3);
        this.jdField_a_of_type_AndroidWidgetImageView = i2;
        this.jdField_a_of_type_AndroidViewWindowManager = i2;
      }
    }
    localObject2 = this.jdField_a_of_type_AndroidOsHandler;
    if (localObject2 != null)
    {
      localObject2 = this.jdField_a_of_type_AndroidOsHandler;
      ((Handler)localObject2).removeMessages(i5);
    }
    localObject2 = this.jdField_a_of_type_Cb;
    localObject3 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
    if (localObject3 != null);
    label174: int i3;
    for (localObject2 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder.a(); ; localObject2 = i3)
    {
      if (localObject2 == 0)
        return;
      localObject2 = this.jdField_a_of_type_Cb;
      localObject3 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
      if (localObject3 != null)
      {
        localObject3 = ((cb)localObject2).jdField_a_of_type_AndroidOsPowerManager$WakeLock;
        if (localObject3 != null)
        {
          localObject3 = ((cb)localObject2).jdField_a_of_type_AndroidOsPowerManager$WakeLock.isHeld();
          if (localObject3 != 0)
          {
            localObject3 = ((cb)localObject2).jdField_a_of_type_AndroidOsPowerManager$WakeLock;
            ((PowerManager.WakeLock)localObject3).release();
          }
        }
        localObject2 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
        ((Recorder)localObject2).a();
      }
      localObject2 = this.jdField_a_of_type_Cb;
      localObject3 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
      if (localObject3 != null)
        localObject2 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder.a();
      while (true)
      {
        long l2 = 1600L;
        Object localObject4;
        localObject4 <= l2;
        if (localObject2 < 0)
        {
          localObject2 = this.jdField_a_of_type_Cb;
          if (((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder != null)
          {
            localObject2 = ((cb)localObject2).jdField_a_of_type_ComTencentMobileqqUtilsRecorder.a();
            if ((localObject2 != null) && (((File)localObject2).exists()))
              ((File)localObject2).delete();
          }
          Toast.makeText(this, "鎸夐敭�", i5).show();
        }
        localObject2 = this.jdField_b_of_type_JavaLangString;
        localObject3 = this.jdField_a_of_type_JavaLangString;
        label547: long l5;
        if (localObject2 != null)
        {
          Object localObject1 = new byte[i1];
          int i6 = ((String)localObject2).length();
          String str1 = "utf-8";
          PkgTools.intToAscString(i6, localObject1, i5, i1, str1);
          String str2 = TransfileUtile.makeTransFileProtocolData((String)localObject2, l1, 2, i4);
          localObject2 = new StorageMessage();
          localObject1 = ((StorageMessage)localObject2).a;
          String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
          ((MessageRecordInfo)localObject1).jdField_a_of_type_JavaLangString = str3;
          ((StorageMessage)localObject2).a.jdField_b_of_type_JavaLangString = ((String)localObject3);
          localObject3 = ((StorageMessage)localObject2).a;
          localObject1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
          ((MessageRecordInfo)localObject3).jdField_c_of_type_JavaLangString = ((String)localObject1);
          ((StorageMessage)localObject2).a.jdField_d_of_type_JavaLangString = str2;
          localObject3 = ((StorageMessage)localObject2).a;
          i3 = (int)(System.currentTimeMillis() / 1000L);
          ((MessageRecordInfo)localObject3).jdField_a_of_type_Int = i3;
          ((StorageMessage)localObject2).a.jdField_a_of_type_Boolean = i4;
          ((StorageMessage)localObject2).a.jdField_b_of_type_Boolean = i4;
          localObject3 = ((StorageMessage)localObject2).a;
          i3 = this.jdField_h_of_type_Int;
          if (i3 == i4)
          {
            i3 = i4;
            ((MessageRecordInfo)localObject3).jdField_c_of_type_Boolean = i3;
            long l4 = StorageManager.instance(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).a((Storageable)localObject2);
            BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            String str4 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
            int i7 = this.jdField_h_of_type_Int;
            str1 = this.jdField_a_of_type_JavaLangString;
            MessageUtil.sendSaveFileMsg((BaseServiceHelper)localObject2, (BaseActionListener)localObject3, i3, i7, str1, str2);
            Object localObject5;
            l5 = localObject5;
          }
        }
        while (true)
        {
          String str5 = this.jdField_a_of_type_JavaLangString;
          int i8 = this.jdField_h_of_type_Int;
          a(str5, i8, i4);
          if (this.jdField_h_of_type_Int == i4)
          {
            TransFileController localTransFileController1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            String str6 = this.jdField_a_of_type_JavaLangString;
            String str7 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
            String str8 = this.jdField_b_of_type_JavaLangString;
            localTransFileController1.a(str6, str7, str8, l5);
          }
          while (true)
          {
            this.jdField_b_of_type_JavaLangString = "";
            this = (Button)this.jdField_a_of_type_AndroidViewView.findViewById(2131492958);
            if (super.getVisibility() == 8);
            super.setVisibility(i5);
            break label174:
            i3 = i5;
            break label547:
            TransFileController localTransFileController2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
            String str9 = this.jdField_a_of_type_JavaLangString;
            String str10 = this.jdField_b_of_type_JavaLangString;
            localTransFileController2.d(str9, str10, l5);
          }
          l5 = l1;
        }
        long l3 = l1;
      }
    }
  }

  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getAction();
    if (i1 != 3)
    {
      i1 = paramMotionEvent.getAction();
      if (i1 != 1)
      {
        i1 = paramMotionEvent.getAction();
        if (i1 == 4);
      }
    }
    Object localObject;
    for (boolean bool = super.dispatchTouchEvent(paramMotionEvent); ; localObject = super.dispatchTouchEvent(paramMotionEvent))
    {
      while (true)
      {
        return bool;
        localObject = new Rect();
        this.jdField_a_of_type_AndroidWidgetButton.getGlobalVisibleRect((Rect)localObject);
        int i2 = (int)paramMotionEvent.getRawX();
        int i3 = (int)paramMotionEvent.getRawY();
        if (!((Rect)localObject).contains(i2, i3))
          break;
        localObject = super.dispatchTouchEvent(paramMotionEvent);
      }
      this.jdField_a_of_type_AndroidWidgetEditText.getGlobalVisibleRect((Rect)localObject);
      int i4 = (int)paramMotionEvent.getRawX();
      int i5 = (int)paramMotionEvent.getRawY();
      localObject = ((Rect)localObject).contains(i4, i5);
      if (localObject != 0)
        continue;
      localObject = (InputMethodManager)getSystemService("input_method");
      IBinder localIBinder = getWindow().peekDecorView().getWindowToken();
      ((InputMethodManager)localObject).hideSoftInputFromWindow(localIBinder, 0);
    }
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    int i1 = 1;
    int i2 = -1;
    String str1 = null;
    boolean bool = null;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt2 == i2)
      switch (paramInt1)
      {
      default:
      case 100:
      case 0:
      case 1:
      case 2:
      case 10:
      case 4:
      case 11:
      case 101:
      case 20:
      }
    while (true)
    {
      label108: return;
      if (this.jdField_h_of_type_Int != 0)
        continue;
      String str2 = this.jdField_a_of_type_JavaLangString;
      int i3 = this.jdField_h_of_type_Int;
      d(str2, i3);
      continue;
      String str3 = this.jdField_a_of_type_JavaLangString;
      int i4 = this.jdField_h_of_type_Int;
      a(str3, i4, bool);
      continue;
      if (paramIntent != null)
      {
        localObject1 = paramIntent.getData();
        if (localObject1 != null)
          break label185;
      }
      Object localObject1 = this.jdField_a_of_type_AndroidNetUri;
      label185: Object localObject2 = ImageUtil.getRealPathFromContentURI(this, (Uri)localObject1);
      if (localObject2 != null)
      {
        localObject2 = new File((String)localObject2).exists();
        if (localObject2 == 0)
          Toast.makeText(this, "鍥剧�", bool).show();
      }
      localObject2 = new Intent(this, PhotoPreview.class);
      if (paramInt1 == i1)
        ((Intent)localObject2).setData((Uri)localObject1);
      while (true)
      {
        ((Intent)localObject2).putExtra("requestType", paramInt1);
        String str4 = this.jdField_a_of_type_JavaLangString;
        ((Intent)localObject2).putExtra("friendUin", str4);
        int i5 = this.jdField_h_of_type_Int;
        ((Intent)localObject2).putExtra("curType", i5);
        ((Intent)localObject2).setFlags(67108864);
        if (paramInt1 != 10)
          break;
        startActivityForResult((Intent)localObject2, 11);
        break label108:
        Uri localUri = paramIntent.getData();
        ((Intent)localObject2).setData(localUri);
      }
      startActivityForResult((Intent)localObject2, 4);
      continue;
      localObject1 = paramIntent.getExtras().getBoolean("phototodoodle", bool);
      if (localObject1 != 0)
      {
        String str5 = paramIntent.getExtras().getString("photofilepath");
        int i6 = paramIntent.getExtras().getInt("rotation");
        a(bool, str5, i6);
      }
      localObject1 = (Button)this.jdField_a_of_type_AndroidViewView.findViewById(2131492958);
      if (((Button)localObject1).getVisibility() == 8)
        ((Button)localObject1).setVisibility(bool);
      if (this.jdField_h_of_type_Int == 0)
        c(paramIntent);
      while (true)
      {
        ChatMessageListAdapter localChatMessageListAdapter = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
        String str6 = this.jdField_a_of_type_JavaLangString;
        int i7 = this.jdField_h_of_type_Int;
        localChatMessageListAdapter.a(str6, i7, i1);
        break label108:
        TransFileController localTransFileController = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str7 = this.jdField_a_of_type_JavaLangString;
        String str8 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
        String str9 = paramIntent.getExtras().getString("filePath");
        long l1 = paramIntent.getExtras().getLong("fileId");
        Object localObject3;
        localTransFileController.a(str7, str8, str9, localObject3);
      }
      a(paramIntent);
      continue;
      localObject1 = paramIntent.getExtras().getBoolean("phototodoodle", bool);
      if (localObject1 != 0)
      {
        String str10 = paramIntent.getExtras().getString("photofilepath");
        int i8 = paramIntent.getExtras().getInt("rotation");
        a(bool, str10, i8);
      }
      localObject1 = paramIntent.getExtras().getInt("requestType", i2);
      if (localObject1 == 12)
      {
        localObject1 = QQApplication.createEntityManagerFactory(this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString).createEntityManager();
        String str11 = str1;
        String str12 = str1;
        String str13 = str1;
        localObject1 = ((EntityManager)localObject1).a(CustomEmotionData.class, str1, str11, str12, str13);
        if (localObject1 != null)
          break label731;
      }
      for (localObject1 = bool; ; localObject1 = ((List)localObject1).size())
      {
        this.v = ((I)localObject1);
        a(paramIntent);
        Toast.makeText(this, "宸叉坊鍔�", bool).show();
        this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter.getCursor().requery();
        label731: break label108:
      }
      getWindow().clearFlags(1024);
      continue;
      this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter.getCursor().requery();
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    int i1 = 0;
    this.jdField_c_of_type_Boolean = true;
    if ((this.jdField_a_of_type_AndroidViewWindowManager != null) && (this.jdField_a_of_type_AndroidWidgetImageView != null))
      c();
    super.onConfigurationChanged(paramConfiguration);
    a();
    if ((this.jdField_a_of_type_AndroidAppDialog != null) && (this.jdField_a_of_type_AndroidAppDialog.isShowing()))
      e();
    if (paramConfiguration.orientation != 2)
      return;
    InputMethodManager localInputMethodManager = (InputMethodManager)getSystemService("input_method");
    IBinder localIBinder = getWindow().peekDecorView().getWindowToken();
    localInputMethodManager.hideSoftInputFromWindow(localIBinder, i1);
    if (this.jdField_a_of_type_JavaLangString.equals("10000"))
      return;
    this.jdField_c_of_type_AndroidWidgetLinearLayout.setVisibility(i1);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903056);
    ce localce = new ce(this, this);
    this.jdField_a_of_type_Ce = localce;
    LayoutInflater localLayoutInflater = (LayoutInflater)getSystemService("layout_inflater");
    findViewById(2131492978);
    ChatWindowActivity.MessageListView localMessageListView1 = (ChatWindowActivity.MessageListView)findViewById(2131492978);
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$MessageListView = localMessageListView1;
    View localView1 = localLayoutInflater.inflate(2130903054, null);
    this.jdField_a_of_type_AndroidViewView = localView1;
    ChatWindowActivity.MessageListView localMessageListView2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$MessageListView;
    View localView2 = this.jdField_a_of_type_AndroidViewView;
    localMessageListView2.addHeaderView(localView2);
    Handler localHandler1 = this.jdField_c_of_type_AndroidOsHandler;
    ChatMessageListAdapter localChatMessageListAdapter1 = new ChatMessageListAdapter(this, localHandler1);
    this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter = localChatMessageListAdapter1;
    ChatWindowActivity.MessageListView localMessageListView3 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$MessageListView;
    ChatMessageListAdapter localChatMessageListAdapter2 = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
    localMessageListView3.setAdapter(localChatMessageListAdapter2);
    ChatWindowActivity.MessageListView localMessageListView4 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$MessageListView;
    ax localax = new ax(this);
    localMessageListView4.setOnSizeChangedListener(localax);
    Button localButton1 = (Button)this.jdField_a_of_type_AndroidViewView.findViewById(2131492958);
    ay localay = new ay(this);
    localButton1.setOnClickListener(localay);
    Button localButton2 = (Button)findViewById(2131492988);
    this.jdField_a_of_type_AndroidWidgetButton = localButton2;
    Button localButton3 = this.jdField_a_of_type_AndroidWidgetButton;
    bb localbb = new bb(this);
    localButton3.setOnClickListener(localbb);
    EditText localEditText1 = (EditText)findViewById(2131492987);
    this.jdField_a_of_type_AndroidWidgetEditText = localEditText1;
    EditText localEditText2 = this.jdField_a_of_type_AndroidWidgetEditText;
    bc localbc = new bc(this);
    localEditText2.addTextChangedListener(localbc);
    TextView localTextView1 = (TextView)findViewById(2131492989);
    this.jdField_a_of_type_AndroidWidgetTextView = localTextView1;
    TextView localTextView2 = this.jdField_a_of_type_AndroidWidgetTextView;
    bd localbd = new bd(this);
    localTextView2.setOnLongClickListener(localbd);
    TextView localTextView3 = this.jdField_a_of_type_AndroidWidgetTextView;
    be localbe = new be(this);
    localTextView3.setOnTouchListener(localbe);
    LinearLayout localLinearLayout1 = (LinearLayout)findViewById(2131492977);
    this.jdField_a_of_type_AndroidWidgetLinearLayout = localLinearLayout1;
    ImageView localImageView1 = (ImageView)findViewById(2131493016);
    this.jdField_e_of_type_AndroidWidgetImageView = localImageView1;
    TextView localTextView4 = (TextView)findViewById(2131493017);
    this.jdField_c_of_type_AndroidWidgetTextView = localTextView4;
    TextView localTextView5 = (TextView)findViewById(2131493018);
    this.jdField_b_of_type_AndroidWidgetTextView = localTextView5;
    TextView localTextView6 = (TextView)findViewById(2131493019);
    this.jdField_d_of_type_AndroidWidgetTextView = localTextView6;
    ImageView localImageView2 = (ImageView)findViewById(2131492976);
    this.jdField_f_of_type_AndroidWidgetImageView = localImageView2;
    LinearLayout localLinearLayout2 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
    az localaz = new az(this);
    localLinearLayout2.setOnClickListener(localaz);
    ((ImageView)findViewById(2131493078)).setVisibility(4);
    LinearLayout localLinearLayout3 = (LinearLayout)findViewById(2131492990);
    this.jdField_c_of_type_AndroidWidgetLinearLayout = localLinearLayout3;
    RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(2131492985);
    this.jdField_a_of_type_AndroidWidgetRelativeLayout = localRelativeLayout;
    ImageView localImageView3 = (ImageView)findViewById(2131492992);
    bt localbt = new bt(this);
    localImageView3.setOnClickListener(localbt);
    ImageView localImageView4 = (ImageView)findViewById(2131492993);
    bu localbu = new bu(this);
    localImageView4.setOnClickListener(localbu);
    ImageView localImageView5 = (ImageView)findViewById(2131492994);
    bv localbv = new bv(this);
    localImageView5.setOnClickListener(localbv);
    ImageView localImageView6 = (ImageView)findViewById(2131492991);
    this.jdField_c_of_type_AndroidWidgetImageView = localImageView6;
    ImageView localImageView7 = this.jdField_c_of_type_AndroidWidgetImageView;
    bw localbw = new bw(this);
    localImageView7.setOnClickListener(localbw);
    ImageView localImageView8 = (ImageView)findViewById(2131492986);
    this.jdField_g_of_type_AndroidWidgetImageView = localImageView8;
    ImageView localImageView9 = this.jdField_g_of_type_AndroidWidgetImageView;
    bx localbx = new bx(this);
    localImageView9.setOnClickListener(localbx);
    ImageView localImageView10 = (ImageView)findViewById(2131492995);
    this.jdField_h_of_type_AndroidWidgetImageView = localImageView10;
    ImageView localImageView11 = this.jdField_h_of_type_AndroidWidgetImageView;
    by localby = new by(this);
    localImageView11.setOnClickListener(localby);
    Intent localIntent = getIntent();
    b(localIntent);
    cb localcb = new cb(this);
    this.jdField_a_of_type_Cb = localcb;
    QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication1.a(localBaseActionListener);
    int i1 = getResources().getDisplayMetrics().density;
    this.jdField_a_of_type_Float = i1;
    QQApplication localQQApplication2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    bg localbg = new bg(this);
    localQQApplication2.jdField_b_of_type_AndroidOsHandler = localbg;
    QQApplication localQQApplication3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass = super.getClass();
    Handler localHandler2 = this.jdField_c_of_type_AndroidOsHandler;
    localQQApplication3.a(localClass, localHandler2);
    bs localbs = new bs(this);
    this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity$UpdataPlayPttStateListener = localbs;
    VideoController localVideoController = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    this.jdField_a_of_type_ComTencentMobileqqVideoVideoController = localVideoController;
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    int i1 = 0;
    Object localObject1 = paramView.getTag(2131493165);
    this.jdField_a_of_type_JavaLangObject = localObject1;
    localObject1 = getMenuInflater();
    paramContextMenu.setHeaderTitle(2131296273);
    if (this.jdField_a_of_type_JavaLangObject != null)
      ((MenuInflater)localObject1).inflate(2131427330, paramContextMenu);
    while (true)
    {
      return;
      Object localObject2 = paramView.getTag();
      this.jdField_a_of_type_JavaLangObject = localObject2;
      if (this.jdField_a_of_type_JavaLangObject instanceof Intent)
        ((MenuInflater)localObject1).inflate(2131427329, paramContextMenu);
      if (!this.jdField_a_of_type_JavaLangObject instanceof CharSequence)
        continue;
      paramContextMenu.add(i1, 16908321, i1, 17039361).setAlphabeticShortcut('c');
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    if (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog = null;
    }
    QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    Class localClass = super.getClass();
    localQQApplication1.a(localClass);
    QQApplication localQQApplication2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication2.b(localBaseActionListener);
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    int i1 = paramMenuItem.getItemId();
    switch (i1)
    {
    default:
    case 2131493159:
    case 2131493160:
    case 2131493161:
    case 2131493162:
    case 2131493163:
    case 2131493164:
    case 16908321:
    case 2131493158:
    case 2131493165:
    case 2131493166:
    }
    while (true)
    {
      label100: return super.onMenuItemSelected(paramInt, paramMenuItem);
      Object localObject1 = new Intent(this, InfoActivity.class);
      int i2 = this.jdField_h_of_type_Int;
      ((Intent)localObject1).putExtra("infowhose", i2);
      String str1 = this.jdField_a_of_type_JavaLangString;
      ((Intent)localObject1).putExtra("infouin", str1);
      if (this.jdField_h_of_type_Int == 0)
        startActivityForResult((Intent)localObject1, 100);
      startActivity((Intent)localObject1);
      continue;
      Intent localIntent1 = new Intent(this, SettingActivity.class);
      startActivity(localIntent1);
      continue;
      localObject1 = getParent();
      if (localObject1 != null)
        ((Activity)localObject1).finish();
      while (true)
      {
        Intent localIntent2 = new Intent(this, HomeActivity.class).putExtra("need login", true);
        startActivity(localIntent2);
        break label100:
        finish();
      }
      SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
      ScreenShotSensorEventListener localScreenShotSensorEventListener = BaseActivity.sensorEventListener;
      localSensorManager.unregisterListener(localScreenShotSensorEventListener);
      if (getParent() != null)
        getParent().finish();
      finish();
      continue;
      Intent localIntent3 = (Intent)this.jdField_a_of_type_JavaLangObject;
      String str2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      String str3 = localIntent3.getExtras().getString("friendUin");
      long l1 = localIntent3.getExtras().getLong("_id");
      StorageMessageManager localStorageMessageManager1 = new StorageMessageManager();
      int i3 = localIntent3.getExtras().getInt("type");
      Object localObject2;
      if (localStorageMessageManager1.a(str2, str3, localObject2, i3) <= 0)
        continue;
      this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter.getCursor().requery();
      continue;
      Intent localIntent4 = (Intent)this.jdField_a_of_type_JavaLangObject;
      if (this.jdField_h_of_type_Int == 0)
        c(localIntent4);
      TransFileController localTransFileController1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str4 = this.jdField_a_of_type_JavaLangString;
      String str5 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      String str6 = localIntent4.getExtras().getString("filePath");
      long l2 = localIntent4.getExtras().getLong("fileId");
      localTransFileController1.a(str4, str5, str6, localIntent4);
      continue;
      CharSequence localCharSequence = (CharSequence)this.jdField_a_of_type_JavaLangObject;
      ((ClipboardManager)getSystemService("clipboard")).setText(localCharSequence);
      continue;
      String str7 = this.jdField_a_of_type_JavaLangString;
      int i4 = this.jdField_h_of_type_Int;
      a(str7, i4);
      continue;
      Intent localIntent5 = (Intent)this.jdField_a_of_type_JavaLangObject;
      String str8 = localIntent5.getExtras().getString("filePath");
      File localFile = new File(str8);
      if (localFile.exists())
        localFile.delete();
      String str9 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
      String str10 = localIntent5.getExtras().getString("friendUin");
      long l3 = localIntent5.getExtras().getLong("_id");
      StorageMessageManager localStorageMessageManager2 = new StorageMessageManager();
      int i5 = localIntent5.getExtras().getInt("type");
      Object localObject3;
      if (localStorageMessageManager2.a(str9, str10, localObject3, localIntent5) <= 0)
        continue;
      this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter.getCursor().requery();
      continue;
      localIntent4 = (Intent)this.jdField_a_of_type_JavaLangObject;
      if (this.jdField_h_of_type_Int == 0)
      {
        TransFileController localTransFileController2 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
        String str11 = this.jdField_a_of_type_JavaLangString;
        String str12 = localIntent4.getExtras().getString("filePath");
        long l4 = localIntent4.getExtras().getLong("fileId");
        Object localObject4;
        localTransFileController2.d(str11, str12, localObject4);
      }
      TransFileController localTransFileController3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
      String str13 = this.jdField_a_of_type_JavaLangString;
      String str14 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
      String str15 = localIntent4.getExtras().getString("filePath");
      long l5 = localIntent4.getExtras().getLong("fileId");
      localTransFileController3.a(str13, str14, str15, localIntent4);
    }
  }

  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    setIntent(paramIntent);
    b(paramIntent);
  }

  protected void onPause()
  {
    super.onPause();
    a();
    getIntent().removeExtra("single");
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1].removeExtra("single");
    getIntent().removeExtra("selfuin");
    this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_ArrayOfAndroidContentIntent[1].removeExtra("selfuin");
    this.jdField_a_of_type_Boolean = null;
    String str = this.jdField_a_of_type_JavaLangString;
    this.jdField_e_of_type_JavaLangString = str;
  }

  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    paramMenu.clear();
    getMenuInflater().inflate(2131427328, paramMenu);
    MenuItem localMenuItem = paramMenu.findItem(2131493159);
    if (this.jdField_h_of_type_Int == 0)
    {
      String str1 = getString(2131296347);
      localMenuItem.setTitle(str1);
      if (this.jdField_a_of_type_JavaLangString.equals("10000"))
        localMenuItem.setEnabled(null);
    }
    while (true)
    {
      return super.onPrepareOptionsMenu(paramMenu);
      String str2 = getString(2131296346);
      localMenuItem.setTitle(str2);
    }
  }

  protected void onRestoreInstanceState(Bundle paramBundle)
  {
    int i1 = paramBundle.getInt("emoCurrentTab", 0);
    this.u = i1;
    StringBuilder localStringBuilder = new StringBuilder().append("emoTabSelect:");
    int i2 = this.u;
    String str = i2;
    QLog.v("wdc", str);
    super.onRestoreInstanceState(paramBundle);
  }

  protected void onResume()
  {
    boolean bool = true;
    int i1 = null;
    super.onResume();
    if ((this.jdField_a_of_type_AndroidAppDialog != null) && (this.jdField_a_of_type_AndroidAppDialog.isShowing()))
      e();
    this.jdField_a_of_type_AndroidWidgetEditText.clearFocus();
    this.jdField_c_of_type_AndroidWidgetImageView.requestFocus();
    this.jdField_a_of_type_AndroidWidgetEditText.setFocusableInTouchMode(bool);
    h();
    g();
    Handler localHandler = this.jdField_d_of_type_AndroidOsHandler;
    TransFileProcessor.setHandler(localHandler);
    GroupPicProcessor.setHandler(localHandler);
    BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    String str1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    String str2 = this.jdField_a_of_type_JavaLangString;
    int i2 = this.jdField_h_of_type_Int;
    MessageUtil.setMessageReaded(localBaseServiceHelper, localBaseActionListener, str1, str2, i2);
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    int i3 = this.jdField_h_of_type_Int;
    String str3 = this.jdField_a_of_type_JavaLangString;
    localQQApplication.a(i3, str3, i1);
    String str4 = this.jdField_a_of_type_JavaLangString;
    String str5 = this.jdField_e_of_type_JavaLangString;
    if (str4.equals(str5))
    {
      ChatMessageListAdapter localChatMessageListAdapter1 = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
      String str6 = this.jdField_a_of_type_JavaLangString;
      int i4 = this.jdField_h_of_type_Int;
      localChatMessageListAdapter1.a(str6, i4, i1);
    }
    while (true)
    {
      return;
      this.jdField_g_of_type_JavaLangString = null;
      this.jdField_f_of_type_JavaLangString = null;
      ChatMessageListAdapter localChatMessageListAdapter2 = this.jdField_a_of_type_ComTencentMobileqqAdapterChatMessageListAdapter;
      String str7 = this.jdField_a_of_type_JavaLangString;
      int i5 = this.jdField_h_of_type_Int;
      localChatMessageListAdapter2.a(str7, i5, bool);
    }
  }

  protected void onSaveInstanceState(Bundle paramBundle)
  {
    if (this.jdField_a_of_type_AndroidWidgetTabHost != null)
    {
      int i1 = this.jdField_a_of_type_AndroidWidgetTabHost.getCurrentTab();
      paramBundle.putInt("emoCurrentTab", i1);
      StringBuilder localStringBuilder = new StringBuilder().append("emoCurrentTab:");
      int i2 = this.jdField_a_of_type_AndroidWidgetTabHost.getCurrentTab();
      String str = i2;
      QLog.v("wdc", str);
    }
    super.onSaveInstanceState(paramBundle);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    return super.onTouchEvent(paramMotionEvent);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatWindowActivity
 * JD-Core Version:    0.5.4
 */