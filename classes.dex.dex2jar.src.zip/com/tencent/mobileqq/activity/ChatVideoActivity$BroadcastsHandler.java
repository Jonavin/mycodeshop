package com.tencent.mobileqq.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import com.tencent.mobileqq.video.VideoController;

public class ChatVideoActivity$BroadcastsHandler extends BroadcastReceiver
{
  public ChatVideoActivity$BroadcastsHandler(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i = 1;
    int j = null;
    if (paramIntent.getAction().equalsIgnoreCase("android.intent.action.HEADSET_PLUG"))
    {
      if (paramIntent.getIntExtra("state", j) != i)
        break label55;
      ChatVideoActivity.access$700(this.a).setSpeakerphoneOn(j);
      ChatVideoActivity.access$000(this.a).b(j);
    }
    while (true)
    {
      return;
      label55: ChatVideoActivity.access$700(this.a).setSpeakerphoneOn(i);
      ChatVideoActivity.access$000(this.a).b(i);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ChatVideoActivity.BroadcastsHandler
 * JD-Core Version:    0.5.4
 */