package com.tencent.mobileqq.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.tencent.mobileqq.app.AppConstants;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.FriendInfo;
import com.tencent.mobileqq.data.FriendMore;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.service.profile.ProfileUtil;
import com.tencent.qphone.base.remote.SimpleAccount;
import com.tencent.qphone.base.util.BaseActionListener;
import com.tencent.qphone.base.util.BaseServiceHelper;
import h;
import i;
import j;
import k;
import l;
import m;

public class AddRequestActivity extends BaseActivity
  implements View.OnClickListener, AppConstants
{
  public static final int DONT_NEED_VERIFY = 2;
  public static final String INFO_UIN = "infouin";
  public static final int NEED_VERIFY = 1;
  public static final String VERIFY_MSG = "verify_msg";
  public static final String VERIFY_TYPE = "verify_type";
  private int jdField_a_of_type_Int;
  private EditText jdField_a_of_type_AndroidWidgetEditText;
  private BaseActionListener jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
  private String jdField_a_of_type_JavaLangString;
  private String b;

  public AddRequestActivity()
  {
    m localm = new m(this);
    this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener = localm;
  }

  public final void a(boolean paramBoolean)
  {
    AddRequestActivity localAddRequestActivity1 = this;
    int i = 2131492889;
    Object localObject1 = (ImageView)localAddRequestActivity1.findViewById(i);
    AddRequestActivity localAddRequestActivity2 = this;
    int i2 = 2131492878;
    TextView localTextView1 = (TextView)localAddRequestActivity2.findViewById(i2);
    AddRequestActivity localAddRequestActivity3 = this;
    int i3 = 2131492890;
    TextView localTextView2 = (TextView)localAddRequestActivity3.findViewById(i3);
    AddRequestActivity localAddRequestActivity4 = this;
    int i4 = 2131492891;
    TextView localTextView3 = (TextView)localAddRequestActivity4.findViewById(i4);
    AddRequestActivity localAddRequestActivity5 = this;
    int i5 = 2131492892;
    TextView localTextView4 = (TextView)localAddRequestActivity5.findViewById(i5);
    AddRequestActivity localAddRequestActivity6 = this;
    int i6 = 2131492894;
    TextView localTextView5 = (TextView)localAddRequestActivity6.findViewById(i6);
    AddRequestActivity localAddRequestActivity7 = this;
    int i7 = 2131492897;
    RadioButton localRadioButton1 = (RadioButton)localAddRequestActivity7.findViewById(i7);
    AddRequestActivity localAddRequestActivity8 = this;
    int i8 = 2131492898;
    RadioButton localRadioButton2 = (RadioButton)localAddRequestActivity8.findViewById(i8);
    AddRequestActivity localAddRequestActivity9 = this;
    int i9 = 2131492899;
    RadioButton localRadioButton3 = (RadioButton)localAddRequestActivity9.findViewById(i9);
    AddRequestActivity localAddRequestActivity10 = this;
    int i10 = 2131492902;
    Button localButton1 = (Button)localAddRequestActivity10.findViewById(i10);
    AddRequestActivity localAddRequestActivity11 = this;
    int i11 = 2131492903;
    Button localButton2 = (Button)localAddRequestActivity11.findViewById(i11);
    EntityManager localEntityManager1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
    Object localObject3 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager2 = localEntityManager1;
    Friends localFriends1 = Friends.class;
    Object localObject4 = localObject3;
    Friends localFriends2 = (Friends)localEntityManager2.a(localFriends1, localObject4);
    String str3 = this.jdField_a_of_type_JavaLangString;
    EntityManager localEntityManager3 = localEntityManager1;
    FriendInfo localFriendInfo = FriendInfo.class;
    String str4 = str3;
    localObject3 = (FriendInfo)localEntityManager3.a(localFriendInfo, str4);
    String str5 = this.jdField_a_of_type_JavaLangString;
    localEntityManager1.a(FriendMore.class, str5);
    localEntityManager1.a();
    StringBuilder localStringBuilder1 = new StringBuilder().append("QQ:");
    String str6 = this.jdField_a_of_type_JavaLangString;
    String str7 = str6;
    TextView localTextView6 = localTextView2;
    String str8 = str7;
    localTextView6.setText(str8);
    if (localFriends2 != null)
    {
      QQApplication localQQApplication1 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
      int i12 = localFriends2.faceid;
      String str9 = this.jdField_a_of_type_JavaLangString;
      QQApplication localQQApplication2 = localQQApplication1;
      Friends localFriends3 = localFriends2;
      String str10 = str9;
      boolean bool1 = null;
      boolean bool2 = paramBoolean;
      Drawable localDrawable = localQQApplication2.a(localFriends3, str10, bool1, bool2);
      ((ImageView)localObject1).setImageDrawable(localDrawable);
    }
    if (localObject3 == null)
    {
      localTextView1.setText("鏄电");
      localTextView3.setText("鎬у");
      localObject1 = "骞撮";
      localTextView4.setText((CharSequence)localObject1);
    }
    if (localObject3 != null)
    {
      localObject1 = ((FriendInfo)localObject3).nickname;
      if (localObject1 == null)
        break label803;
      localObject1 = new StringBuilder().append("鏄�");
      String str11 = ((FriendInfo)localObject3).nickname;
      localObject1 = str11;
      localTextView1.setText((CharSequence)localObject1);
      label500: int j = ((FriendInfo)localObject3).gender;
      if (j != 1)
        break label817;
      Object localObject2 = "鎬у";
      localTextView3.setText((CharSequence)localObject2);
      label524: localObject2 = new Time("GMT+8");
      ((Time)localObject2).setToNow();
      if (((FriendInfo)localObject3).year <= 0)
        break label858;
      int k = ((Time)localObject2).year;
      int i13 = ((FriendInfo)localObject3).year;
      k -= i13;
      int l;
      if (k < 0)
        l = null;
      StringBuilder localStringBuilder2 = new StringBuilder().append("骞�");
      String str12 = String.valueOf(l);
      String str13 = l;
      localTextView4.setText(l);
    }
    if (this.jdField_a_of_type_Int == 2)
    {
      label617: AddRequestActivity localAddRequestActivity12 = this;
      int i14 = 2131492893;
      LinearLayout localLinearLayout1 = (LinearLayout)localAddRequestActivity12.findViewById(i14);
      AddRequestActivity localAddRequestActivity13 = this;
      int i15 = 2131492896;
      LinearLayout localLinearLayout2 = (LinearLayout)localAddRequestActivity13.findViewById(i15);
      AddRequestActivity localAddRequestActivity14 = this;
      int i16 = 2131492900;
      LinearLayout localLinearLayout3 = (LinearLayout)localAddRequestActivity14.findViewById(i16);
      AddRequestActivity localAddRequestActivity15 = this;
      int i17 = 2131492895;
      LinearLayout localLinearLayout4 = (LinearLayout)localAddRequestActivity15.findViewById(i17);
      LinearLayout localLinearLayout5 = localLinearLayout1;
      int i18 = 8;
      localLinearLayout5.setVisibility(i18);
      localLinearLayout2.setVisibility(8);
      localLinearLayout3.setVisibility(8);
      localLinearLayout4.setVisibility(null);
      localButton1.setText("�");
      localButton2.setText("�");
      h localh1 = new h;
      h localh2 = localh1;
      AddRequestActivity localAddRequestActivity16 = this;
      localh2.<init>(localAddRequestActivity16);
      localButton1.setOnClickListener(localh1);
      i locali1 = new i;
      i locali2 = locali1;
      AddRequestActivity localAddRequestActivity17 = this;
      locali2.<init>(localAddRequestActivity17);
      localButton2.setOnClickListener(locali1);
    }
    while (true)
    {
      return;
      label803: String str1 = "鏄电";
      localTextView1.setText(str1);
      break label500:
      label817: int i1 = ((FriendInfo)localObject3).gender;
      if (i1 == 2)
      {
        str2 = "鎬у";
        localTextView3.setText(str2);
      }
      String str2 = "鎬у";
      localTextView3.setText(str2);
      break label524:
      label858: localTextView4.setText("骞撮");
      break label617:
      String str14 = this.b;
      localTextView5.setText(str14);
      j localj1 = new j;
      j localj2 = localj1;
      AddRequestActivity localAddRequestActivity18 = this;
      localj2.<init>(localAddRequestActivity18);
      localRadioButton1.setOnClickListener(localj1);
      localRadioButton2.setOnClickListener(localj1);
      localRadioButton3.setOnClickListener(localj1);
      k localk1 = new k;
      k localk2 = localk1;
      AddRequestActivity localAddRequestActivity19 = this;
      localk2.<init>(localAddRequestActivity19);
      localButton1.setOnClickListener(localk1);
      l locall1 = new l;
      l locall2 = locall1;
      AddRequestActivity localAddRequestActivity20 = this;
      locall2.<init>(localAddRequestActivity20);
      localButton2.setOnClickListener(locall1);
    }
  }

  public void onClick(View paramView)
  {
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    String str1 = getIntent().getStringExtra("infouin");
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = getIntent().getStringExtra("verify_msg");
    this.b = str2;
    int i = getIntent().getIntExtra("verify_type", 1);
    this.jdField_a_of_type_Int = i;
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.a(localBaseActionListener);
    setContentView(2130903045);
    a(true);
    BaseServiceHelper localBaseServiceHelper = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a();
    String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    String str4 = this.jdField_a_of_type_JavaLangString;
    short[] arrayOfShort = InfoActivity.field;
    ProfileUtil.getFriendInfoReq(localBaseServiceHelper, str3, true, str4, arrayOfShort);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication;
    BaseActionListener localBaseActionListener = this.jdField_a_of_type_ComTencentQphoneBaseUtilBaseActionListener;
    localQQApplication.b(localBaseActionListener);
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.AddRequestActivity
 * JD-Core Version:    0.5.4
 */