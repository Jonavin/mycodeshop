package com.tencent.mobileqq.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.mobileqq.skin.SkinHashMap;
import com.tencent.mobileqq.widget.CustomDrawable1;
import fy;
import ga;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ThemeSettingActivity extends BaseActivity
  implements AdapterView.OnItemClickListener
{
  public static final String KEY_SKIN = "skin";
  public static final String SKIN_DEFAULT = "qq_skin_blue";
  private static List myData = new ArrayList();
  private final int jdField_a_of_type_Int = 34099;
  public Context a;
  private Handler jdField_a_of_type_AndroidOsHandler;
  private ListView jdField_a_of_type_AndroidWidgetListView;
  private ga jdField_a_of_type_Ga = null;
  private String jdField_a_of_type_JavaLangString = "";
  private final int b = -2697514;

  public ThemeSettingActivity()
  {
    this.jdField_a_of_type_AndroidContentContext = null;
    fy localfy = new fy(this);
    this.jdField_a_of_type_AndroidOsHandler = localfy;
  }

  private static void addItem(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("iconname", paramString1);
    localHashMap.put("skinname", paramString2);
    localHashMap.put("skinid", paramString3);
    localHashMap.put("filepath", paramString4);
    synchronized (myData)
    {
      myData.add(localHashMap);
      return;
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    Context localContext = getApplicationContext();
    this.jdField_a_of_type_AndroidContentContext = localContext;
    setContentView(2130903088);
    ListView localListView1 = (ListView)findViewById(2131493121);
    this.jdField_a_of_type_AndroidWidgetListView = localListView1;
    this.jdField_a_of_type_AndroidWidgetListView.setChoiceMode(1);
    ga localga1 = new ga(this);
    this.jdField_a_of_type_Ga = localga1;
    ListView localListView2 = this.jdField_a_of_type_AndroidWidgetListView;
    ga localga2 = this.jdField_a_of_type_Ga;
    localListView2.setAdapter(localga2);
    this.jdField_a_of_type_AndroidWidgetListView.setVisibility(0);
    this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this);
    findViewById(2131492938).setVisibility(0);
    TextView localTextView = (TextView)findViewById(2131492939);
    ImageView localImageView = (ImageView)findViewById(2131492865);
    CustomDrawable1 localCustomDrawable1 = new CustomDrawable1(this);
    localImageView.setImageDrawable(localCustomDrawable1);
    localTextView.setText("姝ｅ湪鍒濆");
    String str = getSharedPreferences("skin", 0).getString("skin", "qq_skin_blue");
    this.jdField_a_of_type_JavaLangString = str;
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(0);
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    synchronized (myData)
    {
      String str1 = (String)((HashMap)myData.get(paramInt)).get("skinid");
      this.jdField_a_of_type_JavaLangString = str1;
      String str2 = this.jdField_a_of_type_JavaLangString;
      String str3 = SkinHashMap.skinId;
      if (!str2.equals(str3))
      {
        String str4 = this.jdField_a_of_type_JavaLangString;
        SharedPreferences.Editor localEditor = getSharedPreferences("skin", 0).edit();
        localEditor.putString("skin", str4);
        localEditor.commit();
        String str5 = this.jdField_a_of_type_JavaLangString;
        a(str5);
      }
      return;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.ThemeSettingActivity
 * JD-Core Version:    0.5.4
 */