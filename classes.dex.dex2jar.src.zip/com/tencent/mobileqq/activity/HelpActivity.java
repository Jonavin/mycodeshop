package com.tencent.mobileqq.activity;

public class HelpActivity extends BaseActivity
{
  // ERROR //
  protected void onCreate(android.os.Bundle paramBundle)
  {
    // Byte code:
    //   0: bipush 7
    //   2: istore_2
    //   3: aload_0
    //   4: aload_1
    //   5: invokespecial 14	com/tencent/mobileqq/activity/BaseActivity:onCreate	(Landroid/os/Bundle;)V
    //   8: aconst_null
    //   9: astore_3
    //   10: aload_0
    //   11: invokevirtual 18	com/tencent/mobileqq/activity/HelpActivity:getResources	()Landroid/content/res/Resources;
    //   14: ldc 19
    //   16: invokevirtual 25	android/content/res/Resources:openRawResource	(I)Ljava/io/InputStream;
    //   19: astore 4
    //   21: aload 4
    //   23: invokevirtual 31	java/io/InputStream:available	()I
    //   26: newarray byte
    //   28: astore 5
    //   30: aload 4
    //   32: aload 5
    //   34: invokevirtual 35	java/io/InputStream:read	([B)I
    //   37: pop
    //   38: new 37	java/lang/String
    //   41: dup
    //   42: aload 5
    //   44: invokespecial 40	java/lang/String:<init>	([B)V
    //   47: astore 6
    //   49: aload 4
    //   51: invokevirtual 43	java/io/InputStream:close	()V
    //   54: aload 6
    //   56: astore_3
    //   57: new 45	android/webkit/WebView
    //   60: dup
    //   61: aload_0
    //   62: invokespecial 48	android/webkit/WebView:<init>	(Landroid/content/Context;)V
    //   65: astore 7
    //   67: new 50	java/lang/StringBuilder
    //   70: dup
    //   71: invokespecial 51	java/lang/StringBuilder:<init>	()V
    //   74: ldc 53
    //   76: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: aload_3
    //   80: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   86: astore 8
    //   88: ldc 63
    //   90: aload 8
    //   92: invokestatic 69	com/tencent/qphone/base/util/QLog:i	(Ljava/lang/String;Ljava/lang/String;)V
    //   95: aload 7
    //   97: aload_3
    //   98: ldc 71
    //   100: ldc 73
    //   102: invokevirtual 77	android/webkit/WebView:loadData	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   105: aload_0
    //   106: iload_2
    //   107: invokevirtual 81	com/tencent/mobileqq/activity/HelpActivity:requestWindowFeature	(I)Z
    //   110: pop
    //   111: aload_0
    //   112: aload 7
    //   114: invokevirtual 85	com/tencent/mobileqq/activity/HelpActivity:setContentView	(Landroid/view/View;)V
    //   117: aload_0
    //   118: invokevirtual 89	com/tencent/mobileqq/activity/HelpActivity:getWindow	()Landroid/view/Window;
    //   121: iload_2
    //   122: ldc 90
    //   124: invokevirtual 96	android/view/Window:setFeatureInt	(II)V
    //   127: aload_0
    //   128: ldc 97
    //   130: invokevirtual 101	com/tencent/mobileqq/activity/HelpActivity:findViewById	(I)Landroid/view/View;
    //   133: checkcast 103	android/widget/TextView
    //   136: ldc 104
    //   138: invokevirtual 108	android/widget/TextView:setText	(I)V
    //   141: return
    //   142: astore_3
    //   143: aload 6
    //   145: astore_3
    //   146: goto -89 -> 57
    //   149: astore 9
    //   151: aload 4
    //   153: invokevirtual 43	java/io/InputStream:close	()V
    //   156: goto -99 -> 57
    //   159: astore 10
    //   161: goto -104 -> 57
    //   164: astore_3
    //   165: aload 4
    //   167: invokevirtual 43	java/io/InputStream:close	()V
    //   170: aload_3
    //   171: athrow
    //   172: astore 11
    //   174: goto -4 -> 170
    //
    // Exception table:
    //   from	to	target	type
    //   49	54	142	java/io/IOException
    //   21	49	149	java/io/IOException
    //   151	156	159	java/io/IOException
    //   21	49	164	finally
    //   165	170	172	java/io/IOException
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.HelpActivity
 * JD-Core Version:    0.5.4
 */