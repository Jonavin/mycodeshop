package com.tencent.mobileqq.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.mobileqq.widget.DoodlePicView;
import com.tencent.mobileqq.widget.DoodleTextView;
import com.tencent.qphone.base.remote.SimpleAccount;
import dr;
import ds;
import dt;
import du;
import dv;
import dw;
import dx;
import dz;
import ea;
import eb;
import ec;
import ed;
import ee;
import ef;
import eg;
import java.io.File;

public class DoodleActivity extends BaseActivity
{
  public static final int ADD_TIME = 800;
  public static final int ADD_TYPE = 0;
  public static final int SEND_TYPE = 6;
  public static final int TWINKLE_TIME = 600;
  public static final int TWINKLE_TYPE = 2;
  private static final int num = 6;
  private int jdField_a_of_type_Int;
  private Bitmap jdField_a_of_type_AndroidGraphicsBitmap;
  private Uri jdField_a_of_type_AndroidNetUri;
  private Handler jdField_a_of_type_AndroidOsHandler;
  View.OnClickListener jdField_a_of_type_AndroidViewView$OnClickListener;
  private ImageView jdField_a_of_type_AndroidWidgetImageView;
  private LinearLayout jdField_a_of_type_AndroidWidgetLinearLayout;
  private TextView jdField_a_of_type_AndroidWidgetTextView;
  private DoodlePicView jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView;
  private DoodleTextView jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView;
  private String jdField_a_of_type_JavaLangString;
  private boolean jdField_a_of_type_Boolean;
  private int[] jdField_a_of_type_ArrayOfInt;
  private ImageView[] jdField_a_of_type_ArrayOfAndroidWidgetImageView;
  private int jdField_b_of_type_Int;
  private Bitmap jdField_b_of_type_AndroidGraphicsBitmap;
  View.OnClickListener jdField_b_of_type_AndroidViewView$OnClickListener;
  private ImageView jdField_b_of_type_AndroidWidgetImageView;
  private LinearLayout jdField_b_of_type_AndroidWidgetLinearLayout;
  private TextView jdField_b_of_type_AndroidWidgetTextView;
  private String jdField_b_of_type_JavaLangString;
  private int[] jdField_b_of_type_ArrayOfInt;
  private ImageView[] jdField_b_of_type_ArrayOfAndroidWidgetImageView;
  View.OnClickListener jdField_c_of_type_AndroidViewView$OnClickListener;
  private ImageView jdField_c_of_type_AndroidWidgetImageView;
  private LinearLayout jdField_c_of_type_AndroidWidgetLinearLayout;
  private TextView jdField_c_of_type_AndroidWidgetTextView;
  private String jdField_c_of_type_JavaLangString;
  private int[] jdField_c_of_type_ArrayOfInt;
  private ImageView jdField_d_of_type_AndroidWidgetImageView;
  private int[] jdField_d_of_type_ArrayOfInt;
  private ImageView e;
  private ImageView f;
  private ImageView g;

  public DoodleActivity()
  {
    int[] arrayOfInt1 = { 2131493044, 2131493045, 2131493046, 2131493047, 2131493048, 2131493049 };
    this.jdField_a_of_type_ArrayOfInt = arrayOfInt1;
    int[] arrayOfInt2 = { 2131493053, 2131493054, 2131493055, 2131493056, 2131493057, 2131493058 };
    this.jdField_b_of_type_ArrayOfInt = arrayOfInt2;
    ImageView[] arrayOfImageView1 = new ImageView[6];
    arrayOfImageView1[0] = null;
    arrayOfImageView1[1] = null;
    arrayOfImageView1[2] = null;
    arrayOfImageView1[3] = null;
    arrayOfImageView1[4] = null;
    arrayOfImageView1[5] = null;
    this.jdField_a_of_type_ArrayOfAndroidWidgetImageView = arrayOfImageView1;
    ImageView[] arrayOfImageView2 = new ImageView[6];
    arrayOfImageView2[0] = null;
    arrayOfImageView2[1] = null;
    arrayOfImageView2[2] = null;
    arrayOfImageView2[3] = null;
    arrayOfImageView2[4] = null;
    arrayOfImageView2[5] = null;
    this.jdField_b_of_type_ArrayOfAndroidWidgetImageView = arrayOfImageView2;
    int[] arrayOfInt3 = { 15, 13, 11, 9, 7, 5 };
    this.jdField_c_of_type_ArrayOfInt = arrayOfInt3;
    int[] arrayOfInt4 = { -13948119, -182711, -218815, -132846, -10758621, -13062145 };
    this.jdField_d_of_type_ArrayOfInt = arrayOfInt4;
    this.jdField_b_of_type_Int = null;
    du localdu = new du(this);
    this.jdField_a_of_type_AndroidViewView$OnClickListener = localdu;
    dv localdv = new dv(this);
    this.jdField_b_of_type_AndroidViewView$OnClickListener = localdv;
    dw localdw = new dw(this);
    this.jdField_c_of_type_AndroidViewView$OnClickListener = localdw;
    dx localdx = new dx(this);
    this.jdField_a_of_type_AndroidOsHandler = localdx;
  }

  private void a()
  {
    this.jdField_a_of_type_Boolean = true;
    this.jdField_a_of_type_AndroidWidgetTextView.setOnClickListener(null);
    TextView localTextView1 = this.jdField_b_of_type_AndroidWidgetTextView;
    ea localea = new ea(this);
    localTextView1.setOnClickListener(localea);
    Integer localInteger = (Integer)SkinEngine.getSkinData("codecolor_doodle_top_textview", "codecolor");
    TextView localTextView2 = this.jdField_a_of_type_AndroidWidgetTextView;
    int i = localInteger.intValue();
    localTextView2.setBackgroundColor(i);
    this.jdField_a_of_type_AndroidWidgetTextView.setPadding(0, 0, 0, 0);
    this.jdField_b_of_type_AndroidWidgetTextView.setBackgroundDrawable(null);
    this.jdField_b_of_type_AndroidWidgetTextView.setPadding(0, 0, 0, 0);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView.setVisibility(0);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView.setVisibility(8);
    DoodleTextView localDoodleTextView = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView;
    Handler localHandler = this.jdField_a_of_type_AndroidOsHandler;
    localDoodleTextView.setHandler(localHandler);
    ImageView localImageView1 = this.jdField_c_of_type_AndroidWidgetImageView;
    eb localeb = new eb(this);
    localImageView1.setOnClickListener(localeb);
    this.jdField_d_of_type_AndroidWidgetImageView.setVisibility(8);
    this.e.setVisibility(8);
    ImageView localImageView2 = this.f;
    ec localec = new ec(this);
    localImageView2.setOnClickListener(localec);
    ImageView localImageView3 = this.g;
    ed localed = new ed(this);
    localImageView3.setOnClickListener(localed);
    TextView localTextView3 = this.jdField_c_of_type_AndroidWidgetTextView;
    View.OnClickListener localOnClickListener = this.jdField_a_of_type_AndroidViewView$OnClickListener;
    localTextView3.setOnClickListener(localOnClickListener);
  }

  private void b()
  {
    this.jdField_a_of_type_Boolean = null;
    TextView localTextView1 = this.jdField_a_of_type_AndroidWidgetTextView;
    ee localee = new ee(this);
    localTextView1.setOnClickListener(localee);
    this.jdField_b_of_type_AndroidWidgetTextView.setOnClickListener(null);
    Integer localInteger = (Integer)SkinEngine.getSkinData("codecolor_doodle_top_textview", "codecolor");
    this.jdField_a_of_type_AndroidWidgetTextView.setBackgroundDrawable(null);
    this.jdField_a_of_type_AndroidWidgetTextView.setPadding(0, 0, 0, 0);
    TextView localTextView2 = this.jdField_b_of_type_AndroidWidgetTextView;
    int i = localInteger.intValue();
    localTextView2.setBackgroundColor(i);
    this.jdField_b_of_type_AndroidWidgetTextView.setPadding(0, 0, 0, 0);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView.setVisibility(8);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView.setVisibility(0);
    ImageView localImageView1 = this.jdField_c_of_type_AndroidWidgetImageView;
    ef localef = new ef(this);
    localImageView1.setOnClickListener(localef);
    this.jdField_d_of_type_AndroidWidgetImageView.setVisibility(0);
    this.e.setVisibility(0);
    ImageView localImageView2 = this.jdField_d_of_type_AndroidWidgetImageView;
    eg localeg = new eg(this);
    localImageView2.setOnClickListener(localeg);
    ImageView localImageView3 = this.f;
    ds localds = new ds(this);
    localImageView3.setOnClickListener(localds);
    ImageView localImageView4 = this.g;
    dt localdt = new dt(this);
    localImageView4.setOnClickListener(localdt);
    TextView localTextView3 = this.jdField_c_of_type_AndroidWidgetTextView;
    View.OnClickListener localOnClickListener = this.jdField_a_of_type_AndroidViewView$OnClickListener;
    localTextView3.setOnClickListener(localOnClickListener);
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    int i = 102;
    int j = 0;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    int k = -1;
    if (paramInt2 == k)
      switch (paramInt1)
      {
      default:
      case 1:
      case 2:
      case 102:
      }
    while (true)
    {
      label60: return;
      boolean bool1 = this.jdField_a_of_type_Boolean;
      if (bool1)
        continue;
      if (paramIntent != null)
      {
        localUri1 = paramIntent.getData();
        if (localUri1 != null)
          break label93;
      }
      Uri localUri1 = this.jdField_a_of_type_AndroidNetUri;
      label93: Object localObject = ImageUtil.getRealPathFromContentURI(this, localUri1);
      if (localObject != null)
      {
        localObject = new File((String)localObject).exists();
        if (localObject == 0)
          Toast.makeText(this, "鍥剧�", j).show();
      }
      localObject = new Intent(this, PhotoPreview.class);
      if (paramInt1 == 1)
        ((Intent)localObject).setData(localUri1);
      while (true)
      {
        ((Intent)localObject).putExtra("requestType", i);
        String str2 = this.jdField_a_of_type_JavaLangString;
        ((Intent)localObject).putExtra("friendUin", str2);
        int l = this.jdField_a_of_type_Int;
        ((Intent)localObject).putExtra("curType", l);
        ((Intent)localObject).setFlags(67108864);
        startActivityForResult((Intent)localObject, i);
        break label60:
        Uri localUri2 = paramIntent.getData();
        ((Intent)localObject).setData(localUri2);
      }
      boolean bool2 = this.jdField_a_of_type_Boolean;
      if (bool2)
        continue;
      String str1 = paramIntent.getExtras().getString("photofilepath");
      localObject = paramIntent.getExtras().getInt("rotation");
      if (str1 != null)
        this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView.setPhotoFile(str1, localObject);
      Toast.makeText(this, "鍥剧墖涓�", j).show();
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    int i = 2;
    int j = 0;
    super.onCreate(paramBundle);
    setContentView(2130903065);
    boolean bool = getIntent().getBooleanExtra("doodletype", true);
    this.jdField_a_of_type_Boolean = bool;
    int k = getIntent().getIntExtra("friendtype", -1);
    this.jdField_a_of_type_Int = k;
    String str1 = getIntent().getStringExtra("frienduin");
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = getIntent().getStringExtra("photofilepath");
    this.jdField_c_of_type_JavaLangString = str2;
    int l = getIntent().getIntExtra("rotation", j);
    this.jdField_b_of_type_Int = l;
    String str3 = this.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getUin();
    this.jdField_b_of_type_JavaLangString = str3;
    TextView localTextView1 = (TextView)findViewById(2131493037);
    this.jdField_a_of_type_AndroidWidgetTextView = localTextView1;
    TextView localTextView2 = (TextView)findViewById(2131493038);
    this.jdField_b_of_type_AndroidWidgetTextView = localTextView2;
    DoodleTextView localDoodleTextView1 = (DoodleTextView)findViewById(2131493039);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView = localDoodleTextView1;
    DoodlePicView localDoodlePicView1 = (DoodlePicView)findViewById(2131493040);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView = localDoodlePicView1;
    LinearLayout localLinearLayout1 = (LinearLayout)findViewById(2131493050);
    this.jdField_a_of_type_AndroidWidgetLinearLayout = localLinearLayout1;
    LinearLayout localLinearLayout2 = (LinearLayout)findViewById(2131493042);
    this.jdField_b_of_type_AndroidWidgetLinearLayout = localLinearLayout2;
    ImageView localImageView1 = (ImageView)findViewById(2131493061);
    this.jdField_c_of_type_AndroidWidgetImageView = localImageView1;
    ImageView localImageView2 = (ImageView)findViewById(2131493067);
    this.jdField_d_of_type_AndroidWidgetImageView = localImageView2;
    ImageView localImageView3 = (ImageView)findViewById(2131493065);
    this.e = localImageView3;
    ImageView localImageView4 = (ImageView)findViewById(2131493041);
    this.f = localImageView4;
    ImageView localImageView5 = (ImageView)findViewById(2131493064);
    this.g = localImageView5;
    TextView localTextView3 = (TextView)findViewById(2131493068);
    this.jdField_c_of_type_AndroidWidgetTextView = localTextView3;
    ImageView localImageView6 = (ImageView)findViewById(2131493052);
    this.jdField_a_of_type_AndroidWidgetImageView = localImageView6;
    ImageView localImageView7 = (ImageView)findViewById(2131493043);
    this.jdField_b_of_type_AndroidWidgetImageView = localImageView7;
    LinearLayout localLinearLayout3 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
    int i1 = 2131493051;
    LinearLayout localLinearLayout4 = (LinearLayout)localLinearLayout3.findViewById(i1);
    this.jdField_c_of_type_AndroidWidgetLinearLayout = localLinearLayout4;
    if (this.jdField_a_of_type_Boolean)
      a();
    while (true)
    {
      i1 = j;
      while (true)
      {
        if (i1 >= 6)
          break label570;
        ImageView[] arrayOfImageView1 = this.jdField_a_of_type_ArrayOfAndroidWidgetImageView;
        LinearLayout localLinearLayout5 = this.jdField_b_of_type_AndroidWidgetLinearLayout;
        int i2 = this.jdField_a_of_type_ArrayOfInt[i1];
        ImageView localImageView8 = (ImageView)localLinearLayout5.findViewById(i2);
        arrayOfImageView1[i1] = localImageView8;
        ImageView[] arrayOfImageView2 = this.jdField_b_of_type_ArrayOfAndroidWidgetImageView;
        LinearLayout localLinearLayout6 = this.jdField_a_of_type_AndroidWidgetLinearLayout;
        int i3 = this.jdField_b_of_type_ArrayOfInt[i1];
        ImageView localImageView9 = (ImageView)localLinearLayout6.findViewById(i3);
        arrayOfImageView2[i1] = localImageView9;
        ImageView localImageView10 = this.jdField_a_of_type_ArrayOfAndroidWidgetImageView[i1];
        View.OnClickListener localOnClickListener1 = this.jdField_b_of_type_AndroidViewView$OnClickListener;
        localImageView10.setOnClickListener(localOnClickListener1);
        ImageView localImageView11 = this.jdField_b_of_type_ArrayOfAndroidWidgetImageView[i1];
        View.OnClickListener localOnClickListener2 = this.jdField_c_of_type_AndroidViewView$OnClickListener;
        localImageView11.setOnClickListener(localOnClickListener2);
        i1 += 1;
      }
      b();
    }
    label570: DoodleTextView localDoodleTextView2 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView;
    int i4 = this.jdField_d_of_type_ArrayOfInt[j];
    localDoodleTextView2.setPaintColor(i4);
    DoodlePicView localDoodlePicView2 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView;
    int i5 = this.jdField_d_of_type_ArrayOfInt[j];
    localDoodlePicView2.setPaintColor(i5);
    this.jdField_b_of_type_ArrayOfAndroidWidgetImageView[j].setBackgroundResource(2130838019);
    DoodlePicView localDoodlePicView3 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView;
    int i6 = this.jdField_c_of_type_ArrayOfInt[i];
    localDoodlePicView3.setPaintThickness(i6);
    this.jdField_a_of_type_ArrayOfAndroidWidgetImageView[i].setBackgroundResource(2130838021);
    ImageView localImageView12 = this.jdField_a_of_type_AndroidWidgetImageView;
    dr localdr = new dr(this);
    localImageView12.setOnClickListener(localdr);
    ImageView localImageView13 = this.jdField_b_of_type_AndroidWidgetImageView;
    dz localdz = new dz(this);
    localImageView13.setOnClickListener(localdz);
    Bitmap localBitmap1 = BitmapFactory.decodeResource(getResources(), 2130837582);
    this.jdField_a_of_type_AndroidGraphicsBitmap = localBitmap1;
    Bitmap localBitmap2 = BitmapFactory.decodeResource(getResources(), 2130837581);
    this.jdField_b_of_type_AndroidGraphicsBitmap = localBitmap2;
    DoodleTextView localDoodleTextView3 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodleTextView;
    Bitmap localBitmap3 = this.jdField_a_of_type_AndroidGraphicsBitmap;
    Bitmap localBitmap4 = this.jdField_b_of_type_AndroidGraphicsBitmap;
    localDoodleTextView3.setTextureBitmap(localBitmap3, localBitmap4);
    DoodlePicView localDoodlePicView4 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView;
    Bitmap localBitmap5 = this.jdField_a_of_type_AndroidGraphicsBitmap;
    Bitmap localBitmap6 = this.jdField_b_of_type_AndroidGraphicsBitmap;
    localDoodlePicView4.setTextureBitmap(localBitmap5, localBitmap6);
    DoodlePicView localDoodlePicView5 = this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView;
    String str4 = this.jdField_c_of_type_JavaLangString;
    int i7 = this.jdField_b_of_type_Int;
    localDoodlePicView5.setPhotoFile(str4, i7);
    this.jdField_a_of_type_ComTencentMobileqqWidgetDoodlePicView.invalidate();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    this.jdField_a_of_type_AndroidOsHandler.removeMessages(0);
    this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
  }

  protected void onResume()
  {
    super.onResume();
    setRequestedOrientation(1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.mobileqq.activity.DoodleActivity
 * JD-Core Version:    0.5.4
 */