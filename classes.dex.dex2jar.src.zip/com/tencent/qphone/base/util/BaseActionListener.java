package com.tencent.qphone.base.util;

import android.os.RemoteException;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.IBaseActionListener.Stub;

public abstract class BaseActionListener extends IBaseActionListener.Stub
{
  private boolean isCountinue(FromServiceMsg paramFromServiceMsg)
  {
    boolean bool = paramFromServiceMsg.getServiceCmd().equals("baseSdk.Mul.PingCallback");
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      return localObject;
      int i = 1;
    }
  }

  public abstract void onActionResult(FromServiceMsg paramFromServiceMsg)
    throws RemoteException;

  public void onRecvFromMsg(FromServiceMsg paramFromServiceMsg)
    throws RemoteException
  {
    if (!isCountinue(paramFromServiceMsg))
      return;
    onActionResult(paramFromServiceMsg);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.qphone.base.util.BaseActionListener
 * JD-Core Version:    0.5.4
 */