package com.tencent.qphone.base.util;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import com.tencent.qphone.base.kernel.IPushCenter;
import com.tencent.qphone.base.kernel.NetConnWrapper;
import com.tencent.qphone.base.kernel.k;
import com.tencent.qphone.base.kernel.n;
import com.tencent.qphone.base.kernel.q;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class BaseApplication extends Application
{
  static String accountSyncServiceName;
  static int appid = 0;
  static HelperCallbacker basicCallbacker;
  static Context context;
  public static ConcurrentHashMap loadSubMap;
  static IPushCenter pushCenter;
  private static final String tag = "BaseApplication";
  public static boolean testMode;
  public static boolean validateMode;
  boolean gray = true;
  a mApplicationsReceiver;
  int maxPackageSize = 5242880;
  ExecutorService threadPool;

  static
  {
    boolean bool1 = validateMode;
    boolean bool2 = testMode;
    loadSubMap = new ConcurrentHashMap();
  }

  public static int getApplicationAppid()
  {
    return appid;
  }

  public static HelperCallbacker getApplicationHelperCallbacker()
  {
    return basicCallbacker;
  }

  public static int getConnInfo()
  {
    return n.d();
  }

  public static Context getContext()
  {
    return context;
  }

  public static long[] getCurrentDataCount(boolean paramBoolean)
  {
    return n.a(paramBoolean);
  }

  public static IPushCenter getPushCenter()
  {
    return pushCenter;
  }

  public static String getSyncServiceName()
  {
    return accountSyncServiceName;
  }

  public static boolean isNetSupport()
  {
    return n.c();
  }

  public static void requestSynServices()
  {
    Intent localIntent = new Intent("com.tencent.qphone.base.subservice");
    List localList = context.getPackageManager().queryIntentServices(localIntent, 128);
    int i = 0;
    int i1 = i;
    label28: int j = localList.size();
    if (i1 >= j)
      return;
    ServiceInfo localServiceInfo = ((ResolveInfo)localList.get(i1)).serviceInfo;
    boolean bool = localServiceInfo.exported;
    if (!bool);
    while (true)
    {
      int k = i1 + 1;
      i1 = k;
      break label28:
      Object localObject3 = k.metaData;
      Object localObject5 = k.metaData;
      if (localObject5 != null)
      {
        localObject5 = new q();
        String str2 = k.packageName;
        Object localObject1 = k.name;
        ComponentName localComponentName = new ComponentName(str2, (String)localObject1);
        ((q)localObject5).a = localComponentName;
        localObject1 = ((Bundle)localObject3).getString("SERVICE_ID");
        ((q)localObject5).b = ((String)localObject1);
        localObject1 = ((Bundle)localObject3).getString("SERVICE_NAME");
        ((q)localObject5).c = ((String)localObject1);
        localObject1 = ((Bundle)localObject3).getInt("SERVICE_VERSION");
        ((q)localObject5).d = localObject1;
        localObject1 = ((q)localObject5).b;
        if (localObject1 == null)
          continue;
        localObject3 = "load sub service " + localObject5;
        QLog.i("BaseApplication", (String)localObject3);
        localObject1 = loadSubMap;
        localObject3 = ((q)localObject5).b;
        localObject1 = ((ConcurrentHashMap)localObject1).containsKey(localObject3);
        if (localObject1 != 0)
        {
          localObject1 = loadSubMap;
          localObject3 = ((q)localObject5).b;
          localObject1 = (q)((ConcurrentHashMap)localObject1).get(localObject3);
          int i2 = ((q)localObject1).d;
          int i4 = ((q)localObject5).d;
          if (i2 < i4)
          {
            localObject1 = loadSubMap;
            String str1 = ((q)localObject5).b;
            ((ConcurrentHashMap)localObject1).put(str1, localObject5);
            localObject1 = "BaseApplication";
            str1 = "subService is replaced by " + localObject5;
            QLog.w((String)localObject1, str1);
          }
          int i3 = ((q)localObject1).d;
          int i5 = ((q)localObject5).d;
          if (i3 == i5)
          {
            localObject1 = "BaseApplication";
            localObject4 = new StringBuilder().append("add ");
            String str3 = ((q)localObject5).b;
            localObject4 = str3 + " cancled,found the same version " + localObject5;
            QLog.w((String)localObject1, (String)localObject4);
          }
          localObject4 = "BaseApplication";
          StringBuilder localStringBuilder1 = new StringBuilder().append("add ");
          String str4 = ((q)localObject5).b;
          StringBuilder localStringBuilder2 = localStringBuilder1.append(str4).append(" cancled, new version is ");
          int l = ((q)localObject1).d;
          localObject2 = l + ", the version is oldder. " + localObject5;
          QLog.w((String)localObject4, (String)localObject2);
        }
        localObject2 = loadSubMap;
        localObject4 = ((q)localObject5).b;
        ((ConcurrentHashMap)localObject2).put(localObject4, localObject5);
      }
      Object localObject4 = "BaseApplication";
      localObject5 = new StringBuilder();
      String str5 = ((ServiceInfo)localObject2).packageName;
      localObject5 = ((StringBuilder)localObject5).append(str5).append("|");
      Object localObject2 = ((ServiceInfo)localObject2).name;
      localObject2 = ((StringBuilder)localObject5).append((String)localObject2);
      localObject5 = " has no meta-data.";
      localObject2 = (String)localObject5;
      QLog.w((String)localObject4, (String)localObject2);
    }
  }

  public static void resetDataCount(boolean paramBoolean)
  {
    n.b(paramBoolean);
  }

  public static void setPushCenter(IPushCenter paramIPushCenter)
  {
    pushCenter = paramIPushCenter;
    if (pushCenter == null)
      return;
    pushCenter.init();
  }

  public static void setSyncServiceName(String paramString)
  {
    accountSyncServiceName = paramString;
  }

  public final void closeConn()
  {
    k.c().closeConn();
  }

  public abstract int getAppid();

  /** @deprecated */
  public ExecutorService getCallbackerThreadPool()
  {
    monitorenter;
    try
    {
      ExecutorService localExecutorService = this.threadPool;
      if (localExecutorService == null)
      {
        localExecutorService = Executors.newFixedThreadPool(4);
        this.threadPool = localExecutorService;
      }
      localExecutorService = this.threadPool;
      monitorexit;
      return localExecutorService;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  public abstract HelperCallbacker getHelpCallbacker();

  public int getMaxPackageSize()
  {
    return this.maxPackageSize;
  }

  public boolean isGrayMode()
  {
    return this.gray;
  }

  public boolean isTestMode()
  {
    int i;
    testMode = i;
    return i;
  }

  public boolean isValidateMode()
  {
    int i;
    validateMode = i;
    return i;
  }

  protected ArrayList needInitSubServie()
  {
    return new ArrayList();
  }

  public void onCreate()
  {
    super.onCreate();
    while (true)
    {
      try
      {
        context = this;
        QLog.init(context);
        appid = getAppid();
        Object localObject1 = new a();
        this.mApplicationsReceiver = ((a)localObject1);
        localObject1 = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        ((IntentFilter)localObject1).addAction("android.intent.action.PACKAGE_REMOVED");
        ((IntentFilter)localObject1).addAction("android.intent.action.PACKAGE_CHANGED");
        ((IntentFilter)localObject1).addDataScheme("package");
        Object localObject2 = this.mApplicationsReceiver;
        registerReceiver((BroadcastReceiver)localObject2, (IntentFilter)localObject1);
        requestSynServices();
        basicCallbacker = getHelpCallbacker();
        localObject1 = needInitSubServie();
        if (localObject1 == null)
          break label140;
        localObject2 = ((ArrayList)localObject1).size();
        if (localObject2 <= 0)
          break label140;
        localObject2 = ((ArrayList)localObject1).iterator();
        if (!((Iterator)localObject2).hasNext())
          break label140;
        BaseServiceProxyFactory.doInitSubServiceConn((String)((Iterator)localObject2).next());
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return;
      }
      label140: int i = getAppid();
      HelperCallbacker localHelperCallbacker = basicCallbacker;
      k.a(this, i, localHelperCallbacker);
      n.a(context);
    }
  }

  public final boolean openConn()
  {
    NetConnWrapper localNetConnWrapper = k.c();
    int i = k.w;
    return localNetConnWrapper.openConn(i);
  }

  public final void resume()
  {
    k.G.set(true);
    QLog.d("BaseApplication", "mini sdk resumed.");
  }

  public void setGrayMode(boolean paramBoolean)
  {
    this.gray = paramBoolean;
  }

  public void setMaxPackageSize(int paramInt)
  {
    this.maxPackageSize = paramInt;
  }

  public void setTestMode(boolean paramBoolean)
  {
    boolean bool1;
    testMode = bool1;
    if (bool1 == paramBoolean)
      return;
    boolean bool2 = testMode;
    k.c().closeConn();
  }

  public void setValidateMode(boolean paramBoolean)
  {
    boolean bool1;
    validateMode = bool1;
    if (bool1 == paramBoolean)
      return;
    boolean bool2 = validateMode;
    k.c().closeConn();
  }

  public final void suspend()
  {
    QLog.d("BaseApplication", "mini sdk try suspend.");
    k.G.set(null);
    k.c().closeConn();
    QLog.d("BaseApplication", "mini sdk suspended.");
  }

  class a extends BroadcastReceiver
  {
    a()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      BaseApplication.requestSynServices();
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.qphone.base.util.BaseApplication
 * JD-Core Version:    0.5.4
 */