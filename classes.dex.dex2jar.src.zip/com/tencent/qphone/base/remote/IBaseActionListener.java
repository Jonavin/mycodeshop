package com.tencent.qphone.base.remote;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBaseActionListener extends IInterface
{
  public abstract void onActionResult(FromServiceMsg paramFromServiceMsg)
    throws RemoteException;

  public abstract void onRecvFromMsg(FromServiceMsg paramFromServiceMsg)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IBaseActionListener
  {
    private static final String DESCRIPTOR = "com.tencent.qphone.base.remote.IBaseActionListener";
    static final int TRANSACTION_onActionResult = 2;
    static final int TRANSACTION_onRecvFromMsg = 1;

    public Stub()
    {
      attachInterface(this, "com.tencent.qphone.base.remote.IBaseActionListener");
    }

    public static IBaseActionListener asInterface(IBinder paramIBinder)
    {
      int i;
      if (paramIBinder == null)
        i = 0;
      while (true)
      {
        return i;
        Object localObject = paramIBinder.queryLocalInterface("com.tencent.qphone.base.remote.IBaseActionListener");
        if ((localObject != null) && (localObject instanceof IBaseActionListener))
          localObject = (IBaseActionListener)localObject;
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      Object localObject1 = null;
      boolean bool1 = true;
      boolean bool2;
      switch (paramInt1)
      {
      default:
        bool2 = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        while (true)
        {
          return bool2;
          paramParcel2.writeString("com.tencent.qphone.base.remote.IBaseActionListener");
          bool2 = bool1;
        }
      case 1:
        label51: paramParcel1.enforceInterface("com.tencent.qphone.base.remote.IBaseActionListener");
        int i = paramParcel1.readInt();
        if (i != 0);
        for (localObject2 = (FromServiceMsg)FromServiceMsg.CREATOR.createFromParcel(paramParcel1); ; localObject2 = localObject1)
        {
          onRecvFromMsg((FromServiceMsg)localObject2);
          localObject2 = bool1;
          break label51:
        }
      case 2:
      }
      paramParcel1.enforceInterface("com.tencent.qphone.base.remote.IBaseActionListener");
      Object localObject2 = paramParcel1.readInt();
      if (localObject2 != 0);
      for (localObject2 = (FromServiceMsg)FromServiceMsg.CREATOR.createFromParcel(paramParcel1); ; localObject2 = localObject1)
      {
        onActionResult((FromServiceMsg)localObject2);
        localObject2 = bool1;
        break label51:
      }
    }

    class Proxy
      implements IBaseActionListener
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IBaseActionListener.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.tencent.qphone.base.remote.IBaseActionListener";
      }

      public void onActionResult(FromServiceMsg paramFromServiceMsg)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        int i;
        try
        {
          String str = "com.tencent.qphone.base.remote.IBaseActionListener";
          localParcel.writeInterfaceToken(str);
          if (paramFromServiceMsg != null)
          {
            localParcel.writeInt(1);
            paramFromServiceMsg.writeToParcel(localParcel, 0);
            IBaseActionListener.Stub.this.transact(2, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onRecvFromMsg(FromServiceMsg paramFromServiceMsg)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        int i;
        try
        {
          String str = "com.tencent.qphone.base.remote.IBaseActionListener";
          localParcel.writeInterfaceToken(str);
          if (paramFromServiceMsg != null)
          {
            localParcel.writeInt(1);
            paramFromServiceMsg.writeToParcel(localParcel, 0);
            IBaseActionListener.Stub.this.transact(1, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.tencent.qphone.base.remote.IBaseActionListener
 * JD-Core Version:    0.5.4
 */