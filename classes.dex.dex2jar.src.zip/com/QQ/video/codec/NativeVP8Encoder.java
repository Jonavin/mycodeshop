package com.QQ.video.codec;

public class NativeVP8Encoder
{
  public static final int CSP_YUV420 = 0;
  public static final int FRAME_TYPE_AUTO = 0;
  public static final int FRAME_TYPE_B = 3;
  public static final int FRAME_TYPE_I = 1;
  public static final int FRAME_TYPE_P = 2;
  public static final int FRAME_TYPE_SKIP = 5;
  public static final int FRAME_TYPE_SP = 4;
  public static final int RC_MODE_CBR = 1;
  public static final int RC_MODE_VBR;
  private int jdField_a_of_type_Int = null;
  private long jdField_a_of_type_Long = 0L;
  private int b = 320;
  private int c = 240;
  private int d = 10;
  private int e = 1;
  private int f = 128;
  private int g = 26;
  private int h = 26;
  private int i = 50;
  private int j = 50;
  private int k = null;
  private int l = null;
  private int m = null;

  public static native int EncoderClose();

  public static native byte[] EncoderEncode(byte[] paramArrayOfByte, NativeVP8Encoder paramNativeVP8Encoder);

  public static native int EncoderGetLastStatus();

  public static native int EncoderInit(NativeVP8Encoder paramNativeVP8Encoder);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeVP8Encoder
 * JD-Core Version:    0.5.4
 */