package com.QQ.video.codec;

public class NativeH263EncoderParams
{
  public static final int CBR_1 = 1;
  public static final int CBR_2 = 3;
  public static final int CBR_LOWDELAY = 5;
  public static final int COMBINE_MODE_NO_ERR_RES = 5;
  public static final int COMBINE_MODE_WITH_ERR_RES = 6;
  public static final int CONSTANT_Q = 0;
  public static final int CORE_PROFILE_LEVEL1 = 4;
  public static final int CORE_PROFILE_LEVEL2 = 5;
  public static final int CORE_SCALABLE_PROFILE_LEVEL1 = 10;
  public static final int CORE_SCALABLE_PROFILE_LEVEL2 = 11;
  public static final int CORE_SCALABLE_PROFILE_LEVEL3 = 12;
  public static final int DATA_PARTITIONING_MODE = 4;
  public static final int H263_MODE = 2;
  public static final int H263_MODE_WITH_ERR_RES = 3;
  public static final int SHORT_HEADER = 0;
  public static final int SHORT_HEADER_WITH_ERR_RES = 1;
  public static final int SIMPLE_PROFILE_LEVEL0 = 0;
  public static final int SIMPLE_PROFILE_LEVEL1 = 1;
  public static final int SIMPLE_PROFILE_LEVEL2 = 2;
  public static final int SIMPLE_PROFILE_LEVEL3 = 3;
  public static final int SIMPLE_SCALABLE_PROFILE_LEVEL0 = 6;
  public static final int SIMPLE_SCALABLE_PROFILE_LEVEL1 = 7;
  public static final int SIMPLE_SCALABLE_PROFILE_LEVEL2 = 8;
  public static final int VBR_1 = 2;
  public static final int VBR_2 = 4;
  private float jdField_a_of_type_Float = 1090519040;
  private int jdField_a_of_type_Int = 2;
  private boolean jdField_a_of_type_Boolean = null;
  private float jdField_b_of_type_Float = 1069547520;
  private int jdField_b_of_type_Int = 1024;
  private boolean jdField_b_of_type_Boolean = null;
  private int jdField_c_of_type_Int = 3;
  private boolean jdField_c_of_type_Boolean = null;
  private int jdField_d_of_type_Int = null;
  private boolean jdField_d_of_type_Boolean = true;
  private int jdField_e_of_type_Int = 1;
  private boolean jdField_e_of_type_Boolean = null;
  private int f = 1000;
  private int g = 125;
  private int h = 144;
  private int i = 176;
  private int j = 64000;
  private int k = 15;
  private int l = 12;
  private int m = null;
  private int n = 1;
  private int o = -1;
  private int p = null;
  private int q = 4;
  private int r = null;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeH263EncoderParams
 * JD-Core Version:    0.5.4
 */