package com.QQ.video.codec;

public class NativeH263Decoder
{
  static
  {
    String str = "H263Decoder";
    try
    {
      System.loadLibrary(str);
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public static native int DecodeAndConvert(byte[] paramArrayOfByte, int[] paramArrayOfInt, long paramLong);

  public static native int DeinitDecoder();

  public static native int DeinitParser();

  public static native int InitDecoder(int paramInt1, int paramInt2);

  public static native int InitParser(String paramString);

  public static native String getVideoCoding();

  public static native int getVideoHeight();

  public static native int getVideoLength();

  public static native VideoSample getVideoSample(int[] paramArrayOfInt);

  public static native int getVideoWidth();
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeH263Decoder
 * JD-Core Version:    0.5.4
 */