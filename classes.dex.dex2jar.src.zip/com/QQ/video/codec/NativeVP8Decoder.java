package com.QQ.video.codec;

public class NativeVP8Decoder
{
  private int a = 320;
  private int b = 240;

  public static native int DecoderClose();

  /** @deprecated */
  public static synchronized native int DecoderDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, NativeVP8Decoder paramNativeVP8Decoder);

  public static native int DecoderInit(NativeVP8Decoder paramNativeVP8Decoder);

  public static native int DeinitParser();

  public static native int InitParser(String paramString);

  public static native String getVideoCoding();

  public static native int getVideoHeight();

  public static native int getVideoLength();

  public static native VideoSample getVideoSample(int[] paramArrayOfInt);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeVP8Decoder
 * JD-Core Version:    0.5.4
 */