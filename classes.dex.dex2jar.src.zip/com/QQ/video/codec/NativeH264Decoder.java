package com.QQ.video.codec;

public class NativeH264Decoder
{
  private int a = 320;
  private int b = 240;

  static
  {
    String str = "QQVideoCodec2";
    try
    {
      System.loadLibrary(str);
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public static native int DecoderClose();

  /** @deprecated */
  public static synchronized native int DecoderDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, NativeH264Decoder paramNativeH264Decoder);

  public static native int DecoderInit(NativeH264Decoder paramNativeH264Decoder);

  public static native int DeinitParser();

  public static native int InitParser(String paramString);

  public static native String getVideoCoding();

  public static native int getVideoHeight();

  public static native int getVideoLength();

  public static native VideoSample getVideoSample(int[] paramArrayOfInt);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeH264Decoder
 * JD-Core Version:    0.5.4
 */