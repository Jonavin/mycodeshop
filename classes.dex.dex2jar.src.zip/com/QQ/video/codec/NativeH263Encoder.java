package com.QQ.video.codec;

public class NativeH263Encoder
{
  static
  {
    String str = "H263Encoder";
    try
    {
      System.loadLibrary(str);
      return;
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
    }
  }

  public static native int DeinitEncoder();

  public static native byte[] EncodeFrame(byte[] paramArrayOfByte, long paramLong);

  public static native int InitEncoder(NativeH263EncoderParams paramNativeH263EncoderParams);
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.NativeH263Encoder
 * JD-Core Version:    0.5.4
 */