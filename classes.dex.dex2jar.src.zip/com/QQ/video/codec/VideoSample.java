package com.QQ.video.codec;

public class VideoSample
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.QQ.video.codec.VideoSample
 * JD-Core Version:    0.5.4
 */