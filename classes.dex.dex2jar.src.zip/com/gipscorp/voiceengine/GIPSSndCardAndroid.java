package com.gipscorp.voiceengine;

import Z;
import android.content.Context;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.os.Build.VERSION;
import android.os.Process;
import android.util.Log;
import java.nio.ByteBuffer;
import java.util.concurrent.locks.ReentrantLock;

class GIPSSndCardAndroid
{
  private AudioManager _audioManager;
  private AudioRecord _audioRecord = null;
  private AudioTrack _audioTrack = null;
  private int _bufferedPlaySamples;
  private int _bufferedRecSamples;
  private Context _context;
  private boolean _doPlayInit;
  private boolean _doRecInit;
  private boolean _isPlaying;
  private boolean _isRecording;
  private ByteBuffer _playBuffer;
  private final ReentrantLock _playLock;
  private int _playPosition;
  private ByteBuffer _recBuffer;
  private final ReentrantLock _recLock;
  private int _streamVolume;
  private byte[] _tempBufPlay;
  private byte[] _tempBufRec;
  private int _volumeLevel;

  GIPSSndCardAndroid()
  {
    ReentrantLock localReentrantLock = new ReentrantLock();
    this._playLock = localReentrantLock;
    localReentrantLock = new ReentrantLock();
    this._recLock = localReentrantLock;
    this._doPlayInit = true;
    this._doRecInit = true;
    this._isRecording = null;
    this._isPlaying = null;
    this._bufferedRecSamples = null;
    this._bufferedPlaySamples = null;
    this._playPosition = null;
    this._streamVolume = null;
    this._volumeLevel = null;
    int j = 960;
    try
    {
      ByteBuffer localByteBuffer1 = ByteBuffer.allocateDirect(j);
      this._playBuffer = j;
      ByteBuffer localByteBuffer2 = ByteBuffer.allocateDirect(960);
      this._recBuffer = j;
      byte[] arrayOfByte1 = new byte[i];
      this._tempBufPlay = arrayOfByte1;
      byte[] arrayOfByte2 = new byte[i];
      this._tempBufRec = arrayOfByte2;
      return;
    }
    catch (Exception localException)
    {
      String str = localException.getMessage();
      GIPSLog(str);
    }
  }

  private void GIPSLog(String paramString)
  {
    Log.d("GIPS", paramString);
  }

  private int GetPlayoutVolume()
  {
    int i = 0;
    if ((this._audioManager == null) && (this._context != null))
    {
      AudioManager localAudioManager = (AudioManager)this._context.getSystemService("audio");
      this._audioManager = localAudioManager;
    }
    int j = -1;
    int k;
    if (this._audioManager != null)
    {
      k = this._audioManager.getStreamVolume(i);
      if (this._streamVolume != k)
        break label70;
    }
    label70: int l;
    for (j = this._volumeLevel; ; j = k * 255 / l)
    {
      return j;
      l = this._audioManager.getStreamMaxVolume(i);
    }
  }

  private int InitPlayback(int paramInt)
  {
    Object localObject1 = 1;
    Object localObject2 = -1;
    Object localObject3 = null;
    int i = AudioTrack.getMinBufferSize(paramInt, 2, 2) * 2;
    this._bufferedPlaySamples = localObject3;
    AudioTrack localAudioTrack = this._audioTrack;
    if (localAudioTrack != null)
    {
      this._audioTrack.release();
      int j = 0;
      this._audioTrack = j;
    }
    Object localObject4;
    try
    {
      int k = paramInt;
      localObject4 = new AudioTrack(null, k, 2, 2, i, 1);
      this._audioTrack = ((AudioTrack)localObject4);
      localObject4 = this._audioTrack.getState();
      if (localObject4 == localObject1)
        break label115;
      localObject4 = localObject2;
      label95: label115: return localObject4;
    }
    catch (Exception localException)
    {
      localObject4 = localException.getMessage();
      GIPSLog((String)localObject4);
      localObject4 = localObject2;
      break label95:
      localObject4 = localObject3;
    }
  }

  private int InitRecording(int paramInt)
  {
    Object localObject1 = 1;
    Object localObject2 = -1;
    int i = AudioRecord.getMinBufferSize(paramInt, 2, 2) * 2;
    int j = paramInt * 5 / 200;
    this._bufferedRecSamples = j;
    AudioRecord localAudioRecord = this._audioRecord;
    if (localAudioRecord != null)
    {
      this._audioRecord.release();
      int k = 0;
      this._audioRecord = k;
    }
    Object localObject3;
    try
    {
      int i1 = paramInt;
      localObject3 = new AudioRecord(1, i1, 2, 2, i);
      this._audioRecord = ((AudioRecord)localObject3);
      localObject3 = this._audioRecord.getState();
      if (localObject3 == localObject1)
        break label120;
      localObject3 = localObject2;
      label100: label120: return localObject3;
    }
    catch (Exception localException)
    {
      localObject3 = localException.getMessage();
      GIPSLog((String)localObject3);
      localObject3 = localObject2;
      break label100:
      int l = this._bufferedRecSamples;
    }
  }

  private int PlayAudio(int paramInt)
  {
    Object localObject1 = null;
    Object localObject2 = this._playLock;
    ((ReentrantLock)localObject2).lock();
    while (true)
    {
      int k;
      label48: int i;
      try
      {
        localObject2 = this._audioTrack;
        if (localObject2 == null)
        {
          this._playLock.unlock();
          int j;
          return j;
        }
        boolean bool1 = this._doPlayInit;
        k = 65517;
      }
      finally
      {
        try
        {
          Process.setThreadPriority(k);
          Object localObject3 = null;
          this._doPlayInit = ((Z)localObject3);
          localObject3 = this._playBuffer;
          byte[] arrayOfByte1 = this._tempBufPlay;
          ((ByteBuffer)localObject3).get(arrayOfByte1);
          localObject3 = this._audioTrack;
          byte[] arrayOfByte2 = this._tempBufPlay;
          int i4 = ((AudioTrack)localObject3).write(arrayOfByte2, 0, paramInt);
          this._playBuffer.rewind();
          int l = this._bufferedPlaySamples;
          int i5 = i4 >> 1;
          l += i5;
          this._bufferedPlaySamples = l;
          boolean bool2 = this._isRecording;
          if (!bool2)
          {
            this._recLock.lock();
            int i6 = this._audioTrack.getPlaybackHeadPosition();
            int i1 = this._playPosition;
            if (i6 < i1)
            {
              Object localObject4 = null;
              this._playPosition = localObject4;
            }
            int i2 = this._bufferedPlaySamples;
            int i7 = this._playPosition;
            int i8 = i6 - i7;
            i2 -= i8;
            this._bufferedPlaySamples = i2;
            i = this._bufferedPlaySamples;
            this._playPosition = i6;
            localObject5 = this._recLock;
            ((ReentrantLock)localObject5).unlock();
          }
          if (i4 == paramInt)
            break label319;
          Object localObject5 = "Could not write all data to sc (written = " + i4 + ", length = " + paramInt + ")";
          GIPSLog((String)localObject5);
          this._playLock.unlock();
          int i3 = -1;
        }
        catch (Exception localException)
        {
          localObject6 = new StringBuilder("Set play thread priority failed: ");
          String str = localException.getMessage();
          localObject6 = str;
          GIPSLog((String)localObject6);
          break label48:
          localObject7 = finally;
          this._playLock.unlock();
          throw localObject7;
        }
      }
      label319: this._playLock.unlock();
      Object localObject6 = i;
    }
  }

  private int RecordAudio(int paramInt)
  {
    Object localObject1 = this._recLock;
    ((ReentrantLock)localObject1).lock();
    while (true)
    {
      int j;
      try
      {
        localObject1 = this._audioRecord;
        if (localObject1 == null)
        {
          this._recLock.unlock();
          int i;
          return i;
        }
        boolean bool1 = this._doRecInit;
        label46: j = 65517;
      }
      finally
      {
        try
        {
          Process.setThreadPriority(j);
          Object localObject2 = null;
          this._doRecInit = ((Z)localObject2);
          this._recBuffer.rewind();
          localObject2 = this._audioRecord;
          byte[] arrayOfByte1 = this._tempBufRec;
          int i3 = ((AudioRecord)localObject2).read(arrayOfByte1, 0, paramInt);
          localObject2 = this._recBuffer;
          byte[] arrayOfByte2 = this._tempBufRec;
          ((ByteBuffer)localObject2).put(arrayOfByte2);
          boolean bool2 = this._isPlaying;
          if (bool2)
          {
            int i4 = this._audioTrack.getPlaybackHeadPosition();
            int k = this._playPosition;
            if (i4 < k)
            {
              Object localObject3 = null;
              this._playPosition = localObject3;
            }
            int l = this._bufferedPlaySamples;
            int i5 = this._playPosition;
            int i6 = i4 - i5;
            l -= i6;
            this._bufferedPlaySamples = l;
            this._playPosition = i4;
          }
          if (i3 == paramInt)
            break label273;
          String str1 = "Could not read all data from sc (read = " + i3 + ", length = " + paramInt + ")";
          GIPSLog(str1);
          this._recLock.unlock();
          int i1 = -1;
        }
        catch (Exception localException)
        {
          Object localObject4 = new StringBuilder("Set rec thread priority failed: ");
          String str2 = localException.getMessage();
          localObject4 = str2;
          GIPSLog((String)localObject4);
          break label46:
          localObject5 = finally;
          this._recLock.unlock();
          throw localObject5;
        }
      }
      label273: this._recLock.unlock();
      int i2 = this._bufferedPlaySamples;
    }
  }

  private int SetPlayoutSpeaker(boolean paramBoolean)
  {
    if ((this._audioManager == null) && (this._context != null))
    {
      AudioManager localAudioManager = (AudioManager)this._context.getSystemService("audio");
      this._audioManager = localAudioManager;
    }
    int i = -1;
    if (this._audioManager != null)
    {
      if ((!Build.VERSION.SDK.equals("3")) && (!Build.VERSION.SDK.equals("4")))
        break label91;
      if (!paramBoolean)
        break label80;
      this._audioManager.setMode(0);
    }
    while (true)
    {
      Object localObject = null;
      return localObject;
      label80: this._audioManager.setMode(2);
      continue;
      label91: this._audioManager.setSpeakerphoneOn(paramBoolean);
    }
  }

  private int SetPlayoutVolume(int paramInt)
  {
    int i = 0;
    if ((this._audioManager == null) && (this._context != null))
    {
      AudioManager localAudioManager1 = (AudioManager)this._context.getSystemService("audio");
      this._audioManager = localAudioManager1;
    }
    int j = -1;
    Object localObject;
    if (this._audioManager != null)
    {
      int k = this._audioManager.getStreamMaxVolume(i);
      this._volumeLevel = paramInt;
      int l = paramInt * k / 255;
      this._streamVolume = l;
      AudioManager localAudioManager2 = this._audioManager;
      int i1 = this._streamVolume;
      localAudioManager2.setStreamVolume(i, i1, i);
      localObject = null;
    }
    return localObject;
  }

  private int StartPlayback()
  {
    try
    {
      AudioTrack localAudioTrack = this._audioTrack;
      localAudioTrack.play();
      this._isPlaying = true;
      localAudioTrack = null;
      return localAudioTrack;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      localIllegalStateException.printStackTrace();
      int i = -1;
    }
  }

  private int StartRecording()
  {
    try
    {
      AudioRecord localAudioRecord = this._audioRecord;
      localAudioRecord.startRecording();
      this._isRecording = true;
      localAudioRecord = null;
      return localAudioRecord;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      localIllegalStateException.printStackTrace();
      int i = -1;
    }
  }

  private int StopPlayback()
  {
    Object localObject1 = null;
    int i = 1;
    Object localObject2 = this._playLock;
    ((ReentrantLock)localObject2).lock();
    try
    {
      if (localObject2 != 3);
    }
    finally
    {
      try
      {
        localObject2 = this._audioTrack;
        ((AudioTrack)localObject2).stop();
        localObject2 = this._audioTrack;
        ((AudioTrack)localObject2).flush();
        this._audioTrack.release();
        localObject2 = null;
        this._audioTrack = ((AudioTrack)localObject2);
        this._doPlayInit = i;
        this._playLock.unlock();
        this._isPlaying = localObject1;
        localObject2 = localObject1;
        label77: return localObject2;
      }
      catch (IllegalStateException j)
      {
        IllegalStateException localIllegalStateException2 = localIllegalStateException1;
        localIllegalStateException2.printStackTrace();
        this._doPlayInit = i;
        this._playLock.unlock();
        int j = -1;
        break label77:
        localObject3 = finally;
        this._doPlayInit = i;
        this._playLock.unlock();
        throw localObject3;
      }
    }
  }

  private int StopRecording()
  {
    Object localObject1 = null;
    int i = 1;
    Object localObject2 = this._recLock;
    ((ReentrantLock)localObject2).lock();
    try
    {
      if (localObject2 != 3);
    }
    finally
    {
      try
      {
        localObject2 = this._audioRecord;
        ((AudioRecord)localObject2).stop();
        this._audioRecord.release();
        localObject2 = null;
        this._audioRecord = ((AudioRecord)localObject2);
        this._doRecInit = i;
        this._recLock.unlock();
        this._isRecording = localObject1;
        localObject2 = localObject1;
        label68: return localObject2;
      }
      catch (IllegalStateException j)
      {
        IllegalStateException localIllegalStateException2 = localIllegalStateException1;
        localIllegalStateException2.printStackTrace();
        this._doRecInit = i;
        this._recLock.unlock();
        int j = -1;
        break label68:
        localObject3 = finally;
        this._doRecInit = i;
        this._recLock.unlock();
        throw localObject3;
      }
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.gipscorp.voiceengine.GIPSSndCardAndroid
 * JD-Core Version:    0.5.4
 */