package com.qq.jce.wup;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

public class WupInfo
{
  private static String clientBuilt;
  private static String clientInfo = null;
  private static String clientNumber;

  static
  {
    clientBuilt = null;
    clientNumber = null;
    try
    {
      InputStream localInputStream = WupInfo.class.getResourceAsStream("/com/qq/jce/wup/wup.properties");
      Properties localProperties = new Properties();
      localProperties.load(localInputStream);
      localInputStream.close();
      clientInfo = localProperties.getProperty("client.info");
      clientBuilt = localProperties.getProperty("client.built");
      clientNumber = localProperties.getProperty("client.number");
      if (clientInfo == null)
        clientInfo = "Tencent Taf";
      if (clientBuilt == null)
        clientBuilt = "unknown";
      if (clientNumber == null)
        clientNumber = "unknown";
      return;
    }
    catch (Throwable localThrowable)
    {
    }
  }

  public static String getClientBuilt()
  {
    return clientBuilt;
  }

  public static String getClientInfo()
  {
    return clientInfo;
  }

  public static String getClientNumber()
  {
    return clientNumber;
  }

  public static void main(String[] paramArrayOfString)
  {
    PrintStream localPrintStream1 = System.out;
    String str1 = showString();
    localPrintStream1.println(str1);
    PrintStream localPrintStream2 = System.out;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Client version: ");
    String str2 = getClientInfo();
    String str3 = str2;
    localPrintStream2.println(str3);
    PrintStream localPrintStream3 = System.out;
    StringBuilder localStringBuilder2 = new StringBuilder().append("Client built:   ");
    String str4 = getClientBuilt();
    String str5 = str4;
    localPrintStream3.println(str5);
    PrintStream localPrintStream4 = System.out;
    StringBuilder localStringBuilder3 = new StringBuilder().append("Client number:  ");
    String str6 = getClientNumber();
    String str7 = str6;
    localPrintStream4.println(str7);
    PrintStream localPrintStream5 = System.out;
    StringBuilder localStringBuilder4 = new StringBuilder().append("OS Name:        ");
    String str8 = System.getProperty("os.name");
    String str9 = str8;
    localPrintStream5.println(str9);
    PrintStream localPrintStream6 = System.out;
    StringBuilder localStringBuilder5 = new StringBuilder().append("OS Version:     ");
    String str10 = System.getProperty("os.version");
    String str11 = str10;
    localPrintStream6.println(str11);
    PrintStream localPrintStream7 = System.out;
    StringBuilder localStringBuilder6 = new StringBuilder().append("Architecture:   ");
    String str12 = System.getProperty("os.arch");
    String str13 = str12;
    localPrintStream7.println(str13);
    PrintStream localPrintStream8 = System.out;
    StringBuilder localStringBuilder7 = new StringBuilder().append("JVM Version:    ");
    String str14 = System.getProperty("java.runtime.version");
    String str15 = str14;
    localPrintStream8.println(str15);
    PrintStream localPrintStream9 = System.out;
    StringBuilder localStringBuilder8 = new StringBuilder().append("JVM Vendor:     ");
    String str16 = System.getProperty("java.vm.vendor");
    String str17 = str16;
    localPrintStream9.println(str17);
  }

  public static String showString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    StringBuilder localStringBuilder1 = new StringBuilder().append("Client version: ");
    String str1 = getClientInfo();
    String str2 = str1 + "\n";
    localStringBuffer.append(str2);
    StringBuilder localStringBuilder2 = new StringBuilder().append("Client built:   ");
    String str3 = getClientBuilt();
    String str4 = str3 + "\n";
    localStringBuffer.append(str4);
    StringBuilder localStringBuilder3 = new StringBuilder().append("Client number:  ");
    String str5 = getClientNumber();
    String str6 = str5 + "\n";
    localStringBuffer.append(str6);
    StringBuilder localStringBuilder4 = new StringBuilder().append("OS Name:        ");
    String str7 = System.getProperty("os.name");
    String str8 = str7 + "\n";
    localStringBuffer.append(str8);
    StringBuilder localStringBuilder5 = new StringBuilder().append("OS Version:     ");
    String str9 = System.getProperty("os.version");
    String str10 = str9 + "\n";
    localStringBuffer.append(str10);
    StringBuilder localStringBuilder6 = new StringBuilder().append("Architecture:   ");
    String str11 = System.getProperty("os.arch");
    String str12 = str11 + "\n";
    localStringBuffer.append(str12);
    StringBuilder localStringBuilder7 = new StringBuilder().append("JVM Version:    ");
    String str13 = System.getProperty("java.runtime.version");
    String str14 = str13 + "\n";
    localStringBuffer.append(str14);
    StringBuilder localStringBuilder8 = new StringBuilder().append("JVM Vendor:     ");
    String str15 = System.getProperty("java.vm.vendor");
    String str16 = str15 + "\n";
    localStringBuffer.append(str16);
    return localStringBuffer.toString();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.WupInfo
 * JD-Core Version:    0.5.4
 */