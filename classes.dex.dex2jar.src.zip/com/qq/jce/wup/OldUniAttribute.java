package com.qq.jce.wup;

import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import dalvik.annotation.Signature;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class OldUniAttribute
{

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "Ljava/util/HashMap", "<", "Ljava/lang/String;", "[B>;>;"})
  protected HashMap _data;
  JceInputStream _is;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "Ljava/lang/Object;", ">;"})
  protected HashMap cachedClassName;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "Ljava/lang/Object;", ">;"})
  private HashMap cachedData;
  protected String encodeName;

  OldUniAttribute()
  {
    HashMap localHashMap1 = new HashMap();
    this._data = localHashMap1;
    HashMap localHashMap2 = new HashMap();
    this.cachedClassName = localHashMap2;
    HashMap localHashMap3 = new HashMap();
    this.cachedData = localHashMap3;
    this.encodeName = "GBK";
    JceInputStream localJceInputStream = new JceInputStream();
    this._is = localJceInputStream;
  }

  @Signature({"(", "Ljava/util/ArrayList", "<", "Ljava/lang/String;", ">;", "Ljava/lang/Object;", ")V"})
  private void checkObjectType(ArrayList paramArrayList, Object paramObject)
  {
    int i = 0;
    if (paramObject.getClass().isArray())
    {
      if (!paramObject.getClass().getComponentType().toString().equals("byte"))
        throw new IllegalArgumentException("only byte[] is supported");
      if (Array.getLength(paramObject) > 0)
      {
        paramArrayList.add("java.util.List");
        Object localObject1 = Array.get(paramObject, i);
        checkObjectType(paramArrayList, localObject1);
      }
    }
    while (true)
    {
      return;
      paramArrayList.add("Array");
      paramArrayList.add("?");
      continue;
      if (paramObject instanceof Array)
        throw new IllegalArgumentException("can not support Array, please use List");
      if (paramObject instanceof List)
      {
        paramArrayList.add("java.util.List");
        List localList = (List)paramObject;
        if (localList.size() > 0)
        {
          Object localObject2 = localList.get(i);
          checkObjectType(paramArrayList, localObject2);
        }
        paramArrayList.add("?");
      }
      if (paramObject instanceof Map)
      {
        paramArrayList.add("java.util.Map");
        Map localMap = (Map)paramObject;
        if (localMap.size() > 0)
        {
          Object localObject3 = localMap.keySet().iterator().next();
          Object localObject4 = localMap.get(localObject3);
          String str1 = localObject3.getClass().getName();
          paramArrayList.add(str1);
          checkObjectType(paramArrayList, localObject4);
        }
        paramArrayList.add("?");
        paramArrayList.add("?");
      }
      String str2 = paramObject.getClass().getName();
      paramArrayList.add(str2);
    }
  }

  private Object getCacheProxy(String paramString)
  {
    Object localObject = null;
    if (this.cachedClassName.containsKey(paramString))
      localObject = this.cachedClassName.get(paramString);
    while (true)
    {
      return localObject;
      localObject = BasicClassTypeUtil.createClassByUni(paramString);
      this.cachedClassName.put(paramString, localObject);
    }
  }

  private void saveDataCache(String paramString, Object paramObject)
  {
    this.cachedData.put(paramString, paramObject);
  }

  public void clearCacheData()
  {
    this.cachedData.clear();
  }

  public boolean containsKey(String paramString)
  {
    return this._data.containsKey(paramString);
  }

  public void decode(byte[] paramArrayOfByte)
  {
    this._is.warp(paramArrayOfByte);
    JceInputStream localJceInputStream = this._is;
    String str = this.encodeName;
    localJceInputStream.setServerEncoding(str);
    HashMap localHashMap1 = new HashMap(1);
    HashMap localHashMap2 = new HashMap(1);
    byte[] arrayOfByte = new byte[null];
    localHashMap2.put("", arrayOfByte);
    localHashMap1.put("", localHashMap2);
    HashMap localHashMap3 = this._is.readMap(localHashMap1, 0, null);
    this._data = localHashMap3;
  }

  public byte[] encode()
  {
    JceOutputStream localJceOutputStream = new JceOutputStream(0);
    String str = this.encodeName;
    localJceOutputStream.setServerEncoding(str);
    HashMap localHashMap = this._data;
    localJceOutputStream.write(localHashMap, 0);
    return JceUtil.getJceBufArray(localJceOutputStream.getByteBuffer());
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object get(String paramString)
    throws ObjectCreateException
  {
    Object localObject1 = null;
    boolean bool1 = this._data.containsKey(paramString);
    int i;
    if (!bool1)
      i = 0;
    while (true)
    {
      return i;
      boolean bool2 = this.cachedData.containsKey(paramString);
      if (bool2)
        localObject2 = this.cachedData.get(paramString);
      HashMap localHashMap = (HashMap)this._data.get(paramString);
      String str1 = null;
      byte[] arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      Object localObject2 = localIterator.hasNext();
      if (localObject2 != 0)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        Object localObject3 = getCacheProxy(str1);
        this._is.warp(arrayOfByte);
        localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is;
        Object localObject4 = ((JceInputStream)localObject2).read(localObject3, 0, true);
        saveDataCache(paramString, localObject4);
        localObject2 = localObject4;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        throw new ObjectCreateException(localException);
      }
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "Ljava/lang/Object;", ")TT;"})
  public Object get(String paramString, Object paramObject)
  {
    Object localObject1 = null;
    boolean bool = this._data.containsKey(paramString);
    Object localObject2;
    if (!bool)
      localObject2 = paramObject;
    while (true)
    {
      return localObject2;
      localObject2 = this.cachedData.containsKey(paramString);
      if (localObject2 != 0)
        localObject2 = this.cachedData.get(paramString);
      HashMap localHashMap = (HashMap)this._data.get(paramString);
      String str1 = "";
      byte[] arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      localObject2 = localIterator.hasNext();
      if (localObject2 != 0)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        Object localObject3 = getCacheProxy(str1);
        this._is.warp(arrayOfByte);
        localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is;
        Object localObject4 = ((JceInputStream)localObject2).read(localObject3, 0, true);
        saveDataCache(paramString, localObject4);
        localObject2 = localObject4;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        saveDataCache(paramString, paramObject);
        localObject2 = paramObject;
      }
    }
  }

  public String getEncodeName()
  {
    return this.encodeName;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object getJceStruct(String paramString)
    throws ObjectCreateException
  {
    Object localObject1 = null;
    boolean bool1 = this._data.containsKey(paramString);
    int i;
    if (!bool1)
      i = 0;
    while (true)
    {
      return i;
      boolean bool2 = this.cachedData.containsKey(paramString);
      if (bool2)
        localObject2 = this.cachedData.get(paramString);
      HashMap localHashMap = (HashMap)this._data.get(paramString);
      String str1 = null;
      byte[] arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      Object localObject2 = localIterator.hasNext();
      if (localObject2 != 0)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        Object localObject3 = getCacheProxy(str1);
        this._is.warp(arrayOfByte);
        localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is;
        JceStruct localJceStruct1 = (JceStruct)localObject3;
        JceStruct localJceStruct2 = ((JceInputStream)localObject2).directRead(localJceStruct1, 0, true);
        saveDataCache(paramString, localJceStruct2);
        localObject2 = localJceStruct2;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        throw new ObjectCreateException(localException);
      }
    }
  }

  @Signature({"()", "Ljava/util/Set", "<", "Ljava/lang/String;", ">;"})
  public Set getKeySet()
  {
    return Collections.unmodifiableSet(this._data.keySet());
  }

  public boolean isEmpty()
  {
    return this._data.isEmpty();
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)V"})
  public void put(String paramString, Object paramObject)
  {
    int i = 1;
    if (paramString == null)
      throw new IllegalArgumentException("put key can not is null");
    if (paramObject == null)
      throw new IllegalArgumentException("put value can not is null");
    if (paramObject instanceof Set)
      throw new IllegalArgumentException("can not support Set");
    JceOutputStream localJceOutputStream = new JceOutputStream();
    String str1 = this.encodeName;
    localJceOutputStream.setServerEncoding(str1);
    localJceOutputStream.write(paramObject, 0);
    byte[] arrayOfByte = JceUtil.getJceBufArray(localJceOutputStream.getByteBuffer());
    HashMap localHashMap = new HashMap(i);
    ArrayList localArrayList = new ArrayList(i);
    checkObjectType(localArrayList, paramObject);
    String str2 = BasicClassTypeUtil.transTypeList(localArrayList);
    localHashMap.put(str2, arrayOfByte);
    this.cachedData.remove(paramString);
    this._data.put(paramString, localHashMap);
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object remove(String paramString)
    throws ObjectCreateException
  {
    Object localObject1 = null;
    boolean bool1 = this._data.containsKey(paramString);
    int i;
    if (!bool1)
      i = 0;
    while (true)
    {
      return i;
      HashMap localHashMap = (HashMap)this._data.remove(paramString);
      String str1 = "";
      byte[] arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      boolean bool2 = localIterator.hasNext();
      if (bool2)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        Object localObject3 = BasicClassTypeUtil.createClassByUni(str1);
        this._is.warp(arrayOfByte);
        Object localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is.read(localObject3, 0, true);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        throw new ObjectCreateException(localException);
      }
    }
  }

  public void setEncodeName(String paramString)
  {
    this.encodeName = paramString;
  }

  public int size()
  {
    return this._data.size();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.OldUniAttribute
 * JD-Core Version:    0.5.4
 */