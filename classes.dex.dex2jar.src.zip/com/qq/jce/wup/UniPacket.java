package com.qq.jce.wup;

import com.qq.taf.RequestPacket;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceUtil;
import dalvik.annotation.Signature;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

public class UniPacket extends UniAttribute
{
  public static final int UniPacketHeadSize = 4;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "Ljava/util/HashMap", "<", "Ljava/lang/String;", "[B>;>;"})
  static HashMap cache__tempdata;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "[B>;"})
  static HashMap newCache__tempdata = null;
  protected RequestPacket _package;
  private int oldRespIret;

  static
  {
    cache__tempdata = null;
  }

  public UniPacket()
  {
    RequestPacket localRequestPacket = new RequestPacket();
    this._package = localRequestPacket;
    this.oldRespIret = null;
    this._package.iVersion = 2;
  }

  public UniPacket(boolean paramBoolean)
  {
    RequestPacket localRequestPacket = new RequestPacket();
    this._package = localRequestPacket;
    this.oldRespIret = null;
    if (paramBoolean)
      useVersion3();
    while (true)
    {
      return;
      this._package.iVersion = 2;
    }
  }

  public byte[] createOldRespEncode()
  {
    JceOutputStream localJceOutputStream1 = new JceOutputStream(0);
    String str1 = this.encodeName;
    localJceOutputStream1.setServerEncoding(str1);
    HashMap localHashMap = this._data;
    localJceOutputStream1.write(localHashMap, 0);
    byte[] arrayOfByte = JceUtil.getJceBufArray(localJceOutputStream1.getByteBuffer());
    JceOutputStream localJceOutputStream2 = new JceOutputStream(0);
    String str2 = this.encodeName;
    localJceOutputStream2.setServerEncoding(str2);
    short s = this._package.iVersion;
    localJceOutputStream2.write(s, 1);
    byte b = this._package.cPacketType;
    localJceOutputStream2.write(b, 2);
    int i = this._package.iRequestId;
    localJceOutputStream2.write(i, 3);
    int j = this._package.iMessageType;
    localJceOutputStream2.write(j, 4);
    int k = this.oldRespIret;
    localJceOutputStream2.write(k, 5);
    localJceOutputStream2.write(arrayOfByte, 6);
    Map localMap = this._package.status;
    localJceOutputStream2.write(localMap, 7);
    return JceUtil.getJceBufArray(localJceOutputStream2.getByteBuffer());
  }

  public UniPacket createResponse()
  {
    UniPacket localUniPacket = new UniPacket();
    int i = getRequestId();
    localUniPacket.setRequestId(i);
    String str1 = getServantName();
    localUniPacket.setServantName(str1);
    String str2 = getFuncName();
    localUniPacket.setFuncName(str2);
    String str3 = this.encodeName;
    localUniPacket.setEncodeName(str3);
    RequestPacket localRequestPacket = localUniPacket._package;
    int j = this._package.iVersion;
    localRequestPacket.iVersion = j;
    return localUniPacket;
  }

  public void decode(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length < 4)
      throw new IllegalArgumentException("decode package must include size head");
    try
    {
      JceInputStream localJceInputStream = new JceInputStream(paramArrayOfByte, 4);
      String str1 = this.encodeName;
      localJceInputStream.setServerEncoding(str1);
      readFrom(localJceInputStream);
      if (this._package.iVersion == 3)
      {
        byte[] arrayOfByte1 = this._package.sBuffer;
        localJceInputStream = new JceInputStream(arrayOfByte1);
        String str2 = this.encodeName;
        localJceInputStream.setServerEncoding(str2);
        if (newCache__tempdata == null)
        {
          newCache__tempdata = new HashMap();
          HashMap localHashMap1 = newCache__tempdata;
          byte[] arrayOfByte2 = new byte[null];
          localHashMap1.put("", arrayOfByte2);
        }
        HashMap localHashMap2 = newCache__tempdata;
        HashMap localHashMap3 = localJceInputStream.readMap(localHashMap2, 0, null);
        this._newData = localHashMap3;
        return;
      }
      this._newData = null;
      byte[] arrayOfByte3 = this._package.sBuffer;
      localJceInputStream = new JceInputStream(arrayOfByte3);
      String str3 = this.encodeName;
      localJceInputStream.setServerEncoding(str3);
      if (cache__tempdata == null)
      {
        cache__tempdata = new HashMap();
        HashMap localHashMap4 = new HashMap();
        byte[] arrayOfByte4 = new byte[null];
        localHashMap4.put("", arrayOfByte4);
        cache__tempdata.put("", localHashMap4);
      }
      HashMap localHashMap5 = cache__tempdata;
      HashMap localHashMap6 = localJceInputStream.readMap(localHashMap5, 0, null);
      this._data = localHashMap6;
      HashMap localHashMap7 = new HashMap();
      this.cachedClassName = localHashMap7;
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }

  public void decodeVersion2(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length < 4)
      throw new IllegalArgumentException("decode package must include size head");
    try
    {
      JceInputStream localJceInputStream = new JceInputStream(paramArrayOfByte, 4);
      String str1 = this.encodeName;
      localJceInputStream.setServerEncoding(str1);
      readFrom(localJceInputStream);
      byte[] arrayOfByte1 = this._package.sBuffer;
      localJceInputStream = new JceInputStream(arrayOfByte1);
      String str2 = this.encodeName;
      localJceInputStream.setServerEncoding(str2);
      if (cache__tempdata == null)
      {
        cache__tempdata = new HashMap();
        HashMap localHashMap1 = new HashMap();
        byte[] arrayOfByte2 = new byte[null];
        localHashMap1.put("", arrayOfByte2);
        cache__tempdata.put("", localHashMap1);
      }
      HashMap localHashMap2 = cache__tempdata;
      HashMap localHashMap3 = localJceInputStream.readMap(localHashMap2, 0, null);
      this._data = localHashMap3;
      HashMap localHashMap4 = new HashMap();
      this.cachedClassName = localHashMap4;
      return;
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }

  public void decodeVersion3(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length < 4)
      throw new IllegalArgumentException("decode package must include size head");
    try
    {
      JceInputStream localJceInputStream = new JceInputStream(paramArrayOfByte, 4);
      String str1 = this.encodeName;
      localJceInputStream.setServerEncoding(str1);
      readFrom(localJceInputStream);
      byte[] arrayOfByte1 = this._package.sBuffer;
      localJceInputStream = new JceInputStream(arrayOfByte1);
      String str2 = this.encodeName;
      localJceInputStream.setServerEncoding(str2);
      if (newCache__tempdata == null)
      {
        newCache__tempdata = new HashMap();
        HashMap localHashMap1 = newCache__tempdata;
        byte[] arrayOfByte2 = new byte[null];
        localHashMap1.put("", arrayOfByte2);
      }
      HashMap localHashMap2 = newCache__tempdata;
      HashMap localHashMap3 = localJceInputStream.readMap(localHashMap2, 0, null);
      this._newData = localHashMap3;
      return;
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    this._package.display(paramStringBuilder, paramInt);
  }

  public byte[] encode()
  {
    int i = 2;
    int j = 0;
    if (this._package.iVersion == i)
    {
      if (this._package.sServantName.equals(""))
        throw new IllegalArgumentException("servantName can not is null");
      if (this._package.sFuncName.equals(""))
        throw new IllegalArgumentException("funcName can not is null");
    }
    else
    {
      if (this._package.sServantName == null)
        this._package.sServantName = "";
      if (this._package.sFuncName == null)
        this._package.sFuncName = "";
    }
    JceOutputStream localJceOutputStream1 = new JceOutputStream(j);
    String str1 = this.encodeName;
    localJceOutputStream1.setServerEncoding(str1);
    if (this._package.iVersion == i)
    {
      HashMap localHashMap1 = this._data;
      localJceOutputStream1.write(localHashMap1, j);
    }
    while (true)
    {
      RequestPacket localRequestPacket = this._package;
      byte[] arrayOfByte1 = JceUtil.getJceBufArray(localJceOutputStream1.getByteBuffer());
      localRequestPacket.sBuffer = arrayOfByte1;
      JceOutputStream localJceOutputStream2 = new JceOutputStream(j);
      String str2 = this.encodeName;
      localJceOutputStream1.setServerEncoding(str2);
      writeTo(localJceOutputStream1);
      byte[] arrayOfByte2 = JceUtil.getJceBufArray(localJceOutputStream1.getByteBuffer());
      int k = arrayOfByte2.length;
      ByteBuffer localByteBuffer = ByteBuffer.allocate(k + 4);
      int l = k + 4;
      localByteBuffer.putInt(l).put(arrayOfByte2).flip();
      return localByteBuffer.array();
      HashMap localHashMap2 = this._newData;
      localJceOutputStream1.write(localHashMap2, j);
    }
  }

  public String getFuncName()
  {
    return this._package.sFuncName;
  }

  public int getOldRespIret()
  {
    return this.oldRespIret;
  }

  public int getPackageVersion()
  {
    return this._package.iVersion;
  }

  public int getRequestId()
  {
    return this._package.iRequestId;
  }

  public String getServantName()
  {
    return this._package.sServantName;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)V"})
  public void put(String paramString, Object paramObject)
  {
    if (paramString.startsWith("."))
    {
      String str = "put name can not startwith . , now is " + paramString;
      throw new IllegalArgumentException(str);
    }
    super.put(paramString, paramObject);
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    this._package.readFrom(paramJceInputStream);
  }

  public void setFuncName(String paramString)
  {
    this._package.sFuncName = paramString;
  }

  public void setOldRespIret(int paramInt)
  {
    this.oldRespIret = paramInt;
  }

  public void setRequestId(int paramInt)
  {
    this._package.iRequestId = paramInt;
  }

  public void setServantName(String paramString)
  {
    this._package.sServantName = paramString;
  }

  public void useVersion3()
  {
    super.useVersion3();
    this._package.iVersion = 3;
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    this._package.writeTo(paramJceOutputStream);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.UniPacket
 * JD-Core Version:    0.5.4
 */