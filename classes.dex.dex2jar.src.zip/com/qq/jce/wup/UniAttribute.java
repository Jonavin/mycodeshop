package com.qq.jce.wup;

import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceUtil;
import dalvik.annotation.Signature;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class UniAttribute extends OldUniAttribute
{
  JceInputStream _is;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "[B>;"})
  protected HashMap _newData = null;

  @Signature({"Ljava/util/HashMap", "<", "Ljava/lang/String;", "Ljava/lang/Object;", ">;"})
  private HashMap cachedData;

  public UniAttribute()
  {
    HashMap localHashMap = new HashMap();
    this.cachedData = localHashMap;
    JceInputStream localJceInputStream = new JceInputStream();
    this._is = localJceInputStream;
  }

  private Object decodeData(byte[] paramArrayOfByte, Object paramObject)
  {
    this._is.warp(paramArrayOfByte);
    JceInputStream localJceInputStream = this._is;
    String str = this.encodeName;
    localJceInputStream.setServerEncoding(str);
    return this._is.read(paramObject, 0, true);
  }

  private void saveDataCache(String paramString, Object paramObject)
  {
    this.cachedData.put(paramString, paramObject);
  }

  public void clearCacheData()
  {
    this.cachedData.clear();
  }

  public boolean containsKey(String paramString)
  {
    Object localObject = this._newData;
    if (localObject != null);
    for (localObject = this._newData.containsKey(paramString); ; localObject = this._data.containsKey(paramString))
      return localObject;
  }

  public void decode(byte[] paramArrayOfByte)
  {
    int i = null;
    try
    {
      super.decode(paramArrayOfByte);
      return;
    }
    catch (Exception localException)
    {
      this._is.warp(paramArrayOfByte);
      JceInputStream localJceInputStream = this._is;
      String str = this.encodeName;
      localJceInputStream.setServerEncoding(str);
      HashMap localHashMap1 = new HashMap(1);
      byte[] arrayOfByte = new byte[i];
      localHashMap1.put("", arrayOfByte);
      HashMap localHashMap2 = this._is.readMap(localHashMap1, i, i);
      this._newData = localHashMap2;
    }
  }

  public void decodeVersion2(byte[] paramArrayOfByte)
  {
    super.decode(paramArrayOfByte);
  }

  public void decodeVersion3(byte[] paramArrayOfByte)
  {
    this._is.warp(paramArrayOfByte);
    JceInputStream localJceInputStream = this._is;
    String str = this.encodeName;
    localJceInputStream.setServerEncoding(str);
    HashMap localHashMap1 = new HashMap(1);
    byte[] arrayOfByte = new byte[null];
    localHashMap1.put("", arrayOfByte);
    HashMap localHashMap2 = this._is.readMap(localHashMap1, 0, null);
    this._newData = localHashMap2;
  }

  public byte[] encode()
  {
    int i = 0;
    Object localObject = this._newData;
    JceOutputStream localJceOutputStream;
    if (localObject != null)
    {
      localJceOutputStream = new JceOutputStream(i);
      localObject = this.encodeName;
      localJceOutputStream.setServerEncoding((String)localObject);
      localObject = this._newData;
      localJceOutputStream.write((Map)localObject, i);
    }
    for (localObject = JceUtil.getJceBufArray(localJceOutputStream.getByteBuffer()); ; localObject = super.encode())
      return localObject;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object get(String paramString)
    throws ObjectCreateException
  {
    if (this._newData != null)
      throw new RuntimeException("data is encoded by new version, please use getByClass(String name, T proxy)");
    return super.get(paramString);
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "Ljava/lang/Object;", ")TT;"})
  public Object get(String paramString, Object paramObject)
  {
    if (this._newData != null)
      throw new RuntimeException("data is encoded by new version, please use get(String name, T proxy, Object defaultValue)");
    return super.get(paramString, paramObject);
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;", "Ljava/lang/Object;", ")TT;"})
  public Object get(String paramString, Object paramObject1, Object paramObject2)
  {
    boolean bool = this._newData.containsKey(paramString);
    if (!bool);
    for (Object localObject = paramObject2; ; localObject = getByClass(paramString, paramObject1))
      return localObject;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)TT;"})
  public Object getByClass(String paramString, Object paramObject)
    throws ObjectCreateException
  {
    int i = 0;
    Object localObject1 = null;
    Object localObject2 = this._newData;
    if (localObject2 != null)
    {
      localObject2 = this._newData.containsKey(paramString);
      if (localObject2 == 0)
        localObject2 = i;
    }
    while (true)
    {
      return localObject2;
      localObject2 = this.cachedData.containsKey(paramString);
      if (localObject2 != 0)
        localObject2 = this.cachedData.get(paramString);
      localObject2 = this._newData;
      byte[] arrayOfByte = (byte[])((HashMap)localObject2).get(paramString);
      Object localObject3;
      try
      {
        localObject3 = decodeData(arrayOfByte, paramObject);
        if (localObject3 != null)
          saveDataCache(paramString, localObject3);
        localObject2 = localObject3;
      }
      catch (Exception localException1)
      {
        throw new ObjectCreateException(localException1);
      }
      localObject2 = this._data.containsKey(paramString);
      if (localObject2 == 0)
        localObject2 = i;
      localObject2 = this.cachedData.containsKey(paramString);
      if (localObject2 != 0)
        localObject2 = this.cachedData.get(paramString);
      HashMap localHashMap = (HashMap)this._data.get(paramString);
      arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      localObject2 = localIterator.hasNext();
      if (localObject2 != 0)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        this._is.warp(arrayOfByte);
        localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is;
        localObject3 = ((JceInputStream)localObject2).read(paramObject, 0, true);
        saveDataCache(paramString, localObject3);
        localObject2 = localObject3;
      }
      catch (Exception localException2)
      {
        throw new ObjectCreateException(localException2);
      }
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;TT;)TT;"})
  public Object getByClass(String paramString, Object paramObject1, Object paramObject2)
    throws ObjectCreateException
  {
    Object localObject1 = null;
    Object localObject2 = this._newData;
    if (localObject2 != null)
    {
      localObject2 = this._newData.containsKey(paramString);
      if (localObject2 == 0)
        localObject2 = paramObject2;
    }
    while (true)
    {
      return localObject2;
      localObject2 = this.cachedData.containsKey(paramString);
      if (localObject2 != 0)
        localObject2 = this.cachedData.get(paramString);
      localObject2 = this._newData;
      byte[] arrayOfByte = (byte[])((HashMap)localObject2).get(paramString);
      Object localObject3;
      try
      {
        localObject3 = decodeData(arrayOfByte, paramObject1);
        if (localObject3 != null)
          saveDataCache(paramString, localObject3);
        localObject2 = localObject3;
      }
      catch (Exception localException1)
      {
        throw new ObjectCreateException(localException1);
      }
      localObject2 = this._data.containsKey(paramString);
      if (localObject2 == 0)
        localObject2 = paramObject2;
      localObject2 = this.cachedData.containsKey(paramString);
      if (localObject2 != 0)
        localObject2 = this.cachedData.get(paramString);
      HashMap localHashMap = (HashMap)this._data.get(paramString);
      arrayOfByte = new byte[localObject1];
      Iterator localIterator = localHashMap.entrySet().iterator();
      localObject2 = localIterator.hasNext();
      if (localObject2 != 0)
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str1 = (String)localEntry.getKey();
        arrayOfByte = (byte[])localEntry.getValue();
      }
      try
      {
        this._is.warp(arrayOfByte);
        localObject2 = this._is;
        String str2 = this.encodeName;
        ((JceInputStream)localObject2).setServerEncoding(str2);
        localObject2 = this._is;
        localObject3 = ((JceInputStream)localObject2).read(paramObject1, 0, true);
        saveDataCache(paramString, localObject3);
        localObject2 = localObject3;
      }
      catch (Exception localException2)
      {
        throw new ObjectCreateException(localException2);
      }
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object getJceStruct(String paramString)
    throws ObjectCreateException
  {
    if (this._newData != null)
      throw new RuntimeException("data is encoded by new version, please use getJceStruct(String name,T proxy)");
    return super.getJceStruct(paramString);
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)TT;"})
  public Object getJceStruct(String paramString, Object paramObject)
    throws ObjectCreateException
  {
    boolean bool1 = this._newData.containsKey(paramString);
    int i;
    if (!bool1)
      i = 0;
    while (true)
    {
      return i;
      boolean bool2 = this.cachedData.containsKey(paramString);
      if (bool2)
        localObject1 = this.cachedData.get(paramString);
      Object localObject1 = this._newData;
      byte[] arrayOfByte = (byte[])((HashMap)localObject1).get(paramString);
      try
      {
        Object localObject2 = decodeData(arrayOfByte, paramObject);
        if (localObject2 != null)
          saveDataCache(paramString, localObject2);
        localObject1 = localObject2;
      }
      catch (Exception localException)
      {
        throw new ObjectCreateException(localException);
      }
    }
  }

  @Signature({"()", "Ljava/util/Set", "<", "Ljava/lang/String;", ">;"})
  public Set getKeySet()
  {
    Object localObject = this._newData;
    if (localObject != null);
    for (localObject = Collections.unmodifiableSet(this._newData.keySet()); ; localObject = Collections.unmodifiableSet(this._data.keySet()))
      return localObject;
  }

  public boolean isEmpty()
  {
    Object localObject = this._newData;
    if (localObject != null);
    for (localObject = this._newData.isEmpty(); ; localObject = this._data.isEmpty())
      return localObject;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)V"})
  public void put(String paramString, Object paramObject)
  {
    if (this._newData != null)
    {
      if (paramString == null)
        throw new IllegalArgumentException("put key can not is null");
      if (paramObject == null)
        throw new IllegalArgumentException("put value can not is null");
      if (paramObject instanceof Set)
        throw new IllegalArgumentException("can not support Set");
      JceOutputStream localJceOutputStream = new JceOutputStream();
      String str = this.encodeName;
      localJceOutputStream.setServerEncoding(str);
      localJceOutputStream.write(paramObject, 0);
      byte[] arrayOfByte = JceUtil.getJceBufArray(localJceOutputStream.getByteBuffer());
      this._newData.put(paramString, arrayOfByte);
    }
    while (true)
    {
      return;
      super.put(paramString, paramObject);
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", ")TT;"})
  public Object remove(String paramString)
    throws ObjectCreateException
  {
    int i = 0;
    Object localObject = this._newData;
    if (localObject != null)
    {
      localObject = this._newData.containsKey(paramString);
      if (localObject != 0);
    }
    for (localObject = i; ; localObject = super.remove(paramString))
      while (true)
      {
        return localObject;
        this._newData.remove(paramString);
        localObject = i;
      }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/lang/String;", "TT;)TT;"})
  public Object remove(String paramString, Object paramObject)
    throws ObjectCreateException
  {
    int i = 0;
    boolean bool = this._newData.containsKey(paramString);
    if (!bool);
    for (Object localObject = i; ; localObject = i)
    {
      while (true)
      {
        return localObject;
        if (paramObject == null)
          break;
        byte[] arrayOfByte = (byte[])this._newData.remove(paramString);
        localObject = decodeData(arrayOfByte, paramObject);
      }
      this._newData.remove(paramString);
    }
  }

  public int size()
  {
    Object localObject = this._newData;
    if (localObject != null);
    for (localObject = this._newData.size(); ; localObject = this._data.size())
      return localObject;
  }

  public void useVersion3()
  {
    HashMap localHashMap = new HashMap();
    this._newData = localHashMap;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.UniAttribute
 * JD-Core Version:    0.5.4
 */