package com.qq.jce.wup;

import dalvik.annotation.Signature;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BasicClassTypeUtil
{
  @Signature({"(", "Ljava/util/ArrayList", "<", "Ljava/lang/String;", ">;", "Ljava/lang/String;", ")V"})
  private static void addType(ArrayList paramArrayList, String paramString)
  {
    int i = 0;
    int j = paramString.length();
    int k;
    do
      k = j - 1;
    while ((paramString.charAt(k) == '>') && (--j != 0));
    String str = uni2JavaType(paramString.substring(i, j));
    paramArrayList.add(i, str);
  }

  public static Object createClassByName(String paramString)
    throws ObjectCreateException
  {
    int i = 0;
    boolean bool = paramString.equals("java.lang.Integer");
    Object localObject;
    if (bool)
      localObject = Integer.valueOf(i);
    while (true)
    {
      return localObject;
      localObject = paramString.equals("java.lang.Boolean");
      if (localObject != 0)
        localObject = Boolean.valueOf(i);
      localObject = paramString.equals("java.lang.Byte");
      if (localObject != 0)
        localObject = Byte.valueOf(i);
      localObject = paramString.equals("java.lang.Double");
      if (localObject != 0)
        localObject = Double.valueOf(0L);
      localObject = paramString.equals("java.lang.Float");
      if (localObject != 0)
        localObject = Float.valueOf(null);
      localObject = paramString.equals("java.lang.Long");
      if (localObject != 0)
        localObject = Long.valueOf(0L);
      localObject = paramString.equals("java.lang.Short");
      if (localObject != 0)
        localObject = Short.valueOf(i);
      localObject = paramString.equals("java.lang.Character");
      if (localObject != 0)
        throw new IllegalArgumentException("can not support java.lang.Character");
      localObject = paramString.equals("java.lang.String");
      if (localObject != 0)
        localObject = "";
      localObject = paramString.equals("java.util.List");
      if (localObject != 0)
        localObject = new ArrayList();
      localObject = paramString.equals("java.util.Map");
      if (localObject != 0)
        localObject = new HashMap();
      localObject = paramString.equals("Array");
      if (localObject != 0)
        localObject = "Array";
      localObject = paramString.equals("?");
      if (localObject != 0)
        localObject = paramString;
      try
      {
        Class localClass = Class.forName(paramString);
        localObject = new Class[null];
        Constructor localConstructor = localClass.getConstructor(localObject);
        localObject = new Object[null];
        localObject = localConstructor.newInstance(localObject);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        throw new ObjectCreateException(localException);
      }
    }
  }

  public static Object createClassByUni(String paramString)
    throws ObjectCreateException
  {
    String str1 = 1;
    Object localObject1 = 0;
    ArrayList localArrayList = getTypeList(paramString);
    int i = 0;
    Iterator localIterator = localArrayList.iterator();
    Object localObject3 = 0;
    Object localObject4 = 0;
    label24: boolean bool1 = localIterator.hasNext();
    Object localObject2;
    String str3;
    Object localObject5;
    if (bool1)
    {
      localObject2 = createClassByName((String)localIterator.next());
      bool1 = localObject2 instanceof String;
      if (bool1)
      {
        str3 = "Array";
        localObject5 = (String)(String)localObject2;
        localObject5 = str3.equals(localObject5);
        if (localObject5 != 0)
        {
          if (localObject4 != 0)
            break label409;
          localObject2 = Array.newInstance(Byte.class, localObject1);
          localObject5 = localObject3;
        }
      }
    }
    for (localObject3 = localObject4; ; localObject3 = localObject4)
    {
      while (true)
      {
        label114: localObject4 = localObject3;
        localObject3 = localObject5;
        break label24:
        str3 = "?";
        localObject5 = (String)(String)localObject2;
        localObject5 = str3.equals(localObject5);
        if (localObject5 != 0)
        {
          localObject5 = localObject3;
          localObject3 = localObject4;
        }
        if (localObject4 == 0)
        {
          Object localObject8 = localObject2;
          localObject5 = localObject3;
          localObject3 = localObject8;
        }
        Object localObject9 = localObject2;
        localObject5 = localObject4;
        localObject3 = localObject9;
        continue;
        boolean bool2 = localObject2 instanceof List;
        if (bool2)
        {
          if (localObject4 != 0)
          {
            bool2 = localObject4 instanceof Byte;
            if (bool2)
            {
              localObject2 = Array.newInstance(Byte.class, str1);
              Array.set(localObject2, localObject1, localObject4);
              localObject6 = localObject3;
              localObject3 = localObject4;
            }
          }
          if (localObject4 != 0)
          {
            localObject6 = (List)localObject2;
            ((List)localObject6).add(localObject4);
          }
          Object localObject6 = localObject3;
          localObject3 = null;
        }
        String str2 = localObject2 instanceof Map;
        if (str2 != 0)
        {
          if (localObject4 != 0)
          {
            str2 = str1;
            label307: if (localObject3 == 0)
              break label365;
          }
          for (str3 = str1; ; str3 = localObject1)
          {
            str2 &= str3;
            if (str2 != 0)
            {
              localObject7 = (Map)localObject2;
              ((Map)localObject7).put(localObject4, localObject3);
            }
            localObject4 = null;
            localObject7 = localObject4;
            localObject3 = 0;
            break label114:
            localObject7 = localObject1;
            label365: break label307:
          }
        }
        if (localObject4 == 0)
        {
          Object localObject10 = localObject2;
          localObject7 = localObject3;
          localObject3 = localObject10;
        }
        Object localObject11 = localObject2;
        localObject7 = localObject4;
        localObject3 = localObject11;
      }
      return localObject2;
      label409: Object localObject7 = localObject3;
    }
  }

  public static String getClassTransName(String paramString)
  {
    if (paramString.equals("int"));
    for (paramString = "Integer"; ; paramString = "Character")
      do
        while (true)
        {
          return paramString;
          if (paramString.equals("boolean"))
            paramString = "Boolean";
          if (paramString.equals("byte"))
            paramString = "Byte";
          if (paramString.equals("double"))
            paramString = "Double";
          if (paramString.equals("float"))
            paramString = "Float";
          if (paramString.equals("long"))
            paramString = "Long";
          if (!paramString.equals("short"))
            break;
          paramString = "Short";
        }
      while (!paramString.equals("char"));
  }

  @Signature({"(", "Ljava/lang/String;", ")", "Ljava/util/ArrayList", "<", "Ljava/lang/String;", ">;"})
  public static ArrayList getTypeList(String paramString)
  {
    int i = -1;
    ArrayList localArrayList = new ArrayList();
    int j = 0;
    int k = paramString.indexOf("<");
    int l = -1;
    while (j < k)
    {
      String str1 = paramString.substring(j, k);
      addType(localArrayList, str1);
      j = k + 1;
      k = paramString.indexOf("<", j);
      int i1 = paramString.indexOf(",", j);
      if (k == i)
        k = i1;
      if ((i1 == i) || (i1 >= k))
        continue;
      k = i1;
    }
    int i2 = paramString.length();
    String str2 = paramString.substring(j, i2);
    addType(localArrayList, str2);
    return localArrayList;
  }

  public static String getVariableInit(String paramString1, String paramString2)
  {
    boolean bool = paramString2.equals("int");
    if (bool);
    for (Object localObject = paramString2 + " " + paramString1 + "=0 ;\n"; ; localObject = paramString2 + " " + paramString1 + " = null ;\n")
      while (true)
      {
        return localObject;
        localObject = paramString2.equals("boolean");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + "=false ;\n";
        localObject = paramString2.equals("byte");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + " ;\n";
        localObject = paramString2.equals("double");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + "=0 ;\n";
        localObject = paramString2.equals("float");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + "=0 ;\n";
        localObject = paramString2.equals("long");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + "=0 ;\n";
        localObject = paramString2.equals("short");
        if (localObject != 0)
          localObject = paramString2 + " " + paramString1 + "=0 ;\n";
        localObject = paramString2.equals("char");
        if (localObject == 0)
          break;
        localObject = paramString2 + " " + paramString1 + " ;\n";
      }
  }

  public static boolean isBasicType(String paramString)
  {
    boolean bool1 = true;
    boolean bool2 = paramString.equals("int");
    if (bool2)
      bool2 = bool1;
    while (true)
    {
      return bool2;
      bool2 = paramString.equals("boolean");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("byte");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("double");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("float");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("long");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("short");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("char");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Integer");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Boolean");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Byte");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Double");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Float");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Long");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Short");
      if (bool2)
        bool2 = bool1;
      bool2 = paramString.equals("Char");
      if (bool2)
        bool2 = bool1;
      Object localObject = null;
    }
  }

  public static String java2UniType(String paramString)
  {
    boolean bool = paramString.equals("java.lang.Integer");
    if (!bool)
    {
      bool = paramString.equals("int");
      if (!bool)
        break label28;
    }
    for (Object localObject = "int32"; ; localObject = paramString)
      while (true)
      {
        return localObject;
        label28: localObject = paramString.equals("java.lang.Boolean");
        if (localObject == 0)
        {
          localObject = paramString.equals("boolean");
          if (localObject == 0)
            break label57;
        }
        localObject = "bool";
        continue;
        label57: localObject = paramString.equals("java.lang.Byte");
        if (localObject == 0)
        {
          localObject = paramString.equals("byte");
          if (localObject == 0)
            break label85;
        }
        localObject = "char";
        continue;
        label85: localObject = paramString.equals("java.lang.Double");
        if (localObject == 0)
        {
          localObject = paramString.equals("double");
          if (localObject == 0)
            break label113;
        }
        localObject = "double";
        continue;
        label113: localObject = paramString.equals("java.lang.Float");
        if (localObject == 0)
        {
          localObject = paramString.equals("float");
          if (localObject == 0)
            break label141;
        }
        localObject = "float";
        continue;
        label141: localObject = paramString.equals("java.lang.Long");
        if (localObject == 0)
        {
          localObject = paramString.equals("long");
          if (localObject == 0)
            break label170;
        }
        localObject = "int64";
        continue;
        label170: localObject = paramString.equals("java.lang.Short");
        if (localObject == 0)
        {
          localObject = paramString.equals("short");
          if (localObject == 0)
            break label198;
        }
        localObject = "short";
        continue;
        label198: localObject = paramString.equals("java.lang.Character");
        if (localObject != 0)
          throw new IllegalArgumentException("can not support java.lang.Character");
        localObject = paramString.equals("java.lang.String");
        if (localObject != 0)
          localObject = "string";
        localObject = paramString.equals("java.util.List");
        if (localObject != 0)
          localObject = "list";
        localObject = paramString.equals("java.util.Map");
        if (localObject == 0)
          break;
        localObject = "map";
      }
  }

  public static void main(String[] paramArrayOfString)
  {
    ArrayList localArrayList1 = new ArrayList();
    localArrayList1.add("char");
    localArrayList1.add("list<char>");
    localArrayList1.add("list<list<char>>");
    localArrayList1.add("map<short,string>");
    localArrayList1.add("map<double,map<float,list<bool>>>");
    localArrayList1.add("map<int64,list<Test.UserInfo>>");
    localArrayList1.add("map<short,Test.FriendInfo>");
    Iterator localIterator1 = localArrayList1.iterator();
    while (localIterator1.hasNext())
    {
      ArrayList localArrayList2 = getTypeList((String)localIterator1.next());
      Iterator localIterator2 = localArrayList2.iterator();
      while (localIterator2.hasNext())
      {
        String str1 = (String)localIterator2.next();
        System.out.println(str1);
      }
      Collections.reverse(localArrayList2);
      PrintStream localPrintStream = System.out;
      StringBuilder localStringBuilder = new StringBuilder().append("-------------finished ");
      String str2 = transTypeList(localArrayList2);
      String str3 = str2;
      localPrintStream.println(str3);
    }
  }

  @Signature({"(", "Ljava/util/ArrayList", "<", "Ljava/lang/String;", ">;)", "Ljava/lang/String;"})
  public static String transTypeList(ArrayList paramArrayList)
  {
    int i = 1;
    int j = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    for (int k = 0; ; ++k)
    {
      int l = paramArrayList.size();
      if (k >= l)
        break;
      String str1 = java2UniType((String)paramArrayList.get(k));
      paramArrayList.set(k, str1);
    }
    Collections.reverse(paramArrayList);
    k = 0;
    label64: int i1 = paramArrayList.size();
    if (k < i1)
    {
      String str2 = (String)paramArrayList.get(k);
      if (str2.equals("list"))
      {
        int i2 = k - i;
        StringBuilder localStringBuilder1 = new StringBuilder().append("<");
        int i3 = k - i;
        String str3 = (String)paramArrayList.get(i3);
        String str4 = str3;
        paramArrayList.set(i2, str4);
        StringBuilder localStringBuilder2 = new StringBuilder();
        String str5 = (String)paramArrayList.get(j);
        String str6 = str5 + ">";
        paramArrayList.set(j, str6);
      }
      while (true)
      {
        ++k;
        break label64:
        if (str2.equals("map"))
        {
          int i4 = k - i;
          StringBuilder localStringBuilder3 = new StringBuilder().append("<");
          int i5 = k - i;
          String str7 = (String)paramArrayList.get(i5);
          String str8 = str7 + ",";
          paramArrayList.set(i4, str8);
          StringBuilder localStringBuilder4 = new StringBuilder();
          String str9 = (String)paramArrayList.get(j);
          String str10 = str9 + ">";
          paramArrayList.set(j, str10);
        }
        if (!str2.equals("Array"))
          continue;
        int i6 = k - i;
        StringBuilder localStringBuilder5 = new StringBuilder().append("<");
        int i7 = k - i;
        String str11 = (String)paramArrayList.get(i7);
        String str12 = str11;
        paramArrayList.set(i6, str12);
        StringBuilder localStringBuilder6 = new StringBuilder();
        String str13 = (String)paramArrayList.get(j);
        String str14 = str13 + ">";
        paramArrayList.set(j, str14);
      }
    }
    Collections.reverse(paramArrayList);
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      String str15 = (String)localIterator.next();
      localStringBuffer.append(str15);
    }
    return localStringBuffer.toString();
  }

  public static String uni2JavaType(String paramString)
  {
    boolean bool = paramString.equals("int32");
    if (bool);
    for (Object localObject = "java.lang.Integer"; ; localObject = paramString)
      while (true)
      {
        return localObject;
        localObject = paramString.equals("bool");
        if (localObject != 0)
          localObject = "java.lang.Boolean";
        localObject = paramString.equals("char");
        if (localObject != 0)
          localObject = "java.lang.Byte";
        localObject = paramString.equals("double");
        if (localObject != 0)
          localObject = "java.lang.Double";
        localObject = paramString.equals("float");
        if (localObject != 0)
          localObject = "java.lang.Float";
        localObject = paramString.equals("int64");
        if (localObject != 0)
          localObject = "java.lang.Long";
        localObject = paramString.equals("short");
        if (localObject != 0)
          localObject = "java.lang.Short";
        localObject = paramString.equals("string");
        if (localObject != 0)
          localObject = "java.lang.String";
        localObject = paramString.equals("list");
        if (localObject != 0)
          localObject = "java.util.List";
        localObject = paramString.equals("map");
        if (localObject == 0)
          break;
        localObject = "java.util.Map";
      }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.BasicClassTypeUtil
 * JD-Core Version:    0.5.4
 */