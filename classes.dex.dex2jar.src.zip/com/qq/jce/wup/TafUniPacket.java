package com.qq.jce.wup;

import com.qq.taf.RequestPacket;
import dalvik.annotation.Signature;
import java.util.HashMap;
import java.util.Map;

public class TafUniPacket extends UniPacket
{
  private static final long serialVersionUID = 1L;

  public TafUniPacket()
  {
    this._package.iVersion = 2;
    this._package.cPacketType = null;
    this._package.iMessageType = null;
    this._package.iTimeout = null;
    RequestPacket localRequestPacket1 = this._package;
    byte[] arrayOfByte = new byte[null];
    localRequestPacket1.sBuffer = arrayOfByte;
    RequestPacket localRequestPacket2 = this._package;
    HashMap localHashMap1 = new HashMap();
    localRequestPacket2.context = localHashMap1;
    RequestPacket localRequestPacket3 = this._package;
    HashMap localHashMap2 = new HashMap();
    localRequestPacket3.status = localHashMap2;
  }

  public byte[] getTafBuffer()
  {
    return this._package.sBuffer;
  }

  @Signature({"()", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  public Map getTafContext()
  {
    return this._package.context;
  }

  public int getTafMessageType()
  {
    return this._package.iMessageType;
  }

  public byte getTafPacketType()
  {
    return this._package.cPacketType;
  }

  public int getTafResultCode()
  {
    String str = (String)this._package.status.get("STATUS_RESULT_CODE");
    int i;
    if (str != null)
      i = Integer.parseInt(str);
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public String getTafResultDesc()
  {
    String str1 = (String)this._package.status.get("STATUS_RESULT_DESC");
    if (str1 != null);
    for (String str2 = str1; ; str2 = "")
      return str2;
  }

  @Signature({"()", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  public Map getTafStatus()
  {
    return this._package.status;
  }

  public int getTafTimeout()
  {
    return this._package.iTimeout;
  }

  public short getTafVersion()
  {
    return this._package.iVersion;
  }

  public void setTafBuffer(byte[] paramArrayOfByte)
  {
    this._package.sBuffer = paramArrayOfByte;
  }

  @Signature({"(", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;)V"})
  public void setTafContext(Map paramMap)
  {
    this._package.context = paramMap;
  }

  public void setTafMessageType(int paramInt)
  {
    this._package.iMessageType = paramInt;
  }

  public void setTafPacketType(byte paramByte)
  {
    this._package.cPacketType = paramByte;
  }

  @Signature({"(", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;)V"})
  public void setTafStatus(Map paramMap)
  {
    this._package.status = paramMap;
  }

  public void setTafTimeout(int paramInt)
  {
    this._package.iTimeout = paramInt;
  }

  public void setTafVersion(short paramShort)
  {
    this._package.iVersion = paramShort;
    if (paramShort != 3)
      return;
    useVersion3();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.TafUniPacket
 * JD-Core Version:    0.5.4
 */