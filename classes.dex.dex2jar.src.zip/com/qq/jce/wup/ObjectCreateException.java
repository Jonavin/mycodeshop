package com.qq.jce.wup;

public class ObjectCreateException extends RuntimeException
{
  public ObjectCreateException(Exception paramException)
  {
    super(paramException);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.jce.wup.ObjectCreateException
 * JD-Core Version:    0.5.4
 */