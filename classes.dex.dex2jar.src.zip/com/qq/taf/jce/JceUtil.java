package com.qq.taf.jce;

import dalvik.annotation.Signature;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.List;

public final class JceUtil
{
  private static final byte[] highDigits;
  private static final int iConstant = 37;
  private static final int iTotal = 17;
  private static final byte[] lowDigits;

  static
  {
    int i = 256;
    byte[] arrayOfByte1 = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
    byte[] arrayOfByte2 = new byte[i];
    byte[] arrayOfByte3 = new byte[i];
    for (int j = 0; j < i; ++j)
    {
      int k = j >>> 4;
      int l = arrayOfByte1[k];
      arrayOfByte2[j] = l;
      int i1 = j & 0xF;
      int i2 = arrayOfByte1[i1];
      arrayOfByte3[j] = i2;
    }
    highDigits = arrayOfByte2;
    lowDigits = arrayOfByte3;
  }

  public static int compareTo(byte paramByte1, byte paramByte2)
  {
    int i;
    if (paramByte1 < paramByte2)
      i = -1;
    while (true)
    {
      return i;
      if (paramByte1 > paramByte2)
        i = 1;
      Object localObject = null;
    }
  }

  public static int compareTo(char paramChar1, char paramChar2)
  {
    int i;
    if (paramChar1 < paramChar2)
      i = -1;
    while (true)
    {
      return i;
      if (paramChar1 > paramChar2)
        i = 1;
      Object localObject = null;
    }
  }

  public static int compareTo(double paramDouble1, double paramDouble2)
  {
    paramDouble2 = paramDouble1 < ???;
    if (paramDouble2 < 0)
      paramDouble2 = -1;
    while (true)
    {
      return paramDouble2;
      paramDouble2 = paramDouble1 < ???;
      if (paramDouble2 > 0)
        paramDouble2 = 1;
      paramDouble2 = null;
    }
  }

  public static int compareTo(float paramFloat1, float paramFloat2)
  {
    float f1 = paramFloat1 < paramFloat2;
    int i;
    if (f1 < 0)
      i = -1;
    while (true)
    {
      return i;
      float f2 = paramFloat1 < paramFloat2;
      if (f2 > 0)
        int j = 1;
      Object localObject = null;
    }
  }

  public static int compareTo(int paramInt1, int paramInt2)
  {
    int i;
    if (paramInt1 < paramInt2)
      i = -1;
    while (true)
    {
      return i;
      if (paramInt1 > paramInt2)
        i = 1;
      Object localObject = null;
    }
  }

  public static int compareTo(long paramLong1, long paramLong2)
  {
    paramLong2 = paramLong1 < ???;
    if (paramLong2 < 0)
      paramLong2 = -1;
    while (true)
    {
      return paramLong2;
      paramLong2 = paramLong1 < ???;
      if (paramLong2 > 0)
        paramLong2 = 1;
      paramLong2 = null;
    }
  }

  @Signature({"<T::", "Ljava/lang/Comparable", "<TT;>;>(TT;TT;)I"})
  public static int compareTo(Comparable paramComparable1, Comparable paramComparable2)
  {
    return paramComparable1.compareTo(paramComparable2);
  }

  @Signature({"<T::", "Ljava/lang/Comparable", "<TT;>;>(", "Ljava/util/List", "<TT;>;", "Ljava/util/List", "<TT;>;)I"})
  public static int compareTo(List paramList1, List paramList2)
  {
    Iterator localIterator1 = paramList1.iterator();
    Iterator localIterator2 = paramList2.iterator();
    int i;
    do
    {
      boolean bool1 = localIterator1.hasNext();
      if (!bool1)
        break label82;
      bool1 = localIterator2.hasNext();
      if (!bool1)
        break label82;
      Comparable localComparable = (Comparable)localIterator1.next();
      localObject = localIterator2.next();
      i = localComparable.compareTo(localObject);
    }
    while (i == 0);
    Object localObject = i;
    while (true)
    {
      return localObject;
      label82: localObject = localIterator1.hasNext();
      boolean bool2 = localIterator2.hasNext();
      localObject = compareTo(localObject, bool2);
    }
  }

  public static int compareTo(short paramShort1, short paramShort2)
  {
    int i;
    if (paramShort1 < paramShort2)
      i = -1;
    while (true)
    {
      return i;
      if (paramShort1 > paramShort2)
        i = 1;
      Object localObject = null;
    }
  }

  public static int compareTo(boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int i;
    if (paramBoolean1)
      i = localObject1;
    while (true)
    {
      if (paramBoolean2)
        localObject2 = localObject1;
      return i - localObject2;
      Object localObject3 = localObject2;
    }
  }

  public static int compareTo(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfByte1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfByte2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfByte1[localObject1];
        byte b = paramArrayOfByte2[localObject2];
        int l = compareTo(i, b);
        if (l != 0)
          i = l;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      int j = paramArrayOfByte1.length;
      int i1 = paramArrayOfByte2.length;
      int k = compareTo(j, i1);
    }
  }

  public static int compareTo(char[] paramArrayOfChar1, char[] paramArrayOfChar2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfChar1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfChar2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfChar1[localObject1];
        char c = paramArrayOfChar2[localObject2];
        int l = compareTo(i, c);
        if (l != 0)
          i = l;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      int j = paramArrayOfChar1.length;
      int i1 = paramArrayOfChar2.length;
      int k = compareTo(j, i1);
    }
  }

  public static int compareTo(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfDouble1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfDouble2.length;
      if (localObject2 < i)
      {
        long l1 = paramArrayOfDouble1[localObject1];
        long l2 = paramArrayOfDouble2[localObject2];
        int k = compareTo(l1, l2);
        if (k != 0)
          i = k;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      i = paramArrayOfDouble1.length;
      int l = paramArrayOfDouble2.length;
      int j = compareTo(i, l);
    }
  }

  public static int compareTo(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfFloat1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfFloat2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfFloat1[localObject1];
        int k = paramArrayOfFloat2[localObject2];
        int l = compareTo(i, k);
        if (l != 0)
          i = l;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      i = paramArrayOfFloat1.length;
      int i1 = paramArrayOfFloat2.length;
      int j = compareTo(i, i1);
    }
  }

  public static int compareTo(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfInt1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfInt2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfInt1[localObject1];
        int k = paramArrayOfInt2[localObject2];
        int l = compareTo(i, k);
        if (l != 0)
          i = l;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      i = paramArrayOfInt1.length;
      int i1 = paramArrayOfInt2.length;
      int j = compareTo(i, i1);
    }
  }

  public static int compareTo(long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfLong1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfLong2.length;
      if (localObject2 < i)
      {
        long l1 = paramArrayOfLong1[localObject1];
        long l2 = paramArrayOfLong2[localObject2];
        int k = compareTo(l1, l2);
        if (k != 0)
          i = k;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      i = paramArrayOfLong1.length;
      int l = paramArrayOfLong2.length;
      int j = compareTo(i, l);
    }
  }

  @Signature({"<T::", "Ljava/lang/Comparable", "<TT;>;>([TT;[TT;)I"})
  public static int compareTo(Comparable[] paramArrayOfComparable1, Comparable[] paramArrayOfComparable2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfComparable1.length;
    Comparable localComparable1;
    if (localObject1 < i)
    {
      i = paramArrayOfComparable2.length;
      if (localObject2 < i)
      {
        localComparable1 = paramArrayOfComparable1[localObject1];
        Comparable localComparable2 = paramArrayOfComparable2[localObject2];
        int l = localComparable1.compareTo(localComparable2);
        if (l != 0)
          localComparable1 = l;
      }
    }
    while (true)
    {
      return localComparable1;
      ++localObject1;
      ++localObject2;
      break label4:
      int j = paramArrayOfComparable1.length;
      int i1 = paramArrayOfComparable2.length;
      int k = compareTo(j, i1);
    }
  }

  public static int compareTo(short[] paramArrayOfShort1, short[] paramArrayOfShort2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfShort1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfShort2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfShort1[localObject1];
        short s = paramArrayOfShort2[localObject2];
        int l = compareTo(i, s);
        if (l != 0)
          i = l;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      int j = paramArrayOfShort1.length;
      int i1 = paramArrayOfShort2.length;
      int k = compareTo(j, i1);
    }
  }

  public static int compareTo(boolean[] paramArrayOfBoolean1, boolean[] paramArrayOfBoolean2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    label4: int i = paramArrayOfBoolean1.length;
    if (localObject1 < i)
    {
      i = paramArrayOfBoolean2.length;
      if (localObject2 < i)
      {
        i = paramArrayOfBoolean1[localObject1];
        int l = paramArrayOfBoolean2[localObject2];
        int i1 = compareTo(i, l);
        if (i1 != 0)
          i = i1;
      }
    }
    while (true)
    {
      return i;
      ++localObject1;
      ++localObject2;
      break label4:
      int j = paramArrayOfBoolean1.length;
      int i2 = paramArrayOfBoolean2.length;
      int k = compareTo(j, i2);
    }
  }

  public static boolean equals(byte paramByte1, byte paramByte2)
  {
    int i;
    if (paramByte1 == paramByte2)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static boolean equals(char paramChar1, char paramChar2)
  {
    int i;
    if (paramChar1 == paramChar2)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static boolean equals(double paramDouble1, double paramDouble2)
  {
    paramDouble2 = paramDouble1 < ???;
    if (paramDouble2 == 0)
      paramDouble2 = 1;
    while (true)
    {
      return paramDouble2;
      paramDouble2 = null;
    }
  }

  public static boolean equals(float paramFloat1, float paramFloat2)
  {
    float f = paramFloat1 < paramFloat2;
    int i;
    if (f == 0)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static boolean equals(int paramInt1, int paramInt2)
  {
    int i;
    if (paramInt1 == paramInt2)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static boolean equals(long paramLong1, long paramLong2)
  {
    paramLong2 = paramLong1 < ???;
    if (paramLong2 == 0)
      paramLong2 = 1;
    while (true)
    {
      return paramLong2;
      paramLong2 = null;
    }
  }

  public static boolean equals(Object paramObject1, Object paramObject2)
  {
    return paramObject1.equals(paramObject2);
  }

  public static boolean equals(short paramShort1, short paramShort2)
  {
    int i;
    if (paramShort1 == paramShort2)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static boolean equals(boolean paramBoolean1, boolean paramBoolean2)
  {
    int i;
    if (paramBoolean1 == paramBoolean2)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public static String getHexdump(ByteBuffer paramByteBuffer)
  {
    int i = paramByteBuffer.remaining();
    if (i == 0);
    StringBuffer localStringBuffer;
    String str2;
    for (String str1 = "empty"; ; str2 = localStringBuffer.toString())
    {
      return str1;
      int j = paramByteBuffer.remaining() * 3 - 1;
      localStringBuffer = new StringBuffer(j);
      int k = paramByteBuffer.position();
      int l = paramByteBuffer.get() & 0xFF;
      j = (char)highDigits[l];
      localStringBuffer.append(j);
      char c = (char)lowDigits[l];
      localStringBuffer.append(c);
      --i;
      while (i > 0)
      {
        localStringBuffer.append(' ');
        int i1 = paramByteBuffer.get() & 0xFF;
        c = (char)highDigits[i1];
        localStringBuffer.append(c);
        c = (char)lowDigits[i1];
        localStringBuffer.append(c);
        --i;
      }
      paramByteBuffer.position(k);
    }
  }

  public static String getHexdump(byte[] paramArrayOfByte)
  {
    return getHexdump(ByteBuffer.wrap(paramArrayOfByte));
  }

  public static byte[] getJceBufArray(ByteBuffer paramByteBuffer)
  {
    byte[] arrayOfByte1 = new byte[paramByteBuffer.position()];
    byte[] arrayOfByte2 = paramByteBuffer.array();
    int i = arrayOfByte1.length;
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, i);
    return arrayOfByte1;
  }

  public static int hashCode(byte paramByte)
  {
    return paramByte + 629;
  }

  public static int hashCode(char paramChar)
  {
    return paramChar + 'ɵ';
  }

  public static int hashCode(double paramDouble)
  {
    return hashCode(Double.doubleToLongBits(paramDouble));
  }

  public static int hashCode(float paramFloat)
  {
    return Float.floatToIntBits(paramFloat) + 629;
  }

  public static int hashCode(int paramInt)
  {
    return paramInt + 629;
  }

  public static int hashCode(long paramLong)
  {
    return (int)(paramLong >> 32 ^ paramLong) + 629;
  }

  public static int hashCode(Object paramObject)
  {
    if (paramObject == null);
    int i7;
    for (int i = 629; ; i7 = paramObject.hashCode() + 629)
      while (true)
      {
        return i;
        boolean bool1 = paramObject.getClass().isArray();
        if (bool1)
        {
          bool1 = paramObject instanceof long[];
          if (bool1)
            int j = hashCode((long[])(long[])paramObject);
          boolean bool2 = paramObject instanceof int[];
          if (bool2)
            int k = hashCode((int[])(int[])paramObject);
          boolean bool3 = paramObject instanceof short[];
          if (bool3)
            int l = hashCode((short[])(short[])paramObject);
          boolean bool4 = paramObject instanceof char[];
          if (bool4)
            int i1 = hashCode((char[])(char[])paramObject);
          boolean bool5 = paramObject instanceof byte[];
          if (bool5)
            int i2 = hashCode((byte[])(byte[])paramObject);
          boolean bool6 = paramObject instanceof double[];
          if (bool6)
            int i3 = hashCode((double[])(double[])paramObject);
          boolean bool7 = paramObject instanceof float[];
          if (bool7)
            int i4 = hashCode((float[])(float[])paramObject);
          boolean bool8 = paramObject instanceof boolean[];
          if (bool8)
            int i5 = hashCode((boolean[])(boolean[])paramObject);
          boolean bool9 = paramObject instanceof JceStruct[];
          if (bool9)
            i6 = hashCode((JceStruct[])(JceStruct[])paramObject);
          int i6 = hashCode((Object[])(Object[])paramObject);
        }
        boolean bool10 = paramObject instanceof JceStruct;
        if (!bool10)
          break;
        i7 = paramObject.hashCode();
      }
  }

  public static int hashCode(short paramShort)
  {
    return paramShort + 629;
  }

  public static int hashCode(boolean paramBoolean)
  {
    Object localObject;
    if (paramBoolean)
      localObject = null;
    while (true)
    {
      return localObject + 629;
      int i = 1;
    }
  }

  public static int hashCode(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfByte.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = paramArrayOfByte[localObject];
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfChar.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = paramArrayOfChar[localObject];
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject1 = null;
      while (true)
      {
        i = paramArrayOfDouble.length;
        if (localObject1 >= i)
          break;
        i = j * 37;
        long l1 = Double.doubleToLongBits(paramArrayOfDouble[localObject1]);
        long l2 = Double.doubleToLongBits(paramArrayOfDouble[localObject1]) >> 32;
        Object localObject2;
        int k = (int)(localObject2 ^ l2);
        j = i + k;
        ++localObject1;
      }
    }
  }

  public static int hashCode(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfFloat.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = Float.floatToIntBits(paramArrayOfFloat[localObject]);
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfInt.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = paramArrayOfInt[localObject];
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(long[] paramArrayOfLong)
  {
    if (paramArrayOfLong == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfLong.length;
        if (localObject >= i)
          break;
        i = j * 37;
        long l1 = paramArrayOfLong[localObject];
        long l2 = paramArrayOfLong[localObject] >> 32;
        int k = (int)(l1 ^ l2);
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(JceStruct[] paramArrayOfJceStruct)
  {
    if (paramArrayOfJceStruct == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfJceStruct.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = paramArrayOfJceStruct[localObject].hashCode();
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(short[] paramArrayOfShort)
  {
    if (paramArrayOfShort == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfShort.length;
        if (localObject >= i)
          break;
        i = j * 37;
        int k = paramArrayOfShort[localObject];
        j = i + k;
        ++localObject;
      }
    }
  }

  public static int hashCode(boolean[] paramArrayOfBoolean)
  {
    if (paramArrayOfBoolean == null);
    int j;
    for (int i = 629; ; i = j)
    {
      return i;
      j = 17;
      Object localObject1 = null;
      label15: i = paramArrayOfBoolean.length;
      if (localObject1 >= i)
        continue;
      i = j * 37;
      int k = paramArrayOfBoolean[localObject1];
      Object localObject2;
      if (k != 0)
        localObject2 = null;
      while (true)
      {
        j = i + localObject2;
        ++localObject1;
        break label15:
        int l = 1;
      }
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceUtil
 * JD-Core Version:    0.5.4
 */