package com.qq.taf.jce;

public class JceEncodeException extends RuntimeException
{
  public JceEncodeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceEncodeException
 * JD-Core Version:    0.5.4
 */