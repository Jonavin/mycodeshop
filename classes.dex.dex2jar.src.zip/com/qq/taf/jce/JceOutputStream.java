package com.qq.taf.jce;

import dalvik.annotation.Signature;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class JceOutputStream
{
  private ByteBuffer bs;
  protected String sServerEncoding = "GBK";

  public JceOutputStream()
  {
    this(128);
  }

  public JceOutputStream(int paramInt)
  {
    ByteBuffer localByteBuffer = ByteBuffer.allocate(paramInt);
    this.bs = localByteBuffer;
  }

  public JceOutputStream(ByteBuffer paramByteBuffer)
  {
    this.bs = paramByteBuffer;
  }

  public static void main(String[] paramArrayOfString)
  {
    JceOutputStream localJceOutputStream = new JceOutputStream();
    localJceOutputStream.write(1311768467283714885L, 0);
    ByteBuffer localByteBuffer = localJceOutputStream.getByteBuffer();
    PrintStream localPrintStream1 = System.out;
    String str1 = HexUtil.bytes2HexStr(localByteBuffer.array());
    localPrintStream1.println(str1);
    PrintStream localPrintStream2 = System.out;
    String str2 = Arrays.toString(localJceOutputStream.toByteArray());
    localPrintStream2.println(str2);
  }

  private void writeArray(Object[] paramArrayOfObject, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfObject.length;
    write(j, i);
    Object[] arrayOfObject = paramArrayOfObject;
    int k = arrayOfObject.length;
    Object localObject1 = null;
    while (localObject1 < k)
    {
      Object localObject2 = arrayOfObject[localObject1];
      write(localObject2, i);
      ++localObject1;
    }
  }

  public ByteBuffer getByteBuffer()
  {
    return this.bs;
  }

  public void reserve(int paramInt)
  {
    if (this.bs.remaining() >= paramInt)
      return;
    ByteBuffer localByteBuffer = ByteBuffer.allocate((this.bs.capacity() + paramInt) * 2);
    byte[] arrayOfByte = this.bs.array();
    int i = this.bs.position();
    localByteBuffer.put(arrayOfByte, 0, i);
    this.bs = localByteBuffer;
  }

  public int setServerEncoding(String paramString)
  {
    this.sServerEncoding = paramString;
    return null;
  }

  public byte[] toByteArray()
  {
    byte[] arrayOfByte1 = new byte[this.bs.position()];
    byte[] arrayOfByte2 = this.bs.array();
    int i = this.bs.position();
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, i);
    return arrayOfByte1;
  }

  public void write(byte paramByte, int paramInt)
  {
    reserve(3);
    if (paramByte == 0)
      writeHead(12, paramInt);
    while (true)
    {
      return;
      writeHead(null, paramInt);
      this.bs.put(paramByte);
    }
  }

  public void write(double paramDouble, int paramInt)
  {
    int paramInt;
    reserve(10);
    writeHead(5, ???);
    this.bs.putDouble(paramDouble);
  }

  public void write(float paramFloat, int paramInt)
  {
    reserve(6);
    writeHead(4, paramInt);
    this.bs.putFloat(paramFloat);
  }

  public void write(int paramInt1, int paramInt2)
  {
    reserve(6);
    if ((paramInt1 >= 32768) && (paramInt1 <= 32767))
    {
      short s = (short)paramInt1;
      write(s, paramInt2);
    }
    while (true)
    {
      return;
      writeHead(2, paramInt2);
      this.bs.putInt(paramInt1);
    }
  }

  public void write(long paramLong, int paramInt)
  {
    reserve(10);
    if ((paramLong >= -2147483648L) && (paramLong <= -1L))
    {
      int i = (int)paramLong;
      write(i, ???);
    }
    while (true)
    {
      return;
      writeHead(3, ???);
      this.bs.putLong(paramLong);
    }
  }

  public void write(JceStruct paramJceStruct, int paramInt)
  {
    reserve(2);
    writeHead(10, paramInt);
    paramJceStruct.writeTo(this);
    reserve(2);
    writeHead(11, 0);
  }

  public void write(Boolean paramBoolean, int paramInt)
  {
    boolean bool = paramBoolean.booleanValue();
    write(bool, paramInt);
  }

  public void write(Byte paramByte, int paramInt)
  {
    byte b = paramByte.byteValue();
    write(b, paramInt);
  }

  public void write(Double paramDouble, int paramInt)
  {
    double d = paramDouble.doubleValue();
    Object localObject;
    write(localObject, paramInt);
  }

  public void write(Float paramFloat, int paramInt)
  {
    float f = paramFloat.floatValue();
    write(f, paramInt);
  }

  public void write(Integer paramInteger, int paramInt)
  {
    int i = paramInteger.intValue();
    write(i, paramInt);
  }

  public void write(Long paramLong, int paramInt)
  {
    long l = paramLong.longValue();
    Object localObject;
    write(localObject, paramInt);
  }

  public void write(Object paramObject, int paramInt)
  {
    if (paramObject instanceof Byte)
    {
      byte b = ((Byte)paramObject).byteValue();
      write(b, paramInt);
    }
    while (true)
    {
      return;
      if (paramObject instanceof Boolean)
      {
        boolean bool = ((Boolean)paramObject).booleanValue();
        write(bool, paramInt);
      }
      if (paramObject instanceof Short)
      {
        short s = ((Short)paramObject).shortValue();
        write(s, paramInt);
      }
      if (paramObject instanceof Integer)
      {
        int i = ((Integer)paramObject).intValue();
        write(i, paramInt);
      }
      if (paramObject instanceof Long)
      {
        long l = ((Long)paramObject).longValue();
        Object localObject1;
        write(localObject1, paramInt);
      }
      if (paramObject instanceof Float)
      {
        float f = ((Float)paramObject).floatValue();
        write(f, paramInt);
      }
      if (paramObject instanceof Double)
      {
        double d = ((Double)paramObject).doubleValue();
        Object localObject2;
        write(localObject2, paramInt);
      }
      if (paramObject instanceof String)
      {
        String str1 = (String)paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof Map)
      {
        Map localMap = (Map)paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof List)
      {
        List localList = (List)paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof JceStruct)
      {
        JceStruct localJceStruct = (JceStruct)paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof byte[])
      {
        byte[] arrayOfByte = (byte[])(byte[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof boolean[])
      {
        boolean[] arrayOfBoolean = (boolean[])(boolean[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof short[])
      {
        short[] arrayOfShort = (short[])(short[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof int[])
      {
        int[] arrayOfInt = (int[])(int[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof long[])
      {
        long[] arrayOfLong = (long[])(long[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof float[])
      {
        float[] arrayOfFloat = (float[])(float[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject instanceof double[])
      {
        double[] arrayOfDouble = (double[])(double[])paramObject;
        write(paramObject, paramInt);
      }
      if (paramObject.getClass().isArray())
      {
        Object[] arrayOfObject = (Object[])(Object[])paramObject;
        writeArray(paramObject, paramInt);
      }
      if (!paramObject instanceof Collection)
        break;
      Collection localCollection = (Collection)paramObject;
      write(paramObject, paramInt);
    }
    StringBuilder localStringBuilder = new StringBuilder().append("write object error: unsupport type. ");
    Class localClass = paramObject.getClass();
    String str2 = localClass;
    throw new JceEncodeException(str2);
  }

  public void write(Short paramShort, int paramInt)
  {
    short s = paramShort.shortValue();
    write(s, paramInt);
  }

  public void write(String paramString, int paramInt)
  {
    byte[] arrayOfByte;
    try
    {
      String str = this.sServerEncoding;
      arrayOfByte = paramString.getBytes(str);
      label12: int i = arrayOfByte.length;
      int j;
      j += 10;
      reserve(i);
      if (arrayOfByte.length <= 255)
        break label83;
      writeHead(7, paramInt);
      ByteBuffer localByteBuffer1 = this.bs;
      int k = arrayOfByte.length;
      localByteBuffer1.putInt(k);
      this.bs.put(arrayOfByte);
      label83: return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = paramString.getBytes();
      break label12:
      writeHead(6, paramInt);
      ByteBuffer localByteBuffer2 = this.bs;
      byte b = (byte)arrayOfByte.length;
      localByteBuffer2.put(b);
      this.bs.put(arrayOfByte);
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/util/Collection", "<TT;>;I)V"})
  public void write(Collection paramCollection, int paramInt)
  {
    byte b1 = 0;
    reserve(8);
    byte b2 = 9;
    writeHead(b2, paramInt);
    if (paramCollection == null)
      b2 = b1;
    while (true)
    {
      write(b2, b1);
      if (paramCollection == null)
        return;
      Iterator localIterator = paramCollection.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
          return;
        Object localObject = localIterator.next();
        write(localObject, b1);
      }
      int i = paramCollection.size();
    }
  }

  @Signature({"<K:", "Ljava/lang/Object;", "V:", "Ljava/lang/Object;", ">(", "Ljava/util/Map", "<TK;TV;>;I)V"})
  public void write(Map paramMap, int paramInt)
  {
    byte b1 = 8;
    byte b2 = 0;
    reserve(b1);
    writeHead(b1, paramInt);
    if (paramMap == null)
      b1 = b2;
    while (true)
    {
      write(b1, b2);
      if (paramMap == null)
        return;
      Iterator localIterator = paramMap.entrySet().iterator();
      while (true)
      {
        if (!localIterator.hasNext())
          return;
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        Object localObject1 = localEntry.getKey();
        write(localObject1, b2);
        Object localObject2 = localEntry.getValue();
        write(localObject2, 1);
      }
      int i = paramMap.size();
    }
  }

  public void write(short paramShort, int paramInt)
  {
    reserve(4);
    if ((paramShort >= 65408) && (paramShort <= 127))
    {
      byte b = (byte)paramShort;
      write(b, paramInt);
    }
    while (true)
    {
      return;
      writeHead(1, paramInt);
      this.bs.putShort(paramShort);
    }
  }

  public void write(boolean paramBoolean, int paramInt)
  {
    int i;
    if (paramBoolean)
      i = 1;
    while (true)
    {
      byte b = (byte)i;
      write(b, paramInt);
      return;
      Object localObject = null;
    }
  }

  public void write(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramArrayOfByte.length;
    int j;
    j += 8;
    reserve(i);
    writeHead(13, paramInt);
    writeHead(null, 0);
    int k = paramArrayOfByte.length;
    write(k, 0);
    this.bs.put(paramArrayOfByte);
  }

  public void write(double[] paramArrayOfDouble, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfDouble.length;
    write(j, i);
    double[] arrayOfDouble = paramArrayOfDouble;
    int k = arrayOfDouble.length;
    Object localObject = null;
    while (localObject < k)
    {
      long l = arrayOfDouble[localObject];
      write(l, i);
      ++localObject;
    }
  }

  public void write(float[] paramArrayOfFloat, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfFloat.length;
    write(j, i);
    float[] arrayOfFloat = paramArrayOfFloat;
    int k = arrayOfFloat.length;
    Object localObject = null;
    while (localObject < k)
    {
      int l = arrayOfFloat[localObject];
      write(l, i);
      ++localObject;
    }
  }

  public void write(int[] paramArrayOfInt, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfInt.length;
    write(j, i);
    int[] arrayOfInt = paramArrayOfInt;
    int k = arrayOfInt.length;
    Object localObject = null;
    while (localObject < k)
    {
      int l = arrayOfInt[localObject];
      write(l, i);
      ++localObject;
    }
  }

  public void write(long[] paramArrayOfLong, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfLong.length;
    write(j, i);
    long[] arrayOfLong = paramArrayOfLong;
    int k = arrayOfLong.length;
    Object localObject = null;
    while (localObject < k)
    {
      long l = arrayOfLong[localObject];
      write(l, i);
      ++localObject;
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">([TT;I)V"})
  public void write(Object[] paramArrayOfObject, int paramInt)
  {
    writeArray(paramArrayOfObject, paramInt);
  }

  public void write(short[] paramArrayOfShort, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfShort.length;
    write(j, i);
    short[] arrayOfShort = paramArrayOfShort;
    int k = arrayOfShort.length;
    Object localObject = null;
    while (localObject < k)
    {
      short s = arrayOfShort[localObject];
      write(s, i);
      ++localObject;
    }
  }

  public void write(boolean[] paramArrayOfBoolean, int paramInt)
  {
    int i = 0;
    reserve(8);
    writeHead(9, paramInt);
    int j = paramArrayOfBoolean.length;
    write(j, i);
    boolean[] arrayOfBoolean = paramArrayOfBoolean;
    int k = arrayOfBoolean.length;
    Object localObject = null;
    while (localObject < k)
    {
      int l = arrayOfBoolean[localObject];
      write(l, i);
      ++localObject;
    }
  }

  public void writeByteString(String paramString, int paramInt)
  {
    int i = paramString.length();
    int j;
    j += 10;
    reserve(i);
    byte[] arrayOfByte = HexUtil.hexStr2Bytes(paramString);
    if (arrayOfByte.length > 255)
    {
      writeHead(7, paramInt);
      ByteBuffer localByteBuffer1 = this.bs;
      int k = arrayOfByte.length;
      localByteBuffer1.putInt(k);
      this.bs.put(arrayOfByte);
    }
    while (true)
    {
      return;
      writeHead(6, paramInt);
      ByteBuffer localByteBuffer2 = this.bs;
      byte b = (byte)arrayOfByte.length;
      localByteBuffer2.put(b);
      this.bs.put(arrayOfByte);
    }
  }

  public void writeHead(byte paramByte, int paramInt)
  {
    if (paramInt < 15)
    {
      byte b1 = (byte)(paramInt << 4 | paramByte);
      this.bs.put(b1);
    }
    while (true)
    {
      return;
      if (paramInt >= 256)
        break;
      byte b2 = (byte)(paramByte | 0xF0);
      this.bs.put(b2);
      ByteBuffer localByteBuffer = this.bs;
      byte b3 = (byte)paramInt;
      localByteBuffer.put(b3);
    }
    String str = "tag is too large: " + paramInt;
    throw new JceEncodeException(str);
  }

  public void writeStringByte(String paramString, int paramInt)
  {
    byte[] arrayOfByte = HexUtil.hexStr2Bytes(paramString);
    int i = arrayOfByte.length;
    int j;
    j += 10;
    reserve(i);
    if (arrayOfByte.length > 255)
    {
      writeHead(7, paramInt);
      ByteBuffer localByteBuffer1 = this.bs;
      int k = arrayOfByte.length;
      localByteBuffer1.putInt(k);
      this.bs.put(arrayOfByte);
    }
    while (true)
    {
      return;
      writeHead(6, paramInt);
      ByteBuffer localByteBuffer2 = this.bs;
      byte b = (byte)arrayOfByte.length;
      localByteBuffer2.put(b);
      this.bs.put(arrayOfByte);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceOutputStream
 * JD-Core Version:    0.5.4
 */