package com.qq.taf.jce;

public class JceDecodeException extends RuntimeException
{
  public JceDecodeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceDecodeException
 * JD-Core Version:    0.5.4
 */