package com.qq.taf.jce;

import dalvik.annotation.Signature;
import java.io.PrintStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class JceDisplayer
{
  private int _level = null;
  private StringBuilder sb;

  public JceDisplayer(StringBuilder paramStringBuilder)
  {
    this.sb = paramStringBuilder;
  }

  public JceDisplayer(StringBuilder paramStringBuilder, int paramInt)
  {
    this.sb = paramStringBuilder;
    this._level = paramInt;
  }

  public static void main(String[] paramArrayOfString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(4608083138725491507L);
    PrintStream localPrintStream = System.out;
    String str = localStringBuilder.toString();
    localPrintStream.println(str);
  }

  private void ps(String paramString)
  {
    Object localObject = null;
    while (true)
    {
      int i = this._level;
      if (localObject >= i)
        break;
      this.sb.append('\t');
      ++localObject;
    }
    if (paramString == null)
      return;
    this.sb.append(paramString).append(": ");
  }

  public JceDisplayer display(byte paramByte, String paramString)
  {
    ps(paramString);
    this.sb.append(paramByte).append('\n');
    return this;
  }

  public JceDisplayer display(char paramChar, String paramString)
  {
    ps(paramString);
    this.sb.append(paramChar).append('\n');
    return this;
  }

  public JceDisplayer display(double paramDouble, String paramString)
  {
    String paramString;
    ps(???);
    this.sb.append(paramDouble).append('\n');
    return this;
  }

  public JceDisplayer display(float paramFloat, String paramString)
  {
    ps(paramString);
    this.sb.append(paramFloat).append('\n');
    return this;
  }

  public JceDisplayer display(int paramInt, String paramString)
  {
    ps(paramString);
    this.sb.append(paramInt).append('\n');
    return this;
  }

  public JceDisplayer display(long paramLong, String paramString)
  {
    String paramString;
    ps(???);
    this.sb.append(paramLong).append('\n');
    return this;
  }

  public JceDisplayer display(JceStruct paramJceStruct, String paramString)
  {
    display('{', paramString);
    if (paramJceStruct == null)
      this.sb.append('\t').append("null");
    while (true)
    {
      display('}', null);
      return this;
      StringBuilder localStringBuilder = this.sb;
      int i = this._level;
      int j;
      ++j;
      paramJceStruct.display(localStringBuilder, i);
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(TT;", "Ljava/lang/String;", ")", "Lcom/qq/taf/jce/JceDisplayer;"})
  public JceDisplayer display(Object paramObject, String paramString)
  {
    if (paramObject == null)
      this.sb.append("null").append('\n');
    while (true)
    {
      return this;
      if (paramObject instanceof Byte)
      {
        byte b = ((Byte)paramObject).byteValue();
        display(b, paramString);
      }
      if (paramObject instanceof Boolean)
      {
        boolean bool = ((Boolean)paramObject).booleanValue();
        display(bool, paramString);
      }
      if (paramObject instanceof Short)
      {
        short s = ((Short)paramObject).shortValue();
        display(s, paramString);
      }
      if (paramObject instanceof Integer)
      {
        int i = ((Integer)paramObject).intValue();
        display(i, paramString);
      }
      if (paramObject instanceof Long)
      {
        long l = ((Long)paramObject).longValue();
        Object localObject1;
        display(localObject1, paramString);
      }
      if (paramObject instanceof Float)
      {
        float f = ((Float)paramObject).floatValue();
        display(f, paramString);
      }
      if (paramObject instanceof Double)
      {
        double d = ((Double)paramObject).doubleValue();
        Object localObject2;
        display(localObject2, paramString);
      }
      if (paramObject instanceof String)
      {
        String str = (String)paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof Map)
      {
        Map localMap = (Map)paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof List)
      {
        List localList = (List)paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof JceStruct)
      {
        JceStruct localJceStruct = (JceStruct)paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof byte[])
      {
        byte[] arrayOfByte = (byte[])(byte[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof boolean[])
      {
        boolean[] arrayOfBoolean = (boolean[])(boolean[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof short[])
      {
        short[] arrayOfShort = (short[])(short[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof int[])
      {
        int[] arrayOfInt = (int[])(int[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof long[])
      {
        long[] arrayOfLong = (long[])(long[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof float[])
      {
        float[] arrayOfFloat = (float[])(float[])paramObject;
        display(paramObject, paramString);
      }
      if (paramObject instanceof double[])
      {
        double[] arrayOfDouble = (double[])(double[])paramObject;
        display(paramObject, paramString);
      }
      if (!paramObject.getClass().isArray())
        break;
      Object[] arrayOfObject = (Object[])(Object[])paramObject;
      display(paramObject, paramString);
    }
    throw new JceEncodeException("write object error: unsupport type.");
  }

  public JceDisplayer display(String paramString1, String paramString2)
  {
    char c = '\n';
    ps(paramString2);
    if (paramString1 == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      this.sb.append(paramString1).append(c);
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/util/Collection", "<TT;>;", "Ljava/lang/String;", ")", "Lcom/qq/taf/jce/JceDisplayer;"})
  public JceDisplayer display(Collection paramCollection, String paramString)
  {
    if (paramCollection == null)
    {
      ps(paramString);
      this.sb.append("null").append('\t');
    }
    for (Object localObject = this; ; localObject = display(localObject, paramString))
    {
      return localObject;
      localObject = paramCollection.toArray();
    }
  }

  @Signature({"<K:", "Ljava/lang/Object;", "V:", "Ljava/lang/Object;", ">(", "Ljava/util/Map", "<TK;TV;>;", "Ljava/lang/String;", ")", "Lcom/qq/taf/jce/JceDisplayer;"})
  public JceDisplayer display(Map paramMap, String paramString)
  {
    char c = '\n';
    String str = null;
    ps(paramString);
    if (paramMap == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramMap.isEmpty())
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramMap.size();
        localStringBuilder1.append(i).append(", {}").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramMap.size();
      localStringBuilder2.append(j).append(", {").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer1 = new JceDisplayer(localStringBuilder3, k);
      StringBuilder localStringBuilder4 = this.sb;
      int i1 = this._level;
      l += 2;
      JceDisplayer localJceDisplayer2 = new JceDisplayer(localStringBuilder4, i1);
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        localJceDisplayer1.display('(', str);
        Object localObject1 = localEntry.getKey();
        localJceDisplayer2.display(localObject1, str);
        Object localObject2 = localEntry.getValue();
        localJceDisplayer2.display(localObject2, str);
        localJceDisplayer1.display(')', str);
      }
      display('}', str);
    }
  }

  public JceDisplayer display(short paramShort, String paramString)
  {
    ps(paramString);
    this.sb.append(paramShort).append('\n');
    return this;
  }

  public JceDisplayer display(boolean paramBoolean, String paramString)
  {
    ps(paramString);
    StringBuilder localStringBuilder = this.sb;
    if (paramBoolean);
    for (char c = 'T'; ; c = 'F')
    {
      localStringBuilder.append(c).append('\n');
      return this;
    }
  }

  public JceDisplayer display(byte[] paramArrayOfByte, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfByte == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfByte.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfByte.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfByte.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      byte[] arrayOfByte = paramArrayOfByte;
      int i1 = arrayOfByte.length;
      Object localObject = null;
      while (localObject < i1)
      {
        byte b = arrayOfByte[localObject];
        localJceDisplayer.display(b, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(char[] paramArrayOfChar, String paramString)
  {
    String str = null;
    char c1 = '\n';
    ps(paramString);
    if (paramArrayOfChar == null)
      this.sb.append("null").append(c1);
    while (true)
    {
      return this;
      if (paramArrayOfChar.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfChar.length;
        localStringBuilder1.append(i).append(", []").append(c1);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfChar.length;
      localStringBuilder2.append(j).append(", [").append(c1);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      char[] arrayOfChar = paramArrayOfChar;
      int i1 = arrayOfChar.length;
      Object localObject = null;
      while (localObject < i1)
      {
        char c2 = arrayOfChar[localObject];
        localJceDisplayer.display(c2, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(double[] paramArrayOfDouble, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfDouble == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfDouble.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfDouble.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfDouble.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      double[] arrayOfDouble = paramArrayOfDouble;
      int i1 = arrayOfDouble.length;
      Object localObject = null;
      while (localObject < i1)
      {
        long l1 = arrayOfDouble[localObject];
        localJceDisplayer.display(l1, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(float[] paramArrayOfFloat, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfFloat == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfFloat.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfFloat.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfFloat.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      float[] arrayOfFloat = paramArrayOfFloat;
      int i1 = arrayOfFloat.length;
      Object localObject = null;
      while (localObject < i1)
      {
        int i2 = arrayOfFloat[localObject];
        localJceDisplayer.display(i2, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(int[] paramArrayOfInt, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfInt == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfInt.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfInt.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfInt.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      int[] arrayOfInt = paramArrayOfInt;
      int i1 = arrayOfInt.length;
      Object localObject = null;
      while (localObject < i1)
      {
        int i2 = arrayOfInt[localObject];
        localJceDisplayer.display(i2, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(long[] paramArrayOfLong, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfLong == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfLong.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfLong.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfLong.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      long[] arrayOfLong = paramArrayOfLong;
      int i1 = arrayOfLong.length;
      Object localObject = null;
      while (localObject < i1)
      {
        long l1 = arrayOfLong[localObject];
        localJceDisplayer.display(l1, str);
        ++localObject;
      }
      display(']', str);
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">([TT;", "Ljava/lang/String;", ")", "Lcom/qq/taf/jce/JceDisplayer;"})
  public JceDisplayer display(Object[] paramArrayOfObject, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfObject == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfObject.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfObject.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfObject.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      Object[] arrayOfObject = paramArrayOfObject;
      int i1 = arrayOfObject.length;
      Object localObject1 = null;
      while (localObject1 < i1)
      {
        Object localObject2 = arrayOfObject[localObject1];
        localJceDisplayer.display(localObject2, str);
        ++localObject1;
      }
      display(']', str);
    }
  }

  public JceDisplayer display(short[] paramArrayOfShort, String paramString)
  {
    String str = null;
    char c = '\n';
    ps(paramString);
    if (paramArrayOfShort == null)
      this.sb.append("null").append(c);
    while (true)
    {
      return this;
      if (paramArrayOfShort.length == 0)
      {
        StringBuilder localStringBuilder1 = this.sb;
        int i = paramArrayOfShort.length;
        localStringBuilder1.append(i).append(", []").append(c);
      }
      StringBuilder localStringBuilder2 = this.sb;
      int j = paramArrayOfShort.length;
      localStringBuilder2.append(j).append(", [").append(c);
      StringBuilder localStringBuilder3 = this.sb;
      int k = this._level;
      int l;
      ++l;
      JceDisplayer localJceDisplayer = new JceDisplayer(localStringBuilder3, k);
      short[] arrayOfShort = paramArrayOfShort;
      int i1 = arrayOfShort.length;
      Object localObject = null;
      while (localObject < i1)
      {
        short s = arrayOfShort[localObject];
        localJceDisplayer.display(s, str);
        ++localObject;
      }
      display(']', str);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceDisplayer
 * JD-Core Version:    0.5.4
 */