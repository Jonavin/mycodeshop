package com.qq.taf.jce.dynamic;

public final class ZeroField extends NumberField
{
  ZeroField(int paramInt)
  {
    super(paramInt);
  }

  public byte byteValue()
  {
    return null;
  }

  public double doubleValue()
  {
    return 0L;
  }

  public float floatValue()
  {
    return null;
  }

  public Number getNumber()
  {
    return Integer.valueOf(0);
  }

  public int intValue()
  {
    return null;
  }

  public long longValue()
  {
    return 0L;
  }

  public short shortValue()
  {
    return null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.dynamic.ZeroField
 * JD-Core Version:    0.5.4
 */