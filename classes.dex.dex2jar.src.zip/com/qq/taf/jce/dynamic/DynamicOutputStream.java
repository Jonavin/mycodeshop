package com.qq.taf.jce.dynamic;

import com.qq.taf.jce.JceDecodeException;
import com.qq.taf.jce.JceOutputStream;
import java.nio.ByteBuffer;

public final class DynamicOutputStream extends JceOutputStream
{
  public DynamicOutputStream()
  {
  }

  public DynamicOutputStream(int paramInt)
  {
    super(paramInt);
  }

  public DynamicOutputStream(ByteBuffer paramByteBuffer)
  {
    super(paramByteBuffer);
  }

  public void write(JceField paramJceField)
  {
    int i = 2;
    byte b1 = 8;
    int j = 0;
    int k = paramJceField.getTag();
    if (paramJceField instanceof ZeroField)
      write(j, k);
    while (true)
    {
      return;
      if (paramJceField instanceof IntField)
      {
        int l = ((IntField)paramJceField).get();
        write(l, k);
      }
      if (paramJceField instanceof ShortField)
      {
        short s = ((ShortField)paramJceField).get();
        write(s, k);
      }
      if (paramJceField instanceof ByteField)
      {
        byte b2 = ((ByteField)paramJceField).get();
        write(b2, k);
      }
      if (paramJceField instanceof StringField)
      {
        String str1 = ((StringField)paramJceField).get();
        write(str1, k);
      }
      if (paramJceField instanceof ByteArrayField)
      {
        byte[] arrayOfByte = ((ByteArrayField)paramJceField).get();
        write(arrayOfByte, k);
      }
      JceField[] arrayOfJceField;
      int i2;
      Object localObject1;
      if (paramJceField instanceof ListField)
      {
        ListField localListField = (ListField)paramJceField;
        reserve(b1);
        writeHead(9, k);
        int i1 = localListField.size();
        write(i1, j);
        arrayOfJceField = localListField.get();
        i2 = arrayOfJceField.length;
        localObject1 = null;
        while (true)
        {
          if (localObject1 < i2);
          JceField localJceField1 = arrayOfJceField[localObject1];
          write(localJceField1);
          ++localObject1;
        }
      }
      if (paramJceField instanceof MapField)
      {
        MapField localMapField = (MapField)paramJceField;
        reserve(b1);
        writeHead(b1, k);
        int i3 = localMapField.size();
        write(i3, j);
        for (int i4 = 0; ; ++i4)
        {
          if (i4 < i3);
          JceField localJceField2 = localMapField.getKey(i4);
          write(localJceField2);
          JceField localJceField3 = localMapField.getValue(i4);
          write(localJceField3);
        }
      }
      if (paramJceField instanceof StructField)
      {
        StructField localStructField = (StructField)paramJceField;
        reserve(i);
        writeHead(10, k);
        arrayOfJceField = localStructField.get();
        i2 = arrayOfJceField.length;
        localObject1 = null;
        while (localObject1 < i2)
        {
          JceField localJceField4 = arrayOfJceField[localObject1];
          write(localJceField4);
          ++localObject1;
        }
        reserve(i);
        writeHead(11, j);
      }
      if (paramJceField instanceof LongField)
      {
        long l1 = ((LongField)paramJceField).get();
        Object localObject2;
        write(localObject2, k);
      }
      if (paramJceField instanceof FloatField)
      {
        float f = ((FloatField)paramJceField).get();
        write(f, k);
      }
      if (!paramJceField instanceof DoubleField)
        break;
      double d = ((DoubleField)paramJceField).get();
      Object localObject3;
      write(localObject3, k);
    }
    StringBuilder localStringBuilder = new StringBuilder().append("unknow JceField type: ");
    String str2 = paramJceField.getClass().getName();
    String str3 = str2;
    throw new JceDecodeException(str3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.dynamic.DynamicOutputStream
 * JD-Core Version:    0.5.4
 */