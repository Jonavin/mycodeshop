package com.qq.taf.jce.dynamic;

import com.qq.taf.jce.JceDecodeException;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceInputStream.HeadData;
import java.io.UnsupportedEncodingException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public final class DynamicInputStream
{
  private ByteBuffer bs;
  private String sServerEncoding = "GBK";

  public DynamicInputStream(ByteBuffer paramByteBuffer)
  {
    this.bs = paramByteBuffer;
  }

  public DynamicInputStream(byte[] paramArrayOfByte)
  {
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    this.bs = localByteBuffer;
  }

  private JceField readString(JceInputStream.HeadData paramHeadData, int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    this.bs.get(arrayOfByte);
    String str1 = null;
    try
    {
      String str2 = this.sServerEncoding;
      str1 = new String(arrayOfByte, str2);
      int i = paramHeadData.tag;
      return JceField.create(str1, i);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      str1 = new String(arrayOfByte);
    }
  }

  public JceField read()
  {
    int i = 0;
    JceInputStream.HeadData localHeadData;
    label98: Object localObject4;
    try
    {
      localHeadData = new JceInputStream.HeadData();
      ByteBuffer localByteBuffer = this.bs;
      JceInputStream.readHead(localHeadData, localByteBuffer);
      int j = localHeadData.type;
      switch (j)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 9:
      case 8:
      case 10:
        ArrayList localArrayList;
        JceField localJceField;
        JceField[] arrayOfJceField4;
        int i1;
        for (Object localObject1 = i; ; localObject4 = JceField.createStruct(arrayOfJceField4, i1))
        {
          while (true)
          {
            return localObject1;
            localObject1 = this.bs.get();
            int i3 = localHeadData.tag;
            localObject1 = JceField.create(localObject1, i3);
            continue;
            localObject1 = this.bs.getShort();
            int i4 = localHeadData.tag;
            localObject1 = JceField.create(localObject1, i4);
            continue;
            localObject1 = this.bs.getInt();
            int i5 = localHeadData.tag;
            localObject1 = JceField.create(localObject1, i5);
            continue;
            localObject1 = this.bs.getLong();
            int i6 = localHeadData.tag;
            Object localObject6;
            localObject1 = JceField.create(localObject6, i6);
            continue;
            localObject1 = this.bs.getFloat();
            int i7 = localHeadData.tag;
            localObject1 = JceField.create(localObject1, i7);
            continue;
            localObject1 = this.bs.getDouble();
            int i8 = localHeadData.tag;
            localObject1 = JceField.create(localObject6, i8);
            continue;
            localObject1 = this.bs;
            byte b = ((ByteBuffer)localObject1).get();
            int i9;
            if (b < 0)
              b += 256;
            localObject1 = readString(localHeadData, i9);
            continue;
            localObject1 = this.bs.getInt();
            localObject1 = readString(localHeadData, localObject1);
            continue;
            localObject1 = (NumberField)read();
            int i10 = ((NumberField)localObject1).intValue();
            JceField[] arrayOfJceField1 = new JceField[i10];
            for (int i11 = 0; i11 < i10; ++i11)
            {
              localObject1 = read();
              arrayOfJceField1[i11] = localObject1;
            }
            int k = localHeadData.tag;
            Object localObject2 = JceField.createList(arrayOfJceField1, k);
            continue;
            localObject2 = (NumberField)read();
            i10 = ((NumberField)localObject2).intValue();
            JceField[] arrayOfJceField2 = new JceField[i10];
            JceField[] arrayOfJceField3 = new JceField[i10];
            for (int i12 = 0; i12 < i10; ++i12)
            {
              localObject2 = read();
              arrayOfJceField2[i12] = localObject2;
              localObject2 = read();
              arrayOfJceField3[i12] = localObject2;
            }
            int l = localHeadData.tag;
            localObject3 = JceField.createMap(arrayOfJceField2, arrayOfJceField3, l);
          }
          localArrayList = new ArrayList();
          localJceField = read();
          if (localJceField != null)
            break;
          Object localObject3 = new JceField[null];
          arrayOfJceField4 = (JceField[])localArrayList.toArray(localObject3);
          i1 = localHeadData.tag;
        }
        localArrayList.add(localJceField);
      case 11:
      case 12:
      case 13:
      }
    }
    catch (BufferUnderflowException localBufferUnderflowException)
    {
      localObject4 = i;
      break label98:
      localObject4 = i;
      break label98:
      localObject4 = JceField.createZero(localHeadData.tag);
      break label98:
      int i13 = localHeadData.tag;
      localObject4 = this.bs;
      JceInputStream.readHead(localHeadData, (ByteBuffer)localObject4);
      int i2 = localHeadData.type;
      if (i2 != 0)
      {
        StringBuilder localStringBuilder = new StringBuilder().append("type mismatch, simple_list only support byte, tag: ").append(i13).append(", type: ");
        int i14 = localHeadData.type;
        String str = i14;
        localObject5 = new JceDecodeException(str);
        throw ((Throwable)localObject5);
      }
      byte[] arrayOfByte = new byte[((NumberField)read()).intValue()];
      this.bs.get(arrayOfByte);
      Object localObject5 = JceField.create(arrayOfByte, i13);
      break label98:
    }
  }

  public int setServerEncoding(String paramString)
  {
    this.sServerEncoding = paramString;
    return null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.dynamic.DynamicInputStream
 * JD-Core Version:    0.5.4
 */