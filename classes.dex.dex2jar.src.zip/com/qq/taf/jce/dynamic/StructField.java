package com.qq.taf.jce.dynamic;

import dalvik.annotation.Signature;
import java.util.Arrays;
import java.util.Comparator;

public class StructField extends JceField
{

  @Signature({"Ljava/util/Comparator", "<", "Lcom/qq/taf/jce/dynamic/JceField;", ">;"})
  private static final Comparator tagComp = new StructField.1();
  private JceField[] data;

  StructField(JceField[] paramArrayOfJceField, int paramInt)
  {
    super(paramInt);
    this.data = paramArrayOfJceField;
  }

  public JceField[] get()
  {
    return this.data;
  }

  public JceField getFieldByTag(int paramInt)
  {
    Object localObject = this.data;
    JceField localJceField = JceField.createZero(paramInt);
    Comparator localComparator = tagComp;
    int j = Arrays.binarySearch(localObject, localJceField, localComparator);
    if (j >= 0)
      localObject = this.data[j];
    while (true)
    {
      return localObject;
      int i = 0;
    }
  }

  public boolean setByTag(int paramInt, JceField paramJceField)
  {
    JceField[] arrayOfJceField1 = 1;
    JceField[] arrayOfJceField2 = this.data;
    JceField localJceField2 = JceField.createZero(paramInt);
    Comparator localComparator = tagComp;
    int k = Arrays.binarySearch(arrayOfJceField2, localJceField2, localComparator);
    if (k >= 0)
    {
      this.data[k] = paramJceField;
      arrayOfJceField2 = arrayOfJceField1;
    }
    while (true)
    {
      return arrayOfJceField2;
      int l = -k - arrayOfJceField1;
      int i = this.data.length;
      JceField[] arrayOfJceField3 = new JceField[++i];
      for (int i1 = 0; i1 < l; ++i1)
      {
        JceField localJceField1 = this.data[i1];
        arrayOfJceField3[i1] = localJceField1;
      }
      arrayOfJceField3[l] = paramJceField;
      for (i1 = l; ; ++i1)
      {
        int j = this.data.length;
        if (i1 >= j)
          break;
        j = i1 + 1;
        JceField localJceField3 = this.data[i1];
        arrayOfJceField3[j] = localJceField3;
      }
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.dynamic.StructField
 * JD-Core Version:    0.5.4
 */