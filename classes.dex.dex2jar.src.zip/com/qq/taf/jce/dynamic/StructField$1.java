package com.qq.taf.jce.dynamic;

import dalvik.annotation.Signature;
import java.util.Comparator;

@Signature({"Ljava/lang/Object;", "Ljava/util/Comparator", "<", "Lcom/qq/taf/jce/dynamic/JceField;", ">;"})
final class StructField$1
  implements Comparator
{
  public int compare(JceField paramJceField1, JceField paramJceField2)
  {
    int i = paramJceField1.getTag();
    int j = paramJceField2.getTag();
    return i - j;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.dynamic.StructField.1
 * JD-Core Version:    0.5.4
 */