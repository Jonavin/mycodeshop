package com.qq.taf.jce;

import java.io.PrintStream;

public class HexUtil
{
  private static final char[] digits = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
  public static final byte[] emptybytes = new byte[null];

  public static String byte2HexStr(byte paramByte)
  {
    char[] arrayOfChar1 = new char[2];
    char[] arrayOfChar2 = digits;
    int i = paramByte & 0xF;
    int j = arrayOfChar2[i];
    arrayOfChar1[1] = j;
    int k = (byte)(paramByte >>> 4);
    char[] arrayOfChar3 = digits;
    int l = paramByte & 0xF;
    int i1 = arrayOfChar3[l];
    arrayOfChar1[0] = i1;
    return new String(arrayOfChar1);
  }

  public static String bytes2HexStr(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte != null)
    {
      i = paramArrayOfByte.length;
      if (i != 0)
        break label15;
    }
    int i = 0;
    while (true)
    {
      return i;
      label15: i = paramArrayOfByte.length * 2;
      char[] arrayOfChar1 = new char[i];
      Object localObject = null;
      while (true)
      {
        i = paramArrayOfByte.length;
        if (localObject >= i)
          break;
        int j = paramArrayOfByte[localObject];
        i = localObject * 2;
        ++i;
        char[] arrayOfChar2 = digits;
        int k = j & 0xF;
        int l = arrayOfChar2[k];
        arrayOfChar1[i] = l;
        int i1 = (byte)(j >>> 4);
        i = localObject * 2;
        i += 0;
        char[] arrayOfChar3 = digits;
        int i2 = i1 & 0xF;
        int i3 = arrayOfChar3[i2];
        arrayOfChar1[i] = i3;
        ++localObject;
      }
      String str = new String(arrayOfChar1);
    }
  }

  public static byte char2Byte(char paramChar)
  {
    char c1 = 'a';
    char c2 = 'A';
    char c3 = '0';
    char c5;
    if (paramChar >= c3)
    {
      char c4 = '9';
      if (paramChar <= c4)
        c5 = (byte)(paramChar - c3);
    }
    while (true)
    {
      return c5;
      char c6;
      if (paramChar >= c1)
      {
        c5 = 'f';
        if (paramChar <= c5)
        {
          c6 = paramChar - c1;
          c6 = (byte)(c6 += 10);
        }
      }
      if (paramChar >= c2)
      {
        c6 = 'F';
        if (paramChar <= c6)
        {
          int i = paramChar - c2;
          i = (byte)(i += 10);
        }
      }
      Object localObject = null;
    }
  }

  public static byte hexStr2Byte(String paramString)
  {
    byte b1 = 0;
    byte b2;
    if (paramString != null)
    {
      int i = paramString.length();
      if (i == 1)
        b2 = char2Byte(paramString.charAt(b1));
    }
    while (true)
    {
      return b2;
      b2 = b1;
    }
  }

  public static byte[] hexStr2Bytes(String paramString)
  {
    if (paramString != null)
    {
      boolean bool = paramString.equals("");
      if (!bool)
        break label21;
    }
    label21: byte[] arrayOfByte2;
    Object localObject;
    for (byte[] arrayOfByte1 = emptybytes; ; localObject = arrayOfByte2)
    {
      return arrayOfByte1;
      byte b1 = paramString.length() / 2;
      arrayOfByte2 = new byte[b1];
      for (int i = 0; ; ++i)
      {
        b1 = arrayOfByte2.length;
        if (i >= b1)
          break;
        b1 = i * 2;
        char c1 = paramString.charAt(b1);
        b1 = i * 2;
        char c2 = paramString.charAt(++b1);
        b1 = char2Byte(c1) * 16;
        byte b2 = char2Byte(c2);
        b1 = (byte)(b1 + b2);
        arrayOfByte2[i] = b1;
      }
    }
  }

  public static void main(String[] paramArrayOfString)
  {
    long l1 = System.currentTimeMillis();
    for (int i = 0; i < 1000000; ++i)
    {
      String str1 = "234" + i;
      byte[] arrayOfByte = hexStr2Bytes(bytes2HexStr(str1.getBytes()));
      if (new String(arrayOfByte).equals(str1))
        continue;
      PrintStream localPrintStream1 = System.out;
      String str2 = "error:" + str1;
      localPrintStream1.println(str2);
    }
    PrintStream localPrintStream2 = System.out;
    StringBuilder localStringBuilder = new StringBuilder().append("use:");
    Object localObject;
    long l2 = System.currentTimeMillis() - localObject;
    String str3 = l2;
    localPrintStream2.println(str3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.HexUtil
 * JD-Core Version:    0.5.4
 */