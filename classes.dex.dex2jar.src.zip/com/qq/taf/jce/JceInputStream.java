package com.qq.taf.jce;

import dalvik.annotation.Signature;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class JceInputStream
{
  private ByteBuffer bs;
  protected String sServerEncoding = "GBK";

  public JceInputStream()
  {
  }

  public JceInputStream(ByteBuffer paramByteBuffer)
  {
    this.bs = paramByteBuffer;
  }

  public JceInputStream(byte[] paramArrayOfByte)
  {
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    this.bs = localByteBuffer;
  }

  public JceInputStream(byte[] paramArrayOfByte, int paramInt)
  {
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    this.bs = localByteBuffer;
    this.bs.position(paramInt);
  }

  public static void main(String[] paramArrayOfString)
  {
  }

  private int peakHead(HeadData paramHeadData)
  {
    ByteBuffer localByteBuffer = this.bs.duplicate();
    return readHead(paramHeadData, localByteBuffer);
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(TT;IZ)[TT;"})
  private Object[] readArrayImpl(Object paramObject, int paramInt, boolean paramBoolean)
  {
    boolean bool1 = true;
    int i = 0;
    boolean bool2 = skipToTag(paramInt);
    Object localObject1;
    if (bool2)
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      int j = localHeadData.type;
      switch (j)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int l = read(i, i, bool1);
      if (l < 0)
      {
        String str = "size invalid: " + l;
        throw new JceDecodeException(str);
      }
      localObject1 = (Object[])Array.newInstance(paramObject.getClass(), l);
      Object[] arrayOfObject = (Object[])localObject1;
      for (int i1 = 0; i1 < l; ++i1)
      {
        Object localObject2 = read(paramObject, i, bool1);
        arrayOfObject[i1] = localObject2;
      }
      localObject1 = arrayOfObject;
    }
    while (true)
    {
      return localObject1;
      if (paramBoolean)
        throw new JceDecodeException("require field not exist.");
      int k = 0;
    }
  }

  public static int readHead(HeadData paramHeadData, ByteBuffer paramByteBuffer)
  {
    byte b1 = paramByteBuffer.get();
    int i = (byte)(b1 & 0xF);
    paramHeadData.type = i;
    i = (b1 & 0xF0) >> 4;
    paramHeadData.tag = i;
    i = paramHeadData.tag;
    if (i == 15)
    {
      byte b2 = paramByteBuffer.get();
      paramHeadData.tag = b2;
    }
    for (int j = 2; ; j = 1)
      return j;
  }

  @Signature({"<K:", "Ljava/lang/Object;", "V:", "Ljava/lang/Object;", ">(", "Ljava/util/Map", "<TK;TV;>;", "Ljava/util/Map", "<TK;TV;>;IZ)", "Ljava/util/Map", "<TK;TV;>;"})
  private Map readMap(Map paramMap1, Map paramMap2, int paramInt, boolean paramBoolean)
  {
    if (paramMap2 != null)
    {
      boolean bool = paramMap2.isEmpty();
      if (!bool)
        break label29;
    }
    label29: label250: Map localMap;
    for (Object localObject1 = new HashMap(); ; localMap = paramMap1)
    {
      return localObject1;
      Map.Entry localEntry = (Map.Entry)paramMap2.entrySet().iterator().next();
      Object localObject2 = localEntry.getKey();
      Object localObject3 = localEntry.getValue();
      localObject1 = skipToTag(paramInt);
      if (localObject1 != 0)
      {
        HeadData localHeadData = new HeadData();
        readHead(localHeadData);
        int i = localHeadData.type;
        switch (i)
        {
        default:
          throw new JceDecodeException("type mismatch.");
        case 8:
        }
        i = 0;
        int j = read(i, 0, true);
        if (j < 0)
        {
          String str = "size invalid: " + j;
          throw new JceDecodeException(str);
        }
        Object localObject4 = null;
        while (true)
        {
          if (localObject4 >= j)
            break label250;
          Object localObject5 = read(localObject2, 0, true);
          i = 1;
          Object localObject6 = read(localObject3, i, true);
          paramMap1.put(localObject5, localObject6);
          ++localObject4;
        }
      }
      if (!paramBoolean)
        continue;
      throw new JceDecodeException("require field not exist.");
    }
  }

  private void skip(int paramInt)
  {
    ByteBuffer localByteBuffer = this.bs;
    int i = this.bs.position() + paramInt;
    localByteBuffer.position(i);
  }

  private void skipField()
  {
    HeadData localHeadData = new HeadData();
    readHead(localHeadData);
    byte b = localHeadData.type;
    skipField(b);
  }

  private void skipField(byte paramByte)
  {
    int i = 8;
    int j = 4;
    int k = 1;
    int l = 0;
    switch (paramByte)
    {
    default:
      throw new JceDecodeException("invalid type.");
    case 0:
      skip(k);
    case 11:
    case 12:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 13:
    case 10:
    }
    while (true)
    {
      return;
      skip(2);
      continue;
      skip(j);
      continue;
      skip(i);
      continue;
      skip(j);
      continue;
      skip(i);
      continue;
      byte b = this.bs.get();
      int i1;
      if (b < 0)
        b += 256;
      skip(i1);
      continue;
      int i2 = this.bs.getInt();
      skip(i2);
      continue;
      int i3 = read(l, l, k);
      Object localObject = null;
      while (true)
      {
        int i4 = i3 * 2;
        if (localObject < i4);
        skipField();
        ++localObject;
      }
      i3 = read(l, l, k);
      localObject = null;
      while (true)
      {
        if (localObject < i3);
        skipField();
        ++localObject;
      }
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      if (localHeadData.type != 0)
      {
        StringBuilder localStringBuilder = new StringBuilder().append("skipField with invalid type, type value: ").append(paramByte).append(", ");
        int i5 = localHeadData.type;
        String str = i5;
        throw new JceDecodeException(str);
      }
      int i6 = read(l, l, k);
      skip(i6);
      continue;
      skipToStructEnd();
    }
  }

  public JceStruct directRead(JceStruct paramJceStruct, int paramInt, boolean paramBoolean)
  {
    int i = 0;
    JceStruct localJceStruct;
    if (skipToTag(paramInt))
    {
      try
      {
        localJceStruct = paramJceStruct.newInit();
        HeadData localHeadData = new HeadData();
        readHead(localHeadData);
        if (localHeadData.type != 10)
          throw new JceDecodeException("type mismatch.");
      }
      catch (Exception localException)
      {
        String str = localException.getMessage();
        throw new JceDecodeException(str);
      }
      localJceStruct.readFrom(this);
      skipToStructEnd();
    }
    do
      return localJceStruct;
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public ByteBuffer getBs()
  {
    return this.bs;
  }

  public byte read(byte paramByte, int paramInt, boolean paramBoolean)
  {
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramByte = null;
      case 0:
      }
    }
    do
      while (true)
      {
        return paramByte;
        paramByte = this.bs.get();
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public double read(double paramDouble, int paramInt, boolean paramBoolean)
  {
    boolean paramBoolean;
    if (skipToTag(???))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramDouble = 0L;
      case 4:
      case 5:
      }
    }
    do
      while (true)
      {
        return paramDouble;
        paramDouble = this.bs.getFloat();
        continue;
        paramDouble = this.bs.getDouble();
      }
    while (paramInt == 0);
    throw new JceDecodeException("require field not exist.");
  }

  public float read(float paramFloat, int paramInt, boolean paramBoolean)
  {
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramFloat = null;
      case 4:
      }
    }
    do
      while (true)
      {
        return paramFloat;
        paramFloat = this.bs.getFloat();
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public int read(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (skipToTag(paramInt2))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramInt1 = null;
      case 0:
      case 1:
      case 2:
      }
    }
    do
      while (true)
      {
        return paramInt1;
        paramInt1 = this.bs.get();
        continue;
        paramInt1 = this.bs.getShort();
        continue;
        paramInt1 = this.bs.getInt();
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public long read(long paramLong, int paramInt, boolean paramBoolean)
  {
    boolean paramBoolean;
    if (skipToTag(???))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramLong = 0L;
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    do
      while (true)
      {
        return paramLong;
        paramLong = this.bs.get();
        continue;
        paramLong = this.bs.getShort();
        continue;
        paramLong = this.bs.getInt();
        continue;
        paramLong = this.bs.getLong();
      }
    while (paramInt == 0);
    throw new JceDecodeException("require field not exist.");
  }

  public JceStruct read(JceStruct paramJceStruct, int paramInt, boolean paramBoolean)
  {
    int i = 0;
    JceStruct localJceStruct;
    if (skipToTag(paramInt))
    {
      try
      {
        localJceStruct = (JceStruct)paramJceStruct.getClass().newInstance();
        HeadData localHeadData = new HeadData();
        readHead(localHeadData);
        if (localHeadData.type != 10)
          throw new JceDecodeException("type mismatch.");
      }
      catch (Exception localException)
      {
        String str = localException.getMessage();
        throw new JceDecodeException(str);
      }
      localJceStruct.readFrom(this);
      skipToStructEnd();
    }
    do
      return localJceStruct;
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(TT;IZ)", "Ljava/lang/Object;"})
  public Object read(Object paramObject, int paramInt, boolean paramBoolean)
  {
    byte b = null;
    int i = 0;
    if (paramObject instanceof Byte);
    for (Object localObject = Byte.valueOf(read(b, paramInt, paramBoolean)); ; localObject = readArray(paramObject, paramInt, paramBoolean))
    {
      while (true)
      {
        return localObject;
        if (paramObject instanceof Boolean)
          localObject = Boolean.valueOf(read(b, paramInt, paramBoolean));
        if (paramObject instanceof Short)
          localObject = Short.valueOf(read(b, paramInt, paramBoolean));
        if (paramObject instanceof Integer)
          localObject = Integer.valueOf(read(b, paramInt, paramBoolean));
        if (paramObject instanceof Long)
          localObject = Long.valueOf(read(0L, paramInt, paramBoolean));
        if (paramObject instanceof Float)
          localObject = Float.valueOf(read(null, paramInt, paramBoolean));
        if (paramObject instanceof Double)
          localObject = Double.valueOf(read(0L, paramInt, paramBoolean));
        if (paramObject instanceof String)
          localObject = String.valueOf(readString(paramInt, paramBoolean));
        if (paramObject instanceof Map)
        {
          Map localMap = (Map)paramObject;
          localObject = readMap(paramObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof List)
        {
          List localList = (List)paramObject;
          localObject = readArray(paramObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof JceStruct)
        {
          JceStruct localJceStruct = (JceStruct)paramObject;
          localObject = read(paramObject, paramInt, paramBoolean);
        }
        if (!paramObject.getClass().isArray())
          break label491;
        if ((paramObject instanceof byte[]) || (paramObject instanceof Byte[]))
        {
          localObject = (byte[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof boolean[])
        {
          localObject = (boolean[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof short[])
        {
          localObject = (short[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof int[])
        {
          localObject = (int[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof long[])
        {
          localObject = (long[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (paramObject instanceof float[])
        {
          localObject = (float[])localObject;
          localObject = read(localObject, paramInt, paramBoolean);
        }
        if (!paramObject instanceof double[])
          break;
        localObject = (double[])localObject;
        localObject = read(localObject, paramInt, paramBoolean);
      }
      Object[] arrayOfObject = (Object[])(Object[])paramObject;
    }
    label491: throw new JceDecodeException("read object error: unsupport type.");
  }

  public String read(String paramString, int paramInt, boolean paramBoolean)
  {
    byte[] arrayOfByte;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 6:
        byte b = this.bs.get();
        int i;
        if (b < 0)
          b += 256;
        arrayOfByte = new byte[i];
        this.bs.get(arrayOfByte);
      case 7:
      }
    }
    do
      while (true)
      {
        label118: int j;
        try
        {
          String str1 = this.sServerEncoding;
          paramString = new String(arrayOfByte, str1);
          return paramString;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          paramString = new String(arrayOfByte);
          break label118:
          j = this.bs.getInt();
          if ((j > 104857600) || (j < 0))
          {
            String str2 = "String too long: " + j;
            throw new JceDecodeException(str2);
          }
        }
        arrayOfByte = new byte[j];
        this.bs.get(arrayOfByte);
        try
        {
          String str3 = this.sServerEncoding;
          paramString = new String(arrayOfByte, str3);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          paramString = new String(arrayOfByte);
        }
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public short read(short paramShort, int paramInt, boolean paramBoolean)
  {
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 12:
        paramShort = null;
      case 0:
      case 1:
      }
    }
    do
      while (true)
      {
        return paramShort;
        paramShort = (short)this.bs.get();
        continue;
        paramShort = this.bs.getShort();
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public boolean read(boolean paramBoolean1, int paramInt, boolean paramBoolean2)
  {
    byte b = null;
    int i;
    if (read(b, paramInt, paramBoolean2) != 0)
      i = 1;
    return i;
  }

  public byte[] read(byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    int i1;
    byte[] arrayOfByte;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData1 = new HeadData();
      readHead(localHeadData1);
      switch (localHeadData1.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 13:
        HeadData localHeadData2 = new HeadData();
        readHead(localHeadData2);
        if (localHeadData2.type != 0)
        {
          StringBuilder localStringBuilder1 = new StringBuilder().append("type mismatch, tag: ").append(paramInt).append(", type: ");
          int k = localHeadData1.type;
          StringBuilder localStringBuilder2 = localStringBuilder1.append(k).append(", ");
          int l = localHeadData2.type;
          String str1 = l;
          throw new JceDecodeException(str1);
        }
        i1 = read(i, i, bool);
        if (i1 < 0)
        {
          StringBuilder localStringBuilder3 = new StringBuilder().append("invalid size, tag: ").append(paramInt).append(", type: ");
          int i2 = localHeadData1.type;
          StringBuilder localStringBuilder4 = localStringBuilder3.append(i2).append(", ");
          int i3 = localHeadData2.type;
          String str2 = i3 + ", size: " + i1;
          throw new JceDecodeException(str2);
        }
        arrayOfByte = new byte[i1];
        this.bs.get(arrayOfByte);
      case 9:
      }
    }
    do
    {
      return arrayOfByte;
      i1 = read(i, i, bool);
      if (i1 < 0)
      {
        String str3 = "size invalid: " + i1;
        throw new JceDecodeException(str3);
      }
      arrayOfByte = new byte[i1];
      for (int i4 = 0; ; ++i4)
      {
        if (i4 < i1);
        byte b1 = arrayOfByte[i];
        byte b2 = read(b1, i, bool);
        arrayOfByte[i4] = b2;
      }
    }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public double[] read(double[] paramArrayOfDouble, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    double[] arrayOfDouble;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      arrayOfDouble = new double[k];
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label177;
        long l1 = arrayOfDouble[i];
        double d = read(l1, i, bool);
        Object localObject;
        arrayOfDouble[l] = localObject;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label177: return arrayOfDouble;
  }

  public float[] read(float[] paramArrayOfFloat, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    float[] arrayOfFloat;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      arrayOfFloat = new float[k];
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label177;
        int i1 = arrayOfFloat[i];
        float f = read(i1, i, bool);
        arrayOfFloat[l] = f;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label177: return arrayOfFloat;
  }

  public int[] read(int[] paramArrayOfInt, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    int[] arrayOfInt;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      arrayOfInt = new int[k];
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label177;
        int i1 = arrayOfInt[i];
        int i2 = read(i1, i, bool);
        arrayOfInt[l] = i2;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label177: return arrayOfInt;
  }

  public long[] read(long[] paramArrayOfLong, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    Object localObject1;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      localObject1 = k;
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label175;
        long l1 = localObject1[i];
        long l2 = read(l1, i, bool);
        Object localObject2;
        localObject1[l] = localObject2;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label175: return localObject1;
  }

  public JceStruct[] read(JceStruct[] paramArrayOfJceStruct, int paramInt, boolean paramBoolean)
  {
    return (JceStruct[])readArray(paramArrayOfJceStruct, paramInt, paramBoolean);
  }

  public String[] read(String[] paramArrayOfString, int paramInt, boolean paramBoolean)
  {
    return (String[])readArray(paramArrayOfString, paramInt, paramBoolean);
  }

  public short[] read(short[] paramArrayOfShort, int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    Object localObject;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      localObject = k;
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label175;
        short s1 = localObject[i];
        short s2 = read(s1, i, bool);
        localObject[l] = s2;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label175: return localObject;
  }

  public boolean[] read(boolean[] paramArrayOfBoolean, int paramInt, boolean paramBoolean)
  {
    boolean bool1 = true;
    int i = 0;
    int j = 0;
    boolean[] arrayOfBoolean;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int k = read(i, i, bool1);
      if (k < 0)
      {
        String str = "size invalid: " + k;
        throw new JceDecodeException(str);
      }
      arrayOfBoolean = new boolean[k];
      for (int l = 0; ; ++l)
      {
        if (l >= k)
          break label177;
        int i1 = arrayOfBoolean[i];
        boolean bool2 = read(i1, i, bool1);
        arrayOfBoolean[l] = bool2;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label177: return arrayOfBoolean;
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">(", "Ljava/util/List", "<TT;>;IZ)", "Ljava/util/List", "<TT;>;"})
  public List readArray(List paramList, int paramInt, boolean paramBoolean)
  {
    if (paramList != null)
    {
      boolean bool = paramList.isEmpty();
      if (!bool)
        break label29;
    }
    label29: ArrayList localArrayList;
    Object localObject2;
    for (Object localObject1 = new ArrayList(); ; localObject2 = localArrayList)
    {
      Object[] arrayOfObject;
      int i;
      while (true)
      {
        return localObject1;
        localObject1 = paramList.get(0);
        arrayOfObject = readArrayImpl(localObject1, paramInt, paramBoolean);
        if (arrayOfObject != null)
          break;
        i = 0;
      }
      localArrayList = new ArrayList();
      Object localObject3 = null;
      while (true)
      {
        i = arrayOfObject.length;
        if (localObject3 >= i)
          break;
        localObject2 = arrayOfObject[localObject3];
        localArrayList.add(localObject2);
        ++localObject3;
      }
    }
  }

  @Signature({"<T:", "Ljava/lang/Object;", ">([TT;IZ)[TT;"})
  public Object[] readArray(Object[] paramArrayOfObject, int paramInt, boolean paramBoolean)
  {
    if ((paramArrayOfObject == null) || (paramArrayOfObject.length == 0))
      throw new JceDecodeException("unable to get type of key and value.");
    Object localObject = paramArrayOfObject[null];
    return readArrayImpl(localObject, paramInt, paramBoolean);
  }

  public String readByteString(String paramString, int paramInt, boolean paramBoolean)
  {
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 6:
        byte b = this.bs.get();
        int i;
        if (b < 0)
          b += 256;
        byte[] arrayOfByte1 = new byte[i];
        this.bs.get(arrayOfByte1);
        paramString = HexUtil.bytes2HexStr(arrayOfByte1);
      case 7:
      }
    }
    do
      while (true)
      {
        return paramString;
        int j = this.bs.getInt();
        if ((j > 104857600) || (j < 0))
        {
          String str = "String too long: " + j;
          throw new JceDecodeException(str);
        }
        byte[] arrayOfByte2 = new byte[j];
        this.bs.get(arrayOfByte2);
        paramString = HexUtil.bytes2HexStr(arrayOfByte2);
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  public void readHead(HeadData paramHeadData)
  {
    ByteBuffer localByteBuffer = this.bs;
    readHead(paramHeadData, localByteBuffer);
  }

  public List readList(int paramInt, boolean paramBoolean)
  {
    ArrayList localArrayList = new ArrayList();
    if (skipToTag(paramInt))
    {
      HeadData localHeadData1 = new HeadData();
      readHead(localHeadData1);
      switch (localHeadData1.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 9:
      }
      int i = read(0, 0, true);
      if (i < 0)
      {
        String str1 = "size invalid: " + i;
        throw new JceDecodeException(str1);
      }
      Object localObject = null;
      label115: if (localObject >= i)
        break label460;
      HeadData localHeadData2 = new HeadData();
      readHead(localHeadData2);
      switch (localHeadData2.type)
      {
      case 11:
      default:
        throw new JceDecodeException("type mismatch.");
      case 0:
        skip(1);
      case 8:
      case 9:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 10:
      case 12:
      }
      while (true)
      {
        ++localObject;
        break label115:
        skip(2);
        continue;
        skip(4);
        continue;
        skip(8);
        continue;
        skip(4);
        continue;
        skip(8);
        continue;
        byte b = this.bs.get();
        int j;
        if (b < 0)
          b += 256;
        skip(j);
        continue;
        int k = this.bs.getInt();
        skip(k);
        continue;
        try
        {
          Class localClass = Class.forName(JceStruct.class.getName());
          Class[] arrayOfClass = new Class[null];
          Constructor localConstructor = localClass.getConstructor(arrayOfClass);
          Object[] arrayOfObject = new Object[null];
          JceStruct localJceStruct = (JceStruct)localConstructor.newInstance(arrayOfObject);
          localJceStruct.readFrom(this);
          skipToStructEnd();
          localArrayList.add(localJceStruct);
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          String str2 = "type mismatch." + localException;
          throw new JceDecodeException(str2);
        }
        Integer localInteger = new Integer(0);
        localArrayList.add(localInteger);
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label460: return localArrayList;
  }

  @Signature({"<K:", "Ljava/lang/Object;", "V:", "Ljava/lang/Object;", ">(", "Ljava/util/Map", "<TK;TV;>;IZ)", "Ljava/util/HashMap", "<TK;TV;>;"})
  public HashMap readMap(Map paramMap, int paramInt, boolean paramBoolean)
  {
    HashMap localHashMap = new HashMap();
    return (HashMap)readMap(localHashMap, paramMap, paramInt, paramBoolean);
  }

  public String readString(int paramInt, boolean paramBoolean)
  {
    int i = 0;
    byte[] arrayOfByte;
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 6:
        byte b = this.bs.get();
        int j;
        if (b < 0)
          b += 256;
        arrayOfByte = new byte[j];
        this.bs.get(arrayOfByte);
      case 7:
      }
    }
    do
      while (true)
      {
        String str1;
        label118: int k;
        try
        {
          String str2 = this.sServerEncoding;
          str1 = new String(arrayOfByte, str2);
          return str1;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          str1 = new String(arrayOfByte);
          break label118:
          k = this.bs.getInt();
          if ((k > 104857600) || (k < 0))
          {
            String str3 = "String too long: " + k;
            throw new JceDecodeException(str3);
          }
        }
        arrayOfByte = new byte[k];
        this.bs.get(arrayOfByte);
        try
        {
          String str4 = this.sServerEncoding;
          str1 = new String(arrayOfByte, str4);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          str1 = new String(arrayOfByte);
        }
      }
    while (!paramBoolean);
    throw new JceDecodeException("require field not exist.");
  }

  @Signature({"(IZ)", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  public Map readStringMap(int paramInt, boolean paramBoolean)
  {
    int i = 0;
    int j = 1;
    HashMap localHashMap = new HashMap();
    if (skipToTag(paramInt))
    {
      HeadData localHeadData = new HeadData();
      readHead(localHeadData);
      switch (localHeadData.type)
      {
      default:
        throw new JceDecodeException("type mismatch.");
      case 8:
      }
      int k = read(i, i, j);
      if (k < 0)
      {
        String str1 = "size invalid: " + k;
        throw new JceDecodeException(str1);
      }
      Object localObject = null;
      while (true)
      {
        if (localObject >= k)
          break label176;
        String str2 = readString(i, j);
        String str3 = readString(j, j);
        localHashMap.put(str2, str3);
        ++localObject;
      }
    }
    if (paramBoolean)
      throw new JceDecodeException("require field not exist.");
    label176: return localHashMap;
  }

  public int setServerEncoding(String paramString)
  {
    this.sServerEncoding = paramString;
    return null;
  }

  public void skipToStructEnd()
  {
    HeadData localHeadData = new HeadData();
    do
    {
      readHead(localHeadData);
      byte b = localHeadData.type;
      skipField(b);
    }
    while (localHeadData.type != 11);
  }

  public boolean skipToTag(int paramInt)
  {
    Object localObject1 = null;
    try
    {
      HeadData localHeadData = new HeadData();
      int i = peakHead(localHeadData);
      int j = localHeadData.tag;
      if (paramInt > j)
      {
        k = localHeadData.type;
        if (k != 11)
          break label66;
      }
      int k = localHeadData.tag;
      int l;
      if (paramInt == k)
        l = 1;
      while (true)
      {
        label57: return l;
        Object localObject2 = localObject1;
      }
      label66: skip(i);
      byte b = localHeadData.type;
      label89: skipField(b);
    }
    catch (JceDecodeException localObject3)
    {
      Object localObject3 = localObject1;
      break label57:
    }
    catch (BufferUnderflowException localBufferUnderflowException)
    {
      break label89:
    }
  }

  public void warp(byte[] paramArrayOfByte)
  {
    if (this.bs != null)
      this.bs.clear();
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    this.bs = localByteBuffer;
  }

  public class HeadData
  {
    public int tag;
    public byte type;

    public void clear()
    {
      this.type = null;
      this.tag = null;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.jce.JceInputStream
 * JD-Core Version:    0.5.4
 */