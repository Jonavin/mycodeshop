package com.qq.taf;

import com.qq.jce.wup.WupHexUtil;
import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import dalvik.annotation.Signature;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public final class RequestPacket extends JceStruct
{

  @Signature({"Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  static Map cache_context;
  static byte[] cache_sBuffer;
  public byte cPacketType = null;

  @Signature({"Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  public Map context;
  public int iMessageType = null;
  public int iRequestId = null;
  public int iTimeout = null;
  public short iVersion = null;
  public byte[] sBuffer;
  public String sFuncName = null;
  public String sServantName = null;

  @Signature({"Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;"})
  public Map status;

  static
  {
    int i = 0;
    if (!RequestPacket.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      cache_sBuffer = i;
      cache_context = i;
      return;
    }
  }

  public RequestPacket()
  {
  }

  @Signature({"(SBII", "Ljava/lang/String;", "Ljava/lang/String;", "[BI", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;", "Ljava/util/Map", "<", "Ljava/lang/String;", "Ljava/lang/String;", ">;)V"})
  public RequestPacket(short paramShort, byte paramByte, int paramInt1, int paramInt2, String paramString1, String paramString2, byte[] paramArrayOfByte, int paramInt3, Map paramMap1, Map paramMap2)
  {
    this.iVersion = paramShort;
    this.cPacketType = paramByte;
    this.iMessageType = paramInt1;
    this.iRequestId = paramInt2;
    this.sServantName = paramString1;
    this.sFuncName = paramString2;
    this.sBuffer = paramArrayOfByte;
    this.iTimeout = paramInt3;
    this.context = paramMap1;
    this.status = paramMap2;
  }

  public Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      int j;
      $assertionsDisabled = j;
      if (j == 0);
      throw new AssertionError();
    }
  }

  public void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    short s = this.iVersion;
    localJceDisplayer.display(s, "iVersion");
    byte b = this.cPacketType;
    localJceDisplayer.display(b, "cPacketType");
    int i = this.iMessageType;
    localJceDisplayer.display(i, "iMessageType");
    int j = this.iRequestId;
    localJceDisplayer.display(j, "iRequestId");
    String str1 = this.sServantName;
    localJceDisplayer.display(str1, "sServantName");
    String str2 = this.sFuncName;
    localJceDisplayer.display(str2, "sFuncName");
    byte[] arrayOfByte = this.sBuffer;
    localJceDisplayer.display(arrayOfByte, "sBuffer");
    int k = this.iTimeout;
    localJceDisplayer.display(k, "iTimeout");
    Map localMap1 = this.context;
    localJceDisplayer.display(localMap1, "context");
    Map localMap2 = this.status;
    localJceDisplayer.display(localMap2, "status");
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = 1;
    RequestPacket localRequestPacket = (RequestPacket)paramObject;
    int i = localRequestPacket.iVersion;
    boolean bool1 = JceUtil.equals(localObject1, i);
    Object localObject3;
    if (bool1)
    {
      int j = localRequestPacket.cPacketType;
      boolean bool2 = JceUtil.equals(localObject1, j);
      if (bool2)
      {
        int k = localRequestPacket.iMessageType;
        boolean bool3 = JceUtil.equals(localObject1, k);
        if (bool3)
        {
          int l = localRequestPacket.iRequestId;
          boolean bool4 = JceUtil.equals(localObject1, l);
          if (bool4)
          {
            Object localObject2 = Integer.valueOf(localObject1);
            String str1 = localRequestPacket.sServantName;
            localObject2 = JceUtil.equals(localObject2, str1);
            if (localObject2 != 0)
            {
              localObject2 = Integer.valueOf(localObject1);
              String str2 = localRequestPacket.sFuncName;
              localObject2 = JceUtil.equals(localObject2, str2);
              if (localObject2 != 0)
              {
                localObject2 = Integer.valueOf(localObject1);
                byte[] arrayOfByte = localRequestPacket.sBuffer;
                localObject2 = JceUtil.equals(localObject2, arrayOfByte);
                if (localObject2 != 0)
                {
                  int i1 = localRequestPacket.iTimeout;
                  boolean bool5 = JceUtil.equals(localObject1, i1);
                  if (bool5)
                  {
                    localObject3 = Integer.valueOf(localObject1);
                    Map localMap1 = localRequestPacket.context;
                    localObject3 = JceUtil.equals(localObject3, localMap1);
                    if (localObject3 != 0)
                    {
                      localObject3 = Integer.valueOf(localObject1);
                      Map localMap2 = localRequestPacket.status;
                      localObject3 = JceUtil.equals(localObject3, localMap2);
                      if (localObject3 != 0)
                        localObject3 = localObject1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return localObject3;
      localObject3 = null;
    }
  }

  public void readFrom(JceInputStream paramJceInputStream)
  {
    try
    {
      short s1 = this.iVersion;
      short s2 = paramJceInputStream.read(s1, 1, true);
      this.iVersion = s2;
      byte b1 = this.cPacketType;
      byte b2 = paramJceInputStream.read(b1, 2, true);
      this.cPacketType = b2;
      int i = this.iMessageType;
      int j = paramJceInputStream.read(i, 3, true);
      this.iMessageType = j;
      int k = this.iRequestId;
      int l = paramJceInputStream.read(k, 4, true);
      this.iRequestId = l;
      String str1 = paramJceInputStream.readString(5, true);
      this.sServantName = str1;
      String str2 = paramJceInputStream.readString(6, true);
      this.sFuncName = str2;
      if (cache_sBuffer == null)
      {
        byte[] arrayOfByte1 = new byte[1];
        arrayOfByte1[0] = null;
        cache_sBuffer = arrayOfByte1;
      }
      byte[] arrayOfByte2 = cache_sBuffer;
      byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 7, true);
      this.sBuffer = arrayOfByte3;
      int i1 = this.iTimeout;
      int i2 = paramJceInputStream.read(i1, 8, true);
      this.iTimeout = i2;
      if (cache_context == null)
      {
        cache_context = new HashMap();
        cache_context.put("", "");
      }
      Map localMap1 = cache_context;
      Map localMap2 = (Map)paramJceInputStream.read(localMap1, 9, true);
      this.context = localMap2;
      if (cache_context == null)
      {
        cache_context = new HashMap();
        cache_context.put("", "");
      }
      Map localMap3 = cache_context;
      Map localMap4 = (Map)paramJceInputStream.read(localMap3, 10, true);
      this.status = localMap4;
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      PrintStream localPrintStream = System.out;
      StringBuilder localStringBuilder = new StringBuilder().append("RequestPacket decode error ");
      String str3 = WupHexUtil.bytes2HexStr(this.sBuffer);
      String str4 = str3;
      localPrintStream.println(str4);
      throw new RuntimeException(localException);
    }
  }

  public void writeTo(JceOutputStream paramJceOutputStream)
  {
    short s = this.iVersion;
    paramJceOutputStream.write(s, 1);
    byte b = this.cPacketType;
    paramJceOutputStream.write(b, 2);
    int i = this.iMessageType;
    paramJceOutputStream.write(i, 3);
    int j = this.iRequestId;
    paramJceOutputStream.write(j, 4);
    String str1 = this.sServantName;
    paramJceOutputStream.write(str1, 5);
    String str2 = this.sFuncName;
    paramJceOutputStream.write(str2, 6);
    byte[] arrayOfByte = this.sBuffer;
    paramJceOutputStream.write(arrayOfByte, 7);
    int k = this.iTimeout;
    paramJceOutputStream.write(k, 8);
    Map localMap1 = this.context;
    paramJceOutputStream.write(localMap1, 9);
    Map localMap2 = this.status;
    paramJceOutputStream.write(localMap2, 10);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     com.qq.taf.RequestPacket
 * JD-Core Version:    0.5.4
 */