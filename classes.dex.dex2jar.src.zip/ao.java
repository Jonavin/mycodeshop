import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.video.VcCamera;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.mobileqq.video.surfaceview.Preview;
import com.tencent.mobileqq.video.surfaceview.RemoteView;

final class ao
  implements View.OnClickListener
{
  ao(al paramal)
  {
  }

  public final void onClick(View paramView)
  {
    int i = 4;
    int j = 0;
    boolean bool = ChatVideoActivity.access$000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).a();
    ChatVideoActivity.access$000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).a(j);
    View localView = this.a.jdField_a_of_type_AndroidWidgetFrameLayout.getChildAt(j);
    this.a.jdField_a_of_type_AndroidWidgetFrameLayout.removeAllViews();
    this.a.b.removeAllViews();
    Preview localPreview1 = ChatVideoActivity.access$1200(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    if (localView == localPreview1)
    {
      FrameLayout localFrameLayout1 = this.a.jdField_a_of_type_AndroidWidgetFrameLayout;
      RemoteView localRemoteView1 = ChatVideoActivity.access$600(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
      localFrameLayout1.addView(localRemoteView1);
      FrameLayout localFrameLayout2 = this.a.b;
      Preview localPreview2 = ChatVideoActivity.access$1200(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
      localFrameLayout2.addView(localPreview2);
      if (!ChatVideoActivity.access$1600(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity))
      {
        ChatVideoActivity.access$1700(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(i);
        ChatVideoActivity.access$1800(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(i);
        ChatVideoActivity.access$1900(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(j);
        ChatVideoActivity.access$2000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(j);
      }
    }
    while (true)
    {
      ChatVideoActivity.access$000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).a().c();
      if (bool)
        ChatVideoActivity.access$000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).a(true);
      return;
      FrameLayout localFrameLayout3 = this.a.jdField_a_of_type_AndroidWidgetFrameLayout;
      Preview localPreview3 = ChatVideoActivity.access$1200(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
      localFrameLayout3.addView(localPreview3);
      FrameLayout localFrameLayout4 = this.a.b;
      RemoteView localRemoteView2 = ChatVideoActivity.access$600(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
      localFrameLayout4.addView(localRemoteView2);
      if (ChatVideoActivity.access$1600(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity))
        continue;
      ChatVideoActivity.access$1700(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(j);
      ChatVideoActivity.access$1800(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(j);
      ChatVideoActivity.access$1900(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(i);
      ChatVideoActivity.access$2000(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setVisibility(i);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ao
 * JD-Core Version:    0.5.4
 */