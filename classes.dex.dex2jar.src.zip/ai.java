import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter;

public final class ai extends AsyncQueryHandler
{
  public ai(ChatHistory.ChatHistoryAdapter paramChatHistoryAdapter, Context paramContext)
  {
    super(localContentResolver);
  }

  protected final void onQueryComplete(int paramInt, Object paramObject, Cursor paramCursor)
  {
    if (paramCursor == null)
      return;
    if (this.a.getCursor() != null)
      this.a.getCursor().deactivate();
    this.a.changeCursor(paramCursor);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ai
 * JD-Core Version:    0.5.4
 */