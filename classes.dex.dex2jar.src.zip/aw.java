import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.TroopMemberlistActivity;

public final class aw
  implements View.OnClickListener
{
  public aw(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    if (ChatWindowActivity.access$2100(this.a) == 1)
    {
      ChatWindowActivity localChatWindowActivity = this.a;
      Intent localIntent1 = new Intent(localChatWindowActivity, TroopMemberlistActivity.class);
      String str = this.a.a;
      Intent localIntent2 = localIntent1.putExtra("groupUin", str);
      this.a.startActivity(localIntent2);
    }
    while (true)
    {
      return;
      this.a.finish();
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     aw
 * JD-Core Version:    0.5.4
 */