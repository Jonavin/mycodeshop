import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.utils.Recorder;

public final class ba extends Handler
{
  public ba(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    int i = 0;
    int j = 100;
    int k = 1;
    int l = 1120403456;
    int i1 = -1;
    int i2 = paramMessage.what;
    if (i2 == 0)
      this.a.c();
    do
    {
      label34: return;
      i2 = paramMessage.what;
    }
    while (i2 != k);
    Object localObject = ChatWindowActivity.access$2500(this.a);
    if (((cb)localObject).a != null);
    for (localObject = ((cb)localObject).a.a(); ; localObject = i)
    {
      if (localObject != 0);
      localObject = this.a;
      WindowManager localWindowManager1 = (WindowManager)((ChatWindowActivity)localObject).getSystemService("window");
      ((ChatWindowActivity)localObject).jdField_a_of_type_AndroidViewWindowManager = this;
      if (((ChatWindowActivity)localObject).jdField_a_of_type_Float > 1065353216)
        ((ChatWindowActivity)localObject).e = j;
      int i20;
      for (((ChatWindowActivity)localObject).f = j; ; ((ChatWindowActivity)localObject).f = i20)
      {
        int i3 = ((ChatWindowActivity)localObject).jdField_a_of_type_Float;
        int i4 = (int)(1126629376 * i3);
        ((ChatWindowActivity)localObject).jdField_a_of_type_Int = i4;
        int i5 = ((ChatWindowActivity)localObject).jdField_a_of_type_Float;
        int i6 = (int)(1126105088 * i5);
        ((ChatWindowActivity)localObject).jdField_b_of_type_Int = i6;
        int i7 = ((ChatWindowActivity)localObject).jdField_a_of_type_Int;
        int i8 = ((ChatWindowActivity)localObject).e;
        int i9 = (i7 - i8) / 2;
        ((ChatWindowActivity)localObject).c = i9;
        int i10 = ((ChatWindowActivity)localObject).jdField_b_of_type_Int;
        int i11 = ((ChatWindowActivity)localObject).f;
        int i12 = (i10 - i11) / 2;
        ((ChatWindowActivity)localObject).d = i12;
        ImageView localImageView1 = (ImageView)((LayoutInflater)((ChatWindowActivity)localObject).getSystemService("layout_inflater")).inflate(2130903051, i);
        ((ChatWindowActivity)localObject).jdField_b_of_type_AndroidWidgetImageView = localImageView1;
        ImageView localImageView2 = ((ChatWindowActivity)localObject).jdField_b_of_type_AndroidWidgetImageView;
        int i13 = ((ChatWindowActivity)localObject).c;
        int i14 = ((ChatWindowActivity)localObject).d;
        int i15 = ((ChatWindowActivity)localObject).c;
        int i16 = ((ChatWindowActivity)localObject).d;
        localImageView2.setPadding(i13, i14, i15, i);
        ((ChatWindowActivity)localObject).a(k);
        ImageView localImageView3 = ((ChatWindowActivity)localObject).jdField_b_of_type_AndroidWidgetImageView;
        ((ChatWindowActivity)localObject).jdField_a_of_type_AndroidWidgetImageView = localImageView3;
        WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams(-1, i1);
        localLayoutParams.dimAmount = 1056964608;
        localLayoutParams.flags = 8;
        int i17 = localLayoutParams.flags | 0x40000;
        localLayoutParams.flags = i17;
        int i18 = localLayoutParams.flags | 0x200;
        localLayoutParams.flags = i18;
        localLayoutParams.type = 2003;
        localLayoutParams.width = i1;
        localLayoutParams.height = i1;
        localLayoutParams.gravity = 17;
        localLayoutParams.format = -1;
        WindowManager localWindowManager2 = ((ChatWindowActivity)localObject).jdField_a_of_type_AndroidViewWindowManager;
        ImageView localImageView4 = ((ChatWindowActivity)localObject).jdField_a_of_type_AndroidWidgetImageView;
        localWindowManager2.addView(localImageView4, localLayoutParams);
        ((ChatWindowActivity)localObject).jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(0, 500L);
        break label34:
        int i19 = (int)(((ChatWindowActivity)localObject).jdField_a_of_type_Float * l);
        ((ChatWindowActivity)localObject).e = i19;
        i20 = (int)(((ChatWindowActivity)localObject).jdField_a_of_type_Float * l);
      }
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ba
 * JD-Core Version:    0.5.4
 */