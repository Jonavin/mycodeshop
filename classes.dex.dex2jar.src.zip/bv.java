import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bv
  implements View.OnClickListener
{
  public bv(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity.access$600(this.a, true, null, 0);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bv
 * JD-Core Version:    0.5.4
 */