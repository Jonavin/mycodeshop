import com.tencent.mobileqq.activity.ContactActivity;
import com.tencent.mobileqq.widget.CustomedTabWidget;
import com.tencent.mobileqq.widget.Workspace.OnScreenChangeListener;

public final class cf
  implements Workspace.OnScreenChangeListener
{
  cf(ContactActivity paramContactActivity)
  {
  }

  public final void a(int paramInt)
  {
    int i = ContactActivity.access$000(this.a).a;
    if (paramInt == i)
      return;
    ContactActivity.access$000(this.a).setCurrentTab(paramInt);
  }

  public final void b(int paramInt)
  {
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cf
 * JD-Core Version:    0.5.4
 */