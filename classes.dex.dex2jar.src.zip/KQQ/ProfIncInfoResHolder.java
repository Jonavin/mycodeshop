package KQQ;

public final class ProfIncInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfIncInfoResHolder
 * JD-Core Version:    0.5.4
 */