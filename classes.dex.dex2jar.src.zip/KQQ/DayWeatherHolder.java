package KQQ;

public final class DayWeatherHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.DayWeatherHolder
 * JD-Core Version:    0.5.4
 */