package KQQ;

public final class ProfVipqqInfoReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfVipqqInfoReqHolder
 * JD-Core Version:    0.5.4
 */