package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfIncInfoReq extends JceStruct
{
  public int a;
  public long a;
  public int b = null;

  static
  {
    if (!ProfIncInfoReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfIncInfoReq()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "iUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "iRetIncomPlete");
    int j = this.b;
    localJceDisplayer.display(j, "iReloadFlag");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfIncInfoReq)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int k;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int l = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, l);
      if (bool2)
      {
        int j = this.b;
        int i1 = paramObject.b;
        boolean bool3 = JceUtil.equals(j, i1);
        if (bool3)
          k = 1;
      }
    }
    while (true)
    {
      return k;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 1, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 2, null);
    this.jdField_a_of_type_Int = j;
    int k = this.b;
    int l = paramJceInputStream.read(k, 3, null);
    this.b = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 1);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 2);
    int j = this.b;
    paramJceOutputStream.write(j, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfIncInfoReq
 * JD-Core Version:    0.5.4
 */