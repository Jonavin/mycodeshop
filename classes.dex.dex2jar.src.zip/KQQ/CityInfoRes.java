package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class CityInfoRes extends JceStruct
{
  public byte a;
  public String a;

  static
  {
    if (!CityInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public CityInfoRes()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b, "result");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "city");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (CityInfoRes)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramObject.jdField_a_of_type_Byte;
    boolean bool = JceUtil.equals(b1, b2);
    int i;
    if (bool)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.CityInfoRes
 * JD-Core Version:    0.5.4
 */