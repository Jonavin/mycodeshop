package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class ProfFullUsrQryReq extends JceStruct
{
  static ArrayList cache_vFriendUin;
  public int a;
  public long a;
  public String a;
  public ArrayList a;
  public int b = null;
  public int c = null;

  static
  {
    if (!ProfFullUsrQryReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfFullUsrQryReq()
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_JavaUtilArrayList = null;
  }

  public ProfFullUsrQryReq(String paramString, long paramLong, ArrayList paramArrayList)
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_Long = paramLong;
    this.jdField_a_of_type_JavaUtilArrayList = ???;
    this.b = 1;
    this.c = 1;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "iAppId");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strSessionKey");
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "usruin");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vFriendUin");
    int j = this.b;
    localJceDisplayer.display(j, "iRetIncomPlete");
    int k = this.c;
    localJceDisplayer.display(k, "iReloadFlag");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfFullUsrQryReq)paramObject;
    int i = this.jdField_a_of_type_Int;
    int i1 = paramObject.jdField_a_of_type_Int;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
      {
        long l1 = this.jdField_a_of_type_Long;
        long l2 = paramObject.jdField_a_of_type_Long;
        localObject1 = JceUtil.equals(l1, l2);
        if (localObject1 != 0)
        {
          localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
          ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
          localObject1 = JceUtil.equals(localObject1, localArrayList);
          if (localObject1 != 0)
          {
            int j = this.b;
            int i2 = paramObject.b;
            boolean bool2 = JceUtil.equals(j, i2);
            if (bool2)
            {
              int k = this.c;
              int i3 = paramObject.c;
              boolean bool3 = JceUtil.equals(k, i3);
              if (bool3)
                l = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    boolean bool = null;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    String str = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 3, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    if (cache_vFriendUin == null)
    {
      cache_vFriendUin = new ArrayList();
      Long localLong = Long.valueOf(0L);
      cache_vFriendUin.add(localLong);
    }
    ArrayList localArrayList1 = cache_vFriendUin;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 4, bool);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    int k = this.b;
    int l = paramJceInputStream.read(k, 5, bool);
    this.b = l;
    int i1 = this.c;
    int i2 = paramJceInputStream.read(i1, 6, bool);
    this.c = i2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 3);
    if (this.jdField_a_of_type_JavaUtilArrayList != null)
    {
      ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
      paramJceOutputStream.write(localArrayList, 4);
    }
    int j = this.b;
    paramJceOutputStream.write(j, 5);
    int k = this.c;
    paramJceOutputStream.write(k, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfFullUsrQryReq
 * JD-Core Version:    0.5.4
 */