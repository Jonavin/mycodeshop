package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfIncInfoRes extends JceStruct
{
  public int a;
  public short a;
  public int b = null;

  static
  {
    if (!ProfIncInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfIncInfoRes()
  {
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wLevel");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uOnlineTime");
    int j = this.b;
    localJceDisplayer.display(j, "uRemainTime");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfIncInfoRes)paramObject;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramObject.jdField_a_of_type_Short;
    boolean bool1 = JceUtil.equals(s1, s2);
    int k;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int l = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, l);
      if (bool2)
      {
        int j = this.b;
        int i1 = paramObject.b;
        boolean bool3 = JceUtil.equals(j, i1);
        if (bool3)
          k = 1;
      }
    }
    while (true)
    {
      return k;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 1, true);
    this.jdField_a_of_type_Short = s2;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 2, true);
    this.jdField_a_of_type_Int = j;
    int k = this.b;
    int l = paramJceInputStream.read(k, 3, true);
    this.b = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 1);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 2);
    int j = this.b;
    paramJceOutputStream.write(j, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfIncInfoRes
 * JD-Core Version:    0.5.4
 */