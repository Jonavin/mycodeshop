package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ClientInfo extends JceStruct
{
  static int cache_eUinType;
  public int a;
  public String a;
  public String b = "";
  public String c = "";

  static
  {
    if (!ClientInfo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ClientInfo()
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "eUinType");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strUin");
    String str2 = this.b;
    localJceDisplayer.display(str2, "strAuthName");
    String str3 = this.c;
    localJceDisplayer.display(str3, "strAuthPassword");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ClientInfo)paramObject;
    int i = this.jdField_a_of_type_Int;
    int k = paramObject.jdField_a_of_type_Int;
    boolean bool = JceUtil.equals(i, k);
    int j;
    if (bool)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str1 = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        localObject1 = this.b;
        String str2 = paramObject.b;
        localObject1 = JceUtil.equals(localObject1, str2);
        if (localObject1 != 0)
        {
          localObject1 = this.c;
          String str3 = paramObject.c;
          localObject1 = JceUtil.equals(localObject1, str3);
          if (localObject1 != 0)
            j = 1;
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    String str1 = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(3, true);
    this.b = str2;
    String str3 = paramJceInputStream.readString(4, true);
    this.c = str3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    String str2 = this.b;
    paramJceOutputStream.write(str2, 3);
    String str3 = this.c;
    paramJceOutputStream.write(str3, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ClientInfo
 * JD-Core Version:    0.5.4
 */