package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class ProfRecentRes extends JceStruct
{
  static ArrayList cache_vFriendInfo;
  public byte a;
  public long a;
  public ArrayList a;
  public short a;
  public byte b = null;

  static
  {
    if (!ProfRecentRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfRecentRes()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_JavaUtilArrayList = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cResult");
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "uServerTime");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cMask");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wFriendNum");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vFriendInfo");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfRecentRes)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b3 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b3);
    int i;
    if (bool1)
    {
      long l1 = this.jdField_a_of_type_Long;
      long l2 = paramObject.jdField_a_of_type_Long;
      bool1 = JceUtil.equals(l1, l2);
      if (bool1)
      {
        byte b2 = this.b;
        byte b4 = paramObject.b;
        boolean bool2 = JceUtil.equals(b2, b4);
        if (bool2)
        {
          short s1 = this.jdField_a_of_type_Short;
          short s2 = paramObject.jdField_a_of_type_Short;
          boolean bool3 = JceUtil.equals(s1, s2);
          if (bool3)
          {
            Object localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
            ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
            localObject1 = JceUtil.equals(localObject1, localArrayList);
            if (localObject1 != 0)
              i = 1;
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, i);
    this.jdField_a_of_type_Byte = b2;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 2, i);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 3, i);
    this.b = b4;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 4, i);
    this.jdField_a_of_type_Short = s2;
    if (cache_vFriendInfo == null)
    {
      cache_vFriendInfo = new ArrayList();
      FriendUinInfo localFriendUinInfo = new FriendUinInfo();
      cache_vFriendInfo.add(localFriendUinInfo);
    }
    ArrayList localArrayList1 = cache_vFriendInfo;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 5, i);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 2);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 3);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 4);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfRecentRes
 * JD-Core Version:    0.5.4
 */