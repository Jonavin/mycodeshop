package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.HashMap;
import java.util.Map;

public final class ProfSigSetResp extends JceStruct
{
  static Map cache_mapSetSigRet;
  public Map a = null;

  static
  {
    if (!ProfSigSetResp.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    Map localMap = this.a;
    localJceDisplayer.display(localMap, "mapSetSigRet");
  }

  public final boolean equals(Object paramObject)
  {
    ProfSigSetResp localProfSigSetResp = (ProfSigSetResp)paramObject;
    Map localMap1 = this.a;
    Map localMap2 = paramObject.a;
    return JceUtil.equals(localMap1, localMap2);
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    if (cache_mapSetSigRet == null)
    {
      cache_mapSetSigRet = new HashMap();
      Long localLong = Long.valueOf(0L);
      Integer localInteger = Integer.valueOf(0);
      cache_mapSetSigRet.put(localLong, localInteger);
    }
    Map localMap1 = cache_mapSetSigRet;
    Map localMap2 = (Map)paramJceInputStream.read(localMap1, i, i);
    this.a = localMap2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    Map localMap = this.a;
    paramJceOutputStream.write(localMap, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSigSetResp
 * JD-Core Version:    0.5.4
 */