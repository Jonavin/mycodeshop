package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ChangeFriendNameRes extends JceStruct
{
  public byte a = null;

  static
  {
    if (!ChangeFriendNameRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b = this.a;
    localJceDisplayer.display(b, "cResult");
  }

  public final boolean equals(Object paramObject)
  {
    ChangeFriendNameRes localChangeFriendNameRes = (ChangeFriendNameRes)paramObject;
    byte b1 = this.a;
    byte b2 = paramObject.a;
    return JceUtil.equals(b1, b2);
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    byte b1 = this.a;
    byte b2 = paramJceInputStream.read(b1, 0, true);
    this.a = b2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b = this.a;
    paramJceOutputStream.write(b, 0);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ChangeFriendNameRes
 * JD-Core Version:    0.5.4
 */