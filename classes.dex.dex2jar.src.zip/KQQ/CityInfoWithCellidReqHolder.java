package KQQ;

public final class CityInfoWithCellidReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.CityInfoWithCellidReqHolder
 * JD-Core Version:    0.5.4
 */