package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfSmpInfoRes extends JceStruct
{
  public byte a;
  public long a;
  public String a;
  public short a;
  public byte b = null;
  public byte c = null;

  static
  {
    if (!ProfSmpInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfSmpInfoRes()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "dwUin");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wFace");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSex");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "wAge");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strNick");
    byte b3 = this.c;
    localJceDisplayer.display(b3, "cResult");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfSmpInfoRes)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      short s1 = this.jdField_a_of_type_Short;
      short s2 = paramObject.jdField_a_of_type_Short;
      boolean bool2 = JceUtil.equals(s1, s2);
      if (bool2)
      {
        byte b1 = this.jdField_a_of_type_Byte;
        byte b4 = paramObject.jdField_a_of_type_Byte;
        boolean bool3 = JceUtil.equals(b1, b4);
        if (bool3)
        {
          byte b2 = this.b;
          byte b5 = paramObject.b;
          boolean bool4 = JceUtil.equals(b2, b5);
          if (bool4)
          {
            Object localObject1 = this.jdField_a_of_type_JavaLangString;
            String str = paramObject.jdField_a_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str);
            if (localObject1 != 0)
            {
              byte b3 = this.c;
              byte b6 = paramObject.c;
              boolean bool5 = JceUtil.equals(b3, b6);
              if (bool5)
                i = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 1, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, true);
    this.jdField_a_of_type_Short = s2;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, true);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 4, true);
    this.b = b4;
    String str = paramJceInputStream.readString(5, true);
    this.jdField_a_of_type_JavaLangString = str;
    byte b5 = this.c;
    byte b6 = paramJceInputStream.read(b5, 6, null);
    this.c = b6;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 1);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 2);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 4);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 5);
    byte b3 = this.c;
    paramJceOutputStream.write(b3, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSmpInfoRes
 * JD-Core Version:    0.5.4
 */