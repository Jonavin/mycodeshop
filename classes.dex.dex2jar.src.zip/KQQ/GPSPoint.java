package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class GPSPoint extends JceStruct
{
  public int a = 900000000;
  public int b = 900000000;
  public int c = null;

  static
  {
    if (!GPSPoint.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.a;
    localJceDisplayer.display(i, "lat");
    int j = this.b;
    localJceDisplayer.display(j, "lon");
    int k = this.c;
    localJceDisplayer.display(k, "alt");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (GPSPoint)paramObject;
    int i = this.a;
    int i1 = paramObject.a;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      int j = this.b;
      int i2 = paramObject.b;
      boolean bool2 = JceUtil.equals(j, i2);
      if (bool2)
      {
        int k = this.c;
        int i3 = paramObject.c;
        boolean bool3 = JceUtil.equals(k, i3);
        if (bool3)
          l = 1;
      }
    }
    while (true)
    {
      return l;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.a;
    int j = paramJceInputStream.read(i, 0, true);
    this.a = j;
    int k = this.b;
    int l = paramJceInputStream.read(k, 1, true);
    this.b = l;
    int i1 = this.c;
    int i2 = paramJceInputStream.read(i1, 2, true);
    this.c = i2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.a;
    paramJceOutputStream.write(i, 0);
    int j = this.b;
    paramJceOutputStream.write(j, 1);
    int k = this.c;
    paramJceOutputStream.write(k, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.GPSPoint
 * JD-Core Version:    0.5.4
 */