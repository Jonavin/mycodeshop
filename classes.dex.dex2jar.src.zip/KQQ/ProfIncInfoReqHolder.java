package KQQ;

public final class ProfIncInfoReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfIncInfoReqHolder
 * JD-Core Version:    0.5.4
 */