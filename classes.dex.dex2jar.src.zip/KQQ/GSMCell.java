package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class GSMCell extends JceStruct
{
  public int a;
  public short a;
  public int b;
  public short b;

  static
  {
    if (!GSMCell.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public GSMCell()
  {
    this.jdField_a_of_type_Short = -1;
    this.jdField_b_of_type_Short = -1;
    this.jdField_a_of_type_Int = -1;
    this.jdField_b_of_type_Int = -1;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    short s1 = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s1, "mcc");
    short s2 = this.jdField_b_of_type_Short;
    localJceDisplayer.display(s2, "mnc");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "lac");
    int j = this.jdField_b_of_type_Int;
    localJceDisplayer.display(j, "cellid");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (GSMCell)paramObject;
    short s1 = this.jdField_a_of_type_Short;
    short s3 = paramObject.jdField_a_of_type_Short;
    boolean bool1 = JceUtil.equals(s1, s3);
    int k;
    if (bool1)
    {
      short s2 = this.jdField_b_of_type_Short;
      short s4 = paramObject.jdField_b_of_type_Short;
      boolean bool2 = JceUtil.equals(s2, s4);
      if (bool2)
      {
        int i = this.jdField_a_of_type_Int;
        int l = paramObject.jdField_a_of_type_Int;
        boolean bool3 = JceUtil.equals(i, l);
        if (bool3)
        {
          int j = this.jdField_b_of_type_Int;
          int i1 = paramObject.jdField_b_of_type_Int;
          boolean bool4 = JceUtil.equals(j, i1);
          if (bool4)
            k = 1;
        }
      }
    }
    while (true)
    {
      return k;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 0, true);
    this.jdField_a_of_type_Short = s2;
    short s3 = this.jdField_b_of_type_Short;
    short s4 = paramJceInputStream.read(s3, 1, true);
    this.jdField_b_of_type_Short = s4;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 2, true);
    this.jdField_a_of_type_Int = j;
    int k = this.jdField_b_of_type_Int;
    int l = paramJceInputStream.read(k, 3, true);
    this.jdField_b_of_type_Int = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    short s1 = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s1, 0);
    short s2 = this.jdField_b_of_type_Short;
    paramJceOutputStream.write(s2, 1);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 2);
    int j = this.jdField_b_of_type_Int;
    paramJceOutputStream.write(j, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.GSMCell
 * JD-Core Version:    0.5.4
 */