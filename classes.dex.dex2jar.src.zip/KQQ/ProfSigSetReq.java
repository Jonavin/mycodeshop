package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfSigSetReq extends JceStruct
{
  public int a;
  public long a;
  public String a;
  public int b;
  public String b;

  static
  {
    if (!ProfSigSetReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfSigSetReq()
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_b_of_type_Int = null;
  }

  public ProfSigSetReq(String paramString1, long paramLong, String paramString2)
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_b_of_type_Int = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = paramString1;
    this.jdField_a_of_type_Long = paramLong;
    this.jdField_b_of_type_JavaLangString = ???;
    this.jdField_b_of_type_Int = 1;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "iAppId");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strSessionKey");
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "uin");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "signature");
    int j = this.jdField_b_of_type_Int;
    localJceDisplayer.display(j, "iRetIncomPlete");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfSigSetReq)paramObject;
    int i = this.jdField_a_of_type_Int;
    int l = paramObject.jdField_a_of_type_Int;
    boolean bool1 = JceUtil.equals(i, l);
    int k;
    if (bool1)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str1 = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str1);
      if (localObject1 != 0)
      {
        long l1 = this.jdField_a_of_type_Long;
        long l2 = paramObject.jdField_a_of_type_Long;
        localObject1 = JceUtil.equals(l1, l2);
        if (localObject1 != 0)
        {
          localObject1 = this.jdField_b_of_type_JavaLangString;
          String str2 = paramObject.jdField_b_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str2);
          if (localObject1 != 0)
          {
            int j = this.jdField_b_of_type_Int;
            int i1 = paramObject.jdField_b_of_type_Int;
            boolean bool2 = JceUtil.equals(j, i1);
            if (bool2)
              k = 1;
          }
        }
      }
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    String str1 = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 3, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    String str2 = paramJceInputStream.readString(4, true);
    this.jdField_b_of_type_JavaLangString = str2;
    int k = this.jdField_b_of_type_Int;
    int l = paramJceInputStream.read(k, 5, null);
    this.jdField_b_of_type_Int = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 3);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 4);
    int j = this.jdField_b_of_type_Int;
    paramJceOutputStream.write(j, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSigSetReq
 * JD-Core Version:    0.5.4
 */