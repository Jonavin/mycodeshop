package KQQ;

public final class WeatherInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.WeatherInfoResHolder
 * JD-Core Version:    0.5.4
 */