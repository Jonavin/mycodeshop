package KQQ;

public final class ProfGroupInfoReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfGroupInfoReqHolder
 * JD-Core Version:    0.5.4
 */