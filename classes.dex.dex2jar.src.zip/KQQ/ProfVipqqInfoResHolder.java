package KQQ;

public final class ProfVipqqInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfVipqqInfoResHolder
 * JD-Core Version:    0.5.4
 */