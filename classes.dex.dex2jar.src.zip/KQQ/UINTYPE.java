package KQQ;

public final class UINTYPE
{
  public static final UINTYPE UIN_EMAIL;
  public static final UINTYPE UIN_MOBILE;
  public static final UINTYPE UIN_QQ;
  public static final int _UIN_EMAIL = 1;
  public static final int _UIN_MOBILE = 2;
  public static final int _UIN_QQ;
  private static UINTYPE[] __values;
  private int jdField_a_of_type_Int;
  private String jdField_a_of_type_JavaLangString;

  static
  {
    int i = 2;
    int j = 1;
    int k = 0;
    if (!UINTYPE.class.desiredAssertionStatus())
      int l = j;
    while (true)
    {
      boolean bool = $assertionsDisabled;
      __values = new UINTYPE[3];
      UIN_QQ = new UINTYPE(k, k, "UIN_QQ");
      UIN_EMAIL = new UINTYPE(j, j, "UIN_EMAIL");
      UIN_MOBILE = new UINTYPE(i, i, "UIN_MOBILE");
      return;
      int i1 = k;
    }
  }

  private UINTYPE(int paramInt1, int paramInt2, String paramString)
  {
    String str = new String();
    this.jdField_a_of_type_JavaLangString = str;
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_Int = paramInt2;
    __values[paramInt1] = this;
  }

  public static UINTYPE convert(int paramInt)
  {
    UINTYPE localUINTYPE = null;
    label2: int j = __values.length;
    if (localUINTYPE < j)
      if (__values[localUINTYPE].jdField_a_of_type_Int == paramInt)
        localUINTYPE = __values[localUINTYPE];
    while (true)
    {
      return localUINTYPE;
      ++localUINTYPE;
      break label2:
      $assertionsDisabled = localUINTYPE;
      if (localUINTYPE == null)
        throw new AssertionError();
      int i = 0;
    }
  }

  public static UINTYPE convert(String paramString)
  {
    UINTYPE localUINTYPE = null;
    label2: int j = __values.length;
    if (localUINTYPE < j)
      if (__values[localUINTYPE].toString().equals(paramString))
        localUINTYPE = __values[localUINTYPE];
    while (true)
    {
      return localUINTYPE;
      ++localUINTYPE;
      break label2:
      $assertionsDisabled = localUINTYPE;
      if (localUINTYPE == null)
        throw new AssertionError();
      int i = 0;
    }
  }

  public final String toString()
  {
    return this.jdField_a_of_type_JavaLangString;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.UINTYPE
 * JD-Core Version:    0.5.4
 */