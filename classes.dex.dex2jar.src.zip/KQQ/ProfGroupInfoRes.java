package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfGroupInfoRes extends JceStruct
{
  public byte a;
  public long a;
  public String a;
  public short a;
  public long b;
  public String b;
  public long c;
  public String c;

  static
  {
    if (!ProfGroupInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfGroupInfoRes()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Short = null;
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_c_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cResult");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "uGroupUin");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "uGroupCode");
    long l3 = this.jdField_c_of_type_Long;
    localJceDisplayer.display(l3, "uGroupOwnerUin");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "sGroupName");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wGroupFace");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "sGroupMemo");
    String str3 = this.jdField_c_of_type_JavaLangString;
    localJceDisplayer.display(str3, "sFingerGroupMemo");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfGroupInfoRes)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b2);
    int i;
    if (bool1)
    {
      long l1 = this.jdField_a_of_type_Long;
      long l2 = paramObject.jdField_a_of_type_Long;
      bool1 = JceUtil.equals(l1, l2);
      if (bool1)
      {
        l1 = this.jdField_b_of_type_Long;
        long l3 = paramObject.jdField_b_of_type_Long;
        bool1 = JceUtil.equals(l1, l3);
        if (bool1)
        {
          l1 = this.jdField_c_of_type_Long;
          long l4 = paramObject.jdField_c_of_type_Long;
          bool1 = JceUtil.equals(l1, l4);
          if (bool1)
          {
            Object localObject1 = this.jdField_a_of_type_JavaLangString;
            String str1 = paramObject.jdField_a_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str1);
            if (localObject1 != 0)
            {
              short s1 = this.jdField_a_of_type_Short;
              short s2 = paramObject.jdField_a_of_type_Short;
              boolean bool2 = JceUtil.equals(s1, s2);
              if (bool2)
              {
                Object localObject2 = this.jdField_b_of_type_JavaLangString;
                String str2 = paramObject.jdField_b_of_type_JavaLangString;
                localObject2 = JceUtil.equals(localObject2, str2);
                if (localObject2 != 0)
                {
                  localObject2 = this.jdField_c_of_type_JavaLangString;
                  String str3 = paramObject.jdField_c_of_type_JavaLangString;
                  localObject2 = JceUtil.equals(localObject2, str3);
                  if (localObject2 != 0)
                    i = 1;
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 0, true);
    this.jdField_a_of_type_Byte = b2;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 1, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 2, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.jdField_c_of_type_Long;
    long l6 = paramJceInputStream.read(l5, 3, true);
    Object localObject3;
    this.jdField_c_of_type_Long = localObject3;
    String str1 = paramJceInputStream.readString(4, true);
    this.jdField_a_of_type_JavaLangString = str1;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 5, true);
    this.jdField_a_of_type_Short = s2;
    String str2 = paramJceInputStream.readString(6, true);
    this.jdField_b_of_type_JavaLangString = str2;
    String str3 = paramJceInputStream.readString(7, true);
    this.jdField_c_of_type_JavaLangString = str3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 1);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 2);
    long l3 = this.jdField_c_of_type_Long;
    paramJceOutputStream.write(l3, 3);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 4);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 5);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 6);
    String str3 = this.jdField_c_of_type_JavaLangString;
    paramJceOutputStream.write(str3, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfGroupInfoRes
 * JD-Core Version:    0.5.4
 */