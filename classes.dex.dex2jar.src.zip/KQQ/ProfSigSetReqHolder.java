package KQQ;

public final class ProfSigSetReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSigSetReqHolder
 * JD-Core Version:    0.5.4
 */