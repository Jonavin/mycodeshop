package KQQ;

public final class ProfSmpInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSmpInfoResHolder
 * JD-Core Version:    0.5.4
 */