package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class WeatherInfoWithCellidReq extends JceStruct
{
  static GSMCell cache_cell;
  static GPSPoint cache_coords;
  public GPSPoint a;
  public GSMCell a;

  static
  {
    if (!WeatherInfoWithCellidReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public WeatherInfoWithCellidReq()
  {
    this.jdField_a_of_type_KQQGSMCell = null;
    this.jdField_a_of_type_KQQGPSPoint = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    GSMCell localGSMCell = this.jdField_a_of_type_KQQGSMCell;
    localJceDisplayer.display(localGSMCell, "cell");
    GPSPoint localGPSPoint = this.jdField_a_of_type_KQQGPSPoint;
    localJceDisplayer.display(localGPSPoint, "coords");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (WeatherInfoWithCellidReq)paramObject;
    Object localObject1 = this.jdField_a_of_type_KQQGSMCell;
    GSMCell localGSMCell = paramObject.jdField_a_of_type_KQQGSMCell;
    localObject1 = JceUtil.equals(localObject1, localGSMCell);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.jdField_a_of_type_KQQGPSPoint;
      GPSPoint localGPSPoint = paramObject.jdField_a_of_type_KQQGPSPoint;
      localObject1 = JceUtil.equals(localObject1, localGPSPoint);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    if (cache_cell == null)
      cache_cell = new GSMCell();
    GSMCell localGSMCell1 = cache_cell;
    GSMCell localGSMCell2 = (GSMCell)paramJceInputStream.read(localGSMCell1, i, i);
    this.jdField_a_of_type_KQQGSMCell = localGSMCell2;
    if (cache_coords == null)
      cache_coords = new GPSPoint();
    GPSPoint localGPSPoint1 = cache_coords;
    GPSPoint localGPSPoint2 = (GPSPoint)paramJceInputStream.read(localGPSPoint1, 2, i);
    this.jdField_a_of_type_KQQGPSPoint = localGPSPoint2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    GSMCell localGSMCell = this.jdField_a_of_type_KQQGSMCell;
    paramJceOutputStream.write(localGSMCell, 1);
    GPSPoint localGPSPoint = this.jdField_a_of_type_KQQGPSPoint;
    paramJceOutputStream.write(localGPSPoint, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.WeatherInfoWithCellidReq
 * JD-Core Version:    0.5.4
 */