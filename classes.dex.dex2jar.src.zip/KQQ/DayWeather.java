package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class DayWeather extends JceStruct
{
  public int a;
  public String a;
  public int b;
  public String b;
  public int c;
  public String c;
  public String d = "";

  static
  {
    if (!DayWeather.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public DayWeather()
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_b_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_c_of_type_JavaLangString = "";
    this.jdField_c_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "highTemp");
    int j = this.jdField_b_of_type_Int;
    localJceDisplayer.display(j, "lowTemp");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "bWeather");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "eWeather");
    String str3 = this.jdField_c_of_type_JavaLangString;
    localJceDisplayer.display(str3, "bWind");
    String str4 = this.d;
    localJceDisplayer.display(str4, "eWind");
    int k = this.jdField_c_of_type_Int;
    localJceDisplayer.display(k, "WeatherId");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (DayWeather)paramObject;
    int i = this.jdField_a_of_type_Int;
    int i1 = paramObject.jdField_a_of_type_Int;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      int j = this.jdField_b_of_type_Int;
      int i2 = paramObject.jdField_b_of_type_Int;
      boolean bool2 = JceUtil.equals(j, i2);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str1 = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str1);
        if (localObject1 != 0)
        {
          localObject1 = this.jdField_b_of_type_JavaLangString;
          String str2 = paramObject.jdField_b_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str2);
          if (localObject1 != 0)
          {
            localObject1 = this.jdField_c_of_type_JavaLangString;
            String str3 = paramObject.jdField_c_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str3);
            if (localObject1 != 0)
            {
              localObject1 = this.d;
              String str4 = paramObject.d;
              localObject1 = JceUtil.equals(localObject1, str4);
              if (localObject1 != 0)
              {
                int k = this.jdField_c_of_type_Int;
                int i3 = paramObject.jdField_c_of_type_Int;
                boolean bool3 = JceUtil.equals(k, i3);
                if (bool3)
                  l = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    int k = this.jdField_b_of_type_Int;
    int l = paramJceInputStream.read(k, 2, true);
    this.jdField_b_of_type_Int = l;
    String str1 = paramJceInputStream.readString(3, true);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(4, true);
    this.jdField_b_of_type_JavaLangString = str2;
    String str3 = paramJceInputStream.readString(5, true);
    this.jdField_c_of_type_JavaLangString = str3;
    String str4 = paramJceInputStream.readString(6, true);
    this.d = str4;
    int i1 = this.jdField_c_of_type_Int;
    int i2 = paramJceInputStream.read(i1, 7, true);
    this.jdField_c_of_type_Int = i2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    int j = this.jdField_b_of_type_Int;
    paramJceOutputStream.write(j, 2);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 3);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 4);
    String str3 = this.jdField_c_of_type_JavaLangString;
    paramJceOutputStream.write(str3, 5);
    String str4 = this.d;
    paramJceOutputStream.write(str4, 6);
    int k = this.jdField_c_of_type_Int;
    paramJceOutputStream.write(k, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.DayWeather
 * JD-Core Version:    0.5.4
 */