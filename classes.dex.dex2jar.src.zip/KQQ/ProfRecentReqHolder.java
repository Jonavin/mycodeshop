package KQQ;

public final class ProfRecentReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfRecentReqHolder
 * JD-Core Version:    0.5.4
 */