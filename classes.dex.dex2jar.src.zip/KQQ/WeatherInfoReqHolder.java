package KQQ;

public final class WeatherInfoReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.WeatherInfoReqHolder
 * JD-Core Version:    0.5.4
 */