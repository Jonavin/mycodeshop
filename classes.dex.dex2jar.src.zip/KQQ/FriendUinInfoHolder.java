package KQQ;

public final class FriendUinInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.FriendUinInfoHolder
 * JD-Core Version:    0.5.4
 */