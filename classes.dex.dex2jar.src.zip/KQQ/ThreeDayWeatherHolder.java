package KQQ;

public final class ThreeDayWeatherHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ThreeDayWeatherHolder
 * JD-Core Version:    0.5.4
 */