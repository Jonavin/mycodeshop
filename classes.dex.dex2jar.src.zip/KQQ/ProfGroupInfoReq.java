package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfGroupInfoReq extends JceStruct
{
  public long a = 0L;

  static
  {
    if (!ProfGroupInfoReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.a;
    localJceDisplayer.display(l, "uGroupCode");
  }

  public final boolean equals(Object paramObject)
  {
    ProfGroupInfoReq localProfGroupInfoReq = (ProfGroupInfoReq)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    return JceUtil.equals(l1, l2);
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.a = localObject;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.a;
    paramJceOutputStream.write(l, 0);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfGroupInfoReq
 * JD-Core Version:    0.5.4
 */