package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class ProfFriendInfoRes extends JceStruct
{
  static Map cache_mFieldsInfo;
  static ArrayList cache_vUnGetFields;
  public byte a;
  public long a;
  public String a;
  public ArrayList a;
  public Map a;
  public short a;
  public byte b = null;

  static
  {
    if (!ProfFriendInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfFriendInfoRes()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaUtilMap = null;
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "uFriendUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cResult");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cDataCode");
    Map localMap = this.jdField_a_of_type_JavaUtilMap;
    localJceDisplayer.display(localMap, "mFieldsInfo");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vUnGetFields");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sSigInfo");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wLevel");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfFriendInfoRes)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        byte b2 = this.b;
        byte b4 = paramObject.b;
        boolean bool3 = JceUtil.equals(b2, b4);
        if (bool3)
        {
          Object localObject1 = this.jdField_a_of_type_JavaUtilMap;
          Map localMap = paramObject.jdField_a_of_type_JavaUtilMap;
          localObject1 = JceUtil.equals(localObject1, localMap);
          if (localObject1 != 0)
          {
            localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
            ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
            localObject1 = JceUtil.equals(localObject1, localArrayList);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_a_of_type_JavaLangString;
              String str = paramObject.jdField_a_of_type_JavaLangString;
              localObject1 = JceUtil.equals(localObject1, str);
              if (localObject1 != 0)
              {
                short s1 = this.jdField_a_of_type_Short;
                short s2 = paramObject.jdField_a_of_type_Short;
                boolean bool4 = JceUtil.equals(s1, s2);
                if (bool4)
                  i = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 2, j);
    this.b = b4;
    if (cache_mFieldsInfo == null)
    {
      cache_mFieldsInfo = new HashMap();
      Short localShort1 = Short.valueOf(i);
      byte[] arrayOfByte = (byte[])new byte[j];
      ((byte[])arrayOfByte)[i] = i;
      cache_mFieldsInfo.put(localShort1, arrayOfByte);
    }
    Map localMap1 = cache_mFieldsInfo;
    Map localMap2 = (Map)paramJceInputStream.read(localMap1, 3, j);
    this.jdField_a_of_type_JavaUtilMap = localMap2;
    if (cache_vUnGetFields == null)
    {
      cache_vUnGetFields = new ArrayList();
      Short localShort2 = Short.valueOf(i);
      cache_vUnGetFields.add(localShort2);
    }
    ArrayList localArrayList1 = cache_vUnGetFields;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 4, j);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    String str = paramJceInputStream.readString(5, j);
    this.jdField_a_of_type_JavaLangString = str;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 6, j);
    this.jdField_a_of_type_Short = s2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 2);
    Map localMap = this.jdField_a_of_type_JavaUtilMap;
    paramJceOutputStream.write(localMap, 3);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 4);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 5);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfFriendInfoRes
 * JD-Core Version:    0.5.4
 */