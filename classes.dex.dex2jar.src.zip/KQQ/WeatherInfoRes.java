package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class WeatherInfoRes extends JceStruct
{
  static ThreeDayWeather cache_weatherInfo;
  public byte a;
  public ThreeDayWeather a;
  public String a;
  public byte b = null;

  static
  {
    if (!WeatherInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public WeatherInfoRes()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_KQQThreeDayWeather = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "result");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "city");
    ThreeDayWeather localThreeDayWeather = this.jdField_a_of_type_KQQThreeDayWeather;
    localJceDisplayer.display(localThreeDayWeather, "weatherInfo");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "citytype");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (WeatherInfoRes)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b3 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b3);
    int i;
    if (bool1)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
      {
        localObject1 = this.jdField_a_of_type_KQQThreeDayWeather;
        ThreeDayWeather localThreeDayWeather = paramObject.jdField_a_of_type_KQQThreeDayWeather;
        localObject1 = JceUtil.equals(localObject1, localThreeDayWeather);
        if (localObject1 != 0)
        {
          byte b2 = this.b;
          byte b4 = paramObject.b;
          boolean bool2 = JceUtil.equals(b2, b4);
          if (bool2)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, i);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, i);
    this.jdField_a_of_type_JavaLangString = str;
    if (cache_weatherInfo == null)
      cache_weatherInfo = new ThreeDayWeather();
    ThreeDayWeather localThreeDayWeather1 = cache_weatherInfo;
    ThreeDayWeather localThreeDayWeather2 = (ThreeDayWeather)paramJceInputStream.read(localThreeDayWeather1, 3, i);
    this.jdField_a_of_type_KQQThreeDayWeather = localThreeDayWeather2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 4, null);
    this.b = b4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    ThreeDayWeather localThreeDayWeather = this.jdField_a_of_type_KQQThreeDayWeather;
    paramJceOutputStream.write(localThreeDayWeather, 3);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.WeatherInfoRes
 * JD-Core Version:    0.5.4
 */