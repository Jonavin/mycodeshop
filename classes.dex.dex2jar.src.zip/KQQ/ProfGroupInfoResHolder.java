package KQQ;

public final class ProfGroupInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfGroupInfoResHolder
 * JD-Core Version:    0.5.4
 */