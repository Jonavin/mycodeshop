package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ThreeDayWeather extends JceStruct
{
  static DayWeather cache_aftertom;
  static DayWeather cache_today;
  static DayWeather cache_tomorrow;
  public int a;
  public DayWeather a;
  public String a;
  public DayWeather b;
  public String b;
  public DayWeather c;
  public String c;
  public String d = "";

  static
  {
    if (!ThreeDayWeather.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ThreeDayWeather()
  {
    this.jdField_a_of_type_KQQDayWeather = null;
    this.jdField_b_of_type_KQQDayWeather = null;
    this.jdField_c_of_type_KQQDayWeather = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_c_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    DayWeather localDayWeather1 = this.jdField_a_of_type_KQQDayWeather;
    localJceDisplayer.display(localDayWeather1, "today");
    DayWeather localDayWeather2 = this.jdField_b_of_type_KQQDayWeather;
    localJceDisplayer.display(localDayWeather2, "tomorrow");
    DayWeather localDayWeather3 = this.jdField_c_of_type_KQQDayWeather;
    localJceDisplayer.display(localDayWeather3, "aftertom");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "currtmpe");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "year");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "day");
    String str3 = this.jdField_c_of_type_JavaLangString;
    localJceDisplayer.display(str3, "festa");
    String str4 = this.d;
    localJceDisplayer.display(str4, "currtime");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ThreeDayWeather)paramObject;
    Object localObject1 = this.jdField_a_of_type_KQQDayWeather;
    DayWeather localDayWeather1 = paramObject.jdField_a_of_type_KQQDayWeather;
    localObject1 = JceUtil.equals(localObject1, localDayWeather1);
    int j;
    if (localObject1 != 0)
    {
      localObject1 = this.jdField_b_of_type_KQQDayWeather;
      DayWeather localDayWeather2 = paramObject.jdField_b_of_type_KQQDayWeather;
      localObject1 = JceUtil.equals(localObject1, localDayWeather2);
      if (localObject1 != 0)
      {
        localObject1 = this.jdField_c_of_type_KQQDayWeather;
        DayWeather localDayWeather3 = paramObject.jdField_c_of_type_KQQDayWeather;
        localObject1 = JceUtil.equals(localObject1, localDayWeather3);
        if (localObject1 != 0)
        {
          int i = this.jdField_a_of_type_Int;
          int k = paramObject.jdField_a_of_type_Int;
          boolean bool = JceUtil.equals(i, k);
          if (bool)
          {
            Object localObject2 = this.jdField_a_of_type_JavaLangString;
            String str1 = paramObject.jdField_a_of_type_JavaLangString;
            localObject2 = JceUtil.equals(localObject2, str1);
            if (localObject2 != 0)
            {
              localObject2 = this.jdField_b_of_type_JavaLangString;
              String str2 = paramObject.jdField_b_of_type_JavaLangString;
              localObject2 = JceUtil.equals(localObject2, str2);
              if (localObject2 != 0)
              {
                localObject2 = this.jdField_c_of_type_JavaLangString;
                String str3 = paramObject.jdField_c_of_type_JavaLangString;
                localObject2 = JceUtil.equals(localObject2, str3);
                if (localObject2 != 0)
                {
                  localObject2 = this.d;
                  String str4 = paramObject.d;
                  localObject2 = JceUtil.equals(localObject2, str4);
                  if (localObject2 != 0)
                    j = 1;
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    boolean bool = null;
    if (cache_today == null)
      cache_today = new DayWeather();
    DayWeather localDayWeather1 = cache_today;
    DayWeather localDayWeather2 = (DayWeather)paramJceInputStream.read(localDayWeather1, i, i);
    this.jdField_a_of_type_KQQDayWeather = localDayWeather2;
    if (cache_tomorrow == null)
      cache_tomorrow = new DayWeather();
    DayWeather localDayWeather3 = cache_tomorrow;
    DayWeather localDayWeather4 = (DayWeather)paramJceInputStream.read(localDayWeather3, 2, i);
    this.jdField_b_of_type_KQQDayWeather = localDayWeather4;
    if (cache_aftertom == null)
      cache_aftertom = new DayWeather();
    DayWeather localDayWeather5 = cache_aftertom;
    DayWeather localDayWeather6 = (DayWeather)paramJceInputStream.read(localDayWeather5, 3, i);
    this.jdField_c_of_type_KQQDayWeather = localDayWeather6;
    int j = this.jdField_a_of_type_Int;
    int k = paramJceInputStream.read(j, 4, bool);
    this.jdField_a_of_type_Int = k;
    String str1 = paramJceInputStream.readString(5, bool);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(6, bool);
    this.jdField_b_of_type_JavaLangString = str2;
    String str3 = paramJceInputStream.readString(7, bool);
    this.jdField_c_of_type_JavaLangString = str3;
    String str4 = paramJceInputStream.readString(8, bool);
    this.d = str4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    DayWeather localDayWeather1 = this.jdField_a_of_type_KQQDayWeather;
    paramJceOutputStream.write(localDayWeather1, 1);
    DayWeather localDayWeather2 = this.jdField_b_of_type_KQQDayWeather;
    paramJceOutputStream.write(localDayWeather2, 2);
    DayWeather localDayWeather3 = this.jdField_c_of_type_KQQDayWeather;
    paramJceOutputStream.write(localDayWeather3, 3);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 4);
    if (this.jdField_a_of_type_JavaLangString != null)
    {
      String str1 = this.jdField_a_of_type_JavaLangString;
      paramJceOutputStream.write(str1, 5);
    }
    if (this.jdField_b_of_type_JavaLangString != null)
    {
      String str2 = this.jdField_b_of_type_JavaLangString;
      paramJceOutputStream.write(str2, 6);
    }
    if (this.jdField_c_of_type_JavaLangString != null)
    {
      String str3 = this.jdField_c_of_type_JavaLangString;
      paramJceOutputStream.write(str3, 7);
    }
    if (this.d == null)
      return;
    String str4 = this.d;
    paramJceOutputStream.write(str4, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ThreeDayWeather
 * JD-Core Version:    0.5.4
 */