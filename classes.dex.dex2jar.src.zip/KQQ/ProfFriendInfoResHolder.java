package KQQ;

public final class ProfFriendInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfFriendInfoResHolder
 * JD-Core Version:    0.5.4
 */