package KQQ;

public final class ProfUsrQryReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfUsrQryReqHolder
 * JD-Core Version:    0.5.4
 */