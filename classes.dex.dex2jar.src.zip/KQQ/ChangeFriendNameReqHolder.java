package KQQ;

public final class ChangeFriendNameReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ChangeFriendNameReqHolder
 * JD-Core Version:    0.5.4
 */