package KQQ;

public final class ProfFullUsrQryReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfFullUsrQryReqHolder
 * JD-Core Version:    0.5.4
 */