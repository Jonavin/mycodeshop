package KQQ;

public final class CityInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.CityInfoResHolder
 * JD-Core Version:    0.5.4
 */