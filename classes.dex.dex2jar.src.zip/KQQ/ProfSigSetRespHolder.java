package KQQ;

public final class ProfSigSetRespHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfSigSetRespHolder
 * JD-Core Version:    0.5.4
 */