package KQQ.cnst;

public abstract interface VALUE_NORELOAD
{
  public static final int value;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.cnst.VALUE_NORELOAD
 * JD-Core Version:    0.5.4
 */