package KQQ.cnst;

public abstract interface VALUE_NOSEND
{
  public static final int value;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.cnst.VALUE_NOSEND
 * JD-Core Version:    0.5.4
 */