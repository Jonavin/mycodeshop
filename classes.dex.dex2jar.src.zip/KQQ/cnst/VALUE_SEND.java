package KQQ.cnst;

public abstract interface VALUE_SEND
{
  public static final int value = 1;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.cnst.VALUE_SEND
 * JD-Core Version:    0.5.4
 */