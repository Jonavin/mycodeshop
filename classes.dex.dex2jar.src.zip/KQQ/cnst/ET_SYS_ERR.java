package KQQ.cnst;

public abstract interface ET_SYS_ERR
{
  public static final int value = 255;
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.cnst.ET_SYS_ERR
 * JD-Core Version:    0.5.4
 */