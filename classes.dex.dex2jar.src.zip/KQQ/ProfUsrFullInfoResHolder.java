package KQQ;

public final class ProfUsrFullInfoResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfUsrFullInfoResHolder
 * JD-Core Version:    0.5.4
 */