package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.HashMap;
import java.util.Map;

public final class ProfUsrFullInfoRes extends JceStruct
{
  static Map cache_sRemarkInfo;
  static ProfSmpInfoRes cache_strPfileSmpInfoRes;
  public ProfSmpInfoRes a;
  public String a;
  public Map a;

  static
  {
    if (!ProfUsrFullInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfUsrFullInfoRes()
  {
    this.jdField_a_of_type_KQQProfSmpInfoRes = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_JavaUtilMap = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    ProfSmpInfoRes localProfSmpInfoRes = this.jdField_a_of_type_KQQProfSmpInfoRes;
    localJceDisplayer.display(localProfSmpInfoRes, "strPfileSmpInfoRes");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sSigInfo");
    Map localMap = this.jdField_a_of_type_JavaUtilMap;
    localJceDisplayer.display(localMap, "sRemarkInfo");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfUsrFullInfoRes)paramObject;
    Object localObject1 = this.jdField_a_of_type_KQQProfSmpInfoRes;
    ProfSmpInfoRes localProfSmpInfoRes = paramObject.jdField_a_of_type_KQQProfSmpInfoRes;
    localObject1 = JceUtil.equals(localObject1, localProfSmpInfoRes);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.jdField_a_of_type_JavaLangString;
      String str = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
      {
        localObject1 = this.jdField_a_of_type_JavaUtilMap;
        Map localMap = paramObject.jdField_a_of_type_JavaUtilMap;
        localObject1 = JceUtil.equals(localObject1, localMap);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    if (cache_strPfileSmpInfoRes == null)
      cache_strPfileSmpInfoRes = new ProfSmpInfoRes();
    ProfSmpInfoRes localProfSmpInfoRes1 = cache_strPfileSmpInfoRes;
    ProfSmpInfoRes localProfSmpInfoRes2 = (ProfSmpInfoRes)paramJceInputStream.read(localProfSmpInfoRes1, i, i);
    this.jdField_a_of_type_KQQProfSmpInfoRes = localProfSmpInfoRes2;
    String str = paramJceInputStream.readString(2, i);
    this.jdField_a_of_type_JavaLangString = str;
    if (cache_sRemarkInfo == null)
    {
      cache_sRemarkInfo = new HashMap();
      Long localLong = Long.valueOf(0L);
      cache_sRemarkInfo.put(localLong, "");
    }
    Map localMap1 = cache_sRemarkInfo;
    Map localMap2 = (Map)paramJceInputStream.read(localMap1, 3, i);
    this.jdField_a_of_type_JavaUtilMap = localMap2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    ProfSmpInfoRes localProfSmpInfoRes = this.jdField_a_of_type_KQQProfSmpInfoRes;
    paramJceOutputStream.write(localProfSmpInfoRes, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    Map localMap = this.jdField_a_of_type_JavaUtilMap;
    paramJceOutputStream.write(localMap, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfUsrFullInfoRes
 * JD-Core Version:    0.5.4
 */