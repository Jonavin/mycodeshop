package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ProfVipqqInfoRes extends JceStruct
{
  public short a = null;

  static
  {
    if (!ProfVipqqInfoRes.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    short s = this.a;
    localJceDisplayer.display(s, "wLevel");
  }

  public final boolean equals(Object paramObject)
  {
    ProfVipqqInfoRes localProfVipqqInfoRes = (ProfVipqqInfoRes)paramObject;
    short s1 = this.a;
    short s2 = paramObject.a;
    return JceUtil.equals(s1, s2);
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    short s1 = this.a;
    short s2 = paramJceInputStream.read(s1, 1, true);
    this.a = s2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    short s = this.a;
    paramJceOutputStream.write(s, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfVipqqInfoRes
 * JD-Core Version:    0.5.4
 */