package KQQ;

public final class GPSPointHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.GPSPointHolder
 * JD-Core Version:    0.5.4
 */