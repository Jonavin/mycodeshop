package KQQ;

public final class ProfFriendInfoReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfFriendInfoReqHolder
 * JD-Core Version:    0.5.4
 */