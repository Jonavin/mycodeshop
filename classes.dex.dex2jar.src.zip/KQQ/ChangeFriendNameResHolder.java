package KQQ;

public final class ChangeFriendNameResHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ChangeFriendNameResHolder
 * JD-Core Version:    0.5.4
 */