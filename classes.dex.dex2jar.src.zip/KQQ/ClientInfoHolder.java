package KQQ;

public final class ClientInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ClientInfoHolder
 * JD-Core Version:    0.5.4
 */