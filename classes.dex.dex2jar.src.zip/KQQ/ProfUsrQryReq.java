package KQQ;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class ProfUsrQryReq extends JceStruct
{
  static ArrayList cache_vUin;
  public int a;
  public String a;
  public ArrayList a;
  public int b = null;
  public int c = null;

  static
  {
    if (!ProfUsrQryReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ProfUsrQryReq()
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_JavaUtilArrayList = null;
  }

  public ProfUsrQryReq(String paramString, ArrayList paramArrayList)
  {
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_JavaUtilArrayList = paramArrayList;
    this.b = 1;
    this.c = 1;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "iAppId");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strSessionKey");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vUin");
    int j = this.b;
    localJceDisplayer.display(j, "iRetIncomPlete");
    int k = this.c;
    localJceDisplayer.display(k, "iReloadFlag");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ProfUsrQryReq)paramObject;
    int i = this.jdField_a_of_type_Int;
    int i1 = paramObject.jdField_a_of_type_Int;
    boolean bool1 = JceUtil.equals(i, i1);
    int l;
    if (bool1)
    {
      Object localObject1 = this.jdField_a_of_type_JavaLangString;
      String str = paramObject.jdField_a_of_type_JavaLangString;
      localObject1 = JceUtil.equals(localObject1, str);
      if (localObject1 != 0)
      {
        localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
        ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
        localObject1 = JceUtil.equals(localObject1, localArrayList);
        if (localObject1 != 0)
        {
          int j = this.b;
          int i2 = paramObject.b;
          boolean bool2 = JceUtil.equals(j, i2);
          if (bool2)
          {
            int k = this.c;
            int i3 = paramObject.c;
            boolean bool3 = JceUtil.equals(k, i3);
            if (bool3)
              l = 1;
          }
        }
      }
    }
    while (true)
    {
      return l;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    boolean bool = null;
    int i = 1;
    int j = this.jdField_a_of_type_Int;
    int k = paramJceInputStream.read(j, i, i);
    this.jdField_a_of_type_Int = k;
    String str = paramJceInputStream.readString(2, i);
    this.jdField_a_of_type_JavaLangString = str;
    if (cache_vUin == null)
    {
      cache_vUin = new ArrayList();
      Long localLong = Long.valueOf(0L);
      cache_vUin.add(localLong);
    }
    ArrayList localArrayList1 = cache_vUin;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 3, i);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    int l = this.b;
    int i1 = paramJceInputStream.read(l, 4, bool);
    this.b = i1;
    int i2 = this.c;
    int i3 = paramJceInputStream.read(i2, 5, bool);
    this.c = i3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 3);
    int j = this.b;
    paramJceOutputStream.write(j, 4);
    int k = this.c;
    paramJceOutputStream.write(k, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     KQQ.ProfUsrQryReq
 * JD-Core Version:    0.5.4
 */