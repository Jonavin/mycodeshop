import android.os.Handler;
import com.tencent.mobileqq.activity.ContactActivity;

final class ck
  implements Runnable
{
  ck(ch paramch)
  {
  }

  public final void run()
  {
    ContactActivity.access$300(this.a.a).sendEmptyMessage(1004);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ck
 * JD-Core Version:    0.5.4
 */