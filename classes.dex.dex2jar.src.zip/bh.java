import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bh
  implements AdapterView.OnItemClickListener
{
  public bh(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramInt >= 100)
      return;
    ChatWindowActivity.access$3000(this.a, paramInt);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bh
 * JD-Core Version:    0.5.4
 */