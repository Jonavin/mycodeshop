import android.app.Dialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bf
  implements AdapterView.OnItemClickListener
{
  public bf(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramInt >= 107)
      return;
    ChatWindowActivity.access$2800(this.a).dismiss();
    ChatWindowActivity.access$2900(this.a, paramInt);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bf
 * JD-Core Version:    0.5.4
 */