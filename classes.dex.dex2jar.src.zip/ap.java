import android.widget.Chronometer;
import android.widget.Chronometer.OnChronometerTickListener;

final class ap
  implements Chronometer.OnChronometerTickListener
{
  ap(al paramal)
  {
  }

  public final void onChronometerTick(Chronometer paramChronometer)
  {
    CharSequence localCharSequence = paramChronometer.getText();
    if (localCharSequence.length() == 5)
    {
      String str1 = "00:" + localCharSequence;
      paramChronometer.setText(localCharSequence);
    }
    while (true)
    {
      return;
      if (localCharSequence.length() != 7)
        continue;
      String str2 = "0" + localCharSequence;
      paramChronometer.setText(localCharSequence);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ap
 * JD-Core Version:    0.5.4
 */