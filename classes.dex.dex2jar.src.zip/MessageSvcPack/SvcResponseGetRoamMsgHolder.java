package MessageSvcPack;

public final class SvcResponseGetRoamMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetRoamMsgHolder
 * JD-Core Version:    0.5.4
 */