package MessageSvcPack;

public final class SvcRequestDelMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestDelMsgHolder
 * JD-Core Version:    0.5.4
 */