package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestSvrMsg extends JceStruct
{
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public long b;
  public short b;
  public long c = 0L;
  public long d = 0L;

  static
  {
    if (!SvcRequestSvrMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestSvrMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_Byte = null;
    this.jdField_b_of_type_Short = null;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uDateTime");
    short s1 = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s1, "wMsgType");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSubMsgType");
    short s2 = this.jdField_b_of_type_Short;
    localJceDisplayer.display(s2, "wSubCmd");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lFromUin");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lToUin");
    long l4 = this.d;
    localJceDisplayer.display(l4, "uMsgId");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strMsg");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestSvrMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        short s1 = this.jdField_a_of_type_Short;
        short s3 = paramObject.jdField_a_of_type_Short;
        boolean bool3 = JceUtil.equals(s1, s3);
        if (bool3)
        {
          byte b1 = this.jdField_a_of_type_Byte;
          byte b2 = paramObject.jdField_a_of_type_Byte;
          boolean bool4 = JceUtil.equals(b1, b2);
          if (bool4)
          {
            short s2 = this.jdField_b_of_type_Short;
            short s4 = paramObject.jdField_b_of_type_Short;
            boolean bool5 = JceUtil.equals(s2, s4);
            if (bool5)
            {
              l1 = this.jdField_b_of_type_Long;
              long l3 = paramObject.jdField_b_of_type_Long;
              bool5 = JceUtil.equals(l1, l3);
              if (bool5)
              {
                l1 = this.c;
                long l4 = paramObject.c;
                bool5 = JceUtil.equals(l1, l4);
                if (bool5)
                {
                  l1 = this.d;
                  long l5 = paramObject.d;
                  bool5 = JceUtil.equals(l1, l5);
                  if (bool5)
                  {
                    Object localObject1 = this.jdField_a_of_type_JavaLangString;
                    String str = paramObject.jdField_a_of_type_JavaLangString;
                    localObject1 = JceUtil.equals(localObject1, str);
                    if (localObject1 != 0)
                      j = 1;
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, true);
    this.jdField_a_of_type_Short = s2;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, true);
    this.jdField_a_of_type_Byte = b2;
    short s3 = this.jdField_b_of_type_Short;
    short s4 = paramJceInputStream.read(s3, 4, true);
    this.jdField_b_of_type_Short = s4;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 5, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 6, true);
    Object localObject3;
    this.c = localObject3;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 7, true);
    Object localObject4;
    this.d = localObject4;
    String str = paramJceInputStream.readString(8, true);
    this.jdField_a_of_type_JavaLangString = str;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    short s1 = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s1, 2);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    short s2 = this.jdField_b_of_type_Short;
    paramJceOutputStream.write(s2, 4);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 5);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 6);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 7);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSvrMsg
 * JD-Core Version:    0.5.4
 */