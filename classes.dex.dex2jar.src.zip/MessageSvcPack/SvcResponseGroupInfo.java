package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcResponseGroupInfo extends JceStruct
{
  public byte a;
  public long a;
  public short a;
  public byte b;
  public long b;
  public long c = 0L;
  public long d = 0L;

  static
  {
    if (!SvcResponseGroupInfo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGroupInfo()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_b_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lGroupCode");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lLastSeqId");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cOnline");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shMsgNum");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lGroupSeq");
    long l4 = this.d;
    localJceDisplayer.display(l4, "lMemberSeq");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGroupInfo)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b3 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b3);
    int i;
    if (bool1)
    {
      long l1 = this.jdField_a_of_type_Long;
      long l2 = paramObject.jdField_a_of_type_Long;
      bool1 = JceUtil.equals(l1, l2);
      if (bool1)
      {
        l1 = this.jdField_b_of_type_Long;
        long l3 = paramObject.jdField_b_of_type_Long;
        bool1 = JceUtil.equals(l1, l3);
        if (bool1)
        {
          byte b2 = this.jdField_b_of_type_Byte;
          byte b4 = paramObject.jdField_b_of_type_Byte;
          boolean bool2 = JceUtil.equals(b2, b4);
          if (bool2)
          {
            short s1 = this.jdField_a_of_type_Short;
            short s2 = paramObject.jdField_a_of_type_Short;
            boolean bool3 = JceUtil.equals(s1, s2);
            if (bool3)
            {
              l1 = this.c;
              long l4 = paramObject.c;
              bool3 = JceUtil.equals(l1, l4);
              if (bool3)
              {
                l1 = this.d;
                long l5 = paramObject.d;
                bool3 = JceUtil.equals(l1, l5);
                if (bool3)
                  i = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 0, true);
    this.jdField_a_of_type_Byte = b2;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 1, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 2, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 3, true);
    this.jdField_b_of_type_Byte = b4;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 4, true);
    this.jdField_a_of_type_Short = s2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 5, true);
    Object localObject3;
    this.c = localObject3;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 6, true);
    Object localObject4;
    this.d = localObject4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 1);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 2);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 3);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 4);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 5);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGroupInfo
 * JD-Core Version:    0.5.4
 */