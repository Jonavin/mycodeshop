package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestGetAllOfflineMsgNum extends JceStruct
{
  public byte a;
  public int a;
  public long a;
  public String a;

  static
  {
    if (!SvcRequestGetAllOfflineMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestGetAllOfflineMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b, "cVerifyType");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sA2");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestGetAllOfflineMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          int i = this.jdField_a_of_type_Int;
          int k = paramObject.jdField_a_of_type_Int;
          boolean bool3 = JceUtil.equals(i, k);
          if (bool3)
            j = 1;
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 3, null);
    this.jdField_a_of_type_Int = j;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetAllOfflineMsgNum
 * JD-Core Version:    0.5.4
 */