package MessageSvcPack;

public final class SvcResponseGetOffMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetOffMsgNumHolder
 * JD-Core Version:    0.5.4
 */