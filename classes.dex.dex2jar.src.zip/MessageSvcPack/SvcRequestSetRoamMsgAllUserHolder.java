package MessageSvcPack;

public final class SvcRequestSetRoamMsgAllUserHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSetRoamMsgAllUserHolder
 * JD-Core Version:    0.5.4
 */