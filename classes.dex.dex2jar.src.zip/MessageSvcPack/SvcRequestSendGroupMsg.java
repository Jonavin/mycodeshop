package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestSendGroupMsg extends JceStruct
{
  static byte[] cache_vMsg;
  public byte a;
  public int a;
  public long a;
  public String a;
  public byte[] a;
  public byte b;
  public long b;
  public byte c;
  public long c;
  public byte d;
  public long d;

  static
  {
    if (!SvcRequestSendGroupMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestSendGroupMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_Byte = null;
    this.jdField_c_of_type_Byte = null;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_d_of_type_Long = 0L;
    this.jdField_d_of_type_Byte = null;
    this.jdField_a_of_type_Int = null;
  }

  public final void a(byte[] paramArrayOfByte)
  {
    this.jdField_a_of_type_ArrayOfByte = paramArrayOfByte;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lGroupCode");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strMsg");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cMsgStoreType");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vMsg");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cSendType");
    byte b3 = this.jdField_c_of_type_Byte;
    localJceDisplayer.display(b3, "cVerifyType");
    long l3 = this.jdField_c_of_type_Long;
    localJceDisplayer.display(l3, "lGroupUin");
    long l4 = this.jdField_d_of_type_Long;
    localJceDisplayer.display(l4, "uMsgTime");
    byte b4 = this.jdField_d_of_type_Byte;
    localJceDisplayer.display(b4, "cMsgType");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "shDuration");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestSendGroupMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      l1 = this.jdField_b_of_type_Long;
      long l3 = paramObject.jdField_b_of_type_Long;
      bool1 = JceUtil.equals(l1, l3);
      if (bool1)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          byte b1 = this.jdField_a_of_type_Byte;
          byte b5 = paramObject.jdField_a_of_type_Byte;
          boolean bool2 = JceUtil.equals(b1, b5);
          if (bool2)
          {
            Object localObject2 = this.jdField_a_of_type_ArrayOfByte;
            byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
            localObject2 = JceUtil.equals(localObject2, arrayOfByte);
            if (localObject2 != 0)
            {
              byte b2 = this.jdField_b_of_type_Byte;
              byte b6 = paramObject.jdField_b_of_type_Byte;
              boolean bool3 = JceUtil.equals(b2, b6);
              if (bool3)
              {
                byte b3 = this.jdField_c_of_type_Byte;
                byte b7 = paramObject.jdField_c_of_type_Byte;
                boolean bool4 = JceUtil.equals(b3, b7);
                if (bool4)
                {
                  l1 = this.jdField_c_of_type_Long;
                  long l4 = paramObject.jdField_c_of_type_Long;
                  bool4 = JceUtil.equals(l1, l4);
                  if (bool4)
                  {
                    l1 = this.jdField_d_of_type_Long;
                    long l5 = paramObject.jdField_d_of_type_Long;
                    bool4 = JceUtil.equals(l1, l5);
                    if (bool4)
                    {
                      byte b4 = this.jdField_d_of_type_Byte;
                      byte b8 = paramObject.jdField_d_of_type_Byte;
                      boolean bool5 = JceUtil.equals(b4, b8);
                      if (bool5)
                      {
                        int i = this.jdField_a_of_type_Int;
                        int k = paramObject.jdField_a_of_type_Int;
                        boolean bool6 = JceUtil.equals(i, k);
                        if (bool6)
                          j = 1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    int j = null;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, j, i);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, i, i);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    String str = paramJceInputStream.readString(2, i);
    this.jdField_a_of_type_JavaLangString = str;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, j);
    this.jdField_a_of_type_Byte = b2;
    if (cache_vMsg == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[i];
      cache_vMsg = arrayOfByte1;
      ((byte[])arrayOfByte1)[j] = j;
    }
    byte[] arrayOfByte2 = cache_vMsg;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 4, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 5, j);
    this.jdField_b_of_type_Byte = b4;
    byte b5 = this.jdField_c_of_type_Byte;
    byte b6 = paramJceInputStream.read(b5, 6, j);
    this.jdField_c_of_type_Byte = b6;
    long l5 = this.jdField_c_of_type_Long;
    long l6 = paramJceInputStream.read(l5, 7, j);
    Object localObject3;
    this.jdField_c_of_type_Long = localObject3;
    long l7 = this.jdField_d_of_type_Long;
    long l8 = paramJceInputStream.read(l7, 8, j);
    Object localObject4;
    this.jdField_d_of_type_Long = localObject4;
    byte b7 = this.jdField_d_of_type_Byte;
    byte b8 = paramJceInputStream.read(b7, 9, j);
    this.jdField_d_of_type_Byte = b8;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 10, j);
    this.jdField_a_of_type_Int = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    if (this.jdField_a_of_type_ArrayOfByte != null)
    {
      byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
      paramJceOutputStream.write(arrayOfByte, 4);
    }
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 5);
    byte b3 = this.jdField_c_of_type_Byte;
    paramJceOutputStream.write(b3, 6);
    long l3 = this.jdField_c_of_type_Long;
    paramJceOutputStream.write(l3, 7);
    long l4 = this.jdField_d_of_type_Long;
    paramJceOutputStream.write(l4, 8);
    byte b4 = this.jdField_d_of_type_Byte;
    paramJceOutputStream.write(b4, 9);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 10);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendGroupMsg
 * JD-Core Version:    0.5.4
 */