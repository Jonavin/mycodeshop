package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestGetGroupMsg extends JceStruct
{
  public byte a;
  public long a;
  public byte b;
  public long b;
  public byte c;
  public long c;
  public byte d;
  public long d;

  static
  {
    if (!SvcRequestGetGroupMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestGetGroupMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_d_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_b_of_type_Byte = null;
    this.jdField_c_of_type_Byte = null;
    this.jdField_d_of_type_Byte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lGroupCode");
    long l3 = this.jdField_c_of_type_Long;
    localJceDisplayer.display(l3, "lBeginSeq");
    long l4 = this.jdField_d_of_type_Long;
    localJceDisplayer.display(l4, "lEndSeq");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "c30Min");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cRecivePic");
    byte b3 = this.jdField_c_of_type_Byte;
    localJceDisplayer.display(b3, "cMsgStoreType");
    byte b4 = this.jdField_d_of_type_Byte;
    localJceDisplayer.display(b4, "cVerifyType");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestGetGroupMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      l1 = this.jdField_b_of_type_Long;
      long l3 = paramObject.jdField_b_of_type_Long;
      bool1 = JceUtil.equals(l1, l3);
      if (bool1)
      {
        l1 = this.jdField_c_of_type_Long;
        long l4 = paramObject.jdField_c_of_type_Long;
        bool1 = JceUtil.equals(l1, l4);
        if (bool1)
        {
          l1 = this.jdField_d_of_type_Long;
          long l5 = paramObject.jdField_d_of_type_Long;
          bool1 = JceUtil.equals(l1, l5);
          if (bool1)
          {
            byte b1 = this.jdField_a_of_type_Byte;
            byte b5 = paramObject.jdField_a_of_type_Byte;
            boolean bool2 = JceUtil.equals(b1, b5);
            if (bool2)
            {
              byte b2 = this.jdField_b_of_type_Byte;
              byte b6 = paramObject.jdField_b_of_type_Byte;
              boolean bool3 = JceUtil.equals(b2, b6);
              if (bool3)
              {
                byte b3 = this.jdField_c_of_type_Byte;
                byte b7 = paramObject.jdField_c_of_type_Byte;
                boolean bool4 = JceUtil.equals(b3, b7);
                if (bool4)
                {
                  byte b4 = this.jdField_d_of_type_Byte;
                  byte b8 = paramObject.jdField_d_of_type_Byte;
                  boolean bool5 = JceUtil.equals(b4, b8);
                  if (bool5)
                    i = 1;
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 1, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.jdField_c_of_type_Long;
    long l6 = paramJceInputStream.read(l5, 2, true);
    Object localObject3;
    this.jdField_c_of_type_Long = localObject3;
    long l7 = this.jdField_d_of_type_Long;
    long l8 = paramJceInputStream.read(l7, 3, true);
    Object localObject4;
    this.jdField_d_of_type_Long = localObject4;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 4, true);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 5, true);
    this.jdField_b_of_type_Byte = b4;
    byte b5 = this.jdField_c_of_type_Byte;
    byte b6 = paramJceInputStream.read(b5, 6, null);
    this.jdField_c_of_type_Byte = b6;
    byte b7 = this.jdField_d_of_type_Byte;
    byte b8 = paramJceInputStream.read(b7, 7, null);
    this.jdField_d_of_type_Byte = b8;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 1);
    long l3 = this.jdField_c_of_type_Long;
    paramJceOutputStream.write(l3, 2);
    long l4 = this.jdField_d_of_type_Long;
    paramJceOutputStream.write(l4, 3);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 4);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 5);
    byte b3 = this.jdField_c_of_type_Byte;
    paramJceOutputStream.write(b3, 6);
    byte b4 = this.jdField_d_of_type_Byte;
    paramJceOutputStream.write(b4, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetGroupMsg
 * JD-Core Version:    0.5.4
 */