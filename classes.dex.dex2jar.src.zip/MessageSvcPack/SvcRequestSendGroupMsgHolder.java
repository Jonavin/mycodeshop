package MessageSvcPack;

public final class SvcRequestSendGroupMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendGroupMsgHolder
 * JD-Core Version:    0.5.4
 */