package MessageSvcPack;

public final class SvcRequestSendVoiceReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendVoiceReqHolder
 * JD-Core Version:    0.5.4
 */