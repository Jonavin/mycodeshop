package MessageSvcPack;

public final class SvcResponseOnlineHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseOnlineHolder
 * JD-Core Version:    0.5.4
 */