package MessageSvcPack;

public final class SvcRequestOnlineHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestOnlineHolder
 * JD-Core Version:    0.5.4
 */