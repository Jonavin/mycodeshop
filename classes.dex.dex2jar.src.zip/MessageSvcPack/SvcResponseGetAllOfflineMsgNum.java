package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SvcResponseGetAllOfflineMsgNum extends JceStruct
{
  static ArrayList cache_vOfflineMsgNum;
  public byte a;
  public int a;
  public long a;
  public String a;
  public ArrayList a;
  public short a;
  public short b = null;

  static
  {
    if (!SvcResponseGetAllOfflineMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGetAllOfflineMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    short s1 = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s1, "shSumMsgNum");
    short s2 = this.b;
    localJceDisplayer.display(s2, "shFromUinNum");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vOfflineMsgNum");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGetAllOfflineMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        short s1 = this.jdField_a_of_type_Short;
        short s3 = paramObject.jdField_a_of_type_Short;
        boolean bool3 = JceUtil.equals(s1, s3);
        if (bool3)
        {
          short s2 = this.b;
          short s4 = paramObject.b;
          boolean bool4 = JceUtil.equals(s2, s4);
          if (bool4)
          {
            Object localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
            ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
            localObject1 = JceUtil.equals(localObject1, localArrayList);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_a_of_type_JavaLangString;
              String str = paramObject.jdField_a_of_type_JavaLangString;
              localObject1 = JceUtil.equals(localObject1, str);
              if (localObject1 != 0)
              {
                int i = this.jdField_a_of_type_Int;
                int k = paramObject.jdField_a_of_type_Int;
                boolean bool5 = JceUtil.equals(i, k);
                if (bool5)
                  j = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, j);
    this.jdField_a_of_type_Short = s2;
    short s3 = this.b;
    short s4 = paramJceInputStream.read(s3, 3, j);
    this.b = s4;
    if (cache_vOfflineMsgNum == null)
    {
      cache_vOfflineMsgNum = new ArrayList();
      stOfflineMsgNum localstOfflineMsgNum = new stOfflineMsgNum();
      cache_vOfflineMsgNum.add(localstOfflineMsgNum);
    }
    ArrayList localArrayList1 = cache_vOfflineMsgNum;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 4, j);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    String str = paramJceInputStream.readString(5, j);
    this.jdField_a_of_type_JavaLangString = str;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 6, i);
    this.jdField_a_of_type_Int = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    short s1 = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s1, 2);
    short s2 = this.b;
    paramJceOutputStream.write(s2, 3);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 4);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 5);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetAllOfflineMsgNum
 * JD-Core Version:    0.5.4
 */