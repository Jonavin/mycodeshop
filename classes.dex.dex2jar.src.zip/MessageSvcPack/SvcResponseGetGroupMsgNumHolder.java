package MessageSvcPack;

public final class SvcResponseGetGroupMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetGroupMsgNumHolder
 * JD-Core Version:    0.5.4
 */