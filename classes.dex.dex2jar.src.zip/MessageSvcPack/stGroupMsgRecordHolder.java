package MessageSvcPack;

public final class stGroupMsgRecordHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.stGroupMsgRecordHolder
 * JD-Core Version:    0.5.4
 */