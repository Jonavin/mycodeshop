package MessageSvcPack;

public final class GroupInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.GroupInfoHolder
 * JD-Core Version:    0.5.4
 */