package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class stOfflineMsgNum extends JceStruct
{
  public long a;
  public short a;

  static
  {
    if (!stOfflineMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public stOfflineMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shMsgNum");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (stOfflineMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      short s1 = this.jdField_a_of_type_Short;
      short s2 = paramObject.jdField_a_of_type_Short;
      boolean bool2 = JceUtil.equals(s1, s2);
      if (bool2)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 1, true);
    this.jdField_a_of_type_Short = s2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.stOfflineMsgNum
 * JD-Core Version:    0.5.4
 */