package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestSetRoamMsgAllUser extends JceStruct
{
  public byte a;
  public long a;
  public short a;
  public byte b = null;

  static
  {
    if (!SvcRequestSetRoamMsgAllUser.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestSetRoamMsgAllUser()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cVerifyType");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shType");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cValue");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestSetRoamMsgAllUser)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        short s1 = this.jdField_a_of_type_Short;
        short s2 = paramObject.jdField_a_of_type_Short;
        boolean bool3 = JceUtil.equals(s1, s2);
        if (bool3)
        {
          byte b2 = this.b;
          byte b4 = paramObject.b;
          boolean bool4 = JceUtil.equals(b2, b4);
          if (bool4)
            i = 1;
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, true);
    this.jdField_a_of_type_Short = s2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 3, true);
    this.b = b4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 2);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSetRoamMsgAllUser
 * JD-Core Version:    0.5.4
 */