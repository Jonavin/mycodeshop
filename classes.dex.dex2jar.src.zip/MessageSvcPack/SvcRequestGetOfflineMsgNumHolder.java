package MessageSvcPack;

public final class SvcRequestGetOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */