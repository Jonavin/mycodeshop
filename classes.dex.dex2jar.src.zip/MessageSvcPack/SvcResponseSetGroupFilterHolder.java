package MessageSvcPack;

public final class SvcResponseSetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */