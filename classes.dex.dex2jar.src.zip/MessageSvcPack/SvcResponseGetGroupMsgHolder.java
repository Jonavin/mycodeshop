package MessageSvcPack;

public final class SvcResponseGetGroupMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetGroupMsgHolder
 * JD-Core Version:    0.5.4
 */