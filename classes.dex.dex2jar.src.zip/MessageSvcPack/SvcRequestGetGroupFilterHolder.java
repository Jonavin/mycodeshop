package MessageSvcPack;

public final class SvcRequestGetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */