package MessageSvcPack;

public final class SvcResponseDelMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseDelMsgHolder
 * JD-Core Version:    0.5.4
 */