package MessageSvcPack;

public final class SvcRequestSendPTTMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendPTTMsgHolder
 * JD-Core Version:    0.5.4
 */