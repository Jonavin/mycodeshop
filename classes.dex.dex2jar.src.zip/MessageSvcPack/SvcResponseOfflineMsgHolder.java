package MessageSvcPack;

public final class SvcResponseOfflineMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseOfflineMsgHolder
 * JD-Core Version:    0.5.4
 */