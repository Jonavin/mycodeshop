package MessageSvcPack;

public final class SvcResponseGetOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */