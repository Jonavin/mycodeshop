package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class MsgRecord extends JceStruct
{
  static byte[] cache_vMsg;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte[] a;
  public int b;
  public long b;
  public short b;

  static
  {
    if (!MsgRecord.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public MsgRecord()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_b_of_type_Short = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_Int = null;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_a_of_type_ArrayOfByte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lFromUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
    short s1 = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s1, "wMsgType");
    short s2 = this.jdField_b_of_type_Short;
    localJceDisplayer.display(s2, "wMsgSeq");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sMsg");
    int j = this.jdField_b_of_type_Int;
    localJceDisplayer.display(j, "uRealMsgTime");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lToUin");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vMsg");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (MsgRecord)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int k;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int l = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, l);
      if (bool2)
      {
        short s1 = this.jdField_a_of_type_Short;
        short s3 = paramObject.jdField_a_of_type_Short;
        boolean bool3 = JceUtil.equals(s1, s3);
        if (bool3)
        {
          short s2 = this.jdField_b_of_type_Short;
          short s4 = paramObject.jdField_b_of_type_Short;
          boolean bool4 = JceUtil.equals(s2, s4);
          if (bool4)
          {
            Object localObject1 = this.jdField_a_of_type_JavaLangString;
            String str = paramObject.jdField_a_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str);
            if (localObject1 != 0)
            {
              int j = this.jdField_b_of_type_Int;
              int i1 = paramObject.jdField_b_of_type_Int;
              boolean bool5 = JceUtil.equals(j, i1);
              if (bool5)
              {
                l1 = this.jdField_b_of_type_Long;
                long l3 = paramObject.jdField_b_of_type_Long;
                bool5 = JceUtil.equals(l1, l3);
                if (bool5)
                {
                  Object localObject2 = this.jdField_a_of_type_ArrayOfByte;
                  byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
                  localObject2 = JceUtil.equals(localObject2, arrayOfByte);
                  if (localObject2 != 0)
                    k = 1;
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return k;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, j, j);
    this.jdField_a_of_type_Int = l;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, j);
    this.jdField_a_of_type_Short = s2;
    short s3 = this.jdField_b_of_type_Short;
    short s4 = paramJceInputStream.read(s3, 3, j);
    this.jdField_b_of_type_Short = s4;
    String str = paramJceInputStream.readString(4, j);
    this.jdField_a_of_type_JavaLangString = str;
    int i1 = this.jdField_b_of_type_Int;
    int i2 = paramJceInputStream.read(i1, 5, i);
    this.jdField_b_of_type_Int = i2;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 6, i);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    if (cache_vMsg == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vMsg = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vMsg;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 7, i);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    short s1 = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s1, 2);
    short s2 = this.jdField_b_of_type_Short;
    paramJceOutputStream.write(s2, 3);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 4);
    int j = this.jdField_b_of_type_Int;
    paramJceOutputStream.write(j, 5);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 6);
    if (this.jdField_a_of_type_ArrayOfByte == null)
      return;
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.MsgRecord
 * JD-Core Version:    0.5.4
 */