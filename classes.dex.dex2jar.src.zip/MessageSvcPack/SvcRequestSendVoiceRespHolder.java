package MessageSvcPack;

public final class SvcRequestSendVoiceRespHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendVoiceRespHolder
 * JD-Core Version:    0.5.4
 */