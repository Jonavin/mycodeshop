package MessageSvcPack;

public final class SvcRequestGetAllOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetAllOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */