package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SvcResponseGetGroupMsgNum extends JceStruct
{
  static ArrayList cache_vGroupInfo;
  public long a;
  public ArrayList a;

  static
  {
    if (!SvcResponseGetGroupMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGetGroupMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_JavaUtilArrayList = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vGroupInfo");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGetGroupMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      Object localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
      ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
      localObject1 = JceUtil.equals(localObject1, localArrayList);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, i);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    if (cache_vGroupInfo == null)
    {
      cache_vGroupInfo = new ArrayList();
      SvcResponseGroupInfo localSvcResponseGroupInfo = new SvcResponseGroupInfo();
      cache_vGroupInfo.add(localSvcResponseGroupInfo);
    }
    ArrayList localArrayList1 = cache_vGroupInfo;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, i, i);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetGroupMsgNum
 * JD-Core Version:    0.5.4
 */