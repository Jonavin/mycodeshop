package MessageSvcPack;

public final class SvcDelMsgInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcDelMsgInfoHolder
 * JD-Core Version:    0.5.4
 */