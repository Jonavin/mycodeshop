package MessageSvcPack;

public final class SvcRequestDelRoamMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestDelRoamMsgHolder
 * JD-Core Version:    0.5.4
 */