package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SvcResponseGetMsgNum extends JceStruct
{
  static ArrayList cache_vMsgInfos;
  public byte a;
  public int a;
  public long a;
  public String a;
  public ArrayList a;
  public byte b = null;

  static
  {
    if (!SvcResponseGetMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGetMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cMoreMsg");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vMsgInfos");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGetMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        byte b2 = this.b;
        byte b4 = paramObject.b;
        boolean bool3 = JceUtil.equals(b2, b4);
        if (bool3)
        {
          Object localObject1 = this.jdField_a_of_type_JavaLangString;
          String str = paramObject.jdField_a_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str);
          if (localObject1 != 0)
          {
            localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
            ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
            localObject1 = JceUtil.equals(localObject1, localArrayList);
            if (localObject1 != 0)
            {
              int i = this.jdField_a_of_type_Int;
              int k = paramObject.jdField_a_of_type_Int;
              boolean bool4 = JceUtil.equals(i, k);
              if (bool4)
                j = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 2, j);
    this.b = b4;
    String str = paramJceInputStream.readString(3, j);
    this.jdField_a_of_type_JavaLangString = str;
    if (cache_vMsgInfos == null)
    {
      cache_vMsgInfos = new ArrayList();
      SvcGetMsgNumInfo localSvcGetMsgNumInfo = new SvcGetMsgNumInfo();
      cache_vMsgInfos.add(localSvcGetMsgNumInfo);
    }
    ArrayList localArrayList1 = cache_vMsgInfos;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 4, j);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 5, i);
    this.jdField_a_of_type_Int = l;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 2);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 3);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 4);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetMsgNum
 * JD-Core Version:    0.5.4
 */