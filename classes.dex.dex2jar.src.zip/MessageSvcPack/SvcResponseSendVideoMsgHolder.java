package MessageSvcPack;

public final class SvcResponseSendVideoMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendVideoMsgHolder
 * JD-Core Version:    0.5.4
 */