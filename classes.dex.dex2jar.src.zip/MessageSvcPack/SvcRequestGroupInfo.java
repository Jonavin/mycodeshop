package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestGroupInfo extends JceStruct
{
  public long a = 0L;
  public long b = 0L;

  static
  {
    if (!SvcRequestGroupInfo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.a;
    localJceDisplayer.display(l1, "lGroupCode");
    long l2 = this.b;
    localJceDisplayer.display(l2, "lLastSeqId");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestGroupInfo)paramObject;
    long l1 = this.a;
    long l2 = paramObject.a;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      l1 = this.b;
      long l3 = paramObject.b;
      bool = JceUtil.equals(l1, l3);
      if (bool)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.a;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.a = localObject1;
    long l3 = this.b;
    long l4 = paramJceInputStream.read(l3, 1, true);
    Object localObject2;
    this.b = localObject2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.a;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.b;
    paramJceOutputStream.write(l2, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGroupInfo
 * JD-Core Version:    0.5.4
 */