package MessageSvcPack;

public final class SvcRequestOfflineHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestOfflineHolder
 * JD-Core Version:    0.5.4
 */