package MessageSvcPack;

public final class SvcRequestGetOfflineMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetOfflineMsgHolder
 * JD-Core Version:    0.5.4
 */