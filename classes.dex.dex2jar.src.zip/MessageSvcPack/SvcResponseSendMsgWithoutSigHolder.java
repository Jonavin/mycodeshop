package MessageSvcPack;

public final class SvcResponseSendMsgWithoutSigHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendMsgWithoutSigHolder
 * JD-Core Version:    0.5.4
 */