package MessageSvcPack;

public final class SvcResponseBatchSetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseBatchSetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */