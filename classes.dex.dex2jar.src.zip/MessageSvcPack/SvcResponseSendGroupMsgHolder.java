package MessageSvcPack;

public final class SvcResponseSendGroupMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendGroupMsgHolder
 * JD-Core Version:    0.5.4
 */