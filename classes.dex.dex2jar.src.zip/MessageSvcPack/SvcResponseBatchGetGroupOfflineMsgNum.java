package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SvcResponseBatchGetGroupOfflineMsgNum extends JceStruct
{
  static ArrayList cache_vGroupInfo;
  public byte a;
  public long a;
  public String a;
  public ArrayList a;
  public short a;
  public byte b = null;

  static
  {
    if (!SvcResponseBatchGetGroupOfflineMsgNum.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseBatchGetGroupOfflineMsgNum()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_JavaUtilArrayList = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cOnline");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wGroupNum");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vGroupInfo");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseBatchGetGroupOfflineMsgNum)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        byte b2 = this.b;
        byte b4 = paramObject.b;
        boolean bool3 = JceUtil.equals(b2, b4);
        if (bool3)
        {
          short s1 = this.jdField_a_of_type_Short;
          short s2 = paramObject.jdField_a_of_type_Short;
          boolean bool4 = JceUtil.equals(s1, s2);
          if (bool4)
          {
            Object localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
            ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
            localObject1 = JceUtil.equals(localObject1, localArrayList);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_a_of_type_JavaLangString;
              String str = paramObject.jdField_a_of_type_JavaLangString;
              localObject1 = JceUtil.equals(localObject1, str);
              if (localObject1 != 0)
                i = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, i);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, i);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 2, i);
    this.b = b4;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 3, i);
    this.jdField_a_of_type_Short = s2;
    if (cache_vGroupInfo == null)
    {
      cache_vGroupInfo = new ArrayList();
      GroupInfo localGroupInfo = new GroupInfo();
      cache_vGroupInfo.add(localGroupInfo);
    }
    ArrayList localArrayList1 = cache_vGroupInfo;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 4, i);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    String str = paramJceInputStream.readString(5, i);
    this.jdField_a_of_type_JavaLangString = str;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 2);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 3);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 4);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseBatchGetGroupOfflineMsgNum
 * JD-Core Version:    0.5.4
 */