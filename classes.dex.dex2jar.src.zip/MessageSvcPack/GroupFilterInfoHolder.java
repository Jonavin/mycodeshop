package MessageSvcPack;

public final class GroupFilterInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.GroupFilterInfoHolder
 * JD-Core Version:    0.5.4
 */