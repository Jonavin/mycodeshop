package MessageSvcPack;

public final class RoamInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.RoamInfoHolder
 * JD-Core Version:    0.5.4
 */