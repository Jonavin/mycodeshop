package MessageSvcPack;

public final class SvcResponseBatchGetGroupOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseBatchGetGroupOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */