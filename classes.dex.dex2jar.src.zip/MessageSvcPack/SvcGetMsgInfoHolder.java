package MessageSvcPack;

public final class SvcGetMsgInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcGetMsgInfoHolder
 * JD-Core Version:    0.5.4
 */