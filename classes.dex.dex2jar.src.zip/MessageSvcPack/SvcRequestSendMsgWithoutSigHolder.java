package MessageSvcPack;

public final class SvcRequestSendMsgWithoutSigHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendMsgWithoutSigHolder
 * JD-Core Version:    0.5.4
 */