package MessageSvcPack;

public final class SvcRequestOfflineMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestOfflineMsgHolder
 * JD-Core Version:    0.5.4
 */