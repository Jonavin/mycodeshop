package MessageSvcPack;

public final class SvcRequestGetMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetMsgHolder
 * JD-Core Version:    0.5.4
 */