package MessageSvcPack;

public final class SvcRequestHelloHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestHelloHolder
 * JD-Core Version:    0.5.4
 */