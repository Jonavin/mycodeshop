package MessageSvcPack;

public final class SvcRequestBatchGetGroupOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestBatchGetGroupOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */