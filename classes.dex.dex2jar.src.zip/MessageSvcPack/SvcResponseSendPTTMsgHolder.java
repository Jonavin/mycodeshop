package MessageSvcPack;

public final class SvcResponseSendPTTMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendPTTMsgHolder
 * JD-Core Version:    0.5.4
 */