package MessageSvcPack;

public final class SvcRequestGetMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetMsgNumHolder
 * JD-Core Version:    0.5.4
 */