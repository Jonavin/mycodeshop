package MessageSvcPack;

public final class MsgRecordHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.MsgRecordHolder
 * JD-Core Version:    0.5.4
 */