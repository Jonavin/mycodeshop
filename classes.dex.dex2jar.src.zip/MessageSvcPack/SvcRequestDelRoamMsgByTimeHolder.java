package MessageSvcPack;

public final class SvcRequestDelRoamMsgByTimeHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestDelRoamMsgByTimeHolder
 * JD-Core Version:    0.5.4
 */