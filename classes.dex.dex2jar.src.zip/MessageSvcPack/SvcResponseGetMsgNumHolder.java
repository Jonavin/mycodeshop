package MessageSvcPack;

public final class SvcResponseGetMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetMsgNumHolder
 * JD-Core Version:    0.5.4
 */