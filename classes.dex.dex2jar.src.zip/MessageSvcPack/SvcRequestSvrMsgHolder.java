package MessageSvcPack;

public final class SvcRequestSvrMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSvrMsgHolder
 * JD-Core Version:    0.5.4
 */