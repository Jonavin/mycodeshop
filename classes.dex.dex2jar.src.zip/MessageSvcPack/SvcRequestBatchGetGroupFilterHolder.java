package MessageSvcPack;

public final class SvcRequestBatchGetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestBatchGetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */