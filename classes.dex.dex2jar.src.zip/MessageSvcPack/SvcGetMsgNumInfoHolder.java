package MessageSvcPack;

public final class SvcGetMsgNumInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcGetMsgNumInfoHolder
 * JD-Core Version:    0.5.4
 */