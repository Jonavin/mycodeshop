package MessageSvcPack;

public final class SvcResponseSendVoiceReqHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendVoiceReqHolder
 * JD-Core Version:    0.5.4
 */