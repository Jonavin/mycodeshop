package MessageSvcPack;

public final class SvcResponseOfflineHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseOfflineHolder
 * JD-Core Version:    0.5.4
 */