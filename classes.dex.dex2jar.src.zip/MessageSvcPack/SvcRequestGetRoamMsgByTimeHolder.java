package MessageSvcPack;

public final class SvcRequestGetRoamMsgByTimeHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetRoamMsgByTimeHolder
 * JD-Core Version:    0.5.4
 */