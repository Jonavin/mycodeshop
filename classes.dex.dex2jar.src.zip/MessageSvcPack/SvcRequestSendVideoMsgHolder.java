package MessageSvcPack;

public final class SvcRequestSendVideoMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendVideoMsgHolder
 * JD-Core Version:    0.5.4
 */