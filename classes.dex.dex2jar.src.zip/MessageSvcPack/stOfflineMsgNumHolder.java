package MessageSvcPack;

public final class stOfflineMsgNumHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.stOfflineMsgNumHolder
 * JD-Core Version:    0.5.4
 */