package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcResponseDelMsg extends JceStruct
{
  public byte a;
  public long a;
  public String a;

  static
  {
    if (!SvcResponseDelMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseDelMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    byte b = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b, "cReplyCode");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseDelMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
          i = 1;
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte b = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseDelMsg
 * JD-Core Version:    0.5.4
 */