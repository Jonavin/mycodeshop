package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class stGroupMsgRecord extends JceStruct
{
  static byte[] cache_vMsg;
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte[] a;
  public long b = 0L;
  public long c = 0L;
  public long d = 0L;

  static
  {
    if (!stGroupMsgRecord.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public stGroupMsgRecord()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_ArrayOfByte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lGroupCode");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cGroupType");
    long l2 = this.b;
    localJceDisplayer.display(l2, "lSendUin");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lsMsgSeq");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
    long l4 = this.d;
    localJceDisplayer.display(l4, "lInfoSeq");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "wMsgLen");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strMsg");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vMsg");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (stGroupMsgRecord)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        l1 = this.b;
        long l3 = paramObject.b;
        bool2 = JceUtil.equals(l1, l3);
        if (bool2)
        {
          l1 = this.c;
          long l4 = paramObject.c;
          bool2 = JceUtil.equals(l1, l4);
          if (bool2)
          {
            int i = this.jdField_a_of_type_Int;
            int k = paramObject.jdField_a_of_type_Int;
            boolean bool3 = JceUtil.equals(i, k);
            if (bool3)
            {
              l1 = this.d;
              long l5 = paramObject.d;
              bool3 = JceUtil.equals(l1, l5);
              if (bool3)
              {
                short s1 = this.jdField_a_of_type_Short;
                short s2 = paramObject.jdField_a_of_type_Short;
                boolean bool4 = JceUtil.equals(s1, s2);
                if (bool4)
                {
                  Object localObject1 = this.jdField_a_of_type_JavaLangString;
                  String str = paramObject.jdField_a_of_type_JavaLangString;
                  localObject1 = JceUtil.equals(localObject1, str);
                  if (localObject1 != 0)
                  {
                    localObject1 = this.jdField_a_of_type_ArrayOfByte;
                    byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
                    localObject1 = JceUtil.equals(localObject1, arrayOfByte);
                    if (localObject1 != 0)
                      j = 1;
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    long l3 = this.b;
    long l4 = paramJceInputStream.read(l3, 2, j);
    Object localObject2;
    this.b = localObject2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 3, j);
    Object localObject3;
    this.c = localObject3;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 4, j);
    this.jdField_a_of_type_Int = l;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 5, j);
    Object localObject4;
    this.d = localObject4;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 6, j);
    this.jdField_a_of_type_Short = s2;
    String str = paramJceInputStream.readString(7, j);
    this.jdField_a_of_type_JavaLangString = str;
    if (cache_vMsg == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vMsg = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vMsg;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 8, i);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    long l2 = this.b;
    paramJceOutputStream.write(l2, 2);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 3);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 4);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 5);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 6);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 7);
    if (this.jdField_a_of_type_ArrayOfByte == null)
      return;
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.stGroupMsgRecord
 * JD-Core Version:    0.5.4
 */