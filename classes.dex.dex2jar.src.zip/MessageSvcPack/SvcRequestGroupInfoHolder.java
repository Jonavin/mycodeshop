package MessageSvcPack;

public final class SvcRequestGroupInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGroupInfoHolder
 * JD-Core Version:    0.5.4
 */