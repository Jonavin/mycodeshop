package MessageSvcPack;

public final class SvcResponseBatchGetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseBatchGetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */