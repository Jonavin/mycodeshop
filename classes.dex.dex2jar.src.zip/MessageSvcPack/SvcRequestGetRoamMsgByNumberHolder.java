package MessageSvcPack;

public final class SvcRequestGetRoamMsgByNumberHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetRoamMsgByNumberHolder
 * JD-Core Version:    0.5.4
 */