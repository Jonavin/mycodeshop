package MessageSvcPack;

public final class SvcResponseDelRoamMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseDelRoamMsgHolder
 * JD-Core Version:    0.5.4
 */