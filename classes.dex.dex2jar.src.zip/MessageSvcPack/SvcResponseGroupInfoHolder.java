package MessageSvcPack;

public final class SvcResponseGroupInfoHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGroupInfoHolder
 * JD-Core Version:    0.5.4
 */