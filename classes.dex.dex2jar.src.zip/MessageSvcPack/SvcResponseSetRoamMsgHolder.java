package MessageSvcPack;

public final class SvcResponseSetRoamMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSetRoamMsgHolder
 * JD-Core Version:    0.5.4
 */