package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;
import java.util.ArrayList;

public final class SvcResponseGetRoamMsg extends JceStruct
{
  static ArrayList cache_vMsgs;
  public byte a;
  public long a;
  public String a;
  public ArrayList a;
  public long b = 0L;
  public long c = 0L;
  public long d = 0L;

  static
  {
    if (!SvcResponseGetRoamMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGetRoamMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_JavaUtilArrayList = null;
  }

  public final ArrayList a()
  {
    return this.jdField_a_of_type_JavaUtilArrayList;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
    long l2 = this.b;
    localJceDisplayer.display(l2, "lResLastMsgTime");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lRandom");
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    localJceDisplayer.display(localArrayList, "vMsgs");
    long l4 = this.d;
    localJceDisplayer.display(l4, "lPeerUin");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGetRoamMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          l1 = this.b;
          long l3 = paramObject.b;
          localObject1 = JceUtil.equals(l1, l3);
          if (localObject1 != 0)
          {
            l1 = this.c;
            long l4 = paramObject.c;
            localObject1 = JceUtil.equals(l1, l4);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_a_of_type_JavaUtilArrayList;
              ArrayList localArrayList = paramObject.jdField_a_of_type_JavaUtilArrayList;
              localObject1 = JceUtil.equals(localObject1, localArrayList);
              if (localObject1 != 0)
              {
                l1 = this.d;
                long l5 = paramObject.d;
                localObject1 = JceUtil.equals(l1, l5);
                if (localObject1 != 0)
                  i = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, j);
    this.jdField_a_of_type_JavaLangString = str;
    long l3 = this.b;
    long l4 = paramJceInputStream.read(l3, 3, j);
    Object localObject2;
    this.b = localObject2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 4, j);
    Object localObject3;
    this.c = localObject3;
    if (cache_vMsgs == null)
    {
      cache_vMsgs = new ArrayList();
      MsgRecord localMsgRecord = new MsgRecord();
      cache_vMsgs.add(localMsgRecord);
    }
    ArrayList localArrayList1 = cache_vMsgs;
    ArrayList localArrayList2 = (ArrayList)paramJceInputStream.read(localArrayList1, 6, j);
    this.jdField_a_of_type_JavaUtilArrayList = localArrayList2;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 7, i);
    Object localObject4;
    this.d = localObject4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    long l2 = this.b;
    paramJceOutputStream.write(l2, 3);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 4);
    ArrayList localArrayList = this.jdField_a_of_type_JavaUtilArrayList;
    paramJceOutputStream.write(localArrayList, 6);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetRoamMsg
 * JD-Core Version:    0.5.4
 */