package MessageSvcPack;

public final class SvcResponseGetMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetMsgHolder
 * JD-Core Version:    0.5.4
 */