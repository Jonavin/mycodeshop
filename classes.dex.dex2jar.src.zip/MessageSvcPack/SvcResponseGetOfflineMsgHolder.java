package MessageSvcPack;

public final class SvcResponseGetOfflineMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetOfflineMsgHolder
 * JD-Core Version:    0.5.4
 */