package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcGetMsgNumInfo extends JceStruct
{
  public int a;
  public long a;

  static
  {
    if (!SvcGetMsgNumInfo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcGetMsgNumInfo()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lFromUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "iMsgNum");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcGetMsgNumInfo)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
        j = 1;
    }
    while (true)
    {
      return j;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcGetMsgNumInfo
 * JD-Core Version:    0.5.4
 */