package MessageSvcPack;

public final class SvcResponseSendVoiceRespHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseSendVoiceRespHolder
 * JD-Core Version:    0.5.4
 */