package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestGetMsg extends JceStruct
{
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte b = null;
  public byte c = null;
  public byte d = null;
  public byte e = null;

  static
  {
    if (!SvcRequestGetMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestGetMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uDateTime");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sA2");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cVerifyType");
    byte b2 = this.b;
    localJceDisplayer.display(b2, "cRecivePic");
    byte b3 = this.c;
    localJceDisplayer.display(b3, "cAutoGetMsg");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shAbility");
    byte b4 = this.d;
    localJceDisplayer.display(b4, "cMsgStoreType");
    byte b5 = this.e;
    localJceDisplayer.display(b5, "cPushService");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestGetMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          byte b1 = this.jdField_a_of_type_Byte;
          byte b6 = paramObject.jdField_a_of_type_Byte;
          boolean bool3 = JceUtil.equals(b1, b6);
          if (bool3)
          {
            byte b2 = this.b;
            byte b7 = paramObject.b;
            boolean bool4 = JceUtil.equals(b2, b7);
            if (bool4)
            {
              byte b3 = this.c;
              byte b8 = paramObject.c;
              boolean bool5 = JceUtil.equals(b3, b8);
              if (bool5)
              {
                short s1 = this.jdField_a_of_type_Short;
                short s2 = paramObject.jdField_a_of_type_Short;
                boolean bool6 = JceUtil.equals(s1, s2);
                if (bool6)
                {
                  byte b4 = this.d;
                  byte b9 = paramObject.d;
                  boolean bool7 = JceUtil.equals(b4, b9);
                  if (bool7)
                  {
                    byte b5 = this.e;
                    byte b10 = paramObject.e;
                    boolean bool8 = JceUtil.equals(b5, b10);
                    if (bool8)
                      j = 1;
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    String str = paramJceInputStream.readString(2, null);
    this.jdField_a_of_type_JavaLangString = str;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, null);
    this.jdField_a_of_type_Byte = b2;
    byte b3 = this.b;
    byte b4 = paramJceInputStream.read(b3, 4, null);
    this.b = b4;
    byte b5 = this.c;
    byte b6 = paramJceInputStream.read(b5, 5, null);
    this.c = b6;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 6, null);
    this.jdField_a_of_type_Short = s2;
    byte b7 = this.d;
    byte b8 = paramJceInputStream.read(b7, 7, null);
    this.d = b8;
    byte b9 = this.e;
    byte b10 = paramJceInputStream.read(b9, 8, null);
    this.e = b10;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    if (this.jdField_a_of_type_JavaLangString != null)
    {
      String str = this.jdField_a_of_type_JavaLangString;
      paramJceOutputStream.write(str, 2);
    }
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    byte b2 = this.b;
    paramJceOutputStream.write(b2, 4);
    byte b3 = this.c;
    paramJceOutputStream.write(b3, 5);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 6);
    byte b4 = this.d;
    paramJceOutputStream.write(b4, 7);
    byte b5 = this.e;
    paramJceOutputStream.write(b5, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetMsg
 * JD-Core Version:    0.5.4
 */