package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestOnline extends JceStruct
{
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte b;
  public String b;
  public short b;

  static
  {
    if (!SvcRequestOnline.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestOnline()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
    this.jdField_b_of_type_Short = null;
    this.jdField_a_of_type_Byte = 1;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_a_of_type_Int = null;
    this.jdField_b_of_type_Byte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUin");
    short s1 = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s1, "wClientType");
    short s2 = this.jdField_b_of_type_Short;
    localJceDisplayer.display(s2, "wLoginStatus");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "bPushMsg");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "sA2");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "sLC");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uIP");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cVerifyType");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestOnline)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      short s1 = this.jdField_a_of_type_Short;
      short s3 = paramObject.jdField_a_of_type_Short;
      boolean bool2 = JceUtil.equals(s1, s3);
      if (bool2)
      {
        short s2 = this.jdField_b_of_type_Short;
        short s4 = paramObject.jdField_b_of_type_Short;
        boolean bool3 = JceUtil.equals(s2, s4);
        if (bool3)
        {
          byte b1 = this.jdField_a_of_type_Byte;
          byte b3 = paramObject.jdField_a_of_type_Byte;
          boolean bool4 = JceUtil.equals(b1, b3);
          if (bool4)
          {
            Object localObject1 = this.jdField_a_of_type_JavaLangString;
            String str1 = paramObject.jdField_a_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str1);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_b_of_type_JavaLangString;
              String str2 = paramObject.jdField_b_of_type_JavaLangString;
              localObject1 = JceUtil.equals(localObject1, str2);
              if (localObject1 != 0)
              {
                int i = this.jdField_a_of_type_Int;
                int k = paramObject.jdField_a_of_type_Int;
                boolean bool5 = JceUtil.equals(i, k);
                if (bool5)
                {
                  byte b2 = this.jdField_b_of_type_Byte;
                  byte b4 = paramObject.jdField_b_of_type_Byte;
                  boolean bool6 = JceUtil.equals(b2, b4);
                  if (bool6)
                    j = 1;
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 1, true);
    this.jdField_a_of_type_Short = s2;
    short s3 = this.jdField_b_of_type_Short;
    short s4 = paramJceInputStream.read(s3, 2, true);
    this.jdField_b_of_type_Short = s4;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, true);
    this.jdField_a_of_type_Byte = b2;
    String str1 = paramJceInputStream.readString(4, null);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(5, null);
    this.jdField_b_of_type_JavaLangString = str2;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 6, null);
    this.jdField_a_of_type_Int = j;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 7, null);
    this.jdField_b_of_type_Byte = b4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    short s1 = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s1, 1);
    short s2 = this.jdField_b_of_type_Short;
    paramJceOutputStream.write(s2, 2);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    if (this.jdField_a_of_type_JavaLangString != null)
    {
      String str1 = this.jdField_a_of_type_JavaLangString;
      paramJceOutputStream.write(str1, 4);
    }
    if (this.jdField_b_of_type_JavaLangString != null)
    {
      String str2 = this.jdField_b_of_type_JavaLangString;
      paramJceOutputStream.write(str2, 5);
    }
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 6);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 7);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestOnline
 * JD-Core Version:    0.5.4
 */