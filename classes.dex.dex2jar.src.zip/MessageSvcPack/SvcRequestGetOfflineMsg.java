package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestGetOfflineMsg extends JceStruct
{
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte b;
  public long b;
  public byte c;
  public long c;
  public byte d = null;

  static
  {
    if (!SvcRequestGetOfflineMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestGetOfflineMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_Long = 0L;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_b_of_type_Byte = null;
    this.jdField_c_of_type_Byte = null;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cVerifyType");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "sA2");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lFromUin");
    long l3 = this.jdField_c_of_type_Long;
    localJceDisplayer.display(l3, "lToUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uTime");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cRecivePic");
    byte b3 = this.jdField_c_of_type_Byte;
    localJceDisplayer.display(b3, "cAutoGetMsg");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shAbility");
    byte b4 = this.d;
    localJceDisplayer.display(b4, "cMsgStoreType");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestGetOfflineMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b5 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b5);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str);
        if (localObject1 != 0)
        {
          l1 = this.jdField_b_of_type_Long;
          long l3 = paramObject.jdField_b_of_type_Long;
          localObject1 = JceUtil.equals(l1, l3);
          if (localObject1 != 0)
          {
            l1 = this.jdField_c_of_type_Long;
            long l4 = paramObject.jdField_c_of_type_Long;
            localObject1 = JceUtil.equals(l1, l4);
            if (localObject1 != 0)
            {
              int i = this.jdField_a_of_type_Int;
              int k = paramObject.jdField_a_of_type_Int;
              boolean bool3 = JceUtil.equals(i, k);
              if (bool3)
              {
                byte b2 = this.jdField_b_of_type_Byte;
                byte b6 = paramObject.jdField_b_of_type_Byte;
                boolean bool4 = JceUtil.equals(b2, b6);
                if (bool4)
                {
                  byte b3 = this.jdField_c_of_type_Byte;
                  byte b7 = paramObject.jdField_c_of_type_Byte;
                  boolean bool5 = JceUtil.equals(b3, b7);
                  if (bool5)
                  {
                    short s1 = this.jdField_a_of_type_Short;
                    short s2 = paramObject.jdField_a_of_type_Short;
                    boolean bool6 = JceUtil.equals(s1, s2);
                    if (bool6)
                    {
                      byte b4 = this.d;
                      byte b8 = paramObject.d;
                      boolean bool7 = JceUtil.equals(b4, b8);
                      if (bool7)
                        j = 1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    String str = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 3, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.jdField_c_of_type_Long;
    long l6 = paramJceInputStream.read(l5, 4, true);
    Object localObject3;
    this.jdField_c_of_type_Long = localObject3;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 5, true);
    this.jdField_a_of_type_Int = j;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 6, true);
    this.jdField_b_of_type_Byte = b4;
    byte b5 = this.jdField_c_of_type_Byte;
    byte b6 = paramJceInputStream.read(b5, 7, true);
    this.jdField_c_of_type_Byte = b6;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 8, null);
    this.jdField_a_of_type_Short = s2;
    byte b7 = this.d;
    byte b8 = paramJceInputStream.read(b7, 9, null);
    this.d = b8;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 2);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 3);
    long l3 = this.jdField_c_of_type_Long;
    paramJceOutputStream.write(l3, 4);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 5);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 6);
    byte b3 = this.jdField_c_of_type_Byte;
    paramJceOutputStream.write(b3, 7);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 8);
    byte b4 = this.d;
    paramJceOutputStream.write(b4, 9);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetOfflineMsg
 * JD-Core Version:    0.5.4
 */