package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcResponseGetGroupFilter extends JceStruct
{
  public byte a;
  public long a;
  public String a;
  public byte b;
  public long b;

  static
  {
    if (!SvcResponseGetGroupFilter.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcResponseGetGroupFilter()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_b_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cReplyCode");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lGroupCode");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cOp");
    String str = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str, "strResult");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcResponseGetGroupFilter)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        l1 = this.jdField_b_of_type_Long;
        long l3 = paramObject.jdField_b_of_type_Long;
        bool2 = JceUtil.equals(l1, l3);
        if (bool2)
        {
          byte b2 = this.jdField_b_of_type_Byte;
          byte b4 = paramObject.jdField_b_of_type_Byte;
          boolean bool3 = JceUtil.equals(b2, b4);
          if (bool3)
          {
            Object localObject1 = this.jdField_a_of_type_JavaLangString;
            String str = paramObject.jdField_a_of_type_JavaLangString;
            localObject1 = JceUtil.equals(localObject1, str);
            if (localObject1 != 0)
              i = 1;
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 2, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 3, true);
    this.jdField_b_of_type_Byte = b4;
    String str = paramJceInputStream.readString(4, true);
    this.jdField_a_of_type_JavaLangString = str;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 2);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 3);
    String str = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str, 4);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetGroupFilter
 * JD-Core Version:    0.5.4
 */