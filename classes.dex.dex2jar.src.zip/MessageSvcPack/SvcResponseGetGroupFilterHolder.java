package MessageSvcPack;

public final class SvcResponseGetGroupFilterHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcResponseGetGroupFilterHolder
 * JD-Core Version:    0.5.4
 */