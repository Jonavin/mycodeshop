package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcDelMsgInfo extends JceStruct
{
  public int a;
  public long a;
  public short a;

  static
  {
    if (!SvcDelMsgInfo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcDelMsgInfo()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Short = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lFromUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shMsgSeq");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcDelMsgInfo)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        short s1 = this.jdField_a_of_type_Short;
        short s2 = paramObject.jdField_a_of_type_Short;
        boolean bool3 = JceUtil.equals(s1, s2);
        if (bool3)
          j = 1;
      }
    }
    while (true)
    {
      return j;
      Object localObject = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    int i = this.jdField_a_of_type_Int;
    int j = paramJceInputStream.read(i, 1, true);
    this.jdField_a_of_type_Int = j;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 2, true);
    this.jdField_a_of_type_Short = s2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcDelMsgInfo
 * JD-Core Version:    0.5.4
 */