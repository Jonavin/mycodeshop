package MessageSvcPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class SvcRequestSendVoiceReq extends JceStruct
{
  static byte[] cache_vFtnMsg;
  static byte[] cache_vIMsg;
  public byte a;
  public int a;
  public long a;
  public byte[] a;
  public long b;
  public byte[] b;

  static
  {
    if (!SvcRequestSendVoiceReq.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public SvcRequestSendVoiceReq()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_ArrayOfByte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lPeerUin");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uDateTime");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cVerifyType");
    byte[] arrayOfByte1 = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte1, "vIMsg");
    byte[] arrayOfByte2 = this.jdField_b_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte2, "vFtnMsg");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (SvcRequestSendVoiceReq)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      l1 = this.jdField_b_of_type_Long;
      long l3 = paramObject.jdField_b_of_type_Long;
      bool1 = JceUtil.equals(l1, l3);
      if (bool1)
      {
        int i = this.jdField_a_of_type_Int;
        int k = paramObject.jdField_a_of_type_Int;
        boolean bool2 = JceUtil.equals(i, k);
        if (bool2)
        {
          byte b1 = this.jdField_a_of_type_Byte;
          byte b2 = paramObject.jdField_a_of_type_Byte;
          boolean bool3 = JceUtil.equals(b1, b2);
          if (bool3)
          {
            Object localObject1 = this.jdField_a_of_type_ArrayOfByte;
            byte[] arrayOfByte1 = paramObject.jdField_a_of_type_ArrayOfByte;
            localObject1 = JceUtil.equals(localObject1, arrayOfByte1);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_b_of_type_ArrayOfByte;
              byte[] arrayOfByte2 = paramObject.jdField_b_of_type_ArrayOfByte;
              localObject1 = JceUtil.equals(localObject1, arrayOfByte2);
              if (localObject1 != 0)
                j = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, j, j);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 2, j);
    this.jdField_a_of_type_Int = l;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 3, j);
    this.jdField_a_of_type_Byte = b2;
    if (cache_vIMsg == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vIMsg = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vIMsg;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 4, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
    if (cache_vFtnMsg == null)
    {
      byte[] arrayOfByte4 = (byte[])new byte[j];
      cache_vFtnMsg = arrayOfByte4;
      ((byte[])arrayOfByte4)[i] = i;
    }
    byte[] arrayOfByte5 = cache_vFtnMsg;
    byte[] arrayOfByte6 = (byte[])paramJceInputStream.read(arrayOfByte5, 5, j);
    this.jdField_b_of_type_ArrayOfByte = arrayOfByte6;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 1);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 2);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 3);
    byte[] arrayOfByte1 = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte1, 4);
    byte[] arrayOfByte2 = this.jdField_b_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte2, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestSendVoiceReq
 * JD-Core Version:    0.5.4
 */