package MessageSvcPack;

public final class SvcRequestGetGroupMsgHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     MessageSvcPack.SvcRequestGetGroupMsgHolder
 * JD-Core Version:    0.5.4
 */