import android.os.Handler;
import android.widget.Toast;
import com.tencent.mobileqq.activity.ContactActivity;

final class cl
  implements Runnable
{
  cl(ch paramch)
  {
  }

  public final void run()
  {
    ContactActivity.access$300(this.a.a).sendEmptyMessage(1004);
    Toast.makeText(this.a.a, 2131296301, 0).show();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cl
 * JD-Core Version:    0.5.4
 */