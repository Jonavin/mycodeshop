import android.content.Context;
import android.view.OrientationEventListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.video.VcCamera;

public final class aj extends OrientationEventListener
{
  public aj(ChatVideoActivity paramChatVideoActivity, Context paramContext)
  {
    super(paramContext, 2);
  }

  public final void onOrientationChanged(int paramInt)
  {
    if ((paramInt > 314) || (paramInt < 45))
    {
      ChatVideoActivity.access$000(this.a);
      VcCamera.setRotation(0);
    }
    while (true)
    {
      ChatVideoActivity localChatVideoActivity = this.a;
      ChatVideoActivity.access$000(this.a);
      int i = VcCamera.getRotation();
      ChatVideoActivity.access$100(localChatVideoActivity, i);
      return;
      if ((paramInt > 44) && (paramInt < 135))
      {
        ChatVideoActivity.access$000(this.a);
        VcCamera.setRotation(90);
      }
      if ((paramInt > 134) && (paramInt < 225))
      {
        ChatVideoActivity.access$000(this.a);
        VcCamera.setRotation(180);
      }
      ChatVideoActivity.access$000(this.a);
      VcCamera.setRotation(270);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     aj
 * JD-Core Version:    0.5.4
 */