import com.tencent.mobileqq.utils.Recorder.OnStateChangedListener;

public final class cc
  implements Recorder.OnStateChangedListener
{
  public cc(cb paramcb)
  {
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cc
 * JD-Core Version:    0.5.4
 */