import com.tencent.mobileqq.activity.ChatHistory;

public final class ae
  implements Runnable
{
  public ae(ChatHistory paramChatHistory)
  {
  }

  public final void run()
  {
    ChatHistory.access$1700(this.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ae
 * JD-Core Version:    0.5.4
 */