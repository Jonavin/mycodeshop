import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.service.message.EmoWindow;

public final class bc
  implements TextWatcher
{
  boolean jdField_a_of_type_Boolean = null;

  public bc(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void afterTextChanged(Editable paramEditable)
  {
  }

  public final void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public final void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 1;
    boolean bool = this.jdField_a_of_type_Boolean;
    if (!bool)
    {
      this.jdField_a_of_type_Boolean = i;
      if (paramCharSequence != null)
        break label25;
    }
    while (true)
    {
      return;
      label25: Object localObject = paramCharSequence.toString();
      int j = paramInt1 + paramInt3;
      localObject = ((String)localObject).substring(paramInt1, j);
      int k = ((String)localObject).indexOf('/');
      if (k >= 0)
      {
        int l = ((String)localObject).length() - i;
        if (k < l)
        {
          ChatWindowActivity localChatWindowActivity = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
          float f1 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
          localObject = EmoWindow.toShownEmoSpanMsg(localChatWindowActivity, f1, (String)localObject);
          if (localObject != null)
          {
            if (paramInt1 == 0)
            {
              int i1 = paramInt1 + paramInt3;
              int i2 = paramCharSequence.length();
              if (i1 == i2)
                break label166;
            }
            localObject = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity;
            float f2 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
            String str = paramCharSequence.toString();
            localObject = EmoWindow.toShownEmoSpanMsg((Context)localObject, f2, str);
            label166: int i3 = ChatWindowActivity.access$2600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).getSelectionEnd();
            ChatWindowActivity.access$2600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setText((CharSequence)localObject);
            ChatWindowActivity.access$2600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity).setSelection(i3);
          }
        }
      }
      this.jdField_a_of_type_Boolean = null;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bc
 * JD-Core Version:    0.5.4
 */