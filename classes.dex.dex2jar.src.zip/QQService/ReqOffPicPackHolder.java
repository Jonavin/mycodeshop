package QQService;

public final class ReqOffPicPackHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqOffPicPackHolder
 * JD-Core Version:    0.5.4
 */