package QQService;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ReqDownload extends JceStruct
{
  public byte a;
  public long a;
  public String a;
  public long b;
  public String b;
  public long c = 0L;

  static
  {
    if (!ReqDownload.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ReqDownload()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSumCmd");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lToUIN");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lSeq");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strFliePath");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lReserve");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strReserve");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ReqDownload)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramObject.jdField_a_of_type_Byte;
    boolean bool = JceUtil.equals(b1, b2);
    int i;
    if (bool)
    {
      long l1 = this.jdField_a_of_type_Long;
      long l2 = paramObject.jdField_a_of_type_Long;
      bool = JceUtil.equals(l1, l2);
      if (bool)
      {
        l1 = this.jdField_b_of_type_Long;
        long l3 = paramObject.jdField_b_of_type_Long;
        bool = JceUtil.equals(l1, l3);
        if (bool)
        {
          Object localObject1 = this.jdField_a_of_type_JavaLangString;
          String str1 = paramObject.jdField_a_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str1);
          if (localObject1 != 0)
          {
            l1 = this.c;
            long l4 = paramObject.c;
            localObject1 = JceUtil.equals(l1, l4);
            if (localObject1 != 0)
            {
              localObject1 = this.jdField_b_of_type_JavaLangString;
              String str2 = paramObject.jdField_b_of_type_JavaLangString;
              localObject1 = JceUtil.equals(localObject1, str2);
              if (localObject1 != 0)
                i = 1;
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 0, true);
    this.jdField_a_of_type_Byte = b2;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 1, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 2, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    String str1 = paramJceInputStream.readString(3, true);
    this.jdField_a_of_type_JavaLangString = str1;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 4, true);
    Object localObject3;
    this.c = localObject3;
    String str2 = paramJceInputStream.readString(5, true);
    this.jdField_b_of_type_JavaLangString = str2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 1);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 2);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 3);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 4);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 5);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqDownload
 * JD-Core Version:    0.5.4
 */