package QQService;

public final class RespOffFilePackHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespOffFilePackHolder
 * JD-Core Version:    0.5.4
 */