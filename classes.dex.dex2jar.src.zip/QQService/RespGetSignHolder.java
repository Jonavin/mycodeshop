package QQService;

public final class RespGetSignHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespGetSignHolder
 * JD-Core Version:    0.5.4
 */