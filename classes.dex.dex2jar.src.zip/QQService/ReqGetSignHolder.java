package QQService;

public final class ReqGetSignHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqGetSignHolder
 * JD-Core Version:    0.5.4
 */