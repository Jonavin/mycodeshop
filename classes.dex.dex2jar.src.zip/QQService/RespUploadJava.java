package QQService;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class RespUploadJava extends JceStruct
{
  static byte[] cache_strFlieKey;
  static byte[] cache_strFliePath;
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte[] a;
  public byte b;
  public long b;
  public String b;
  public byte[] b;
  public long c = 0L;

  static
  {
    if (!RespUploadJava.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RespUploadJava()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_Byte = null;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_b_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSumCmd");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "lReplyCode");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strResult");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUploadIP");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shUploadPort");
    byte[] arrayOfByte1 = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte1, "strFliePath");
    byte[] arrayOfByte2 = this.jdField_b_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte2, "strFlieKey");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cFileExist");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lPackSize");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lReserve");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strReserve");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (RespUploadJava)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b3 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b3);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str1 = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str1);
        if (localObject1 != 0)
        {
          long l1 = this.jdField_a_of_type_Long;
          long l2 = paramObject.jdField_a_of_type_Long;
          localObject1 = JceUtil.equals(l1, l2);
          if (localObject1 != 0)
          {
            short s1 = this.jdField_a_of_type_Short;
            short s2 = paramObject.jdField_a_of_type_Short;
            boolean bool3 = JceUtil.equals(s1, s2);
            if (bool3)
            {
              Object localObject2 = this.jdField_a_of_type_ArrayOfByte;
              byte[] arrayOfByte1 = paramObject.jdField_a_of_type_ArrayOfByte;
              localObject2 = JceUtil.equals(localObject2, arrayOfByte1);
              if (localObject2 != 0)
              {
                localObject2 = this.jdField_b_of_type_ArrayOfByte;
                byte[] arrayOfByte2 = paramObject.jdField_b_of_type_ArrayOfByte;
                localObject2 = JceUtil.equals(localObject2, arrayOfByte2);
                if (localObject2 != 0)
                {
                  byte b2 = this.jdField_b_of_type_Byte;
                  byte b4 = paramObject.jdField_b_of_type_Byte;
                  boolean bool4 = JceUtil.equals(b2, b4);
                  if (bool4)
                  {
                    l1 = this.jdField_b_of_type_Long;
                    long l3 = paramObject.jdField_b_of_type_Long;
                    bool4 = JceUtil.equals(l1, l3);
                    if (bool4)
                    {
                      l1 = this.c;
                      long l4 = paramObject.c;
                      bool4 = JceUtil.equals(l1, l4);
                      if (bool4)
                      {
                        Object localObject3 = this.jdField_b_of_type_JavaLangString;
                        String str2 = paramObject.jdField_b_of_type_JavaLangString;
                        localObject3 = JceUtil.equals(localObject3, str2);
                        if (localObject3 != 0)
                          j = 1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject4 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, j);
    this.jdField_a_of_type_Byte = b2;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, j, j);
    this.jdField_a_of_type_Int = l;
    String str1 = paramJceInputStream.readString(2, j);
    this.jdField_a_of_type_JavaLangString = str1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 3, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 4, j);
    this.jdField_a_of_type_Short = s2;
    if (cache_strFliePath == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_strFliePath = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_strFliePath;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 5, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
    if (cache_strFlieKey == null)
    {
      byte[] arrayOfByte4 = (byte[])new byte[j];
      cache_strFlieKey = arrayOfByte4;
      ((byte[])arrayOfByte4)[i] = i;
    }
    byte[] arrayOfByte5 = cache_strFlieKey;
    byte[] arrayOfByte6 = (byte[])paramJceInputStream.read(arrayOfByte5, 6, j);
    this.jdField_b_of_type_ArrayOfByte = arrayOfByte6;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 7, j);
    this.jdField_b_of_type_Byte = b4;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 8, j);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 9, j);
    Object localObject3;
    this.c = localObject3;
    String str2 = paramJceInputStream.readString(10, j);
    this.jdField_b_of_type_JavaLangString = str2;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 3);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 4);
    byte[] arrayOfByte1 = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte1, 5);
    byte[] arrayOfByte2 = this.jdField_b_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte2, 6);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 7);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 8);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 9);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 10);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespUploadJava
 * JD-Core Version:    0.5.4
 */