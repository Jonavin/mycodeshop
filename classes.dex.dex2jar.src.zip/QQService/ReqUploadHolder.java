package QQService;

public final class ReqUploadHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqUploadHolder
 * JD-Core Version:    0.5.4
 */