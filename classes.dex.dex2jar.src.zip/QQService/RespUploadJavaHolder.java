package QQService;

public final class RespUploadJavaHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespUploadJavaHolder
 * JD-Core Version:    0.5.4
 */