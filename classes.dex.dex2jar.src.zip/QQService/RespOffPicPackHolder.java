package QQService;

public final class RespOffPicPackHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespOffPicPackHolder
 * JD-Core Version:    0.5.4
 */