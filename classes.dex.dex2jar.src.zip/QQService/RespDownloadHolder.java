package QQService;

public final class RespDownloadHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespDownloadHolder
 * JD-Core Version:    0.5.4
 */