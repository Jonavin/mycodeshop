package QQService;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class RespDownload extends JceStruct
{
  static byte[] cache_vFileMD5;
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte[] a;
  public long b;
  public String b;
  public String c = "";

  static
  {
    if (!RespDownload.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RespDownload()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Short = null;
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_a_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_Long = 0L;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSumCmd");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "lReplyCode");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strResult");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lDownloadIP");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shDownloadPort");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strDownloadURL");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vFileMD5");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lReserve");
    String str3 = this.c;
    localJceDisplayer.display(str3, "strReserve");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (RespDownload)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramObject.jdField_a_of_type_Byte;
    boolean bool1 = JceUtil.equals(b1, b2);
    int j;
    if (bool1)
    {
      int i = this.jdField_a_of_type_Int;
      int k = paramObject.jdField_a_of_type_Int;
      boolean bool2 = JceUtil.equals(i, k);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str1 = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str1);
        if (localObject1 != 0)
        {
          long l1 = this.jdField_a_of_type_Long;
          long l2 = paramObject.jdField_a_of_type_Long;
          localObject1 = JceUtil.equals(l1, l2);
          if (localObject1 != 0)
          {
            short s1 = this.jdField_a_of_type_Short;
            short s2 = paramObject.jdField_a_of_type_Short;
            boolean bool3 = JceUtil.equals(s1, s2);
            if (bool3)
            {
              Object localObject2 = this.jdField_b_of_type_JavaLangString;
              String str2 = paramObject.jdField_b_of_type_JavaLangString;
              localObject2 = JceUtil.equals(localObject2, str2);
              if (localObject2 != 0)
              {
                localObject2 = this.jdField_a_of_type_ArrayOfByte;
                byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
                localObject2 = JceUtil.equals(localObject2, arrayOfByte);
                if (localObject2 != 0)
                {
                  l1 = this.jdField_b_of_type_Long;
                  long l3 = paramObject.jdField_b_of_type_Long;
                  localObject2 = JceUtil.equals(l1, l3);
                  if (localObject2 != 0)
                  {
                    localObject2 = this.c;
                    String str3 = paramObject.c;
                    localObject2 = JceUtil.equals(localObject2, str3);
                    if (localObject2 != 0)
                      j = 1;
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, j);
    this.jdField_a_of_type_Byte = b2;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, j, j);
    this.jdField_a_of_type_Int = l;
    String str1 = paramJceInputStream.readString(2, j);
    this.jdField_a_of_type_JavaLangString = str1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 3, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 4, j);
    this.jdField_a_of_type_Short = s2;
    String str2 = paramJceInputStream.readString(5, j);
    this.jdField_b_of_type_JavaLangString = str2;
    if (cache_vFileMD5 == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vFileMD5 = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vFileMD5;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 6, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 7, j);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    String str3 = paramJceInputStream.readString(8, j);
    this.c = str3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 3);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 4);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 5);
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 6);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 7);
    String str3 = this.c;
    paramJceOutputStream.write(str3, 8);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespDownload
 * JD-Core Version:    0.5.4
 */