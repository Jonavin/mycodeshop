package QQService;

public final class ReqOffFilePackHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqOffFilePackHolder
 * JD-Core Version:    0.5.4
 */