package QQService;

public final class ReqDownloadHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqDownloadHolder
 * JD-Core Version:    0.5.4
 */