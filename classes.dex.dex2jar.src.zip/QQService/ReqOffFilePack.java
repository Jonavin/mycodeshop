package QQService;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ReqOffFilePack extends JceStruct
{
  static byte[] cache_vBody;
  public long a;
  public byte[] a;

  static
  {
    if (!ReqOffFilePack.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ReqOffFilePack()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_ArrayOfByte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l, "lUIN");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vBody");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ReqOffFilePack)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool = JceUtil.equals(l1, l2);
    int i;
    if (bool)
    {
      Object localObject1 = this.jdField_a_of_type_ArrayOfByte;
      byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
      localObject1 = JceUtil.equals(localObject1, arrayOfByte);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject;
    this.jdField_a_of_type_Long = localObject;
    if (cache_vBody == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vBody = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vBody;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, j, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l, 0);
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqOffFilePack
 * JD-Core Version:    0.5.4
 */