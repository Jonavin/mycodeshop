package QQService;

public final class RespUploadHolder
{
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.RespUploadHolder
 * JD-Core Version:    0.5.4
 */