package QQService;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class ReqUpload extends JceStruct
{
  static byte[] cache_vFileMD5;
  public byte a;
  public long a;
  public String a;
  public byte[] a;
  public long b;
  public String b;
  public long c;
  public String c;
  public long d = 0L;
  public long e = 0L;
  public long f = 0L;
  public long g = 0L;

  static
  {
    if (!ReqUpload.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public ReqUpload()
  {
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_Long = 0L;
    this.jdField_b_of_type_Long = 0L;
    this.jdField_c_of_type_Long = 0L;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_a_of_type_ArrayOfByte = null;
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_c_of_type_JavaLangString = "";
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cSumCmd");
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lFromUIN");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lToUIN");
    long l3 = this.jdField_c_of_type_Long;
    localJceDisplayer.display(l3, "lFromVipLevel");
    long l4 = this.d;
    localJceDisplayer.display(l4, "lToVipLevel");
    long l5 = this.e;
    localJceDisplayer.display(l5, "lSeq");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strSession");
    long l6 = this.f;
    localJceDisplayer.display(l6, "lFileSize");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vFileMD5");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strFileName");
    long l7 = this.g;
    localJceDisplayer.display(l7, "lReserve");
    String str3 = this.jdField_c_of_type_JavaLangString;
    localJceDisplayer.display(str3, "strReserve");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (ReqUpload)paramObject;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramObject.jdField_a_of_type_Byte;
    boolean bool = JceUtil.equals(b1, b2);
    int i;
    if (bool)
    {
      long l1 = this.jdField_a_of_type_Long;
      long l2 = paramObject.jdField_a_of_type_Long;
      bool = JceUtil.equals(l1, l2);
      if (bool)
      {
        l1 = this.jdField_b_of_type_Long;
        long l3 = paramObject.jdField_b_of_type_Long;
        bool = JceUtil.equals(l1, l3);
        if (bool)
        {
          l1 = this.jdField_c_of_type_Long;
          long l4 = paramObject.jdField_c_of_type_Long;
          bool = JceUtil.equals(l1, l4);
          if (bool)
          {
            l1 = this.d;
            long l5 = paramObject.d;
            bool = JceUtil.equals(l1, l5);
            if (bool)
            {
              l1 = this.e;
              long l6 = paramObject.e;
              bool = JceUtil.equals(l1, l6);
              if (bool)
              {
                Object localObject1 = this.jdField_a_of_type_JavaLangString;
                String str1 = paramObject.jdField_a_of_type_JavaLangString;
                localObject1 = JceUtil.equals(localObject1, str1);
                if (localObject1 != 0)
                {
                  l1 = this.f;
                  long l7 = paramObject.f;
                  localObject1 = JceUtil.equals(l1, l7);
                  if (localObject1 != 0)
                  {
                    localObject1 = this.jdField_a_of_type_ArrayOfByte;
                    byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
                    localObject1 = JceUtil.equals(localObject1, arrayOfByte);
                    if (localObject1 != 0)
                    {
                      localObject1 = this.jdField_b_of_type_JavaLangString;
                      String str2 = paramObject.jdField_b_of_type_JavaLangString;
                      localObject1 = JceUtil.equals(localObject1, str2);
                      if (localObject1 != 0)
                      {
                        l1 = this.g;
                        long l8 = paramObject.g;
                        localObject1 = JceUtil.equals(l1, l8);
                        if (localObject1 != 0)
                        {
                          localObject1 = this.jdField_c_of_type_JavaLangString;
                          String str3 = paramObject.jdField_c_of_type_JavaLangString;
                          localObject1 = JceUtil.equals(localObject1, str3);
                          if (localObject1 != 0)
                            i = 1;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, i, j);
    this.jdField_a_of_type_Byte = b2;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, j, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 2, j);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.jdField_c_of_type_Long;
    long l6 = paramJceInputStream.read(l5, 3, j);
    Object localObject3;
    this.jdField_c_of_type_Long = localObject3;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 4, j);
    Object localObject4;
    this.d = localObject4;
    long l9 = this.e;
    long l10 = paramJceInputStream.read(l9, 5, j);
    Object localObject5;
    this.e = localObject5;
    String str1 = paramJceInputStream.readString(6, j);
    this.jdField_a_of_type_JavaLangString = str1;
    long l11 = this.f;
    long l12 = paramJceInputStream.read(l11, 7, j);
    Object localObject6;
    this.f = localObject6;
    if (cache_vFileMD5 == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vFileMD5 = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vFileMD5;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 8, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
    String str2 = paramJceInputStream.readString(9, j);
    this.jdField_b_of_type_JavaLangString = str2;
    long l13 = this.g;
    long l14 = paramJceInputStream.read(l13, 10, j);
    Object localObject7;
    this.g = localObject7;
    String str3 = paramJceInputStream.readString(11, j);
    this.jdField_c_of_type_JavaLangString = str3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 0);
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 1);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 2);
    long l3 = this.jdField_c_of_type_Long;
    paramJceOutputStream.write(l3, 3);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 4);
    long l5 = this.e;
    paramJceOutputStream.write(l5, 5);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 6);
    long l6 = this.f;
    paramJceOutputStream.write(l6, 7);
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 8);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 9);
    long l7 = this.g;
    paramJceOutputStream.write(l7, 10);
    String str3 = this.jdField_c_of_type_JavaLangString;
    paramJceOutputStream.write(str3, 11);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     QQService.ReqUpload
 * JD-Core Version:    0.5.4
 */