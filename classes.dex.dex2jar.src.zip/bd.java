import android.view.View;
import android.view.View.OnLongClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bd
  implements View.OnLongClickListener
{
  public bd(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final boolean onLongClick(View paramView)
  {
    this.a.b();
    return null;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bd
 * JD-Core Version:    0.5.4
 */