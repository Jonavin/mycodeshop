import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.video.VideoChatSettings;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.qphone.base.util.BaseActionListener;

public final class al extends Thread
{
  public al(ChatVideoActivity paramChatVideoActivity, FrameLayout paramFrameLayout1, FrameLayout paramFrameLayout2)
  {
  }

  public final void run()
  {
    ChatVideoActivity localChatVideoActivity1 = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity;
    Bitmap localBitmap1 = BitmapFactory.decodeResource(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity.getResources(), 2130838073);
    ChatVideoActivity.access$902(localChatVideoActivity1, localBitmap1);
    ChatVideoActivity localChatVideoActivity2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity;
    Bitmap localBitmap2 = BitmapFactory.decodeResource(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity.getResources(), 2130838070);
    ChatVideoActivity.access$1002(localChatVideoActivity2, localBitmap2);
    ChatVideoActivity.access$1100(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    LinearLayout localLinearLayout1 = ChatVideoActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    am localam = new am(this);
    localLinearLayout1.setOnClickListener(localam);
    ChatVideoActivity.access$1300(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setClickable(null);
    LinearLayout localLinearLayout2 = ChatVideoActivity.access$1500(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    an localan = new an(this);
    localLinearLayout2.setOnClickListener(localan);
    FrameLayout localFrameLayout = ChatVideoActivity.access$2100(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    ao localao = new ao(this);
    localFrameLayout.setOnClickListener(localao);
    ChatVideoActivity.access$2100(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).setClickable(null);
    Chronometer localChronometer = ChatVideoActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    ap localap = new ap(this);
    localChronometer.setOnChronometerTickListener(localap);
    ChatVideoActivity.access$000(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity).a();
    QQApplication localQQApplication = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity.a;
    BaseActionListener localBaseActionListener = ChatVideoActivity.access$2300(this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity);
    localQQApplication.a(localBaseActionListener);
    ChatVideoActivity localChatVideoActivity3 = this.jdField_a_of_type_ComTencentMobileqqActivityChatVideoActivity;
    int i = VideoChatSettings.getWidth();
    int j = VideoChatSettings.getHeight();
    Bitmap.Config localConfig = Bitmap.Config.RGB_565;
    Bitmap localBitmap3 = Bitmap.createBitmap(i, j, localConfig);
    ChatVideoActivity.access$302(localChatVideoActivity3, localBitmap3);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     al
 * JD-Core Version:    0.5.4
 */