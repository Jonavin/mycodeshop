import android.widget.Toast;

final class cn
  implements Runnable
{
  cn(ch paramch)
  {
  }

  public final void run()
  {
    Toast.makeText(this.a.a, 2131296307, 0).show();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cn
 * JD-Core Version:    0.5.4
 */