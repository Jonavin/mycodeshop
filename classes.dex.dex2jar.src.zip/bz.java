import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bz extends BaseAdapter
{
  private Context jdField_a_of_type_AndroidContentContext;
  private Integer[] jdField_a_of_type_ArrayOfJavaLangInteger;

  public bz(ChatWindowActivity paramChatWindowActivity, Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    Integer[] arrayOfInteger1 = new Integer[108];
    this.jdField_a_of_type_ArrayOfJavaLangInteger = arrayOfInteger1;
    for (int i = 0; i < 107; ++i)
    {
      Integer[] arrayOfInteger2 = this.jdField_a_of_type_ArrayOfJavaLangInteger;
      Integer localInteger1 = Integer.valueOf(2130837619 + i);
      arrayOfInteger2[i] = localInteger1;
    }
    Integer[] arrayOfInteger3 = this.jdField_a_of_type_ArrayOfJavaLangInteger;
    Integer localInteger2 = Integer.valueOf(2130838082);
    arrayOfInteger3[i] = localInteger2;
  }

  public final int getCount()
  {
    return this.jdField_a_of_type_ArrayOfJavaLangInteger.length;
  }

  public final Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public final long getItemId(int paramInt)
  {
    return paramInt;
  }

  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ImageView localImageView;
    if (paramView == null)
    {
      StateListDrawable localStateListDrawable = (StateListDrawable)this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getDrawable(2130837552);
      localObject = this.jdField_a_of_type_AndroidContentContext;
      localImageView = new ImageView((Context)localObject);
      int i = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int j = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      localObject = new AbsListView.LayoutParams(i, j);
      localImageView.setLayoutParams((ViewGroup.LayoutParams)localObject);
      localObject = ChatWindowActivity.access$3600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int k = ChatWindowActivity.access$3600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int l = ChatWindowActivity.access$3600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i1 = ChatWindowActivity.access$3600(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      localImageView.setPadding(localObject, k, l, i1);
      localImageView.setAdjustViewBounds(null);
      localObject = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i2 = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      Bitmap.Config localConfig = Bitmap.Config.ARGB_8888;
      Bitmap localBitmap = Bitmap.createBitmap(localObject, i2, localConfig);
      localObject = new Canvas(localBitmap);
      Paint localPaint = new Paint(1);
      int i3 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getColor(2131230762);
      localPaint.setColor(i3);
      int i4 = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i5 = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      Rect localRect = new Rect(0, 0, i4, i5);
      ((Canvas)localObject).drawRect(localRect, localPaint);
      int i6 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getColor(2131230761);
      localPaint.setColor(i6);
      float f1 = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f2 = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f3 = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ((Canvas)localObject).drawLine(null, f1, f2, f3, localPaint);
      float f4 = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f5 = ChatWindowActivity.access$3400(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f6 = ChatWindowActivity.access$3500(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ((Canvas)localObject).drawLine(f4, null, f5, f6, localPaint);
      localObject = new int[1];
      localObject[0] = 16842910;
      BitmapDrawable localBitmapDrawable = new BitmapDrawable(localBitmap);
      localStateListDrawable.addState(localObject, localBitmapDrawable);
      localImageView.setBackgroundDrawable(localStateListDrawable);
    }
    for (Object localObject = localImageView; ; localObject = (ImageView)paramView)
    {
      int i7 = this.jdField_a_of_type_ArrayOfJavaLangInteger[paramInt].intValue();
      ((ImageView)localObject).setImageResource(i7);
      return localObject;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bz
 * JD-Core Version:    0.5.4
 */