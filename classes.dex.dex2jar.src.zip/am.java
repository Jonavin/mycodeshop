import android.view.SurfaceHolder;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.video.VcCamera;
import com.tencent.mobileqq.video.VideoController;
import com.tencent.mobileqq.video.surfaceview.Preview;

final class am
  implements View.OnClickListener
{
  am(al paramal)
  {
  }

  public final void onClick(View paramView)
  {
    VcCamera localVcCamera = ChatVideoActivity.access$000(this.a.a).a();
    if (!localVcCamera.a())
      return;
    SurfaceHolder localSurfaceHolder = ChatVideoActivity.access$1200(this.a.a).getHolder();
    localVcCamera.a(localSurfaceHolder);
    localVcCamera.c();
    localVcCamera.b();
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     am
 * JD-Core Version:    0.5.4
 */