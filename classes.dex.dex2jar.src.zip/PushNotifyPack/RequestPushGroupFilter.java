package PushNotifyPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class RequestPushGroupFilter extends JceStruct
{
  public byte a;
  public long a;
  public String a;
  public long b;
  public String b;
  public long c = 0L;
  public long d = 0L;

  static
  {
    if (!RequestPushGroupFilter.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RequestPushGroupFilter()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_b_of_type_Long = 0L;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cType");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strService");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strCmd");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lGroupCode");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lGroupUin");
    long l4 = this.d;
    localJceDisplayer.display(l4, "cMsgMask");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (RequestPushGroupFilter)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int i;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b2 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b2);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str1 = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str1);
        if (localObject1 != 0)
        {
          localObject1 = this.jdField_b_of_type_JavaLangString;
          String str2 = paramObject.jdField_b_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str2);
          if (localObject1 != 0)
          {
            l1 = this.jdField_b_of_type_Long;
            long l3 = paramObject.jdField_b_of_type_Long;
            localObject1 = JceUtil.equals(l1, l3);
            if (localObject1 != 0)
            {
              l1 = this.c;
              long l4 = paramObject.c;
              localObject1 = JceUtil.equals(l1, l4);
              if (localObject1 != 0)
              {
                l1 = this.d;
                long l5 = paramObject.d;
                localObject1 = JceUtil.equals(l1, l5);
                if (localObject1 != 0)
                  i = 1;
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, 0, true);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, 1, true);
    this.jdField_a_of_type_Byte = b2;
    String str1 = paramJceInputStream.readString(2, true);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(3, true);
    this.jdField_b_of_type_JavaLangString = str2;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 4, true);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 5, true);
    Object localObject3;
    this.c = localObject3;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 6, true);
    Object localObject4;
    this.d = localObject4;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 3);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 4);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 5);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 6);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     PushNotifyPack.RequestPushGroupFilter
 * JD-Core Version:    0.5.4
 */