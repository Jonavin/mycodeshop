package PushNotifyPack;

import com.qq.taf.jce.JceDisplayer;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.qq.taf.jce.JceStruct;
import com.qq.taf.jce.JceUtil;

public final class RequestPushGroupMsg extends JceStruct
{
  static byte[] cache_vMsg;
  public byte a;
  public int a;
  public long a;
  public String a;
  public short a;
  public byte[] a;
  public byte b;
  public long b;
  public String b;
  public long c = 0L;
  public long d = 0L;
  public long e = 0L;

  static
  {
    if (!RequestPushGroupMsg.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = $assertionsDisabled;
      return;
    }
  }

  public RequestPushGroupMsg()
  {
    this.jdField_a_of_type_Long = 0L;
    this.jdField_a_of_type_Byte = null;
    this.jdField_a_of_type_JavaLangString = "";
    this.jdField_b_of_type_JavaLangString = "";
    this.jdField_b_of_type_Long = 0L;
    this.jdField_b_of_type_Byte = null;
    this.jdField_a_of_type_Int = null;
    this.jdField_a_of_type_Short = null;
    this.jdField_a_of_type_ArrayOfByte = null;
  }

  public final Object clone()
  {
    int i = 0;
    try
    {
      Object localObject = super.clone();
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      $assertionsDisabled = localCloneNotSupportedException;
      if (localCloneNotSupportedException == null);
      throw new AssertionError();
    }
  }

  public final void display(StringBuilder paramStringBuilder, int paramInt)
  {
    JceDisplayer localJceDisplayer = new JceDisplayer(paramStringBuilder, paramInt);
    long l1 = this.jdField_a_of_type_Long;
    localJceDisplayer.display(l1, "lUin");
    byte b1 = this.jdField_a_of_type_Byte;
    localJceDisplayer.display(b1, "cType");
    String str1 = this.jdField_a_of_type_JavaLangString;
    localJceDisplayer.display(str1, "strService");
    String str2 = this.jdField_b_of_type_JavaLangString;
    localJceDisplayer.display(str2, "strCmd");
    long l2 = this.jdField_b_of_type_Long;
    localJceDisplayer.display(l2, "lGroupCode");
    byte b2 = this.jdField_b_of_type_Byte;
    localJceDisplayer.display(b2, "cGroupType");
    long l3 = this.c;
    localJceDisplayer.display(l3, "lSendUin");
    long l4 = this.d;
    localJceDisplayer.display(l4, "lsMsgSeq");
    int i = this.jdField_a_of_type_Int;
    localJceDisplayer.display(i, "uMsgTime");
    long l5 = this.e;
    localJceDisplayer.display(l5, "lInfoSeq");
    short s = this.jdField_a_of_type_Short;
    localJceDisplayer.display(s, "shMsgLen");
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    localJceDisplayer.display(arrayOfByte, "vMsg");
  }

  public final boolean equals(Object paramObject)
  {
    paramObject = (RequestPushGroupMsg)paramObject;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramObject.jdField_a_of_type_Long;
    boolean bool1 = JceUtil.equals(l1, l2);
    int j;
    if (bool1)
    {
      byte b1 = this.jdField_a_of_type_Byte;
      byte b3 = paramObject.jdField_a_of_type_Byte;
      boolean bool2 = JceUtil.equals(b1, b3);
      if (bool2)
      {
        Object localObject1 = this.jdField_a_of_type_JavaLangString;
        String str1 = paramObject.jdField_a_of_type_JavaLangString;
        localObject1 = JceUtil.equals(localObject1, str1);
        if (localObject1 != 0)
        {
          localObject1 = this.jdField_b_of_type_JavaLangString;
          String str2 = paramObject.jdField_b_of_type_JavaLangString;
          localObject1 = JceUtil.equals(localObject1, str2);
          if (localObject1 != 0)
          {
            l1 = this.jdField_b_of_type_Long;
            long l3 = paramObject.jdField_b_of_type_Long;
            localObject1 = JceUtil.equals(l1, l3);
            if (localObject1 != 0)
            {
              byte b2 = this.jdField_b_of_type_Byte;
              byte b4 = paramObject.jdField_b_of_type_Byte;
              boolean bool3 = JceUtil.equals(b2, b4);
              if (bool3)
              {
                l1 = this.c;
                long l4 = paramObject.c;
                bool3 = JceUtil.equals(l1, l4);
                if (bool3)
                {
                  l1 = this.d;
                  long l5 = paramObject.d;
                  bool3 = JceUtil.equals(l1, l5);
                  if (bool3)
                  {
                    int i = this.jdField_a_of_type_Int;
                    int k = paramObject.jdField_a_of_type_Int;
                    boolean bool4 = JceUtil.equals(i, k);
                    if (bool4)
                    {
                      l1 = this.e;
                      long l6 = paramObject.e;
                      bool4 = JceUtil.equals(l1, l6);
                      if (bool4)
                      {
                        short s1 = this.jdField_a_of_type_Short;
                        short s2 = paramObject.jdField_a_of_type_Short;
                        boolean bool5 = JceUtil.equals(s1, s2);
                        if (bool5)
                        {
                          Object localObject2 = this.jdField_a_of_type_ArrayOfByte;
                          byte[] arrayOfByte = paramObject.jdField_a_of_type_ArrayOfByte;
                          localObject2 = JceUtil.equals(localObject2, arrayOfByte);
                          if (localObject2 != 0)
                            j = 1;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    while (true)
    {
      return j;
      Object localObject3 = null;
    }
  }

  public final void readFrom(JceInputStream paramJceInputStream)
  {
    int i = null;
    int j = 1;
    long l1 = this.jdField_a_of_type_Long;
    long l2 = paramJceInputStream.read(l1, i, j);
    Object localObject1;
    this.jdField_a_of_type_Long = localObject1;
    byte b1 = this.jdField_a_of_type_Byte;
    byte b2 = paramJceInputStream.read(b1, j, j);
    this.jdField_a_of_type_Byte = b2;
    String str1 = paramJceInputStream.readString(2, j);
    this.jdField_a_of_type_JavaLangString = str1;
    String str2 = paramJceInputStream.readString(3, j);
    this.jdField_b_of_type_JavaLangString = str2;
    long l3 = this.jdField_b_of_type_Long;
    long l4 = paramJceInputStream.read(l3, 4, j);
    Object localObject2;
    this.jdField_b_of_type_Long = localObject2;
    byte b3 = this.jdField_b_of_type_Byte;
    byte b4 = paramJceInputStream.read(b3, 5, j);
    this.jdField_b_of_type_Byte = b4;
    long l5 = this.c;
    long l6 = paramJceInputStream.read(l5, 6, j);
    Object localObject3;
    this.c = localObject3;
    long l7 = this.d;
    long l8 = paramJceInputStream.read(l7, 7, j);
    Object localObject4;
    this.d = localObject4;
    int k = this.jdField_a_of_type_Int;
    int l = paramJceInputStream.read(k, 8, j);
    this.jdField_a_of_type_Int = l;
    long l9 = this.e;
    long l10 = paramJceInputStream.read(l9, 9, j);
    Object localObject5;
    this.e = localObject5;
    short s1 = this.jdField_a_of_type_Short;
    short s2 = paramJceInputStream.read(s1, 10, j);
    this.jdField_a_of_type_Short = s2;
    if (cache_vMsg == null)
    {
      byte[] arrayOfByte1 = (byte[])new byte[j];
      cache_vMsg = arrayOfByte1;
      ((byte[])arrayOfByte1)[i] = i;
    }
    byte[] arrayOfByte2 = cache_vMsg;
    byte[] arrayOfByte3 = (byte[])paramJceInputStream.read(arrayOfByte2, 11, j);
    this.jdField_a_of_type_ArrayOfByte = arrayOfByte3;
  }

  public final void writeTo(JceOutputStream paramJceOutputStream)
  {
    long l1 = this.jdField_a_of_type_Long;
    paramJceOutputStream.write(l1, 0);
    byte b1 = this.jdField_a_of_type_Byte;
    paramJceOutputStream.write(b1, 1);
    String str1 = this.jdField_a_of_type_JavaLangString;
    paramJceOutputStream.write(str1, 2);
    String str2 = this.jdField_b_of_type_JavaLangString;
    paramJceOutputStream.write(str2, 3);
    long l2 = this.jdField_b_of_type_Long;
    paramJceOutputStream.write(l2, 4);
    byte b2 = this.jdField_b_of_type_Byte;
    paramJceOutputStream.write(b2, 5);
    long l3 = this.c;
    paramJceOutputStream.write(l3, 6);
    long l4 = this.d;
    paramJceOutputStream.write(l4, 7);
    int i = this.jdField_a_of_type_Int;
    paramJceOutputStream.write(i, 8);
    long l5 = this.e;
    paramJceOutputStream.write(l5, 9);
    short s = this.jdField_a_of_type_Short;
    paramJceOutputStream.write(s, 10);
    byte[] arrayOfByte = this.jdField_a_of_type_ArrayOfByte;
    paramJceOutputStream.write(arrayOfByte, 11);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     PushNotifyPack.RequestPushGroupMsg
 * JD-Core Version:    0.5.4
 */