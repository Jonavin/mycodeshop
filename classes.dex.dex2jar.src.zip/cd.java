import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.CustomEmotionData;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.mobileqq.utils.ImageUtil;
import com.tencent.qphone.base.util.BaseApplication;
import java.io.File;
import java.util.List;

public final class cd extends BaseAdapter
{
  private Context jdField_a_of_type_AndroidContentContext;
  private String[] jdField_a_of_type_ArrayOfJavaLangString;

  public cd(ChatWindowActivity paramChatWindowActivity, Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    EntityManager localEntityManager = QQApplication.createEntityManagerFactory(paramChatWindowActivity.a.a).createEntityManager();
    String str2 = str1;
    String str3 = str1;
    String str4 = str1;
    List localList = localEntityManager.a(CustomEmotionData.class, str1, str2, str3, str4);
    localEntityManager.a();
    String[] arrayOfString1 = new String[i];
    this.jdField_a_of_type_ArrayOfJavaLangString = arrayOfString1;
    int j = 0;
    if (j >= i)
      label84: return;
    if (localList != null)
    {
      int k = localList.size();
      if (j < k)
        break label129;
    }
    this.jdField_a_of_type_ArrayOfJavaLangString[j] = str1;
    while (true)
    {
      j += 1;
      break label84:
      label129: String[] arrayOfString2 = this.jdField_a_of_type_ArrayOfJavaLangString;
      String str5 = ((CustomEmotionData)localList.get(j)).emoPath;
      arrayOfString2[j] = str5;
    }
  }

  public final int getCount()
  {
    return this.jdField_a_of_type_ArrayOfJavaLangString.length;
  }

  public final Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public final long getItemId(int paramInt)
  {
    return paramInt;
  }

  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Object localObject1;
    Object localObject3;
    if (paramView == null)
    {
      StateListDrawable localStateListDrawable = (StateListDrawable)this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getDrawable(2130837552);
      localObject1 = this.jdField_a_of_type_AndroidContentContext;
      ImageView localImageView = new ImageView((Context)localObject1);
      int i = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int j = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      localObject1 = new AbsListView.LayoutParams(i, j);
      localImageView.setLayoutParams((ViewGroup.LayoutParams)localObject1);
      localImageView.setPadding(2, 2, 2, 2);
      localImageView.setAdjustViewBounds(null);
      localObject1 = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      i = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      Bitmap.Config localConfig = Bitmap.Config.ARGB_8888;
      Bitmap localBitmap = Bitmap.createBitmap(localObject1, i, localConfig);
      localObject1 = new Canvas(localBitmap);
      Paint localPaint = new Paint(1);
      i = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getColor(2131230762);
      localPaint.setColor(i);
      int l = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      int i1 = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      Object localObject2 = new Rect(0, 0, l, i1);
      ((Canvas)localObject1).drawRect((Rect)localObject2, localPaint);
      localObject2 = this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity.getResources().getColor(2131230761);
      localPaint.setColor(localObject2);
      float f2 = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f3 = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f4 = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ((Canvas)localObject1).drawLine(null, f2, f3, f4, localPaint);
      float f1 = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f5 = ChatWindowActivity.access$3700(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      float f6 = ChatWindowActivity.access$3800(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      ((Canvas)localObject1).drawLine(f1, null, f5, f6, localPaint);
      localObject1 = new int[1];
      int k = 16842910;
      localObject1[0] = k;
      localObject3 = new BitmapDrawable(localBitmap);
      localStateListDrawable.addState(localObject1, (Drawable)localObject3);
      localImageView.setBackgroundDrawable(localStateListDrawable);
      localObject1 = localImageView;
      label364: localObject3 = ChatWindowActivity.access$3900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      if (paramInt <= localObject3)
        break label411;
      localObject3 = this.jdField_a_of_type_ArrayOfJavaLangString[paramInt];
      if (localObject3 != null)
        break label411;
      ((ImageView)localObject1).setImageResource(2130838082);
    }
    while (true)
    {
      return localObject1;
      localObject1 = (ImageView)paramView;
      break label364:
      label411: localObject3 = ChatWindowActivity.access$3900(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
      if (paramInt == localObject3)
      {
        ((ImageView)localObject1).setImageResource(2130837509);
        float f7 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        int i2 = (int)(1097859072 * f7);
        float f8 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        int i3 = (int)(1101004800 * f8);
        float f9 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        int i4 = (int)(1097859072 * f9);
        float f10 = ChatWindowActivity.access$2200(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity);
        int i5 = (int)(1101004800 * f10);
        ((ImageView)localObject1).setPadding(i2, i3, i4, i5);
      }
      localObject3 = this.jdField_a_of_type_ArrayOfJavaLangString[paramInt];
      Object localObject4 = Uri.parse((String)localObject3);
      localObject4 = ImageUtil.getThumbPath(this.jdField_a_of_type_ComTencentMobileqqActivityChatWindowActivity, (Uri)localObject4);
      if (!new File((String)localObject4).exists())
        ImageUtil.compressImagetoSize(BaseApplication.getContext(), (String)localObject3, (String)localObject4, 240, 180);
      Uri localUri = Uri.parse((String)localObject4);
      ((ImageView)localObject1).setImageURI(localUri);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     cd
 * JD-Core Version:    0.5.4
 */