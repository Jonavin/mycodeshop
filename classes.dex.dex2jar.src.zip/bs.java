import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ChatWindowActivity.UpdataPlayPttStateListener;
import com.tencent.mobileqq.adapter.ChatMessageListAdapter;

public final class bs
  implements ChatWindowActivity.UpdataPlayPttStateListener
{
  public bs(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void a()
  {
    if (this.a.c.length() > 0)
      ChatWindowActivity.access$100(this.a).notifyDataSetChanged();
    ChatWindowActivity.access$202(this.a, null);
    this.a.c = "";
    ChatWindowActivity.access$302(this.a, -1);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bs
 * JD-Core Version:    0.5.4
 */