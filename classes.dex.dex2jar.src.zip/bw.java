import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bw
  implements View.OnClickListener
{
  public bw(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity.access$700(this.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bw
 * JD-Core Version:    0.5.4
 */