import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.video.VideoController;

public final class by
  implements View.OnClickListener
{
  public by(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    Object localObject1 = 1;
    boolean bool1 = ChatWindowActivity.access$1000(this.a);
    ChatWindowActivity localChatWindowActivity;
    Object localObject2;
    label82: Object localObject4;
    if (bool1)
    {
      localChatWindowActivity = this.a;
      boolean bool2 = ChatVideoActivity.checkVersion();
      if (bool2)
        break label255;
      localObject2 = new AlertDialog.Builder(localChatWindowActivity).setTitle(2131296443);
      String str1 = localChatWindowActivity.getString(2131296444);
      localObject2 = ((AlertDialog.Builder)localObject2).setMessage(str1);
      Object localObject3 = null;
      ((AlertDialog.Builder)localObject2).setNegativeButton(2131296271, (DialogInterface.OnClickListener)localObject3).create().show();
      localObject2 = null;
      if (localObject2 != null)
      {
        this = (ConnectivityManager)localChatWindowActivity.getSystemService("connectivity");
        localObject2 = super.getActiveNetworkInfo();
        if (localObject2 != null)
        {
          localObject2 = ((NetworkInfo)localObject2).getType();
          if (localObject2 == localObject1)
          {
            localObject2 = "wifi";
            this = (WifiManager)localChatWindowActivity.getSystemService((String)localObject2);
            if (this != null)
            {
              localObject2 = super.createWifiLock(localObject1, "video wifi lock");
              localChatWindowActivity.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock = ((WifiManager.WifiLock)localObject2);
              localObject2 = localChatWindowActivity.jdField_a_of_type_AndroidNetWifiWifiManager$WifiLock;
              ((WifiManager.WifiLock)localObject2).acquire();
            }
          }
        }
        localObject2 = Long.parseLong(localChatWindowActivity.jdField_a_of_type_JavaLangString);
        localObject3 = localChatWindowActivity.jdField_a_of_type_ComTencentMobileqqVideoVideoController;
        if (localObject3 == null)
          break label261;
        localObject3 = localChatWindowActivity.jdField_a_of_type_ComTencentMobileqqVideoVideoController.a(localObject4);
        switch (localObject3)
        {
        case 0:
        default:
          label196: Intent localIntent = new Intent(localChatWindowActivity, ChatVideoActivity.class);
          localIntent.putExtra("UID", localObject4);
          localChatWindowActivity.startActivityForResult(localIntent, 20);
        case -1:
        case -2:
        }
      }
    }
    while (true)
    {
      return;
      label255: localObject2 = localObject1;
      break label82:
      label261: int i = -1;
      break label196:
      String str2 = localChatWindowActivity.getString(2131296454);
      VideoController.addVideoMsg(localObject4, localChatWindowActivity);
      continue;
      String str3 = localChatWindowActivity.getString(2131296438);
      VideoController.addVideoMsg(localObject4, localChatWindowActivity);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     by
 * JD-Core Version:    0.5.4
 */