import android.os.Handler;
import android.os.Message;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.data.Friends;
import com.tencent.mobileqq.persistence.EntityManager;
import com.tencent.mobileqq.persistence.EntityManagerFactory;
import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.util.BaseActionListener;

public final class bm extends BaseActionListener
{
  public bm(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onActionResult(FromServiceMsg paramFromServiceMsg)
  {
    int i = paramFromServiceMsg.resultCode;
    if (i != 1000);
    while (true)
    {
      return;
      boolean bool = paramFromServiceMsg.serviceCmd.equals("MessageSvc.PushGroupMsg");
      if (!bool)
      {
        bool = paramFromServiceMsg.serviceCmd.equals("MessageSvc.GetGroupMsg");
        if (!bool)
        {
          bool = paramFromServiceMsg.serviceCmd.equals("MessageSvc.getmsg");
          if (!bool)
            break label78;
        }
      }
      Message localMessage = ChatWindowActivity.access$1900(this.a).obtainMessage(1);
      ChatWindowActivity.access$4300(this.a, localMessage);
      continue;
      label78: bool = paramFromServiceMsg.serviceCmd.equals("CImgService.GetUserDefineAvatar");
      if (bool)
      {
        int j = ChatWindowActivity.access$2100(this.a);
        if (j != 0)
          continue;
        EntityManager localEntityManager = this.a.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().createEntityManager();
        String str = this.a.jdField_a_of_type_JavaLangString;
        Friends localFriends = (Friends)localEntityManager.a(Friends.class, str);
        localEntityManager.a();
        if (localFriends == null)
          continue;
        ChatWindowActivity.access$1900(this.a).obtainMessage(4, localFriends).sendToTarget();
      }
      if (paramFromServiceMsg.serviceCmd.equals("friendlist.getTroopMemberList"))
      {
        ChatWindowActivity localChatWindowActivity = this.a;
        bn localbn = new bn(this);
        localChatWindowActivity.runOnUiThread(localbn);
      }
      if (!paramFromServiceMsg.serviceCmd.equals("MessageSvc.MsgSaved"))
        continue;
      ChatWindowActivity.access$1900(this.a).sendEmptyMessageDelayed(0, 0L);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bm
 * JD-Core Version:    0.5.4
 */