import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bu
  implements View.OnClickListener
{
  public bu(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void onClick(View paramView)
  {
    ChatWindowActivity.access$500(this.a, 2);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bu
 * JD-Core Version:    0.5.4
 */