import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import com.tencent.mobileqq.activity.AddFriendActivity;
import com.tencent.mobileqq.app.QQApplication;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class c extends SimpleAdapter
{
  c(b paramb, Context paramContext, List paramList1, String[] paramArrayOfString, int[] paramArrayOfInt, List paramList2, Set paramSet)
  {
  }

  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView = super.getView(paramInt, paramView, paramViewGroup);
    Button localButton = (Button)localView.findViewById(2131492877);
    String str = (String)((Map)this.jdField_a_of_type_JavaUtilList.get(paramInt)).get("uin");
    localButton.setTag(str);
    AddFriendActivity localAddFriendActivity = this.jdField_a_of_type_B.a.a;
    localButton.setOnClickListener(localAddFriendActivity);
    ImageView localImageView = (ImageView)localView.findViewById(2131492873);
    int i = Integer.parseInt((String)((Map)this.jdField_a_of_type_JavaUtilList.get(paramInt)).get("faceID"));
    QQApplication localQQApplication = this.jdField_a_of_type_B.a.a.a;
    boolean bool = this.jdField_a_of_type_JavaUtilSet.add(str);
    Drawable localDrawable = localQQApplication.a(i, str, true, bool);
    localImageView.setImageDrawable(localDrawable);
    return localView;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     c
 * JD-Core Version:    0.5.4
 */