import android.os.Handler;
import com.tencent.mobileqq.activity.ContactActivity;

final class co
  implements Runnable
{
  co(ch paramch)
  {
  }

  public final void run()
  {
    ContactActivity.access$300(this.a.a).removeMessages(1004);
    ContactActivity.access$300(this.a.a).sendEmptyMessageDelayed(1004, 500L);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     co
 * JD-Core Version:    0.5.4
 */