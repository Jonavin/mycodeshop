import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.app.QQApplication;

public final class bl
  implements Runnable
{
  public bl(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void run()
  {
    ChatWindowActivity localChatWindowActivity = this.a;
    String str1 = this.a.jdField_a_of_type_ComTencentMobileqqAppQQApplication.jdField_a_of_type_JavaLangString;
    String str2 = this.a.jdField_a_of_type_JavaLangString;
    int i = ChatWindowActivity.access$2100(this.a);
    localChatWindowActivity.a(str1, str2, i);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bl
 * JD-Core Version:    0.5.4
 */