import com.tencent.mobileqq.activity.ChatVideoActivity;

public final class ak extends Thread
{
  public ak(ChatVideoActivity paramChatVideoActivity)
  {
  }

  // ERROR //
  public final void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   4: astore_1
    //   5: aload_1
    //   6: invokestatic 22	com/tencent/mobileqq/activity/ChatVideoActivity:access$200	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Ljava/util/Vector;
    //   9: astore_2
    //   10: aload_2
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   16: invokestatic 22	com/tencent/mobileqq/activity/ChatVideoActivity:access$200	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Ljava/util/Vector;
    //   19: invokevirtual 28	java/util/Vector:isEmpty	()Z
    //   22: astore_1
    //   23: iload_1
    //   24: ifeq +6 -> 30
    //   27: aload_2
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   34: invokestatic 22	com/tencent/mobileqq/activity/ChatVideoActivity:access$200	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Ljava/util/Vector;
    //   37: iconst_0
    //   38: invokevirtual 32	java/util/Vector:get	(I)Ljava/lang/Object;
    //   41: checkcast 34	com/tencent/mobileqq/activity/ChatVideoActivity$DrawData
    //   44: astore_1
    //   45: aload_1
    //   46: getfield 37	com/tencent/mobileqq/activity/ChatVideoActivity$DrawData:jdField_a_of_type_ArrayOfByte	[B
    //   49: astore_3
    //   50: aload_1
    //   51: getfield 40	com/tencent/mobileqq/activity/ChatVideoActivity$DrawData:jdField_a_of_type_Int	I
    //   54: istore_1
    //   55: aload_0
    //   56: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   59: invokestatic 22	com/tencent/mobileqq/activity/ChatVideoActivity:access$200	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Ljava/util/Vector;
    //   62: iconst_0
    //   63: invokevirtual 43	java/util/Vector:remove	(I)Ljava/lang/Object;
    //   66: pop
    //   67: aload_2
    //   68: monitorexit
    //   69: aload_3
    //   70: ifnull -41 -> 29
    //   73: bipush 255
    //   75: istore_2
    //   76: iload_1
    //   77: iload_2
    //   78: if_icmpeq -49 -> 29
    //   81: aload_0
    //   82: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   85: invokestatic 47	com/tencent/mobileqq/activity/ChatVideoActivity:access$300	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Landroid/graphics/Bitmap;
    //   88: astore_2
    //   89: aload_2
    //   90: ifnull -61 -> 29
    //   93: aload_3
    //   94: ifnull -65 -> 29
    //   97: iload_1
    //   98: ifeq +176 -> 274
    //   101: aload_0
    //   102: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   105: invokestatic 51	com/tencent/mobileqq/activity/ChatVideoActivity:access$400	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)I
    //   108: astore_2
    //   109: aload_3
    //   110: arraylength
    //   111: istore 4
    //   113: iload_2
    //   114: iload 4
    //   116: if_icmpge +42 -> 158
    //   119: aload_0
    //   120: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   123: astore_2
    //   124: aload_3
    //   125: arraylength
    //   126: istore 5
    //   128: aload_2
    //   129: iload 5
    //   131: invokestatic 55	com/tencent/mobileqq/activity/ChatVideoActivity:access$402	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;I)I
    //   134: pop
    //   135: aload_0
    //   136: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   139: astore_2
    //   140: aload_0
    //   141: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   144: invokestatic 51	com/tencent/mobileqq/activity/ChatVideoActivity:access$400	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)I
    //   147: newarray byte
    //   149: astore 6
    //   151: aload_2
    //   152: aload 6
    //   154: invokestatic 59	com/tencent/mobileqq/activity/ChatVideoActivity:access$502	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;[B)[B
    //   157: pop
    //   158: aload_0
    //   159: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   162: invokestatic 63	com/tencent/mobileqq/activity/ChatVideoActivity:access$500	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)[B
    //   165: astore_2
    //   166: aload_2
    //   167: aload_3
    //   168: sipush 320
    //   171: sipush 240
    //   174: iload_1
    //   175: invokestatic 69	com/QQ/video/codec/NativeCommon:RotateRGB565	([B[BIII)I
    //   178: pop
    //   179: aload_0
    //   180: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   183: invokestatic 63	com/tencent/mobileqq/activity/ChatVideoActivity:access$500	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)[B
    //   186: astore_1
    //   187: aload_0
    //   188: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   191: invokestatic 47	com/tencent/mobileqq/activity/ChatVideoActivity:access$300	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Landroid/graphics/Bitmap;
    //   194: astore_2
    //   195: aload_1
    //   196: invokestatic 75	java/nio/ByteBuffer:wrap	([B)Ljava/nio/ByteBuffer;
    //   199: astore_1
    //   200: aload_2
    //   201: aload_1
    //   202: invokevirtual 81	android/graphics/Bitmap:copyPixelsFromBuffer	(Ljava/nio/Buffer;)V
    //   205: aload_0
    //   206: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   209: invokestatic 85	com/tencent/mobileqq/activity/ChatVideoActivity:access$600	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Lcom/tencent/mobileqq/video/surfaceview/RemoteView;
    //   212: invokevirtual 91	com/tencent/mobileqq/video/surfaceview/RemoteView:getHolder	()Landroid/view/SurfaceHolder;
    //   215: astore_1
    //   216: aload_1
    //   217: invokeinterface 97 1 0
    //   222: astore_2
    //   223: aload_2
    //   224: ifnull -195 -> 29
    //   227: aload_0
    //   228: getfield 10	ak:a	Lcom/tencent/mobileqq/activity/ChatVideoActivity;
    //   231: invokestatic 47	com/tencent/mobileqq/activity/ChatVideoActivity:access$300	(Lcom/tencent/mobileqq/activity/ChatVideoActivity;)Landroid/graphics/Bitmap;
    //   234: astore 7
    //   236: aload_2
    //   237: invokevirtual 103	android/graphics/Canvas:getClipBounds	()Landroid/graphics/Rect;
    //   240: astore 8
    //   242: aload_2
    //   243: aload 7
    //   245: aconst_null
    //   246: aload 8
    //   248: aconst_null
    //   249: invokevirtual 107	android/graphics/Canvas:drawBitmap	(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    //   252: aload_1
    //   253: aload_2
    //   254: invokeinterface 111 2 0
    //   259: goto -230 -> 29
    //   262: astore 9
    //   264: goto -235 -> 29
    //   267: astore 10
    //   269: aload_2
    //   270: monitorexit
    //   271: aload 10
    //   273: athrow
    //   274: aload_3
    //   275: astore_1
    //   276: goto -89 -> 187
    //
    // Exception table:
    //   from	to	target	type
    //   0	12	262	java/lang/Exception
    //   81	274	262	java/lang/Exception
    //   12	69	267	finally
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ak
 * JD-Core Version:    0.5.4
 */