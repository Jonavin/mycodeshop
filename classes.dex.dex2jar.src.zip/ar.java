import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import com.tencent.mobileqq.activity.ChatVideoActivity;

public final class ar
  implements DialogInterface.OnDismissListener
{
  public ar(ChatVideoActivity paramChatVideoActivity)
  {
  }

  public final void onDismiss(DialogInterface paramDialogInterface)
  {
    ChatVideoActivity.access$2510(this.a);
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ar
 * JD-Core Version:    0.5.4
 */