import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.Button;
import com.tencent.mobileqq.activity.ChatHistory;
import com.tencent.mobileqq.activity.ChatHistory.ChatHistoryAdapter;
import com.tencent.mobileqq.utils.Recorder;

final class ah
  implements Runnable
{
  ah(ag paramag)
  {
  }

  public final void run()
  {
    int i = 2130838036;
    ChatHistory localChatHistory1 = 0;
    Drawable localDrawable1 = null;
    Object localObject1 = (ChatHistory)ChatHistory.ChatHistoryAdapter.access$2400(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter);
    Button localButton1 = this.a.jdField_a_of_type_AndroidWidgetButton;
    localObject1 = ((ChatHistory)localObject1).jdField_a_of_type_AndroidViewView;
    label48: ChatHistory localChatHistory2;
    if (localObject1 == localButton1)
    {
      int j = 1;
      if (j != 0)
      {
        boolean bool = ChatHistory.access$600(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter.a);
        if (!bool)
          break label352;
      }
      localChatHistory2 = (ChatHistory)ChatHistory.ChatHistoryAdapter.access$2400(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter);
      String str = this.a.jdField_a_of_type_JavaLangString;
      Button localButton2 = this.a.jdField_a_of_type_AndroidWidgetButton;
      int k = this.a.jdField_a_of_type_Int;
      if (localChatHistory2.jdField_a_of_type_ComTencentMobileqqUtilsRecorder == null)
      {
        Recorder localRecorder1 = new Recorder();
        localChatHistory2.jdField_a_of_type_ComTencentMobileqqUtilsRecorder = localRecorder1;
      }
      if ((localChatHistory2.jdField_a_of_type_AndroidViewView != null) && (!localChatHistory2.jdField_a_of_type_JavaLangObject.equals(localButton2)))
      {
        localChatHistory2.jdField_a_of_type_ComTencentMobileqqUtilsRecorder.b();
        Drawable localDrawable2 = localChatHistory2.getResources().getDrawable(i);
        int l = i.getMinimumWidth();
        int i1 = i.getMinimumHeight();
        i.setBounds(localChatHistory1, localChatHistory1, l, i1);
        ((Button)localChatHistory2.jdField_a_of_type_AndroidViewView).setCompoundDrawables(i, localDrawable1, localDrawable1, localDrawable1);
      }
      localChatHistory2.jdField_a_of_type_AndroidViewView = localButton2;
      Object localObject2 = localButton2.getTag();
      localChatHistory2.jdField_a_of_type_JavaLangObject = localObject2;
      localChatHistory2.jdField_a_of_type_Int = k;
      localChatHistory2.jdField_a_of_type_ComTencentMobileqqUtilsRecorder.b(str);
      localChatHistory2.jdField_a_of_type_Boolean = localChatHistory1;
      Recorder localRecorder2 = localChatHistory2.jdField_a_of_type_ComTencentMobileqqUtilsRecorder;
      x localx = new x(localChatHistory2);
      localRecorder2.a(str);
      Drawable localDrawable3 = ChatHistory.ChatHistoryAdapter.access$2400(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter).getResources().getDrawable(2130837934);
      int i2 = localChatHistory2.getMinimumWidth();
      int i3 = localChatHistory2.getMinimumHeight();
      localChatHistory2.setBounds(localChatHistory1, localChatHistory1, i2, str);
      this.a.jdField_a_of_type_AndroidWidgetButton.setCompoundDrawables(localChatHistory2, localDrawable1, localDrawable1, localDrawable1);
    }
    while (true)
    {
      return;
      localChatHistory2 = localChatHistory1;
      break label48:
      label352: ((ChatHistory)ChatHistory.ChatHistoryAdapter.access$2400(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter)).a();
      Drawable localDrawable4 = ChatHistory.ChatHistoryAdapter.access$2400(this.a.jdField_a_of_type_ComTencentMobileqqActivityChatHistory$ChatHistoryAdapter).getResources().getDrawable(i);
      int i4 = localDrawable4.getMinimumWidth();
      int i5 = localDrawable4.getMinimumHeight();
      localDrawable4.setBounds(localChatHistory1, localChatHistory1, i4, i5);
      this.a.jdField_a_of_type_AndroidWidgetButton.setCompoundDrawables(localDrawable4, localDrawable1, localDrawable1, localDrawable1);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ah
 * JD-Core Version:    0.5.4
 */