import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatHistory;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.mobileqq.utils.CacheUtils;
import com.tencent.mobileqq.utils.Chatter;
import java.util.Map;
import java.util.Vector;

public final class ac
  implements View.OnClickListener
{
  public ac(ChatHistory paramChatHistory)
  {
  }

  public final void onClick(View paramView)
  {
    ChatHistory.access$1500(this.a);
    ??? = ChatHistory.access$900(this.a);
    int i = ChatHistory.access$1000(this.a);
    Chatter localChatter = new Chatter((String)???, i);
    synchronized (this.a.a.a)
    {
      this.a.a.a.a.remove(localChatter);
      this.a.a.a.b.remove(localChatter);
      return;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ac
 * JD-Core Version:    0.5.4
 */