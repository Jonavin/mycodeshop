import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.mobileqq.activity.ChatHistory;
import com.tencent.mobileqq.app.QQApplication;
import com.tencent.qphone.base.remote.SimpleAccount;

public final class ad
  implements View.OnClickListener
{
  public ad(ChatHistory paramChatHistory)
  {
  }

  public final void onClick(View paramView)
  {
    if (ChatHistory.access$1000(this.a) == 0)
      ChatHistory.access$1600(this.a);
    while (true)
    {
      return;
      String[] arrayOfString = new String[3];
      String str1 = this.a.jdField_a_of_type_ComTencentMobileqqAppQQApplication.a().getSid();
      arrayOfString[0] = str1;
      String str2 = this.a.jdField_a_of_type_JavaLangString;
      arrayOfString[1] = str2;
      String str3 = ChatHistory.access$900(this.a);
      arrayOfString[2] = str3;
      String str4 = String.format("http://kiss.3g.qq.com/activeQQ/mqq/groupMsg_wap20.jsp?bid=591&sid=%s&groupName=%s&groupCode=%s", arrayOfString);
      Intent localIntent = new Intent();
      localIntent.setFlags(270532608);
      localIntent.setAction("android.intent.action.VIEW");
      Uri localUri = Uri.parse(str4);
      localIntent.setData(localUri);
      this.a.startActivity(localIntent);
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     ad
 * JD-Core Version:    0.5.4
 */