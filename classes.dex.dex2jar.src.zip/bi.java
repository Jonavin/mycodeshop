import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import com.tencent.mobileqq.activity.ChatWindowActivity;

public final class bi
  implements AdapterView.OnItemLongClickListener
{
  public bi(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final boolean onItemLongClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramInt < 100)
      ChatWindowActivity.access$3100(this.a, paramInt);
    return true;
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bi
 * JD-Core Version:    0.5.4
 */