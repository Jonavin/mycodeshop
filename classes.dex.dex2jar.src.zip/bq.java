import android.database.Cursor;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import com.tencent.mobileqq.activity.ChatWindowActivity;
import com.tencent.mobileqq.activity.ChatWindowActivity.MessageListView;
import com.tencent.mobileqq.adapter.ChatMessageListAdapter;
import com.tencent.mobileqq.skin.SkinEngine;
import com.tencent.mobileqq.transfile.FileMsg;
import com.tencent.qphone.base.util.QLog;

public final class bq extends Handler
{
  public bq(ChatWindowActivity paramChatWindowActivity)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    int i = 1;
    int j = 2000;
    int k = 8;
    int l = 2;
    int i1 = 0;
    String str1 = null;
    FileMsg localFileMsg = (FileMsg)paramMessage.obj;
    int i3 = paramMessage.what;
    Object localObject3;
    label133: Object localObject5;
    switch (i3)
    {
    default:
      int i4 = ChatWindowActivity.access$2300(this.a).getChildCount();
      localObject3 = new StringBuilder();
      Object localObject4 = "count = ";
      localObject3 = (String)localObject4 + i4;
      QLog.d("gene", (String)localObject3);
      int i7 = i1;
      if (i7 >= i4)
        break label1650;
      localObject3 = ChatWindowActivity.access$2300(this.a).getChildAt(i7);
      localObject4 = ((View)localObject3).getTag();
      if (localObject4 == null)
        break label960;
      int i6 = paramMessage.what;
      if (i6 < j)
        break label897;
      localObject5 = new StringBuilder();
      String str2 = localFileMsg.e;
      localObject5 = ((StringBuilder)localObject5).append(str2);
      String str3 = localFileMsg.g;
      localObject5 = ((StringBuilder)localObject5).append(str3);
      long l1 = localFileMsg.b;
      localObject5 = l1;
      label238: String str4 = "item id: " + i7 + " key: " + (String)localObject5;
      QLog.v("gene", str4);
      if (!((View)localObject3).getTag().equals(localObject5))
        break label960;
    case 2003:
    case 1003:
    case 2005:
    case 1005:
    }
    while (true)
    {
      str1 = "ptt";
      Object localObject2 = new StringBuilder();
      Object localObject6 = "item : ";
      localObject2 = (String)localObject6 + localObject3;
      QLog.v(str1, (String)localObject2);
      if (localObject3 == null);
      label366: label502: ProgressBar localProgressBar;
      while (true)
      {
        return;
        localObject2 = "STATUS_RECV_FINISHED";
        QLog.d("gene", (String)localObject2);
        Object localObject1 = localFileMsg.jdField_c_of_type_Int;
        Object localObject7;
        if (localObject1 == l)
        {
          localObject1 = i1;
          localObject2 = ChatWindowActivity.access$2300(this.a).getChildCount();
          if (localObject1 < localObject2)
          {
            localObject2 = ChatWindowActivity.access$2300(this.a).getChildAt(localObject1);
            localObject6 = ((View)localObject2).getTag();
            long l2;
            if (localObject6 != null)
            {
              int i8 = paramMessage.what;
              if (i8 < j)
                break label502;
              localObject7 = new StringBuilder();
              String str5 = localFileMsg.e;
              localObject7 = ((StringBuilder)localObject7).append(str5);
              String str6 = localFileMsg.g;
              localObject7 = ((StringBuilder)localObject7).append(str6);
              l2 = localFileMsg.b;
            }
            long l3;
            for (localObject7 = l2; !((View)localObject2).getTag().equals(localObject7); localObject7 = l3)
            {
              ++localObject1;
              break label366:
              localObject7 = new StringBuilder();
              String str7 = localFileMsg.d;
              localObject7 = ((StringBuilder)localObject7).append(str7);
              String str8 = localFileMsg.g;
              localObject7 = ((StringBuilder)localObject7).append(str8);
              l3 = localFileMsg.b;
            }
          }
        }
        ChatWindowActivity.access$100(this.a).getCursor().requery();
        int i10 = ChatWindowActivity.access$2300(this.a).getLastVisiblePosition();
        int i2 = ChatWindowActivity.access$100(this.a).getCount();
        if (i10 != i2)
          continue;
        ChatWindowActivity.MessageListView localMessageListView = ChatWindowActivity.access$2300(this.a);
        int i11 = i2 - i;
        localMessageListView.setSelection(i2);
        continue;
        localObject2 = "STATUS_SEND_FINISHED";
        QLog.d("gene", (String)localObject2);
        i2 = localFileMsg.jdField_c_of_type_Int;
        if (i2 == l)
        {
          i2 = i1;
          label666: localObject2 = ChatWindowActivity.access$2300(this.a).getChildCount();
          if (i2 < localObject2)
          {
            localObject2 = ChatWindowActivity.access$2300(this.a).getChildAt(i2);
            localObject7 = ((View)localObject2).getTag();
            long l4;
            if (localObject7 != null)
            {
              int i9 = paramMessage.what;
              if (i9 < j)
                break label802;
              localObject8 = new StringBuilder();
              String str9 = localFileMsg.e;
              localObject8 = ((StringBuilder)localObject8).append(str9);
              String str10 = localFileMsg.g;
              localObject8 = ((StringBuilder)localObject8).append(str10);
              l4 = localFileMsg.b;
            }
            label802: long l5;
            for (localObject8 = l4; !((View)localObject2).getTag().equals(localObject8); localObject8 = l5)
            {
              ++i2;
              break label666:
              localObject8 = new StringBuilder();
              String str11 = localFileMsg.d;
              localObject8 = ((StringBuilder)localObject8).append(str11);
              String str12 = localFileMsg.g;
              localObject8 = ((StringBuilder)localObject8).append(str12);
              l5 = localFileMsg.b;
            }
          }
        }
        ChatWindowActivity.access$100(this.a).getCursor().requery();
        continue;
        ChatWindowActivity.access$100(this.a).notifyDataSetChanged();
        continue;
        label897: localObject5 = new StringBuilder();
        String str13 = localFileMsg.d;
        localObject5 = ((StringBuilder)localObject5).append(str13);
        String str14 = localFileMsg.g;
        localObject5 = ((StringBuilder)localObject5).append(str14);
        long l6 = localFileMsg.b;
        localObject5 = l6;
        break label238:
        label960: ++localObject8;
        break label133:
        localProgressBar = (ProgressBar)((View)localObject3).findViewById(2131493008);
        localObject2 = (ProgressBar)((View)localObject3).findViewById(2131493002);
        Object localObject8 = (ImageView)((View)localObject3).findViewById(2131492999);
        localObject3 = (ImageView)((View)localObject3).findViewById(2131493011);
        StringBuilder localStringBuilder1 = new StringBuilder().append("msg.what : ");
        int i12 = paramMessage.what;
        String str15 = i12;
        QLog.v("ptt", str15);
        int i5;
        switch (paramMessage.what)
        {
        default:
          break;
        case 1000:
        case 1001:
          StringBuilder localStringBuilder2 = new StringBuilder().append("2=");
          int i13 = paramMessage.what;
          StringBuilder localStringBuilder3 = localStringBuilder2.append(i13).append("----file.fileType = ");
          int i14 = localFileMsg.jdField_c_of_type_Int;
          String str16 = i14;
          QLog.d("gene", str16);
          ((ImageView)localObject8).setVisibility(k);
          ChatWindowActivity.access$100(this.a).getCursor().requery();
          if (localFileMsg.jdField_c_of_type_Int == l)
            continue;
          ((ProgressBar)localObject2).setVisibility(i1);
          ((ProgressBar)localObject2).setProgress(i1);
          break;
        case 2000:
        case 2001:
          StringBuilder localStringBuilder4 = new StringBuilder().append("0=");
          int i15 = paramMessage.what;
          StringBuilder localStringBuilder5 = localStringBuilder4.append(i15).append("----file.fileType = ");
          int i16 = localFileMsg.jdField_c_of_type_Int;
          String str17 = i16;
          QLog.d("gene", str17);
          ((ImageView)localObject3).setVisibility(k);
          ChatWindowActivity.access$100(this.a).getCursor().requery();
          if (localFileMsg.jdField_c_of_type_Int == l)
            continue;
          localProgressBar.setVisibility(i1);
          SkinEngine.setProgressDrawable(localProgressBar, "progressbarpic", "progressDrawable");
          localProgressBar.setProgress(i1);
          break;
        case 2002:
          StringBuilder localStringBuilder6 = new StringBuilder().append("1=");
          int i17 = paramMessage.what;
          StringBuilder localStringBuilder7 = localStringBuilder6.append(i17).append("----file.fileType = ");
          int i18 = localFileMsg.jdField_c_of_type_Int;
          String str18 = i18;
          QLog.d("gene", str18);
          ((ImageView)localObject3).setVisibility(k);
          ChatWindowActivity.access$100(this.a).getCursor().requery();
          long l7 = localFileMsg.jdField_c_of_type_Long;
          long l8 = localProgressBar.getMax();
          l7 *= localObject3;
          long l9 = localFileMsg.a;
          i5 = (int)(l7 / localObject3);
          if (localFileMsg.jdField_c_of_type_Int == l)
            continue;
          localProgressBar.setVisibility(i1);
          SkinEngine.setProgressDrawable(localProgressBar, "progressbarpic", "progressDrawable");
          localProgressBar.setProgress(i5);
          break;
        case 1002:
        }
        StringBuilder localStringBuilder8 = new StringBuilder().append("3=");
        int i19 = paramMessage.what;
        StringBuilder localStringBuilder9 = localStringBuilder8.append(i19).append("----file.fileType = ");
        int i20 = localFileMsg.jdField_c_of_type_Int;
        String str19 = i20;
        QLog.d("gene", str19);
        ((ImageView)localObject8).setVisibility(k);
        ChatWindowActivity.access$100(this.a).getCursor().requery();
        if (localFileMsg.jdField_c_of_type_Int != i)
          continue;
        long l10 = localFileMsg.jdField_c_of_type_Long;
        long l11 = i5.getMax();
        long l12 = l10 * l11;
        long l13 = localFileMsg.a;
        int i21 = (int)(l12 / localFileMsg);
        i5.setProgress(localFileMsg);
        i5.setVisibility(i1);
      }
      label1650: localObject3 = localProgressBar;
    }
  }
}

/* Location:           E:\apk\classes.dex.dex2jar.jar
 * Qualified Name:     bq
 * JD-Core Version:    0.5.4
 */