package com.jiayuan;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class f
  implements DialogInterface.OnClickListener
{
  f(MyActivity paramMyActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.f
 * JD-Core Version:    0.5.4
 */