package com.jiayuan.match;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class b
  implements View.OnTouchListener
{
  b(MatchActivity paramMatchActivity)
  {
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return MatchActivity.d(this.a).onTouchEvent(paramMotionEvent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.b
 * JD-Core Version:    0.5.4
 */