package com.jiayuan.match;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.location.Location;
import com.jiayuan.a.i;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.a.z;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.util.ArrayList;
import java.util.List;

public class j
  implements i, q
{
  public m a;
  public Context b;
  private List c;
  private int d = null;
  private int e = null;
  private int f = null;
  private int g = 10;

  public j(m paramm)
  {
    this.a = paramm;
    Activity localActivity = (Activity)paramm;
    this.b = paramm;
  }

  // ERROR //
  public void a(int paramInt, String paramString)
  {
    // Byte code:
    //   0: ldc 45
    //   2: astore_3
    //   3: ldc 47
    //   5: aload_3
    //   6: invokestatic 52	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   9: aload_2
    //   10: ldc 54
    //   12: invokevirtual 60	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   15: astore 4
    //   17: iload 4
    //   19: ifeq +21 -> 40
    //   22: ldc 47
    //   24: ldc 62
    //   26: invokestatic 52	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   29: aload_0
    //   30: getfield 34	com/jiayuan/match/j:a	Lcom/jiayuan/match/m;
    //   33: aload_2
    //   34: invokeinterface 68 2 0
    //   39: return
    //   40: new 70	org/json/JSONObject
    //   43: dup
    //   44: aload_2
    //   45: invokespecial 72	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   48: astore_3
    //   49: new 74	java/lang/StringBuilder
    //   52: dup
    //   53: ldc 76
    //   55: invokespecial 77	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   58: astore 5
    //   60: aload_3
    //   61: invokevirtual 81	org/json/JSONObject:toString	()Ljava/lang/String;
    //   64: astore 6
    //   66: aload 5
    //   68: aload 6
    //   70: invokevirtual 85	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: invokevirtual 86	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   76: astore 5
    //   78: ldc 47
    //   80: aload 5
    //   82: invokestatic 52	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   85: new 88	java/util/ArrayList
    //   88: dup
    //   89: invokespecial 89	java/util/ArrayList:<init>	()V
    //   92: astore 4
    //   94: aload_0
    //   95: aload 4
    //   97: putfield 91	com/jiayuan/match/j:c	Ljava/util/List;
    //   100: ldc 93
    //   102: astore 4
    //   104: aload_3
    //   105: aload 4
    //   107: invokevirtual 97	org/json/JSONObject:getJSONObject	(Ljava/lang/String;)Lorg/json/JSONObject;
    //   110: astore 5
    //   112: aload 5
    //   114: invokevirtual 101	org/json/JSONObject:keys	()Ljava/util/Iterator;
    //   117: astore 6
    //   119: aload 6
    //   121: invokeinterface 107 1 0
    //   126: astore 4
    //   128: iload 4
    //   130: ifne +182 -> 312
    //   133: aload_3
    //   134: ldc 109
    //   136: invokevirtual 113	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   139: astore 7
    //   141: aload_0
    //   142: iload 7
    //   144: putfield 26	com/jiayuan/match/j:d	I
    //   147: aload_0
    //   148: getfield 30	com/jiayuan/match/j:f	I
    //   151: istore 8
    //   153: aload_0
    //   154: iload 8
    //   156: putfield 28	com/jiayuan/match/j:e	I
    //   159: aload_3
    //   160: ldc 115
    //   162: invokevirtual 113	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   165: astore 9
    //   167: aload_0
    //   168: iload 9
    //   170: putfield 30	com/jiayuan/match/j:f	I
    //   173: new 74	java/lang/StringBuilder
    //   176: dup
    //   177: ldc 117
    //   179: invokespecial 77	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   182: astore 10
    //   184: aload_0
    //   185: getfield 30	com/jiayuan/match/j:f	I
    //   188: istore 11
    //   190: aload 10
    //   192: iload 11
    //   194: invokevirtual 120	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   197: invokevirtual 86	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   200: astore 12
    //   202: ldc 47
    //   204: aload 12
    //   206: invokestatic 52	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   209: new 122	com/jiayuan/match/n
    //   212: dup
    //   213: aload_0
    //   214: invokespecial 125	com/jiayuan/match/n:<init>	(Lcom/jiayuan/match/j;)V
    //   217: astore 13
    //   219: aload_0
    //   220: getfield 91	com/jiayuan/match/j:c	Ljava/util/List;
    //   223: aload 13
    //   225: invokestatic 131	java/util/Collections:sort	(Ljava/util/List;Ljava/util/Comparator;)V
    //   228: aload_0
    //   229: getfield 34	com/jiayuan/match/j:a	Lcom/jiayuan/match/m;
    //   232: astore 14
    //   234: aload_0
    //   235: getfield 91	com/jiayuan/match/j:c	Ljava/util/List;
    //   238: astore 15
    //   240: aload 14
    //   242: aload 15
    //   244: invokeinterface 134 2 0
    //   249: aload_0
    //   250: getfield 34	com/jiayuan/match/j:a	Lcom/jiayuan/match/m;
    //   253: invokeinterface 136 1 0
    //   258: goto -219 -> 39
    //   261: astore 16
    //   263: new 74	java/lang/StringBuilder
    //   266: dup
    //   267: ldc 138
    //   269: invokespecial 77	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   272: astore 17
    //   274: aload 16
    //   276: invokevirtual 139	org/json/JSONException:toString	()Ljava/lang/String;
    //   279: astore 18
    //   281: aload 17
    //   283: aload 18
    //   285: invokevirtual 85	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: invokevirtual 86	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   291: astore 19
    //   293: ldc 47
    //   295: aload 19
    //   297: invokestatic 52	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   300: aload_0
    //   301: getfield 34	com/jiayuan/match/j:a	Lcom/jiayuan/match/m;
    //   304: invokeinterface 141 1 0
    //   309: goto -270 -> 39
    //   312: aload 6
    //   314: invokeinterface 145 1 0
    //   319: checkcast 56	java/lang/String
    //   322: astore 4
    //   324: aload 5
    //   326: aload 4
    //   328: invokevirtual 97	org/json/JSONObject:getJSONObject	(Ljava/lang/String;)Lorg/json/JSONObject;
    //   331: astore 20
    //   333: new 147	com/jiayuan/match/k
    //   336: dup
    //   337: invokespecial 148	com/jiayuan/match/k:<init>	()V
    //   340: astore 21
    //   342: aload 21
    //   344: aload 4
    //   346: putfield 151	com/jiayuan/match/k:a	Ljava/lang/String;
    //   349: aload 20
    //   351: ldc 153
    //   353: invokevirtual 157	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   356: astore 4
    //   358: aload 21
    //   360: aload 4
    //   362: putfield 159	com/jiayuan/match/k:d	Ljava/lang/String;
    //   365: aload 20
    //   367: ldc 161
    //   369: invokevirtual 113	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   372: astore 4
    //   374: aload 21
    //   376: iload 4
    //   378: putfield 163	com/jiayuan/match/k:c	I
    //   381: iconst_2
    //   382: invokestatic 167	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   385: astore 4
    //   387: aload 20
    //   389: aload 4
    //   391: invokevirtual 157	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   394: astore 4
    //   396: aload 21
    //   398: aload 4
    //   400: putfield 169	com/jiayuan/match/k:e	Ljava/lang/String;
    //   403: iconst_0
    //   404: istore 4
    //   406: aload 21
    //   408: aload 4
    //   410: putfield 171	com/jiayuan/match/k:b	Ljava/lang/String;
    //   413: aload 20
    //   415: ldc 173
    //   417: invokevirtual 157	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   420: astore 4
    //   422: aload 21
    //   424: aload 4
    //   426: putfield 175	com/jiayuan/match/k:f	Ljava/lang/String;
    //   429: aload_0
    //   430: getfield 91	com/jiayuan/match/j:c	Ljava/util/List;
    //   433: astore 4
    //   435: aload 4
    //   437: aload 21
    //   439: invokeinterface 181 2 0
    //   444: pop
    //   445: goto -326 -> 119
    //   448: invokevirtual 184	java/lang/Exception:printStackTrace	()V
    //   451: ldc 186
    //   453: astore 4
    //   455: aload 21
    //   457: aload 4
    //   459: putfield 175	com/jiayuan/match/k:f	Ljava/lang/String;
    //   462: goto -33 -> 429
    //   465: invokevirtual 184	java/lang/Exception:printStackTrace	()V
    //   468: goto -295 -> 173
    //
    // Exception table:
    //   from	to	target	type
    //   40	128	261	org/json/JSONException
    //   133	173	261	org/json/JSONException
    //   173	258	261	org/json/JSONException
    //   312	413	261	org/json/JSONException
    //   413	429	261	org/json/JSONException
    //   429	468	261	org/json/JSONException
    //   413	429	448	java/lang/Exception
    //   133	173	465	java/lang/Exception
  }

  public void a(ArrayList paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder("onGetPhotoAmount photoUrls.size()=");
    int i = paramArrayList.size();
    String str = i;
    a.a("MatchDataProcessing", str);
    int j = this.f;
    int k = this.g;
    if (j / k >= 1)
      return;
    this.a.b(paramArrayList);
  }

  public void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    long l = 0L;
    a.a("MatchDataProcessing", "execute()");
    Location localLocation = s.a(this.b);
    Object localObject1 = this.a;
    ((m)localObject1).a();
    if (paramBoolean1)
    {
      Context localContext = this.b;
      String str1 = o.e();
      j localj = this;
      localObject1 = new z(localContext, localj, str1, 1, "-2", -1, 10, 22);
      ((z)localObject1).a();
    }
    localObject1 = new StringBuffer("http://api2.jiayuan.com/geo/");
    ((StringBuffer)localObject1).append("fast_getid_cached.php?");
    ((StringBuffer)localObject1).append("uid=");
    String str2 = o.e();
    ((StringBuffer)localObject1).append(str2);
    ((StringBuffer)localObject1).append("&token=");
    String str3 = o.f();
    ((StringBuffer)localObject1).append(str3);
    ((StringBuffer)localObject1).append("&cursor=");
    if (paramBoolean2)
    {
      int i = this.e;
      this.f = i;
    }
    int j = this.f;
    ((StringBuffer)localObject1).append(j);
    if ((localLocation != null) && (localLocation.getLatitude() > l) && (localLocation.getLongitude() > l))
    {
      ((StringBuffer)localObject1).append("&loc={\"lng\":");
      double d1 = localLocation.getLongitude();
      Object localObject2;
      ((StringBuffer)localObject1).append(localObject2);
      ((StringBuffer)localObject1).append(",\"lat\":");
      double d2 = localLocation.getLatitude();
      Object localObject3;
      ((StringBuffer)localObject1).append(localObject3);
      ((StringBuffer)localObject1).append("}");
    }
    l locall = new l();
    locall.a = this;
    String str4 = ((StringBuffer)localObject1).toString();
    locall.b((String)localObject1);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MatchDataProcessing", "onProgressUpdate()");
  }

  public void a_(int paramInt, String paramString, Bitmap paramBitmap)
  {
  }

  public void a_(String paramString)
  {
  }

  public void b()
  {
    a.a("MatchDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MatchDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.j
 * JD-Core Version:    0.5.4
 */