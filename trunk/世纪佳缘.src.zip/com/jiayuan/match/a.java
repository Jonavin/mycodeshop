package com.jiayuan.match;

import android.view.View;
import android.view.View.OnClickListener;

class a
  implements View.OnClickListener
{
  a(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(View paramView)
  {
    MatchActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.a
 * JD-Core Version:    0.5.4
 */