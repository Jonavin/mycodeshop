package com.jiayuan.match;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class l
  implements DialogInterface.OnClickListener
{
  l(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.l
 * JD-Core Version:    0.5.4
 */