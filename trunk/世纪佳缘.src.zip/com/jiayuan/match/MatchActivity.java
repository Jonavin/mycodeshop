package com.jiayuan.match;

import Z;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager.BadTokenException;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.a.aa;
import com.jiayuan.a.z;
import com.jiayuan.mail.detail.MailSendActivity;
import com.jiayuan.myprofile.MyMateSelectionActivity;
import com.jiayuan.profile.ProfileActivity;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MatchActivity extends Activity
  implements aa, com.jiayuan.a.i, m
{
  Button a;
  boolean b = null;
  boolean c = null;
  boolean d = null;
  Context e = this;
  j f;
  private ArrayList g = null;
  private ArrayList h = null;
  private k i = null;
  private Bitmap j = null;
  private int k = null;
  private GestureDetector l;
  private ImageView m;
  private int n;
  private int o;
  private ProgressDialog p;
  private GestureDetector.OnGestureListener q;
  private boolean r;
  private boolean s;

  public MatchActivity()
  {
    c localc = new c(this);
    this.q = localc;
    this.r = null;
    this.s = null;
  }

  private void a(boolean paramBoolean, int paramInt)
  {
    com.jiayuan.util.a.a("MatchActivity", "updataPhotoCache");
    this.h.remove(0);
    this.h.add(null);
    int i1 = this.k;
    i1 += 3;
    if (!paramBoolean)
      return;
    int i2 = this.g.size();
    if (i1 >= i2)
      return;
    a(i1, paramInt);
  }

  private void e()
  {
    Object localObject1 = new StringBuilder("Match image button clicked currentIndex=");
    int i3 = this.k;
    localObject1 = i3;
    com.jiayuan.util.a.a("MatchActivity", (String)localObject1);
    int i4 = -1;
    int i1 = this.k;
    if (i4 != i1)
    {
      Object localObject2 = this.g;
      if (localObject2 != null)
      {
        localObject2 = this.g.isEmpty();
        if (localObject2 == 0)
        {
          int i5 = this.k;
          int i2 = this.g.size();
          if (i5 < i2)
            break label83;
        }
      }
    }
    label82: return;
    label83: Intent localIntent = new Intent();
    boolean bool1 = this.r;
    if (bool1);
    int i8;
    for (Object localObject3 = this.i; ; localObject3 = (k)((ArrayList)localObject3).get(i8))
    {
      String str1 = ((k)localObject3).a;
      localIntent.putExtra("uid", str1);
      boolean bool2 = ((k)localObject3).g;
      localIntent.putExtra("isMatchBtnEnable", bool2);
      String str2 = ((k)localObject3).e;
      localIntent.putExtra("sex", (String)localObject3);
      localIntent.putExtra("src", 1);
      int i6 = com.jiayuan.a.h.e;
      localIntent.putExtra("matchSrc", i6);
      int i7 = com.jiayuan.a.d.a;
      localIntent.putExtra("profileSrc", i7);
      localIntent.setClass(this, ProfileActivity.class);
      startActivity(localIntent);
      break label82:
      localObject3 = this.g;
      i8 = this.k;
    }
  }

  private void f()
  {
    int i1 = 0;
    com.jiayuan.util.a.a("MatchActivity", "Match ok button clicked");
    if (this.r)
    {
      this.i.g = i1;
      Button localButton1 = this.a;
      boolean bool1 = this.i.g;
      localButton1.setEnabled(bool1);
      String str1 = this.i.a;
      int i2 = this.k;
      int i3 = com.jiayuan.a.h.c;
      new com.jiayuan.a.h(this, str1, i1, i3).a();
    }
    while (true)
    {
      return;
      int i4 = this.k;
      if ((-1 == i4) || (this.g == null) || (this.g.isEmpty()))
        continue;
      int i5 = this.k;
      int i6 = this.g.size();
      if (i5 >= i6)
        continue;
      ArrayList localArrayList = this.g;
      int i7 = this.k;
      k localk = (k)localArrayList.get(i7);
      localk.g = i1;
      Button localButton2 = this.a;
      boolean bool2 = localk.g;
      localButton2.setEnabled(i1);
      String str2 = localk.a;
      int i8 = this.k;
      int i9 = com.jiayuan.a.h.c;
      new com.jiayuan.a.h(this, str2, i1, i9).a();
    }
  }

  private void g()
  {
    boolean bool1 = this.r;
    Object localObject;
    if (!bool1)
    {
      localObject = this.i;
      if (localObject != null)
      {
        com.jiayuan.util.a.a("MatchActivity", "onMatchPrevious");
        this.r = true;
        StringBuffer localStringBuffer = new StringBuffer();
        localObject = this.i.d;
        localStringBuffer.append((String)localObject);
        ((TextView)findViewById(2131361929)).setText(localStringBuffer);
        localObject = (TextView)findViewById(2131361931);
        String str = s.a(this.i.f);
        ((TextView)localObject).setText(str);
        localObject = (ImageView)findViewById(2131361930);
        switch (this.i.c)
        {
        default:
          label132: ImageView localImageView1 = this.m;
          ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
          localImageView1.setScaleType(localScaleType);
          if (this.j == null)
            break label233;
          if (this.p != null)
            this.p.dismiss();
          ImageView localImageView2 = this.m;
          Bitmap localBitmap = this.j;
          localImageView2.setImageBitmap(localBitmap);
        case 0:
        case 1:
        }
      }
    }
    while (true)
    {
      Button localButton = this.a;
      boolean bool2 = this.i.g;
      localButton.setEnabled(bool2);
      return;
      ((ImageView)localObject).setBackgroundResource(2130837659);
      break label132:
      ((ImageView)localObject).setBackgroundResource(2130837660);
      break label132:
      label233: this.m.setImageResource(17170444);
      if (this.p == null)
        continue;
      this.p.dismiss();
    }
  }

  private void h()
  {
    int i1 = 0;
    int i2 = 1;
    StringBuilder localStringBuilder1 = new StringBuilder("Match next button clicked currentIndex=");
    int i3 = this.k;
    String str1 = i3;
    com.jiayuan.util.a.a("MatchActivity", str1);
    int i4 = this.k;
    if ((-1 == i4) || (this.g == null) || (this.g.isEmpty()));
    while (true)
    {
      return;
      int i5 = this.k;
      int i6 = this.g.size() - i2;
      if (i5 < i6)
      {
        if (!this.r)
        {
          ArrayList localArrayList1 = this.g;
          int i7 = this.k;
          k localk1 = (k)localArrayList1.get(i7);
          this.i = localk1;
          Bitmap localBitmap1 = (Bitmap)this.h.get(i1);
          this.j = localBitmap1;
          a(i2, i2);
          StringBuilder localStringBuilder2 = new StringBuilder("match currentIndex");
          int i8 = this.k;
          String str2 = i8;
          com.jiayuan.util.a.a("MatchActivity", str2);
          int i9 = this.k;
          int i10;
          ++i10;
          this.k = i9;
        }
        i();
        ArrayList localArrayList2 = this.g;
        int i11 = this.k;
        k localk2 = (k)localArrayList2.get(i11);
        localk2.g = i2;
        Button localButton = this.a;
        boolean bool1 = localk2.g;
        localButton.setEnabled(bool1);
        this.r = i1;
      }
      ArrayList localArrayList3 = this.g;
      int i12 = this.k;
      k localk3 = (k)localArrayList3.get(i12);
      this.i = localk3;
      Bitmap localBitmap2 = (Bitmap)this.h.get(i1);
      this.j = localBitmap2;
      if ((o.e() == null) || (o.e().equals("")))
        continue;
      try
      {
        String str3 = getString(2131165195);
        ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str3);
        this.p = localProgressDialog;
        this.p.setCancelable(true);
        this.s = null;
        j localj = this.f;
        boolean bool2 = this.c;
        boolean bool3 = this.s;
        localj.a(bool2, bool3);
      }
      catch (WindowManager.BadTokenException localBadTokenException)
      {
      }
      catch (Exception localException)
      {
      }
    }
  }

  private void i()
  {
    Object localObject = this.g;
    if (localObject != null)
    {
      localObject = this.g.size();
      if (localObject != 0)
        break label22;
    }
    while (true)
    {
      label21: return;
      label22: StringBuilder localStringBuilder = new StringBuilder("updateMatch currentIndex=");
      int i1 = this.k;
      String str = i1;
      com.jiayuan.util.a.a("MatchActivity", str);
      StringBuffer localStringBuffer1 = new StringBuffer();
      localObject = this.g;
      int i2 = this.k;
      localObject = ((k)((ArrayList)localObject).get(i2)).d;
      localStringBuffer1.append((String)localObject);
      ((TextView)findViewById(2131361929)).setText(localStringBuffer1);
      StringBuffer localStringBuffer2 = new StringBuffer();
      localObject = this.g;
      int i3 = this.k;
      localObject = s.a(((k)((ArrayList)localObject).get(i3)).f);
      localStringBuffer2.append((String)localObject);
      ((TextView)findViewById(2131361931)).setText(localStringBuffer2);
      localObject = (ImageView)findViewById(2131361930);
      ArrayList localArrayList = this.g;
      int i4 = this.k;
      switch (((k)localArrayList.get(i4)).c)
      {
      default:
      case 0:
      case 1:
      }
      while (true)
      {
        localObject = (Bitmap)this.h.get(0);
        ImageView localImageView = this.m;
        ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
        localImageView.setScaleType(localScaleType);
        if (localObject == null)
          break;
        if (this.p != null)
          this.p.dismiss();
        this.m.setImageBitmap((Bitmap)localObject);
        break label21:
        ((ImageView)localObject).setBackgroundResource(2130837659);
        continue;
        ((ImageView)localObject).setBackgroundResource(2130837660);
      }
      this.m.setImageResource(17170444);
    }
  }

  public AlertDialog a(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      return i1;
      Object localObject = new AlertDialog.Builder(this).setTitle(2131165644).setMessage(2131165645);
      d locald = new d(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165482, locald).create();
      continue;
      localObject = new AlertDialog.Builder(this).setTitle(2131165355).setMessage(2131165356);
      e locale = new e(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165357, locale);
      h localh = new h(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165358, localh).create();
      continue;
      localObject = new AlertDialog.Builder(this).setTitle(2131165558).setMessage(2131165559);
      i locali = new i(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165561, locali);
      l locall = new l(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165562, locall).create();
    }
  }

  public void a()
  {
    com.jiayuan.util.a.a("MatchActivity", "---------onWaitingActivityStart()---------");
  }

  public void a(int paramInt1, int paramInt2)
  {
    String str1 = "getPhotoCache aStartIndex=" + paramInt1 + ", size=" + paramInt2;
    com.jiayuan.util.a.a("MatchActivity", str1);
    try
    {
      if ((this.g != null) && (this.g.size() > 0))
      {
        String str2 = getString(2131165195);
        ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str2);
        this.p = localProgressDialog;
        this.p.setCancelable(true);
      }
      label85: int i1 = paramInt1;
      int i2 = paramInt1 + paramInt2;
      if (i1 >= i2);
      int i3;
      do
      {
        return;
        i3 = this.g.size();
      }
      while (i1 >= i3);
      Context localContext = this.e;
      String str3 = ((k)this.g.get(i1)).a;
      int i4 = this.n;
      int i5 = this.o + 12;
      MatchActivity localMatchActivity = this;
      new z(localContext, localMatchActivity, str3, null, "-1", i1, i4, i5).a();
      i1 += 1;
    }
    catch (Exception localException)
    {
      break label85:
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
      break label85:
    }
  }

  public void a(ArrayList paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder("onGetPhotoAmount  photoUrls.size()=");
    int i1 = paramArrayList.size();
    String str = i1;
    com.jiayuan.util.a.a("MatchActivity", str);
  }

  public void a(List paramList)
  {
    int i1 = 1;
    Object localObject1 = null;
    Object localObject2 = 3;
    com.jiayuan.util.a.a("MatchActivity", "----------------onGetData()----------------");
    boolean bool1 = com.jiayuan.a.a().a(MatchActivity.class);
    Object localObject4 = this.p;
    if ((localObject4 != null) && (bool1))
    {
      ProgressDialog localProgressDialog = this.p;
      localProgressDialog.dismiss();
    }
    boolean bool2 = this.s;
    if (!bool2)
      this.k = localObject1;
    Object localObject3 = new ArrayList(paramList);
    this.g = ((ArrayList)localObject3);
    localObject3 = new ArrayList(localObject2);
    this.h = ((ArrayList)localObject3);
    localObject4 = new StringBuilder("match mData.size()=");
    int i3 = this.g.size();
    localObject4 = i3;
    com.jiayuan.util.a.a("MatchActivity", (String)localObject4);
    localObject3 = localObject1;
    label144: int i2;
    if (localObject3 >= localObject2)
    {
      localObject3 = this.g;
      if (localObject3 == null)
        break label301;
      localObject3 = this.g.size();
      if (localObject3 <= 0)
        break label301;
      i2 = this.k;
      localObject4 = this.g.size();
      if (localObject2 >= localObject4)
        break label289;
      localObject4 = localObject2;
      label202: a(i2, localObject4);
      i();
      ArrayList localArrayList = this.g;
      int i4 = this.k;
      k localk = (k)i2.get(localObject4);
      i2.g = i1;
      Button localButton = this.a;
      boolean bool3 = i2.g;
      ((Button)localObject4).setEnabled(i2);
      this.r = localObject1;
    }
    while (true)
    {
      return;
      localObject4 = this.h;
      ((ArrayList)localObject4).add(null);
      ++i2;
      break label144:
      label289: localObject4 = this.g.size();
      break label202:
      label301: Toast.makeText(this.e, 2131165672, i1).show();
    }
  }

  public void a_(int paramInt, String paramString, Bitmap paramBitmap)
  {
    String str = "onGetPhoto index=" + paramInt + ", sPhotoUrl=" + paramString;
    com.jiayuan.util.a.a("MatchActivity", str);
    int i1 = this.k;
    if (paramInt >= i1)
    {
      int i2 = this.k;
      int i3;
      i3 += 3;
      if (paramInt >= i2);
    }
    try
    {
      ArrayList localArrayList = this.h;
      int i4 = this.k;
      int i5 = paramInt - i4;
      localArrayList.set(i5, paramBitmap);
      int i6 = this.k;
      if (paramInt == i6)
        i();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public void a_(String paramString)
  {
    Toast.makeText(this, 2131165663, 1).show();
    boolean bool = com.jiayuan.a.a().a(MatchActivity.class);
    if ((this.p == null) || (!bool))
      return;
    this.p.dismiss();
  }

  public void b()
  {
    com.jiayuan.util.a.a("MatchActivity", "---------onWaitingActivityFinish()---------");
  }

  public void b(int paramInt)
  {
    Toast localToast = Toast.makeText(this, paramInt, 0);
    localToast.setGravity(48, 0, 70);
    localToast.show();
  }

  public void b(int paramInt1, int paramInt2)
  {
    String str = "onMatchOkResult index=" + paramInt1 + ", result=" + paramInt2;
    com.jiayuan.util.a.a("MatchActivity", str);
    switch (paramInt2)
    {
    case -126:
    default:
    case 1:
    case -100:
    case -123:
    case -111:
    case -125:
    case -115:
    case -113:
    case -112:
    case -116:
    case -117:
    case -118:
    case -119:
    case -120:
    case -121:
    case -122:
    case -124:
    case -127:
    case -128:
    case -129:
    case -130:
    }
    while (true)
    {
      return;
      b(2131165353);
      continue;
      b(2131165496);
      continue;
      b(2131165497);
      continue;
      b(2131165495);
      continue;
      b(2131165498);
      continue;
      b(2131165502);
      continue;
      b(2131165504);
      continue;
      showDialog(0);
      continue;
      b(2131165506);
      continue;
      b(2131165507);
      continue;
      b(2131165508);
      continue;
      b(2131165509);
      continue;
      b(2131165511);
      continue;
      b(2131165512);
      continue;
      b(2131165501);
      continue;
      b(2131165503);
    }
  }

  public void b(ArrayList paramArrayList)
  {
    int i1 = 1;
    StringBuilder localStringBuilder1 = new StringBuilder("onGetPhotoAmountForAlert  photoUrls.size()=");
    int i2 = paramArrayList.size();
    String str1 = i2;
    com.jiayuan.util.a.a("MatchActivity", str1);
    boolean bool1 = com.jiayuan.a.a().a(MainActivity.class);
    if (paramArrayList.size() != 0)
      return;
    this.b = i1;
    StringBuilder localStringBuilder2 = new StringBuilder("show none photo alert");
    boolean bool2 = this.b;
    String str2 = bool2;
    com.jiayuan.util.a.a("onGetPhotoAmountForAlert", str2);
    String str3 = "isTopActivity " + bool1;
    com.jiayuan.util.a.a("onGetPhotoAmountForAlert", str3);
    if (!bool1)
      return;
    showDialog(i1);
    this.b = null;
  }

  public void c()
  {
    boolean bool1 = true;
    boolean bool2 = null;
    com.jiayuan.util.a.a("MatchActivity", "refreshData");
    if (this.g != null)
      this.g.clear();
    if (this.h != null)
      this.h.clear();
    this.s = bool1;
    this.k = bool2;
    this.r = bool2;
    String str = getString(2131165195);
    ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
    this.p = localProgressDialog;
    this.p.setCancelable(bool1);
    j localj = this.f;
    boolean bool3 = this.c;
    boolean bool4 = this.s;
    localj.a(bool3, bool2);
  }

  public void d()
  {
  }

  public void onCreate(Bundle paramBundle)
  {
    Object localObject1 = 25;
    int i1 = 2131165228;
    Object localObject2 = null;
    Object localObject3 = 1;
    super.onCreate(paramBundle);
    setContentView(2130903065);
    Object localObject4 = this.q;
    Object localObject5 = new GestureDetector(this, (GestureDetector.OnGestureListener)localObject4);
    this.l = ((GestureDetector)localObject5);
    localObject5 = o.a;
    if (localObject5 != null)
    {
      localObject5 = o.a;
      localObject4 = "";
      localObject5 = ((String)localObject5).equals(localObject4);
      if (localObject5 == 0)
        break label84;
    }
    label83: return;
    label84: localObject5 = o.i;
    String str1;
    if (localObject5 != null)
    {
      localObject5 = new Intent(this, ProfileActivity.class);
      localObject4 = "sex";
      boolean bool1 = o.i().equals("0");
      if (!bool1)
        break label578;
      str1 = "f";
      label131: ((Intent)localObject5).putExtra((String)localObject4, str1);
      localObject4 = "uid";
      String str2 = o.i;
      ((Intent)localObject5).putExtra((String)localObject4, str1);
      startActivity((Intent)localObject5);
    }
    this.k = localObject2;
    localObject5 = (ImageView)findViewById(2131361928);
    this.m = ((ImageView)localObject5);
    this.m.setClickable(localObject3);
    localObject5 = this.m;
    localObject4 = new a(this);
    ((ImageView)localObject5).setOnClickListener((View.OnClickListener)localObject4);
    localObject5 = this.m;
    localObject4 = new b(this);
    ((ImageView)localObject5).setOnTouchListener((View.OnTouchListener)localObject4);
    localObject5 = (Button)findViewById(2131361932);
    this.a = ((Button)localObject5);
    localObject5 = this.a;
    localObject4 = new f(this);
    ((Button)localObject5).setOnClickListener((View.OnClickListener)localObject4);
    localObject5 = (Button)findViewById(2131361933);
    localObject4 = new g(this);
    ((Button)localObject5).setOnClickListener((View.OnClickListener)localObject4);
    localObject5 = o.d(this);
    localObject4 = o.e(this);
    this.n = localObject5;
    int i2 = localObject4 - localObject1 - localObject1;
    this.o = i2;
    Object localObject6 = new SimpleDateFormat("yyyy-MM-dd");
    localObject4 = com.jiayuan.util.b.c(this, i1);
    if (localObject4 != null)
    {
      String str3 = ((SimpleDateFormat)localObject6).format((Date)localObject4);
      Date localDate = Calendar.getInstance().getTime();
      localObject6 = ((SimpleDateFormat)localObject6).format(localDate).equalsIgnoreCase((String)localObject4);
      if (localObject6 == 0)
      {
        this.c = localObject3;
        localObject6 = new Date();
        com.jiayuan.util.b.a(this, i1, (Date)localObject6);
      }
      localObject6 = o.e();
      if (localObject6 != null)
      {
        localObject6 = o.e().equals("");
        if (localObject6 != 0);
      }
    }
    try
    {
      String str4 = getString(2131165195);
      localObject6 = ProgressDialog.show(this, "", str4);
      this.p = ((ProgressDialog)localObject6);
      localObject6 = this.p;
      ((ProgressDialog)localObject6).setCancelable(true);
      label493: localObject6 = new j(this);
      this.f = ((j)localObject6);
      localObject6 = this.f;
      boolean bool2 = this.c;
      boolean bool3 = this.s;
      ((j)localObject6).a(bool2, bool3);
      localObject6 = com.jiayuan.util.b.i(this);
      if (localObject6 != 0)
      {
        localObject6 = localObject2;
        this.d = ((Z)localObject6);
        if (this.d);
        showDialog(2);
        this.d = localObject2;
        break label83:
        label578: str1 = "m";
        break label131:
        this.c = localObject3;
        localObject6 = new Date();
        com.jiayuan.util.b.a(this, i1, (Date)localObject6);
      }
      localObject6 = localObject3;
    }
    catch (Exception localException)
    {
      break label493:
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
      break label493:
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131296258, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    com.jiayuan.util.a.a("MatchActivity", "onDestroy");
    com.jiayuan.a.a().d(this);
    super.onDestroy();
    System.gc();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    com.jiayuan.util.a.a("MatchActivity", "back key pressed");
    boolean bool1 = MainActivity.a(this, paramInt, paramKeyEvent);
    int i1;
    if (bool1)
    {
      com.jiayuan.util.a.a("MatchActivity", "back key pressed 000");
      i1 = 1;
    }
    while (true)
    {
      return i1;
      com.jiayuan.util.a.a("MatchActivity", "back key pressed 111");
      boolean bool2 = super.onKeyDown(paramInt, paramKeyEvent);
    }
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default:
    case 2131362248:
    case 2131362249:
    case 2131362250:
    }
    while (true)
    {
      label32: return true;
      Intent localIntent1 = new Intent(this, MyMateSelectionActivity.class);
      startActivity(localIntent1);
      continue;
      if ((this.g == null) || (this.g.isEmpty()))
        continue;
      Intent localIntent2 = new Intent(this, MailSendActivity.class);
      Bundle localBundle = new Bundle();
      if (this.r)
      {
        String str1 = this.i.a;
        localBundle.putString("to_id", str1);
        String str2 = this.i.d;
        localBundle.putString("nickname", str2);
        StringBuilder localStringBuilder1 = new StringBuilder("mUid=");
        String str3 = this.i.a;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str3).append("Nickname=");
        String str4 = this.i.d;
        String str5 = str4;
        com.jiayuan.util.a.a("MatchActivity", str5);
      }
      while (true)
      {
        localIntent2.putExtras(localBundle);
        startActivity(localIntent2);
        break label32:
        ArrayList localArrayList1 = this.g;
        int i1 = this.k;
        String str6 = ((k)localArrayList1.get(i1)).a;
        localBundle.putString("to_id", str6);
        ArrayList localArrayList2 = this.g;
        int i2 = this.k;
        String str7 = ((k)localArrayList2.get(i2)).d;
        localBundle.putString("nickname", str7);
        StringBuilder localStringBuilder3 = new StringBuilder("mUid=");
        ArrayList localArrayList3 = this.g;
        int i3 = this.k;
        String str8 = ((k)localArrayList3.get(i3)).a;
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str8).append("Nickname=");
        ArrayList localArrayList4 = this.g;
        int i4 = this.k;
        String str9 = ((k)localArrayList4.get(i4)).d;
        String str10 = str9;
        com.jiayuan.util.a.a("MatchActivity", str10);
      }
      c();
    }
  }

  public void onStart()
  {
    super.onStart();
    boolean bool1 = com.jiayuan.a.a().a(MainActivity.class);
    StringBuilder localStringBuilder = new StringBuilder("show none photo alert ");
    boolean bool2 = this.b;
    String str1 = bool2;
    com.jiayuan.util.a.a("onStart", str1);
    String str2 = "is top activity " + bool1;
    com.jiayuan.util.a.a("onStart", str2);
    if ((!this.b) || (!bool1))
      return;
    showDialog(1);
    this.b = null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.MatchActivity
 * JD-Core Version:    0.5.4
 */