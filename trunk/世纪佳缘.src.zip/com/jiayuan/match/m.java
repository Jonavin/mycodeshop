package com.jiayuan.match;

import java.util.ArrayList;
import java.util.List;

public abstract interface m
{
  public abstract void a();

  public abstract void a(List paramList);

  public abstract void a_(String paramString);

  public abstract void b();

  public abstract void b(ArrayList paramArrayList);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.m
 * JD-Core Version:    0.5.4
 */