package com.jiayuan.match;

public class k
{
  public String a;
  public String b;
  public int c;
  public String d;
  public String e;
  public String f;
  public boolean g = true;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.k
 * JD-Core Version:    0.5.4
 */