package com.jiayuan.match;

import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import com.jiayuan.util.o;

class c
  implements GestureDetector.OnGestureListener
{
  c(MatchActivity paramMatchActivity)
  {
  }

  public boolean onDown(MotionEvent paramMotionEvent)
  {
    return null;
  }

  public boolean onFling(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    Object localObject = null;
    float f1 = paramMotionEvent1.getX();
    float f2 = paramMotionEvent2.getX();
    f1 = Math.abs(f1 - f2);
    float f3 = paramMotionEvent1.getX();
    float f4 = paramMotionEvent2.getX();
    if (f3 - f4 > localObject)
    {
      float f5 = o.d(this.a.e) / 4;
      if (f1 > f5)
        MatchActivity.a(this.a);
    }
    while (true)
    {
      return true;
      float f6 = paramMotionEvent1.getX();
      float f7 = paramMotionEvent2.getX();
      if (f6 - f7 >= localObject)
        continue;
      float f8 = o.d(this.a.e) / 4;
      if (f1 <= f8)
        continue;
      MatchActivity.b(this.a);
    }
  }

  public void onLongPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onScroll(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    return null;
  }

  public void onShowPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onSingleTapUp(MotionEvent paramMotionEvent)
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.c
 * JD-Core Version:    0.5.4
 */