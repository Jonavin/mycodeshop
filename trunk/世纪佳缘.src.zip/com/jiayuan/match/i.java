package com.jiayuan.match;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.util.b;

class i
  implements DialogInterface.OnClickListener
{
  i(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    b.d(this.a, true);
    b.c(this.a, true);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.i
 * JD-Core Version:    0.5.4
 */