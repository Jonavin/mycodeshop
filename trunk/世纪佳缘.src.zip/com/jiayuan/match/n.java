package com.jiayuan.match;

import java.util.Comparator;

public class n
  implements Comparator
{
  public n(j paramj)
  {
  }

  public int a(k paramk1, k paramk2)
  {
    float f1 = Float.parseFloat(paramk1.f);
    float f3 = Float.parseFloat(paramk2.f);
    int i;
    if (f1 < f3)
      i = -1;
    while (true)
    {
      return i;
      float f2;
      i <= f3;
      if (f2 > 0)
        int j = 1;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.n
 * JD-Core Version:    0.5.4
 */