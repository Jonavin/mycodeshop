package com.jiayuan.match;

import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(View paramView)
  {
    MatchActivity.a(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.g
 * JD-Core Version:    0.5.4
 */