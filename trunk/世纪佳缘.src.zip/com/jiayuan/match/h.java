package com.jiayuan.match;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.MainActivity;
import com.jiayuan.a;

class h
  implements DialogInterface.OnClickListener
{
  h(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ((MainActivity)a.a().d(MainActivity.class)).a(4);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.h
 * JD-Core Version:    0.5.4
 */