package com.jiayuan.match;

import android.view.View;
import android.view.View.OnClickListener;

class f
  implements View.OnClickListener
{
  f(MatchActivity paramMatchActivity)
  {
  }

  public void onClick(View paramView)
  {
    MatchActivity.e(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.match.f
 * JD-Core Version:    0.5.4
 */