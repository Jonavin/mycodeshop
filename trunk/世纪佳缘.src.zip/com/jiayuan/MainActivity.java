package com.jiayuan;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.mail.MailHomeActivity;
import com.jiayuan.mail.detail.af;
import com.jiayuan.mail.detail.g;
import com.jiayuan.match.MatchActivity;
import com.jiayuan.myprofile.MyProfileActivity;
import com.jiayuan.search.SearchResultActivity;
import com.jiayuan.service.ServiceActivity;
import com.jiayuan.util.o;
import java.lang.reflect.Field;

public class MainActivity extends TabActivity
  implements af
{
  private static TextView e;
  TabHost a;
  private Field b;
  private Field c;
  private int d = 2;

  public static void a()
  {
    StringBuffer localStringBuffer = new StringBuffer("淇");
    localStringBuffer.append("(");
    int i = o.h;
    localStringBuffer.append(i);
    localStringBuffer.append(")");
    TextView localTextView = e;
    String str = localStringBuffer.toString();
    localTextView.setText(str);
    e.setHorizontallyScrolling(true);
  }

  public static boolean a(Activity paramActivity, int paramInt, KeyEvent paramKeyEvent)
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    com.jiayuan.util.a.a("MainActivity", "hanndleChildBackButtonPress");
    int i = 4;
    Object localObject3;
    if (paramInt == i)
    {
      localObject3 = a.a();
      StringBuilder localStringBuilder = new StringBuilder("screenManager.activityCount()=");
      int j = ((a)localObject3).c();
      String str = j;
      com.jiayuan.util.a.a("MainActivity", str);
      localObject3 = ((a)localObject3).c();
      if (localObject1 == localObject3)
      {
        localObject3 = new AlertDialog.Builder(paramActivity).setTitle(2131165201).setMessage(2131165202);
        c localc = new c(paramActivity);
        localObject3 = ((AlertDialog.Builder)localObject3).setPositiveButton(2131165204, localc);
        b localb = new b();
        ((AlertDialog.Builder)localObject3).setNegativeButton(2131165203, localb).create().show();
        localObject3 = localObject1;
      }
    }
    while (true)
    {
      return localObject3;
      localObject3 = localObject2;
      continue;
      localObject3 = localObject2;
    }
  }

  public void a(int paramInt)
  {
    com.jiayuan.util.a.a("MainActivity", "setSelectedTab");
    this.a.setCurrentTab(paramInt);
  }

  public void b()
  {
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b(int paramInt)
  {
    o.h = paramInt;
    String str1 = getResources().getString(2131165340);
    StringBuffer localStringBuffer = new StringBuffer(str1);
    localStringBuffer.append("(");
    int i = o.h;
    localStringBuffer.append(i);
    localStringBuffer.append(")");
    TextView localTextView = e;
    String str2 = localStringBuffer.toString();
    localTextView.setText(str2);
    e.setHorizontallyScrolling(true);
  }

  public void onCreate(Bundle paramBundle)
  {
    int i = 16908310;
    int j = 1;
    int k = 2130837705;
    Object localObject1 = 0;
    super.onCreate(paramBundle);
    a locala = a.a();
    locala.c(this);
    locala.d(this);
    TabHost localTabHost1 = getTabHost();
    this.a = localTabHost1;
    TabHost localTabHost2 = this.a;
    Object localObject2 = this.a.newTabSpec("tabSpecMatch");
    Object localObject3 = getString(2131165339);
    localObject2 = ((TabHost.TabSpec)localObject2).setIndicator((CharSequence)localObject3);
    localObject3 = new Intent(this, MatchActivity.class);
    localObject2 = ((TabHost.TabSpec)localObject2).setContent((Intent)localObject3);
    localTabHost2.addTab((TabHost.TabSpec)localObject2);
    TabHost localTabHost3 = this.a;
    localObject2 = this.a.newTabSpec("tabSpecMail");
    localObject3 = getString(2131165340);
    localObject2 = ((TabHost.TabSpec)localObject2).setIndicator((CharSequence)localObject3);
    localObject3 = new Intent(this, MailHomeActivity.class);
    localObject2 = ((TabHost.TabSpec)localObject2).setContent((Intent)localObject3);
    localTabHost3.addTab((TabHost.TabSpec)localObject2);
    TabHost localTabHost4 = this.a;
    localObject2 = this.a.newTabSpec("tabSpecSearch");
    localObject3 = getString(2131165341);
    localObject2 = ((TabHost.TabSpec)localObject2).setIndicator((CharSequence)localObject3);
    localObject3 = new Intent(this, SearchResultActivity.class);
    localObject2 = ((TabHost.TabSpec)localObject2).setContent((Intent)localObject3);
    localTabHost4.addTab((TabHost.TabSpec)localObject2);
    TabHost localTabHost5 = this.a;
    localObject2 = this.a.newTabSpec("tabSpecService");
    localObject3 = getString(2131165343);
    localObject2 = ((TabHost.TabSpec)localObject2).setIndicator((CharSequence)localObject3);
    localObject3 = new Intent(this, ServiceActivity.class);
    localObject2 = ((TabHost.TabSpec)localObject2).setContent((Intent)localObject3);
    localTabHost5.addTab((TabHost.TabSpec)localObject2);
    TabHost localTabHost6 = this.a;
    localObject2 = this.a.newTabSpec("tabSpecProfile");
    localObject3 = getString(2131165342);
    localObject2 = ((TabHost.TabSpec)localObject2).setIndicator((CharSequence)localObject3);
    localObject3 = new Intent(this, MyProfileActivity.class);
    localObject2 = ((TabHost.TabSpec)localObject2).setContent((Intent)localObject3);
    localTabHost6.addTab((TabHost.TabSpec)localObject2);
    int l = getIntent().getIntExtra("tabIndex", localObject1);
    this.a.setCurrentTab(l);
    TabHost localTabHost7 = this.a;
    localObject2 = new d(this);
    localTabHost7.setOnTabChangedListener((TabHost.OnTabChangeListener)localObject2);
    localObject2 = this.a.getTabWidget();
    localObject3 = ((TabWidget)localObject2).getChildCount();
    Object localObject4 = localObject1;
    if (localObject4 >= localObject3)
    {
      label421: String str1 = Build.VERSION.RELEASE.substring(localObject1, 3);
      String str2 = "sdk_version=" + str1;
      com.jiayuan.util.a.a("MainActivity", str2);
      if (Float.valueOf(str1).floatValue() > 4611911198408756429L)
        break label831;
    }
    try
    {
      Field localField1 = localObject2.getClass().getDeclaredField("mBottomLeftStrip");
      this.b = localField1;
      Field localField2 = localObject2.getClass().getDeclaredField("mBottomRightStrip");
      this.c = localField2;
      if (!this.b.isAccessible())
        this.b.setAccessible(true);
      if (!this.c.isAccessible())
        this.c.setAccessible(true);
      Field localField3 = this.b;
      Drawable localDrawable1 = getResources().getDrawable(2130837705);
      localField3.set(localObject2, localDrawable1);
      Field localField4 = this.c;
      Drawable localDrawable2 = getResources().getDrawable(2130837705);
      localField4.set(localObject2, localDrawable2);
      if ((o.a != null) && (!o.a.equals("")))
        label608: new g(this).a();
      e = (TextView)((TabWidget)localObject2).getChildAt(j).findViewById(i);
      return;
      TextView localTextView = (TextView)((TabWidget)localObject2).getChildAt(localObject4).findViewById(i);
      localTextView.setPadding(localObject1, 4, localObject1, localObject1);
      ColorStateList localColorStateList = getResources().getColorStateList(17170443);
      localTextView.setTextColor(localColorStateList);
      int i1;
      switch (localObject4)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
        while (true)
        {
          localObject4 += 1;
          break label421:
          ((TabWidget)localObject2).getChildAt(i1).setBackgroundResource(2130837690);
          continue;
          ((TabWidget)localObject2).getChildAt(i1).setBackgroundResource(2130837636);
          continue;
          ((TabWidget)localObject2).getChildAt(i1).setBackgroundResource(2130837699);
          continue;
          ((TabWidget)localObject2).getChildAt(i1).setBackgroundResource(2130837702);
        }
      case 4:
      }
      label831: ((TabWidget)localObject2).getChildAt(i1).setBackgroundResource(2130837693);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      break label608:
      ((TabWidget)localObject2).setLeftStripDrawable(k);
      ((TabWidget)localObject2).setRightStripDrawable(k);
      break label608:
    }
  }

  public void onDestroy()
  {
    com.jiayuan.util.a.a("MainActivity", "onDestroy");
    a locala = a.a();
    locala.b(this);
    locala.d(this);
    super.onDestroy();
  }

  public void onResume()
  {
    super.onResume();
  }

  public void onStart()
  {
    super.onStart();
    com.jiayuan.util.a.a("MainActivity", "onStart");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.MainActivity
 * JD-Core Version:    0.5.4
 */