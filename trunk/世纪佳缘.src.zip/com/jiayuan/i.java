package com.jiayuan;

import android.content.Context;
import android.content.Intent;
import com.a.a.bh;
import com.a.a.bv;
import com.a.a.h;
import com.jiayuan.home.HomeActivity;
import com.jiayuan.system.service.JiayuanService;
import com.jiayuan.util.a;
import com.jiayuan.util.b;

class i
  implements h
{
  i(SplashActivity paramSplashActivity)
  {
  }

  public bv a(bh parambh)
  {
    return null;
  }

  public void a()
  {
    a.a("SplashActivity", "splash handleSuccess");
  }

  public void b()
  {
    Context localContext1 = this.a.d;
    String str1 = this.a.a;
    b.d(localContext1, str1);
    StringBuilder localStringBuilder = new StringBuilder("splash Preference");
    String str2 = b.l(this.a.d);
    String str3 = str2;
    a.a("SplashActivity", str3);
    Context localContext2 = this.a.d;
    Intent localIntent1 = new Intent(localContext2, JiayuanService.class);
    this.a.d.startService(localIntent1);
    SplashActivity localSplashActivity = this.a;
    Context localContext3 = this.a.d;
    Intent localIntent2 = new Intent(localContext3, HomeActivity.class);
    localSplashActivity.startActivity(localIntent2);
    this.a.finish();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.i
 * JD-Core Version:    0.5.4
 */