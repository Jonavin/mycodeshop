package com.jiayuan.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class SmsSendReceiver extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i = 2131165479;
    int j = 0;
    switch (getResultCode())
    {
    case 0:
    default:
    case -1:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      Toast.makeText(paramContext, 2131165478, j).show();
      continue;
      Toast.makeText(paramContext, i, j).show();
      continue;
      Toast.makeText(paramContext, i, j).show();
      continue;
      Toast.makeText(paramContext, i, j).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.receiver.SmsSendReceiver
 * JD-Core Version:    0.5.4
 */