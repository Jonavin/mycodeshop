package com.jiayuan;

import android.app.Activity;
import java.util.ArrayList;
import java.util.Stack;

public class a
{
  private static Stack a;
  private static a b;

  public static a a()
  {
    if (b == null)
      b = new a();
    return b;
  }

  public boolean a(Activity paramActivity)
  {
    int i = 1;
    int j = 0;
    int k = a.size();
    if (k == i)
    {
      Object localObject = paramActivity.getClass().getName();
      String str = ((Activity)a.get(j)).getClass().getName();
      localObject = ((String)localObject).equals(str);
      if (localObject == 0);
    }
    for (int l = i; ; l = j)
      return l;
  }

  public boolean a(Class paramClass)
  {
    int i = 1;
    int j = a.size();
    int k;
    if (j > 0)
    {
      Stack localStack = a;
      j -= i;
      Object localObject1 = ((Activity)localStack.get(j)).getClass();
      localObject1 = localObject1.equals(localObject1);
      if (localObject1 != 0)
        k = i;
    }
    while (true)
    {
      return k;
      Object localObject2 = null;
    }
  }

  public Activity b()
  {
    int i = a.size();
    Activity localActivity;
    if (i != 0)
      localActivity = (Activity)a.lastElement();
    while (true)
    {
      return localActivity;
      int j = 0;
    }
  }

  public void b(Activity paramActivity)
  {
    if (paramActivity == null)
      return;
    paramActivity.finish();
    a.remove(paramActivity);
  }

  public void b(Class paramClass)
  {
    ArrayList localArrayList = new ArrayList();
    int i = a.size() - 1;
    if (i < 0)
      i = 0;
    while (true)
    {
      int j = localArrayList.size();
      if (i >= j)
      {
        return;
        String str1 = "indexs[" + i + "]=" + i;
        com.jiayuan.util.a.a("ScreenManager", str1);
        if (!((Activity)a.elementAt(i)).getClass().equals(paramClass))
        {
          Integer localInteger = Integer.valueOf(i);
          localArrayList.add(localInteger);
        }
        i += -1;
      }
      StringBuilder localStringBuilder = new StringBuilder("indexs[").append(i).append("]=");
      Object localObject = localArrayList.get(i);
      String str2 = localObject;
      com.jiayuan.util.a.a("ScreenManager", str2);
      Stack localStack = a;
      int k = ((Integer)localArrayList.get(i)).intValue();
      Activity localActivity = (Activity)localStack.elementAt(k);
      b(localActivity);
      i += 1;
    }
  }

  public int c()
  {
    return a.size();
  }

  public void c(Activity paramActivity)
  {
    if (a == null)
      a = new Stack();
    a.add(paramActivity);
  }

  public void c(Class paramClass)
  {
    for (int i = 0; ; ++i)
    {
      int j = a.size();
      if (i >= j)
        return;
      if (!((Activity)a.elementAt(i)).getClass().equals(paramClass))
        continue;
      ((Activity)a.elementAt(i)).finish();
      a.remove(i);
    }
  }

  public Activity d(Class paramClass)
  {
    Activity localActivity;
    for (int i = 0; ; ++localActivity)
    {
      int j = a.size();
      if (i >= j)
        i = 0;
      while (true)
      {
        return i;
        if (!((Activity)a.elementAt(i)).getClass().equals(paramClass))
          break;
        localActivity = (Activity)a.elementAt(i);
      }
    }
  }

  public void d(Activity paramActivity)
  {
    com.jiayuan.util.a.a("ScreenManager", "----- activityStack ----- HUA -- LI -- DE -- FEN -- GE -- XIAN ----- activityStack -----");
    for (int i = 0; ; ++i)
    {
      int j = a.size();
      if (i >= j)
        return;
      String str1 = paramActivity.getClass().toString();
      StringBuilder localStringBuilder = new StringBuilder("activityStack[").append(i).append("]=");
      String str2 = ((Activity)a.elementAt(i)).getClass().toString();
      String str3 = str2;
      com.jiayuan.util.a.a(str1, str3);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a
 * JD-Core Version:    0.5.4
 */