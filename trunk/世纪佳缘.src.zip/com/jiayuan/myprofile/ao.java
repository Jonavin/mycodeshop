package com.jiayuan.myprofile;

import android.content.Context;
import android.graphics.Bitmap;
import com.jiayuan.a.i;
import com.jiayuan.a.z;
import com.jiayuan.util.a;
import java.util.ArrayList;

public class ao
  implements i
{
  public ab a;
  private String b;
  private int c;
  private int d;
  private Context e;

  public ao(ab paramab, String paramString, int paramInt1, int paramInt2)
  {
    this.a = paramab;
    Context localContext = (Context)paramab;
    this.e = paramab;
    this.b = paramString;
    this.c = paramInt1;
    this.d = paramInt2;
  }

  public void a()
  {
    a.a("MyProfilePhotoDataProcessing", "execute()");
    this.a.a();
    Context localContext = this.e;
    String str = this.b;
    int i = this.c;
    int j = this.d;
    ao localao = this;
    new z(localContext, localao, str, 1, "100", -1, i, j).a();
  }

  public void a(ArrayList paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder("onGetPhotoAmount photoUrls.size()=");
    int i = paramArrayList.size();
    String str = i;
    a.a("MyProfilePhotoDataProcessing", str);
    this.a.a(paramArrayList);
  }

  public void a_(int paramInt, String paramString, Bitmap paramBitmap)
  {
    String str = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    a.a("MyProfilePhotoDataProcessing", str);
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a_(String paramString)
  {
    this.a.a_(paramString);
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ao
 * JD-Core Version:    0.5.4
 */