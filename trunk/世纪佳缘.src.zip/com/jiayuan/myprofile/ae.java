package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class ae
  implements View.OnClickListener
{
  ae(MyProfileActivity paramMyProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyProfileActivity.a(this.a, paramView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ae
 * JD-Core Version:    0.5.4
 */