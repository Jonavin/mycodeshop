package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class ad
  implements View.OnClickListener
{
  ad(MyProfileActivity paramMyProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyProfileActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ad
 * JD-Core Version:    0.5.4
 */