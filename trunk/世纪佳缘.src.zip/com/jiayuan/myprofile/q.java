package com.jiayuan.myprofile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class q
  implements DialogInterface.OnClickListener
{
  q(MyProfilePhotoGalleryActivity paramMyProfilePhotoGalleryActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.a.a();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.q
 * JD-Core Version:    0.5.4
 */