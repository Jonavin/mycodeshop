package com.jiayuan.myprofile;

import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class o
  implements q
{
  public aa a;
  private String b;
  private String c;
  private String d;

  public o(aa paramaa, String paramString1, String paramString2)
  {
    this.a = paramaa;
    this.b = paramString1;
    this.c = paramString2;
    int j = this.c.lastIndexOf("/");
    ++j;
    int k = this.c.lastIndexOf(".") - i;
    Object localObject = paramString2.substring(j, k);
    localObject = Pattern.compile("(\\d+)").matcher((CharSequence)localObject);
    while (true)
    {
      if (!((Matcher)localObject).find())
      {
        StringBuilder localStringBuilder = new StringBuilder("mPid=");
        String str1 = this.d;
        String str2 = str1;
        a.a("PhotoDeleteDataProcessing", str2);
        return;
      }
      String str3 = ((Matcher)localObject).group(i);
      this.d = str3;
    }
  }

  public void a()
  {
    a.a("PhotoDeleteDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("photo/http_delete.php?");
    localStringBuffer.append("uid=");
    String str1 = com.jiayuan.util.o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&type=");
    String str2 = this.b;
    localStringBuffer.append(str2);
    localStringBuffer.append("&pid=");
    String str3 = this.d;
    localStringBuffer.append(str3);
    localStringBuffer.append("&token=");
    String str4 = com.jiayuan.util.o.f();
    localStringBuffer.append(str4);
    l locall = new l();
    locall.a = this;
    String str5 = localStringBuffer.toString();
    locall.b(str5);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("PhotoDeleteDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        this.a.b();
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("PhotoDeleteDataProcessing", str2);
        this.a.c();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("PhotoDeleteDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("PhotoDeleteDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("PhotoDeleteDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.o
 * JD-Core Version:    0.5.4
 */