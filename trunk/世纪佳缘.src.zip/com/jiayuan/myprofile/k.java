package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class k
  implements View.OnClickListener
{
  k(MyMateSelectionActivity paramMyMateSelectionActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyMateSelectionActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.k
 * JD-Core Version:    0.5.4
 */