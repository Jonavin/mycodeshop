package com.jiayuan.myprofile;

import android.content.Context;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class f
  implements q
{
  public p a;
  public Context b;
  private String c;

  public f(p paramp, String paramString)
  {
    this.a = paramp;
    Context localContext = (Context)paramp;
    this.b = paramp;
    this.c = paramString;
  }

  public void a(int paramInt, String paramString)
  {
    a.a("SubmitMyProfileDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        String str1 = new JSONObject(paramString).getString("retcode");
        this.a.b(str1);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str2 = localJSONException.toString();
        String str3 = str2;
        a.a("SubmitMyProfileDataProcessing", str3);
        this.a.d();
      }
    }
  }

  public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11)
  {
    String str1;
    try
    {
      str1 = URLEncoder.encode(paramString11, "UTF-8");
      this.a.c();
      StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer.append("uic/infoupdate.php?");
      localStringBuffer.append("uid=");
      String str2 = this.c;
      localStringBuffer.append(str2);
      localStringBuffer.append("&token=");
      String str3 = o.f();
      localStringBuffer.append(str3);
      localStringBuffer.append("&userinfo={");
      localStringBuffer.append("\"");
      localStringBuffer.append(106);
      localStringBuffer.append("\":\"");
      String str4 = com.jiayuan.util.f.h(this.b, paramString1);
      localStringBuffer.append(str4);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(100);
      localStringBuffer.append("\":\"");
      localStringBuffer.append(paramString2);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(101);
      localStringBuffer.append("\":\"");
      localStringBuffer.append(paramString3);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(116);
      localStringBuffer.append("\":\"");
      String str5 = com.jiayuan.util.f.i(this.b, paramString4);
      localStringBuffer.append(str5);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(111);
      localStringBuffer.append("\":\"");
      String str6 = com.jiayuan.util.f.j(this.b, paramString5);
      localStringBuffer.append(str6);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(107);
      localStringBuffer.append("\":\"");
      String str7 = com.jiayuan.util.f.k(this.b, paramString6);
      localStringBuffer.append(str7);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(114);
      localStringBuffer.append("\":\"");
      String str8 = com.jiayuan.util.f.g(this.b, paramString7);
      localStringBuffer.append(str8);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(121);
      localStringBuffer.append("\":\"");
      String str9 = com.jiayuan.util.f.l(this.b, paramString8);
      localStringBuffer.append(str9);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(125);
      localStringBuffer.append("\":\"");
      String str10 = com.jiayuan.util.f.n(this.b, paramString10);
      localStringBuffer.append(str10);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(231);
      localStringBuffer.append("\":\"");
      localStringBuffer.append(str1);
      localStringBuffer.append("\",\"");
      localStringBuffer.append(122);
      localStringBuffer.append("\":\"");
      String str11 = com.jiayuan.util.f.m(this.b, paramString9);
      localStringBuffer.append(str1);
      localStringBuffer.append("\"}");
      l locall = new l();
      str1.a = this;
      String str12 = localStringBuffer.toString();
      str1.b(str12);
      return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      localUnsupportedEncodingException.printStackTrace();
      str1 = paramString11;
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("SubmitMyProfileDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("SubmitMyProfileDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("SubmitMyProfileDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.f
 * JD-Core Version:    0.5.4
 */