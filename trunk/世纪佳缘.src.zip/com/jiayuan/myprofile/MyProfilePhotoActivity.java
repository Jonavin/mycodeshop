package com.jiayuan.myprofile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager.BadTokenException;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.e;
import com.jiayuan.util.m;
import com.jiayuan.util.n;
import com.jiayuan.util.o;
import com.jiayuan.util.q;
import com.jiayuan.util.r;
import com.jiayuan.util.s;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class MyProfilePhotoActivity extends MyActivity
  implements ab, e, n
{
  Context a = this;
  public z b;
  private ArrayList c;
  private ArrayList d;
  private int e = 998;
  private final int f = null;
  private final int g = 1;
  private r h = null;
  private Bitmap i = null;
  private int j;
  private int k;
  private int l;
  private int m;
  private ProgressDialog n;
  private ProgressDialog o;
  private int p = null;

  private View b()
  {
    return (ListView)findViewById(2131361991);
  }

  private void c()
  {
    if (this.c != null)
      this.c.clear();
    if (this.d != null)
      this.d.clear();
    this.p = null;
    String str = o.e();
    int i1 = this.j;
    int i2 = this.k;
    new ao(this, str, i1, i2).a();
  }

  public void a()
  {
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.o = localProgressDialog;
      this.o.setCancelable(true);
      a.a("MyProfilePhotoActivity", "---------onWaitingActivityStart()---------");
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void a(int paramInt, Bitmap paramBitmap)
  {
    Bitmap localBitmap1 = s.a(paramBitmap);
    this.i = localBitmap1;
    s.b(this.i);
    if (this.i != null)
    {
      ArrayList localArrayList = this.d;
      Bitmap localBitmap2 = this.i;
      localArrayList.add(localBitmap2);
      this.c.add("");
      this.b.notifyDataSetChanged();
    }
    if (this.i == null)
      return;
    Bitmap localBitmap3 = this.i;
    new m(this, "photo", localBitmap3).a();
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    String str = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    a.a("MyProfilePhotoActivity", str);
    int i1 = this.p;
    this.p = (++i1);
    if (paramBitmap == null)
    {
      boolean bool = o.l().equals("m");
      if (!bool);
    }
    for (Bitmap localBitmap = BitmapFactory.decodeResource(getResources(), 2130837630); ; localBitmap = paramBitmap)
      while (true)
      {
        this.d.set(paramInt, localBitmap);
        this.b.notifyDataSetChanged();
        int i2 = this.p;
        int i3 = this.d.size();
        if (localBitmap == i3)
        {
          this.o.dismiss();
          this.p = null;
        }
        return;
        localBitmap = BitmapFactory.decodeResource(getResources(), 2130837628);
      }
  }

  public void a(String paramString)
  {
    int i1 = 1;
    this.n.dismiss();
    String str1 = "onPhotoUploadReturn aResult=" + paramString;
    a.a("MyProfilePhotoActivity", str1);
    while (true)
      try
      {
        if (new JSONObject(paramString).getString("retcode").equalsIgnoreCase("1"))
        {
          Toast.makeText(this, 2131165638, 1).show();
          if (this.c != null)
            this.c.clear();
          if (this.d != null)
            this.d.clear();
          String str2 = o.e();
          int i2 = this.j;
          int i3 = this.k;
          new ao(this, str2, i2, i3).a();
          return;
        }
        Toast.makeText(this, 2131165639, 1).show();
        ArrayList localArrayList1 = this.d;
        int i4 = this.d.size() - i1;
        localArrayList1.remove(i4);
        ArrayList localArrayList2 = this.c;
        int i5 = this.c.size() - i1;
        localArrayList2.remove(i5);
        this.b.notifyDataSetChanged();
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public void a(ArrayList paramArrayList)
  {
    a.a("MyProfilePhotoActivity", "----------------onGetPhotoAmount()----------------");
    Object localObject = new StringBuilder("onGetPhotoAmount photoUrls.size()=");
    int i3 = paramArrayList.size();
    localObject = i3;
    a.a("MyProfilePhotoActivity", (String)localObject);
    int i4 = paramArrayList.size();
    if (i4 == 0)
    {
      a.a("MyProfilePhotoActivity", "abort gallery construct");
      int i1 = 1;
      localToast = Toast.makeText(this, 2131165585, i1);
      localToast.show();
    }
    this.c = paramArrayList;
    Toast localToast = null;
    label79: int i2 = paramArrayList.size();
    if (localToast >= i2)
    {
      GridView localGridView = (GridView)findViewById(2131361990);
      z localz1 = new z(this, this);
      this.b = localz1;
      z localz2 = this.b;
      localGridView.setAdapter(localz2);
      ah localah = new ah(this);
      localGridView.setOnItemClickListener(localah);
      return;
    }
    boolean bool = o.l().equals("m");
    if (bool);
    for (Bitmap localBitmap = BitmapFactory.decodeResource(getResources(), 2130837631); ; localBitmap = BitmapFactory.decodeResource(getResources(), 2130837629))
    {
      this.d.add(localBitmap);
      ++localToast;
      break label79:
    }
  }

  public void a_(String paramString)
  {
    if (this.n != null)
      this.n.dismiss();
    if (this.o != null)
      this.o.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void d()
  {
    if (this.n != null)
      this.n.dismiss();
    if (this.o == null)
      return;
    this.o.dismiss();
  }

  public void g()
  {
    try
    {
      String str = getResources().getString(2131165593);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.n = localProgressDialog;
      this.n.setCancelable(true);
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    Object localObject = "requestCode=" + paramInt1;
    a.a("MyProfilePhotoActivity", (String)localObject);
    String str1 = "resultCode=";
    localObject = str1 + paramInt2;
    a.a("MyProfilePhotoActivity", (String)localObject);
    label108: ArrayList localArrayList;
    if (this.e == paramInt1)
    {
      if ((paramInt2 != 0) && (-1 == paramInt2))
      {
        localObject = "11111";
        a.a("MyProfilePhotoActivity", (String)localObject);
      }
      localObject = paramIntent.getExtras().getStringArrayList("delete_indexs");
      int i1 = 0;
      int i3 = ((ArrayList)localObject).size();
      if (i1 >= i3)
      {
        localArrayList = new ArrayList();
        int i4 = ((ArrayList)localObject).size() - 1;
        label140: if (i4 >= 0)
          break label209;
        this.b.notifyDataSetChanged();
      }
    }
    while (true)
    {
      return;
      String str2 = "MyProfilePhotoActivity";
      StringBuilder localStringBuilder = new StringBuilder("deleted index=");
      String str3 = (String)((ArrayList)localObject).get(localArrayList);
      String str4 = str3;
      a.a(str2, str4);
      int i2;
      localArrayList += 1;
      break label108:
      label209: int i6 = Integer.parseInt((String)((ArrayList)localObject).get(str2));
      String str5 = (String)this.c.get(i6);
      i2.add(str5);
      this.d.remove(i6);
      this.c.remove(i6);
      int i5;
      str2 += -1;
      break label140:
      if ((123 != paramInt1) && (456 != paramInt1))
        continue;
      String str6 = "asdfadsf 000 requestCode" + paramInt1;
      a.a("MyProfilePhotoActivity", str6);
      if (this.h == null)
        continue;
      a.a("MyProfilePhotoActivity", "asdfadsf 111");
      this.h.a(paramInt1, paramInt2, paramIntent);
    }
  }

  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    Object localObject1 = 1;
    Object localObject2 = (AdapterView.AdapterContextMenuInfo)paramMenuItem.getMenuInfo();
    localObject2 = this.h;
    if (localObject2 == null)
    {
      localObject2 = new r(this, 0);
      this.h = ((r)localObject2);
    }
    localObject2 = paramMenuItem.getItemId();
    switch (localObject2)
    {
    default:
    case 0:
    case 1:
    }
    for (localObject2 = localObject1; ; localObject2 = localObject1)
    {
      while (true)
      {
        return localObject2;
        this.h.a();
        localObject2 = localObject1;
      }
      this.h.b();
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903074);
    int i1 = o.d(this);
    this.l = i1;
    int i2 = o.e(this);
    this.m = i2;
    int i3 = this.l / 2;
    this.j = i3;
    int i4 = this.m / 2;
    this.k = i4;
    ArrayList localArrayList1 = new ArrayList();
    this.d = localArrayList1;
    ArrayList localArrayList2 = new ArrayList();
    this.c = localArrayList2;
    String str = o.e();
    int i5 = this.j;
    int i6 = this.k;
    new ao(this, str, i5, i6).a();
    View localView = b();
    registerForContextMenu(localView);
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    super.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
    paramContextMenu.setHeaderTitle("閫夋");
    paramContextMenu.add(0, 0, 0, "鐩告").setIcon(2130837645);
    paramContextMenu.add(0, 1, 0, "鎵嬫").setIcon(2130837648);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131296260, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  public void onDestroy()
  {
    q.a(this);
    super.onDestroy();
    System.gc();
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    View localView1 = 1;
    int i1 = paramMenuItem.getItemId();
    boolean bool;
    switch (i1)
    {
    default:
      bool = super.onOptionsItemSelected(paramMenuItem);
    case 2131362254:
    case 2131362255:
    }
    while (true)
    {
      return bool;
      View localView2 = b();
      openContextMenu(localView2);
      localView2 = localView1;
      continue;
      c();
      localView2 = localView1;
    }
  }

  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    int i1 = null;
    MenuItem localMenuItem = paramMenu.getItem(i1);
    if (this.d.size() == 6)
      localMenuItem.setEnabled(i1);
    while (true)
    {
      return super.onPrepareOptionsMenu(paramMenu);
      localMenuItem.setEnabled(true);
    }
  }

  protected void onResume()
  {
    super.onResume();
    a.a("MyProfilePhotoActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.MyProfilePhotoActivity
 * JD-Core Version:    0.5.4
 */