package com.jiayuan.myprofile;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import java.util.ArrayList;

class ah
  implements AdapterView.OnItemClickListener
{
  ah(MyProfilePhotoActivity paramMyProfilePhotoActivity)
  {
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    Intent localIntent = new Intent();
    localIntent.putExtra("selected_index", paramInt);
    ArrayList localArrayList = MyProfilePhotoActivity.d(this.a);
    localIntent.putStringArrayListExtra("photo_urls", localArrayList);
    MyProfilePhotoActivity localMyProfilePhotoActivity1 = this.a;
    localIntent.setClass(localMyProfilePhotoActivity1, MyProfilePhotoGalleryActivity.class);
    MyProfilePhotoActivity localMyProfilePhotoActivity2 = this.a;
    int i = MyProfilePhotoActivity.e(this.a);
    localMyProfilePhotoActivity2.startActivityForResult(localIntent, i);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ah
 * JD-Core Version:    0.5.4
 */