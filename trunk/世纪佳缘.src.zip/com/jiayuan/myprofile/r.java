package com.jiayuan.myprofile;

import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.widget.Gallery;
import com.jiayuan.util.o;
import java.util.ArrayList;

class r
  implements GestureDetector.OnGestureListener
{
  r(MyProfilePhotoGalleryActivity paramMyProfilePhotoGalleryActivity)
  {
  }

  public boolean onDown(MotionEvent paramMotionEvent)
  {
    return null;
  }

  public boolean onFling(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    Object localObject = null;
    int i = 1;
    float f1 = paramMotionEvent1.getX();
    float f2 = paramMotionEvent2.getX();
    f1 = Math.abs(f1 - f2);
    float f3 = paramMotionEvent1.getX();
    float f4 = paramMotionEvent2.getX();
    if (f3 - f4 > localObject)
    {
      float f5 = o.d(MyProfilePhotoGalleryActivity.a(this.a)) / 4;
      if (f1 > f5)
      {
        int j = MyProfilePhotoGalleryActivity.b(this.a);
        int k = MyProfilePhotoGalleryActivity.c(this.a).size() - i;
        if (j < k)
        {
          Gallery localGallery1 = MyProfilePhotoGalleryActivity.d(this.a);
          MyProfilePhotoGalleryActivity localMyProfilePhotoGalleryActivity1 = this.a;
          int l = MyProfilePhotoGalleryActivity.b(localMyProfilePhotoGalleryActivity1);
          int i1;
          ++i1;
          MyProfilePhotoGalleryActivity.a(localMyProfilePhotoGalleryActivity1, l);
          localGallery1.setSelection(l);
        }
      }
    }
    while (true)
    {
      return i;
      float f6 = paramMotionEvent1.getX();
      float f7 = paramMotionEvent2.getX();
      if (f6 - f7 >= localObject)
        continue;
      float f8 = o.d(MyProfilePhotoGalleryActivity.a(this.a)) / 4;
      if ((f1 <= f8) || (MyProfilePhotoGalleryActivity.b(this.a) <= 0))
        continue;
      Gallery localGallery2 = MyProfilePhotoGalleryActivity.d(this.a);
      MyProfilePhotoGalleryActivity localMyProfilePhotoGalleryActivity2 = this.a;
      int i2 = MyProfilePhotoGalleryActivity.b(localMyProfilePhotoGalleryActivity2) - i;
      MyProfilePhotoGalleryActivity.a(localMyProfilePhotoGalleryActivity2, i2);
      localGallery2.setSelection(i2);
    }
  }

  public void onLongPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onScroll(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    return null;
  }

  public void onShowPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onSingleTapUp(MotionEvent paramMotionEvent)
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.r
 * JD-Core Version:    0.5.4
 */