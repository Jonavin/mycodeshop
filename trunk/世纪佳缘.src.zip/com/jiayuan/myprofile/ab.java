package com.jiayuan.myprofile;

import android.graphics.Bitmap;
import java.util.ArrayList;

public abstract interface ab
{
  public abstract void a();

  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a(ArrayList paramArrayList);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ab
 * JD-Core Version:    0.5.4
 */