package com.jiayuan.myprofile;

public class ap
{
  public String a;
  public String b;
  public String c;
  public int d;
  public int e;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ap
 * JD-Core Version:    0.5.4
 */