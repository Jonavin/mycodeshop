package com.jiayuan.myprofile;

import I;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.mateselection.b;
import com.jiayuan.setting.SettingActivity;
import com.jiayuan.util.f;
import com.jiayuan.util.o;
import com.jiayuan.util.picker.AgeRangePicker;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.picker.HeightRangePicker;
import com.jiayuan.util.picker.ab;
import com.jiayuan.util.picker.z;
import com.jiayuan.util.s;
import com.jiayuan.util.t;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MyMateSelectionActivity extends MyActivity
  implements AdapterView.OnItemClickListener, com.jiayuan.login.l, com.jiayuan.mateselection.a, com.jiayuan.util.picker.a, ab
{
  b a;
  private final int b = null;
  private final int c = 1;
  private final int d = 2;
  private final int e = 3;
  private final int f = 4;
  private final int g = 5;
  private final int h = 6;
  private ArrayList i;
  private ListView j;
  private a k;
  private Context l;
  private Spinner m;
  private Spinner n;
  private Spinner o;
  private Spinner p;

  public MyMateSelectionActivity()
  {
    b localb = new b();
    this.a = localb;
  }

  private int[] a(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int i1 = 0; ; ++i1)
    {
      if (i1 >= paramInt)
        return arrayOfInt;
      int i2 = t.a(i1);
      arrayOfInt[i1] = i2;
    }
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int i1 = 0;
    int i2 = paramArrayOfInt.length;
    if (i2 <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      i2 = 0;
      return i2;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    int[] arrayOfInt;
    for (int i3 = i1; ; ++arrayOfInt)
    {
      int i4 = paramArrayOfInt.length;
      if (i3 >= i4)
      {
        arrayOfInt = new int[4];
        i5 = t.c(this.l, "11");
        arrayOfInt[i1] = i5;
        int i6 = t.c(this.l, "12");
        arrayOfInt[1] = i6;
        int i7 = t.c(this.l, "31");
        arrayOfInt[2] = i7;
        int i8 = t.c(this.l, "50");
        arrayOfInt[3] = i8;
        for (i5 = i1; ; ++i5)
        {
          int i9 = arrayOfInt.length;
          if (i5 < i9);
          int i10 = arrayOfInt[i5];
          int i11 = t.a(i1);
          String[] arrayOfString3 = localResources.getStringArray(i11);
          arrayOfString1[i10] = arrayOfString3;
        }
      }
      int i5 = paramArrayOfInt[arrayOfInt];
      String[] arrayOfString2 = localResources.getStringArray(i5);
      arrayOfString1[arrayOfInt] = arrayOfString2;
    }
  }

  private void e()
  {
    com.jiayuan.util.a.a("MyMateSelectionActivity", "Goto my profile button clicked");
    finish();
  }

  private void f()
  {
    com.jiayuan.util.a.a("MyMateSelectionActivity", "Goto setting button clicked");
    Intent localIntent = new Intent(this, SettingActivity.class);
    startActivity(localIntent);
    finish();
  }

  private void g()
  {
    com.jiayuan.util.a.a("MyMateSelectionActivity", "Back button clicked");
    finish();
  }

  private void h()
  {
    com.jiayuan.util.a.a("MyMateSelectionActivity", "Confirm button clicked");
    String str1 = ((b)this.i.get(0)).b;
    String str2 = ((b)this.i.get(0)).c;
    int i1 = ((b)this.i.get(1)).d;
    String str3 = t.d(this, i1);
    int i2 = ((b)this.i.get(1)).d;
    int i3 = ((b)this.i.get(1)).e;
    String str4 = t.b(this, i2, i3);
    String str5 = ((b)this.i.get(2)).b;
    String str6 = ((b)this.i.get(2)).c;
    String str7 = ((b)this.i.get(3)).b;
    String str8 = ((b)this.i.get(4)).b;
    String str9 = ((b)this.i.get(5)).b;
    String str10 = ((b)this.i.get(6)).b;
    MyMateSelectionActivity localMyMateSelectionActivity = this;
    new com.jiayuan.mateselection.i(localMyMateSelectionActivity, str1, str2, str3, str4, str5, str6, str7, str8, str9, str10).a();
  }

  private void i()
  {
    b localb1 = this.a;
    String str1 = ((b)this.i.get(1)).a;
    localb1.a = str1;
    b localb2 = this.a;
    String str2 = ((b)this.i.get(1)).b;
    localb2.b = str2;
    b localb3 = this.a;
    String str3 = ((b)this.i.get(1)).c;
    localb3.c = str3;
    b localb4 = this.a;
    int i1 = ((b)this.i.get(1)).d;
    localb4.d = i1;
    b localb5 = this.a;
    int i2 = ((b)this.i.get(1)).e;
    localb5.e = i2;
    StringBuilder localStringBuilder1 = new StringBuilder("tempCell.index=");
    int i3 = this.a.d;
    String str4 = i3;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str4);
    StringBuilder localStringBuilder2 = new StringBuilder("tempCell.index1=");
    int i4 = this.a.e;
    String str5 = i4;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str5);
  }

  private View j()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099840);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = a(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    i();
    h localh = new h(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(localh);
    int i2 = this.a.d;
    int i3 = this.a.e;
    localDoubleLevelSpinner.a(i2, true, i3, true);
    return localView;
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int i1 = ((b)this.i.get(paramInt3)).d;
    localSpinner.setSelection(i1, true);
    l locall = new l(this, paramInt3);
    localSpinner.setOnItemSelectedListener(locall);
    return localSpinner;
  }

  public void a()
  {
    Spinner localSpinner1 = a(2131361939, "璇烽��", 2131099754, 3);
    this.m = localSpinner1;
    Spinner localSpinner2 = a(2131361940, "璇烽�", 2131099787, 4);
    this.n = localSpinner2;
    Spinner localSpinner3 = a(2131361941, "璇烽�", 2131099786, 5);
    this.o = localSpinner3;
    Spinner localSpinner4 = a(2131361942, "璇烽��", 2131099755, 6);
    this.p = localSpinner4;
  }

  public void a(AgeRangePicker paramAgeRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    String str1 = "onAgeRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str1);
    String str2 = "onAgeRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str2);
    if (paramInt1 < paramInt2)
    {
      b localb1 = (b)this.i.get(i1);
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = f.r(this, paramInt1);
      String str4 = str3;
      localb1.b = str4;
      b localb2 = (b)this.i.get(i1);
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str5 = f.s(this, paramInt2);
      String str6 = str5;
      localb2.c = str6;
    }
    while (true)
    {
      this.k.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165336, i1).show();
    }
  }

  public void a(HeightRangePicker paramHeightRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 2;
    String str1 = "onHeightRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str1);
    String str2 = "onHeightRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str2);
    if (paramInt1 < paramInt2)
    {
      b localb1 = (b)this.i.get(i1);
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = f.t(this, paramInt1);
      String str4 = str3;
      localb1.b = str4;
      b localb2 = (b)this.i.get(i1);
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str5 = f.u(this, paramInt2);
      String str6 = str5;
      localb2.c = str6;
    }
    while (true)
    {
      this.k.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165337, 0).show();
    }
  }

  public void a(String paramString)
  {
    try
    {
      if (new JSONObject(paramString).getString("retcode").equalsIgnoreCase("1"))
      {
        Toast.makeText(this, 2131165579, 0).show();
        String str1 = ((b)this.i.get(0)).b;
        o.a("127", str1);
        String str2 = ((b)this.i.get(0)).c;
        o.a("128", str2);
        int i1 = ((b)this.i.get(1)).d;
        String str3 = t.d(this, i1);
        o.a("136", str3);
        int i2 = ((b)this.i.get(1)).d;
        int i3 = ((b)this.i.get(1)).e;
        String str4 = t.b(this, i2, i3);
        o.a("137", str4);
        String str5 = ((b)this.i.get(2)).b;
        o.a("129", str5);
        String str6 = ((b)this.i.get(2)).c;
        o.a("130", str6);
        String str7 = ((b)this.i.get(3)).b;
        String str8 = f.o(this, str7);
        o.a("131", str8);
        String str9 = ((b)this.i.get(4)).b;
        String str10 = f.d(this, str9);
        o.a("132", str10);
        String str11 = ((b)this.i.get(5)).b;
        String str12 = f.f(this, str11);
        o.a("133", str12);
        o.a("134", "1");
        String str13 = ((b)this.i.get(6)).b;
        String str14 = f.p(this, str13);
        o.a("135", str14);
        return;
      }
      Toast.makeText(this, 2131165580, 0).show();
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    o.a(paramJSONArray);
    StringBuilder localStringBuilder = new StringBuilder("onGetServiceType serviceType=");
    String str1 = o.k().toString();
    String str2 = str1;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str2);
  }

  public void a(JSONObject paramJSONObject)
  {
    try
    {
      Object localObject1 = paramJSONObject.getJSONObject("userinfos");
      Object localObject2 = o.e();
      localObject2 = ((JSONObject)localObject1).getJSONObject((String)localObject2);
      o.a(s.a((JSONObject)localObject2));
      localObject1 = "MyMateSelectionActivity";
      Object localObject3 = new StringBuilder("onGetProfiles profile=");
      Object localObject4 = o.j().toString();
      localObject3 = (String)localObject4;
      com.jiayuan.util.a.a((String)localObject1, (String)localObject3);
      if (localObject2 != null)
      {
        localObject1 = (b)this.i.get(0);
        ((b)localObject1).a = "骞";
        localObject3 = ((JSONObject)localObject2).getString("127");
        ((b)localObject1).b = ((String)localObject3);
        localObject3 = ((JSONObject)localObject2).getString("128");
        ((b)localObject1).c = ((String)localObject3);
        localObject3 = ((b)localObject1).b;
        localObject3 = f.F(this, (String)localObject3);
        ((b)localObject1).d = localObject3;
        localObject3 = ((b)localObject1).c;
        localObject3 = f.G(this, (String)localObject3);
        ((b)localObject1).e = localObject3;
        localObject1 = (b)this.i.get(1);
        localObject3 = ((JSONObject)localObject2).getString("136");
        localObject3 = t.c(this, (String)localObject3);
        localObject4 = ((JSONObject)localObject2).getString("137");
        localObject4 = t.c(this, localObject3, (String)localObject4);
        ((b)localObject1).a = "鍦";
        ((b)localObject1).d = localObject3;
        ((b)localObject1).e = localObject4;
        String str1 = t.b(this, localObject3);
        ((b)localObject1).b = str1;
        localObject3 = t.b(this, localObject3, localObject4, true);
        ((b)localObject1).c = ((String)localObject3);
        this.a = ((b)localObject1);
        localObject3 = ((JSONObject)localObject2).getString("129");
        localObject4 = ((JSONObject)localObject2).getString("130");
        localObject1 = (b)this.i.get(2);
        ((b)localObject1).a = "韬";
        if (((String)localObject3).equalsIgnoreCase("0"))
          localObject3 = "130";
        ((b)localObject1).b = ((String)localObject3);
        localObject3 = ((String)localObject4).equalsIgnoreCase("0");
        if (localObject3 == 0)
          break label818;
        localObject3 = "260";
        ((b)localObject1).c = ((String)localObject3);
        String str2 = ((b)localObject1).b;
        int i1 = f.I(this, (String)localObject3);
        ((b)localObject1).d = ((I)localObject3);
        String str3 = ((b)localObject1).c;
        int i2 = f.I(this, (String)localObject3);
        ((b)localObject1).e = ((I)localObject3);
        b localb1 = (b)this.i.get(3);
        ((b)localObject1).a = "璇氫";
        int i3 = ((JSONObject)localObject2).getInt("131");
        String str4 = f.n(this, localObject3);
        ((b)localObject1).b = ((String)localObject3);
        ((b)localObject1).c = "";
        String str5 = ((b)localObject1).b;
        int i4 = f.D(this, (String)localObject3);
        ((b)localObject1).d = ((I)localObject3);
        ((b)localObject1).e = null;
        b localb2 = (b)this.i.get(4);
        ((b)localObject1).a = "濠";
        int i5 = ((JSONObject)localObject2).getInt("132");
        String str6 = f.b(this, localObject3);
        ((b)localObject1).b = ((String)localObject3);
        ((b)localObject1).c = "";
        String str7 = ((b)localObject1).b;
        int i6 = f.r(this, (String)localObject3);
        ((b)localObject1).d = ((I)localObject3);
        ((b)localObject1).e = null;
        b localb3 = (b)this.i.get(5);
        ((b)localObject1).a = "瀛";
        int i7 = ((JSONObject)localObject2).getInt("133");
        String str8 = f.a(this, localObject3);
        ((b)localObject1).b = ((String)localObject3);
        ((b)localObject1).c = "";
        String str9 = ((b)localObject1).b;
        int i8 = f.s(this, (String)localObject3);
        ((b)localObject1).d = ((I)localObject3);
        ((b)localObject1).e = null;
        b localb4 = (b)this.i.get(6);
        ((b)localObject1).a = "鏈夋";
        int i9 = ((JSONObject)localObject2).getInt("135");
        String str10 = f.o(this, localObject2);
        ((b)localObject1).b = ((String)localObject2);
        ((b)localObject1).c = "";
        String str11 = ((b)localObject1).b;
        int i10 = f.E(this, (String)localObject2);
        ((b)localObject1).d = ((I)localObject2);
        ((b)localObject1).e = null;
        j();
        Spinner localSpinner1 = this.m;
        int i11 = ((b)this.i.get(3)).d;
        ((Spinner)localObject2).setSelection(localObject1, true);
        Spinner localSpinner2 = this.n;
        int i12 = ((b)this.i.get(4)).d;
        ((Spinner)localObject2).setSelection(localObject1, true);
        Spinner localSpinner3 = this.o;
        int i13 = ((b)this.i.get(5)).d;
        ((Spinner)localObject2).setSelection(localObject1, true);
        Spinner localSpinner4 = this.p;
        int i14 = ((b)this.i.get(6)).d;
        ((Spinner)localObject2).setSelection(localObject1, true);
        com.jiayuan.util.a.a("MyMateSelectionActivity", "onGetUserMateSelectionInfo   update list");
        this.k.notifyDataSetChanged();
      }
      label817: return;
      label818: localObject3 = localObject4;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      break label817:
    }
  }

  public void b()
  {
  }

  public void b(String paramString)
  {
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void c()
  {
  }

  public void c(String paramString)
  {
  }

  public void d()
  {
    Toast.makeText(this, 2131165664, 1).show();
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool = null;
    super.onCreate(paramBundle);
    setContentView(2130903070);
    this.l = this;
    b localb1 = new b();
    b localb2 = new b();
    b localb3 = new b();
    b localb4 = new b();
    b localb5 = new b();
    b localb6 = new b();
    b localb7 = new b();
    Object localObject = new ArrayList();
    this.i = ((ArrayList)localObject);
    this.i.add(localb1);
    this.i.add(localb2);
    this.i.add(localb3);
    this.i.add(localb4);
    this.i.add(localb5);
    this.i.add(localb6);
    this.i.add(localb7);
    localObject = o.j();
    if (localObject == null)
    {
      localb1.a = "骞";
      localb1.b = "18";
      localb1.c = "35";
      String str1 = localb1.b;
      int i1 = f.F(this, str1);
      localb1.d = i1;
      String str2 = localb1.c;
      int i2 = f.G(this, str2);
      localb1.e = i2;
      localb2.a = "鍦";
      localb2.b = "鍖";
      localb2.c = "涓";
      localb2.d = bool;
      localb2.e = bool;
      localb3.a = "韬";
      localb3.b = "160";
      localb3.c = "185";
      String str3 = localb3.b;
      int i3 = f.I(this, localb1);
      localb3.d = localb1;
      String str4 = localb3.c;
      int i4 = f.I(this, localb1);
      localb3.e = localb1;
      localb4.a = "璇氫";
      localb4.b = "涓";
      localb4.c = "";
      localb4.d = bool;
      localb4.e = bool;
      localb5.a = "濠";
      localb5.b = "涓";
      localb5.c = "";
      localb5.d = bool;
      localb5.e = bool;
      localb6.a = "瀛";
      localb6.b = "涓";
      localb6.c = "";
      localb6.d = bool;
      localb6.e = bool;
      localb7.a = "鏈夋";
      localb7.b = "涓";
      localb7.c = "";
      localb7.d = bool;
      localb7.e = bool;
      String str5 = o.e();
      new com.jiayuan.login.j(this, localb2).a();
    }
    while (true)
    {
      a();
      ListView localListView1 = (ListView)findViewById(2131361961);
      this.j = localListView1;
      ArrayList localArrayList = this.i;
      a locala1 = new a(this, this, localArrayList);
      this.k = locala1;
      this.k.setNotifyOnChange(bool);
      ListView localListView2 = this.j;
      a locala2 = this.k;
      localListView2.setAdapter(locala2);
      this.j.setOnItemClickListener(this);
      Button localButton1 = (Button)findViewById(2131361955);
      n localn = new n(this);
      localButton1.setOnClickListener(localn);
      Button localButton2 = (Button)findViewById(2131361957);
      k localk = new k(this);
      localButton2.setOnClickListener(localk);
      Button localButton3 = (Button)findViewById(2131361959);
      j localj = new j(this);
      localButton3.setOnClickListener(localj);
      Button localButton4 = (Button)findViewById(2131361960);
      m localm = new m(this);
      localButton4.setOnClickListener(localm);
      return;
      try
      {
        localb1.a = "骞";
        String str6 = ((JSONObject)localObject).getString("127");
        localb1.b = str6;
        String str7 = ((JSONObject)localObject).getString("128");
        localb1.c = str7;
        String str8 = localb1.b;
        int i5 = f.F(this, str8);
        localb1.d = i5;
        String str9 = localb1.c;
        int i6 = f.G(this, str9);
        localb1.e = i6;
        String str10 = ((JSONObject)localObject).getString("136");
        int i7 = t.c(this, localb1);
        String str11 = ((JSONObject)localObject).getString("137");
        int i8 = t.c(this, localb1, str11);
        localb2.a = "鍦";
        String str12 = t.b(this, localb1);
        localb2.b = str12;
        String str13 = t.b(this, localb1, i8, true);
        localb2.c = str13;
        String str14 = localb2.c;
        com.jiayuan.util.a.a("MyMateSelectionActivity", str14);
        localb2.d = localb1;
        localb2.e = i8;
        localb3.a = "韬";
        String str15 = ((JSONObject)localObject).getString("129");
        localb3.b = localb1;
        String str16 = ((JSONObject)localObject).getString("130");
        localb3.c = localb1;
        String str17 = localb3.b;
        int i9 = f.I(this, localb1);
        localb3.d = localb1;
        String str18 = localb3.c;
        int i10 = f.I(this, localb1);
        localb3.e = localb1;
        localb4.a = "璇氫";
        int i11 = ((JSONObject)localObject).getInt("131");
        String str19 = f.n(this, localb1);
        localb4.b = localb1;
        localb4.c = "";
        String str20 = localb4.b;
        int i12 = f.D(this, localb1);
        localb4.d = localb1;
        localb4.e = null;
        localb5.a = "濠";
        int i13 = ((JSONObject)localObject).getInt("132");
        String str21 = f.b(this, localb1);
        localb5.b = localb1;
        localb5.c = "";
        String str22 = localb5.b;
        int i14 = f.r(this, localb1);
        localb5.d = localb1;
        localb5.e = null;
        localb6.a = "瀛";
        int i15 = ((JSONObject)localObject).getInt("133");
        String str23 = f.a(this, localb1);
        localb6.b = localb1;
        StringBuilder localStringBuilder1 = new StringBuilder("mateselection education detail=");
        int i16 = ((JSONObject)localObject).getInt("133");
        String str24 = localb3;
        com.jiayuan.util.a.a("MyMateSelectionActivity", localb2);
        localb6.c = "";
        String str25 = localb6.b;
        int i17 = f.s(this, localb1);
        localb6.d = localb1;
        StringBuilder localStringBuilder2 = new StringBuilder("mateselection education index=");
        int i18 = localb6.d;
        String str26 = localb3;
        com.jiayuan.util.a.a("MyMateSelectionActivity", localb2);
        localb6.e = null;
        localb7.a = "鏈夋";
        int i19 = ((JSONObject)localObject).getInt("135");
        String str27 = f.o(this, localb1);
        localb7.b = localb1;
        localb7.c = "";
        String str28 = localb7.b;
        int i20 = f.E(this, localb1);
        localb7.d = localb1;
        localb7.e = null;
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
    }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 1:
    }
    while (true)
    {
      return i1;
      Object localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView = j();
      localObject = ((AlertDialog.Builder)localObject).setView(localView);
      g localg = new g(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165642, localg);
      i locali = new i(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, locali).create();
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i1 = 0;
    int i2 = 2;
    int i3 = 1;
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str);
    if (paramInt == 0)
    {
      int i4 = ((b)this.i.get(i1)).d;
      int i5 = ((b)this.i.get(i1)).e;
      new com.jiayuan.util.picker.m(this, this, i4, i5).show();
    }
    while (true)
    {
      return;
      if (i3 == paramInt)
        showDialog(i3);
      if (i2 == paramInt)
      {
        int i6 = ((b)this.i.get(i2)).d;
        int i7 = ((b)this.i.get(i2)).e;
        new z(this, this, i6, i7).show();
      }
      if (3 == paramInt)
      {
        this.m.performClick();
        CharSequence localCharSequence1 = this.m.getPrompt();
        Toast.makeText(this, localCharSequence1, i3).show();
      }
      if (4 == paramInt)
      {
        this.n.performClick();
        CharSequence localCharSequence2 = this.n.getPrompt();
        Toast.makeText(this, localCharSequence2, i3).show();
      }
      if (5 == paramInt)
      {
        this.o.performClick();
        CharSequence localCharSequence3 = this.o.getPrompt();
        Toast.makeText(this, localCharSequence3, i3).show();
      }
      if (6 != paramInt)
        continue;
      this.p.performClick();
      CharSequence localCharSequence4 = this.p.getPrompt();
      Toast.makeText(this, localCharSequence4, i3).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.MyMateSelectionActivity
 * JD-Core Version:    0.5.4
 */