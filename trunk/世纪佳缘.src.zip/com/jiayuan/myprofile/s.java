package com.jiayuan.myprofile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class s
  implements DialogInterface.OnClickListener
{
  s(MyProfilePhotoGalleryActivity paramMyProfilePhotoGalleryActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.s
 * JD-Core Version:    0.5.4
 */