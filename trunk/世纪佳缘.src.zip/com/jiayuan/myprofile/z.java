package com.jiayuan.myprofile;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import com.jiayuan.util.a;
import java.util.ArrayList;

public class z extends BaseAdapter
{
  private LayoutInflater b;
  private Context c;

  public z(MyProfilePhotoActivity paramMyProfilePhotoActivity, Context paramContext)
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(paramContext);
    this.b = localLayoutInflater;
    this.c = paramContext;
  }

  public int getCount()
  {
    return MyProfilePhotoActivity.a(this.a).size();
  }

  public Object getItem(int paramInt)
  {
    return null;
  }

  public long getItemId(int paramInt)
  {
    return 0L;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Bitmap localBitmap = (Bitmap)MyProfilePhotoActivity.a(this.a).get(paramInt);
    int i = (MyProfilePhotoActivity.b(this.a) - 10) / 3;
    int j = (MyProfilePhotoActivity.c(this.a) - 200) / 3;
    View localView;
    Object localObject1;
    if (paramView == null)
    {
      MyProfilePhotoActivity localMyProfilePhotoActivity = this.a;
      aq localaq = new aq(localMyProfilePhotoActivity);
      localView = this.b.inflate(2130903077, null);
      ImageView localImageView1 = (ImageView)localView.findViewById(2131362000);
      localaq.a = this;
      AbsListView.LayoutParams localLayoutParams = new AbsListView.LayoutParams(i, j);
      localView.setLayoutParams(localLayoutParams);
      localView.setTag(localaq);
      localObject1 = localaq;
    }
    for (Object localObject2 = localView; ; localObject2 = paramView)
    {
      String str = "position=" + paramInt;
      a.a("MyProfilePhotoActivity", str);
      ImageView localImageView2 = ((aq)localObject1).a;
      ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
      localImageView2.setScaleType(localScaleType);
      ((aq)localObject1).a.setImageBitmap(localBitmap);
      return localObject2;
      localObject1 = (aq)paramView.getTag();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.z
 * JD-Core Version:    0.5.4
 */