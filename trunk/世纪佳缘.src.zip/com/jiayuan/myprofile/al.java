package com.jiayuan.myprofile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.widget.ImageView;
import com.jiayuan.util.a;

class al
  implements DialogInterface.OnClickListener
{
  al(MyProfileActivity paramMyProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.a("MyProfileActivity", "Photo manager button clicked");
    MyProfileActivity localMyProfileActivity = this.a;
    ImageView localImageView = this.a.c;
    localMyProfileActivity.openContextMenu(localImageView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.al
 * JD-Core Version:    0.5.4
 */