package com.jiayuan.myprofile;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class y extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  y(MyProfileActivity paramMyProfileActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903073, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    v localv = (v)paramView.getTag();
    localv.d = paramInt;
    paramView.setTag(localv);
    TextView localTextView1 = localv.a;
    String str1 = ((ap)MyProfileActivity.a(this.b).get(paramInt)).a;
    localTextView1.setText(str1);
    TextView localTextView2 = localv.b;
    String str2 = String.valueOf(((ap)MyProfileActivity.a(this.b).get(paramInt)).b);
    StringBuilder localStringBuilder = new StringBuilder(str2);
    String str3 = ((ap)MyProfileActivity.a(this.b).get(paramInt)).c;
    String str4 = str3;
    localTextView2.setText(str4);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903073, paramViewGroup, null);
      v localv = new v(null);
      localObject = (TextView)localView.findViewById(2131361986);
      localv.a = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361987);
      localv.b = ((TextView)localObject);
      localObject = (ImageView)localView.findViewById(2131361988);
      localv.c = ((ImageView)localObject);
      localView.setTag(localv);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    v localv = (v)((View)paramView.getTag()).getTag();
    a.a("MyProfileActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.y
 * JD-Core Version:    0.5.4
 */