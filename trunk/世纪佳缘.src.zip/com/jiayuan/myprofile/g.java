package com.jiayuan.myprofile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.mateselection.b;
import java.util.ArrayList;

class g
  implements DialogInterface.OnClickListener
{
  g(MyMateSelectionActivity paramMyMateSelectionActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ArrayList localArrayList = MyMateSelectionActivity.a(this.a);
    b localb = this.a.a;
    localArrayList.set(1, localb);
    MyMateSelectionActivity.f(this.a).notifyDataSetChanged();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.g
 * JD-Core Version:    0.5.4
 */