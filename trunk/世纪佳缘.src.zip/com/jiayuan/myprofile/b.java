package com.jiayuan.myprofile;

import java.util.Comparator;

public class b
  implements Comparator
{
  public b(MyProfilePhotoGalleryActivity paramMyProfilePhotoGalleryActivity)
  {
  }

  public int a(String paramString1, String paramString2)
  {
    int i = Integer.parseInt(paramString1);
    int k = Integer.parseInt(paramString2);
    int j;
    if (i < k)
      j = -1;
    while (true)
    {
      return j;
      if (j > k)
        j = 1;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.b
 * JD-Core Version:    0.5.4
 */