package com.jiayuan.myprofile;

import com.jiayuan.util.a;

class h
  implements com.jiayuan.util.picker.b
{
  h(MyMateSelectionActivity paramMyMateSelectionActivity, String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    com.jiayuan.mateselection.b localb1 = this.a.a;
    String str1 = this.b[paramInt1];
    localb1.b = str1;
    this.a.a.d = paramInt1;
    com.jiayuan.mateselection.b localb2 = this.a.a;
    String str2 = this.c[paramInt1][paramInt2];
    localb2.c = str2;
    this.a.a.e = paramInt2;
    StringBuilder localStringBuilder1 = new StringBuilder("selected detail=");
    String str3 = this.a.a.b;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str3).append(" index=");
    int i = this.a.a.d;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(i).append(" detail1=");
    String str4 = this.a.a.c;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str4).append(" index1=");
    int j = this.a.a.e;
    String str5 = j;
    a.a("MyMateSelectionActivity", str5);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.h
 * JD-Core Version:    0.5.4
 */