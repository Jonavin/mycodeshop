package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class j
  implements View.OnClickListener
{
  j(MyMateSelectionActivity paramMyMateSelectionActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyMateSelectionActivity.d(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.j
 * JD-Core Version:    0.5.4
 */