package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class af
  implements View.OnClickListener
{
  af(MyProfileActivity paramMyProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyProfileActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.af
 * JD-Core Version:    0.5.4
 */