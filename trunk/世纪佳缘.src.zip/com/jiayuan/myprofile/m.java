package com.jiayuan.myprofile;

import android.view.View;
import android.view.View.OnClickListener;

class m
  implements View.OnClickListener
{
  m(MyMateSelectionActivity paramMyMateSelectionActivity)
  {
  }

  public void onClick(View paramView)
  {
    MyMateSelectionActivity.e(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.m
 * JD-Core Version:    0.5.4
 */