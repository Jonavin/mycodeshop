package com.jiayuan.myprofile;

public class ar
{
  public int A;
  public int B;
  public int C;
  public int D;
  public int E;
  public String F;
  public String a;
  public String b;
  public String c;
  public int d;
  public int e;
  public String f;
  public int g;
  public int h;
  public int i;
  public int j;
  public int k;
  public int l;
  public int m;
  public int n;
  public int o;
  public int p;
  public int q;
  public int r;
  public int s;
  public int t;
  public int u;
  public int v;
  public int w;
  public int x;
  public int y;
  public int z;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ar
 * JD-Core Version:    0.5.4
 */