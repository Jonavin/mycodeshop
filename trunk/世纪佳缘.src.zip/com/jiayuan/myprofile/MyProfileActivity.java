package com.jiayuan.myprofile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager.BadTokenException;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.a.w;
import com.jiayuan.home.HomeActivity;
import com.jiayuan.setting.SettingActivity;
import com.jiayuan.system.service.NotificationService;
import com.jiayuan.system.service.UnreadMailService;
import com.jiayuan.util.b;
import com.jiayuan.util.m;
import com.jiayuan.util.n;
import com.jiayuan.util.o;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.r;
import com.jiayuan.util.s;
import com.jiayuan.util.t;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MyProfileActivity extends Activity
  implements AdapterView.OnItemClickListener, w, p, u, com.jiayuan.util.e, n
{
  private Spinner A;
  private Spinner B;
  private Spinner C;
  private Spinner D;
  private ProgressDialog E;
  private ProgressDialog F;
  private ProgressDialog G;
  private EditText H;
  r a = null;
  ap b;
  ImageView c;
  private final int d = null;
  private final int e = 1;
  private Bitmap f = null;
  private final int g = null;
  private final int h = 1;
  private final int i = 2;
  private final int j = 3;
  private final int k = 4;
  private final int l = 5;
  private final int m = 6;
  private final int n = 7;
  private final int o = 8;
  private ar p;
  private int q;
  private int r;
  private ArrayList s;
  private ListView t;
  private y u;
  private Context v;
  private Spinner w;
  private Spinner x;
  private Spinner y;
  private Spinner z;

  public MyProfileActivity()
  {
    ap localap = new ap();
    this.b = localap;
  }

  private void a(View paramView)
  {
    com.jiayuan.util.a.a("MyProfileActivity", "Header image button clicked");
    openContextMenu(paramView);
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int i1 = paramArrayOfInt.length;
    if (i1 <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      i1 = 0;
      return i1;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    for (int i2 = 0; ; ++i2)
    {
      int i3 = paramArrayOfInt.length;
      if (i2 < i3);
      int i4 = paramArrayOfInt[i2];
      String[] arrayOfString2 = localResources.getStringArray(i4);
      arrayOfString1[i2] = arrayOfString2;
    }
  }

  private int[] b(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int i1 = 0; ; ++i1)
    {
      if (i1 >= paramInt)
        return arrayOfInt;
      int i2 = t.b(i1);
      arrayOfInt[i1] = i2;
    }
  }

  private void e()
  {
    com.jiayuan.util.a.a("MyProfileActivity", "Photo manager button clicked");
    Intent localIntent = new Intent();
    int i1 = this.p.o;
    localIntent.putExtra("photo_privacy", i1);
    localIntent.setClass(this, MyProfilePhotoActivity.class);
    startActivity(localIntent);
  }

  private void f()
  {
    com.jiayuan.util.a.a("MyProfileActivity", "Goto mate selection button clicked");
    Intent localIntent = new Intent(this, MyMateSelectionActivity.class);
    startActivity(localIntent);
  }

  private void h()
  {
    com.jiayuan.util.a.a("MyProfileActivity", "Goto setting button clicked");
    Intent localIntent = new Intent(this, SettingActivity.class);
    startActivity(localIntent);
  }

  private void i()
  {
    int i1 = 1;
    String str1 = this.H.getText().toString().trim();
    com.jiayuan.util.a.a("MyProfileActivity", "Submit button clicked");
    if ((str1.equals("")) || (str1.length() < 20) || (str1.length() > 1500))
      Toast.makeText(this, 2131165300, i1).show();
    while (true)
    {
      if (this.f != null)
      {
        Bitmap localBitmap = this.f;
        new m(this, "avatar", localBitmap).a();
      }
      return;
      String str2 = this.p.a;
      f localf = new f(this, str2);
      String str3 = ((ap)this.s.get(0)).b;
      int i2 = ((ap)this.s.get(i1)).d;
      String str4 = t.c(this, i2);
      int i3 = ((ap)this.s.get(i1)).d;
      int i4 = ((ap)this.s.get(i1)).e;
      String str5 = t.a(this, i3, i4);
      String str6 = ((ap)this.s.get(2)).b;
      String str7 = ((ap)this.s.get(3)).b;
      String str8 = ((ap)this.s.get(4)).b;
      String str9 = ((ap)this.s.get(5)).b;
      String str10 = ((ap)this.s.get(6)).b;
      String str11 = ((ap)this.s.get(7)).b;
      String str12 = ((ap)this.s.get(8)).b;
      localf.a(str3, str4, str5, str6, i1, str8, str9, str10, str11, str12, str1);
    }
  }

  private void j()
  {
    int i1 = 4;
    int i2 = 3;
    int i3 = 2;
    int i4 = 1;
    int i5 = 0;
    com.jiayuan.util.a.a("MyProfileActivity", "updateProfile");
    Object localObject1 = new StringBuilder("nickname=");
    String str1 = this.p.b;
    localObject1 = str1;
    com.jiayuan.util.a.a("MyProfileActivity", (String)localObject1);
    TextView localTextView = (TextView)findViewById(2131361981);
    str1 = String.valueOf(this.p.b);
    localObject1 = new StringBuilder(str1).append(" (");
    int i6 = Integer.parseInt(o.e()) + 1000000;
    localObject1 = i6 + ")";
    localTextView.setText((CharSequence)localObject1);
    localTextView = (TextView)findViewById(2131361982);
    i6 = this.p.e;
    String str2 = this.p.f;
    Object localObject2 = String.valueOf(s.a(i6, str2));
    localObject1 = new StringBuilder((String)localObject2).append("宀�");
    localObject2 = this.v;
    int i8 = this.p.d;
    localObject2 = com.jiayuan.util.f.d((Context)localObject2, i8);
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(" | ");
    localObject2 = this.v;
    i8 = this.p.h;
    localObject2 = com.jiayuan.util.f.c((Context)localObject2, i8);
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(" | ");
    int i7 = this.p.g;
    localObject1 = i7 + "cm";
    localTextView.setText((CharSequence)localObject1);
    localTextView = (TextView)findViewById(2131361983);
    localObject1 = new StringBuilder();
    i7 = this.p.i;
    localObject1 = i7;
    localObject1 = t.b(this, (String)localObject1);
    Object localObject3 = new StringBuilder();
    i8 = this.p.j;
    localObject3 = i8;
    localObject3 = t.b(this, localObject1, (String)localObject3);
    int i9 = s.b(o.k());
    if (i9 == -1);
    for (String str3 = com.jiayuan.util.f.v(this.v, i9); ; str3 = getString(str3))
    {
      String str4 = String.valueOf(t.a(this, localObject1));
      StringBuilder localStringBuilder = new StringBuilder(str4);
      String str5 = t.a(this, localObject1, localObject3, i5);
      String str6 = str5 + " | " + str3;
      localTextView.setText(str3);
      ap localap1 = (ap)this.s.get(i5);
      localTextView.a = "鏈夋";
      int i10 = this.p.m;
      String str7 = com.jiayuan.util.f.f(this, str3);
      localTextView.b = str3;
      localTextView.c = "";
      String str8 = localTextView.b;
      int i11 = com.jiayuan.util.f.v(this, str3);
      localTextView.d = str3;
      localTextView.e = i5;
      ap localap2 = (ap)this.s.get(i4);
      localTextView.a = "鍦";
      String str9 = t.a(this, localObject1);
      localTextView.b = str3;
      String str10 = t.a(this, localObject1, localObject3, i5);
      localTextView.c = str3;
      localTextView.d = localObject1;
      localTextView.e = localObject3;
      ap localap3 = (ap)this.s.get(i3);
      localTextView.a = "琛";
      int i12 = this.p.r;
      String str11 = com.jiayuan.util.f.i(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str12 = localTextView.b;
      int i13 = com.jiayuan.util.f.w(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap4 = (ap)this.s.get(i2);
      localTextView.a = "姘";
      int i14 = this.p.p;
      String str13 = com.jiayuan.util.f.g(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str14 = localTextView.b;
      int i15 = com.jiayuan.util.f.x(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap5 = (ap)this.s.get(i1);
      localTextView.a = "鑱";
      int i16 = this.p.n;
      String str15 = com.jiayuan.util.f.e(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str16 = localTextView.b;
      int i17 = com.jiayuan.util.f.y(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap6 = (ap)this.s.get(5);
      localTextView.a = "鏈";
      int i18 = this.p.k;
      String str17 = com.jiayuan.util.f.h(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str18 = localTextView.b;
      int i19 = com.jiayuan.util.f.z(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap7 = (ap)this.s.get(6);
      localTextView.a = "灞呬";
      int i20 = this.p.s;
      String str19 = com.jiayuan.util.f.k(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str20 = localTextView.b;
      int i21 = com.jiayuan.util.f.A(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap8 = (ap)this.s.get(7);
      localTextView.a = "璐";
      int i22 = this.p.t;
      String str21 = com.jiayuan.util.f.l(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str22 = localTextView.b;
      int i23 = com.jiayuan.util.f.B(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      ap localap9 = (ap)this.s.get(8);
      localTextView.a = "涓";
      int i24 = this.p.l;
      String str23 = com.jiayuan.util.f.m(this, localObject1);
      localTextView.b = ((String)localObject1);
      localTextView.c = "";
      String str24 = localTextView.b;
      int i25 = com.jiayuan.util.f.C(this, (String)localObject1);
      localTextView.d = localObject1;
      localTextView.e = i5;
      Spinner localSpinner1 = this.w;
      int i26 = ((ap)this.s.get(i5)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner2 = this.x;
      int i27 = ((ap)this.s.get(i3)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner3 = this.y;
      int i28 = ((ap)this.s.get(i2)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner4 = this.z;
      int i29 = ((ap)this.s.get(i1)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner5 = this.A;
      int i30 = ((ap)this.s.get(5)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner6 = this.B;
      int i31 = ((ap)this.s.get(6)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner7 = this.C;
      int i32 = ((ap)this.s.get(7)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      Spinner localSpinner8 = this.D;
      int i33 = ((ap)this.s.get(8)).d;
      ((Spinner)localObject1).setSelection(localTextView, i4);
      this.u.notifyDataSetChanged();
      return;
    }
  }

  private void k()
  {
    ap localap1 = this.b;
    String str1 = ((ap)this.s.get(1)).a;
    localap1.a = str1;
    ap localap2 = this.b;
    String str2 = ((ap)this.s.get(1)).b;
    localap2.b = str2;
    ap localap3 = this.b;
    String str3 = ((ap)this.s.get(1)).c;
    localap3.c = str3;
    ap localap4 = this.b;
    int i1 = ((ap)this.s.get(1)).d;
    localap4.d = i1;
    ap localap5 = this.b;
    int i2 = ((ap)this.s.get(1)).e;
    localap5.e = i2;
    StringBuilder localStringBuilder1 = new StringBuilder("tempCell.detail=");
    String str4 = this.b.b;
    String str5 = str4;
    com.jiayuan.util.a.a("MyProfileActivity", str5);
    StringBuilder localStringBuilder2 = new StringBuilder("tempCell.detail1=");
    String str6 = this.b.c;
    String str7 = str6;
    com.jiayuan.util.a.a("MyProfileActivity", str7);
  }

  private View l()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099686);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = b(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    k();
    am localam = new am(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(localam);
    int i2 = this.b.d;
    int i3 = this.b.e;
    localDoubleLevelSpinner.a(i2, true, i3, true);
    return localView;
  }

  private void m()
  {
    String str = this.p.a;
    new x(this, str, 80, 100).a();
  }

  private void n()
  {
    JSONObject localJSONObject = null;
    int i1 = 1;
    com.jiayuan.util.a.a("MyProfileActivity", "Logout menu clicked");
    o.a("");
    o.b("");
    o.c("");
    o.d("");
    o.e("0");
    if (o.j() != null)
      o.a(localJSONObject);
    if (o.k() != null)
      o.a(localJSONObject);
    o.h = null;
    b.a(this, "");
    b.b(this, "");
    b.a(this, i1);
    b.b(this, i1);
    b.c(this, "");
    b.a(this, 1065353216);
    b.b(this, 2131165216, "0");
    b.b(this, 2131165217, "");
    b.b(this, 2131165218, "");
    b.b(this, 2131165219, "");
    b.b(this, 2131165220, "");
    b.b(this, 2131165221, "");
    b.b(this, 2131165222, "");
    b.b(this, 2131165223, "");
    b.b(this, 2131165224, "");
    b.b(this, 2131165225, "");
    b.b(this, 2131165226, "");
    Date localDate = new Date();
    int i2 = localDate.getYear() - i1;
    localDate.setYear(i2);
    b.a(this, 2131165228, localDate);
    b.a(this, 2131165229, localDate);
    Intent localIntent1 = new Intent(this, HomeActivity.class);
    startActivity(localIntent1);
    Intent localIntent2 = new Intent(this, UnreadMailService.class);
    stopService(localIntent2);
    Intent localIntent3 = new Intent(this, NotificationService.class);
    stopService(localIntent3);
    com.jiayuan.a locala = com.jiayuan.a.a();
    locala.c(MainActivity.class);
    locala.d(this);
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int i1 = ((ap)this.s.get(paramInt3)).d;
    localSpinner.setSelection(i1, true);
    ag localag = new ag(this, paramInt3);
    localSpinner.setOnItemSelectedListener(localag);
    return localSpinner;
  }

  public void a()
  {
    Spinner localSpinner1 = a(2131361970, "璇烽��", 2131099740, 0);
    this.w = localSpinner1;
    Spinner localSpinner2 = a(2131361971, "璇烽�", 2131099744, 2);
    this.x = localSpinner2;
    Spinner localSpinner3 = a(2131361972, "璇烽�", 2131099742, 3);
    this.y = localSpinner3;
    Spinner localSpinner4 = a(2131361973, "璇烽�", 2131099739, 4);
    this.z = localSpinner4;
    Spinner localSpinner5 = a(2131361974, "璇烽�", 2131099743, 5);
    this.A = localSpinner5;
    Spinner localSpinner6 = a(2131361975, "璇烽��", 2131099747, 6);
    this.B = localSpinner6;
    Spinner localSpinner7 = a(2131361976, "璇烽��", 2131099748, 7);
    this.C = localSpinner7;
    Spinner localSpinner8 = a(2131361977, "璇烽�", 2131099749, 8);
    this.D = localSpinner8;
  }

  public void a(int paramInt)
  {
    boolean bool = true;
    int i1 = 2131165229;
    Boolean localBoolean;
    if (paramInt == 0)
    {
      localBoolean = Boolean.valueOf(null);
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = b.c(this, i1);
      if (localDate1 == null)
        break label174;
      String str = localSimpleDateFormat.format(localDate1);
      Date localDate2 = Calendar.getInstance().getTime();
      if (!localSimpleDateFormat.format(localDate2).equalsIgnoreCase(localDate1))
      {
        localBoolean = Boolean.valueOf(bool);
        Date localDate3 = new Date();
        b.a(this, i1, localDate3);
      }
    }
    while (true)
    {
      if (localBoolean.booleanValue())
      {
        Context localContext = this.v;
        AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localContext).setTitle(2131165581);
        ai localai = new ai(this);
        AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165583, localai);
        al localal = new al(this);
        localBuilder2.setNegativeButton(2131165584, localal).create().show();
      }
      return;
      label174: localBoolean = Boolean.valueOf(bool);
      Date localDate4 = new Date();
      b.a(this, i1, localDate4);
    }
  }

  public void a(int paramInt, Bitmap paramBitmap)
  {
    Bitmap localBitmap1;
    if (paramBitmap == null)
    {
      boolean bool = o.l().equals("m");
      if (bool)
      {
        localBitmap1 = BitmapFactory.decodeResource(getResources(), 2130837630);
        label29: Toast.makeText(this, 2131165592, 1).show();
      }
    }
    while (true)
    {
      Bitmap localBitmap2 = s.a(s.a(localBitmap1, 220, 270), 1084227584);
      this.c.setImageBitmap(localBitmap1);
      this.f = localBitmap1;
      return;
      localBitmap1 = BitmapFactory.decodeResource(getResources(), 2130837628);
      break label29:
      localBitmap1 = paramBitmap;
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    Object localObject = this.p;
    ((ar)localObject).F = paramString;
    if (paramBitmap == null)
    {
      localObject = o.l().equals("m");
      if (localObject != 0)
      {
        localObject = BitmapFactory.decodeResource(getResources(), 2130837630);
        label44: Toast.makeText(this, 2131165592, 1).show();
      }
    }
    while (true)
    {
      Bitmap localBitmap = s.a((Bitmap)localObject, 1084227584);
      this.c.setImageBitmap((Bitmap)localObject);
      return;
      localObject = BitmapFactory.decodeResource(getResources(), 2130837628);
      break label44:
      localObject = paramBitmap;
    }
  }

  public void a(String paramString)
  {
    this.G.dismiss();
    String str1 = "onPhotoUploadReturn aResult=" + paramString;
    com.jiayuan.util.a.a("MyProfileActivity", str1);
    while (true)
      try
      {
        if (new JSONObject(paramString).getString("retcode").equalsIgnoreCase("1"))
        {
          Toast.makeText(this, 2131165636, 1).show();
          String str2 = this.p.a;
          new x(this, str2, 80, 100).a();
          return;
        }
        Toast.makeText(this, 2131165637, 1).show();
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public void a(JSONArray paramJSONArray)
  {
    int i1 = -1;
    TextView localTextView = (TextView)findViewById(2131361983);
    int i2 = s.b(paramJSONArray);
    if (i2 == i1);
    for (Object localObject = com.jiayuan.util.f.v(this.v, i1); ; localObject = getString(localObject))
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      int i3 = this.p.i;
      String str1 = i3;
      int i4 = t.b(this, str1);
      StringBuilder localStringBuilder2 = new StringBuilder();
      int i5 = this.p.j;
      String str2 = i5;
      int i6 = t.b(this, i4, str2);
      String str3 = String.valueOf(t.a(this, i4));
      StringBuilder localStringBuilder3 = new StringBuilder(str3);
      String str4 = t.a(this, i4, i6, null);
      String str5 = str4 + " | " + (String)localObject;
      localTextView.setText((CharSequence)localObject);
      return;
      localObject = s.b(paramJSONArray);
    }
  }

  public void a(JSONObject paramJSONObject)
  {
    this.E.dismiss();
    Object localObject1 = "MyProfileActivity";
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    com.jiayuan.util.a.a((String)localObject1, str2);
    try
    {
      localObject1 = paramJSONObject.getJSONObject("userinfo");
      ar localar1 = this.p;
      int i1 = ((JSONObject)localObject1).getInt("115");
      localar1.E = i1;
      ar localar2 = this.p;
      String str3 = ((JSONObject)localObject1).getString("221");
      localar2.F = str3;
      int i2 = this.p.E;
      a(i2);
      ar localar3 = this.p;
      String str4 = ((JSONObject)localObject1).getString("3");
      localar3.b = str4;
      ar localar4 = this.p;
      String str5 = ((JSONObject)localObject1).getString("2");
      localar4.c = str5;
      ar localar5 = this.p;
      int i3 = ((JSONObject)localObject1).getInt("105");
      localar5.d = i3;
      ar localar6 = this.p;
      int i4 = ((JSONObject)localObject1).getInt("6");
      localar6.e = i4;
      ar localar7 = this.p;
      String str6 = ((JSONObject)localObject1).getString("5");
      localar7.f = str6;
      ar localar8 = this.p;
      int i5 = ((JSONObject)localObject1).getInt("112");
      localar8.g = i5;
      ar localar9 = this.p;
      int i6 = ((JSONObject)localObject1).getInt("104");
      localar9.h = i6;
      ar localar10 = this.p;
      int i7 = ((JSONObject)localObject1).getInt("100");
      localar10.i = i7;
      ar localar11 = this.p;
      int i8 = ((JSONObject)localObject1).getInt("101");
      localar11.j = i8;
      ar localar12 = this.p;
      int i9 = ((JSONObject)localObject1).getInt("114");
      localar12.k = i9;
      ar localar13 = this.p;
      int i10 = ((JSONObject)localObject1).getInt("109");
      localar13.o = i10;
      ar localar14 = this.p;
      int i11 = ((JSONObject)localObject1).getInt("117");
      localar14.q = i11;
      ar localar15 = this.p;
      int i12 = ((JSONObject)localObject1).getInt("125");
      localar15.l = i12;
      ar localar16 = this.p;
      int i13 = ((JSONObject)localObject1).getInt("127");
      localar16.u = i13;
      ar localar17 = this.p;
      int i14 = ((JSONObject)localObject1).getInt("128");
      localar17.v = i14;
      ar localar18 = this.p;
      int i15 = ((JSONObject)localObject1).getInt("129");
      localar18.w = i15;
      ar localar19 = this.p;
      int i16 = ((JSONObject)localObject1).getInt("130");
      localar19.x = i16;
      ar localar20 = this.p;
      int i17 = ((JSONObject)localObject1).getInt("131");
      localar20.y = i17;
      ar localar21 = this.p;
      int i18 = ((JSONObject)localObject1).getInt("132");
      localar21.z = i18;
      ar localar22 = this.p;
      int i19 = ((JSONObject)localObject1).getInt("133");
      localar22.A = i19;
      ar localar23 = this.p;
      int i20 = ((JSONObject)localObject1).getInt("134");
      localar23.B = i20;
      ar localar24 = this.p;
      int i21 = ((JSONObject)localObject1).getInt("135");
      localar24.C = i21;
      ar localar25 = this.p;
      int i22 = ((JSONObject)localObject1).getInt("136");
      localar25.D = i22;
      ar localar26 = this.p;
      int i23 = ((JSONObject)localObject1).getInt("106");
      localar26.m = i23;
      ar localar27 = this.p;
      int i24 = ((JSONObject)localObject1).getInt("107");
      localar27.n = i24;
      ar localar28 = this.p;
      int i25 = ((JSONObject)localObject1).getInt("111");
      localar28.p = i25;
      ar localar29 = this.p;
      int i26 = ((JSONObject)localObject1).getInt("116");
      localar29.r = i26;
      ar localar30 = this.p;
      int i27 = ((JSONObject)localObject1).getInt("121");
      localar30.s = i27;
      ar localar31 = this.p;
      localObject1 = ((JSONObject)localObject1).getInt("122");
      localar31.t = localObject1;
      return;
    }
    catch (JSONException localJSONException)
    {
      this.p.m = 1;
      this.p.n = 1;
      this.p.p = 1;
      this.p.r = 1;
      this.p.s = 1;
      this.p.t = 1;
      localJSONException.printStackTrace();
    }
    finally
    {
      j();
    }
  }

  public void a_(String paramString)
  {
    if (this.E != null)
      this.E.dismiss();
    if (this.F != null)
      this.F.dismiss();
    if (this.G != null)
      this.G.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.E = localProgressDialog;
      this.E.setCancelable(true);
      com.jiayuan.util.a.a("MyProfileActivity", "---------onWaitingActivityStart()---------");
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void b(String paramString)
  {
    int i1 = 1;
    this.F.dismiss();
    if (paramString.equalsIgnoreCase("1"))
    {
      Toast.makeText(this, 2131165632, i1).show();
      int i2 = ((ap)this.s.get(i1)).d;
      String str1 = t.c(this, i2);
      o.a("136", str1);
      int i3 = ((ap)this.s.get(i1)).d;
      int i4 = ((ap)this.s.get(i1)).e;
      String str2 = t.a(this, i3, i4);
      o.a("137", str2);
      ar localar1 = this.p;
      int i5 = ((ap)this.s.get(i1)).d;
      int i6 = Integer.parseInt(t.c(this, i5));
      localar1.i = i6;
      ar localar2 = this.p;
      int i7 = ((ap)this.s.get(i1)).d;
      int i8 = ((ap)this.s.get(i1)).e;
      int i9 = Integer.parseInt(t.a(this, i7, i8));
      localar2.j = i9;
      TextView localTextView = (TextView)findViewById(2131361983);
      StringBuilder localStringBuilder1 = new StringBuilder();
      int i10 = this.p.i;
      String str3 = i10;
      int i11 = t.b(this, str3);
      StringBuilder localStringBuilder2 = new StringBuilder();
      int i12 = this.p.j;
      String str4 = i1;
      int i13 = t.b(this, i11, str4);
      String str5 = String.valueOf(t.a(this, i11));
      StringBuilder localStringBuilder3 = new StringBuilder(str5);
      String str6 = t.a(this, i11, i13, null);
      StringBuilder localStringBuilder4 = i1.append(str6).append(" | ");
      String str7 = com.jiayuan.util.f.v(this, -1);
      String str8 = str7;
      localTextView.setText(str8);
    }
    while (true)
    {
      return;
      Toast.makeText(this, 2131165633, i1).show();
    }
  }

  public void c()
  {
    try
    {
      String str = getResources().getString(2131165594);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.F = localProgressDialog;
      this.F.setCancelable(true);
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void d()
  {
    if (this.E != null)
      this.E.dismiss();
    if (this.F != null)
      this.F.dismiss();
    if (this.G == null)
      return;
    this.G.dismiss();
  }

  public void d(String paramString)
  {
    com.jiayuan.util.a.a("MyProfileActivity", paramString);
    EditText localEditText = this.H;
    Spanned localSpanned = Html.fromHtml(paramString);
    localEditText.setText(localSpanned);
  }

  public void g()
  {
    try
    {
      String str = getResources().getString(2131165593);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.G = localProgressDialog;
      this.G.setCancelable(true);
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    com.jiayuan.util.a.a("MyProfileActivity", "asdfadsf 000");
    if (this.a == null)
      return;
    com.jiayuan.util.a.a("MyProfileActivity", "asdfadsf 111");
    this.a.a(paramInt1, paramInt2, paramIntent);
  }

  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    Object localObject1 = 1;
    Object localObject2 = (AdapterView.AdapterContextMenuInfo)paramMenuItem.getMenuInfo();
    localObject2 = this.a;
    if (localObject2 == null)
    {
      localObject2 = new r(this, 0);
      this.a = ((r)localObject2);
    }
    localObject2 = paramMenuItem.getItemId();
    switch (localObject2)
    {
    default:
    case 0:
    case 1:
    }
    for (localObject2 = localObject1; ; localObject2 = localObject1)
    {
      while (true)
      {
        return localObject2;
        this.a.a();
        localObject2 = localObject1;
      }
      this.a.b();
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    ViewGroup localViewGroup1 = null;
    int i1 = 25;
    boolean bool = null;
    super.onCreate(paramBundle);
    setContentView(2130903071);
    com.jiayuan.util.a.a("MyProfileActivity", "onCreate");
    if ((o.a == null) || (o.a.equals("")));
    while (true)
    {
      return;
      ar localar1 = new ar();
      this.p = localar1;
      ar localar2 = this.p;
      String str1 = o.e();
      localar2.a = str1;
      int i2 = o.d(this);
      int i3 = o.e(this);
      int i4 = i2 / 2;
      this.q = i4;
      int i5 = (i3 - i1 - i1) / 2;
      this.r = i5;
      String str2 = this.p.a;
      int i6 = this.q;
      int i7 = this.r;
      new x(this, str2, i1, i7).a();
      this.v = this;
      ap localap1 = new ap();
      localap1.a = "鏈夋";
      localap1.b = "鏃�";
      localap1.c = "";
      localap1.d = bool;
      localap1.e = bool;
      ap localap2 = new ap();
      localap2.a = "鍦";
      localap2.b = "鍖";
      localap2.c = "鏈";
      localap2.d = bool;
      localap2.e = bool;
      ap localap3 = new ap();
      i1.a = "琛";
      i1.b = "A�";
      i1.c = "";
      i1.d = bool;
      i1.e = bool;
      ap localap4 = new ap();
      localap4.a = "姘";
      localap4.b = "姹";
      localap4.c = "";
      localap4.d = bool;
      localap4.e = bool;
      ap localap5 = new ap();
      localap5.a = "鑱";
      localap5.b = "鍦ㄦ";
      localap5.c = "";
      localap5.d = bool;
      localap5.e = bool;
      ap localap6 = new ap();
      localap6.a = "鏈";
      localap6.b = "2000鍏�";
      localap6.c = "";
      localap6.d = bool;
      localap6.e = bool;
      ap localap7 = new ap();
      localap7.a = "灞呬";
      localap7.b = "鏆傛";
      localap7.c = "";
      localap7.d = bool;
      localap7.e = bool;
      ap localap8 = new ap();
      localap8.a = "璐";
      localap8.b = "鏆傛";
      localap8.c = "";
      localap8.d = bool;
      localap8.e = bool;
      ap localap9 = new ap();
      localap8.a = "涓";
      localap8.b = "娴";
      localap8.c = "";
      localap8.d = bool;
      localap8.e = bool;
      ArrayList localArrayList1 = new ArrayList();
      this.s = localArrayList1;
      this.s.add(localap1);
      this.s.add(localap2);
      this.s.add(i1);
      this.s.add(localap4);
      this.s.add(localap5);
      this.s.add(localap6);
      this.s.add(localap7);
      this.s.add(localap8);
      this.s.add(localap9);
      a();
      ListView localListView1 = (ListView)findViewById(2131361969);
      this.t = localListView1;
      ArrayList localArrayList2 = this.s;
      y localy1 = new y(this, this, localArrayList2);
      this.u = localy1;
      this.u.setNotifyOnChange(bool);
      ViewGroup localViewGroup2 = (ViewGroup)getLayoutInflater().inflate(2130903072, localViewGroup1);
      this.t.addHeaderView(localViewGroup2);
      View localView1 = getLayoutInflater().inflate(2130903069, localViewGroup1);
      this.t.addFooterView(localView1);
      ListView localListView2 = this.t;
      y localy2 = this.u;
      i1.setAdapter(localy2);
      this.t.setOnItemClickListener(this);
      EditText localEditText = (EditText)localView1.findViewById(2131361952);
      this.H = localEditText;
      Button localButton1 = (Button)findViewById(2131361966);
      af localaf = new af(this);
      localButton1.setOnClickListener(i1);
      Button localButton2 = (Button)findViewById(2131361967);
      ad localad = new ad(this);
      localButton2.setOnClickListener(i1);
      ImageView localImageView1 = (ImageView)localViewGroup2.findViewById(2131361979);
      this.c = localImageView1;
      ImageView localImageView2 = this.c;
      ae localae = new ae(this);
      localImageView2.setOnClickListener(i1);
      ImageView localImageView3 = this.c;
      registerForContextMenu(localImageView3);
      View localView2 = localViewGroup2.findViewById(2131361984);
      aj localaj = new aj(this);
      localView2.setOnClickListener(localaj);
      Button localButton3 = (Button)findViewById(2131361968);
      ak localak = new ak(this);
      localButton3.setOnClickListener(localak);
    }
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    super.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
    paramContextMenu.setHeaderTitle("閫夋");
    paramContextMenu.add(0, 0, 0, "鐩告").setIcon(2130837645);
    paramContextMenu.add(0, 1, 0, "鎵嬫").setIcon(2130837648);
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 0:
    }
    while (true)
    {
      return i1;
      Object localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView = l();
      localObject = ((AlertDialog.Builder)localObject).setView(localView);
      d locald = new d(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165642, locald);
      e locale = new e(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, locale).create();
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131296259, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i1 = 1;
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("MyProfileActivity", str);
    int i2 = paramInt + -1;
    if (i2 == 0)
    {
      this.w.performClick();
      CharSequence localCharSequence1 = this.w.getPrompt();
      Toast.makeText(this, localCharSequence1, i1).show();
    }
    while (true)
    {
      return;
      if (i1 == i2)
        showDialog(0);
      if (2 == i2)
      {
        this.x.performClick();
        CharSequence localCharSequence2 = this.x.getPrompt();
        Toast.makeText(this, localCharSequence2, i1).show();
      }
      if (3 == i2)
      {
        this.y.performClick();
        CharSequence localCharSequence3 = this.y.getPrompt();
        Toast.makeText(this, localCharSequence3, i1).show();
      }
      if (4 == i2)
      {
        this.z.performClick();
        CharSequence localCharSequence4 = this.z.getPrompt();
        Toast.makeText(this, localCharSequence4, i1).show();
      }
      if (5 == i2)
      {
        this.A.performClick();
        CharSequence localCharSequence5 = this.A.getPrompt();
        Toast.makeText(this, localCharSequence5, i1).show();
      }
      if (6 == i2)
      {
        this.B.performClick();
        CharSequence localCharSequence6 = this.B.getPrompt();
        Toast.makeText(this, localCharSequence6, i1).show();
      }
      if (7 == i2)
      {
        this.C.performClick();
        CharSequence localCharSequence7 = this.C.getPrompt();
        Toast.makeText(this, localCharSequence7, i1).show();
      }
      if (8 != i2)
        continue;
      this.D.performClick();
      CharSequence localCharSequence8 = this.D.getPrompt();
      Toast.makeText(this, localCharSequence8, i1).show();
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    com.jiayuan.util.a.a("MyProfileActivity", "back key pressed");
    boolean bool1 = MainActivity.a(this, paramInt, paramKeyEvent);
    int i1;
    if (bool1)
    {
      com.jiayuan.util.a.a("MyProfileActivity", "back key pressed 000");
      i1 = 1;
    }
    while (true)
    {
      return i1;
      com.jiayuan.util.a.a("MyProfileActivity", "back key pressed 111");
      boolean bool2 = super.onKeyDown(paramInt, paramKeyEvent);
    }
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    Intent localIntent1 = 1;
    int i1 = paramMenuItem.getItemId();
    boolean bool;
    switch (i1)
    {
    default:
      bool = super.onOptionsItemSelected(paramMenuItem);
    case 2131362251:
    case 2131362253:
    case 2131362252:
    }
    while (true)
    {
      return bool;
      com.jiayuan.util.a.a("MyProfileActivity", "PHOTO_MANAGER_MENU");
      Intent localIntent2 = new Intent();
      int i2 = this.p.o;
      localIntent2.putExtra("photo_privacy", i2);
      localIntent2.setClass(this, MyProfilePhotoActivity.class);
      startActivity(localIntent2);
      localIntent2 = localIntent1;
      continue;
      com.jiayuan.util.a.a("MyProfileActivity", "LOGOUT_MENU");
      n();
      localIntent2 = localIntent1;
      continue;
      m();
      localIntent2 = localIntent1;
    }
  }

  protected void onResume()
  {
    super.onResume();
    com.jiayuan.util.a.a("MyProfileActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.MyProfileActivity
 * JD-Core Version:    0.5.4
 */