package com.jiayuan.myprofile;

public abstract interface p
{
  public abstract void a_(String paramString);

  public abstract void b(String paramString);

  public abstract void c();

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.p
 * JD-Core Version:    0.5.4
 */