package com.jiayuan.myprofile;

import com.jiayuan.util.picker.b;

class am
  implements b
{
  am(MyProfileActivity paramMyProfileActivity, String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    ap localap1 = this.a.b;
    String str1 = this.b[paramInt1];
    localap1.b = str1;
    this.a.b.d = paramInt1;
    ap localap2 = this.a.b;
    String str2 = this.c[paramInt1][paramInt2];
    localap2.c = str2;
    this.a.b.e = paramInt2;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.am
 * JD-Core Version:    0.5.4
 */