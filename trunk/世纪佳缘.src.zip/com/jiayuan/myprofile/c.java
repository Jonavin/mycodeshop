package com.jiayuan.myprofile;

import android.graphics.Bitmap;

public abstract interface c
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.c
 * JD-Core Version:    0.5.4
 */