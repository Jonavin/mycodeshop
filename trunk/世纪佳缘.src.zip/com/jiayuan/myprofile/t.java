package com.jiayuan.myprofile;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class t
  implements View.OnTouchListener
{
  t(MyProfilePhotoGalleryActivity paramMyProfilePhotoGalleryActivity)
  {
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return MyProfilePhotoGalleryActivity.e(this.a).onTouchEvent(paramMotionEvent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.t
 * JD-Core Version:    0.5.4
 */