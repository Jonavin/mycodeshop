package com.jiayuan.myprofile;

import android.widget.ImageView;
import android.widget.TextView;

final class ac
{
  TextView a;
  TextView b;
  ImageView c;
  int d;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ac
 * JD-Core Version:    0.5.4
 */