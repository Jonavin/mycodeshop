package com.jiayuan.myprofile;

public abstract interface aa
{
  public abstract void a(String paramString);

  public abstract void b();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.aa
 * JD-Core Version:    0.5.4
 */