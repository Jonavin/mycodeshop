package com.jiayuan.myprofile;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.mateselection.b;
import java.util.ArrayList;
import java.util.List;

class a extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  a(MyMateSelectionActivity paramMyMateSelectionActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903067, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    ac localac = (ac)paramView.getTag();
    localac.d = paramInt;
    paramView.setTag(localac);
    TextView localTextView1 = localac.a;
    String str1 = ((b)MyMateSelectionActivity.a(this.b).get(paramInt)).a;
    localTextView1.setText(str1);
    if (paramInt == 0)
    {
      TextView localTextView2 = localac.b;
      String str2 = String.valueOf(((b)MyMateSelectionActivity.a(this.b).get(paramInt)).b);
      StringBuilder localStringBuilder1 = new StringBuilder(localac).append(" - ");
      String str3 = ((b)MyMateSelectionActivity.a(this.b).get(paramInt)).c;
      String str4 = str3 + "�";
      localTextView2.setText(localac);
    }
    while (true)
    {
      return;
      if (1 == paramInt)
      {
        TextView localTextView3 = localac.b;
        String str5 = String.valueOf(((b)MyMateSelectionActivity.a(this.b).get(paramInt)).b);
        StringBuilder localStringBuilder2 = new StringBuilder(localac).append(" ");
        String str6 = ((b)MyMateSelectionActivity.a(this.b).get(paramInt)).c;
        String str7 = str6;
        localTextView3.setText(localac);
      }
      if (2 == paramInt)
      {
        TextView localTextView4 = localac.b;
        String str8 = String.valueOf(((b)MyMateSelectionActivity.a(this.b).get(paramInt)).b);
        StringBuilder localStringBuilder3 = new StringBuilder(localac).append(" - ");
        String str9 = ((b)MyMateSelectionActivity.a(this.b).get(paramInt)).c;
        String str10 = str9 + "鍘";
        localTextView4.setText(localac);
      }
      TextView localTextView5 = localac.b;
      String str11 = String.valueOf(((b)MyMateSelectionActivity.a(this.b).get(paramInt)).b);
      StringBuilder localStringBuilder4 = new StringBuilder(localac);
      String str12 = ((b)MyMateSelectionActivity.a(this.b).get(paramInt)).c;
      String str13 = localac;
      localTextView5.setText(localac);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903067, paramViewGroup, null);
      ac localac = new ac(null);
      localObject = (TextView)localView.findViewById(2131361944);
      localac.a = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361945);
      localac.b = ((TextView)localObject);
      localObject = (ImageView)localView.findViewById(2131361946);
      localac.c = ((ImageView)localObject);
      localView.setTag(localac);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    ac localac = (ac)((View)paramView.getTag()).getTag();
    com.jiayuan.util.a.a("MyMateSelectionActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.a
 * JD-Core Version:    0.5.4
 */