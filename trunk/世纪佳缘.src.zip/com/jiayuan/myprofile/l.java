package com.jiayuan.myprofile;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.mateselection.b;
import java.util.ArrayList;

class l
  implements AdapterView.OnItemSelectedListener
{
  l(MyMateSelectionActivity paramMyMateSelectionActivity, int paramInt)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str1 = "selected pos=" + paramInt;
    com.jiayuan.util.a.a("MyMateSelectionActivity", str1);
    ArrayList localArrayList1 = MyMateSelectionActivity.a(this.a);
    int i = this.b;
    b localb = (b)localArrayList1.get(i);
    String str2 = paramAdapterView.getItemAtPosition(paramInt).toString();
    localb.b = str2;
    ArrayList localArrayList2 = MyMateSelectionActivity.a(this.a);
    int j = this.b;
    ((b)localArrayList2.get(j)).d = paramInt;
    paramAdapterView.setVisibility(0);
    MyMateSelectionActivity.f(this.a).notifyDataSetChanged();
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.l
 * JD-Core Version:    0.5.4
 */