package com.jiayuan.myprofile;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.BadTokenException;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.FrameLayout.LayoutParams;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.Toast;
import android.widget.ViewSwitcher.ViewFactory;
import com.jiayuan.MyActivity;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MyProfilePhotoGalleryActivity extends MyActivity
  implements AdapterView.OnItemSelectedListener, ViewSwitcher.ViewFactory, aa, c
{
  int a;
  int b;
  ProgressDialog c;
  int d = null;
  private ArrayList e;
  private ArrayList f;
  private ArrayList g;
  private ArrayList h;
  private GestureDetector i;
  private Gallery j;
  private ImageSwitcher k;
  private an l;
  private int m = null;
  private Context n = this;
  private GestureDetector.OnGestureListener o;

  public MyProfilePhotoGalleryActivity()
  {
    r localr = new r(this);
    this.o = localr;
  }

  private void a(Menu paramMenu)
  {
    paramMenu.add(0, 1, 0, 2131165588).setIcon(2130837646);
  }

  public void a()
  {
    int i1 = 1;
    a.a("MyProfilePhotoGalleryActivity", "Delete photo in MyProfilePhotoGalleryActivity");
    int i2 = this.j.getSelectedItemPosition();
    String str1 = (String)this.e.get(i2);
    ArrayList localArrayList1 = this.h;
    Object localObject = (String)this.g.get(i2);
    localArrayList1.add(localObject);
    localObject = new b(this);
    Collections.sort(this.h, (Comparator)localObject);
    ArrayList localArrayList2 = 0;
    localArrayList1 = localArrayList2;
    label82: int i3 = this.h.size();
    if (localArrayList1 >= i3)
    {
      this.f.remove(i2);
      this.e.remove(i2);
      this.g.remove(i2);
      i3 = this.j.getSelectedItemPosition();
      int i4 = this.f.size() - i1;
      if (i3 > i2)
        i3 = this.f.size() - i1;
      if (this.f.size() != 0)
        break label321;
      finish();
      label176: Intent localIntent = new Intent();
      Bundle localBundle = new Bundle();
      ArrayList localArrayList4 = this.h;
      localBundle.putStringArrayList("delete_indexs", localArrayList4);
      localIntent.putExtras(localBundle);
      setResult(-1, localIntent);
      if (this.f.size() != 0)
        break label360;
      finish();
    }
    while (true)
    {
      new o(this, "photo", str1).a();
      return;
      StringBuilder localStringBuilder = new StringBuilder("mDelIndexData.get(").append(localArrayList1).append(")=");
      String str2 = (String)this.h.get(localArrayList1);
      str2 = str2;
      a.a("MyProfilePhotoGalleryActivity", str2);
      ArrayList localArrayList3 = localArrayList1 + 1;
      localArrayList1 = localArrayList3;
      break label82:
      label321: this.j.setSelection(localArrayList3);
      ImageSwitcher localImageSwitcher = this.k;
      Drawable localDrawable = (Drawable)this.f.get(localArrayList3);
      localImageSwitcher.setImageDrawable(localArrayList3);
      break label176:
      label360: this.l.notifyDataSetChanged();
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    String str = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    a.a("MyProfilePhotoGalleryActivity", str);
    int i3 = this.d;
    this.d = (++i3);
    int i1;
    if (paramBitmap == null)
    {
      localObject = com.jiayuan.util.o.l();
      str = "m";
      localObject = ((String)localObject).equals(str);
      if (localObject != 0)
      {
        localObject = getResources();
        i1 = 2130837630;
      }
    }
    for (Object localObject = BitmapFactory.decodeResource((Resources)localObject, i1); ; localObject = paramBitmap)
      while (true)
      {
        BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject);
        this.f.set(paramInt, localBitmapDrawable);
        this.l.notifyDataSetChanged();
        int i4 = this.m;
        if (paramInt == localObject)
          this.k.setImageDrawable(localBitmapDrawable);
        int i5 = this.d;
        int i6 = this.e.size();
        if (i5 == i6)
          this.c.dismiss();
        return;
        localObject = getResources();
        int i2 = 2130837628;
        localObject = BitmapFactory.decodeResource((Resources)localObject, i2);
      }
  }

  public void a(String paramString)
  {
    this.c.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
  }

  public void c()
  {
    this.c.dismiss();
  }

  public View makeView()
  {
    ImageView localImageView = new ImageView(this);
    localImageView.setBackgroundColor(-16777216);
    ImageView.ScaleType localScaleType = ImageView.ScaleType.FIT_CENTER;
    localImageView.setScaleType(localScaleType);
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    localImageView.setLayoutParams(localLayoutParams);
    return localImageView;
  }

  public void onCreate(Bundle paramBundle)
  {
    Object localObject1 = 0;
    int i1 = 1;
    super.onCreate(paramBundle);
    getWindow().setFlags(1024, 1024);
    requestWindowFeature(i1);
    Object localObject2 = this.o;
    Object localObject4 = new GestureDetector(this, (GestureDetector.OnGestureListener)localObject2);
    this.i = ((GestureDetector)localObject4);
    setContentView(2130903076);
    localObject4 = "MyProfilePhotoGalleryActivity";
    localObject2 = "onCreate";
    a.a((String)localObject4, (String)localObject2);
    try
    {
      localObject2 = getResources();
      int i2 = 2131165195;
      localObject2 = ((Resources)localObject2).getString(i2);
      localObject4 = ProgressDialog.show(this, "", (CharSequence)localObject2);
      this.c = ((ProgressDialog)localObject4);
      localObject4 = this.c;
      boolean bool = true;
      ((ProgressDialog)localObject4).setCancelable(bool);
      label128: localObject4 = com.jiayuan.util.o.d(this);
      this.a = localObject4;
      localObject4 = com.jiayuan.util.o.e(this);
      this.b = localObject4;
      localObject4 = getIntent();
      Object localObject3 = ((Intent)localObject4).getExtras();
      Object localObject5 = "selected_index";
      localObject3 = ((Bundle)localObject3).getInt((String)localObject5);
      this.m = localObject3;
      localObject3 = "photo_urls";
      localObject4 = ((Intent)localObject4).getStringArrayListExtra((String)localObject3);
      this.e = ((ArrayList)localObject4);
      localObject4 = new ArrayList();
      this.h = ((ArrayList)localObject4);
      localObject4 = new ArrayList();
      this.g = ((ArrayList)localObject4);
      localObject4 = localObject1;
      localObject3 = this.e.size();
      if (localObject4 >= localObject3)
      {
        localObject4 = new ArrayList();
        this.f = ((ArrayList)localObject4);
        localObject4 = this.e.size();
      }
      for (localObject3 = localObject1; ; ++localObject3)
      {
        if (localObject3 >= localObject4)
        {
          ArrayList localArrayList1 = this.e;
          int i3 = this.a;
          int i4 = this.b;
          new w(this, localArrayList1, i3, i4).a();
          an localan1 = new an(this, this);
          this.l = localan1;
          Gallery localGallery1 = (Gallery)findViewById(2131361999);
          this.j = localGallery1;
          Gallery localGallery2 = this.j;
          an localan2 = this.l;
          localGallery2.setAdapter(localan2);
          Gallery localGallery3 = this.j;
          int i5 = this.m;
          localGallery3.setSelection(i5);
          this.j.setOnItemSelectedListener(this);
          ImageSwitcher localImageSwitcher1 = (ImageSwitcher)findViewById(2131361998);
          this.k = localImageSwitcher1;
          this.k.setFactory(this);
          ImageSwitcher localImageSwitcher2 = this.k;
          Animation localAnimation1 = AnimationUtils.loadAnimation(this, 17432576);
          localImageSwitcher2.setInAnimation(localAnimation1);
          ImageSwitcher localImageSwitcher3 = this.k;
          Animation localAnimation2 = AnimationUtils.loadAnimation(this, 17432577);
          localImageSwitcher3.setOutAnimation(localAnimation2);
          this.k.setLongClickable(i1);
          ImageSwitcher localImageSwitcher4 = this.k;
          t localt = new t(this);
          localImageSwitcher4.setOnTouchListener(localt);
          Intent localIntent = new Intent();
          Bundle localBundle = new Bundle();
          ArrayList localArrayList2 = this.h;
          localBundle.putStringArrayList("delete_indexs", localArrayList2);
          localIntent.putExtras(localBundle);
          setResult(-1, localIntent);
          return;
          localObject3 = this.g;
          localObject5 = localObject4;
          ((ArrayList)localObject3).add(localObject5);
          ++localObject4;
        }
        localObject5 = com.jiayuan.util.o.l().equals("m");
        if (localObject5 == 0)
          break;
        localObject5 = BitmapFactory.decodeResource(getResources(), 2130837631);
        BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject5);
        this.f.add(localBitmapDrawable);
      }
      localObject5 = BitmapFactory.decodeResource(getResources(), 2130837629);
    }
    catch (Exception localException)
    {
      break label128:
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
      break label128:
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    a(paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    ImageSwitcher localImageSwitcher = this.k;
    Drawable localDrawable = (Drawable)this.f.get(paramInt);
    localImageSwitcher.setImageDrawable(this);
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i1 = 2131165589;
    int i2 = paramMenuItem.getItemId();
    boolean bool;
    switch (i2)
    {
    default:
      bool = super.onOptionsItemSelected(paramMenuItem);
    case 1:
    }
    while (true)
    {
      return bool;
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this).setTitle(i1).setMessage(i1);
      s locals = new s(this);
      localBuilder = localBuilder.setPositiveButton(2131165591, locals);
      q localq = new q(this);
      localBuilder.setNegativeButton(2131165590, localq).create().show();
      int i3 = 1;
    }
  }

  protected void onResume()
  {
    super.onResume();
    a.a("MyProfilePhotoGalleryActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.MyProfilePhotoGalleryActivity
 * JD-Core Version:    0.5.4
 */