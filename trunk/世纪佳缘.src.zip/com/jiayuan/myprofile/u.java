package com.jiayuan.myprofile;

import android.graphics.Bitmap;
import org.json.JSONArray;
import org.json.JSONObject;

public abstract interface u
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a(JSONArray paramJSONArray);

  public abstract void a(JSONObject paramJSONObject);

  public abstract void a_(String paramString);

  public abstract void b();

  public abstract void d();

  public abstract void d(String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.u
 * JD-Core Version:    0.5.4
 */