package com.jiayuan.myprofile;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;
import java.util.ArrayList;

class ag
  implements AdapterView.OnItemSelectedListener
{
  ag(MyProfileActivity paramMyProfileActivity, int paramInt)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder("selected=");
    String str1 = paramAdapterView.getItemAtPosition(paramInt).toString();
    String str2 = str1;
    a.a("MyProfileActivity", str2);
    ArrayList localArrayList1 = MyProfileActivity.a(this.a);
    int i = this.b;
    ap localap = (ap)localArrayList1.get(i);
    String str3 = paramAdapterView.getItemAtPosition(paramInt).toString();
    localap.b = str3;
    ArrayList localArrayList2 = MyProfileActivity.a(this.a);
    int j = this.b;
    ((ap)localArrayList2.get(j)).d = paramInt;
    paramAdapterView.setVisibility(0);
    MyProfileActivity.f(this.a).notifyDataSetChanged();
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.ag
 * JD-Core Version:    0.5.4
 */