package com.jiayuan.myprofile;

import android.widget.ImageView;

public final class aq
{
  public ImageView a;

  public aq(MyProfilePhotoActivity paramMyProfilePhotoActivity)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.aq
 * JD-Core Version:    0.5.4
 */