package com.jiayuan.myprofile;

import android.app.Activity;
import android.graphics.Bitmap;
import com.jiayuan.a.c;
import com.jiayuan.a.d;
import com.jiayuan.a.e;
import com.jiayuan.a.f;
import com.jiayuan.a.k;
import com.jiayuan.a.n;
import com.jiayuan.a.w;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class x
  implements c, e, n, w
{
  public u a;
  private String b;
  private int c;
  private int d;
  private Activity e;

  public x(u paramu, String paramString, int paramInt1, int paramInt2)
  {
    Activity localActivity = (Activity)paramu;
    this.e = localActivity;
    this.a = paramu;
    this.b = paramString;
    this.c = paramInt1;
    this.d = paramInt2;
  }

  public void a()
  {
    a.a("MyProfileDataProcessing", "execute()");
    this.a.b();
    ArrayList localArrayList = new ArrayList();
    Integer localInteger1 = Integer.valueOf(3);
    localArrayList.add(localInteger1);
    Integer localInteger2 = Integer.valueOf(2);
    localArrayList.add(localInteger2);
    Integer localInteger3 = Integer.valueOf(105);
    localArrayList.add(localInteger3);
    Integer localInteger4 = Integer.valueOf(6);
    localArrayList.add(localInteger4);
    Integer localInteger5 = Integer.valueOf(5);
    localArrayList.add(localInteger5);
    Integer localInteger6 = Integer.valueOf(112);
    localArrayList.add(localInteger6);
    Integer localInteger7 = Integer.valueOf(104);
    localArrayList.add(localInteger7);
    Integer localInteger8 = Integer.valueOf(100);
    localArrayList.add(localInteger8);
    Integer localInteger9 = Integer.valueOf(101);
    localArrayList.add(localInteger9);
    Integer localInteger10 = Integer.valueOf(114);
    localArrayList.add(localInteger10);
    Integer localInteger11 = Integer.valueOf(1);
    localArrayList.add(localInteger11);
    Integer localInteger12 = Integer.valueOf(106);
    localArrayList.add(localInteger12);
    Integer localInteger13 = Integer.valueOf(107);
    localArrayList.add(localInteger13);
    Integer localInteger14 = Integer.valueOf(109);
    localArrayList.add(localInteger14);
    Integer localInteger15 = Integer.valueOf(125);
    localArrayList.add(localInteger15);
    Integer localInteger16 = Integer.valueOf(111);
    localArrayList.add(localInteger16);
    Integer localInteger17 = Integer.valueOf(117);
    localArrayList.add(localInteger17);
    Integer localInteger18 = Integer.valueOf(116);
    localArrayList.add(localInteger18);
    Integer localInteger19 = Integer.valueOf(121);
    localArrayList.add(localInteger19);
    Integer localInteger20 = Integer.valueOf(122);
    localArrayList.add(localInteger20);
    Integer localInteger21 = Integer.valueOf(127);
    localArrayList.add(localInteger21);
    Integer localInteger22 = Integer.valueOf(128);
    localArrayList.add(localInteger22);
    Integer localInteger23 = Integer.valueOf(129);
    localArrayList.add(localInteger23);
    Integer localInteger24 = Integer.valueOf(130);
    localArrayList.add(localInteger24);
    Integer localInteger25 = Integer.valueOf(131);
    localArrayList.add(localInteger25);
    Integer localInteger26 = Integer.valueOf(132);
    localArrayList.add(localInteger26);
    Integer localInteger27 = Integer.valueOf(133);
    localArrayList.add(localInteger27);
    Integer localInteger28 = Integer.valueOf(134);
    localArrayList.add(localInteger28);
    Integer localInteger29 = Integer.valueOf(135);
    localArrayList.add(localInteger29);
    Integer localInteger30 = Integer.valueOf(136);
    localArrayList.add(localInteger30);
    Integer localInteger31 = Integer.valueOf(115);
    localArrayList.add(localInteger31);
    Integer localInteger32 = Integer.valueOf(221);
    localArrayList.add(localInteger32);
    String str1 = this.b;
    new d(this, str1, localArrayList, 0).a();
    String str2 = this.b;
    new k(this, str2).a();
    String str3 = this.b;
    new com.jiayuan.a.u(this, str3, 0).a();
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    this.a.a(paramJSONArray);
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder1 = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("MyProfileDataProcessing", str2);
    this.a.a(paramJSONObject);
    String str3 = "";
    String str4;
    try
    {
      JSONObject localJSONObject = paramJSONObject.getJSONObject("userinfo");
      str4 = "221";
      String str5 = String.valueOf(localJSONObject.getString(str4));
      StringBuilder localStringBuilder2 = new StringBuilder(str5).append("?");
      long l = Calendar.getInstance().getTimeInMillis();
      Object localObject;
      str3 = localObject;
      str4 = str3;
      String str6 = this.b;
      int i = this.c;
      int j = this.d + 12;
      x localx = this;
      new f(localx, str6, str4, -1, i, j).a();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      str4 = str3;
    }
  }

  public void a_(String paramString)
  {
    this.a.a_(paramString);
  }

  public void d()
  {
    this.a.d();
  }

  public void d(String paramString)
  {
    this.a.d(paramString);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.myprofile.x
 * JD-Core Version:    0.5.4
 */