package com.jiayuan;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class LicenseActivity extends Activity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903047);
    String str = getString(2131165333);
    ((TextView)findViewById(2131361821)).setText(str);
    Button localButton = (Button)findViewById(2131361822);
    g localg = new g(this);
    localButton.setOnClickListener(localg);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.LicenseActivity
 * JD-Core Version:    0.5.4
 */