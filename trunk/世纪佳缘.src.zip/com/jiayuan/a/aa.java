package com.jiayuan.a;

public abstract interface aa
{
  public abstract void a_(String paramString);

  public abstract void b(int paramInt1, int paramInt2);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.aa
 * JD-Core Version:    0.5.4
 */