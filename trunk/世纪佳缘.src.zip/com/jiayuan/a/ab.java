package com.jiayuan.a;

import org.json.JSONObject;

public abstract interface ab
{
  public abstract void a_(String paramString);

  public abstract void b(JSONObject paramJSONObject);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.ab
 * JD-Core Version:    0.5.4
 */