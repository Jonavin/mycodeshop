package com.jiayuan.a;

import android.os.AsyncTask;
import com.jiayuan.login.k;
import com.jiayuan.util.o;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;

public class t extends AsyncTask
  implements com.jiayuan.login.a
{
  public g a;
  private String b = null;

  protected String a(String[] paramArrayOfString)
  {
    com.jiayuan.util.a.a("NetBasicAsyncTask", "doInBackground");
    String str1 = paramArrayOfString[null];
    com.jiayuan.util.a.a("NetBasicAsyncTask", str1);
    String str2 = null;
    try
    {
      str2 = paramArrayOfString[str2];
      this.b = str2;
      str2 = c();
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      str2 = "";
    }
  }

  public void a()
  {
  }

  public void a(String paramString)
  {
  }

  protected void a(Integer[] paramArrayOfInteger)
  {
    StringBuilder localStringBuilder = new StringBuilder("onProgressUpdate");
    String str1 = paramArrayOfInteger[null].toString();
    String str2 = str1;
    com.jiayuan.util.a.a("NetBasicAsyncTask", str2);
    this.a.a(paramArrayOfInteger);
  }

  public void b()
  {
  }

  public void b(String paramString)
  {
    Object localObject = "NetBasicAsyncTask";
    String str1 = "onGetLoginData result=" + paramString;
    com.jiayuan.util.a.a((String)localObject, str1);
    try
    {
      localObject = new JSONObject(paramString);
      int i = ((JSONObject)localObject).getInt("retcode");
      if (1 == i)
      {
        o.a(((JSONObject)localObject).getString("uid"));
        o.b(((JSONObject)localObject).getString("token"));
        StringBuilder localStringBuilder1 = new StringBuilder("onGetLoginData uid=");
        String str2 = o.e();
        String str3 = str2;
        com.jiayuan.util.a.a("NetBasicAsyncTask", str3);
        StringBuilder localStringBuilder2 = new StringBuilder("onGetLoginData token=");
        String str4 = o.f();
        String str5 = str4;
        com.jiayuan.util.a.a("NetBasicAsyncTask", str5);
        this.a.a(0, "");
      }
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  protected String c()
  {
    Object localObject2;
    Object localObject3;
    try
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      Object localObject1 = this.b;
      localObject2 = new URL((String)localObject1);
      localObject1 = ((URL)localObject2).getHost();
      boolean bool = ((String)localObject1).toLowerCase().endsWith("www.miuu.cn");
      if (!bool)
        break label256;
      localObject3 = this.b.replace((CharSequence)localObject1, "59.151.18.55");
      localObject2 = new URL((String)localObject3);
      localObject3 = localObject2;
      label68: localObject2 = (HttpURLConnection)((URL)localObject3).openConnection();
      ((HttpURLConnection)localObject2).setRequestMethod("GET");
      localObject3 = "url=" + localObject3;
      com.jiayuan.util.a.a("NetBasicAsyncTask", (String)localObject3);
      ((HttpURLConnection)localObject2).setRequestProperty("Host", (String)localObject1);
      ((HttpURLConnection)localObject2).setRequestProperty("Authorization", "Basic bG92ZTIxY246amlheXVhbiFAIw==");
      ((HttpURLConnection)localObject2).setConnectTimeout(10000);
      ((HttpURLConnection)localObject2).connect();
      localObject1 = ((HttpURLConnection)localObject2).getInputStream();
      InputStreamReader localInputStreamReader = new InputStreamReader((InputStream)localObject1, "UTF-8");
      localObject3 = new BufferedReader(localInputStreamReader);
      localObject1 = ((BufferedReader)localObject3).readLine();
      if (localObject1 == null)
      {
        ((HttpURLConnection)localObject2).disconnect();
        localObject2 = super.getClass().getName();
        StringBuilder localStringBuilder2 = new StringBuilder("sb=");
        String str1 = localStringBuilder1.toString();
        String str2 = str1;
        com.jiayuan.util.a.a((String)localObject2, str2);
        localObject2 = localStringBuilder1.toString();
        label225: return localObject2;
      }
      label256: localStringBuilder1.append((String)localObject1);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      this.a.a("NETWORK_ERROR");
      localObject2 = "NETWORK_ERROR";
      break label225:
      localObject3 = localObject2;
      break label68:
    }
  }

  protected void c(String paramString)
  {
    int i = 1;
    com.jiayuan.util.a.a("NetBasicAsyncTask", "onPostExecute");
    int j = -1;
    int k = paramString.indexOf("-1025,\"msg\":\"invalid parameter: token\"");
    long l;
    if (j != k)
    {
      String str1 = "NetBasicAsyncTask";
      com.jiayuan.util.a.a(str1, "------ token is expire -------");
      k.a = str1;
      if (str1 != null)
        l = 2000L;
    }
    try
    {
      Thread.sleep(l);
      label53: this.a.a(i, paramString);
      label64: return;
    }
    catch (InterruptedException localInterruptedException)
    {
      localInterruptedException.printStackTrace();
      break label53:
      String str2 = o.g();
      String str3 = o.h();
      new k(this, str2, str3).a(0);
      break label64:
      com.jiayuan.util.a.a("NetBasicAsyncTask", "------ token is not expire -------");
      this.a.a(i, paramString);
    }
  }

  public void d()
  {
    this.a.c();
  }

  protected void onCancelled()
  {
    super.onCancelled();
    com.jiayuan.util.a.a("NetBasicAsyncTask", "onCancelled");
    this.a.a();
  }

  protected void onPreExecute()
  {
    com.jiayuan.util.a.a("NetBasicAsyncTask", "onPreExecute");
    this.a.b();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.t
 * JD-Core Version:    0.5.4
 */