package com.jiayuan.a;

public abstract interface w
{
  public abstract void a_(String paramString);

  public abstract void d();

  public abstract void d(String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.w
 * JD-Core Version:    0.5.4
 */