package com.jiayuan.a;

import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class r
  implements q
{
  public b a;
  private String b = "";
  private String c = "";

  public r(b paramb, String paramString)
  {
    this.a = paramb;
    this.b = paramString;
  }

  public void a(int paramInt, String paramString)
  {
    a.a("BlockDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        a.a("BlockDataProcessing", str2);
        b localb = this.a;
        String str3 = this.c;
        localb.a(str3, paramString);
      }
      catch (JSONException localJSONException)
      {
        this.a.d();
      }
    }
  }

  public void a(String paramString)
  {
    a.a("BlockDataProcessing", "execute()");
    this.c = paramString;
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    if (paramString.equalsIgnoreCase("add"))
    {
      localStringBuffer.append("relation/http_blacklist.php?");
      localStringBuffer.append("uid=");
      String str1 = o.e();
      localStringBuffer.append(str1);
      localStringBuffer.append("&type=");
      String str2 = this.c;
      localStringBuffer.append(str2);
      localStringBuffer.append("&black_uid=");
      String str3 = this.b;
      localStringBuffer.append(str3);
      localStringBuffer.append("&mod=");
      localStringBuffer.append("0");
      localStringBuffer.append("&token=");
      String str4 = o.f();
      localStringBuffer.append(str4);
    }
    while (true)
    {
      l locall = new l();
      locall.a = this;
      String str5 = localStringBuffer.toString();
      locall.b(localStringBuffer);
      return;
      if (paramString.equalsIgnoreCase("query"))
      {
        localStringBuffer.append("relation/http_blacklist.php?");
        localStringBuffer.append("uid=");
        String str6 = o.e();
        localStringBuffer.append(str6);
        localStringBuffer.append("&type=");
        String str7 = this.c;
        localStringBuffer.append(str7);
        localStringBuffer.append("&p=");
        localStringBuffer.append("1");
        localStringBuffer.append("&rows=");
        localStringBuffer.append("100");
        localStringBuffer.append("&token=");
        String str8 = o.f();
        localStringBuffer.append(str8);
      }
      if (!paramString.equalsIgnoreCase("delete"))
        continue;
      localStringBuffer.append("relation/http_blacklist.php?");
      localStringBuffer.append("uid=");
      String str9 = o.e();
      localStringBuffer.append(str9);
      localStringBuffer.append("&type=");
      String str10 = this.c;
      localStringBuffer.append(str10);
      localStringBuffer.append("&black_uid=");
      String str11 = this.b;
      localStringBuffer.append(str11);
      localStringBuffer.append("&token=");
      String str12 = o.f();
      localStringBuffer.append(str12);
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("BlockDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("BlockDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("BlockDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.r
 * JD-Core Version:    0.5.4
 */