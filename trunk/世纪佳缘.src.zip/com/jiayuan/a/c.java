package com.jiayuan.a;

import org.json.JSONArray;

public abstract interface c
{
  public abstract void a(JSONArray paramJSONArray, int paramInt);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.c
 * JD-Core Version:    0.5.4
 */