package com.jiayuan.a;

import android.graphics.Bitmap;

public abstract interface p
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.p
 * JD-Core Version:    0.5.4
 */