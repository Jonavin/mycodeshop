package com.jiayuan.a;

import com.jiayuan.util.a;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class u
  implements q
{
  public c a;
  private String b = "";
  private int c = -1;

  public u(c paramc, String paramString, int paramInt)
  {
    this.a = paramc;
    this.b = paramString;
    this.c = paramInt;
  }

  public void a()
  {
    a.a("ServiceTypeDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("cc/person_service.php?");
    localStringBuffer.append("looked_uid=");
    String str1 = this.b;
    localStringBuffer.append(str1);
    l locall = new l();
    locall.a = this;
    String str2 = localStringBuffer.toString();
    locall.b(str2);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("ServiceTypeDataProcessing", "onPostExecute()");
    boolean bool = paramString.equals("NETWORK_ERROR");
    if (bool)
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        if (localJSONObject.getString("retcode").equalsIgnoreCase("1"));
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        a.a("ServiceTypeDataProcessing", str2);
        c localc = this.a;
        JSONArray localJSONArray = localJSONObject.getJSONArray("service");
        int i = this.c;
        localc.a(localJSONObject, i);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str3 = localJSONException.toString();
        String str4 = str3;
        a.a("ServiceTypeDataProcessing", str4);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("ServiceTypeDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("ServiceTypeDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("ServiceTypeDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.u
 * JD-Core Version:    0.5.4
 */