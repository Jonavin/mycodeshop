package com.jiayuan.a;

public abstract interface g
{
  public abstract void a();

  public abstract void a(int paramInt, String paramString);

  public abstract void a(String paramString);

  public abstract void a(Integer[] paramArrayOfInteger);

  public abstract void b();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.g
 * JD-Core Version:    0.5.4
 */