package com.jiayuan.a;

import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class h
  implements q
{
  public static int b = null;
  public static int c = 1;
  public static int d = 2;
  public static int e = 3;
  public static int f = 4;
  public aa a;
  private String g;
  private int h;
  private int i;

  public h(aa paramaa, String paramString, int paramInt1, int paramInt2)
  {
    this.a = paramaa;
    this.i = paramInt2;
    this.g = paramString;
    this.h = paramInt1;
  }

  public void a()
  {
    a.a("MatchOkDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/dosend.php?");
    localStringBuffer.append("from=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&to=");
    String str2 = this.g;
    localStringBuffer.append(str2);
    localStringBuffer.append("&withtype=");
    localStringBuffer.append("1");
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    localStringBuffer.append("&clientid=");
    String str4 = o.b();
    localStringBuffer.append(str4);
    localStringBuffer.append("&src=");
    int j = this.i;
    localStringBuffer.append(j);
    l locall = new l();
    locall.a = this;
    String str5 = localStringBuffer.toString();
    locall.b(str5);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("MatchOkDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        int j = new JSONObject(paramString).getInt("retcode");
        aa localaa = this.a;
        int k = this.h;
        localaa.b(k, j);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("MatchOkDataProcessing", str2);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MatchOkDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MatchOkDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MatchOkDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.h
 * JD-Core Version:    0.5.4
 */