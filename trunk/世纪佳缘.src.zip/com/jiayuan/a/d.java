package com.jiayuan.a;

import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class d
  implements q
{
  public static int a = 1;
  public static int b = 2;
  public static int c = 3;
  public static int d = 4;
  public static int e = null;
  public e f;
  private String g;
  private List h;
  private int i;

  public d(e parame, String paramString, ArrayList paramArrayList, int paramInt)
  {
    this.f = parame;
    this.i = paramInt;
    this.g = paramString;
    this.h = paramArrayList;
  }

  public void a()
  {
    Object localObject1 = 1;
    String str1 = 0;
    a.a("InfoQueryDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("uic/infoquery.php?");
    localStringBuffer.append("uid=");
    String str2 = o.e();
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    str2 = o.f();
    localStringBuffer.append(str2);
    localStringBuffer.append("&q_uid=");
    str2 = this.g;
    localStringBuffer.append(str2);
    localStringBuffer.append("&userinfotypes=[");
    str2 = str1;
    label96: int k = this.h.size();
    if (str2 >= k)
    {
      int j = localStringBuffer.length() - localObject1;
      localStringBuffer.deleteCharAt(j);
      localStringBuffer.append("]");
      localStringBuffer.append("&ifself=");
      localObject2 = this.g;
      String str3 = o.e();
      localObject2 = ((String)localObject2).equalsIgnoreCase(str3);
      if (localObject2 == 0)
        break label289;
    }
    for (Object localObject2 = localObject1; ; localObject2 = str1)
    {
      localStringBuffer.append(localObject2);
      if (this.i > 0)
      {
        localStringBuffer.append("&src=");
        int l = this.i;
        localStringBuffer.append(l);
      }
      String str4 = "strUtl=" + localStringBuffer;
      a.a("InfoQueryDataProcessing", str4);
      l locall = new l();
      locall.a = this;
      String str5 = localStringBuffer.toString();
      locall.b(localStringBuffer);
      return;
      Object localObject3 = this.h.get(localObject2);
      localStringBuffer.append(localObject3).append(",");
      ++localObject2;
      label289: break label96:
    }
  }

  public void a(int paramInt, String paramString)
  {
    a.a("InfoQueryDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.f.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        this.f.a(localJSONObject);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("InfoQueryDataProcessing", str2);
        this.f.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("InfoQueryDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("InfoQueryDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("InfoQueryDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.f.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.d
 * JD-Core Version:    0.5.4
 */