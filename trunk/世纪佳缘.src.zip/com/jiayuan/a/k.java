package com.jiayuan.a;

import com.jiayuan.util.a;
import org.json.JSONException;
import org.json.JSONObject;

public class k
  implements q
{
  public w a;
  private String b = "";

  public k(w paramw, String paramString)
  {
    this.a = paramw;
    this.b = paramString;
  }

  public void a()
  {
    a.a("NoteDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("uic/simplequery.php?");
    localStringBuffer.append("oper=");
    localStringBuffer.append("getnote");
    localStringBuffer.append("&uid=");
    String str1 = this.b;
    localStringBuffer.append(str1);
    l locall = new l();
    locall.a = this;
    String str2 = localStringBuffer.toString();
    locall.b(str2);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("NoteDataProcessing", "onPostExecute()");
    boolean bool = paramString.equals("NETWORK_ERROR");
    if (bool)
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        a.a("NoteDataProcessing", str2);
        if (localJSONObject.getString("retcode").equalsIgnoreCase("1"));
        w localw = this.a;
        String str3 = localJSONObject.getJSONObject("userinfo").getString("note");
        localw.d(localJSONObject);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str4 = localJSONException.toString();
        String str5 = str4;
        a.a("NoteDataProcessing", str5);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("NoteDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("NoteDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("NoteDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.k
 * JD-Core Version:    0.5.4
 */