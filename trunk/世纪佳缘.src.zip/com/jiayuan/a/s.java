package com.jiayuan.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class s extends AsyncTask
  implements com.jiayuan.login.a
{
  public q a;
  public Context b;
  public String c = "--------boundary";
  private String d = null;
  private JSONObject e;
  private Bitmap f;

  protected String a(Object[] paramArrayOfObject)
  {
    com.jiayuan.util.a.a("PostAsyncTask", "doInBackground");
    Object localObject = (String)paramArrayOfObject[null];
    com.jiayuan.util.a.a("PostAsyncTask", (String)localObject);
    localObject = null;
    try
    {
      localObject = (String)paramArrayOfObject[localObject];
      this.d = ((String)localObject);
      localObject = (String)paramArrayOfObject[1];
      JSONObject localJSONObject = new JSONObject((String)localObject);
      this.e = localJSONObject;
      localObject = (Bitmap)paramArrayOfObject[2];
      this.f = ((Bitmap)localObject);
      localObject = c();
      return localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      localObject = "";
    }
  }

  public void a()
  {
  }

  public void a(String paramString)
  {
  }

  protected void a(Integer[] paramArrayOfInteger)
  {
    StringBuilder localStringBuilder = new StringBuilder("onProgressUpdate");
    String str1 = paramArrayOfInteger[null].toString();
    String str2 = str1;
    com.jiayuan.util.a.a("PostAsyncTask", str2);
    this.a.a(paramArrayOfInteger);
  }

  public void b()
  {
  }

  public void b(String paramString)
  {
    try
    {
      int i = new JSONObject(paramString).getInt("retcode");
      if (1 == i)
        this.a.a(0, "");
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      d();
    }
  }

  protected String c()
  {
    StringBuilder localStringBuilder1;
    Object localObject1;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    try
    {
      localStringBuilder1 = new StringBuilder();
      localObject1 = this.d;
      localObject2 = new URL((String)localObject1);
      localObject1 = ((URL)localObject2).getHost();
      localObject3 = ((String)localObject1).toLowerCase();
      localObject4 = ".miuu.cn";
      localObject3 = ((String)localObject3).endsWith((String)localObject4);
      if (localObject3 != 0)
      {
        localObject3 = this.d;
        localObject4 = "59.151.18.55";
        localObject3 = ((String)localObject3).replace((CharSequence)localObject1, (CharSequence)localObject4);
        localObject2 = new URL((String)localObject3);
      }
      localObject2 = (HttpURLConnection)((URL)localObject2).openConnection();
      ((HttpURLConnection)localObject2).setRequestMethod("POST");
      ((HttpURLConnection)localObject2).setRequestProperty("Host", (String)localObject1);
      ((HttpURLConnection)localObject2).setRequestProperty("Authorization", "Basic bG92ZTIxY246amlheXVhbiFAIw==");
      ((HttpURLConnection)localObject2).setConnectTimeout(10000);
      ((HttpURLConnection)localObject2).setDoOutput(true);
      ((HttpURLConnection)localObject2).setDoInput(true);
      ((HttpURLConnection)localObject2).setUseCaches(null);
      ((HttpURLConnection)localObject2).setRequestProperty("Connection", "Keep-Alive");
      ((HttpURLConnection)localObject2).setRequestProperty("Charset", "UTF-8");
      ((HttpURLConnection)localObject2).setInstanceFollowRedirects(null);
      ((HttpURLConnection)localObject2).setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
      localObject3 = new StringBuilder("multipart/form-data; boundary=");
      localObject4 = this.c;
      localObject3 = (String)localObject4;
      ((HttpURLConnection)localObject2).setRequestProperty("Content-Type", (String)localObject3);
      ((HttpURLConnection)localObject2).connect();
      localObject1 = ((HttpURLConnection)localObject2).getOutputStream();
      localObject3 = new DataOutputStream((OutputStream)localObject1);
      localObject1 = this.f;
      if (localObject1 != null)
      {
        com.jiayuan.util.a.a("PostAsyncTask", "null != mPostBitmap");
        localObject1 = new ByteArrayOutputStream();
        localObject4 = this.f;
        localObject5 = Bitmap.CompressFormat.PNG;
        ((Bitmap)localObject4).compress((Bitmap.CompressFormat)localObject5, 75, (OutputStream)localObject1);
        localObject4 = new StringBuilder("--");
        localObject5 = this.c;
        localObject4 = ((StringBuilder)localObject4).append((String)localObject5);
        localObject5 = "\r\n";
        localObject4 = (String)localObject5;
        ((DataOutputStream)localObject3).writeBytes((String)localObject4);
        ((DataOutputStream)localObject3).writeBytes("Content-Disposition: form-data; name=\"upload_file\"; filename=\"image.png\"\r\n");
        ((DataOutputStream)localObject3).writeBytes("Content-Type:image/png\r\n");
        localObject4 = "\r\n";
        ((DataOutputStream)localObject3).writeBytes((String)localObject4);
        localObject1 = ((ByteArrayOutputStream)localObject1).toByteArray();
        ((DataOutputStream)localObject3).write(localObject1);
        localObject1 = "\r\n";
        ((DataOutputStream)localObject3).writeBytes((String)localObject1);
        localObject1 = this.e;
        localObject4 = ((JSONObject)localObject1).keys();
        label368: localObject1 = ((Iterator)localObject4).hasNext();
        if (localObject1 != 0)
          break label509;
        ((DataOutputStream)localObject3).flush();
        ((DataOutputStream)localObject3).close();
        localObject1 = ((HttpURLConnection)localObject2).getInputStream();
        InputStreamReader localInputStreamReader = new InputStreamReader((InputStream)localObject1, "UTF-8");
        localObject3 = new BufferedReader(localInputStreamReader);
        label418: localObject1 = ((BufferedReader)localObject3).readLine();
        if (localObject1 != null)
          break label747;
        ((HttpURLConnection)localObject2).disconnect();
        localObject2 = super.getClass().getName();
        StringBuilder localStringBuilder2 = new StringBuilder("sb=");
        String str1 = localStringBuilder1.toString();
        String str2 = str1;
        com.jiayuan.util.a.a((String)localObject2, str2);
        localObject2 = localStringBuilder1.toString();
        label481: return localObject2;
      }
      localObject1 = "PostAsyncTask";
      localObject4 = "null == mPostBitmap";
      label747: label509: com.jiayuan.util.a.a((String)localObject1, (String)localObject4);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      localObject2 = "";
      break label481:
      localObject1 = (String)((Iterator)localObject4).next();
      localObject5 = this.e.getString((String)localObject1);
      String str3 = "key=" + (String)localObject1 + ", value=" + (String)localObject5;
      com.jiayuan.util.a.a("PostAsyncTask", str3);
      StringBuilder localStringBuilder3 = new StringBuilder("--");
      String str4 = this.c;
      String str5 = str4 + "\r\n";
      ((DataOutputStream)localObject3).writeBytes(str5);
      String str6 = "Content-Disposition: form-data; name=\"" + (String)localObject1 + "\"\r\n";
      ((DataOutputStream)localObject3).writeBytes(str6);
      ((DataOutputStream)localObject3).writeBytes("\r\n");
      localObject1 = ((String)localObject1).equalsIgnoreCase("note");
      if (localObject1 != 0)
      {
        localObject1 = new StringBuilder();
        localObject5 = ((String)localObject5).getBytes("utf-8");
        localObject1 = ((StringBuilder)localObject1).append(localObject5);
        localObject5 = "\r\n";
        localObject1 = (String)localObject5;
        ((DataOutputStream)localObject3).writeBytes((String)localObject1);
      }
      localObject5 = String.valueOf(localObject5);
      localObject1 = new StringBuilder((String)localObject5);
      localObject5 = "\r\n";
      localObject1 = (String)localObject5;
      ((DataOutputStream)localObject3).writeBytes((String)localObject1);
      break label368:
      localStringBuilder1.append((String)localObject1);
      break label418:
    }
  }

  protected void c(String paramString)
  {
    com.jiayuan.util.a.a("PostAsyncTask", "onPostExecute");
    this.a.a(1, paramString);
  }

  public void d()
  {
    this.a.d();
  }

  protected void onCancelled()
  {
    super.onCancelled();
    com.jiayuan.util.a.a("PostAsyncTask", "onCancelled");
    this.a.b();
  }

  protected void onPreExecute()
  {
    com.jiayuan.util.a.a("PostAsyncTask", "onPreExecute");
    this.a.c();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.s
 * JD-Core Version:    0.5.4
 */