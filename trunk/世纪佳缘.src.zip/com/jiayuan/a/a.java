package com.jiayuan.a;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.jiayuan.util.o;
import com.jiayuan.util.p;

public class a
  implements q
{
  Context a;
  public j b;

  public a(Context paramContext, j paramj)
  {
    this.a = paramContext;
    this.b = paramj;
  }

  private String e()
  {
    try
    {
      Object localObject = this.a.getPackageManager();
      String str = this.a.getPackageName();
      localObject = ((PackageManager)localObject).getPackageInfo(str, 0).versionName;
      return localObject;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localNameNotFoundException.printStackTrace();
      int i = 0;
    }
  }

  private String f()
  {
    String str1 = o.b(this.a);
    com.jiayuan.util.a.a("getDeviceIMEI", str1);
    String str2 = String.valueOf(o.b(this.a));
    StringBuilder localStringBuilder = new StringBuilder(str2).append("mobilejiayuan");
    String str3 = o.c();
    return p.a(str3);
  }

  public void a()
  {
    l locall = new l();
    locall.a = this;
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("mobile/get_version.php?");
    localStringBuffer.append("version=");
    String str1 = e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&deviceid=");
    String str2 = o.b(this.a);
    localStringBuffer.append(str2);
    localStringBuffer.append("&channelid=");
    String str3 = o.c();
    localStringBuffer.append(str3);
    localStringBuffer.append("&clientid=");
    String str4 = o.b();
    localStringBuffer.append(str4);
    localStringBuffer.append("&token=");
    String str5 = f();
    localStringBuffer.append(str5);
    String str6 = localStringBuffer.toString();
    locall.b(str6);
  }

  public void a(int paramInt, String paramString)
  {
    this.b.a(paramInt, paramString);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.a
 * JD-Core Version:    0.5.4
 */