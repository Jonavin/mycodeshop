package com.jiayuan.a;

public abstract interface q
{
  public abstract void a(int paramInt, String paramString);

  public abstract void a(Integer[] paramArrayOfInteger);

  public abstract void b();

  public abstract void c();

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.q
 * JD-Core Version:    0.5.4
 */