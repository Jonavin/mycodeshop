package com.jiayuan.a;

import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class y
  implements q
{
  public o a;
  private List b;
  private List c;

  public y(o paramo, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    this.a = paramo;
    this.b = paramArrayList1;
    this.c = paramArrayList2;
  }

  public void a()
  {
    int i = 1;
    Object localObject1 = 0;
    a.a("ProfilesDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("uic/multiinfoquery.php?");
    Object localObject2 = "uids=[";
    localStringBuffer.append((String)localObject2);
    Object localObject4 = localObject1;
    localObject2 = this.b.size();
    if (localObject4 >= localObject2)
    {
      j = localStringBuffer.length() - i;
      localStringBuffer.deleteCharAt(j);
      localStringBuffer.append("]&userinfotypes=[");
    }
    Object localObject3;
    for (int j = localObject1; ; ++localObject3)
    {
      int k = this.c.size();
      if (j >= k)
      {
        int l = localStringBuffer.length() - i;
        localStringBuffer.deleteCharAt(l);
        localStringBuffer.append("]");
        String str2 = "strUtl=" + localStringBuffer;
        a.a("ProfilesDataProcessing", str2);
        l locall = new l();
        locall.a = this;
        String str3 = localStringBuffer.toString();
        locall.b(localStringBuffer);
        return;
        String str1 = (String)this.b.get(localObject4);
        localStringBuffer.append(str1).append(",");
        localObject3 = localObject4 + 1;
        localObject4 = localObject3;
      }
      Object localObject5 = this.c.get(localObject3);
      localStringBuffer.append(localObject5).append(",");
    }
  }

  public void a(int paramInt, String paramString)
  {
    a.a("ProfilesDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        this.a.a(localJSONObject);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("ProfilesDataProcessing", str2);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("ProfilesDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("ProfilesDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("ProfilesDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.y
 * JD-Core Version:    0.5.4
 */