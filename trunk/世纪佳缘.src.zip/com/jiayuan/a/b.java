package com.jiayuan.a;

public abstract interface b
{
  public abstract void a(String paramString1, String paramString2);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.b
 * JD-Core Version:    0.5.4
 */