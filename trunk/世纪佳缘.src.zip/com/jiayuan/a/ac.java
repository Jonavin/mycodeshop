package com.jiayuan.a;

import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class ac
  implements q
{
  public v a;
  private String b = "";

  public ac(v paramv, String paramString)
  {
    this.a = paramv;
    this.b = paramString;
  }

  public void a()
  {
    a.a("LastLoginDataProcessing", "execute()");
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("uic/get_lastlogin_time.php?");
    localStringBuffer.append("uid=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&looked_uid=");
    String str2 = this.b;
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    l locall = new l();
    locall.a = this;
    String str4 = localStringBuffer.toString();
    locall.b(str4);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject1 = "onPostExecute()";
    a.a("LastLoginDataProcessing", (String)localObject1);
    boolean bool = paramString.equals("NETWORK_ERROR");
    if (bool)
    {
      this.a.a_(paramString);
      label32: return;
    }
    while (true)
    {
      try
      {
        localObject2 = new JSONObject(paramString);
        Object localObject3 = new StringBuilder("firstReq result.toString():");
        String str1 = ((JSONObject)localObject2).toString();
        localObject3 = str1;
        a.a("LastLoginDataProcessing", (String)localObject3);
        localObject1 = this.a;
        localObject3 = ((JSONObject)localObject2).getInt("retcode");
        int i = ((JSONObject)localObject2).getInt("retcode");
        if (1 != i)
          break label182;
        localObject2 = ((JSONObject)localObject2).getString("last_login");
        ((v)localObject1).a(localObject3, (String)localObject2);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str2 = localJSONException.toString();
        String str3 = str2;
        a.a("LastLoginDataProcessing", str3);
        this.a.d();
      }
      break label32:
      label182: Object localObject2 = "";
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("LastLoginDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("LastLoginDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("LastLoginDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.ac
 * JD-Core Version:    0.5.4
 */