package com.jiayuan.a;

import android.graphics.Bitmap;

public abstract interface n
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.n
 * JD-Core Version:    0.5.4
 */