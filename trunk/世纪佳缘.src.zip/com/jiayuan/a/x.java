package com.jiayuan.a;

import android.content.Context;
import android.location.Location;
import com.jiayuan.util.a;
import com.jiayuan.util.s;
import org.json.JSONException;
import org.json.JSONObject;

public class x
  implements q
{
  public ab a;
  private Context b;
  private String c = "";

  public x(ab paramab, Context paramContext, String paramString)
  {
    this.a = paramab;
    this.b = paramContext;
    this.c = paramString;
  }

  public void a()
  {
    a.a("DistanceDataProcessing", "execute()");
    Location localLocation = s.a(this.b);
    StringBuffer localStringBuffer = new StringBuffer("http://api2.jiayuan.com/geo/");
    localStringBuffer.append("distance.php?");
    localStringBuffer.append("uid=");
    String str1 = this.c;
    localStringBuffer.append(str1);
    localStringBuffer.append("&loc=");
    localStringBuffer.append("{\"lng\":");
    double d1 = localLocation.getLongitude();
    Object localObject1;
    localStringBuffer.append(localObject1);
    localStringBuffer.append(",\"lat\":");
    double d2 = localLocation.getLatitude();
    Object localObject2;
    localStringBuffer.append(localObject2);
    localStringBuffer.append("}");
    l locall = new l();
    locall.a = this;
    String str2 = localStringBuffer.toString();
    locall.b(str2);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("DistanceDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        a.a("DistanceDataProcessing", str2);
        this.a.b(localJSONObject);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str3 = localJSONException.toString();
        String str4 = str3;
        a.a("DistanceDataProcessing", str4);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("DistanceDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("DistanceDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("DistanceDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.x
 * JD-Core Version:    0.5.4
 */