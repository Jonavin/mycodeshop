package com.jiayuan.a;

import android.graphics.Bitmap;
import java.util.ArrayList;

public abstract interface i
{
  public abstract void a(ArrayList paramArrayList);

  public abstract void a_(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.i
 * JD-Core Version:    0.5.4
 */