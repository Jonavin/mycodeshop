package com.jiayuan.a;

import com.jiayuan.util.a;
import com.jiayuan.util.o;

public class l
  implements g
{
  public q a;
  t b;
  private String c = "";
  private int d = null;

  public void a()
  {
    a.a("NetAsyncTask", "onCancelled()");
    this.a.b();
  }

  public void a(int paramInt, String paramString)
  {
    int i = 1;
    a.a("NetAsyncTask", "onPostExecute()");
    if (i == paramInt)
      this.a.a(i, paramString);
    while (true)
    {
      return;
      d();
      String str = this.c;
      b(str);
    }
  }

  public void a(String paramString)
  {
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("NetAsyncTask", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("NetAsyncTask", "onPreExecute()");
    this.a.c();
  }

  public void b(String paramString)
  {
    this.c = paramString;
    t localt1 = new t();
    this.b = localt1;
    this.b.a = this;
    t localt2 = this.b;
    String[] arrayOfString = new String[1];
    String str = this.c;
    arrayOfString[0] = str;
    localt2.execute(arrayOfString);
  }

  public void c()
  {
    this.b.a.c();
  }

  public void d()
  {
    int i = this.c.indexOf("token=");
    int j = "token=".length();
    int k = i + j;
    String str1 = this.c;
    int l = k + 55;
    str1.substring(k, l);
    String str2 = this.c;
    StringBuffer localStringBuffer = new StringBuffer(str2);
    int i1 = k + 55;
    String str3 = o.f();
    localStringBuffer.replace(k, i1, str3);
    String str4 = localStringBuffer.toString();
    this.c = str4;
    StringBuilder localStringBuilder = new StringBuilder("updateUrlToken new mUrl=");
    String str5 = this.c;
    String str6 = str5;
    a.a("NetAsyncTask", str6);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.l
 * JD-Core Version:    0.5.4
 */