package com.jiayuan.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import com.jiayuan.util.q;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class m extends AsyncTask
{
  private p a;
  private String b;
  private int c;
  private int d;
  private int e;
  private int f;
  private int g;
  private String h;
  private Bitmap i;
  private Context j;

  protected Bitmap a(Object[] paramArrayOfObject)
  {
    int k = 0;
    com.jiayuan.util.a.a("PhotoAsyncTask", "doInBackground");
    String str = paramArrayOfObject[null].toString();
    com.jiayuan.util.a.a("PhotoAsyncTask", str);
    Object localObject = null;
    try
    {
      localObject = (String)paramArrayOfObject[localObject];
      this.b = ((String)localObject);
      localObject = (p)paramArrayOfObject[1];
      this.a = ((p)localObject);
      localObject = Integer.parseInt(paramArrayOfObject[2].toString());
      this.c = localObject;
      localObject = Integer.parseInt(paramArrayOfObject[3].toString());
      this.d = localObject;
      localObject = Integer.parseInt(paramArrayOfObject[4].toString());
      this.e = localObject;
      localObject = Integer.parseInt(paramArrayOfObject[5].toString());
      this.f = localObject;
      localObject = Integer.parseInt(paramArrayOfObject[6].toString());
      this.g = localObject;
      localObject = com.jiayuan.util.p.a(this.b);
      this.h = ((String)localObject);
      localObject = com.jiayuan.a.a().b();
      this.j = ((Context)localObject);
      localObject = e();
      if (localObject != 0)
      {
        localObject = this.i;
        return localObject;
      }
      localObject = k;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      localObject = k;
    }
  }

  protected void a(Bitmap paramBitmap)
  {
    int k = 1065353216;
    if (paramBitmap != null);
    try
    {
      int l = paramBitmap.getWidth();
      int i1 = paramBitmap.getHeight();
      int i2 = this.g;
      if (i2 == 0)
      {
        float f1 = l * k;
        float f8 = this.d * k;
        f1 /= f8;
        f8 = i1 * k;
        float f13 = this.e * k;
        f8 /= f13;
        f1 <= f8;
        float f16;
        if (f1 > 0)
        {
          f2 = this.d;
          f8 = i1;
          float f14 = l * k;
          f8 /= f14;
          float f15 = this.d * k;
          f16 = (int)(f8 * f15);
          f8 = f2;
        }
        label205: float f19;
        for (float f2 = f16; ; f5 = f19)
        {
          f8 = f8;
          float f17 = l;
          f8 /= f17;
          float f3 = f2;
          float f18 = i1;
          f3 /= f18;
          Matrix localMatrix1 = new Matrix();
          localMatrix1.postScale(f8, f3);
          int i5 = 0;
          Bitmap localBitmap1 = Bitmap.createBitmap(paramBitmap, i5, 0, l, i1, localMatrix1, true);
          p localp = this.a;
          int i10 = this.c;
          String str1 = this.b;
          localp.a(i10, str1, localBitmap1);
          return;
          float f4 = l;
          float f9 = i1 * k;
          f4 /= f9;
          f9 = this.e * k;
          f5 = (int)(f4 * f9);
          f19 = this.e;
          f9 = f5;
        }
      }
      float f5 = 2;
      int i6 = this.g;
      if (f5 == i6)
      {
        float f6 = l * k;
        float f10 = this.d * k;
        f6 /= f10;
        f10 = i1 * k;
        float f20 = this.e * k;
        f10 /= f20;
        f6 <= f10;
        int i3;
        int i11;
        if (f6 > 0)
        {
          f6 = l;
          f10 = i1 * k;
          f6 /= f10;
          f10 = this.e * k;
          i3 = (int)(f6 * f10);
          int i7 = this.e;
          i11 = i7;
        }
        for (int i12 = i3; ; i12 = i4)
        {
          while (true)
          {
            float f7 = i12;
            float f11 = l;
            f7 /= f11;
            f11 = i11;
            float f21 = i1;
            f11 /= f21;
            Matrix localMatrix2 = new Matrix();
            localMatrix2.postScale(f7, f11);
            Object localObject1 = Bitmap.createBitmap(paramBitmap, 0, 0, l, i1, localMatrix2, true);
            f11 = i12 * k;
            float f22 = this.d * k;
            f11 /= f22;
            float f23 = i11 * k;
            float f24 = this.e * k;
            float f25 = f23 / l;
            f11 <= f25;
            if (f11 > 0)
            {
              i8 = this.d;
              i8 = (i12 - i8) / 2;
            }
            Matrix localMatrix3 = new Matrix();
            localMatrix3.postScale(1065353216, 1065353216);
            int i8 = 0;
            int i13 = this.d;
            int i14 = this.e;
            localObject1 = Bitmap.createBitmap((Bitmap)localObject1, i8, 0, i13, i14, localMatrix3, true);
            Object localObject2;
            try
            {
              localObject2 = this.a;
              int i15 = this.c;
              String str2 = this.b;
              label644: ((p)localObject2).a(i15, str2, (Bitmap)localObject1);
            }
            catch (OutOfMemoryError localOutOfMemoryError2)
            {
              localObject2 = localObject1;
              localObject1 = localOutOfMemoryError2;
              ((OutOfMemoryError)localObject1).printStackTrace();
              localObject1 = localObject2;
            }
          }
          break label205:
          i4 = this.d;
          float f12 = i1;
          float f26 = l * k;
          f12 /= f26;
          float f27 = this.d * k;
          i9 = (int)(f12 * f27);
          i11 = i9;
        }
      }
      int i4 = this.d;
      int i9 = this.e;
      int i16 = i9;
      i9 = i4;
      i4 = i16;
    }
    catch (OutOfMemoryError localBitmap2)
    {
      Bitmap localBitmap3 = paramBitmap;
      break label644:
      Bitmap localBitmap2 = paramBitmap;
      break label205:
    }
  }

  protected void a(Integer[] paramArrayOfInteger)
  {
  }

  public boolean a()
  {
    Object localObject1 = null;
    Object localObject2 = "PhotoAsyncTask";
    StringBuilder localStringBuilder = new StringBuilder("getPhotoFromNet mPhotoUrl=");
    String str1 = this.b;
    String str2 = str1;
    com.jiayuan.util.a.a((String)localObject2, str2);
    try
    {
      String str3 = this.b;
      localObject2 = (HttpURLConnection)new URL(str3).openConnection();
      ((HttpURLConnection)localObject2).setRequestMethod("GET");
      ((HttpURLConnection)localObject2).setConnectTimeout(6000);
      int l = ((HttpURLConnection)localObject2).getResponseCode();
      if (200 == l)
      {
        localObject2 = ((HttpURLConnection)localObject2).getInputStream();
        Bitmap localBitmap = BitmapFactory.decodeStream((InputStream)localObject2);
        this.i = localBitmap;
        ((InputStream)localObject2).close();
        localObject2 = this.i;
        if (localObject2 != null)
          break label134;
        localObject2 = localObject1;
        label119: return localObject2;
      }
      label134: localObject2 = localObject1;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      localObject2 = localObject1;
      break label119:
      int k = 1;
    }
  }

  public void b()
  {
    StringBuilder localStringBuilder = new StringBuilder("writePhotoToCache mPhotoUrl=");
    String str1 = this.b;
    String str2 = str1;
    com.jiayuan.util.a.a("PhotoAsyncTask", str2);
    if (this.i == null)
      return;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    Bitmap localBitmap = this.i;
    Bitmap.CompressFormat localCompressFormat = Bitmap.CompressFormat.PNG;
    localBitmap.compress(localCompressFormat, 100, localByteArrayOutputStream);
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    Context localContext = this.j;
    String str3 = this.h;
    q.a(localContext, str3, arrayOfByte);
  }

  public boolean c()
  {
    Object localObject1 = 0;
    StringBuilder localStringBuilder = new StringBuilder("getPhotoFromCache mPhotoUrl=");
    String str1 = this.b;
    String str2 = str1;
    com.jiayuan.util.a.a("PhotoAsyncTask", str2);
    Object localObject2 = this.j;
    String str3 = this.h;
    localObject2 = q.a((Context)localObject2, str3);
    if (localObject2.length == 0);
    int k;
    for (localObject2 = localObject1; ; k = 1)
    {
      return localObject2;
      int l = localObject2.length;
      localObject2 = BitmapFactory.decodeByteArray(localObject2, localObject1, l);
      this.i = ((Bitmap)localObject2);
    }
  }

  public boolean d()
  {
    Context localContext = this.j;
    String str = this.h;
    return q.b(localContext, str);
  }

  public boolean e()
  {
    Object localObject1 = null;
    int k = this.f;
    if (k == 0)
    {
      a();
      k = 1;
    }
    while (true)
    {
      return k;
      boolean bool = d();
      if (bool)
      {
        bool = c();
        if (!bool);
        localObject2 = localObject1;
      }
      Object localObject2 = a();
      if (localObject2 != 0)
        b();
      localObject2 = localObject1;
    }
  }

  protected void onCancelled()
  {
    super.onCancelled();
  }

  protected void onPreExecute()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.m
 * JD-Core Version:    0.5.4
 */