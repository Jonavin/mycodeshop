package com.jiayuan.a;

public abstract interface j
{
  public abstract void a(int paramInt, String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.j
 * JD-Core Version:    0.5.4
 */