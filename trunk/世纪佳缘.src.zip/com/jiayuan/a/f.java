package com.jiayuan.a;

import android.graphics.Bitmap;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class f
  implements p, q
{
  public n a;
  private String b;
  private String c;
  private int d;
  private int e;
  private int f;

  public f(n paramn, String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3)
  {
    this.a = paramn;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
  }

  public void a()
  {
    a.a("HeaderDataProcessing", "execute()");
    boolean bool = this.c.equalsIgnoreCase("");
    StringBuffer localStringBuffer1;
    if (bool)
    {
      a.a("HeaderDataProcessing", "HeaderDataProcessing execute mHeaderUrl.equalsIgnoreCase(\"\")");
      localStringBuffer1 = new StringBuffer("http://api.jiayuan.com/");
      if ((o.e().equalsIgnoreCase("")) || (o.f().equalsIgnoreCase("")))
      {
        localStringBuffer1.append("photo/http_get.php?");
        localStringBuffer1.append("looked_uid=");
        String str1 = this.b;
        localStringBuffer1.append(str1);
        localStringBuffer1.append("&type=");
        localStringBuffer1.append("avatar");
        localStringBuffer1.append("&access=");
        localStringBuffer1.append("0");
        label113: l locall = new l();
        locall.a = this;
        String str2 = localStringBuffer1.toString();
        locall.b(localStringBuffer1);
      }
    }
    while (true)
    {
      return;
      localStringBuffer1.append("photo/http_get.php?");
      localStringBuffer1.append("looked_uid=");
      String str3 = this.b;
      localStringBuffer1.append(str3);
      localStringBuffer1.append("&type=");
      localStringBuffer1.append("avatar");
      localStringBuffer1.append("&access=");
      localStringBuffer1.append("1");
      localStringBuffer1.append("&uid=");
      String str4 = o.e();
      localStringBuffer1.append(str4);
      localStringBuffer1.append("&token=");
      String str5 = o.f();
      localStringBuffer1.append(str5);
      break label113:
      StringBuilder localStringBuilder = new StringBuilder("HeaderDataProcessing execute mHeaderUrl=");
      String str6 = this.c;
      String str7 = str6;
      a.a("HeaderDataProcessing", str7);
      StringBuffer localStringBuffer2 = new StringBuffer();
      localStringBuffer2.append("{\"retcode\":1,\"msg\":\"");
      String str8 = this.c;
      localStringBuffer2.append(str8);
      localStringBuffer2.append("\"}");
      String str9 = localStringBuffer2.toString();
      a(1, str9);
    }
  }

  public void a(int paramInt, String paramString)
  {
    a.a("HeaderDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        if (new JSONObject(paramString).get("retcode").toString().contentEquals("1"));
        String str1 = new JSONObject(paramString).getString("msg");
        this.c = str1;
        this.c.replace("\\/", "/");
        m localm = new m();
        Object[] arrayOfObject = new Object[7];
        String str2 = this.c;
        arrayOfObject[0] = str2;
        arrayOfObject[1] = this;
        Integer localInteger = Integer.valueOf(this.d);
        arrayOfObject[2] = localInteger;
        StringBuilder localStringBuilder1 = new StringBuilder();
        int i = this.e;
        String str3 = i;
        arrayOfObject[3] = str3;
        StringBuilder localStringBuilder2 = new StringBuilder();
        int j = this.f;
        int k;
        k += 12;
        String str4 = j;
        arrayOfObject[4] = str4;
        arrayOfObject[5] = "0";
        arrayOfObject[6] = "0";
        localm.execute(arrayOfObject);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder3 = new StringBuilder("JSONException");
        String str5 = localJSONException.toString();
        String str6 = str5;
        a.a("HeaderDataProcessing", str6);
        this.a.d();
      }
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("HeaderDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("HeaderDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("HeaderDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.f
 * JD-Core Version:    0.5.4
 */