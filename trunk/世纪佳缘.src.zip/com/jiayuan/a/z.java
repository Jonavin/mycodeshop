package com.jiayuan.a;

import android.content.Context;
import android.graphics.Bitmap;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class z
  implements p, q
{
  public i a;
  private ArrayList b;
  private String c;
  private int d;
  private int e;
  private int f;
  private String g;
  private int h;
  private Context i;

  public z(Context paramContext, i parami, String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3, int paramInt4)
  {
    this.i = paramContext;
    this.a = parami;
    this.c = paramString1;
    this.d = paramInt3;
    this.e = paramInt4;
    this.f = paramInt1;
    this.g = paramString2;
    this.h = paramInt2;
  }

  public void a()
  {
    a.a("PhotoListDataProcessing", "execute()");
    StringBuffer localStringBuffer1 = new StringBuffer("http://api.jiayuan.com/");
    if ((o.e().equalsIgnoreCase("")) || (o.f().equalsIgnoreCase("")))
    {
      localStringBuffer1.append("photo/http_get.php");
      localStringBuffer1.append("?looked_uid=");
      String str1 = this.c;
      localStringBuffer1.append(str1);
      localStringBuffer1.append("&type=");
      localStringBuffer1.append("photo");
      localStringBuffer1.append("&access=");
      localStringBuffer1.append("0");
      StringBuffer localStringBuffer2 = localStringBuffer1.append("&clientid=");
      String str2 = o.b();
      localStringBuffer2.append(str2);
      StringBuffer localStringBuffer3 = localStringBuffer1.append("&screenwidth=");
      int j = o.d(this.i);
      localStringBuffer3.append(j);
    }
    while (true)
    {
      l locall = new l();
      locall.a = this;
      String str3 = localStringBuffer1.toString();
      locall.b(localStringBuffer1);
      return;
      localStringBuffer1.append("photo/http_get.php");
      localStringBuffer1.append("?looked_uid=");
      String str4 = this.c;
      localStringBuffer1.append(str4);
      localStringBuffer1.append("&type=");
      localStringBuffer1.append("photo");
      localStringBuffer1.append("&access=");
      localStringBuffer1.append("1");
      localStringBuffer1.append("&uid=");
      String str5 = o.e();
      localStringBuffer1.append(str5);
      localStringBuffer1.append("&token=");
      String str6 = o.f();
      localStringBuffer1.append(str6);
      localStringBuffer1.append("&ifself=");
      int k = this.f;
      localStringBuffer1.append(k);
      StringBuffer localStringBuffer4 = localStringBuffer1.append("&clientid=");
      String str7 = o.b();
      localStringBuffer4.append(str7);
      StringBuffer localStringBuffer5 = localStringBuffer1.append("&screenwidth=");
      int l = o.d(this.i);
      localStringBuffer5.append(l);
    }
  }

  public void a(int paramInt, String paramString)
  {
    int j = 1;
    Object localObject1 = 0;
    Object localObject2 = "onPostExecute()";
    a.a("PhotoListDataProcessing", (String)localObject2);
    boolean bool = paramString.equals("NETWORK_ERROR");
    if (bool)
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        Object localObject3 = new ArrayList();
        this.b = ((ArrayList)localObject3);
        localObject3 = new JSONObject(paramString).getString("msg");
        localObject2 = new JSONArray((String)localObject3);
        for (localObject3 = localObject1; ; ++localObject3)
        {
          int k = ((JSONArray)localObject2).length();
          if (localObject3 >= k)
          {
            StringBuilder localStringBuilder1 = new StringBuilder("mData.size()=");
            int l = this.b.size();
            String str1 = l;
            a.a("PhotoListDataProcessing", str1);
            localObject3 = this.a;
            ArrayList localArrayList1 = this.b;
            ((i)localObject3).a(localArrayList1);
            localObject3 = this.b.size();
            if (localObject3 > 0);
            localObject3 = this.g.equalsIgnoreCase("100");
            if (localObject3 == 0)
              break;
            for (localObject3 = localObject1; ; ++localObject3)
            {
              int i1 = this.b.size();
              if (localObject3 < i1);
              m localm1 = new m();
              Object[] arrayOfObject1 = new Object[7];
              Object localObject4 = this.b.get(localObject3);
              arrayOfObject1[0] = localObject4;
              arrayOfObject1[1] = this;
              Integer localInteger1 = Integer.valueOf(localObject3);
              arrayOfObject1[2] = localInteger1;
              StringBuilder localStringBuilder2 = new StringBuilder();
              int i2 = this.d;
              String str2 = i2;
              arrayOfObject1[3] = str2;
              StringBuilder localStringBuilder3 = new StringBuilder();
              int i3 = this.e;
              String str3 = i3;
              arrayOfObject1[4] = str3;
              arrayOfObject1[5] = "1";
              arrayOfObject1[6] = "0";
              localm1.execute(arrayOfObject1);
            }
          }
          if (((JSONArray)localObject2).get(localObject3).toString().equalsIgnoreCase(""))
            continue;
          String str4 = ((JSONArray)localObject2).get(localObject3).toString();
          a.a("PhotoListDataProcessing", str4);
          ArrayList localArrayList2 = this.b;
          String str5 = ((JSONArray)localObject2).get(localObject3).toString();
          localArrayList2.add(str5);
        }
        if (!this.g.equalsIgnoreCase("0"))
          break label648;
        m localm2 = new m();
        Object[] arrayOfObject2 = new Object[7];
        Object localObject5 = this.b.get(0);
        arrayOfObject2[0] = localObject5;
        arrayOfObject2[1] = this;
        Integer localInteger2 = Integer.valueOf(this.h);
        arrayOfObject2[2] = localInteger2;
        StringBuilder localStringBuilder4 = new StringBuilder();
        int i4 = this.d;
        String str6 = i4;
        arrayOfObject2[3] = str6;
        StringBuilder localStringBuilder5 = new StringBuilder();
        int i5 = this.e;
        String str7 = i5;
        arrayOfObject2[4] = str7;
        arrayOfObject2[5] = "0";
        arrayOfObject2[6] = "0";
        localm2.execute(arrayOfObject2);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder6 = new StringBuilder("JSONException");
        String str8 = localJSONException.toString();
        String str9 = str8;
        a.a("PhotoListDataProcessing", str9);
        this.a.d();
        i locali = this.a;
        ArrayList localArrayList3 = this.b;
        locali.a(localArrayList3);
      }
      continue;
      if (this.g.equalsIgnoreCase("-1"))
      {
        label648: m localm3 = new m();
        Object[] arrayOfObject3 = new Object[7];
        ArrayList localArrayList4 = this.b;
        int i6 = this.b.size() - j;
        Object localObject6 = localArrayList4.get(i6);
        arrayOfObject3[0] = localObject6;
        arrayOfObject3[1] = this;
        Integer localInteger3 = Integer.valueOf(this.h);
        arrayOfObject3[2] = localInteger3;
        StringBuilder localStringBuilder7 = new StringBuilder();
        int i7 = this.d;
        String str10 = i7;
        arrayOfObject3[3] = str10;
        StringBuilder localStringBuilder8 = new StringBuilder();
        int i8 = this.e;
        String str11 = i8;
        arrayOfObject3[4] = str11;
        arrayOfObject3[5] = "0";
        arrayOfObject3[6] = "0";
        localm3.execute(arrayOfObject3);
      }
      this.g.equalsIgnoreCase("-2");
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a_(paramInt, paramString, paramBitmap);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("PhotoListDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("PhotoListDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("PhotoListDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.a.z
 * JD-Core Version:    0.5.4
 */