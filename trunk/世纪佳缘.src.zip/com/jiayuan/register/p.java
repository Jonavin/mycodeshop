package com.jiayuan.register;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.jiayuan.LicenseActivity;

class p
  implements View.OnClickListener
{
  p(RegisterActivity paramRegisterActivity)
  {
  }

  public void onClick(View paramView)
  {
    RegisterActivity localRegisterActivity = this.a;
    Intent localIntent = new Intent(localRegisterActivity, LicenseActivity.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.p
 * JD-Core Version:    0.5.4
 */