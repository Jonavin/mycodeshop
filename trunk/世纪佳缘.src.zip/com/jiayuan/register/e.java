package com.jiayuan.register;

import android.widget.ImageView;
import android.widget.TextView;

final class e
{
  TextView a;
  TextView b;
  ImageView c;
  int d;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.e
 * JD-Core Version:    0.5.4
 */