package com.jiayuan.register;

import android.app.DatePickerDialog.OnDateSetListener;
import android.widget.DatePicker;
import android.widget.Toast;
import com.jiayuan.util.a;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

class n
  implements DatePickerDialog.OnDateSetListener
{
  n(RegisterActivity paramRegisterActivity)
  {
  }

  public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 1;
    Object localObject = Calendar.getInstance(Locale.CHINA);
    Date localDate = new Date();
    ((Calendar)localObject).setTime(localDate);
    localObject = ((Calendar)localObject).get(i);
    int j = localObject - 18;
    if (paramInt1 <= j)
    {
      int k = localObject - 99;
      if (paramInt1 >= localObject)
      {
        RegisterActivity.a(this.a, paramInt1);
        RegisterActivity.b(this.a, paramInt2);
        RegisterActivity.c(this.a, paramInt3);
        RegisterActivity.a(this.a);
        StringBuilder localStringBuilder1 = new StringBuilder("year ");
        int l = RegisterActivity.b(this.a);
        StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" ");
        int i1 = RegisterActivity.c(this.a);
        StringBuilder localStringBuilder3 = localStringBuilder2.append(i1).append(" ");
        int i2 = RegisterActivity.d(this.a);
        String str = i2;
        a.a("RegisterActivity", str);
        RegisterActivity.e(this.a).notifyDataSetChanged();
      }
    }
    while (true)
    {
      return;
      Toast.makeText(RegisterActivity.f(this.a), 2131165662, i).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.n
 * JD-Core Version:    0.5.4
 */