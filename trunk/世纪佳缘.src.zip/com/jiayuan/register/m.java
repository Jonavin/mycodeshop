package com.jiayuan.register;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import java.util.ArrayList;

class m
  implements DialogInterface.OnClickListener
{
  m(RegisterActivity paramRegisterActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ArrayList localArrayList = RegisterActivity.g(this.a);
    d locald = RegisterActivity.k(this.a);
    localArrayList.set(2, locald);
    RegisterActivity.e(this.a).notifyDataSetChanged();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.m
 * JD-Core Version:    0.5.4
 */