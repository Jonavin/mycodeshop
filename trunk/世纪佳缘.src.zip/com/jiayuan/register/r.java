package com.jiayuan.register;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class r
  implements DialogInterface.OnClickListener
{
  r(RegisterActivity paramRegisterActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.r
 * JD-Core Version:    0.5.4
 */