package com.jiayuan.register;

import com.jiayuan.util.a;
import com.jiayuan.util.picker.NumberPicker;
import com.jiayuan.util.picker.r;

class q
  implements r
{
  q(RegisterActivity paramRegisterActivity)
  {
  }

  public void a(NumberPicker paramNumberPicker, int paramInt1, int paramInt2)
  {
    String str = "oldVal=" + paramInt1 + ", newVal=" + paramInt2;
    a.a("RegisterActivity", str);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.q
 * JD-Core Version:    0.5.4
 */