package com.jiayuan.register;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

class b
  implements View.OnClickListener
{
  b(RegisterType paramRegisterType)
  {
  }

  public void onClick(View paramView)
  {
    boolean bool = null;
    switch (paramView.getId())
    {
    default:
    case 2131362141:
    case 2131362140:
    }
    while (true)
    {
      return;
      RegisterType localRegisterType1 = this.a;
      Intent localIntent1 = new Intent(localRegisterType1, RegisterActivity.class);
      localIntent1.putExtra("isEmail", true);
      this.a.startActivity(localIntent1);
      continue;
      RegisterType localRegisterType2 = this.a;
      String str1 = this.a.b;
      if (RegisterType.a(localRegisterType2, str1))
      {
        RegisterType localRegisterType3 = this.a;
        Intent localIntent2 = new Intent(localRegisterType3, RegisterActivity.class);
        localIntent2.putExtra("isEmail", bool);
        String str2 = this.a.b;
        localIntent2.putExtra("telNum", str2);
        localIntent2.putExtra("needValid", bool);
        localIntent2.putExtra("validationCode", "");
        this.a.startActivity(localIntent2);
      }
      RegisterType localRegisterType4 = this.a;
      Intent localIntent3 = new Intent(localRegisterType4, ValidMobile.class);
      this.a.startActivity(localIntent3);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.b
 * JD-Core Version:    0.5.4
 */