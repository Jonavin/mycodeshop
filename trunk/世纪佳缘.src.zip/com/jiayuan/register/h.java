package com.jiayuan.register;

public abstract interface h
{
  public abstract void d(String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.h
 * JD-Core Version:    0.5.4
 */