package com.jiayuan.register;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class f
  implements View.OnClickListener
{
  f(ValidMobile paramValidMobile)
  {
  }

  public void onClick(View paramView)
  {
    int i = 1;
    boolean bool1 = null;
    String str1 = this.a.a.getText().toString();
    boolean bool2 = Pattern.compile("^1[3|4|5|8][0-9]\\d{8}$").matcher(str1).matches();
    if (!bool2)
      Toast.makeText(this.a.e, 2131165319, i).show();
    while (true)
    {
      return;
      int j = paramView.getId();
      switch (j)
      {
      case 2131361950:
      default:
        break;
      case 2131361949:
        ValidMobile localValidMobile1 = this.a;
        ProgressDialog localProgressDialog = ProgressDialog.show(this.a.e, "", "璇风�");
        localValidMobile1.f = localProgressDialog;
        ValidMobile localValidMobile2 = this.a;
        Context localContext1 = this.a.e;
        new c(localValidMobile2, localContext1, str1).a();
        break;
      case 2131361951:
      }
      String str2 = this.a.b.getText().toString();
      if (!Pattern.compile("^\\d{5}$").matcher(str2).matches())
        Toast.makeText(this.a.e, 2131165320, i).show();
      Context localContext2 = this.a.e;
      Intent localIntent = new Intent(localContext2, RegisterActivity.class);
      localIntent.putExtra("isEmail", bool1);
      localIntent.putExtra("telNum", str1);
      localIntent.putExtra("needValid", bool1);
      localIntent.putExtra("validationCode", str2);
      this.a.startActivity(localIntent);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.f
 * JD-Core Version:    0.5.4
 */