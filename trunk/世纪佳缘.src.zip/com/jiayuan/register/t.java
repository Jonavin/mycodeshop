package com.jiayuan.register;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;
import java.util.ArrayList;

class t
  implements AdapterView.OnItemSelectedListener
{
  t(RegisterActivity paramRegisterActivity, int paramInt)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder("selected=");
    String str1 = paramAdapterView.getItemAtPosition(paramInt).toString();
    String str2 = str1;
    a.a("RegisterActivity", str2);
    ArrayList localArrayList1 = RegisterActivity.g(this.a);
    int i = this.b;
    d locald = (d)localArrayList1.get(i);
    String str3 = paramAdapterView.getItemAtPosition(paramInt).toString();
    locald.b = str3;
    ArrayList localArrayList2 = RegisterActivity.g(this.a);
    int j = this.b;
    ((d)localArrayList2.get(j)).d = paramInt;
    paramAdapterView.setVisibility(0);
    RegisterActivity.e(this.a).notifyDataSetChanged();
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.t
 * JD-Core Version:    0.5.4
 */