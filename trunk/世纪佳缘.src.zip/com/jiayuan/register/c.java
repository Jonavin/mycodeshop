package com.jiayuan.register;

import android.content.Context;
import com.jiayuan.a.l;
import com.jiayuan.a.q;

public class c
  implements q
{
  Context a;
  h b;
  String c;

  public c(h paramh, Context paramContext, String paramString)
  {
    this.b = paramh;
    this.c = paramString;
    this.a = paramContext;
  }

  public void a()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("http://api.jiayuan.com/");
    localStringBuffer.append("reg/send_phone_code.php?");
    localStringBuffer.append("phoneid=");
    String str1 = this.c;
    localStringBuffer.append(str1);
    l locall = new l();
    locall.a = this;
    String str2 = localStringBuffer.toString();
    locall.b(str2);
  }

  public void a(int paramInt, String paramString)
  {
    this.b.d(paramString);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.c
 * JD-Core Version:    0.5.4
 */