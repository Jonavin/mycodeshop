package com.jiayuan.register;

import android.view.View;
import android.view.View.OnClickListener;

class l
  implements View.OnClickListener
{
  l(RegisterActivity paramRegisterActivity)
  {
  }

  public void onClick(View paramView)
  {
    RegisterActivity.j(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.l
 * JD-Core Version:    0.5.4
 */