package com.jiayuan.register;

import android.view.View;
import android.view.View.OnClickListener;

class j
  implements View.OnClickListener
{
  j(RegisterActivity paramRegisterActivity)
  {
  }

  public void onClick(View paramView)
  {
    RegisterActivity.a(this.a, paramView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.j
 * JD-Core Version:    0.5.4
 */