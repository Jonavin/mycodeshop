package com.jiayuan.register;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import org.json.JSONException;
import org.json.JSONObject;

public class ValidMobile extends MyActivity
  implements h
{
  EditText a;
  EditText b;
  Button c;
  Button d;
  Context e;
  ProgressDialog f;
  View.OnClickListener g;

  public ValidMobile()
  {
    f localf = new f(this);
    this.g = localf;
  }

  public void d(String paramString)
  {
    int i = 1;
    this.f.dismiss();
    if (paramString.equals("NETWORK_ERROR"))
      Toast.makeText(this.e, 2131165663, i).show();
    while (true)
    {
      return;
      try
      {
        switch (new JSONObject(paramString).getInt("retcode"))
        {
        default:
          break;
        case -2:
          Toast.makeText(this.e, 2131165319, 1).show();
        case 1:
        case 300:
        case 400:
        case 500:
        case -1:
        }
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
      continue;
      Toast.makeText(this.e, 2131165314, 1).show();
      continue;
      Toast.makeText(this.e, 2131165315, 1).show();
      continue;
      Toast.makeText(this.e, 2131165316, 1).show();
      continue;
      Toast.makeText(this.e, 2131165317, 1).show();
      continue;
      Toast.makeText(this.e, 2131165318, 1).show();
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903068);
    this.e = this;
    EditText localEditText1 = (EditText)findViewById(2131361948);
    this.a = localEditText1;
    EditText localEditText2 = (EditText)findViewById(2131361950);
    this.b = localEditText2;
    Button localButton1 = (Button)findViewById(2131361951);
    this.c = localButton1;
    Button localButton2 = (Button)findViewById(2131361949);
    this.d = localButton2;
    Button localButton3 = this.c;
    View.OnClickListener localOnClickListener1 = this.g;
    localButton3.setOnClickListener(localOnClickListener1);
    Button localButton4 = this.d;
    View.OnClickListener localOnClickListener2 = this.g;
    localButton4.setOnClickListener(localOnClickListener2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.ValidMobile
 * JD-Core Version:    0.5.4
 */