package com.jiayuan.register;

import com.jiayuan.util.a;
import com.jiayuan.util.picker.b;

class s
  implements b
{
  s(RegisterActivity paramRegisterActivity, String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    String str1 = "primaryId=" + paramInt1 + ", secondaryId=" + paramInt2;
    a.a("RegisterActivity", str1);
    d locald1 = RegisterActivity.k(this.a);
    String str2 = this.b[paramInt1];
    locald1.b = str2;
    RegisterActivity.k(this.a).d = paramInt1;
    d locald2 = RegisterActivity.k(this.a);
    String str3 = this.c[paramInt1][paramInt2];
    locald2.c = str3;
    RegisterActivity.k(this.a).e = paramInt2;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.s
 * JD-Core Version:    0.5.4
 */