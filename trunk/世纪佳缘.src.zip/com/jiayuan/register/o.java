package com.jiayuan.register;

import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class o
  implements CompoundButton.OnCheckedChangeListener
{
  o(RegisterActivity paramRegisterActivity)
  {
  }

  public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    if (paramBoolean)
      RegisterActivity.h(this.a).setEnabled(true);
    while (true)
    {
      return;
      RegisterActivity.h(this.a).setEnabled(null);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.o
 * JD-Core Version:    0.5.4
 */