package com.jiayuan.register;

import android.content.Context;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.f;
import com.jiayuan.util.o;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class a
  implements q
{
  public g a;
  public Context b;
  private StringBuffer c;

  public a(g paramg, String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3, String paramString4, String paramString5, int paramInt3, int paramInt4, int paramInt5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, String paramString12)
  {
    this.a = paramg;
    Context localContext1 = (Context)this.a;
    this.b = paramg;
    String str1 = String.valueOf(paramInt3);
    int i = 10;
    int j = paramInt4;
    int k = i;
    String str2;
    label74: String str3;
    if (j >= k)
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      int l = paramInt4;
      str2 = l;
      int i1 = 10;
      int i2 = paramInt5;
      int i3 = i1;
      if (i2 < i3)
        break label842;
      StringBuilder localStringBuilder2 = new StringBuilder();
      int i4 = paramInt5;
      str3 = i4;
    }
    while (true)
      try
      {
        StringBuffer localStringBuffer1 = new StringBuffer();
        this.c = localStringBuffer1;
        this.c.append("from=");
        StringBuffer localStringBuffer2 = this.c;
        String str4 = o.b();
        localStringBuffer2.append(str4);
        this.c.append("&channelid=");
        StringBuffer localStringBuffer3 = this.c;
        String str5 = o.c();
        localStringBuffer3.append(str5);
        this.c.append("&clientid=");
        StringBuffer localStringBuffer4 = this.c;
        String str6 = o.b();
        localStringBuffer4.append(str6);
        this.c.append("&mobile=");
        this.c.append(paramString1);
        this.c.append("&rtype=");
        this.c.append(paramInt2);
        this.c.append("&mflag=");
        this.c.append(paramInt1);
        this.c.append("&mobile_vali=");
        this.c.append(paramString2);
        this.c.append("&nickname=");
        StringBuffer localStringBuffer5 = this.c;
        String str7 = URLEncoder.encode(paramString4, "UTF-8");
        localStringBuffer5.append(str7);
        this.c.append("&password=");
        this.c.append(paramString3);
        this.c.append("&chkpass=");
        this.c.append(paramString3);
        this.c.append("&sex=");
        StringBuffer localStringBuffer6 = this.c;
        String str8 = f.b(this.b, paramString5);
        localStringBuffer6.append(str8);
        this.c.append("&year=");
        this.c.append(str1);
        this.c.append("&month=");
        this.c.append(str2);
        this.c.append("&day=");
        this.c.append(str3);
        this.c.append("&birthday=");
        StringBuffer localStringBuffer7 = this.c;
        String str9 = String.valueOf(str2);
        String str10 = str2 + str3;
        str1.append(str2);
        this.c.append("&height=");
        StringBuffer localStringBuffer8 = this.c;
        String str11 = paramString8;
        localStringBuffer8.append(str11);
        this.c.append("&marriage=");
        StringBuffer localStringBuffer9 = this.c;
        Context localContext2 = this.b;
        String str12 = paramString9;
        String str13 = f.c(localContext2, str12);
        str1.append(str2);
        this.c.append("&degree=");
        StringBuffer localStringBuffer10 = this.c;
        Context localContext3 = this.b;
        String str14 = paramString10;
        String str15 = f.e(localContext3, str14);
        str1.append(str2);
        this.c.append("&income=");
        StringBuffer localStringBuffer11 = this.c;
        Context localContext4 = this.b;
        String str16 = paramString11;
        String str17 = f.g(localContext4, str16);
        str1.append(str2);
        this.c.append("&province=");
        StringBuffer localStringBuffer12 = this.c;
        String str18 = paramString6;
        localStringBuffer12.append(str18);
        this.c.append("&city=");
        StringBuffer localStringBuffer13 = this.c;
        String str19 = paramString7;
        localStringBuffer13.append(str19);
        this.c.append("&country=");
        this.c.append("&region=12");
        this.c.append("&validate_code=macjr&mobile_msg_code=");
        this.c.append("&readme=");
        this.c.append("on");
        this.c.append("&note=");
        StringBuffer localStringBuffer14 = this.c;
        String str20 = paramString12;
        localStringBuffer14.append(str20);
        label807: return;
        str3 = "0";
        StringBuilder localStringBuilder3 = new StringBuilder(str3);
        int i5 = paramInt4;
        str2 = i5;
        break label74:
        label842: StringBuilder localStringBuilder4 = new StringBuilder("0");
        int i6 = paramInt5;
        str3 = i6;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localUnsupportedEncodingException.printStackTrace();
        break label807:
      }
  }

  public a(g paramg, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2, int paramInt3, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11)
  {
    this.a = paramg;
    Context localContext1 = (Context)this.a;
    this.b = paramg;
    Object localObject = new StringBuilder();
    int i = paramInt2 + 10;
    localObject = i;
    i = 10;
    String str1;
    if (paramInt3 >= i)
      str1 = paramInt3;
    while (true)
    {
      String str2 = String.valueOf(paramInt1);
      try
      {
        StringBuffer localStringBuffer1 = new StringBuffer();
        this.c = localStringBuffer1;
        this.c.append("from=");
        StringBuffer localStringBuffer2 = this.c;
        String str3 = o.b();
        localStringBuffer2.append(str3);
        this.c.append("&channelid=");
        StringBuffer localStringBuffer3 = this.c;
        String str4 = o.c();
        localStringBuffer3.append(str4);
        this.c.append("&clientid=");
        StringBuffer localStringBuffer4 = this.c;
        String str5 = o.b();
        localStringBuffer4.append(str5);
        this.c.append("&email=");
        this.c.append(paramString1);
        this.c.append("&nickname=");
        StringBuffer localStringBuffer5 = this.c;
        String str6 = URLEncoder.encode(paramString3, "UTF-8");
        localStringBuffer5.append(str6);
        this.c.append("&password=");
        this.c.append(paramString2);
        this.c.append("&chkpass=");
        this.c.append(paramString2);
        this.c.append("&sex=");
        StringBuffer localStringBuffer6 = this.c;
        String str7 = f.b(this.b, paramString4);
        localStringBuffer6.append(str7);
        this.c.append("&year=");
        this.c.append(str2);
        this.c.append("&month=");
        this.c.append((String)localObject);
        this.c.append("&day=");
        StringBuffer localStringBuffer7 = this.c;
        String str8 = String.valueOf(localObject);
        String str9 = (String)localObject + str1;
        str2.append((String)localObject);
        this.c.append("&height=");
        StringBuffer localStringBuffer8 = this.c;
        String str10 = paramString7;
        localStringBuffer8.append(str10);
        this.c.append("&marriage=");
        StringBuffer localStringBuffer9 = this.c;
        Context localContext2 = this.b;
        String str11 = paramString8;
        String str12 = f.c(localContext2, str11);
        ((StringBuffer)localObject).append(str1);
        this.c.append("&degree=");
        StringBuffer localStringBuffer10 = this.c;
        Context localContext3 = this.b;
        String str13 = paramString9;
        String str14 = f.e(localContext3, str13);
        ((StringBuffer)localObject).append(str1);
        this.c.append("&income=");
        StringBuffer localStringBuffer11 = this.c;
        Context localContext4 = this.b;
        String str15 = paramString10;
        String str16 = f.g(localContext4, str15);
        ((StringBuffer)localObject).append(str1);
        this.c.append("&province=");
        StringBuffer localStringBuffer12 = this.c;
        String str17 = paramString5;
        localStringBuffer12.append(str17);
        this.c.append("&city=");
        StringBuffer localStringBuffer13 = this.c;
        String str18 = paramString6;
        localStringBuffer13.append(str18);
        this.c.append("&country=");
        this.c.append("&region=12");
        this.c.append("&validate_code=macjr&mobile_msg_code=&mobile=");
        this.c.append("&readme=");
        this.c.append("on");
        this.c.append("&note=");
        StringBuffer localStringBuffer14 = this.c;
        String str19 = paramString11;
        localStringBuffer14.append(str19);
        label694: return;
        str2 = "0";
        str1 = str2 + paramInt3;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localUnsupportedEncodingException.printStackTrace();
        break label694:
      }
    }
  }

  public void a()
  {
    com.jiayuan.util.a.a("RegisterDataProcessing", "execute()");
    this.a.e();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("reg/register_basic.php?");
    String str1 = this.c.toString();
    localStringBuffer.append(str1);
    l locall = new l();
    locall.a = this;
    String str2 = localStringBuffer.toString();
    locall.b(str2);
  }

  public void a(int paramInt, String paramString)
  {
    com.jiayuan.util.a.a("RegisterDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        com.jiayuan.util.a.a("RegisterDataProcessing", str2);
        this.a.f();
        this.a.b(paramString);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str3 = localJSONException.toString();
        String str4 = str3;
        com.jiayuan.util.a.a("RegisterDataProcessing", str4);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    com.jiayuan.util.a.a("RegisterDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    com.jiayuan.util.a.a("RegisterDataProcessing", "onCancelled()");
  }

  public void c()
  {
    com.jiayuan.util.a.a("RegisterDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.a
 * JD-Core Version:    0.5.4
 */