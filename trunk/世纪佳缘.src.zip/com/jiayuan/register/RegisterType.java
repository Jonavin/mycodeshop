package com.jiayuan.register;

import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.jiayuan.MyActivity;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterType extends MyActivity
{
  TelephonyManager a;
  String b;
  Button c;
  Button d;
  View.OnClickListener e;

  public RegisterType()
  {
    b localb = new b(this);
    this.e = localb;
  }

  private boolean a(String paramString)
  {
    Object localObject1 = null;
    if (paramString != null)
    {
      boolean bool = paramString.equals("");
      if (!bool)
        break label21;
    }
    label21: Object localObject3;
    for (Object localObject2 = localObject1; ; localObject3 = localObject1)
      while (true)
      {
        return localObject2;
        localObject2 = Pattern.compile("^1[3|4|5|8][0-9]\\d{8}$").matcher(paramString).matches();
        if (localObject2 == 0)
          break;
        int i = 1;
      }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903096);
    TelephonyManager localTelephonyManager = (TelephonyManager)getSystemService("phone");
    this.a = localTelephonyManager;
    String str = this.a.getLine1Number();
    this.b = str;
    Button localButton1 = (Button)findViewById(2131362140);
    this.c = localButton1;
    Button localButton2 = (Button)findViewById(2131362141);
    this.d = localButton2;
    Button localButton3 = this.c;
    View.OnClickListener localOnClickListener1 = this.e;
    localButton3.setOnClickListener(localOnClickListener1);
    Button localButton4 = this.d;
    View.OnClickListener localOnClickListener2 = this.e;
    localButton4.setOnClickListener(localOnClickListener2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.RegisterType
 * JD-Core Version:    0.5.4
 */