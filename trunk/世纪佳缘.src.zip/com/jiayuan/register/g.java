package com.jiayuan.register;

public abstract interface g
{
  public abstract void a_(String paramString);

  public abstract void b(String paramString);

  public abstract void d();

  public abstract void e();

  public abstract void f();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.g
 * JD-Core Version:    0.5.4
 */