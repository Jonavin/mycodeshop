package com.jiayuan.register;

import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.mateselection.MateSelectionActivity;
import com.jiayuan.system.service.NotificationService;
import com.jiayuan.util.b;
import com.jiayuan.util.e;
import com.jiayuan.util.f;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.picker.HeightPicker;
import com.jiayuan.util.picker.NumberPicker;
import com.jiayuan.util.picker.aa;
import com.jiayuan.util.picker.y;
import java.util.ArrayList;
import java.util.Calendar;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends MyActivity
  implements AdapterView.OnItemClickListener, g, h, e, com.jiayuan.util.n, y
{
  private Spinner A;
  private Spinner B;
  private d C;
  private ProgressDialog D;
  private ProgressDialog E;
  private CheckBox F;
  private TextView G;
  private Button H;
  private Button I;
  private String J;
  private boolean K;
  private boolean L;
  private String M;
  private int N;
  private DatePickerDialog.OnDateSetListener O;
  com.jiayuan.util.r a = null;
  Bitmap b = null;
  int c;
  private final int d = null;
  private final int e = 1;
  private final int f = null;
  private final int g = 1;
  private final int h = 2;
  private final int i = 3;
  private final int j = 4;
  private final int k = 5;
  private final int l = 6;
  private ArrayList m;
  private EditText n;
  private EditText o;
  private EditText p;
  private EditText q;
  private ListView r;
  private i s;
  private Context t;
  private int u;
  private int v;
  private int w;
  private NumberPicker x;
  private Spinner y;
  private Spinner z;

  public RegisterActivity()
  {
    d locald = new d();
    this.C = locald;
    n localn = new n(this);
    this.O = localn;
  }

  private void a(View paramView)
  {
    com.jiayuan.util.a.a("RegisterActivity", "Header image button clicked");
    openContextMenu(paramView);
  }

  private int[] a(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int i1 = 0; ; ++i1)
    {
      if (i1 >= paramInt)
        return arrayOfInt;
      int i2 = com.jiayuan.util.t.b(i1);
      arrayOfInt[i1] = i2;
    }
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int i1 = paramArrayOfInt.length;
    if (i1 <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      i1 = 0;
      return i1;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    for (int i2 = 0; ; ++i2)
    {
      int i3 = paramArrayOfInt.length;
      if (i2 < i3);
      int i4 = paramArrayOfInt[i2];
      String[] arrayOfString2 = localResources.getStringArray(i4);
      arrayOfString1[i2] = arrayOfString2;
    }
  }

  private void h()
  {
    com.jiayuan.util.a.a("RegisterActivity", "Back button clicked");
    finish();
  }

  // ERROR //
  private void i()
  {
    // Byte code:
    //   0: ldc 115
    //   2: ldc 186
    //   4: invokestatic 122	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   7: aload_0
    //   8: astore_1
    //   9: ldc 188
    //   11: astore_2
    //   12: aload_1
    //   13: aload_2
    //   14: invokevirtual 192	com/jiayuan/register/RegisterActivity:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   17: checkcast 194	android/view/inputmethod/InputMethodManager
    //   20: astore_3
    //   21: aload_0
    //   22: invokevirtual 198	com/jiayuan/register/RegisterActivity:getCurrentFocus	()Landroid/view/View;
    //   25: astore 4
    //   27: aload 4
    //   29: ifnull +18 -> 47
    //   32: aload 4
    //   34: invokevirtual 204	android/view/View:getWindowToken	()Landroid/os/IBinder;
    //   37: astore 4
    //   39: aload_3
    //   40: aload 4
    //   42: iconst_0
    //   43: invokevirtual 208	android/view/inputmethod/InputMethodManager:hideSoftInputFromWindow	(Landroid/os/IBinder;I)Z
    //   46: pop
    //   47: aload_0
    //   48: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   51: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   54: invokeinterface 222 1 0
    //   59: astore_3
    //   60: ldc 224
    //   62: astore 4
    //   64: aload_3
    //   65: aload 4
    //   67: invokevirtual 228	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   70: astore_3
    //   71: iload_3
    //   72: ifne +31 -> 103
    //   75: aload_0
    //   76: getfield 230	com/jiayuan/register/RegisterActivity:o	Landroid/widget/EditText;
    //   79: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   82: invokeinterface 222 1 0
    //   87: astore_3
    //   88: ldc 224
    //   90: astore 4
    //   92: aload_3
    //   93: aload 4
    //   95: invokevirtual 228	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   98: astore_3
    //   99: iload_3
    //   100: ifeq +26 -> 126
    //   103: aload_0
    //   104: astore 5
    //   106: ldc 231
    //   108: istore 6
    //   110: iconst_0
    //   111: istore 7
    //   113: aload 5
    //   115: iload 6
    //   117: iload 7
    //   119: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   122: invokevirtual 240	android/widget/Toast:show	()V
    //   125: return
    //   126: aload_0
    //   127: getfield 242	com/jiayuan/register/RegisterActivity:p	Landroid/widget/EditText;
    //   130: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   133: invokeinterface 222 1 0
    //   138: astore_3
    //   139: ldc 224
    //   141: astore 4
    //   143: aload_3
    //   144: aload 4
    //   146: invokevirtual 228	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   149: astore_3
    //   150: iload_3
    //   151: ifeq +28 -> 179
    //   154: aload_0
    //   155: astore 8
    //   157: ldc 243
    //   159: istore 9
    //   161: iconst_1
    //   162: istore 10
    //   164: aload 8
    //   166: iload 9
    //   168: iload 10
    //   170: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   173: invokevirtual 240	android/widget/Toast:show	()V
    //   176: goto -51 -> 125
    //   179: aload_0
    //   180: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   183: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   186: invokeinterface 222 1 0
    //   191: invokevirtual 247	java/lang/String:length	()I
    //   194: astore_3
    //   195: sipush 128
    //   198: istore 4
    //   200: iload_3
    //   201: iload 4
    //   203: if_icmple +28 -> 231
    //   206: aload_0
    //   207: astore 11
    //   209: ldc 248
    //   211: istore 12
    //   213: iconst_0
    //   214: istore 13
    //   216: aload 11
    //   218: iload 12
    //   220: iload 13
    //   222: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   225: invokevirtual 240	android/widget/Toast:show	()V
    //   228: goto -103 -> 125
    //   231: aload_0
    //   232: getfield 230	com/jiayuan/register/RegisterActivity:o	Landroid/widget/EditText;
    //   235: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   238: invokeinterface 222 1 0
    //   243: astore_3
    //   244: ldc 250
    //   246: astore 4
    //   248: aload_3
    //   249: aload 4
    //   251: invokevirtual 254	java/lang/String:matches	(Ljava/lang/String;)Z
    //   254: astore_3
    //   255: iload_3
    //   256: ifne +28 -> 284
    //   259: aload_0
    //   260: astore 14
    //   262: ldc 255
    //   264: istore 15
    //   266: iconst_0
    //   267: istore 16
    //   269: aload 14
    //   271: iload 15
    //   273: iload 16
    //   275: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   278: invokevirtual 240	android/widget/Toast:show	()V
    //   281: goto -156 -> 125
    //   284: ldc_w 257
    //   287: iconst_2
    //   288: invokestatic 263	java/util/regex/Pattern:compile	(Ljava/lang/String;I)Ljava/util/regex/Pattern;
    //   291: astore_3
    //   292: aload_0
    //   293: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   296: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   299: invokeinterface 222 1 0
    //   304: astore 4
    //   306: aload_3
    //   307: aload 4
    //   309: invokevirtual 267	java/util/regex/Pattern:matcher	(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   312: invokevirtual 272	java/util/regex/Matcher:matches	()Z
    //   315: astore_3
    //   316: iload_3
    //   317: ifne +37 -> 354
    //   320: aload_0
    //   321: getfield 274	com/jiayuan/register/RegisterActivity:c	I
    //   324: istore_3
    //   325: iload_3
    //   326: ifne +28 -> 354
    //   329: aload_0
    //   330: astore 17
    //   332: ldc 248
    //   334: istore 18
    //   336: iconst_0
    //   337: istore 19
    //   339: aload 17
    //   341: iload 18
    //   343: iload 19
    //   345: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   348: invokevirtual 240	android/widget/Toast:show	()V
    //   351: goto -226 -> 125
    //   354: ldc_w 276
    //   357: invokestatic 279	java/util/regex/Pattern:compile	(Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   360: astore_3
    //   361: aload_0
    //   362: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   365: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   368: invokeinterface 222 1 0
    //   373: astore 4
    //   375: aload_3
    //   376: aload 4
    //   378: invokevirtual 267	java/util/regex/Pattern:matcher	(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   381: invokevirtual 272	java/util/regex/Matcher:matches	()Z
    //   384: astore_3
    //   385: iload_3
    //   386: ifne +43 -> 429
    //   389: aload_0
    //   390: getfield 274	com/jiayuan/register/RegisterActivity:c	I
    //   393: istore_3
    //   394: iconst_1
    //   395: istore 4
    //   397: iload_3
    //   398: iload 4
    //   400: if_icmpne +29 -> 429
    //   403: aload_0
    //   404: astore 20
    //   406: ldc_w 280
    //   409: istore 21
    //   411: iconst_0
    //   412: istore 22
    //   414: aload 20
    //   416: iload 21
    //   418: iload 22
    //   420: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   423: invokevirtual 240	android/widget/Toast:show	()V
    //   426: goto -301 -> 125
    //   429: aload_0
    //   430: getfield 274	com/jiayuan/register/RegisterActivity:c	I
    //   433: istore_3
    //   434: iconst_1
    //   435: istore 4
    //   437: iload_3
    //   438: iload 4
    //   440: if_icmpne +47 -> 487
    //   443: ldc_w 282
    //   446: invokestatic 279	java/util/regex/Pattern:compile	(Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   449: astore_3
    //   450: aload_0
    //   451: getfield 284	com/jiayuan/register/RegisterActivity:M	Ljava/lang/String;
    //   454: astore 4
    //   456: aload_3
    //   457: aload 4
    //   459: invokevirtual 267	java/util/regex/Pattern:matcher	(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   462: invokevirtual 272	java/util/regex/Matcher:matches	()Z
    //   465: astore_3
    //   466: iload_3
    //   467: ifne +20 -> 487
    //   470: aload_0
    //   471: getfield 167	com/jiayuan/register/RegisterActivity:t	Landroid/content/Context;
    //   474: ldc_w 285
    //   477: iconst_1
    //   478: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   481: invokevirtual 240	android/widget/Toast:show	()V
    //   484: goto -359 -> 125
    //   487: aload_0
    //   488: getfield 242	com/jiayuan/register/RegisterActivity:p	Landroid/widget/EditText;
    //   491: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   494: invokeinterface 222 1 0
    //   499: ldc_w 287
    //   502: invokevirtual 291	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   505: arraylength
    //   506: istore_3
    //   507: bipush 20
    //   509: istore 4
    //   511: iload_3
    //   512: iload 4
    //   514: if_icmple +36 -> 550
    //   517: iconst_0
    //   518: istore 4
    //   520: aload_0
    //   521: astore 23
    //   523: ldc_w 292
    //   526: istore 24
    //   528: iload 4
    //   530: istore 25
    //   532: aload 23
    //   534: iload 24
    //   536: iload 25
    //   538: invokestatic 237	android/widget/Toast:makeText	(Landroid/content/Context;II)Landroid/widget/Toast;
    //   541: astore_3
    //   542: aload_3
    //   543: invokevirtual 240	android/widget/Toast:show	()V
    //   546: goto -421 -> 125
    //   549: astore_3
    //   550: aload_0
    //   551: getfield 294	com/jiayuan/register/RegisterActivity:q	Landroid/widget/EditText;
    //   554: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   557: invokeinterface 222 1 0
    //   562: invokevirtual 297	java/lang/String:trim	()Ljava/lang/String;
    //   565: astore 4
    //   567: aload_0
    //   568: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   571: iconst_1
    //   572: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   575: checkcast 102	com/jiayuan/register/d
    //   578: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   581: ldc_w 307
    //   584: invokevirtual 228	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   587: astore_3
    //   588: iload_3
    //   589: ifeq +29 -> 618
    //   592: aload_0
    //   593: astore 26
    //   595: ldc_w 309
    //   598: astore 27
    //   600: iconst_1
    //   601: istore 28
    //   603: aload 26
    //   605: aload 27
    //   607: iload 28
    //   609: invokestatic 312	android/widget/Toast:makeText	(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    //   612: invokevirtual 240	android/widget/Toast:show	()V
    //   615: goto -490 -> 125
    //   618: aload_0
    //   619: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   622: iconst_2
    //   623: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   626: checkcast 102	com/jiayuan/register/d
    //   629: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   632: ldc_w 307
    //   635: invokevirtual 228	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   638: astore_3
    //   639: iload_3
    //   640: ifeq +29 -> 669
    //   643: aload_0
    //   644: astore 29
    //   646: ldc_w 314
    //   649: astore 30
    //   651: iconst_1
    //   652: istore 31
    //   654: aload 29
    //   656: aload 30
    //   658: iload 31
    //   660: invokestatic 312	android/widget/Toast:makeText	(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    //   663: invokevirtual 240	android/widget/Toast:show	()V
    //   666: goto -541 -> 125
    //   669: aload 4
    //   671: ldc_w 316
    //   674: invokestatic 322	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   677: astore_3
    //   678: aload_3
    //   679: astore 32
    //   681: aload_0
    //   682: invokevirtual 150	com/jiayuan/register/RegisterActivity:getResources	()Landroid/content/res/Resources;
    //   685: ldc_w 323
    //   688: invokevirtual 327	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   691: astore 33
    //   693: aload_0
    //   694: astore 34
    //   696: ldc 224
    //   698: astore 35
    //   700: aload 33
    //   702: astore 36
    //   704: aload 34
    //   706: aload 35
    //   708: aload 36
    //   710: invokestatic 332	android/app/ProgressDialog:show	(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/app/ProgressDialog;
    //   713: astore 37
    //   715: aload_0
    //   716: aload 37
    //   718: putfield 334	com/jiayuan/register/RegisterActivity:D	Landroid/app/ProgressDialog;
    //   721: aload_0
    //   722: getfield 334	com/jiayuan/register/RegisterActivity:D	Landroid/app/ProgressDialog;
    //   725: iconst_1
    //   726: invokevirtual 338	android/app/ProgressDialog:setCancelable	(Z)V
    //   729: aload_0
    //   730: invokespecial 340	com/jiayuan/register/RegisterActivity:k	()V
    //   733: aload_0
    //   734: getfield 274	com/jiayuan/register/RegisterActivity:c	I
    //   737: ifne +304 -> 1041
    //   740: aload_0
    //   741: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   744: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   747: invokeinterface 222 1 0
    //   752: astore 38
    //   754: aload_0
    //   755: getfield 230	com/jiayuan/register/RegisterActivity:o	Landroid/widget/EditText;
    //   758: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   761: invokeinterface 222 1 0
    //   766: astore 39
    //   768: aload_0
    //   769: getfield 242	com/jiayuan/register/RegisterActivity:p	Landroid/widget/EditText;
    //   772: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   775: invokeinterface 222 1 0
    //   780: astore 40
    //   782: aload_0
    //   783: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   786: aconst_null
    //   787: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   790: checkcast 102	com/jiayuan/register/d
    //   793: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   796: astore 41
    //   798: aload_0
    //   799: getfield 130	com/jiayuan/register/RegisterActivity:u	I
    //   802: istore 42
    //   804: aload_0
    //   805: getfield 159	com/jiayuan/register/RegisterActivity:v	I
    //   808: iconst_1
    //   809: iadd
    //   810: istore 43
    //   812: aload_0
    //   813: getfield 161	com/jiayuan/register/RegisterActivity:w	I
    //   816: istore 44
    //   818: aload_0
    //   819: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   822: iconst_2
    //   823: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   826: checkcast 102	com/jiayuan/register/d
    //   829: getfield 341	com/jiayuan/register/d:d	I
    //   832: istore 45
    //   834: aload_0
    //   835: astore 46
    //   837: iload 45
    //   839: istore 47
    //   841: aload 46
    //   843: iload 47
    //   845: invokestatic 344	com/jiayuan/util/t:c	(Landroid/content/Context;I)Ljava/lang/String;
    //   848: astore 48
    //   850: aload_0
    //   851: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   854: iconst_2
    //   855: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   858: checkcast 102	com/jiayuan/register/d
    //   861: getfield 341	com/jiayuan/register/d:d	I
    //   864: istore 49
    //   866: aload_0
    //   867: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   870: iconst_2
    //   871: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   874: checkcast 102	com/jiayuan/register/d
    //   877: getfield 345	com/jiayuan/register/d:e	I
    //   880: istore 50
    //   882: aload_0
    //   883: astore 51
    //   885: iload 49
    //   887: istore 52
    //   889: iload 50
    //   891: istore 53
    //   893: aload 51
    //   895: iload 52
    //   897: iload 53
    //   899: invokestatic 348	com/jiayuan/util/t:a	(Landroid/content/Context;II)Ljava/lang/String;
    //   902: astore 54
    //   904: aload_0
    //   905: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   908: iconst_3
    //   909: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   912: checkcast 102	com/jiayuan/register/d
    //   915: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   918: astore 55
    //   920: aload_0
    //   921: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   924: iconst_4
    //   925: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   928: checkcast 102	com/jiayuan/register/d
    //   931: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   934: astore 56
    //   936: aload_0
    //   937: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   940: astore 57
    //   942: iconst_5
    //   943: istore 58
    //   945: aload 57
    //   947: iload 58
    //   949: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   952: checkcast 102	com/jiayuan/register/d
    //   955: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   958: astore 59
    //   960: aload_0
    //   961: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   964: astore 60
    //   966: bipush 6
    //   968: istore 61
    //   970: aload 60
    //   972: iload 61
    //   974: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   977: checkcast 102	com/jiayuan/register/d
    //   980: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   983: astore 62
    //   985: aload_0
    //   986: astore 63
    //   988: new 350	com/jiayuan/register/a
    //   991: dup
    //   992: aload 63
    //   994: aload 38
    //   996: aload 39
    //   998: aload 40
    //   1000: aload 41
    //   1002: iload 42
    //   1004: iload 43
    //   1006: iload 44
    //   1008: aload 48
    //   1010: aload 54
    //   1012: aload 55
    //   1014: aload 56
    //   1016: aload 59
    //   1018: aload 62
    //   1020: aload 32
    //   1022: invokespecial 353	com/jiayuan/register/a:<init>	(Lcom/jiayuan/register/g;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1025: invokevirtual 355	com/jiayuan/register/a:a	()V
    //   1028: goto -903 -> 125
    //   1031: invokevirtual 358	java/io/UnsupportedEncodingException:printStackTrace	()V
    //   1034: aload 4
    //   1036: astore 32
    //   1038: goto -357 -> 681
    //   1041: aload_0
    //   1042: getfield 210	com/jiayuan/register/RegisterActivity:n	Landroid/widget/EditText;
    //   1045: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   1048: invokeinterface 222 1 0
    //   1053: astore 64
    //   1055: aload_0
    //   1056: getfield 284	com/jiayuan/register/RegisterActivity:M	Ljava/lang/String;
    //   1059: astore 65
    //   1061: aload_0
    //   1062: getfield 360	com/jiayuan/register/RegisterActivity:N	I
    //   1065: istore 66
    //   1067: aload_0
    //   1068: getfield 274	com/jiayuan/register/RegisterActivity:c	I
    //   1071: istore 67
    //   1073: aload_0
    //   1074: getfield 230	com/jiayuan/register/RegisterActivity:o	Landroid/widget/EditText;
    //   1077: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   1080: invokeinterface 222 1 0
    //   1085: astore 68
    //   1087: aload_0
    //   1088: getfield 242	com/jiayuan/register/RegisterActivity:p	Landroid/widget/EditText;
    //   1091: invokevirtual 216	android/widget/EditText:getText	()Landroid/text/Editable;
    //   1094: invokeinterface 222 1 0
    //   1099: astore 69
    //   1101: aload_0
    //   1102: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1105: aconst_null
    //   1106: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1109: checkcast 102	com/jiayuan/register/d
    //   1112: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   1115: astore 70
    //   1117: aload_0
    //   1118: getfield 130	com/jiayuan/register/RegisterActivity:u	I
    //   1121: istore 71
    //   1123: aload_0
    //   1124: getfield 159	com/jiayuan/register/RegisterActivity:v	I
    //   1127: iconst_1
    //   1128: iadd
    //   1129: istore 72
    //   1131: aload_0
    //   1132: getfield 161	com/jiayuan/register/RegisterActivity:w	I
    //   1135: istore 73
    //   1137: aload_0
    //   1138: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1141: iconst_2
    //   1142: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1145: checkcast 102	com/jiayuan/register/d
    //   1148: getfield 341	com/jiayuan/register/d:d	I
    //   1151: istore 74
    //   1153: aload_0
    //   1154: astore 75
    //   1156: iload 74
    //   1158: istore 76
    //   1160: aload 75
    //   1162: iload 76
    //   1164: invokestatic 344	com/jiayuan/util/t:c	(Landroid/content/Context;I)Ljava/lang/String;
    //   1167: astore 77
    //   1169: aload_0
    //   1170: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1173: iconst_2
    //   1174: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1177: checkcast 102	com/jiayuan/register/d
    //   1180: getfield 341	com/jiayuan/register/d:d	I
    //   1183: istore 78
    //   1185: aload_0
    //   1186: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1189: iconst_2
    //   1190: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1193: checkcast 102	com/jiayuan/register/d
    //   1196: getfield 345	com/jiayuan/register/d:e	I
    //   1199: istore 79
    //   1201: aload_0
    //   1202: astore 80
    //   1204: iload 78
    //   1206: istore 81
    //   1208: iload 79
    //   1210: istore 82
    //   1212: aload 80
    //   1214: iload 81
    //   1216: iload 82
    //   1218: invokestatic 348	com/jiayuan/util/t:a	(Landroid/content/Context;II)Ljava/lang/String;
    //   1221: astore 83
    //   1223: aload_0
    //   1224: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1227: iconst_3
    //   1228: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1231: checkcast 102	com/jiayuan/register/d
    //   1234: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   1237: astore 84
    //   1239: aload_0
    //   1240: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1243: iconst_4
    //   1244: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1247: checkcast 102	com/jiayuan/register/d
    //   1250: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   1253: astore 85
    //   1255: aload_0
    //   1256: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1259: iconst_5
    //   1260: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1263: checkcast 102	com/jiayuan/register/d
    //   1266: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   1269: astore 86
    //   1271: aload_0
    //   1272: getfield 170	com/jiayuan/register/RegisterActivity:m	Ljava/util/ArrayList;
    //   1275: bipush 6
    //   1277: invokevirtual 303	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1280: checkcast 102	com/jiayuan/register/d
    //   1283: getfield 305	com/jiayuan/register/d:b	Ljava/lang/String;
    //   1286: astore 87
    //   1288: aload_0
    //   1289: astore 88
    //   1291: aload 32
    //   1293: astore 89
    //   1295: new 350	com/jiayuan/register/a
    //   1298: dup
    //   1299: aload 88
    //   1301: aload 64
    //   1303: aload 65
    //   1305: iload 66
    //   1307: iload 67
    //   1309: aload 68
    //   1311: aload 69
    //   1313: aload 70
    //   1315: iload 71
    //   1317: iload 72
    //   1319: iload 73
    //   1321: aload 77
    //   1323: aload 83
    //   1325: aload 84
    //   1327: aload 85
    //   1329: aload 86
    //   1331: aload 87
    //   1333: aload 89
    //   1335: invokespecial 363	com/jiayuan/register/a:<init>	(Lcom/jiayuan/register/g;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1338: invokevirtual 355	com/jiayuan/register/a:a	()V
    //   1341: goto -1216 -> 125
    //   1344: astore 90
    //   1346: goto -617 -> 729
    //   1349: astore 91
    //   1351: goto -622 -> 729
    //
    // Exception table:
    //   from	to	target	type
    //   487	546	549	java/io/UnsupportedEncodingException
    //   669	678	1031	java/io/UnsupportedEncodingException
    //   681	729	1344	java/lang/Exception
    //   681	729	1349	android/view/WindowManager$BadTokenException
  }

  private void j()
  {
    int i1 = 5;
    int i2 = 4;
    int i3 = 2;
    int i4 = null;
    Object localObject1 = 1;
    com.jiayuan.util.a.a("RegisterActivity", "saveRegInfo");
    Object localObject2 = b.m(this.t);
    this.p.setText((CharSequence)localObject2);
    Object localObject7 = b.x(this.t);
    localObject2 = ((String)localObject7).equals("");
    if ((localObject2 != 0) || (localObject7 == null));
    do
    {
      label66: return;
      StringBuilder localStringBuilder1 = new StringBuilder("register resume sex=");
      int i5 = ((d)this.m.get(i4)).d;
      localObject3 = i5;
      com.jiayuan.util.a.a("RegisterActivity", (String)localObject3);
      ((d)this.m.get(i4)).b = ((String)localObject7);
      localObject3 = b.n(this.t);
      localObject7 = ((String)localObject3).equals("");
    }
    while ((localObject7 != 0) || (localObject3 == null));
    Object localObject3 = (d)this.m.get(localObject1);
    localObject7 = b.n(this.t);
    ((d)localObject3).b = ((String)localObject7);
    StringBuilder localStringBuilder2 = new StringBuilder("register resume birthday");
    localObject3 = ((d)this.m.get(localObject1)).b;
    localObject3 = (String)localObject3;
    com.jiayuan.util.a.a("RegisterActivity", (String)localObject3);
    localObject3 = ((d)this.m.get(localObject1)).b.split("-");
    localObject7 = Integer.parseInt(localObject3[i4]);
    this.u = localObject7;
    int i9 = Integer.parseInt(localObject3[localObject1]) - localObject1;
    this.v = i9;
    localObject3 = Integer.parseInt(localObject3[i3]);
    this.w = localObject3;
    localObject3 = (d)this.m.get(i3);
    Object localObject8 = b.o(this.t);
    ((d)localObject3).b = ((String)localObject8);
    localObject3 = (d)this.m.get(i3);
    localObject8 = b.p(this.t);
    ((d)localObject3).d = localObject8;
    localObject3 = (d)this.m.get(i3);
    localObject8 = b.q(this.t);
    ((d)localObject3).c = ((String)localObject8);
    localObject3 = (d)this.m.get(i3);
    localObject8 = b.r(this.t);
    ((d)localObject3).e = localObject8;
    localObject3 = (d)this.m.get(3);
    localObject8 = b.s(this.t);
    ((d)localObject3).b = ((String)localObject8);
    localObject3 = (d)this.m.get(3);
    localObject8 = ((d)this.m.get(3)).b;
    localObject8 = f.H(this, (String)localObject8);
    ((d)localObject3).d = localObject8;
    localObject3 = (d)this.m.get(i2);
    localObject8 = b.t(this.t);
    ((d)localObject3).b = ((String)localObject8);
    localObject3 = (d)this.m.get(i2);
    Context localContext1 = this.t;
    localObject8 = ((d)this.m.get(i2)).b;
    localObject8 = f.t(localContext1, (String)localObject8);
    ((d)localObject3).d = localObject8;
    StringBuilder localStringBuilder3 = new StringBuilder("register resume marriage=");
    int i6 = ((d)this.m.get(i2)).d;
    Object localObject4 = i6;
    com.jiayuan.util.a.a("RegisterActivity", (String)localObject4);
    localObject4 = (d)this.m.get(i1);
    localObject8 = b.u(this.t);
    ((d)localObject4).b = ((String)localObject8);
    localObject4 = (d)this.m.get(i1);
    Context localContext2 = this.t;
    localObject8 = ((d)this.m.get(i1)).b;
    localObject8 = f.u(localContext2, (String)localObject8);
    ((d)localObject4).d = localObject8;
    StringBuilder localStringBuilder4 = new StringBuilder("register resume education=");
    int i7 = ((d)this.m.get(i1)).d;
    Object localObject5 = i7;
    com.jiayuan.util.a.a("RegisterActivity", (String)localObject5);
    localObject5 = (d)this.m.get(6);
    localObject8 = b.v(this.t);
    ((d)localObject5).b = ((String)localObject8);
    localObject5 = (d)this.m.get(6);
    Context localContext3 = this.t;
    localObject8 = ((d)this.m.get(6)).b;
    localObject8 = f.z(localContext3, (String)localObject8);
    ((d)localObject5).d = localObject8;
    StringBuilder localStringBuilder5 = new StringBuilder("register resume income=");
    int i8 = ((d)this.m.get(6)).d;
    Object localObject6 = i8;
    com.jiayuan.util.a.a("RegisterActivity", (String)localObject6);
    localObject6 = b.w(this.t);
    this.q.setText((CharSequence)localObject6);
    localObject8 = this.y;
    localObject6 = ((d)this.m.get(i4)).b.equals("�");
    if (localObject6 != 0)
      localObject6 = i4;
    while (true)
    {
      ((Spinner)localObject8).setSelection(localObject6);
      Spinner localSpinner1 = this.z;
      int i10 = ((d)this.m.get(i2)).d;
      ((Spinner)localObject8).setSelection(localObject6);
      Spinner localSpinner2 = this.A;
      int i11 = ((d)this.m.get(i1)).d;
      ((Spinner)localObject8).setSelection(localObject6);
      Spinner localSpinner3 = this.B;
      int i12 = ((d)this.m.get(6)).d;
      ((Spinner)localObject6).setSelection(localObject8);
      break label66:
      localObject6 = localObject1;
    }
  }

  private void k()
  {
    com.jiayuan.util.a.a("RegisterActivity", "saveRegInfo");
    Context localContext1 = this.t;
    String str1 = this.p.getText().toString();
    b.e(localContext1, str1);
    Context localContext2 = this.t;
    String str2 = ((d)this.m.get(0)).b;
    b.n(localContext2, str2);
    StringBuffer localStringBuffer = new StringBuffer();
    int i1 = this.u;
    localStringBuffer.append(i1);
    localStringBuffer.append("-");
    int i2 = this.v;
    int i3;
    ++i3;
    localStringBuffer.append(i2);
    localStringBuffer.append("-");
    int i4 = this.w;
    localStringBuffer.append(i4);
    Context localContext3 = this.t;
    String str3 = localStringBuffer.toString();
    b.f(localContext3, str3);
    Context localContext4 = this.t;
    String str4 = ((d)this.m.get(2)).b;
    b.g(localContext4, str4);
    Context localContext5 = this.t;
    int i5 = ((d)this.m.get(2)).d;
    b.d(localContext5, i5);
    Context localContext6 = this.t;
    String str5 = ((d)this.m.get(2)).c;
    b.h(localContext6, str5);
    Context localContext7 = this.t;
    int i6 = ((d)this.m.get(2)).e;
    b.e(localContext7, i6);
    Context localContext8 = this.t;
    String str6 = ((d)this.m.get(3)).b;
    b.i(localContext8, str6);
    Context localContext9 = this.t;
    String str7 = ((d)this.m.get(4)).b;
    b.j(localContext9, str7);
    Context localContext10 = this.t;
    String str8 = ((d)this.m.get(5)).b;
    b.k(localContext10, str8);
    Context localContext11 = this.t;
    String str9 = ((d)this.m.get(6)).b;
    b.l(localContext11, str9);
    Context localContext12 = this.t;
    String str10 = this.q.getText().toString().trim();
    b.m(localContext12, str10);
  }

  private void l()
  {
    d locald = (d)this.m.get(1);
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i1 = this.u;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i1).append("-");
    int i2 = this.v;
    int i3;
    ++i3;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(i2).append("-");
    int i4 = this.w;
    String str = i4;
    locald.b = str;
  }

  private View m()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099686);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = a(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    d locald1 = this.C;
    String str1 = ((d)this.m.get(2)).a;
    locald1.a = str1;
    d locald2 = this.C;
    String str2 = ((d)this.m.get(2)).b;
    locald2.b = str2;
    d locald3 = this.C;
    String str3 = ((d)this.m.get(2)).c;
    locald3.c = str3;
    d locald4 = this.C;
    int i2 = ((d)this.m.get(2)).d;
    locald4.d = i2;
    d locald5 = this.C;
    int i3 = ((d)this.m.get(2)).e;
    locald5.e = i3;
    StringBuilder localStringBuilder1 = new StringBuilder("tempCell.detail=");
    String str4 = this.C.b;
    String str5 = str4;
    com.jiayuan.util.a.a("RegisterActivity", str5);
    StringBuilder localStringBuilder2 = new StringBuilder("tempCell.detail1=");
    String str6 = this.C.c;
    String str7 = str6;
    com.jiayuan.util.a.a("RegisterActivity", str7);
    s locals = new s(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(locals);
    return localView;
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int i1 = ((d)this.m.get(paramInt3)).d;
    localSpinner.setSelection(i1, true);
    StringBuilder localStringBuilder1 = new StringBuilder("register ");
    String str1 = ((d)this.m.get(paramInt3)).b;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(" ");
    int i2 = ((d)this.m.get(paramInt3)).d;
    String str2 = i2;
    com.jiayuan.util.a.a("RegisterActivity", str2);
    t localt = new t(this, paramInt3);
    localSpinner.setOnItemSelectedListener(localt);
    return localSpinner;
  }

  public void a()
  {
    Calendar localCalendar = Calendar.getInstance();
    int i1 = localCalendar.get(1) - 18;
    this.u = i1;
    int i2 = localCalendar.get(2);
    this.v = i2;
    int i3 = localCalendar.get(5);
    this.w = i3;
  }

  public void a(int paramInt, Bitmap paramBitmap)
  {
    Bitmap localBitmap = com.jiayuan.util.s.a(paramBitmap, 110, 135);
    Button localButton = (Button)findViewById(2131362132);
    BitmapDrawable localBitmapDrawable = new BitmapDrawable(localBitmap);
    localButton.setBackgroundDrawable(localBitmapDrawable);
    this.b = localBitmap;
  }

  public void a(HeightPicker paramHeightPicker, int paramInt)
  {
    String str1 = "onHeightChanged height=" + paramInt;
    com.jiayuan.util.a.a("RegisterActivity", str1);
    StringBuilder localStringBuilder1 = new StringBuilder("onHeightChanged height=");
    int i1 = f.q(this, paramInt);
    String str2 = i1;
    com.jiayuan.util.a.a("RegisterActivity", str2);
    d locald = (d)this.m.get(3);
    StringBuilder localStringBuilder2 = new StringBuilder();
    int i2 = f.q(this, paramInt);
    String str3 = i2;
    locald.b = str3;
    ((d)this.m.get(3)).d = paramInt;
    this.s.notifyDataSetChanged();
  }

  public void a(String paramString)
  {
    String str = "onPhotoUploadReturn aResult=" + paramString;
    com.jiayuan.util.a.a("RegisterActivity", str);
    while (true)
      try
      {
        if (new JSONObject(paramString).getString("retcode").equalsIgnoreCase("1"))
        {
          Toast.makeText(this, 2131165636, 1).show();
          return;
        }
        Toast.makeText(this, 2131165637, 1).show();
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public void a_(String paramString)
  {
    if (this.D != null)
      this.D.dismiss();
    if (this.E != null)
      this.E.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    NumberPicker localNumberPicker1 = (NumberPicker)findViewById(2131362126);
    this.x = localNumberPicker1;
    NumberPicker localNumberPicker2 = this.x;
    com.jiayuan.util.picker.p localp = NumberPicker.a;
    localNumberPicker2.a(localp);
    this.x.a(200L);
    NumberPicker localNumberPicker3 = this.x;
    String[] arrayOfString = getResources().getStringArray(2131099730);
    localNumberPicker3.a(0, 4, arrayOfString);
    NumberPicker localNumberPicker4 = this.x;
    q localq = new q(this);
    localNumberPicker4.a(localq);
  }

  public void b(String paramString)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      switch (localJSONObject.getInt("retcode"))
      {
      default:
        Toast.makeText(this.t, 2131165293, 1).show();
        return;
      case 1:
        label146: com.jiayuan.util.o.a(localJSONObject.getString("uid"));
        com.jiayuan.util.o.b(localJSONObject.getString("token"));
        com.jiayuan.util.o.c(this.n.getText().toString().toLowerCase());
        com.jiayuan.util.o.d(this.o.getText().toString());
        b.a(this, true);
        b.b(this, true);
        String str1 = this.n.getText().toString();
        b.a(this, localJSONObject);
        String str2 = this.o.getText().toString();
        b.b(this, localJSONObject);
        if (this.b != null)
        {
          com.jiayuan.util.a.a("RegisterActivity", "onGetRegisterData null != bmHeader");
          Bitmap localBitmap = this.b;
          new com.jiayuan.util.m(this, "avatar", localBitmap).a();
        }
        com.jiayuan.a locala = com.jiayuan.a.a();
        locala.b(MainActivity.class);
        locala.d(this);
        Intent localIntent1 = new Intent(this, NotificationService.class);
        startService(localIntent1);
        Intent localIntent2 = new Intent();
        Bundle localBundle = new Bundle();
        localIntent2.setClass(this, MateSelectionActivity.class);
        localIntent2.putExtras(localBundle);
        startActivity(localIntent2);
        finish();
      case -20:
      case -21:
      case -22:
      case -23:
      case -24:
      case -25:
      case -26:
      case -27:
      case -28:
      case -29:
      case -30:
      case -31:
      }
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      break label146:
      Toast.makeText(this.t, 2131165294, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165295, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165296, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165297, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165298, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165299, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165300, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165301, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165302, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165303, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165305, 1).show();
      break label146:
      Toast.makeText(this.t, 2131165304, 1).show();
    }
  }

  public void c()
  {
    Spinner localSpinner1 = a(2131362127, "璇烽�", 2131099735, 0);
    this.y = localSpinner1;
    Spinner localSpinner2 = a(2131362128, "璇烽�", 2131099737, 4);
    this.z = localSpinner2;
    Spinner localSpinner3 = a(2131362129, "璇烽�", 2131099736, 5);
    this.A = localSpinner3;
    Spinner localSpinner4 = a(2131362130, "璇烽�", 2131099743, 6);
    this.B = localSpinner4;
  }

  public void d()
  {
    if (this.D != null)
      this.D.dismiss();
    if (this.E == null)
      return;
    this.E.dismiss();
  }

  public void d(String paramString)
  {
    int i1 = 1;
    if (paramString.equals("NETWORK_ERROR"))
      Toast.makeText(this.t, 2131165663, i1).show();
    while (true)
    {
      return;
      try
      {
        switch (new JSONObject(paramString).getInt("retcode"))
        {
        default:
          break;
        case -2:
          Toast.makeText(this.t, 2131165319, 1).show();
        case 1:
        case 300:
        case 400:
        case 500:
        case -1:
        }
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
      continue;
      Toast.makeText(this.t, 2131165314, 1).show();
      continue;
      Toast.makeText(this.t, 2131165315, 1).show();
      continue;
      Toast.makeText(this.t, 2131165316, 1).show();
      continue;
      Toast.makeText(this.t, 2131165317, 1).show();
      continue;
      Toast.makeText(this.t, 2131165318, 1).show();
    }
  }

  public void e()
  {
  }

  public void f()
  {
    this.D.dismiss();
  }

  public void g()
  {
  }

  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if (this.a == null)
      return;
    this.a.a(paramInt1, paramInt2, paramIntent);
  }

  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    Object localObject1 = 1;
    Object localObject2 = (AdapterView.AdapterContextMenuInfo)paramMenuItem.getMenuInfo();
    localObject2 = this.a;
    if (localObject2 == null)
    {
      localObject2 = new com.jiayuan.util.r(this, 0);
      this.a = ((com.jiayuan.util.r)localObject2);
    }
    localObject2 = paramMenuItem.getItemId();
    switch (localObject2)
    {
    default:
    case 0:
    case 1:
    }
    for (localObject2 = localObject1; ; localObject2 = localObject1)
    {
      while (true)
      {
        return localObject2;
        this.a.a();
        localObject2 = localObject1;
      }
      this.a.b();
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool1 = true;
    boolean bool2 = null;
    super.onCreate(paramBundle);
    setContentView(2130903093);
    this.t = this;
    Object localObject = new d();
    ((d)localObject).a = "鎬";
    ((d)localObject).b = "�";
    ((d)localObject).c = "";
    ((d)localObject).d = bool2;
    ((d)localObject).e = bool2;
    d locald1 = new d();
    locald1.a = "鐢";
    locald1.b = "璇�";
    locald1.c = "";
    locald1.d = bool2;
    locald1.e = bool2;
    d locald2 = new d();
    locald2.a = "鍦";
    locald2.b = "璇�";
    locald2.c = "";
    locald2.d = bool2;
    locald2.e = bool2;
    d locald3 = new d();
    locald3.a = "韬";
    locald3.b = "170";
    locald3.c = "";
    String str1 = locald3.b;
    int i1 = f.H(this, str1);
    locald3.d = i1;
    locald3.e = bool2;
    d locald4 = new d();
    locald4.a = "濠";
    locald4.b = "鏈";
    locald4.c = "";
    locald4.d = bool2;
    locald4.e = bool2;
    d locald5 = new d();
    locald5.a = "瀛";
    locald5.b = "鏈";
    locald5.c = "";
    locald5.d = 2;
    locald5.e = bool2;
    d locald6 = new d();
    locald6.a = "鏀";
    locald6.b = "2000-5000";
    locald6.c = "";
    locald6.d = bool1;
    locald6.e = bool2;
    ArrayList localArrayList1 = new ArrayList();
    this.m = localArrayList1;
    this.m.add(localObject);
    this.m.add(locald1);
    this.m.add(locald2);
    this.m.add(locald3);
    this.m.add(locald4);
    this.m.add(locald5);
    this.m.add(locald6);
    a();
    b();
    c();
    localObject = (ListView)findViewById(2131362125);
    this.r = ((ListView)localObject);
    localObject = getLayoutInflater();
    View localView1 = ((LayoutInflater)localObject).inflate(2130903094, null);
    this.r.addHeaderView(localView1);
    View localView2 = ((LayoutInflater)localObject).inflate(2130903095, null);
    this.r.addFooterView(localView2);
    localObject = (EditText)localView1.findViewById(2131362134);
    this.n = ((EditText)localObject);
    localObject = (EditText)localView1.findViewById(2131362135);
    this.o = ((EditText)localObject);
    localObject = (EditText)localView1.findViewById(2131362136);
    this.p = ((EditText)localObject);
    localObject = (EditText)localView2.findViewById(2131362137);
    this.q = ((EditText)localObject);
    localObject = (CheckBox)localView2.findViewById(2131362138);
    this.F = ((CheckBox)localObject);
    localObject = this.F;
    o localo = new o(this);
    ((CheckBox)localObject).setOnCheckedChangeListener(localo);
    localObject = (TextView)localView2.findViewById(2131362139);
    this.G = ((TextView)localObject);
    localObject = this.G;
    p localp = new p(this);
    ((TextView)localObject).setOnClickListener(localp);
    localObject = (Button)localView1.findViewById(2131362132);
    j localj = new j(this);
    ((Button)localObject).setOnClickListener(localj);
    registerForContextMenu((View)localObject);
    localObject = (Button)findViewById(2131362122);
    this.I = ((Button)localObject);
    localObject = this.I;
    k localk = new k(this);
    ((Button)localObject).setOnClickListener(localk);
    localObject = (Button)findViewById(2131362124);
    this.H = ((Button)localObject);
    localObject = this.H;
    l locall = new l(this);
    ((Button)localObject).setOnClickListener(locall);
    localObject = getIntent();
    boolean bool3 = ((Intent)localObject).getBooleanExtra("isEmail", bool1);
    this.L = bool3;
    if (!this.L)
    {
      this.c = bool1;
      String str2 = ((Intent)localObject).getStringExtra("telNum");
      this.J = str2;
      boolean bool4 = ((Intent)localObject).getBooleanExtra("needValid", bool1);
      this.K = bool4;
      if (!this.K)
        break label1017;
      this.N = bool1;
    }
    while (true)
    {
      StringBuilder localStringBuilder = new StringBuilder("needValid");
      boolean bool5 = this.K;
      String str3 = bool5;
      com.jiayuan.util.a.a("RegisterActivity", str3);
      String str4 = ((Intent)localObject).getStringExtra("validationCode");
      this.M = ((String)localObject);
      EditText localEditText = this.n;
      String str5 = this.J;
      ((EditText)localObject).setText(str5);
      this.n.setEnabled(bool2);
      this.n.setFocusable(bool2);
      try
      {
        j();
        label956: ArrayList localArrayList2 = this.m;
        i locali1 = new i(this, this, localArrayList2);
        this.s = locali1;
        this.s.setNotifyOnChange(bool2);
        ListView localListView = this.r;
        i locali2 = this.s;
        localListView.setAdapter(locali2);
        this.r.setOnItemClickListener(this);
        return;
        label1017: this.N = bool2;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        break label956:
      }
    }
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    super.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
    paramContextMenu.setHeaderTitle("閫夋");
    paramContextMenu.add(0, 0, 0, "鐩告").setIcon(2130837645);
    paramContextMenu.add(0, 1, 0, "鎵嬫").setIcon(2130837648);
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 12:
    case 13:
    }
    while (true)
    {
      return i1;
      DatePickerDialog.OnDateSetListener localOnDateSetListener = this.O;
      int i2 = this.u;
      int i3 = this.v;
      int i4 = this.w;
      RegisterActivity localRegisterActivity = this;
      Object localObject = new DatePickerDialog(localRegisterActivity, localOnDateSetListener, i2, i3, i4);
      continue;
      localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView = m();
      localObject = ((AlertDialog.Builder)localObject).setView(localView);
      m localm = new m(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165642, localm);
      r localr = new r(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, localr).create();
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i1 = 3;
    int i2 = 1;
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("RegisterActivity", str);
    int i3 = paramInt + -1;
    if (i3 == 0)
    {
      this.y.performClick();
      CharSequence localCharSequence1 = this.y.getPrompt();
      Toast.makeText(this, localCharSequence1, i2).show();
    }
    while (true)
    {
      return;
      if (i2 == i3)
        showDialog(12);
      if (2 == i3)
        showDialog(13);
      if (i1 == i3)
      {
        int i4 = ((d)this.m.get(i1)).d;
        new aa(this, this, i4).show();
      }
      if (4 == i3)
      {
        this.z.performClick();
        CharSequence localCharSequence2 = this.z.getPrompt();
        Toast.makeText(this, localCharSequence2, i2).show();
      }
      if (5 == i3)
      {
        this.A.performClick();
        CharSequence localCharSequence3 = this.A.getPrompt();
        Toast.makeText(this, localCharSequence3, i2).show();
      }
      if (6 != i3)
        continue;
      this.B.performClick();
      CharSequence localCharSequence4 = this.B.getPrompt();
      Toast.makeText(this, localCharSequence4, i2).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.RegisterActivity
 * JD-Core Version:    0.5.4
 */