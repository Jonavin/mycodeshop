package com.jiayuan.register;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class i extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  i(RegisterActivity paramRegisterActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903097, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    e locale = (e)paramView.getTag();
    locale.d = paramInt;
    paramView.setTag(locale);
    TextView localTextView1 = locale.a;
    String str1 = ((d)RegisterActivity.g(this.b).get(paramInt)).a;
    localTextView1.setText(str1);
    TextView localTextView2 = locale.b;
    String str2 = String.valueOf(((d)RegisterActivity.g(this.b).get(paramInt)).b);
    StringBuilder localStringBuilder = new StringBuilder(str2);
    String str3 = ((d)RegisterActivity.g(this.b).get(paramInt)).c;
    String str4 = str3;
    localTextView2.setText(str4);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903097, paramViewGroup, null);
      e locale = new e(null);
      localObject = (TextView)localView.findViewById(2131362143);
      locale.a = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131362144);
      locale.b = ((TextView)localObject);
      localObject = (ImageView)localView.findViewById(2131362145);
      locale.c = ((ImageView)localObject);
      localView.setTag(locale);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    e locale = (e)((View)paramView.getTag()).getTag();
    a.a("RegisterActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.register.i
 * JD-Core Version:    0.5.4
 */