package com.jiayuan.login;

import android.app.Activity;
import com.jiayuan.a.c;
import com.jiayuan.a.o;
import com.jiayuan.a.u;
import com.jiayuan.a.y;
import com.jiayuan.util.a;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class j
  implements c, o
{
  public l a;
  private String b;
  private Activity c;

  public j(l paraml, String paramString)
  {
    Activity localActivity = (Activity)paraml;
    this.c = localActivity;
    this.a = paraml;
    this.b = paramString;
  }

  public void a()
  {
    a.a("LoginUserInfoDataProcessing", "execute()");
    ArrayList localArrayList1 = new ArrayList();
    String str1 = this.b;
    localArrayList1.add(str1);
    ArrayList localArrayList2 = new ArrayList();
    Integer localInteger1 = Integer.valueOf(1);
    localArrayList2.add(localInteger1);
    Integer localInteger2 = Integer.valueOf(2);
    localArrayList2.add(localInteger2);
    Integer localInteger3 = Integer.valueOf(6);
    localArrayList2.add(localInteger3);
    Integer localInteger4 = Integer.valueOf(112);
    localArrayList2.add(localInteger4);
    Integer localInteger5 = Integer.valueOf(127);
    localArrayList2.add(localInteger5);
    Integer localInteger6 = Integer.valueOf(128);
    localArrayList2.add(localInteger6);
    Integer localInteger7 = Integer.valueOf(129);
    localArrayList2.add(localInteger7);
    Integer localInteger8 = Integer.valueOf(130);
    localArrayList2.add(localInteger8);
    Integer localInteger9 = Integer.valueOf(131);
    localArrayList2.add(localInteger9);
    Integer localInteger10 = Integer.valueOf(132);
    localArrayList2.add(localInteger10);
    Integer localInteger11 = Integer.valueOf(133);
    localArrayList2.add(localInteger11);
    Integer localInteger12 = Integer.valueOf(134);
    localArrayList2.add(localInteger12);
    Integer localInteger13 = Integer.valueOf(135);
    localArrayList2.add(localInteger13);
    Integer localInteger14 = Integer.valueOf(136);
    localArrayList2.add(localInteger14);
    Integer localInteger15 = Integer.valueOf(137);
    localArrayList2.add(localInteger15);
    new y(this, localArrayList1, localArrayList2).a();
    String str2 = this.b;
    new u(this, str2, -1).a();
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    this.a.a(paramJSONArray, paramInt);
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("LoginUserInfoDataProcessing", str2);
    this.a.a(paramJSONObject);
  }

  public void a_(String paramString)
  {
    this.a.c(paramString);
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.j
 * JD-Core Version:    0.5.4
 */