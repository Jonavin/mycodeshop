package com.jiayuan.login;

import android.view.View;
import android.view.View.OnClickListener;

class h
  implements View.OnClickListener
{
  h(LoginActivity paramLoginActivity)
  {
  }

  public void onClick(View paramView)
  {
    LoginActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.h
 * JD-Core Version:    0.5.4
 */