package com.jiayuan.login;

import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class d
  implements CompoundButton.OnCheckedChangeListener
{
  d(LoginActivity paramLoginActivity)
  {
  }

  public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    if (paramBoolean)
      return;
    this.a.e.setChecked(null);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.d
 * JD-Core Version:    0.5.4
 */