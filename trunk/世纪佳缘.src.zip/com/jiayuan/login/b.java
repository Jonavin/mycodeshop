package com.jiayuan.login;

import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class b
  implements CompoundButton.OnCheckedChangeListener
{
  b(LoginActivity paramLoginActivity)
  {
  }

  public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    if (!paramBoolean)
      return;
    this.a.d.setChecked(true);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.b
 * JD-Core Version:    0.5.4
 */