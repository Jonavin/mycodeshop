package com.jiayuan.login;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.view.View;
import android.view.WindowManager.BadTokenException;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.register.RegisterType;
import com.jiayuan.system.service.NotificationService;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends MyActivity
  implements com.jiayuan.a.j, a, l
{
  ProgressDialog a;
  boolean b = null;
  boolean c = null;
  CheckBox d;
  CheckBox e;
  Context f;
  j g;
  private String h;

  private boolean c()
  {
    int i = 2131165227;
    Object localObject1 = 1;
    Object localObject2 = com.jiayuan.util.b.c(this, i);
    if (localObject2 != null)
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
      localObject2 = localSimpleDateFormat.format((Date)localObject2);
      Date localDate = new Date();
      String str = localSimpleDateFormat.format(localDate);
      com.jiayuan.util.a.a("LoginActivity", (String)localObject2);
      com.jiayuan.util.a.a("LoginActivity", str);
      localObject2 = ((String)localObject2).equals(str);
      if (localObject2 != 0)
        localObject2 = null;
    }
    while (true)
    {
      return localObject2;
      localObject2 = localObject1;
      continue;
      localObject2 = new Date();
      int j = ((Date)localObject2).getYear() - localObject1;
      ((Date)localObject2).setYear(j);
      com.jiayuan.util.b.a(this, i, (Date)localObject2);
      localObject2 = localObject1;
    }
  }

  private void e()
  {
    int i = 1;
    int j = 0;
    com.jiayuan.util.a.a("LoginActivity", "Login button clicked");
    Object localObject1 = (InputMethodManager)getSystemService("input_method");
    Object localObject2 = getCurrentFocus();
    if (localObject2 != null)
    {
      localObject2 = ((View)localObject2).getWindowToken();
      ((InputMethodManager)localObject1).hideSoftInputFromWindow((IBinder)localObject2, j);
    }
    localObject1 = (EditText)findViewById(2131361845);
    localObject2 = (EditText)findViewById(2131361846);
    if ((((EditText)localObject1).getText().toString().equals("")) || (((EditText)localObject2).getText().toString().equals("")))
      Toast.makeText(this, 2131165274, j).show();
    while (true)
    {
      return;
      if (((EditText)localObject1).getText().toString().length() > 128)
        Toast.makeText(this, 2131165275, j).show();
      try
      {
        String str1 = getResources().getString(2131165271);
        String str2 = getResources().getString(2131165272);
        ProgressDialog localProgressDialog = ProgressDialog.show(this, str1, str2);
        this.a = localProgressDialog;
        this.a.setCancelable(true);
        label191: String str3 = ((EditText)localObject1).getText().toString().toLowerCase();
        String str4 = ((EditText)localObject2).getText().toString();
        new k(this, (String)localObject1, (String)localObject2).a(i);
      }
      catch (Exception localException)
      {
        break label191:
      }
      catch (WindowManager.BadTokenException localBadTokenException)
      {
        break label191:
      }
    }
  }

  private void f()
  {
    com.jiayuan.util.a.a("LoginActivity", "Register button clicked");
    Intent localIntent = new Intent(this, RegisterType.class);
    startActivity(localIntent);
  }

  private void g()
  {
    com.jiayuan.util.b.e(this.f, "");
    com.jiayuan.util.b.n(this.f, "");
    com.jiayuan.util.b.f(this.f, "");
    com.jiayuan.util.b.g(this.f, "");
    com.jiayuan.util.b.d(this.f, 0);
    com.jiayuan.util.b.h(this.f, "");
    com.jiayuan.util.b.e(this.f, 0);
    com.jiayuan.util.b.i(this.f, "");
    com.jiayuan.util.b.j(this.f, "");
    com.jiayuan.util.b.k(this.f, "");
    com.jiayuan.util.b.l(this.f, "");
    com.jiayuan.util.b.m(this.f, "");
  }

  public AlertDialog a(int paramInt)
  {
    int i = 2131165197;
    int j = 2131165196;
    int k;
    switch (paramInt)
    {
    default:
      k = 0;
    case 0:
    case 1:
    }
    while (true)
    {
      return k;
      Object localObject = new AlertDialog.Builder(this).setTitle(j).setMessage(i);
      g localg = new g(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165647, i);
      f localf = new f(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, i).create();
      continue;
      localObject = new AlertDialog.Builder(this).setTitle(j).setMessage(i);
      e locale = new e(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton("鏇存", i);
      i locali = new i(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton("鍏抽", i).setCancelable(null).create();
    }
  }

  public void a()
  {
  }

  public void a(int paramInt, String paramString)
  {
    int i = 0;
    int j = 2131165227;
    int k = 1;
    com.jiayuan.util.a.a("LoginActivity", paramString);
    Boolean localBoolean = Boolean.valueOf(i);
    Object localObject2;
    label74: String str;
    boolean bool;
    label121: Object localObject1;
    try
    {
      localObject2 = new JSONObject(paramString);
      int i1 = ((JSONObject)localObject2).getInt("retcode");
      switch (i1)
      {
      default:
        localBoolean = Boolean.valueOf(true);
      case 0:
        localObject2 = com.jiayuan.util.b.e(this);
        str = com.jiayuan.util.b.f(this);
        bool = com.jiayuan.util.b.b(this);
        if (!this.b)
          break label184;
        Date localDate1 = new Date();
        com.jiayuan.util.b.a(this, j, localDate1);
        showDialog(i);
        return;
      case 1:
        int l = 1;
        this.b = l;
        localObject1 = ((JSONObject)localObject2).getString("url");
        this.h = ((String)localObject1);
      case 2:
      }
      this.c = true;
      localObject1 = ((JSONObject)localObject2).getString("url");
      label184: this.h = ((String)localObject1);
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      localObject1 = Boolean.valueOf(k);
      break label74:
      if (this.c)
      {
        localObject1 = com.jiayuan.util.b.c(this, j);
        if (localObject1 == null)
          localObject1 = new Date();
        int i2 = ((Date)localObject1).getYear() - k;
        ((Date)localObject1).setYear(i2);
        com.jiayuan.util.b.a(this, j, (Date)localObject1);
        showDialog(k);
      }
      if (!((Boolean)localObject1).booleanValue())
      {
        Date localDate2 = new Date();
        com.jiayuan.util.b.a(this, j, localDate2);
      }
      if ((bool) && (!((String)localObject2).equalsIgnoreCase("")) && (!str.equalsIgnoreCase("")));
      e();
      break label121:
    }
  }

  public void a(String paramString)
  {
    if (this.a != null)
      this.a.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    o.a(paramJSONArray);
    StringBuilder localStringBuilder = new StringBuilder("onGetServiceType serviceType=");
    String str1 = o.k().toString();
    String str2 = str1;
    com.jiayuan.util.a.a("LoginActivity", str2);
  }

  public void a(JSONObject paramJSONObject)
  {
    try
    {
      JSONObject localJSONObject1 = paramJSONObject.getJSONObject("userinfos");
      String str1 = o.e();
      JSONObject localJSONObject2 = localJSONObject1.getJSONObject(str1);
      o.a(s.a(localJSONObject2));
      String str2 = String.valueOf(2);
      o.f(localJSONObject2.getString(str2));
      StringBuilder localStringBuilder = new StringBuilder("onGetProfiles profile=");
      String str3 = o.j().toString();
      String str4 = str3;
      com.jiayuan.util.a.a("LoginActivity", str4);
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public void b()
  {
  }

  public void b(String paramString)
  {
    Object localObject1 = this.a;
    if (localObject1 != null)
    {
      localObject1 = this.a;
      ((ProgressDialog)localObject1).dismiss();
    }
    Object localObject2;
    try
    {
      localObject1 = new JSONObject(paramString);
      localObject2 = ((JSONObject)localObject1).getString("retcode");
      if (((String)localObject2).equalsIgnoreCase("1"))
      {
        o.a(((JSONObject)localObject1).getString("uid"));
        o.b(((JSONObject)localObject1).getString("token"));
        localObject1 = (EditText)findViewById(2131361845);
        localObject2 = (EditText)findViewById(2131361846);
        String str1 = o.g();
        String str2 = ((EditText)localObject1).getText().toString();
        if (!str1.equalsIgnoreCase(str2))
        {
          com.jiayuan.util.b.c(this, true);
          com.jiayuan.util.b.d(this, true);
          int j = com.jiayuan.util.b.b;
          com.jiayuan.util.b.a(this, j);
          com.jiayuan.util.b.b(this, 2131165216, "0");
        }
        o.c(((EditText)localObject1).getText().toString().toLowerCase());
        o.d(((EditText)localObject2).getText().toString());
        CheckBox localCheckBox1 = (CheckBox)findViewById(2131361850);
        CheckBox localCheckBox2 = (CheckBox)findViewById(2131361851);
        boolean bool1 = localCheckBox1.isChecked();
        com.jiayuan.util.b.a(this, bool1);
        boolean bool2 = localCheckBox2.isChecked();
        com.jiayuan.util.b.b(this, bool2);
        String str3 = ((EditText)localObject1).getText().toString();
        com.jiayuan.util.b.a(this, (String)localObject1);
        if (localCheckBox1.isChecked())
        {
          String str4 = ((EditText)localObject2).getText().toString();
          com.jiayuan.util.b.b(this, str4);
        }
        com.jiayuan.a locala = com.jiayuan.a.a();
        locala.b(LoginActivity.class);
        locala.d(this);
        Intent localIntent1 = new Intent(this, NotificationService.class);
        startService(localIntent1);
        Intent localIntent2 = new Intent();
        Bundle localBundle = new Bundle();
        localBundle.putInt("tabIndex", 0);
        localIntent2.setClass(this, MainActivity.class);
        localIntent2.putExtras(localBundle);
        startActivity(localIntent2);
        String str5 = o.e();
        j localj = new j(this, str5);
        this.g = localj;
        this.g.a();
        finish();
        label383: g();
        return;
      }
      int i = 2131361846;
      ((EditText)findViewById(i)).setText("");
      if (!((String)localObject2).equalsIgnoreCase("-7"))
        break label434;
      label434: Toast.makeText(this, 2131165276, 0).show();
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      break label383:
      if (((String)localObject2).equalsIgnoreCase("2"))
        Toast.makeText(this, 2131165277, 0).show();
      if (((String)localObject2).equalsIgnoreCase("3"))
        Toast.makeText(this, 2131165278, 0).show();
      if (((String)localObject2).equalsIgnoreCase("4"))
        Toast.makeText(this, 2131165279, 0).show();
      if (((String)localObject2).equalsIgnoreCase("-1"))
        Toast.makeText(this, 2131165280, 0).show();
      if (((String)localObject2).equalsIgnoreCase("-2"))
        Toast.makeText(this, 2131165281, 0).show();
      if (((String)localObject2).equalsIgnoreCase("-5"));
      Toast.makeText(this, 2131165282, 0).show();
    }
  }

  public void c(String paramString)
  {
    this.g.a();
  }

  public void d()
  {
    if (this.a == null)
      return;
    this.a.dismiss();
  }

  public void onCreate(Bundle paramBundle)
  {
    int i = 1;
    super.onCreate(paramBundle);
    setContentView(2130903051);
    this.f = this;
    Object localObject1 = new StringBuilder("Static.uid=");
    String str1 = o.a;
    localObject1 = str1;
    com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
    localObject1 = new StringBuilder("Static.token=");
    str1 = o.b;
    localObject1 = str1;
    com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
    localObject1 = new StringBuilder("Static.email=");
    str1 = o.c;
    localObject1 = str1;
    com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
    localObject1 = new StringBuilder("Static.password=");
    str1 = o.d;
    localObject1 = str1;
    com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
    localObject1 = new StringBuilder("Static.sex=");
    str1 = o.e;
    localObject1 = str1;
    com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
    Object localObject3 = o.f;
    label228: Object localObject2;
    label277: Object localObject4;
    boolean bool2;
    if (localObject3 != null)
    {
      localObject3 = "LoginActivity";
      localObject1 = new StringBuilder("Static.profile.toString()=");
      str1 = o.f.toString();
      localObject1 = str1;
      com.jiayuan.util.a.a((String)localObject3, (String)localObject1);
      localObject3 = o.g;
      if (localObject3 == null)
        break label671;
      localObject3 = "LoginActivity";
      localObject1 = new StringBuilder("Static.serviceType.toString()=");
      str1 = o.g.toString();
      localObject1 = str1;
      com.jiayuan.util.a.a((String)localObject3, (String)localObject1);
      localObject1 = new StringBuilder("Static.UNREAD_MAIL_COUNT=");
      int j = o.h;
      localObject1 = j;
      com.jiayuan.util.a.a("LoginActivity", (String)localObject1);
      localObject3 = (EditText)findViewById(2131361845);
      ((EditText)localObject3).setLines(i);
      localObject1 = (EditText)findViewById(2131361846);
      ((EditText)localObject1).setLines(i);
      localObject2 = (CheckBox)findViewById(2131361850);
      this.d = ((CheckBox)localObject2);
      localObject2 = this.d;
      localObject4 = new d(this);
      ((CheckBox)localObject2).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)localObject4);
      localObject2 = (CheckBox)findViewById(2131361851);
      this.e = ((CheckBox)localObject2);
      localObject2 = this.e;
      localObject4 = new b(this);
      ((CheckBox)localObject2).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)localObject4);
      localObject2 = com.jiayuan.util.b.e(this);
      localObject4 = com.jiayuan.util.b.f(this);
      boolean bool1 = com.jiayuan.util.b.a(this);
      bool2 = com.jiayuan.util.b.b(this);
      String str2 = "userName userName userName userName=" + (String)localObject2;
      com.jiayuan.util.a.a("LoginActivity", str2);
      String str3 = "password password password password=" + (String)localObject4;
      com.jiayuan.util.a.a("LoginActivity", str3);
      if (!((String)localObject2).equalsIgnoreCase(""))
        ((EditText)localObject3).setText((CharSequence)localObject2);
      if ((bool1) && (!((String)localObject4).equalsIgnoreCase("")))
        ((EditText)localObject1).setText((CharSequence)localObject4);
      if (((String)localObject2).equalsIgnoreCase(""))
        break label688;
      this.d.setChecked(bool1);
      this.e.setChecked(bool2);
      label567: if (!c())
        break label707;
      com.jiayuan.util.a.a("Update", "needCheckUpdate  ");
      new com.jiayuan.a.a(this, this).a();
    }
    while (true)
    {
      Button localButton1 = (Button)findViewById(2131361847);
      c localc = new c(this);
      localButton1.setOnClickListener(localc);
      Button localButton2 = (Button)findViewById(2131361849);
      h localh = new h(this);
      localButton2.setOnClickListener(localh);
      return;
      localObject3 = "LoginActivity";
      localObject1 = "Static.profile=null";
      com.jiayuan.util.a.a((String)localObject3, (String)localObject1);
      break label228:
      label671: localObject3 = "LoginActivity";
      localObject1 = "Static.serviceType=null";
      com.jiayuan.util.a.a((String)localObject3, (String)localObject1);
      break label277:
      label688: this.d.setChecked(i);
      this.e.setChecked(i);
      break label567:
      label707: if ((!bool2) || (((String)localObject2).equalsIgnoreCase("")) || (((String)localObject4).equalsIgnoreCase("")))
        continue;
      e();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.LoginActivity
 * JD-Core Version:    0.5.4
 */