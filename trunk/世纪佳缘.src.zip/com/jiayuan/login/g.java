package com.jiayuan.login;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.system.service.AppUpdateService;

class g
  implements DialogInterface.OnClickListener
{
  g(LoginActivity paramLoginActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    LoginActivity localLoginActivity = this.a;
    Intent localIntent = new Intent(localLoginActivity, AppUpdateService.class);
    String str = LoginActivity.c(this.a);
    localIntent.putExtra("url", str);
    this.a.startService(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.g
 * JD-Core Version:    0.5.4
 */