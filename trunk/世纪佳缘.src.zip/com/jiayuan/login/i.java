package com.jiayuan.login;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.a;

class i
  implements DialogInterface.OnClickListener
{
  i(LoginActivity paramLoginActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.a().b(LoginActivity.class);
    this.a.finish();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.i
 * JD-Core Version:    0.5.4
 */