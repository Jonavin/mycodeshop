package com.jiayuan.login;

import android.content.Context;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class k
  implements q
{
  public static boolean a;
  public a b;
  private String c;
  private String d;

  static
  {
    boolean bool = a;
  }

  public k(a parama, String paramString1, String paramString2)
  {
    this.b = parama;
    this.c = paramString1;
    this.d = paramString2;
  }

  public void a(int paramInt)
  {
    int i = 1;
    com.jiayuan.util.a.a("LoginDataProcessing", "execute()");
    this.b.a();
    Object localObject1 = new StringBuffer("http://api.jiayuan.com/");
    ((StringBuffer)localObject1).append("sign/signon.php?");
    Object localObject3 = ((StringBuffer)localObject1).append("name=");
    String str1 = this.c;
    ((StringBuffer)localObject3).append(str1);
    localObject3 = ((StringBuffer)localObject1).append("&password=");
    String str2 = this.d;
    ((StringBuffer)localObject3).append(str2);
    localObject3 = ((StringBuffer)localObject1).append("&channel=");
    String str3 = o.c();
    ((StringBuffer)localObject3).append(str3);
    localObject3 = ((StringBuffer)localObject1).append("&clientid=");
    String str4 = o.b();
    ((StringBuffer)localObject3).append(str4);
    ((StringBuffer)localObject1).append("&reallogin=").append(paramInt);
    localObject3 = com.jiayuan.a.a().b();
    if (localObject3 != null)
    {
      StringBuffer localStringBuffer1 = ((StringBuffer)localObject1).append("&ver=");
      String str5 = o.c((Context)localObject3);
      localStringBuffer1.append(str5);
      StringBuffer localStringBuffer2 = ((StringBuffer)localObject1).append("&deviceid=");
      String str6 = o.b((Context)localObject3);
      localStringBuffer2.append((String)localObject3);
    }
    if (paramInt == i)
      boolean bool = a;
    monitorenter;
    try
    {
      l locall = new l();
      locall.a = this;
      localObject1 = ((StringBuffer)localObject1).toString();
      locall.b((String)localObject1);
      monitorexit;
      return;
    }
    finally
    {
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
  }

  public void a(int paramInt, String paramString)
  {
    com.jiayuan.util.a.a("LoginDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.b.a(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        com.jiayuan.util.a.a("LoginDataProcessing", str2);
        this.b.b();
        this.b.b(paramString);
        label91: boolean bool = a;
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str3 = localJSONException.toString();
        String str4 = str3;
        com.jiayuan.util.a.a("LoginDataProcessing", str4);
        this.b.d();
        break label91:
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    com.jiayuan.util.a.a("LoginDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    com.jiayuan.util.a.a("LoginDataProcessing", "onCancelled()");
  }

  public void c()
  {
    com.jiayuan.util.a.a("LoginDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.b.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.k
 * JD-Core Version:    0.5.4
 */