package com.jiayuan.login;

import android.view.View;
import android.view.View.OnClickListener;

class c
  implements View.OnClickListener
{
  c(LoginActivity paramLoginActivity)
  {
  }

  public void onClick(View paramView)
  {
    LoginActivity.a(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.c
 * JD-Core Version:    0.5.4
 */