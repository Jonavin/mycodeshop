package com.jiayuan.login;

import org.json.JSONArray;
import org.json.JSONObject;

public abstract interface l
{
  public abstract void a(JSONArray paramJSONArray, int paramInt);

  public abstract void a(JSONObject paramJSONObject);

  public abstract void c(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.login.l
 * JD-Core Version:    0.5.4
 */