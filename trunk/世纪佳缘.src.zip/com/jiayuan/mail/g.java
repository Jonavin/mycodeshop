package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(ad paramad)
  {
  }

  public void onClick(View paramView)
  {
    this.a.a(paramView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.g
 * JD-Core Version:    0.5.4
 */