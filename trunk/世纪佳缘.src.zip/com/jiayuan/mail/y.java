package com.jiayuan.mail;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.util.b;

class y
  implements DialogInterface.OnClickListener
{
  y(ae paramae, int paramInt)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    b.c(ae.b(this.a), "1");
    ae localae = this.a;
    int i = this.b;
    localae.a(i);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.y
 * JD-Core Version:    0.5.4
 */