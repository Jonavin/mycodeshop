package com.jiayuan.mail.detail;

import android.app.Activity;
import android.graphics.Bitmap;
import com.jiayuan.a.ab;
import com.jiayuan.a.b;
import com.jiayuan.a.d;
import com.jiayuan.a.e;
import com.jiayuan.a.f;
import com.jiayuan.a.n;
import com.jiayuan.a.r;
import com.jiayuan.a.x;
import com.jiayuan.util.a;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class ah
  implements ab, b, e, n
{
  public j a;
  private String b;
  private int c;
  private int d;
  private Activity e;

  public ah(j paramj, String paramString, int paramInt1, int paramInt2)
  {
    Activity localActivity = (Activity)paramj;
    this.e = localActivity;
    this.a = paramj;
    this.b = paramString;
    this.c = paramInt1;
    this.d = paramInt2;
  }

  public void a()
  {
    a.a("MailReadDataProcessing", "execute()");
    ArrayList localArrayList = new ArrayList();
    Integer localInteger1 = Integer.valueOf(3);
    localArrayList.add(localInteger1);
    Integer localInteger2 = Integer.valueOf(6);
    localArrayList.add(localInteger2);
    Integer localInteger3 = Integer.valueOf(5);
    localArrayList.add(localInteger3);
    Integer localInteger4 = Integer.valueOf(112);
    localArrayList.add(localInteger4);
    Integer localInteger5 = Integer.valueOf(104);
    localArrayList.add(localInteger5);
    Integer localInteger6 = Integer.valueOf(100);
    localArrayList.add(localInteger6);
    Integer localInteger7 = Integer.valueOf(101);
    localArrayList.add(localInteger7);
    Integer localInteger8 = Integer.valueOf(105);
    localArrayList.add(localInteger8);
    Integer localInteger9 = Integer.valueOf(114);
    localArrayList.add(localInteger9);
    Integer localInteger10 = Integer.valueOf(206);
    localArrayList.add(localInteger10);
    Integer localInteger11 = Integer.valueOf(221);
    localArrayList.add(localInteger11);
    String str1 = this.b;
    int i = d.e;
    new d(this, str1, localArrayList, i).a();
    Activity localActivity = this.e;
    String str2 = this.b;
    new x(this, localActivity, str2).a();
    String str3 = this.b;
    new r(this, str3).a("query");
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a(String paramString1, String paramString2)
  {
    this.a.a(paramString1, paramString2);
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("MailReadDataProcessing", str2);
    this.a.a(paramJSONObject);
    String str3 = "";
    String str4;
    try
    {
      str3 = paramJSONObject.getJSONObject("userinfo").getString("221");
      str4 = str3;
      String str5 = this.b;
      int i = this.c;
      int j = this.d + 12;
      ah localah = this;
      new f(localah, str5, str4, -1, i, j).a();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      str4 = str3;
    }
  }

  public void a_(String paramString)
  {
    this.a.a_(paramString);
  }

  public void b(JSONObject paramJSONObject)
  {
    this.a.b(paramJSONObject);
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ah
 * JD-Core Version:    0.5.4
 */