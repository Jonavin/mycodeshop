package com.jiayuan.mail.detail;

public class k
{
  public String a;
  public String b;
  public String c;
  public String d;
  public String e;
  public String f;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.k
 * JD-Core Version:    0.5.4
 */