package com.jiayuan.mail.detail;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager.BadTokenException;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.a.b;
import com.jiayuan.a.d;
import com.jiayuan.a.r;
import com.jiayuan.profile.ProfileActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.f;
import com.jiayuan.util.s;
import com.jiayuan.util.t;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MailReadActivity extends MyActivity
  implements AdapterView.OnItemClickListener, b, c, e, j
{
  ImageView a;
  EditText b;
  String c;
  private h d;
  private LinearLayout e;
  private ArrayList f;
  private ListView g;
  private i h;
  private ah i;
  private ad j;
  private int k;
  private int l;
  private ProgressDialog m;

  public MailReadActivity()
  {
    String str = com.jiayuan.util.o.l();
    this.c = str;
  }

  private void f()
  {
    int i1 = 1;
    int i2 = 0;
    a.a("MailReadActivity", "Mail send button clicked");
    String str1 = ((EditText)findViewById(2131361878)).getText().toString();
    if (str1.equalsIgnoreCase(""))
      Toast.makeText(this, 2131165671, i2).show();
    while (true)
    {
      return;
      String str2 = getResources().getString(2131165458);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str2);
      this.m = localProgressDialog;
      this.m.setCancelable(i1);
      String str3 = this.d.b;
      String str4 = this.d.a;
      MailReadActivity localMailReadActivity = this;
      new l(localMailReadActivity, str3, "", str1, str4, i1, i2, 3).a();
    }
  }

  private void g()
  {
    a.a("MailReadActivity", "Mail add contact to blacklist button clicked");
    String str1 = this.d.b;
    r localr = new r(this, str1);
    boolean bool = this.d.s;
    if (bool);
    for (String str2 = "delete"; ; str2 = "add")
    {
      localr.a(str2);
      return;
    }
  }

  private void h()
  {
    a.a("MailReadActivity", "updateProfile");
    StringBuilder localStringBuilder1 = new StringBuilder("nickname=");
    String str1 = this.d.e;
    String str2 = str1;
    a.a("MailReadActivity", str2);
    TextView localTextView = (TextView)findViewById(2131361868);
    String str3 = this.d.e;
    localTextView.setText(str3);
    StringBuffer localStringBuffer1 = new StringBuffer("");
    int i1 = this.d.f;
    String str4 = this.d.g;
    int i2 = s.a(i1, str4);
    localStringBuffer1.append(i2);
    Object localObject1 = new StringBuilder("宀");
    int i4 = this.d.h;
    localObject1 = i4;
    localStringBuffer1.append((String)localObject1);
    localObject1 = new StringBuilder("鍘�");
    int i5 = this.d.i;
    String str5 = f.c(this, i5);
    localObject1 = str5;
    localStringBuffer1.append((String)localObject1);
    localObject1 = new StringBuilder();
    int i6 = this.d.j;
    localObject1 = i6;
    localObject1 = t.b(this, (String)localObject1);
    StringBuilder localStringBuilder2 = new StringBuilder();
    int i7 = this.d.k;
    String str6 = i7;
    int i8 = t.b(this, localObject1, str6);
    StringBuilder localStringBuilder3 = new StringBuilder("\n");
    String str7 = t.a(this, localObject1);
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str7);
    localObject1 = t.a(this, localObject1, i8, null);
    localObject1 = (String)localObject1;
    localStringBuffer1.append((String)localObject1);
    ((TextView)findViewById(2131361869)).setText(localStringBuffer1);
    StringBuffer localStringBuffer2 = new StringBuffer("");
    int i3 = this.d.m;
    Object localObject2 = f.h(this, i3);
    localStringBuffer2.append((String)localObject2);
    localObject2 = new StringBuilder("/");
    int i9 = this.d.l;
    String str8 = f.d(this, i9);
    localObject2 = str8;
    localStringBuffer2.append((String)localObject2);
    ((TextView)findViewById(2131361870)).setText(localStringBuffer2);
    localObject2 = (ImageView)findViewById(2131361871);
    switch (this.d.p)
    {
    default:
      label492: localObject2 = new StringBuffer("");
      if (this.d.q == null)
        break label561;
    case 0:
    case 1:
    }
    while (true)
      try
      {
        if (this.d.q.getString("code").equalsIgnoreCase("0"))
        {
          String str9 = s.a(this.d.q.getString("dis"));
          ((StringBuffer)localObject2).append(str9);
          label561: ((TextView)findViewById(2131361872)).setText((CharSequence)localObject2);
          return;
          ((ImageView)localObject2).setBackgroundResource(2130837666);
          break label492:
          ((ImageView)localObject2).setBackgroundResource(2130837667);
        }
        ((StringBuffer)localObject2).append("璺濈�");
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public void a()
  {
  }

  public void a(int paramInt)
  {
    String str = "onGetResult aResult=" + paramInt;
    a.a("MailReadActivity", str);
    switch (paramInt)
    {
    case -126:
    default:
    case 1:
    case -100:
    case -123:
    case -111:
    case -125:
    case -115:
    case -113:
    case -112:
    case -116:
    case -117:
    case -118:
    case -119:
    case -120:
    case -121:
    case -122:
    case -124:
    case -127:
    case -128:
    case -129:
    case -130:
    }
    while (true)
    {
      return;
      b(2131165494);
      continue;
      b(2131165496);
      continue;
      b(2131165497);
      continue;
      b(2131165495);
      continue;
      b(2131165498);
      continue;
      b(2131165502);
      continue;
      b(2131165504);
      continue;
      showDialog(0);
      continue;
      b(2131165506);
      continue;
      b(2131165507);
      continue;
      b(2131165508);
      continue;
      b(2131165509);
      continue;
      b(2131165511);
      continue;
      b(2131165512);
      continue;
      b(2131165501);
      continue;
      b(2131165503);
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    Object localObject = this.d;
    ((h)localObject).o = paramString;
    if (paramBitmap == null)
    {
      a.a("MailReadActivity", "null != bm");
      localObject = com.jiayuan.util.o.i().equals("0");
      if (localObject == 0);
    }
    for (localObject = BitmapFactory.decodeResource(getResources(), 2130837628); ; localObject = paramBitmap)
      while (true)
      {
        Bitmap localBitmap = s.a((Bitmap)localObject, 1084227584);
        this.a.setImageBitmap((Bitmap)localObject);
        return;
        localObject = BitmapFactory.decodeResource(getResources(), 2130837630);
      }
  }

  public void a(String paramString1, String paramString2)
  {
    String str1 = -1;
    int i1 = 1;
    int i2 = 0;
    Object localObject;
    label84: label119: label126: int i5;
    try
    {
      a.a("MailReadActivity", "onGetBlockResult");
      localObject = new JSONObject(paramString2);
      int i3 = ((JSONObject)localObject).getInt("retcode");
      if (!paramString1.equalsIgnoreCase("add"))
        break label194;
      a.a("MailReadActivity", "onGetBlockResult Add");
      if (i1 == i3)
      {
        int i4 = 0;
        localObject = Toast.makeText(this, 2131165532, i4);
        ((Toast)localObject).show();
        finish();
      }
      do
      {
        do
        {
          localObject = (Button)findViewById(2131361880);
          boolean bool = this.d.s;
          if (!bool)
            break label421;
          str2 = getString(2131165527);
          ((Button)localObject).setText(str2);
          return;
        }
        while (str1 != str2);
        localObject = ((JSONObject)localObject).getString("msg");
        String str2 = getString(2131165528);
        localObject = ((String)localObject).equalsIgnoreCase(str2);
      }
      while (localObject == 0);
      i5 = 0;
      localObject = Toast.makeText(this, 2131165530, i5);
      label421: label194: ((Toast)localObject).show();
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      break label126:
      int i6;
      if (paramString1.equalsIgnoreCase("query"))
      {
        a.a("MailReadActivity", "onGetBlockResult Query");
        if (i1 == i5);
        localObject = ((JSONObject)localObject).getJSONObject("uid").getJSONArray("uids");
        for (i5 = i2; ; ++i6)
        {
          int i8 = ((JSONArray)localObject).length();
          if (i5 < i8);
          String str5 = ((JSONArray)localObject).getString(i5);
          String str6 = this.d.b;
          if (!str5.equalsIgnoreCase(str6))
            continue;
          localObject = this.d;
          i6 = 1;
          ((h)localObject).s = i6;
          break label84:
        }
      }
      if (paramString1.equalsIgnoreCase("delete"));
      a.a("MailReadActivity", "onGetBlockResult Delete");
      if (i1 == i6)
      {
        this.d.s = null;
        str3 = 1;
        localObject = Toast.makeText(this, 2131165533, str3);
        ((Toast)localObject).show();
      }
      if (str1 == str3);
      localObject = ((JSONObject)localObject).getString("msg");
      String str3 = getString(2131165529);
      localObject = ((String)localObject).equalsIgnoreCase(str3);
      if (localObject != 0);
      int i7 = 0;
      localObject = Toast.makeText(this, 2131165531, i7);
      ((Toast)localObject).show();
      break label84:
      String str4 = getString(2131165526);
      break label119:
    }
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("MailReadActivity", str2);
    try
    {
      JSONObject localJSONObject = paramJSONObject.getJSONObject("userinfo");
      h localh1 = this.d;
      String str3 = localJSONObject.getString("3");
      localh1.e = str3;
      h localh2 = this.d;
      int i1 = localJSONObject.getInt("6");
      localh2.f = i1;
      h localh3 = this.d;
      String str4 = localJSONObject.getString("5");
      localh3.g = str4;
      h localh4 = this.d;
      int i2 = localJSONObject.getInt("112");
      localh4.h = i2;
      h localh5 = this.d;
      int i3 = localJSONObject.getInt("104");
      localh5.i = i3;
      h localh6 = this.d;
      int i4 = localJSONObject.getInt("100");
      localh6.j = i4;
      h localh7 = this.d;
      int i5 = localJSONObject.getInt("101");
      localh7.k = i5;
      h localh8 = this.d;
      int i6 = localJSONObject.getInt("105");
      localh8.l = i6;
      h localh9 = this.d;
      int i7 = localJSONObject.getInt("114");
      localh9.m = i7;
      h localh10 = this.d;
      int i8 = localJSONObject.getInt("206");
      localh10.p = i8;
      h localh11 = this.d;
      String str5 = localJSONObject.getString("221");
      localh11.o = str5;
      h();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      d();
    }
  }

  public void a_(String paramString)
  {
    this.m.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    this.m.dismiss();
  }

  public void b(int paramInt)
  {
    Toast localToast = Toast.makeText(this, paramInt, 0);
    localToast.setGravity(17, 0, 0);
    localToast.show();
  }

  public void b(JSONObject paramJSONObject)
  {
    this.d.q = paramJSONObject;
    TextView localTextView = (TextView)findViewById(2131361872);
    while (true)
      try
      {
        if (paramJSONObject.getString("code").equalsIgnoreCase("0"))
        {
          int i1 = this.d.p;
          String str1 = String.valueOf(f.p(this, i1));
          StringBuilder localStringBuilder = new StringBuilder(str1).append("/");
          String str2 = s.a(this.d.q.getString("dis"));
          String str3 = str2;
          localTextView.setText(str3);
          return;
        }
        int i2 = this.d.p;
        String str4 = String.valueOf(f.p(this, i2));
        String str5 = str4 + "/" + "璺濈�";
        localTextView.setText(str5);
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public AlertDialog c(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 0:
    }
    while (true)
    {
      return i1;
      Object localObject = new AlertDialog.Builder(this).setTitle(2131165644).setMessage(2131165645);
      m localm = new m(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165482, localm).create();
    }
  }

  public void c()
  {
    a.a("MailReadActivity", "onHeaderButtonClicked");
    Intent localIntent = new Intent();
    Object localObject = this.d.b;
    localIntent.putExtra("uid", (String)localObject);
    String str = "sex";
    localObject = this.c.equals("f");
    if (localObject != 0);
    for (localObject = "m"; ; localObject = "f")
    {
      localIntent.putExtra(str, (String)localObject);
      int i1 = d.c;
      localIntent.putExtra("profileSrc", localObject);
      localIntent.setClass(this, ProfileActivity.class);
      startActivity(localIntent);
      return;
    }
  }

  public void d()
  {
    this.m.dismiss();
  }

  public void e()
  {
    int i1 = 0;
    int i2 = i1;
    int i3 = i1;
    while (true)
    {
      int i4 = this.h.getCount();
      if (i2 >= i4)
      {
        ViewGroup.LayoutParams localLayoutParams = this.g.getLayoutParams();
        int i5 = this.g.getDividerHeight();
        int i6 = this.h.getCount() - 1;
        int i7 = i5 * i6;
        int i8 = i3 + i7;
        localLayoutParams.height = i3;
        int i9 = localLayoutParams.height;
        localLayoutParams.height = (i3 += 5);
        this.g.setLayoutParams(localLayoutParams);
        return;
      }
      i locali = this.h;
      ListView localListView = this.g;
      View localView = locali.getView(i2, null, localListView);
      localView.measure(i1, i1);
      int i10 = localView.getMeasuredHeight();
      i3 += i10;
      ++i2;
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool1 = null;
    super.onCreate(paramBundle);
    setContentView(2130903056);
    Object localObject1 = (EditText)findViewById(2131361878);
    this.b = ((EditText)localObject1);
    localObject1 = getIntent().getExtras();
    Object localObject3 = new h();
    this.d = ((h)localObject3);
    localObject3 = this.d;
    String str2 = ((Bundle)localObject1).getString("msg_id");
    ((h)localObject3).a = str2;
    localObject3 = this.d;
    String str3 = ((Bundle)localObject1).getString("uid");
    ((h)localObject3).b = str3;
    localObject3 = this.d;
    String str4 = ((Bundle)localObject1).getString("send_time");
    ((h)localObject3).c = str4;
    localObject3 = this.d;
    String str5 = ((Bundle)localObject1).getString("content");
    ((h)localObject3).d = str5;
    localObject3 = this.d;
    localObject1 = ((Bundle)localObject1).getString("box_type");
    ((h)localObject3).r = ((String)localObject1);
    this.d.e = "";
    this.d.f = bool1;
    this.d.g = null;
    this.d.h = bool1;
    this.d.i = 10;
    this.d.j = 11;
    this.d.k = 1101;
    this.d.l = 1;
    this.d.m = 10;
    this.d.n = bool1;
    this.d.o = "";
    this.d.p = bool1;
    this.d.q = null;
    this.d.s = bool1;
    localObject3 = new StringBuilder("mData.mUid=");
    String str6 = this.d.b;
    localObject3 = str6;
    a.a("MailReadActivity", (String)localObject3);
    localObject1 = com.jiayuan.util.o.d(this);
    localObject3 = com.jiayuan.util.o.e(this);
    localObject1 /= 4;
    this.k = i1;
    int i1 = (localObject3 - 25 - 25) / 4;
    this.l = i1;
    Object localObject2 = (LinearLayout)findViewById(2131361873);
    this.e = ((LinearLayout)localObject2);
    localObject2 = (ImageView)findViewById(2131361866);
    this.a = ((ImageView)localObject2);
    localObject2 = this.a;
    localObject3 = new p(this);
    ((ImageView)localObject2).setOnClickListener((View.OnClickListener)localObject3);
    localObject2 = this.c;
    label434: Object localObject4;
    if (localObject2 == null)
    {
      localObject2 = getResources();
      int i2 = 2130837632;
      localObject2 = BitmapFactory.decodeResource((Resources)localObject2, i2);
      localObject2 = s.a((Bitmap)localObject2, 1084227584);
      localObject4 = this.a;
      ((ImageView)localObject4).setImageBitmap((Bitmap)localObject2);
    }
    try
    {
      localObject4 = getResources().getString(2131165195);
      localObject2 = ProgressDialog.show(this, "", (CharSequence)localObject4);
      this.m = ((ProgressDialog)localObject2);
      localObject2 = this.m;
      boolean bool2 = true;
      ((ProgressDialog)localObject2).setCancelable(bool2);
      label494: Object localObject5 = this.d.b;
      int i4 = this.k;
      int i5 = this.l;
      localObject2 = new ah(this, (String)localObject5, i4, i5);
      this.i = ((ah)localObject2);
      this.i.a();
      localObject5 = this.d;
      LinearLayout localLinearLayout = this.e;
      localObject2 = new ad(this, (h)localObject5, localLinearLayout);
      this.j = ((ad)localObject2);
      this.j.a();
      localObject2 = (Button)findViewById(2131361879);
      localObject5 = new o(this);
      ((Button)localObject2).setOnClickListener((View.OnClickListener)localObject5);
      localObject2 = (Button)findViewById(2131361880);
      localObject5 = new n(this);
      ((Button)localObject2).setOnClickListener((View.OnClickListener)localObject5);
      boolean bool3 = this.d.s;
      if (bool3);
      String str1;
      for (Object localObject6 = getString(2131165527); ; str1 = getString(2131165526))
      {
        ((Button)localObject2).setText((CharSequence)localObject6);
        localObject2 = new ArrayList();
        this.f = ((ArrayList)localObject2);
        localObject2 = getResources().getStringArray(2131099880);
        localObject6 = bool1;
        int i6 = localObject2.length;
        if (localObject6 < i6)
          break;
        ListView localListView1 = (ListView)findViewById(2131361876);
        this.g = localListView1;
        ArrayList localArrayList1 = this.f;
        i locali1 = new i(this, this, localArrayList1);
        this.h = locali1;
        this.h.setNotifyOnChange(bool1);
        ListView localListView2 = this.g;
        i locali2 = this.h;
        localListView2.setAdapter(locali2);
        this.g.setOnItemClickListener(this);
        e();
        return;
        localObject2 = this.c;
        localObject6 = "m";
        localObject2 = ((String)localObject2).equals(localObject6);
        if (localObject2 != 0)
        {
          localObject2 = getResources();
          i3 = 2130837629;
          localObject2 = BitmapFactory.decodeResource((Resources)localObject2, i3);
        }
        localObject2 = getResources();
        int i3 = 2130837631;
        localObject2 = BitmapFactory.decodeResource((Resources)localObject2, i3);
        break label434:
      }
      ArrayList localArrayList2 = this.f;
      Object localObject7 = localObject2[str1];
      localArrayList2.add(localObject7);
      ++str1;
    }
    catch (Exception localException)
    {
      break label494:
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
      break label494:
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder("position=").append(paramInt);
    String str1 = (String)this.f.get(paramInt);
    String str2 = str1;
    a.a("MailReadActivity", str2);
    String str3 = (String)this.f.get(paramInt);
    this.b.setText(str3);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.MailReadActivity
 * JD-Core Version:    0.5.4
 */