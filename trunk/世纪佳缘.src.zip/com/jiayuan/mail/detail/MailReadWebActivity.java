package com.jiayuan.mail.detail;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.jiayuan.MyActivity;
import com.jiayuan.a.b;
import com.jiayuan.util.a;
import org.json.JSONObject;

public class MailReadWebActivity extends MyActivity
  implements AdapterView.OnItemClickListener, b, c, e, j
{
  private h a;

  public void a()
  {
  }

  public void a(int paramInt)
  {
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
  }

  public void a(String paramString1, String paramString2)
  {
  }

  public void a(JSONObject paramJSONObject)
  {
  }

  public void a_(String paramString)
  {
  }

  public void b()
  {
  }

  public void b(JSONObject paramJSONObject)
  {
  }

  public void d()
  {
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903057);
    Bundle localBundle = getIntent().getExtras();
    h localh1 = new h();
    this.a = localh1;
    h localh2 = this.a;
    String str1 = localBundle.getString("msg_id");
    localh2.a = str1;
    h localh3 = this.a;
    String str2 = localBundle.getString("uid");
    localh3.b = str2;
    h localh4 = this.a;
    String str3 = localBundle.getString("send_time");
    localh4.c = str3;
    h localh5 = this.a;
    String str4 = localBundle.getString("content");
    localh5.d = str4;
    h localh6 = this.a;
    String str5 = localBundle.getString("box_type");
    localh6.r = str5;
    WebView localWebView = (WebView)findViewById(2131361881);
    WebSettings localWebSettings = localWebView.getSettings();
    localWebSettings.setDefaultTextEncodingName("utf-8");
    localWebSettings.setAllowFileAccess(true);
    localWebSettings.setJavaScriptEnabled(true);
    localWebSettings.setBuiltInZoomControls(null);
    localWebSettings.setSupportZoom(true);
    localWebView.setInitialScale(0);
    h localh7 = this.a;
    String str6 = Uri.encode(this.a.d);
    localh7.d = str6;
    String str7 = this.a.d;
    localWebView.loadData(str7, "text/html", "utf-8");
    String str8 = this.a.d;
    a.a("MailReadWebActivity", str8);
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
  }

  public void onStart()
  {
    super.onStart();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.MailReadWebActivity
 * JD-Core Version:    0.5.4
 */