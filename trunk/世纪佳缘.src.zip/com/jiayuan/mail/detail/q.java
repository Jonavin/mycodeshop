package com.jiayuan.mail.detail;

import android.widget.TextView;

final class q
{
  TextView a;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.q
 * JD-Core Version:    0.5.4
 */