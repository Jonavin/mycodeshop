package com.jiayuan.mail.detail;

import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class ag
  implements q
{
  public b a;
  private int b;
  private String c;
  private String d;

  public ag(b paramb, int paramInt, String paramString1, String paramString2)
  {
    this.a = paramb;
    this.b = paramInt;
    this.c = paramString1;
    this.d = paramString2;
  }

  public void a()
  {
    a.a("MailReadPreDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/showmsg.php?");
    localStringBuffer.append("uid=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&msg_id=");
    String str2 = this.c;
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    localStringBuffer.append("&boxtype=");
    String str4 = this.d;
    localStringBuffer.append(str4);
    localStringBuffer.append("&clientid=");
    String str5 = o.b();
    localStringBuffer.append(str5);
    l locall = new l();
    locall.a = this;
    String str6 = localStringBuffer.toString();
    locall.b(str6);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("MailReadPreDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      try
      {
        if (!new JSONObject(paramString).has("msg_id"))
          break label118;
        b localb1 = this.a;
        int i = this.b;
        localb1.a(i, 1, paramString);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("MailReadPreDataProcessing", str2);
        this.a.d();
      }
      continue;
      label118: b localb2 = this.a;
      int j = this.b;
      localb2.a(j, 0, paramString);
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailReadPreDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MailReadPreDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailReadPreDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ag
 * JD-Core Version:    0.5.4
 */