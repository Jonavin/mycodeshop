package com.jiayuan.mail.detail;

public abstract interface b
{
  public abstract void a();

  public abstract void a(int paramInt1, int paramInt2, String paramString);

  public abstract void a_(String paramString);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.b
 * JD-Core Version:    0.5.4
 */