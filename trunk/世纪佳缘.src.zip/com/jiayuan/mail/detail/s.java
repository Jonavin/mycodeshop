package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class s
  implements View.OnClickListener
{
  s(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailSendActivity.a(this.a, 0);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.s
 * JD-Core Version:    0.5.4
 */