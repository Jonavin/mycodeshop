package com.jiayuan.mail.detail;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class ae extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  ae(MailSendActivity paramMailSendActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903062, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    d locald = (d)paramView.getTag();
    paramView.setTag(locald);
    TextView localTextView = locald.a;
    CharSequence localCharSequence = (CharSequence)MailSendActivity.a(this.b).get(paramInt);
    localTextView.setText(this);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903062, paramViewGroup, null);
      d locald = new d(null);
      localObject = (TextView)localView.findViewById(2131361914);
      locald.a = ((TextView)localObject);
      localView.setTag(locald);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    d locald = (d)((View)paramView.getTag()).getTag();
    a.a("MailSendActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ae
 * JD-Core Version:    0.5.4
 */