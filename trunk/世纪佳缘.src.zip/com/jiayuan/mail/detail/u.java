package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class u
  implements View.OnClickListener
{
  u(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailSendActivity.a(this.a, 2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.u
 * JD-Core Version:    0.5.4
 */