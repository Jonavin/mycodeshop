package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class v
  implements View.OnClickListener
{
  v(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailSendActivity.a(this.a, 1);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.v
 * JD-Core Version:    0.5.4
 */