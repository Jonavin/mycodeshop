package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class t
  implements View.OnClickListener
{
  t(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailSendActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.t
 * JD-Core Version:    0.5.4
 */