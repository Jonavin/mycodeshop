package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class n
  implements View.OnClickListener
{
  n(MailReadActivity paramMailReadActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailReadActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.n
 * JD-Core Version:    0.5.4
 */