package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;
import java.util.ArrayList;

class ab
  implements View.OnClickListener
{
  ab(ad paramad)
  {
  }

  public void onClick(View paramView)
  {
    ad localad = this.a;
    ArrayList localArrayList = this.a.b;
    ad.a(localad, localArrayList);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ab
 * JD-Core Version:    0.5.4
 */