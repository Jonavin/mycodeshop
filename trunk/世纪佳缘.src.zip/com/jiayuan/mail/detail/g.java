package com.jiayuan.mail.detail;

import android.content.Context;
import android.telephony.TelephonyManager;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;

public class g
  implements q
{
  af a;
  Context b;
  TelephonyManager c;

  public g(af paramaf)
  {
    this.a = paramaf;
    Context localContext = (Context)paramaf;
    this.b = paramaf;
    TelephonyManager localTelephonyManager = (TelephonyManager)this.b.getSystemService("phone");
    this.c = localTelephonyManager;
  }

  public void a()
  {
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/other.php?");
    localStringBuffer.append("uid=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&token=");
    String str2 = o.f();
    localStringBuffer.append(str2);
    localStringBuffer.append("&act=new");
    localStringBuffer.append("&mobile=");
    String str3 = this.c.getLine1Number();
    localStringBuffer.append(str3);
    localStringBuffer.append("&clientid=");
    String str4 = o.b();
    localStringBuffer.append(str4);
    l locall = new l();
    locall.a = this;
    String str5 = localStringBuffer.toString();
    locall.b(str5);
  }

  public void a(int paramInt, String paramString)
  {
    String str = "successful=" + paramInt + "result=" + paramString;
    a.a("UnreadMailCountProcessing", str);
    boolean bool = paramString.equalsIgnoreCase("NETWORK_ERROR");
    if (bool)
      this.a.b();
    while (true)
    {
      return;
      try
      {
        int i = Integer.parseInt(paramString);
        label61: this.a.b(i);
      }
      catch (NumberFormatException localNumberFormatException)
      {
        localNumberFormatException.printStackTrace();
        int j = 0;
        break label61:
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.g
 * JD-Core Version:    0.5.4
 */