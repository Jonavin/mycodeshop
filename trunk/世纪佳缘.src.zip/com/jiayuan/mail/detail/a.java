package com.jiayuan.mail.detail;

import android.content.Context;
import com.jiayuan.util.b;

public class a
{
  private Context a;

  public a(Context paramContext)
  {
    this.a = paramContext;
  }

  public int a(String paramString)
  {
    int i = 0;
    Context localContext1 = 1;
    com.jiayuan.util.a.a("MailSendPreDataProcessing", "SaveTemplate()");
    boolean bool = paramString.equalsIgnoreCase("");
    if (bool);
    Context localContext2;
    for (int j = -1; ; localContext2 = localContext1)
    {
      return j;
      localContext2 = this.a;
      String str1 = b.a(this.a, localContext1);
      b.a(localContext2, 2, str1);
      localContext2 = this.a;
      String str2 = b.a(this.a, i);
      b.a(localContext2, localContext1, str2);
      b.a(this.a, i, paramString);
    }
  }

  public String a(int paramInt)
  {
    String str1 = "MailSendPreDataProcessing";
    com.jiayuan.util.a.a(str1, "getTemplate()");
    if (paramInt >= 0)
    {
      int i = 2;
      if (paramInt <= i)
        break label25;
    }
    label25: for (String str2 = ""; ; str2 = b.a(this.a, paramInt))
      return str2;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.a
 * JD-Core Version:    0.5.4
 */