package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class r
  implements View.OnClickListener
{
  r(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailSendActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.r
 * JD-Core Version:    0.5.4
 */