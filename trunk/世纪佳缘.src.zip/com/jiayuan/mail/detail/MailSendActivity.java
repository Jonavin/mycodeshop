package com.jiayuan.mail.detail;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager.BadTokenException;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.service.ServiceActivity;
import com.jiayuan.util.b;
import java.util.ArrayList;
import java.util.List;

public class MailSendActivity extends MyActivity
  implements AdapterView.OnItemClickListener, ac, e
{
  CheckBox a;
  ProgressDialog b;
  TableLayout c;
  private Context d = this;
  private int e = 1;
  private String f;
  private String g;
  private ArrayList h;
  private ListView i;
  private ae j;
  private int k;

  private void c()
  {
    Object localObject1 = 0;
    Object localObject2 = (Button)findViewById(2131361899);
    Object localObject3 = new s(this);
    ((Button)localObject2).setOnClickListener((View.OnClickListener)localObject3);
    localObject3 = (Button)findViewById(2131361900);
    Object localObject4 = new v(this);
    ((Button)localObject3).setOnClickListener((View.OnClickListener)localObject4);
    localObject4 = (Button)findViewById(2131361901);
    Object localObject6 = new u(this);
    ((Button)localObject4).setOnClickListener((View.OnClickListener)localObject6);
    localObject6 = new ArrayList();
    ((ArrayList)localObject6).add(localObject2);
    ((ArrayList)localObject6).add(localObject3);
    ((ArrayList)localObject6).add(localObject4);
    localObject2 = new ArrayList();
    localObject3 = localObject1;
    Object localObject5 = 3;
    if (localObject3 >= localObject5);
    for (localObject3 = localObject1; ; ++localObject3)
    {
      int l = ((ArrayList)localObject2).size();
      if (localObject3 >= l)
      {
        return;
        localObject5 = b.a(this, localObject3);
        if ((localObject5 != null) && (!((String)localObject5).equals("")))
          ((ArrayList)localObject2).add(localObject5);
        ++localObject3;
      }
      ((Button)((ArrayList)localObject6).get(localObject3)).setVisibility(localObject1);
    }
  }

  private void e()
  {
    int l = 1;
    com.jiayuan.util.a.a("MailSendActivity", "Save template button clicked");
    EditText localEditText = (EditText)findViewById(2131361895);
    a locala = new a(this);
    String str = localEditText.getText().toString();
    if (locala.a(str) == l)
      Toast.makeText(this, 2131165500, l).show();
    c();
  }

  private void e(int paramInt)
  {
    com.jiayuan.util.a.a("MailSendActivity", "Get template button clicked");
    String str = new a(this).a(paramInt);
    ((EditText)findViewById(2131361895)).setText(str);
  }

  private void f()
  {
    int l = 1;
    int i1 = 0;
    com.jiayuan.util.a.a("MailSendActivity", "Mail send button clicked");
    String str1 = ((EditText)findViewById(2131361895)).getText().toString();
    if (str1.equalsIgnoreCase(""))
      Toast.makeText(this, 2131165671, i1).show();
    while (true)
    {
      return;
      int i2 = this.e;
      boolean bool;
      if (l == i2)
        bool = this.a.isChecked();
      try
      {
        label70: String str2 = getResources().getString(2131165458);
        ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str2);
        this.b = localProgressDialog;
        this.b.setCancelable(true);
        label105: String str3 = this.f;
        int i3 = this.e;
        int i4 = this.k;
        MailSendActivity localMailSendActivity = this;
        new l(localMailSendActivity, str3, "NO_SUBJECT", str1, "NO_REPLY_MSG_ID", i3, bool, i4).a();
      }
      catch (Exception localException)
      {
        break label105:
      }
      catch (WindowManager.BadTokenException localBadTokenException)
      {
        break label105:
        bool = i1;
        break label70:
      }
    }
  }

  public void a()
  {
    com.jiayuan.util.a.a("MailSendActivity", "onWaitingActivityStart");
  }

  public void a(int paramInt)
  {
    String str = "onGetResult aResult=" + paramInt;
    com.jiayuan.util.a.a("MailSendActivity", str);
    this.b.dismiss();
    switch (paramInt)
    {
    default:
    case 1:
    case -100:
    case -123:
    case -111:
    case -125:
    case -115:
    case -113:
    case -112:
    case -116:
    case -117:
    case -118:
    case -119:
    case -120:
    case -121:
    case -122:
    case -124:
    case -126:
    case -127:
    case -128:
    case -129:
    case -130:
    }
    while (true)
    {
      return;
      d(2131165494);
      continue;
      d(2131165496);
      continue;
      d(2131165497);
      continue;
      d(2131165495);
      continue;
      d(2131165498);
      continue;
      d(2131165502);
      continue;
      d(2131165504);
      continue;
      showDialog(0);
      continue;
      d(2131165506);
      continue;
      d(2131165507);
      continue;
      d(2131165508);
      continue;
      d(2131165509);
      continue;
      showDialog(2);
      continue;
      d(2131165511);
      continue;
      d(2131165512);
      continue;
      d(2131165501);
      continue;
      d(2131165503);
    }
  }

  public void a_(String paramString)
  {
    if (this.b != null)
      this.b.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    com.jiayuan.util.a.a("MailSendActivity", "onWaitingActivityFinish");
  }

  public void b(int paramInt)
  {
    int l = 0;
    String str = "onGetResult aResult=" + paramInt;
    com.jiayuan.util.a.a("MailSendActivity", str);
    this.e = paramInt;
    CheckBox localCheckBox = (CheckBox)findViewById(2131361903);
    if (paramInt == 0)
      this.c.setVisibility(8);
    while (true)
    {
      return;
      if (1 == paramInt)
        this.c.setVisibility(l);
      if (2 == paramInt)
        this.c.setVisibility(l);
      if (65417 == paramInt)
        showDialog(l);
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this).setTitle(2131165480).setMessage(2131165481);
      x localx = new x(this);
      localBuilder.setPositiveButton(2131165482, localx).create().show();
    }
  }

  public AlertDialog c(int paramInt)
  {
    int l;
    switch (paramInt)
    {
    case 1:
    default:
      l = 0;
    case 0:
    case 2:
    }
    while (true)
    {
      return l;
      Object localObject = new AlertDialog.Builder(this).setTitle(2131165644).setMessage(2131165645);
      w localw = new w(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165482, localw).create();
      continue;
      localObject = new AlertDialog.Builder(this).setTitle(2131165543).setMessage(2131165646);
      z localz = new z(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165467, localz);
      y localy = new y(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165546, localy).create();
    }
  }

  public void d()
  {
    if (this.b == null)
      return;
    this.b.dismiss();
  }

  public void d(int paramInt)
  {
    Toast localToast = Toast.makeText(this, paramInt, 0);
    localToast.setGravity(17, 0, 0);
    localToast.show();
  }

  public void onCreate(Bundle paramBundle)
  {
    Object localObject1 = 0;
    super.onCreate(paramBundle);
    setContentView(2130903060);
    Object localObject2 = (TableLayout)findViewById(2131361902);
    this.c = ((TableLayout)localObject2);
    localObject2 = getIntent().getExtras();
    Object localObject3 = ((Bundle)localObject2).getString("to_id");
    this.f = ((String)localObject3);
    localObject3 = ((Bundle)localObject2).getString("nickname");
    this.g = ((String)localObject3);
    localObject2 = ((Bundle)localObject2).getInt("src");
    this.k = localObject2;
    localObject3 = new StringBuilder("nickname=");
    String str1 = this.g;
    localObject3 = str1;
    com.jiayuan.util.a.a("MailSendActivity", (String)localObject3);
    localObject2 = (TextView)findViewById(2131361893);
    localObject3 = this.g;
    ((TextView)localObject2).setText((CharSequence)localObject3);
    localObject2 = (CheckBox)findViewById(2131361903);
    this.a = ((CheckBox)localObject2);
    localObject2 = (TextView)findViewById(2131361893);
    localObject3 = this.g;
    ((TextView)localObject2).setText((CharSequence)localObject3);
    localObject2 = (Button)findViewById(2131361896);
    localObject3 = new r(this);
    ((Button)localObject2).setOnClickListener((View.OnClickListener)localObject3);
    localObject2 = (Button)findViewById(2131361898);
    localObject3 = new t(this);
    ((Button)localObject2).setOnClickListener((View.OnClickListener)localObject3);
    c();
    localObject2 = new ArrayList();
    this.h = ((ArrayList)localObject2);
    localObject2 = getResources().getStringArray(2131099879);
    localObject3 = localObject1;
    Object localObject4 = localObject2.length;
    if (localObject3 >= localObject4)
    {
      localObject2 = (ListView)findViewById(2131361907);
      this.i = ((ListView)localObject2);
      localObject3 = this.h;
      localObject2 = new ae(this, this, (List)localObject3);
      this.j = ((ae)localObject2);
      this.j.setNotifyOnChange(localObject1);
      localObject2 = this.i;
      localObject3 = this.j;
      ((ListView)localObject2).setAdapter((ListAdapter)localObject3);
      this.i.setOnItemClickListener(this);
      localObject2 = localObject1;
      localObject3 = localObject1;
    }
    while (true)
    {
      int i1 = this.j.getCount();
      if (localObject2 >= i1)
      {
        ViewGroup.LayoutParams localLayoutParams = this.i.getLayoutParams();
        int i2 = this.i.getDividerHeight();
        int i3 = this.j.getCount() - 1;
        Object localObject5 = i2 * i3;
        int i4 = localObject3 + localObject5;
        localLayoutParams.height = localObject3;
        int i5 = localLayoutParams.height;
        localLayoutParams.height = (localObject3 += 5);
        this.i.setLayoutParams(localLayoutParams);
        String str2 = this.f;
        new f(this, (String)localObject3).a();
        return;
        ArrayList localArrayList = this.h;
        Object localObject6 = localObject2[localObject3];
        localArrayList.add(localObject6);
        ++localObject3;
      }
      ae localae = this.j;
      ListView localListView = this.i;
      View localView = localae.getView(localObject2, null, localListView);
      localView.measure(localObject1, localObject1);
      int i6 = localView.getMeasuredHeight();
      int l;
      localObject3 += i6;
      ++localObject2;
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131296263, paramMenu);
    return true;
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("MailSendActivity", str);
    EditText localEditText = (EditText)findViewById(2131361895);
    CharSequence localCharSequence = (CharSequence)this.h.get(paramInt);
    localEditText.setText(this);
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default:
    case 2131362259:
    }
    while (true)
    {
      return true;
      com.jiayuan.a locala = com.jiayuan.a.a();
      locala.b(MainActivity.class);
      MainActivity localMainActivity = (MainActivity)locala.d(MainActivity.class);
      localMainActivity.a(3);
      ServiceActivity localServiceActivity = (ServiceActivity)localMainActivity.getCurrentActivity();
      int l = ServiceActivity.b;
      localServiceActivity.a(l);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.MailSendActivity
 * JD-Core Version:    0.5.4
 */