package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class aa
  implements View.OnClickListener
{
  aa(ad paramad)
  {
  }

  public void onClick(View paramView)
  {
    ad localad = this.a;
    h localh = ad.a(this.a);
    ad.a(localad, localh);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.aa
 * JD-Core Version:    0.5.4
 */