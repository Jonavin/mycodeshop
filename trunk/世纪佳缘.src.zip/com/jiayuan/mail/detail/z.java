package com.jiayuan.mail.detail;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.mail.other.SmsPay;

class z
  implements DialogInterface.OnClickListener
{
  z(MailSendActivity paramMailSendActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    Context localContext = MailSendActivity.d(this.a);
    Intent localIntent = new Intent(localContext, SmsPay.class);
    MailSendActivity.d(this.a).startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.z
 * JD-Core Version:    0.5.4
 */