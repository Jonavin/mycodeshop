package com.jiayuan.mail.detail;

import android.app.Activity;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class f
  implements q
{
  public ac a;
  private String b;
  private Activity c;

  public f(ac paramac, String paramString)
  {
    Activity localActivity = (Activity)paramac;
    this.c = localActivity;
    this.a = paramac;
    this.b = paramString;
  }

  public void a()
  {
    a.a("MailSendPreDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/send.php?");
    localStringBuffer.append("&from=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&to=");
    String str2 = this.b;
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    l locall = new l();
    locall.a = this;
    String str4 = localStringBuffer.toString();
    locall.b(str4);
  }

  public void a(int paramInt, String paramString)
  {
    a.a("MailSendPreDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      this.a.b();
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        ac localac = this.a;
        int i = localJSONObject.getInt("retcode");
        localac.b(i);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("MailSendPreDataProcessing", str2);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailSendPreDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MailSendPreDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailSendPreDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.f
 * JD-Core Version:    0.5.4
 */