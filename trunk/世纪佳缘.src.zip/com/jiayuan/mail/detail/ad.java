package com.jiayuan.mail.detail;

import android.app.Activity;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ad
  implements q
{
  public c a;
  public ArrayList b;
  public boolean c = null;
  private String d;
  private LinearLayout e;
  private boolean f = null;
  private Activity g;
  private h h;

  public ad(c paramc, h paramh, LinearLayout paramLinearLayout)
  {
    Activity localActivity = (Activity)paramc;
    this.g = localActivity;
    this.e = paramLinearLayout;
    this.a = paramc;
    this.h = paramh;
    String str = paramh.b;
    this.d = str;
  }

  private View a(String paramString)
  {
    ViewGroup localViewGroup = null;
    Object localObject = o.e();
    localObject = paramString.equals(localObject);
    if (localObject != 0);
    for (localObject = this.g.getLayoutInflater().inflate(2130903053, localViewGroup); ; localObject = this.g.getLayoutInflater().inflate(2130903052, localViewGroup))
      return localObject;
  }

  private void a(h paramh)
  {
    this.e.removeAllViews();
    String str1;
    if (paramh.r.equals("outbox"))
      str1 = o.e();
    String str3;
    for (View localView = a(str1); ; localView = a(str3))
    {
      TextView localTextView1 = (TextView)localView.findViewById(2131361854);
      TextView localTextView2 = (TextView)localView.findViewById(2131361855);
      Button localButton = (Button)localView.findViewById(2131361852);
      Spanned localSpanned = Html.fromHtml(Html.fromHtml(paramh.d).toString());
      localTextView1.setText(localSpanned);
      Date localDate = new Date();
      long l1 = Integer.parseInt(paramh.c);
      long l2 = 1000L * l1;
      localDate.setTime(l2);
      String str2 = localDate.toLocaleString();
      localTextView2.setText(str2);
      localButton.setVisibility(0);
      localButton.setBackgroundResource(2130837623);
      ab localab = new ab(this);
      localButton.setOnClickListener(localab);
      this.e.addView(localView);
      return;
      str3 = paramh.b;
    }
  }

  private void a(List paramList)
  {
    int i = 0;
    this.e.removeAllViews();
    LinearLayout localLinearLayout = this.e;
    int j = 1;
    localLinearLayout.setOrientation(j);
    if ((paramList == null) || (paramList.size() == 0))
      return;
    int k = paramList.size();
    Object localObject2 = "data.size=";
    Object localObject1 = (String)localObject2 + k;
    a.a("MailReadChatDataProcessing", (String)localObject1);
    int l = i;
    while (true)
    {
      if (l < k);
      k localk = (k)paramList.get(l);
      localObject1 = localk.a;
      View localView = a((String)localObject1);
      localObject1 = (TextView)localView.findViewById(2131361854);
      localObject2 = (TextView)localView.findViewById(2131361855);
      Button localButton = (Button)localView.findViewById(2131361852);
      localButton.setBackgroundResource(2130837620);
      Spanned localSpanned = Html.fromHtml(Html.fromHtml(localk.e).toString());
      ((TextView)localObject1).setText(localSpanned);
      localObject1 = new Date();
      long l1 = 1000L;
      try
      {
        long l2 = Integer.parseInt(((k)paramList.get(l)).c);
        long l3 = l1 * l2;
        ((Date)localObject1).setTime(l1);
        String str = ((Date)localObject1).toLocaleString();
        ((TextView)localObject2).setText(str);
        if (l == 0)
        {
          label243: localButton.setVisibility(i);
          aa localaa = new aa(this);
          localButton.setOnClickListener(localaa);
        }
        Integer localInteger = Integer.valueOf(l);
        localView.setTag(localInteger);
        this.e.addView(localView);
        l += 1;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        ((TextView)localObject2).setText("");
        break label243:
      }
    }
  }

  public void a()
  {
    a.a("MailReadChatDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/chat.php?");
    localStringBuffer.append("uid=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&another_uid=");
    String str2 = this.d;
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    l locall = new l();
    locall.a = this;
    String str4 = localStringBuffer.toString();
    locall.b(str4);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject = "MailReadChatDataProcessing";
    String str1 = "onPostExecute()";
    a.a((String)localObject, str1);
    label37: int i;
    try
    {
      localObject = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject != 0)
      {
        this.a.a_("NETWORK_ERROR");
        return;
      }
      localObject = new ArrayList();
      this.b = ((ArrayList)localObject);
      localObject = new JSONArray(paramString);
      i = 0;
      label63: int j = ((JSONArray)localObject).length();
      if (i < j)
        break label157;
      this.c = true;
      this.a.b();
      h localh = this.h;
      label157: a(localh);
    }
    catch (JSONException localJSONException)
    {
      this.a.d();
      StringBuilder localStringBuilder1 = new StringBuilder("JSONException");
      String str2 = localJSONException.toString();
      String str3 = str2;
      a.a("MailReadChatDataProcessing", str3);
      break label37:
      k localk = new k();
      String str4 = ((JSONArray)localObject).getJSONObject(i).getString("from_uid");
      localk.a = str4;
      String str5 = ((JSONArray)localObject).getJSONObject(i).getString("to_uid");
      localk.b = str5;
      String str6 = ((JSONArray)localObject).getJSONObject(i).getString("send_time");
      localk.c = str6;
      String str7 = ((JSONArray)localObject).getJSONObject(i).getString("subject");
      localk.d = str7;
      String str8 = ((JSONArray)localObject).getJSONObject(i).getString("content");
      localk.e = str8;
      String str9 = ((JSONArray)localObject).getJSONObject(i).getString("to_status");
      localk.f = str9;
      this.b.add(localk);
      StringBuilder localStringBuilder2 = new StringBuilder("cell.from_uid=");
      String str10 = localk.a;
      String str11 = str10;
      a.a("MailReadChatDataProcessing", str11);
      StringBuilder localStringBuilder3 = new StringBuilder("cell.to_uid=");
      String str12 = localk.b;
      String str13 = str12;
      a.a("MailReadChatDataProcessing", str13);
      StringBuilder localStringBuilder4 = new StringBuilder("cell.send_time=");
      String str14 = localk.c;
      String str15 = str14;
      a.a("MailReadChatDataProcessing", str15);
      ++i;
      break label63:
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailReadChatDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MailReadChatDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailReadChatDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ad
 * JD-Core Version:    0.5.4
 */