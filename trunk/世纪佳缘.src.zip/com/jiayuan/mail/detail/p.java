package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class p
  implements View.OnClickListener
{
  p(MailReadActivity paramMailReadActivity)
  {
  }

  public void onClick(View paramView)
  {
    this.a.c();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.p
 * JD-Core Version:    0.5.4
 */