package com.jiayuan.mail.detail;

import org.json.JSONObject;

public class h
{
  public String a;
  public String b;
  public String c;
  public String d;
  public String e;
  public int f;
  public String g;
  public int h;
  public int i;
  public int j;
  public int k;
  public int l;
  public int m;
  public int n;
  public String o;
  public int p;
  public JSONObject q;
  public String r;
  public boolean s;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.h
 * JD-Core Version:    0.5.4
 */