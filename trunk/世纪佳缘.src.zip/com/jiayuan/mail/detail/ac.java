package com.jiayuan.mail.detail;

public abstract interface ac
{
  public abstract void a();

  public abstract void a_(String paramString);

  public abstract void b();

  public abstract void b(int paramInt);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.ac
 * JD-Core Version:    0.5.4
 */