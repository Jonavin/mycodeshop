package com.jiayuan.mail.detail;

import android.app.Activity;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class l
  implements q
{
  public e a;
  private String b;
  private String c;
  private String d;
  private String e;
  private String f = "0";
  private String g = "0";
  private Activity h;
  private int i;

  public l(e parame, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    Activity localActivity = (Activity)parame;
    this.h = localActivity;
    this.a = parame;
    this.i = paramInt2;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramString4;
    if (paramInt1 == 0)
      this.f = "0";
    for (this.g = "0"; ; this.g = "1")
    {
      do
        while (true)
        {
          return;
          if (1 != paramInt1)
            break;
          if (paramBoolean)
          {
            this.f = "1";
            this.g = "0";
          }
          this.f = "0";
          this.g = "0";
        }
      while (2 != paramInt1);
      this.f = "1";
    }
  }

  public void a()
  {
    a.a("MailSendDataProcessing", "execute()");
    Object localObject = this.a;
    ((e)localObject).a();
    try
    {
      localObject = new StringBuffer("http://api.jiayuan.com/");
      ((StringBuffer)localObject).append("msg/dosend.php?");
      ((StringBuffer)localObject).append("from=");
      String str1 = o.e();
      ((StringBuffer)localObject).append(str1);
      ((StringBuffer)localObject).append("&to=");
      String str2 = this.b;
      ((StringBuffer)localObject).append(str2);
      ((StringBuffer)localObject).append("&subject=");
      String str3 = this.c;
      ((StringBuffer)localObject).append(str3);
      ((StringBuffer)localObject).append("&content=");
      String str4 = URLEncoder.encode(this.d, "UTF-8");
      ((StringBuffer)localObject).append(str4);
      ((StringBuffer)localObject).append("&reply_msg_id=");
      ((StringBuffer)localObject).append("");
      ((StringBuffer)localObject).append("&reply_send_time=");
      long l = System.currentTimeMillis() / 1000L;
      ((StringBuffer)localObject).append(l);
      ((StringBuffer)localObject).append("&token=");
      String str5 = o.f();
      ((StringBuffer)localObject).append(str5);
      ((StringBuffer)localObject).append("&self_pay=");
      String str6 = this.f;
      ((StringBuffer)localObject).append(str6);
      ((StringBuffer)localObject).append("&fxbc=");
      String str7 = this.g;
      ((StringBuffer)localObject).append(str7);
      if (!this.e.equalsIgnoreCase("NO_REPLY_MSG_ID"))
      {
        ((StringBuffer)localObject).append("&reply_msg_id=");
        String str8 = this.e;
        ((StringBuffer)localObject).append(str8);
      }
      ((StringBuffer)localObject).append("&clientid=");
      String str9 = o.b();
      ((StringBuffer)localObject).append(str9);
      ((StringBuffer)localObject).append("&src=");
      int j = this.i;
      ((StringBuffer)localObject).append(j);
      com.jiayuan.a.l locall = new com.jiayuan.a.l();
      locall.a = this;
      String str10 = ((StringBuffer)localObject).toString();
      locall.b((String)localObject);
      return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      localUnsupportedEncodingException.printStackTrace();
    }
  }

  public void a(int paramInt, String paramString)
  {
    a.a("MailSendDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.a_(paramString);
    while (true)
    {
      return;
      if (paramString.equalsIgnoreCase(""))
        this.a.a(-1);
      this.a.b();
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        e locale = this.a;
        int j = localJSONObject.getInt("retcode");
        locale.a(j);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder = new StringBuilder("JSONException");
        String str1 = localJSONException.toString();
        String str2 = str1;
        a.a("MailSendDataProcessing", str2);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailSendDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MailSendDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailSendDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.l
 * JD-Core Version:    0.5.4
 */