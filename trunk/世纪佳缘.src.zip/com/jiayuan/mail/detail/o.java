package com.jiayuan.mail.detail;

import android.view.View;
import android.view.View.OnClickListener;

class o
  implements View.OnClickListener
{
  o(MailReadActivity paramMailReadActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailReadActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.o
 * JD-Core Version:    0.5.4
 */