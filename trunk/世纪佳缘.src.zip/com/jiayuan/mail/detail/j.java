package com.jiayuan.mail.detail;

import android.graphics.Bitmap;
import org.json.JSONObject;

public abstract interface j
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a(String paramString1, String paramString2);

  public abstract void a(JSONObject paramJSONObject);

  public abstract void a_(String paramString);

  public abstract void b(JSONObject paramJSONObject);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.j
 * JD-Core Version:    0.5.4
 */