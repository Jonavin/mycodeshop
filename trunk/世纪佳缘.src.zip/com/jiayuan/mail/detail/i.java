package com.jiayuan.mail.detail;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class i extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  i(MailReadActivity paramMailReadActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903058, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    a.a("MailReadActivity", "MRQuickReplyListAdapter bindView");
    q localq = (q)paramView.getTag();
    paramView.setTag(localq);
    TextView localTextView = localq.a;
    CharSequence localCharSequence = (CharSequence)MailReadActivity.a(this.b).get(paramInt);
    localTextView.setText(this);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903058, paramViewGroup, null);
      q localq = new q(null);
      localObject = (TextView)localView.findViewById(2131361882);
      localq.a = ((TextView)localObject);
      localView.setTag(localq);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    q localq = (q)((View)paramView.getTag()).getTag();
    a.a("MailReadActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.detail.i
 * JD-Core Version:    0.5.4
 */