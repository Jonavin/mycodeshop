package com.jiayuan.mail;

public abstract interface h
{
  public abstract void a();

  public abstract void a(String paramString);

  public abstract void b_();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.h
 * JD-Core Version:    0.5.4
 */