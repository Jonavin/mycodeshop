package com.jiayuan.mail;

import com.jiayuan.a.l;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class v
  implements com.jiayuan.a.q
{
  public q a;
  private List b;
  private String c;
  private boolean d;
  private int e = null;

  public v(q paramq, String paramString, boolean paramBoolean, ArrayList paramArrayList)
  {
    this.a = paramq;
    this.c = paramString;
    this.d = paramBoolean;
    this.b = paramArrayList;
  }

  public void a()
  {
    a.a("MailDeleteDataProcessing", "execute()");
    int i = 0;
    while (true)
    {
      int j = this.b.size();
      if (i >= j)
        return;
      Object localObject = new StringBuffer("http://api.jiayuan.com/");
      ((StringBuffer)localObject).append("msg/deletemsg.php?");
      ((StringBuffer)localObject).append("uid=");
      String str1 = o.e();
      ((StringBuffer)localObject).append(str1);
      ((StringBuffer)localObject).append("&boxtype=");
      String str2 = this.c;
      ((StringBuffer)localObject).append(str2);
      ((StringBuffer)localObject).append("&msg_id=");
      String str3 = (String)this.b.get(i);
      ((StringBuffer)localObject).append(str3);
      ((StringBuffer)localObject).append("&token=");
      String str4 = o.f();
      ((StringBuffer)localObject).append(str4);
      if (this.d)
      {
        ((StringBuffer)localObject).append("&adm=");
        ((StringBuffer)localObject).append("1");
      }
      l locall = new l();
      locall.a = this;
      localObject = ((StringBuffer)localObject).toString();
      locall.b((String)localObject);
      i += 1;
    }
  }

  public void a(int paramInt, String paramString)
  {
    a.a("MailDeleteDataProcessing", "onPostExecute()");
    if (paramString.equalsIgnoreCase("NETWORK_ERROR"))
      this.a.a_("NETWORK_ERROR");
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        int i = this.e;
        int j;
        ++j;
        this.e = i;
        int k = this.b.size();
        int l = this.e;
        if (k == l);
        this.a.i();
      }
      catch (JSONException localJSONException)
      {
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailDeleteDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("MailDeleteDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailDeleteDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.v
 * JD-Core Version:    0.5.4
 */