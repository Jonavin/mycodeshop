package com.jiayuan.mail;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.mail.detail.MailReadActivity;
import com.jiayuan.mail.detail.MailReadWebActivity;
import com.jiayuan.mail.detail.ag;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ak
  implements AdapterView.OnItemClickListener, com.jiayuan.a.q, com.jiayuan.mail.detail.b, q
{
  public aq a;
  private String b;
  private ArrayList c;
  private ArrayList d;
  private ArrayList e;
  private int f = 1;
  private int g = 10;
  private Activity h;
  private ListView i;
  private ai j;
  private boolean k = null;

  public ak(aq paramaq, ListView paramListView)
  {
    Activity localActivity = (Activity)paramaq;
    this.h = localActivity;
    this.i = paramListView;
    this.a = paramaq;
    String str = o.e();
    this.b = str;
    ArrayList localArrayList = new ArrayList();
    this.c = localArrayList;
    f();
    e();
  }

  private void l()
  {
    a.a("MailRecvAllDataProcessing", "loadRemainListItem loadRemainListItem");
    int l = this.f;
    int i1;
    ++i1;
    this.f = l;
    int i2 = this.f;
    int i3 = this.g;
    a(i2, i3);
  }

  public void a()
  {
  }

  public void a(int paramInt)
  {
    a.a("MailRecvAllDataProcessing", "doPreReadForMail");
    this.a.d();
    String str = ((af)this.c.get(paramInt)).a;
    new ag(this, paramInt, str, "inbox").a();
  }

  public void a(int paramInt1, int paramInt2)
  {
    int l = 1;
    a.a("MailRecvAllDataProcessing", "execute()");
    if (this.k)
    {
      int i1 = this.f - l;
      this.f = i1;
      Toast.makeText(this.h, 2131165472, l).show();
    }
    while (true)
    {
      return;
      this.f = paramInt1;
      this.g = paramInt2;
      this.a.a();
      StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer.append("msg/list.php?");
      localStringBuffer.append("uid=");
      String str1 = o.e();
      localStringBuffer.append(str1);
      localStringBuffer.append("&token=");
      String str2 = o.f();
      localStringBuffer.append(str2);
      localStringBuffer.append("&p=");
      int i2 = this.f;
      localStringBuffer.append(i2);
      localStringBuffer.append("&page_size=");
      int i3 = this.g;
      localStringBuffer.append(i3);
      localStringBuffer.append("&boxtype=");
      localStringBuffer.append("inbox");
      com.jiayuan.a.l locall = new com.jiayuan.a.l();
      locall.a = this;
      String str3 = localStringBuffer.toString();
      locall.b(str3);
    }
  }

  public void a(int paramInt1, int paramInt2, String paramString)
  {
    int l = 1;
    Object localObject = this.a;
    ((aq)localObject).e();
    if (l == paramInt2)
    {
      localObject = "MailRecvAllDataProcessing";
      String str1 = "Goto mail read activity, position=" + paramInt1 + ", sResult=" + paramString;
      a.a((String)localObject, str1);
    }
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      localObject = (af)this.c.get(paramInt1);
      String str2 = localJSONObject.getString("content");
      ((af)localObject).i = str2;
      localObject = new Intent();
      String str3 = localJSONObject.getString("msg_id");
      ((Intent)localObject).putExtra("msg_id", str3);
      String str4 = localJSONObject.getString("from_uid");
      ((Intent)localObject).putExtra("uid", str4);
      ((Intent)localObject).putExtra("box_type", "inbox");
      String str5 = localJSONObject.getString("send_time");
      ((Intent)localObject).putExtra("send_time", str5);
      String str6 = localJSONObject.getString("content");
      ((Intent)localObject).putExtra("content", str6);
      if (s.b(localJSONObject.getString("from_uid")))
      {
        Activity localActivity1 = this.h;
        ((Intent)localObject).setClass(localActivity1, MailReadWebActivity.class);
        this.h.startActivity((Intent)localObject);
        this.a.f();
        if (((af)this.c.get(paramInt1)).c == 0)
        {
          if (o.h > 0)
            label241: o.h -= l;
          ((af)this.c.get(paramInt1)).c = l;
          ((af)this.c.get(paramInt1)).h = "1";
          this.a.f();
          this.j.notifyDataSetChanged();
        }
        return;
      }
      Activity localActivity2 = this.h;
      ((Intent)localObject).setClass(localActivity2, MailReadActivity.class);
    }
    catch (JSONException localJSONException1)
    {
      while (true)
      {
        this.a.c();
        localJSONException1.printStackTrace();
        break label241:
        if (paramInt2 == 0);
        try
        {
          int i1 = new JSONObject(paramString).getInt("retcode");
          if (-1 == i1);
          a.a("MailRecvAllDataProcessing", "-8 == aResult");
          Activity localActivity3 = this.h;
          AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity3).setTitle(2131165465).setMessage(2131165466);
          n localn = new n(this);
          AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165467, localn);
          m localm = new m(this);
          localBuilder2.setNegativeButton(2131165469, localm).create().show();
        }
        catch (JSONException localJSONException2)
        {
          localJSONException2.printStackTrace();
          this.a.c();
        }
      }
    }
  }

  public void a(int paramInt, String paramString)
  {
    int l = 1;
    Object localObject1 = 0;
    Object localObject2 = "MailRecvAllDataProcessing";
    a.a((String)localObject2, paramString);
    label63: Object localObject3;
    try
    {
      localObject2 = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject2 != 0)
      {
        a.a("MailRecvAllDataProcessing", "Get NETWORK_ERROR");
        int i1 = this.f - l;
        this.f = i1;
        this.a.a("NETWORK_ERROR");
        return;
      }
      localObject2 = new ArrayList();
      this.d = ((ArrayList)localObject2);
      localObject2 = new ArrayList();
      this.e = ((ArrayList)localObject2);
      localObject3 = new StringBuilder("str.length()=");
      int i2 = paramString.length();
      localObject3 = i2;
      a.a("MailRecvAllDataProcessing", (String)localObject3);
      localObject2 = new JSONArray(paramString);
      localObject3 = ((JSONArray)localObject2).length();
      if (localObject3 != 0)
        break label249;
      int i3 = this.f - l;
      this.f = i3;
      this.k = true;
      Toast.makeText(this.h, 2131165472, 1).show();
      label249: this.a.b_();
    }
    catch (JSONException localJSONException)
    {
      StringBuilder localStringBuilder1 = new StringBuilder("JSONException");
      String str1 = localJSONException.toString();
      String str2 = str1;
      a.a("MailRecvAllDataProcessing", str2);
      this.a.c();
      break label63:
      for (localObject3 = localObject1; ; ++localObject3)
      {
        int i4 = ((JSONArray)localObject2).length();
        if (localObject3 >= i4)
        {
          this.a.b_();
          this.j.notifyDataSetChanged();
        }
        StringBuilder localStringBuilder2 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").toString()=");
        String str3 = ((JSONArray)localObject2).getJSONObject(localObject3).toString();
        String str4 = str3;
        a.a("MailRecvAllDataProcessing", str4);
        StringBuilder localStringBuilder3 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").getString(\"read_free\")=");
        String str5 = ((JSONArray)localObject2).getJSONObject(localObject3).getString("read_free");
        String str6 = str5;
        a.a("MailRecvAllDataProcessing", str6);
        af localaf = new af();
        JSONObject localJSONObject = ((JSONArray)localObject2).getJSONObject(localObject3);
        String str7 = localJSONObject.getString("from_uid");
        localaf.b = str7;
        String str8 = localJSONObject.getString("msg_id");
        localaf.a = str8;
        String str9 = localJSONObject.getString("subject");
        localaf.d = str9;
        int i5 = localJSONObject.getInt("to_status");
        localaf.c = i5;
        String str10 = localJSONObject.getString("user_info_nickname");
        localaf.g = str10;
        String str11 = localJSONObject.getString("user_info_detail");
        localaf.f = str11;
        String str12 = localJSONObject.getString("read_free");
        localaf.h = str12;
        int i6 = localJSONObject.getInt("rude_type");
        localaf.e = i6;
        localaf.j = null;
        localaf.k = 1;
        localaf.l = null;
        localaf.m = 10;
        localaf.o = 10;
        localaf.n = 170;
        localaf.p = null;
        localaf.q = null;
        this.c.add(localaf);
        ArrayList localArrayList = this.d;
        String str13 = localJSONObject.getString("from_uid");
        localArrayList.add(str13);
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailRecvAllDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    a.a("MailRecvAllDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailRecvAllDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    ListView localListView1 = this.i;
    j localj = new j(this);
    localListView1.setOnScrollListener(localj);
    ListView localListView2 = this.i;
    i locali = new i(this);
    localListView2.setOnItemSelectedListener(locali);
  }

  public void f()
  {
    Activity localActivity = this.h;
    ArrayList localArrayList = this.c;
    ai localai1 = new ai(this, localActivity, localArrayList);
    this.j = localai1;
    this.j.setNotifyOnChange(null);
    ListView localListView = this.i;
    ai localai2 = this.j;
    localListView.setAdapter(localai2);
    this.i.setOnItemClickListener(this);
  }

  public void g()
  {
    int l = 0;
    while (true)
    {
      int i1 = this.c.size();
      if (l >= i1)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((af)this.c.get(l)).q = true;
      l += 1;
    }
  }

  public void h()
  {
    int l = 1;
    ArrayList localArrayList = new ArrayList();
    int i1 = this.c.size() - l;
    while (true)
    {
      if (i1 < 0)
      {
        this.j.notifyDataSetChanged();
        this.a.f();
        new v(this, "inbox", null, localArrayList).a();
        return;
      }
      if (((af)this.c.get(i1)).q)
      {
        String str = ((af)this.c.get(i1)).a;
        localArrayList.add(str);
        this.c.remove(i1);
        if (o.h > 0)
          o.h -= l;
      }
      i1 += -1;
    }
  }

  public void i()
  {
    j();
  }

  public void j()
  {
    if (this.c != null)
      this.c.clear();
    if (this.d != null)
      this.d.clear();
    if (this.e != null)
      this.e.clear();
    this.f = 1;
    int l = this.f;
    int i1 = this.g;
    a(l, i1);
  }

  public void k()
  {
    int l = 0;
    int i1 = l;
    while (true)
    {
      int i2 = this.c.size();
      if (i1 >= i2)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((af)this.c.get(i1)).q = l;
      i1 += 1;
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str = "position=" + paramInt;
    a.a("MailRecvAllDataProcessing", str);
    if (((af)this.c.get(paramInt)).h.equalsIgnoreCase("1"))
      a(paramInt);
    while (true)
    {
      return;
      if (com.jiayuan.util.b.j(this.h).equalsIgnoreCase("1"))
        a(paramInt);
      Activity localActivity = this.h;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity).setTitle(2131165459).setMessage(2131165460);
      l locall = new l(this);
      AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165591, locall);
      k localk = new k(this, paramInt);
      localBuilder2.setNegativeButton(2131165454, localk).create().show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ak
 * JD-Core Version:    0.5.4
 */