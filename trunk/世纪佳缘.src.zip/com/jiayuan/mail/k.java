package com.jiayuan.mail;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.util.b;

class k
  implements DialogInterface.OnClickListener
{
  k(ak paramak, int paramInt)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    b.c(ak.b(this.a), "1");
    ak localak = this.a;
    int i = this.b;
    localak.a(i);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.k
 * JD-Core Version:    0.5.4
 */