package com.jiayuan.mail;

public class ar
{
  public String a;
  public String b;
  public String c;
  public String d;
  public int e;
  public boolean f;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ar
 * JD-Core Version:    0.5.4
 */