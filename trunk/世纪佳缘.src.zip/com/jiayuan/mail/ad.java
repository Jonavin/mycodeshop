package com.jiayuan.mail;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class ad extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  ad(o paramo, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903061, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView)
  {
    int i = Integer.parseInt(paramView.getTag().toString());
    String str = "position=" + i;
    a.a("MailSendedDataProcessing", str);
    as localas = (as)o.a(this.b).get(i);
    boolean bool = ((as)o.a(this.b).get(i)).q;
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      localas.q = localObject;
      return;
      int j = 1;
    }
  }

  public void a(View paramView, int paramInt)
  {
    int i = 2130837672;
    int j = 0;
    r localr = (r)paramView.getTag();
    localr.f = paramInt;
    paramView.setTag(localr);
    if (((as)o.a(this.b).get(paramInt)).q)
    {
      localr.a.setChecked(true);
      switch (((as)o.a(this.b).get(paramInt)).c)
      {
      default:
        switch (((as)o.a(this.b).get(paramInt)).e)
        {
        default:
          label56: label100: localr.c.setImageResource(i);
          localr.c.setVisibility(8);
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
      case 0:
      case 1:
      case 2:
      }
    }
    while (true)
    {
      TextView localTextView1 = localr.d;
      String str1 = ((as)o.a(this.b).get(paramInt)).f;
      localTextView1.setText(str1);
      TextView localTextView2 = localr.e;
      String str2 = ((as)o.a(this.b).get(paramInt)).g;
      localr.setText(str2);
      return;
      localr.a.setChecked(j);
      break label56:
      localr.b.setImageResource(2130837655);
      break label100:
      localr.b.setImageResource(2130837651);
      break label100:
      localr.b.setImageResource(2130837652);
      break label100:
      localr.c.setVisibility(j);
      localr.c.setImageResource(2130837665);
      continue;
      localr.c.setVisibility(j);
      localr.c.setImageResource(2130837653);
      continue;
      localr.c.setVisibility(j);
      localr.c.setImageResource(2130837671);
      continue;
      localr.c.setVisibility(j);
      localr.c.setImageResource(2130837650);
      continue;
      localr.c.setVisibility(j);
      localr.c.setImageResource(i);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903061, paramViewGroup, null);
      r localr = new r(null);
      CheckBox localCheckBox1 = (CheckBox)localView.findViewById(2131361908);
      localr.a = localCheckBox1;
      ImageView localImageView1 = (ImageView)localView.findViewById(2131361909);
      localr.b = localImageView1;
      ImageView localImageView2 = (ImageView)localView.findViewById(2131361911);
      localr.c = localImageView2;
      TextView localTextView1 = (TextView)localView.findViewById(2131361913);
      localr.d = localTextView1;
      TextView localTextView2 = (TextView)localView.findViewById(2131361912);
      localr.e = localTextView2;
      localView.setTag(localr);
    }
    while (true)
    {
      CheckBox localCheckBox2 = ((r)localView.getTag()).a;
      Integer localInteger = Integer.valueOf(paramInt);
      localCheckBox2.setTag(localInteger);
      CheckBox localCheckBox3 = ((r)localView.getTag()).a;
      g localg = new g(this);
      localCheckBox3.setOnClickListener(localg);
      a(localView, paramInt);
      return localView;
      localView = paramView;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    r localr = (r)((View)paramView.getTag()).getTag();
    a.a("MailSendedDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ad
 * JD-Core Version:    0.5.4
 */