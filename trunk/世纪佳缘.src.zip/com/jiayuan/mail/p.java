package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class p
  implements View.OnClickListener
{
  p(f paramf)
  {
  }

  public void onClick(View paramView)
  {
    this.a.a(paramView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.p
 * JD-Core Version:    0.5.4
 */