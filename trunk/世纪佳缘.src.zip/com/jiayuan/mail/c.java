package com.jiayuan.mail;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.MainActivity;
import com.jiayuan.service.ServiceActivity;

class c
  implements DialogInterface.OnClickListener
{
  c(at paramat)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    com.jiayuan.util.a.a("MailSystemDataProcessing", "who_looked_me_buy");
    MainActivity localMainActivity = (MainActivity)com.jiayuan.a.a().d(MainActivity.class);
    localMainActivity.a(3);
    ServiceActivity localServiceActivity = (ServiceActivity)localMainActivity.getCurrentActivity();
    int i = ServiceActivity.b;
    localServiceActivity.a(i);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.c
 * JD-Core Version:    0.5.4
 */