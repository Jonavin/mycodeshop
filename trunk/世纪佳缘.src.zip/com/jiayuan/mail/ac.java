package com.jiayuan.mail;

public abstract interface ac
{
  public abstract void a();

  public abstract void a(String paramString);

  public abstract void b_();

  public abstract void c();

  public abstract void d();

  public abstract void e();

  public abstract void f();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ac
 * JD-Core Version:    0.5.4
 */