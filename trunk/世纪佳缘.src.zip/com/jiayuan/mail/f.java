package com.jiayuan.mail;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class f extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  f(at paramat, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903063, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView)
  {
    int i = Integer.parseInt(paramView.getTag().toString());
    String str = "position=" + i;
    a.a("MailSystemDataProcessing", str);
    ar localar = (ar)at.a(this.b).get(i);
    boolean bool = ((ar)at.a(this.b).get(i)).f;
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      localar.f = localObject;
      return;
      int j = 1;
    }
  }

  public void a(View paramView, int paramInt)
  {
    int i = 1;
    int j = 0;
    s locals = (s)paramView.getTag();
    locals.e = paramInt;
    paramView.setTag(locals);
    if (((ar)at.a(this.b).get(paramInt)).f)
    {
      locals.a.setChecked(i);
      label55: if ((paramInt != 0) && (i != paramInt))
        break label220;
      a.a("MailSystemDataProcessing", "GONE GONE GONE");
      locals.a.setVisibility(8);
      locals.b.setPadding(9, j, j, j);
      label97: switch (((ar)at.a(this.b).get(paramInt)).e)
      {
      default:
      case 0:
      case 1:
      case 2:
      }
    }
    while (true)
    {
      TextView localTextView1 = locals.c;
      String str1 = ((ar)at.a(this.b).get(paramInt)).b;
      localTextView1.setText(str1);
      TextView localTextView2 = locals.d;
      String str2 = ((ar)at.a(this.b).get(paramInt)).d;
      locals.setText(str2);
      return;
      locals.a.setChecked(j);
      break label55:
      label220: locals.a.setVisibility(j);
      locals.b.setPadding(j, j, j, j);
      break label97:
      locals.b.setImageResource(2130837655);
      continue;
      locals.b.setImageResource(2130837651);
      continue;
      locals.b.setImageResource(2130837652);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903063, paramViewGroup, null);
      s locals = new s(null);
      CheckBox localCheckBox1 = (CheckBox)localView.findViewById(2131361915);
      locals.a = localCheckBox1;
      ImageView localImageView = (ImageView)localView.findViewById(2131361916);
      locals.b = localImageView;
      TextView localTextView1 = (TextView)localView.findViewById(2131361920);
      locals.c = localTextView1;
      TextView localTextView2 = (TextView)localView.findViewById(2131361919);
      locals.d = localTextView2;
      localView.setTag(locals);
    }
    while (true)
    {
      CheckBox localCheckBox2 = ((s)localView.getTag()).a;
      Integer localInteger = Integer.valueOf(paramInt);
      localCheckBox2.setTag(localInteger);
      CheckBox localCheckBox3 = ((s)localView.getTag()).a;
      p localp = new p(this);
      localCheckBox3.setOnClickListener(localp);
      a(localView, paramInt);
      return localView;
      localView = paramView;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    s locals = (s)((View)paramView.getTag()).getTag();
    a.a("MailSystemDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.f
 * JD-Core Version:    0.5.4
 */