package com.jiayuan.mail;

public class ab
{
  public String a;
  public String b;
  public int c;
  public String d;
  public int e;
  public String f;
  public String g;
  public String h;
  public String i;
  public int j;
  public int k;
  public int l;
  public int m;
  public int n;
  public int o;
  public int p;
  public boolean q;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ab
 * JD-Core Version:    0.5.4
 */