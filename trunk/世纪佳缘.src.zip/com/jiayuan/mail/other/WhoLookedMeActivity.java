package com.jiayuan.mail.other;

import android.app.ProgressDialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.WindowManager.BadTokenException;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.o;

public class WhoLookedMeActivity extends MyActivity
  implements d
{
  ProgressDialog a;
  private ListView b;

  public void a()
  {
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.a = localProgressDialog;
      this.a.setCancelable(true);
      a.a("WhoLookedMeActivity", "---------onWaitingActivityStart()---------");
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void a(String paramString)
  {
    this.a.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    this.a.dismiss();
    a.a("WhoLookedMeActivity", "---------onWaitingActivityFinish()---------");
  }

  public void c()
  {
    this.a.dismiss();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903113);
    ListView localListView1 = (ListView)findViewById(2131362234);
    this.b = localListView1;
    int i = o.d(this);
    int j = o.e(this);
    int k = i / 2;
    int l = j / 2;
    ListView localListView2 = this.b;
    new c(this, localListView2, k, l).a();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.WhoLookedMeActivity
 * JD-Core Version:    0.5.4
 */