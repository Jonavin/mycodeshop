package com.jiayuan.mail.other;

import android.widget.ImageView;
import android.widget.TextView;

final class b
{
  ImageView a;
  ImageView b;
  TextView c;
  TextView d;
  TextView e;
  TextView f;
  TextView g;
  TextView h;
  int i;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.b
 * JD-Core Version:    0.5.4
 */