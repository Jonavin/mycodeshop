package com.jiayuan.mail.other;

import org.json.JSONArray;

public class n
{
  public String a;
  public String b;
  public int c;
  public String d;
  public int e;
  public String f;
  public int g;
  public int h;
  public int i;
  public String j;
  public JSONArray k;
  public String l;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.n
 * JD-Core Version:    0.5.4
 */