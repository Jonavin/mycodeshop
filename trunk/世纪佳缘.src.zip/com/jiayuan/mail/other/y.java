package com.jiayuan.mail.other;

import com.jiayuan.a.q;
import com.jiayuan.a.s;
import com.jiayuan.util.o;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class y
  implements q
{
  final String a = "SendAllDataProcessing";
  q b;
  JSONObject c;

  public y(q paramq)
  {
    this.b = paramq;
  }

  public void a(int paramInt, String paramString)
  {
    com.jiayuan.util.a.a("SendAllDataProcessing", paramString);
    this.b.a(paramInt, paramString);
  }

  public void a(ArrayList paramArrayList)
  {
    int i = 2;
    int j = 0;
    StringBuffer localStringBuffer1 = new StringBuffer();
    localStringBuffer1.append("{");
    int k = paramArrayList.size();
    int l = j;
    if (l >= k)
      localStringBuffer1.append("}");
    try
    {
      JSONObject localJSONObject1 = new JSONObject();
      this.c = localJSONObject1;
      JSONObject localJSONObject2 = this.c;
      String str1 = o.a;
      localJSONObject2.put("from", str1);
      JSONObject localJSONObject3 = this.c;
      String str2 = o.f();
      localJSONObject3.put("token", str2);
      JSONObject localJSONObject4 = this.c;
      String str3 = localStringBuffer1.toString();
      localJSONObject4.put("to", str3);
      JSONObject localJSONObject5 = this.c;
      String str4 = o.b();
      localJSONObject5.put("clientid", str4);
      this.c.put("src", 2);
      label157: String str5 = localStringBuffer1.toString();
      com.jiayuan.util.a.a("SendAllDataProcessing", localStringBuffer1);
      s locals = new s();
      locals.a = this;
      StringBuffer localStringBuffer2 = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer1.append("msg/dosend_more.php?");
      Object[] arrayOfObject = new Object[3];
      String str6 = localStringBuffer1.toString();
      arrayOfObject[j] = localStringBuffer1;
      String str7 = this.c.toString();
      arrayOfObject[1] = str7;
      arrayOfObject[i] = null;
      locals.execute(arrayOfObject);
      return;
      if (l == 0)
      {
        localStringBuffer1.append(l);
        localStringBuffer1.append(":'");
        String str8 = ((a)paramArrayList.get(l)).a;
        localStringBuffer1.append(str8);
        localStringBuffer1.append("'");
        l += 1;
      }
      localStringBuffer1.append(",");
      localStringBuffer1.append(l);
      localStringBuffer1.append(":'");
      String str9 = ((a)paramArrayList.get(l)).a;
      localStringBuffer1.append(str9);
      localStringBuffer1.append("'");
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      break label157:
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.y
 * JD-Core Version:    0.5.4
 */