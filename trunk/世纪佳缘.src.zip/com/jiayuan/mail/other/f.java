package com.jiayuan.mail.other;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.a.c;
import com.jiayuan.a.l;
import com.jiayuan.a.n;
import com.jiayuan.a.q;
import com.jiayuan.profile.ProfileActivity;
import com.jiayuan.util.b;
import com.jiayuan.util.o;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class f
  implements AdapterView.OnItemClickListener, c, n, q
{
  public t a;
  private ArrayList b;
  private ArrayList c;
  private ArrayList d;
  private int e;
  private int f;
  private Activity g;
  private ListView h;
  private h i;
  private Button j;
  private ProgressDialog k;

  public f(t paramt, ListView paramListView, Button paramButton, int paramInt1, int paramInt2)
  {
    Activity localActivity = (Activity)paramt;
    this.g = localActivity;
    this.h = paramListView;
    this.a = paramt;
    this.j = paramButton;
    this.e = paramInt1;
    this.f = paramInt2;
  }

  private void g()
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "loadRemainListItem loadRemainListItem");
  }

  public void a()
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api2.jiayuan.com/geo/");
    localStringBuffer.append("notifynew.php?");
    localStringBuffer.append("uid=");
    String str1 = o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&maxDis=");
    float f1 = b.h(this.g);
    localStringBuffer.append(f1);
    localStringBuffer.append("&token=");
    String str2 = o.f();
    localStringBuffer.append(str2);
    l locall = new l();
    locall.a = this;
    String str3 = localStringBuffer.toString();
    locall.b(str3);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject1 = 0;
    Object localObject2 = "onPostExecute()";
    Object localObject3 = (String)localObject2 + paramString;
    com.jiayuan.util.a.a("LocationDataProcessing", (String)localObject3);
    Object localObject4 = this.k;
    if (localObject4 != null)
    {
      localObject4 = this.k.isShowing();
      if (localObject4 != 0)
      {
        localObject4 = this.k;
        ((ProgressDialog)localObject4).dismiss();
      }
    }
    try
    {
      localObject4 = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject4 != 0)
      {
        com.jiayuan.util.a.a("LocationDataProcessing", "Get NETWORK_ERROR");
        this.a.a(paramString);
        label97: return;
      }
      localObject4 = paramString.indexOf("sucnum");
      if (localObject4 <= 0)
        break label229;
      JSONObject localJSONObject1 = new JSONObject(paramString);
      Activity localActivity = this.g;
      StringBuilder localStringBuilder1 = new StringBuilder("鍙戦");
      int i2 = localJSONObject1.getInt("sucnum");
      String str1 = i2 + "灏�";
      label321: label726: label229: label758: Toast.makeText(localActivity, str1, 1).show();
    }
    catch (JSONException localJSONException2)
    {
      StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
      String str2 = localJSONException2.toString();
      String str3 = str2;
      com.jiayuan.util.a.a("LocationDataProcessing", str3);
      this.a.c();
      break label97:
      localObject4 = new ArrayList();
      this.b = ((ArrayList)localObject4);
      localObject4 = new JSONObject(paramString);
      localObject3 = ((JSONObject)localObject4).getJSONObject("node");
      localObject2 = ((JSONObject)localObject3).keys();
      while (true)
      {
        localObject4 = ((Iterator)localObject2).hasNext();
        if (localObject4 == 0)
        {
          localObject4 = new x(this);
          Collections.sort(this.b, (Comparator)localObject4);
          localObject4 = new ArrayList();
          this.c = ((ArrayList)localObject4);
          localObject3 = localObject1;
          localObject4 = this.b.size();
          if (localObject3 < localObject4)
            break label758;
          this.a.b();
          e();
          this.j.setEnabled(true);
          Button localButton = this.j;
          i locali = new i(this);
          localButton.setOnClickListener(locali);
          int i3 = localObject1;
          while (true)
          {
            int i4 = this.b.size();
            if (i3 < i4);
            String str4 = ((a)this.b.get(i3)).a;
            String str5 = ((a)this.b.get(i3)).m;
            int i5 = this.e;
            int i6 = this.f;
            f localf = this;
            new com.jiayuan.a.f(localf, str4, str5, i3, i5, i6).a();
            i3 += 1;
          }
        }
        localObject4 = (String)((Iterator)localObject2).next();
        JSONObject localJSONObject2 = ((JSONObject)localObject3).getJSONObject((String)localObject4);
        a locala = new a();
        locala.a = ((String)localObject4);
        try
        {
          localObject4 = localJSONObject2.getString("3");
          locala.b = ((String)localObject4);
          localObject4 = localJSONObject2.getString("112");
          locala.d = ((String)localObject4);
          localObject4 = localJSONObject2.getInt("6");
          locala.e = localObject4;
          localObject4 = localJSONObject2.getInt("104");
          locala.f = localObject4;
          localObject4 = localJSONObject2.getInt("100");
          locala.g = localObject4;
          localObject4 = localJSONObject2.getInt("101");
          locala.h = localObject4;
          localObject4 = localJSONObject2.getString("intimate");
          locala.j = ((String)localObject4);
          localObject4 = localJSONObject2.getJSONArray("service");
          locala.l = ((JSONArray)localObject4);
          localObject4 = localJSONObject2.getString("221");
          locala.m = ((String)localObject4);
          long l1 = localJSONObject2.getLong("ts");
          Object localObject5;
          locala.i = localObject5;
          localObject4 = String.valueOf(2);
          localObject4 = localJSONObject2.getString((String)localObject4);
          locala.k = ((String)localObject4);
          localObject4 = localJSONObject2.getInt("114");
          locala.c = localObject4;
          localObject4 = this.b;
          ((ArrayList)localObject4).add(locala);
        }
        catch (JSONException localInputStream)
        {
          int i1 = 1;
          locala.c = i1;
          break label726:
          boolean bool = ((a)this.b.get(localObject3)).k.equals("f");
          if (bool);
          for (InputStream localInputStream = this.g.getResources().openRawResource(2130837629); ; localInputStream = this.g.getResources().openRawResource(2130837631))
          {
            Bitmap localBitmap = BitmapFactory.decodeStream(localInputStream);
            this.c.add(localInputStream);
            int l;
            localObject3 += 1;
            break label321:
          }
        }
      }
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    if (paramBitmap == null)
    {
      boolean bool = ((a)this.b.get(paramInt)).k.equals("f");
      if (!bool);
    }
    for (Bitmap localBitmap = BitmapFactory.decodeResource(this.g.getResources(), 2130837628); ; localBitmap = paramBitmap)
      while (true)
      {
        this.c.set(paramInt, localBitmap);
        ((a)this.b.get(paramInt)).m = paramString;
        this.i.notifyDataSetChanged();
        return;
        localBitmap = BitmapFactory.decodeResource(this.g.getResources(), 2130837630);
      }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    ((a)this.b.get(paramInt)).l = paramJSONArray;
    this.i.notifyDataSetChanged();
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "onCancelled()");
  }

  public void c()
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    Activity localActivity = this.g;
    ArrayList localArrayList = this.b;
    h localh1 = new h(this, localActivity, localArrayList);
    this.i = localh1;
    this.i.setNotifyOnChange(null);
    ListView localListView1 = this.h;
    h localh2 = this.i;
    localListView1.setAdapter(localh2);
    this.h.setOnItemClickListener(this);
    ListView localListView2 = this.h;
    j localj = new j(this);
    localListView2.setOnScrollListener(localj);
    ListView localListView3 = this.h;
    k localk = new k(this);
    localListView3.setOnItemSelectedListener(localk);
    this.i.notifyDataSetChanged();
  }

  // ERROR //
  public void f()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: iconst_1
    //   3: istore_2
    //   4: getstatic 410	com/jiayuan/util/o:a	Ljava/lang/String;
    //   7: astore_3
    //   8: aload_3
    //   9: ifnull +23 -> 32
    //   12: getstatic 410	com/jiayuan/util/o:a	Ljava/lang/String;
    //   15: astore_3
    //   16: ldc_w 412
    //   19: astore 4
    //   21: aload_3
    //   22: aload 4
    //   24: invokevirtual 328	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   27: astore_3
    //   28: iload_3
    //   29: ifeq +33 -> 62
    //   32: aload_0
    //   33: getfield 40	com/jiayuan/mail/other/f:g	Landroid/app/Activity;
    //   36: astore 5
    //   38: new 414	android/content/Intent
    //   41: dup
    //   42: aload 5
    //   44: ldc_w 416
    //   47: invokespecial 419	android/content/Intent:<init>	(Landroid/content/Context;Ljava/lang/Class;)V
    //   50: astore 6
    //   52: aload_0
    //   53: getfield 40	com/jiayuan/mail/other/f:g	Landroid/app/Activity;
    //   56: aload 6
    //   58: invokevirtual 423	android/app/Activity:startActivity	(Landroid/content/Intent;)V
    //   61: return
    //   62: new 189	java/util/ArrayList
    //   65: dup
    //   66: invokespecial 190	java/util/ArrayList:<init>	()V
    //   69: astore_3
    //   70: aload_0
    //   71: aload_3
    //   72: putfield 425	com/jiayuan/mail/other/f:d	Ljava/util/ArrayList;
    //   75: aload_0
    //   76: getfield 40	com/jiayuan/mail/other/f:g	Landroid/app/Activity;
    //   79: astore 4
    //   81: new 427	com/jiayuan/util/l
    //   84: dup
    //   85: aload 4
    //   87: ldc_w 429
    //   90: aload_1
    //   91: iload_2
    //   92: invokespecial 432	com/jiayuan/util/l:<init>	(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V
    //   95: invokevirtual 436	com/jiayuan/util/l:getWritableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   98: astore 4
    //   100: new 438	java/util/Date
    //   103: dup
    //   104: invokespecial 439	java/util/Date:<init>	()V
    //   107: invokevirtual 443	java/util/Date:getTime	()J
    //   110: astore 7
    //   112: new 126	java/lang/StringBuilder
    //   115: dup
    //   116: ldc_w 445
    //   119: invokespecial 127	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   122: lload 8
    //   124: invokevirtual 448	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   127: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   130: astore 10
    //   132: ldc 61
    //   134: aload 10
    //   136: invokestatic 68	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   139: new 126	java/lang/StringBuilder
    //   142: dup
    //   143: ldc_w 450
    //   146: invokespecial 127	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   149: lload 8
    //   151: invokevirtual 448	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   154: ldc_w 452
    //   157: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   163: astore_3
    //   164: aload 4
    //   166: aload_3
    //   167: invokevirtual 457	android/database/sqlite/SQLiteDatabase:execSQL	(Ljava/lang/String;)V
    //   170: ldc_w 459
    //   173: astore_3
    //   174: aload 4
    //   176: aload_3
    //   177: aload_1
    //   178: invokevirtual 463	android/database/sqlite/SQLiteDatabase:rawQuery	(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   181: astore 7
    //   183: new 465	java/util/HashSet
    //   186: dup
    //   187: invokespecial 466	java/util/HashSet:<init>	()V
    //   190: astore 11
    //   192: new 242	com/jiayuan/mail/other/a
    //   195: dup
    //   196: invokespecial 259	com/jiayuan/mail/other/a:<init>	()V
    //   199: astore 10
    //   201: aload 7
    //   203: invokeinterface 471 1 0
    //   208: astore_3
    //   209: iload_3
    //   210: ifne +129 -> 339
    //   213: aload 7
    //   215: invokeinterface 474 1 0
    //   220: aload 4
    //   222: invokevirtual 477	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   225: aload_0
    //   226: getfield 55	com/jiayuan/mail/other/f:b	Ljava/util/ArrayList;
    //   229: astore_3
    //   230: aload_3
    //   231: invokevirtual 480	java/util/ArrayList:iterator	()Ljava/util/Iterator;
    //   234: astore 7
    //   236: aload 7
    //   238: invokeinterface 205 1 0
    //   243: astore_3
    //   244: iload_3
    //   245: ifne +284 -> 529
    //   248: aload 4
    //   250: invokevirtual 483	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   253: aload 4
    //   255: invokevirtual 486	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   258: aload 4
    //   260: invokevirtual 487	android/database/sqlite/SQLiteDatabase:close	()V
    //   263: aload_0
    //   264: getfield 425	com/jiayuan/mail/other/f:d	Ljava/util/ArrayList;
    //   267: invokevirtual 219	java/util/ArrayList:size	()I
    //   270: ifeq +441 -> 711
    //   273: aload_0
    //   274: getfield 40	com/jiayuan/mail/other/f:g	Landroid/app/Activity;
    //   277: astore 12
    //   279: new 135	android/app/ProgressDialog
    //   282: dup
    //   283: aload 12
    //   285: invokespecial 490	android/app/ProgressDialog:<init>	(Landroid/content/Context;)V
    //   288: astore 13
    //   290: aload_0
    //   291: aload 13
    //   293: putfield 133	com/jiayuan/mail/other/f:k	Landroid/app/ProgressDialog;
    //   296: aload_0
    //   297: getfield 133	com/jiayuan/mail/other/f:k	Landroid/app/ProgressDialog;
    //   300: ldc_w 492
    //   303: invokevirtual 496	android/app/ProgressDialog:setMessage	(Ljava/lang/CharSequence;)V
    //   306: aload_0
    //   307: getfield 133	com/jiayuan/mail/other/f:k	Landroid/app/ProgressDialog;
    //   310: invokevirtual 497	android/app/ProgressDialog:show	()V
    //   313: new 499	com/jiayuan/mail/other/y
    //   316: dup
    //   317: aload_0
    //   318: invokespecial 502	com/jiayuan/mail/other/y:<init>	(Lcom/jiayuan/a/q;)V
    //   321: astore 14
    //   323: aload_0
    //   324: getfield 425	com/jiayuan/mail/other/f:d	Ljava/util/ArrayList;
    //   327: astore 15
    //   329: aload 14
    //   331: aload 15
    //   333: invokevirtual 505	com/jiayuan/mail/other/y:a	(Ljava/util/ArrayList;)V
    //   336: goto -275 -> 61
    //   339: aload 10
    //   341: invokevirtual 508	com/jiayuan/mail/other/a:clone	()Ljava/lang/Object;
    //   344: checkcast 242	com/jiayuan/mail/other/a
    //   347: astore_3
    //   348: aload 7
    //   350: ldc_w 510
    //   353: invokeinterface 513 2 0
    //   358: astore 16
    //   360: aload 7
    //   362: iload 16
    //   364: invokeinterface 515 2 0
    //   369: astore 17
    //   371: aload_3
    //   372: aload 17
    //   374: putfield 245	com/jiayuan/mail/other/a:a	Ljava/lang/String;
    //   377: aload 7
    //   379: ldc_w 517
    //   382: invokeinterface 513 2 0
    //   387: astore 18
    //   389: aload 7
    //   391: iload 18
    //   393: invokeinterface 521 2 0
    //   398: astore 19
    //   400: new 146	java/lang/String
    //   403: dup
    //   404: aload 19
    //   406: ldc_w 523
    //   409: invokespecial 526	java/lang/String:<init>	([BLjava/lang/String;)V
    //   412: astore 20
    //   414: aload_3
    //   415: aload 20
    //   417: putfield 267	com/jiayuan/mail/other/a:b	Ljava/lang/String;
    //   420: aload 7
    //   422: ldc_w 528
    //   425: invokeinterface 513 2 0
    //   430: astore 21
    //   432: aload 7
    //   434: iload 21
    //   436: invokeinterface 531 2 0
    //   441: astore 22
    //   443: aload_3
    //   444: lload 23
    //   446: putfield 534	com/jiayuan/mail/other/a:n	J
    //   449: aload 11
    //   451: aload_3
    //   452: invokevirtual 535	java/util/HashSet:add	(Ljava/lang/Object;)Z
    //   455: pop
    //   456: new 126	java/lang/StringBuilder
    //   459: dup
    //   460: ldc_w 537
    //   463: invokespecial 127	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   466: astore 25
    //   468: aload_3
    //   469: getfield 245	com/jiayuan/mail/other/a:a	Ljava/lang/String;
    //   472: astore 26
    //   474: aload 25
    //   476: aload 26
    //   478: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   481: ldc_w 539
    //   484: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: astore 27
    //   489: aload_3
    //   490: getfield 267	com/jiayuan/mail/other/a:b	Ljava/lang/String;
    //   493: astore_3
    //   494: aload 27
    //   496: aload_3
    //   497: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   500: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   503: astore_3
    //   504: ldc 61
    //   506: aload_3
    //   507: invokestatic 68	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   510: goto -309 -> 201
    //   513: astore_3
    //   514: aload_3
    //   515: invokevirtual 542	java/lang/CloneNotSupportedException:printStackTrace	()V
    //   518: goto -305 -> 213
    //   521: astore_3
    //   522: aload_3
    //   523: invokevirtual 543	java/io/UnsupportedEncodingException:printStackTrace	()V
    //   526: goto -313 -> 213
    //   529: aload 7
    //   531: invokeinterface 258 1 0
    //   536: checkcast 242	com/jiayuan/mail/other/a
    //   539: astore_3
    //   540: aload 11
    //   542: invokevirtual 544	java/util/HashSet:size	()I
    //   545: astore 28
    //   547: aload 11
    //   549: aload_3
    //   550: invokevirtual 535	java/util/HashSet:add	(Ljava/lang/Object;)Z
    //   553: pop
    //   554: aload 11
    //   556: invokevirtual 544	java/util/HashSet:size	()I
    //   559: iload 28
    //   561: if_icmpeq -325 -> 236
    //   564: iconst_3
    //   565: anewarray 4	java/lang/Object
    //   568: astore 29
    //   570: aload_3
    //   571: getfield 245	com/jiayuan/mail/other/a:a	Ljava/lang/String;
    //   574: invokevirtual 548	java/lang/String:getBytes	()[B
    //   577: astore 30
    //   579: new 146	java/lang/String
    //   582: dup
    //   583: aload 30
    //   585: ldc_w 523
    //   588: invokespecial 526	java/lang/String:<init>	([BLjava/lang/String;)V
    //   591: astore 31
    //   593: aload 29
    //   595: iconst_0
    //   596: aload 31
    //   598: aastore
    //   599: aload_3
    //   600: getfield 267	com/jiayuan/mail/other/a:b	Ljava/lang/String;
    //   603: invokevirtual 548	java/lang/String:getBytes	()[B
    //   606: astore 32
    //   608: new 146	java/lang/String
    //   611: dup
    //   612: aload 32
    //   614: ldc_w 523
    //   617: invokespecial 526	java/lang/String:<init>	([BLjava/lang/String;)V
    //   620: astore 33
    //   622: aload 29
    //   624: iconst_1
    //   625: aload 33
    //   627: aastore
    //   628: new 438	java/util/Date
    //   631: dup
    //   632: invokespecial 439	java/util/Date:<init>	()V
    //   635: invokevirtual 443	java/util/Date:getTime	()J
    //   638: invokestatic 553	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   641: astore 34
    //   643: aload 29
    //   645: iconst_2
    //   646: aload 34
    //   648: aastore
    //   649: aload 4
    //   651: ldc_w 555
    //   654: aload 29
    //   656: invokevirtual 558	android/database/sqlite/SQLiteDatabase:execSQL	(Ljava/lang/String;[Ljava/lang/Object;)V
    //   659: new 126	java/lang/StringBuilder
    //   662: dup
    //   663: ldc_w 560
    //   666: invokespecial 127	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   669: ldc_w 555
    //   672: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   675: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   678: astore 35
    //   680: ldc 61
    //   682: aload 35
    //   684: invokestatic 68	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   687: aload_0
    //   688: getfield 425	com/jiayuan/mail/other/f:d	Ljava/util/ArrayList;
    //   691: aload_3
    //   692: invokevirtual 324	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   695: pop
    //   696: goto -460 -> 236
    //   699: invokevirtual 561	android/database/SQLException:printStackTrace	()V
    //   702: goto -454 -> 248
    //   705: invokevirtual 543	java/io/UnsupportedEncodingException:printStackTrace	()V
    //   708: goto -460 -> 248
    //   711: aload_0
    //   712: getfield 40	com/jiayuan/mail/other/f:g	Landroid/app/Activity;
    //   715: ldc_w 563
    //   718: iload_2
    //   719: invokestatic 179	android/widget/Toast:makeText	(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    //   722: invokevirtual 182	android/widget/Toast:show	()V
    //   725: goto -664 -> 61
    //
    // Exception table:
    //   from	to	target	type
    //   201	209	513	java/lang/CloneNotSupportedException
    //   339	510	513	java/lang/CloneNotSupportedException
    //   201	209	521	java/io/UnsupportedEncodingException
    //   339	510	521	java/io/UnsupportedEncodingException
    //   225	244	699	android/database/SQLException
    //   529	696	699	android/database/SQLException
    //   225	244	705	java/io/UnsupportedEncodingException
    //   529	696	705	java/io/UnsupportedEncodingException
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str1 = "position=" + paramInt;
    com.jiayuan.util.a.a("LocationDataProcessing", str1);
    Intent localIntent = new Intent();
    String str2 = ((a)this.b.get(paramInt)).a;
    localIntent.putExtra("uid", str2);
    String str3 = ((a)this.b.get(paramInt)).k;
    localIntent.putExtra("sex", str3);
    Activity localActivity = this.g;
    localIntent.setClass(localActivity, ProfileActivity.class);
    this.g.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.f
 * JD-Core Version:    0.5.4
 */