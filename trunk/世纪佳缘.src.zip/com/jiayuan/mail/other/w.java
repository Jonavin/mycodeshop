package com.jiayuan.mail.other;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class w
  implements DialogInterface.OnClickListener
{
  w(i parami)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    i.a(this.a).f();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.w
 * JD-Core Version:    0.5.4
 */