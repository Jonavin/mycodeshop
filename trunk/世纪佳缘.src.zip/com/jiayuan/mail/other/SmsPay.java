package com.jiayuan.mail.other;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class SmsPay extends Activity
  implements s
{
  TelephonyManager a;
  Button b;
  Spinner c;
  LinearLayout d;
  int e;
  String f;
  String g;
  boolean h = null;
  ProgressDialog i;

  private void a(int paramInt)
  {
    a.a("SmsPay", "getSmsInfo");
    String str = getString(2131165477);
    ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
    this.i = localProgressDialog;
    new r(this, paramInt).a();
  }

  private void a(String paramString1, String paramString2)
  {
    String str1 = null;
    SmsManager localSmsManager = SmsManager.getDefault();
    Intent localIntent1 = new Intent("com.jiayuan.mail.other.SmsPay.SENT_SMS_ACTION");
    PendingIntent localPendingIntent1 = PendingIntent.getBroadcast(this, 0, localIntent1, 0);
    Intent localIntent2 = new Intent("DELIVERED_SMS_ACTION");
    PendingIntent localPendingIntent2 = PendingIntent.getBroadcast(this, 0, localIntent2, 0);
    Iterator localIterator;
    if (paramString2.length() > 70)
    {
      localIterator = localSmsManager.divideMessage(paramString2).iterator();
      label69: if (localIterator.hasNext());
    }
    while (true)
    {
      return;
      String str2 = (String)localIterator.next();
      String str3 = paramString1;
      localSmsManager.sendTextMessage(str3, str1, str2, localPendingIntent1, localPendingIntent2);
      break label69:
      String str4 = paramString1;
      String str5 = paramString2;
      localSmsManager.sendTextMessage(str4, str1, str5, localPendingIntent1, localPendingIntent2);
    }
  }

  public void a(int paramInt, String paramString)
  {
    int j = 1;
    String str1 = "str=" + paramString;
    a.a("SmsPay", str1);
    if (this.i != null)
      this.i.dismiss();
    if ((paramString.equals("NETWORK_ERROR")) || (paramString.equals("null")))
      Toast.makeText(this, 2131165663, j).show();
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localJSONObject.getInt("retcode");
        String str2 = localJSONObject.getString("send_msg");
        this.g = str2;
        String str3 = localJSONObject.getString("send_mobile");
        this.f = str3;
        label118: this.h = j;
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
        break label118:
      }
    }
  }

  public boolean a()
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int j = ((TelephonyManager)getSystemService("phone")).getSimState();
    Object localObject3;
    switch (j)
    {
    default:
      localObject3 = localObject2;
    case 1:
    case 0:
    case 4:
    case 2:
    case 3:
    case 5:
    }
    while (true)
    {
      return localObject3;
      Toast.makeText(this, 2131165620, localObject1).show();
      localObject3 = localObject2;
      continue;
      Toast.makeText(this, 2131165621, localObject1).show();
      localObject3 = localObject2;
      continue;
      Toast.makeText(this, 2131165622, localObject1).show();
      localObject3 = localObject2;
      continue;
      Toast.makeText(this, 2131165623, localObject1).show();
      localObject3 = localObject2;
      continue;
      Toast.makeText(this, 2131165624, localObject1).show();
      localObject3 = localObject2;
      continue;
      localObject3 = localObject1;
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903110);
    LinearLayout localLinearLayout = (LinearLayout)findViewById(2131362225);
    this.d = localLinearLayout;
    Spinner localSpinner = (Spinner)findViewById(2131362226);
    this.c = localSpinner;
    Button localButton = (Button)findViewById(2131362228);
    this.b = localButton;
    TelephonyManager localTelephonyManager = (TelephonyManager)getSystemService("phone");
    this.a = localTelephonyManager;
    if (a())
      return;
    finish();
  }

  public void onStart()
  {
    int j = 2;
    int k = 1;
    super.onStart();
    String str1 = this.a.getNetworkOperatorName().trim();
    String[] arrayOfString = getResources().getStringArray(2131099878);
    String str2 = "operatorName=" + str1;
    a.a("SmsPay", str2);
    StringBuilder localStringBuilder1 = new StringBuilder("operator China Mobile=");
    String str3 = arrayOfString[k];
    String str4 = str3;
    a.a("SmsPay", str4);
    StringBuilder localStringBuilder2 = new StringBuilder("operator China Unicom=");
    String str5 = arrayOfString[j];
    String str6 = str5;
    a.a("SmsPay", str6);
    String str7 = arrayOfString[k];
    if (str1.equals(str7))
    {
      this.e = k;
      Spinner localSpinner1 = this.c;
      int l = this.e;
      localSpinner1.setSelection(l);
      int i1 = this.e;
      a(i1);
    }
    while (true)
    {
      Button localButton = this.b;
      v localv = new v(this);
      localButton.setOnClickListener(localv);
      return;
      String str8 = arrayOfString[j];
      if (str1.equals(arrayOfString))
      {
        this.e = j;
        Spinner localSpinner2 = this.c;
        int i2 = this.e;
        localSpinner2.setSelection(i2);
        int i3 = this.e;
        a(i3);
      }
      this.e = null;
      Toast.makeText(this, 2131165475, k).show();
      this.d.setEnabled(k);
      Spinner localSpinner3 = this.c;
      u localu = new u(this);
      localSpinner3.setOnItemSelectedListener(localu);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.SmsPay
 * JD-Core Version:    0.5.4
 */