package com.jiayuan.mail.other;

import java.util.Comparator;

public class x
  implements Comparator
{
  public x(f paramf)
  {
  }

  public int a(a parama1, a parama2)
  {
    int i = Integer.parseInt(parama1.j);
    int k = Integer.parseInt(parama2.j);
    int j;
    if (i > k)
      j = -1;
    while (true)
    {
      return j;
      if (j < k)
        j = 1;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.x
 * JD-Core Version:    0.5.4
 */