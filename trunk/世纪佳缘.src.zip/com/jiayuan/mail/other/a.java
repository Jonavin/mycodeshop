package com.jiayuan.mail.other;

import org.json.JSONArray;

public class a
  implements Cloneable
{
  public String a;
  public String b;
  public int c;
  public String d;
  public int e;
  public int f;
  public int g;
  public int h;
  public long i;
  public String j;
  public String k;
  public JSONArray l;
  public String m;
  public long n;

  public Object clone()
  {
    return super.clone();
  }

  public boolean equals(Object paramObject)
  {
    a locala = (a)paramObject;
    String str1 = this.a;
    String str2 = paramObject.a;
    return str1.equals(str2);
  }

  public int hashCode()
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.a
 * JD-Core Version:    0.5.4
 */