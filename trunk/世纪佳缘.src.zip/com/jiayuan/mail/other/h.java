package com.jiayuan.mail.other;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.s;
import com.jiayuan.util.t;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

class h extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  h(f paramf, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903050, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    b localb = (b)paramView.getTag();
    localb.i = paramInt;
    paramView.setTag(localb);
    Object localObject1 = (Bitmap)f.a(this.b).get(paramInt);
    Bitmap localBitmap = s.a((Bitmap)localObject1, 1084227584);
    f.a(this.b).set(paramInt, localBitmap);
    ((Bitmap)localObject1).recycle();
    localb.a.setImageBitmap(localBitmap);
    TextView localTextView1 = localb.c;
    localObject1 = ((a)f.b(this.b).get(paramInt)).b;
    localTextView1.setText((CharSequence)localObject1);
    Activity localActivity1 = this.a;
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = ((a)f.b(this.b).get(paramInt)).g;
    String str1 = i;
    int i1 = t.b(localActivity1, str1);
    Activity localActivity2 = this.a;
    StringBuilder localStringBuilder2 = new StringBuilder();
    int j = ((a)f.b(this.b).get(paramInt)).h;
    Object localObject2 = j;
    int i2 = t.b(localActivity2, i1, (String)localObject2);
    TextView localTextView2 = localb.d;
    localObject2 = String.valueOf(((a)f.b(this.b).get(paramInt)).e);
    StringBuilder localStringBuilder3 = new StringBuilder((String)localObject2).append("宀");
    localObject2 = ((a)f.b(this.b).get(paramInt)).d;
    localObject2 = localStringBuilder3.append((String)localObject2).append("鍘�");
    String str3 = t.a(this.a, i1);
    localObject2 = ((StringBuilder)localObject2).append(str3);
    String str4 = t.a(this.a, i1, i2, null);
    localObject2 = str4;
    localTextView2.setText((CharSequence)localObject2);
    TextView localTextView3 = localb.e;
    Activity localActivity3 = f.c(this.b);
    int k = ((a)f.b(this.b).get(paramInt)).f;
    String str2 = String.valueOf(com.jiayuan.util.f.c(localActivity3, k));
    StringBuilder localStringBuilder4 = new StringBuilder(str2).append("/");
    Activity localActivity4 = f.c(this.b);
    int l = ((a)f.b(this.b).get(paramInt)).c;
    Object localObject3 = com.jiayuan.util.f.h(localActivity4, l);
    localObject3 = (String)localObject3;
    localTextView3.setText((CharSequence)localObject3);
    localObject3 = s.b(((a)f.b(this.b).get(paramInt)).l);
    if (localObject3 != -1)
      localb.f.setText(localObject3);
    while (true)
    {
      TextView localTextView4 = localb.g;
      String str5 = ((a)f.b(this.b).get(paramInt)).j;
      localTextView4.setText(str5);
      Calendar localCalendar = Calendar.getInstance();
      long l1 = ((a)f.b(this.b).get(paramInt)).i;
      long l2 = 1000L * l1;
      localCalendar.setTimeInMillis(l2);
      String str6 = f.c(this.b).getString(2131165557);
      StringBuffer localStringBuffer = new StringBuffer(str6);
      int i3 = localCalendar.get(5);
      localStringBuffer.append(i3);
      localStringBuffer.append("�");
      int i4 = localCalendar.get(11);
      localStringBuffer.append(i4);
      localStringBuffer.append("�");
      TextView localTextView5 = localb.h;
      String str7 = localStringBuffer.toString();
      localb.setText(str7);
      return;
      localb.f.setText(2131165630);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903050, paramViewGroup, null);
      b localb = new b(null);
      localObject = (ImageView)localView.findViewById(2131361829);
      localb.a = ((ImageView)localObject);
      localObject = (ImageView)localView.findViewById(2131361830);
      localb.b = ((ImageView)localObject);
      localObject = (TextView)localView.findViewById(2131361832);
      localb.c = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361833);
      localb.d = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361834);
      localb.e = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361835);
      localb.f = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361840);
      localb.g = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361836);
      localb.h = ((TextView)localObject);
      localView.setTag(localb);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    com.jiayuan.util.a.a("LocationDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.h
 * JD-Core Version:    0.5.4
 */