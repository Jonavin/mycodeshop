package com.jiayuan.mail.other;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;

class k
  implements AdapterView.OnItemSelectedListener
{
  k(f paramf)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    a.a("LocationDataProcessing", "OnItemSelectedListener onItemSelected!!!!!!!!!!!!!!!");
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
    a.a("LocationDataProcessing", "OnItemSelectedListener onNothingSelected@@@@@@@@@@@");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.k
 * JD-Core Version:    0.5.4
 */