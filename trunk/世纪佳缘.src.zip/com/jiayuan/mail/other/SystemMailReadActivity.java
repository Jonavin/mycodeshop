package com.jiayuan.mail.other;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager.BadTokenException;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.util.a;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public class SystemMailReadActivity extends MyActivity
  implements m
{
  ProgressDialog a;
  private q b;

  private void d()
  {
    a.a("SystemMailReadActivity", "updateSystemMail");
    TextView localTextView1 = (TextView)findViewById(2131362230);
    StringBuilder localStringBuilder1 = new StringBuilder();
    CharSequence localCharSequence1 = localTextView1.getText();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localCharSequence1);
    String str1 = this.b.b;
    String str2 = str1;
    localTextView1.setText(str2);
    Date localDate = new Date();
    long l1 = Integer.parseInt(this.b.c);
    long l2 = 1000L * l1;
    localDate.setTime(l2);
    TextView localTextView2 = (TextView)findViewById(2131362231);
    StringBuilder localStringBuilder3 = new StringBuilder();
    CharSequence localCharSequence2 = localTextView2.getText();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(localCharSequence2);
    String str3 = localDate.toLocaleString();
    String str4 = str3;
    localTextView2.setText(str4);
    WebView localWebView = (WebView)findViewById(2131362232);
    WebSettings localWebSettings = localWebView.getSettings();
    localWebSettings.setDefaultTextEncodingName("utf-8");
    localWebSettings.setAllowFileAccess(true);
    localWebSettings.setJavaScriptEnabled(true);
    localWebSettings.setBuiltInZoomControls(null);
    localWebSettings.setSupportZoom(true);
    localWebView.setInitialScale(0);
    q localq = this.b;
    String str5 = Uri.encode(this.b.d);
    localq.d = str5;
    String str6 = this.b.d;
    localWebView.loadData(str6, "text/html", "utf-8");
    StringBuilder localStringBuilder5 = new StringBuilder("WEBCONTENT=");
    String str7 = this.b.d;
    String str8 = str7;
    a.a("SystemMailReadActivity", str8);
  }

  public void a()
  {
    a.a("SystemMailReadActivity", "---------onWaitingActivityStart()---------");
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.a = localProgressDialog;
      this.a.setCancelable(true);
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void a(String paramString)
  {
    this.a.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("SystemMailReadActivity", str2);
    try
    {
      q localq1 = this.b;
      String str3 = paramJSONObject.getString("subject");
      localq1.b = str3;
      q localq2 = this.b;
      String str4 = paramJSONObject.getString("send_time");
      localq2.c = str4;
      q localq3 = this.b;
      String str5 = paramJSONObject.getString("content");
      localq3.d = str5;
      d();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public void b()
  {
    this.a.dismiss();
    a.a("SystemMailReadActivity", "---------onWaitingActivityFinish()---------");
  }

  public void c()
  {
    this.a.dismiss();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903112);
    a.a("SystemMailReadActivity", "onCreate");
    q localq1 = new q();
    this.b = localq1;
    Bundle localBundle = getIntent().getExtras();
    q localq2 = this.b;
    String str1 = localBundle.getString("msg_id");
    localq2.a = str1;
    String str2 = this.b.a;
    new e(this, str2).a();
  }

  protected void onResume()
  {
    super.onResume();
    a.a("SystemMailReadActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.SystemMailReadActivity
 * JD-Core Version:    0.5.4
 */