package com.jiayuan.mail.other;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.view.View;
import android.view.View.OnClickListener;

class i
  implements View.OnClickListener
{
  i(f paramf)
  {
  }

  public void onClick(View paramView)
  {
    Activity localActivity = f.c(this.a);
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(localActivity).setMessage("鏄惁缁欐�");
    w localw = new w(this);
    localBuilder.setPositiveButton("�", localw).setNegativeButton("�", null).create().show();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.i
 * JD-Core Version:    0.5.4
 */