package com.jiayuan.mail.other;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import com.jiayuan.util.f;
import com.jiayuan.util.s;
import com.jiayuan.util.t;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class g extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  g(c paramc, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903114, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    l locall = (l)paramView.getTag();
    locall.g = paramInt;
    paramView.setTag(locall);
    Object localObject1 = s.a((Bitmap)c.a(this.b).get(paramInt), 1084227584);
    locall.a.setImageBitmap((Bitmap)localObject1);
    TextView localTextView1 = locall.c;
    localObject1 = ((n)c.b(this.b).get(paramInt)).b;
    localTextView1.setText((CharSequence)localObject1);
    Activity localActivity1 = this.a;
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = ((n)c.b(this.b).get(paramInt)).h;
    String str1 = i;
    int i1 = t.b(localActivity1, str1);
    Activity localActivity2 = this.a;
    StringBuilder localStringBuilder2 = new StringBuilder();
    int j = ((n)c.b(this.b).get(paramInt)).i;
    Object localObject2 = j;
    int i2 = t.b(localActivity2, i1, (String)localObject2);
    TextView localTextView2 = locall.d;
    int i3 = ((n)c.b(this.b).get(paramInt)).e;
    localObject2 = ((n)c.b(this.b).get(paramInt)).f;
    localObject2 = String.valueOf(s.a(i3, (String)localObject2));
    StringBuilder localStringBuilder3 = new StringBuilder((String)localObject2).append("宀");
    localObject2 = ((n)c.b(this.b).get(paramInt)).d;
    localObject2 = localStringBuilder3.append((String)localObject2).append("鍘�");
    String str3 = t.a(this.a, i1);
    localObject2 = ((StringBuilder)localObject2).append(str3);
    String str4 = t.a(this.a, i1, i2, null);
    localObject2 = str4;
    localTextView2.setText((CharSequence)localObject2);
    TextView localTextView3 = locall.e;
    Activity localActivity3 = c.c(this.b);
    int k = ((n)c.b(this.b).get(paramInt)).g;
    String str2 = String.valueOf(f.c(localActivity3, k));
    StringBuilder localStringBuilder4 = new StringBuilder(str2).append("/");
    Activity localActivity4 = c.c(this.b);
    int l = ((n)c.b(this.b).get(paramInt)).c;
    Object localObject3 = f.h(localActivity4, l);
    localObject3 = (String)localObject3;
    localTextView3.setText((CharSequence)localObject3);
    localObject3 = s.b(((n)c.b(this.b).get(paramInt)).k);
    if (localObject3 != -1)
    {
      TextView localTextView4 = locall.e;
      StringBuilder localStringBuilder5 = new StringBuilder();
      CharSequence localCharSequence = locall.e.getText();
      StringBuilder localStringBuilder6 = localStringBuilder5.append(localCharSequence).append("/");
      String str5 = c.c(this.b).getString(localObject3);
      String str6 = (String)localObject3;
      localTextView4.setText((CharSequence)localObject3);
    }
    Date localDate = new Date();
    long l1 = Integer.parseInt(((n)c.b(this.b).get(paramInt)).j);
    long l2 = 1000L * l1;
    localDate.setTime(l2);
    TextView localTextView5 = locall.f;
    StringBuilder localStringBuilder7 = new StringBuilder("鍒拌");
    String str7 = localDate.toLocaleString();
    String str8 = str7;
    locall.setText(str8);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903114, paramViewGroup, null);
      l locall = new l(null);
      localObject = (ImageView)localView.findViewById(2131362236);
      locall.a = ((ImageView)localObject);
      localObject = (ImageView)localView.findViewById(2131362237);
      locall.b = ((ImageView)localObject);
      localObject = (TextView)localView.findViewById(2131362239);
      locall.c = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131362240);
      locall.d = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131362241);
      locall.e = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131362242);
      locall.f = ((TextView)localObject);
      localView.setTag(locall);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    a.a("WhoLookedMeDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.g
 * JD-Core Version:    0.5.4
 */