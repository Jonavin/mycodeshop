package com.jiayuan.mail.other;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;

class o
  implements AdapterView.OnItemSelectedListener
{
  o(c paramc)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    a.a("WhoLookedMeDataProcessing", "OnItemSelectedListener onItemSelected!!!!!!!!!!!!!!!");
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
    a.a("WhoLookedMeDataProcessing", "OnItemSelectedListener onNothingSelected@@@@@@@@@@@");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.o
 * JD-Core Version:    0.5.4
 */