package com.jiayuan.mail.other;

public abstract interface s
{
  public abstract void a(int paramInt, String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.s
 * JD-Core Version:    0.5.4
 */