package com.jiayuan.mail.other;

public class q
{
  public String a;
  public String b;
  public String c;
  public String d;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.q
 * JD-Core Version:    0.5.4
 */