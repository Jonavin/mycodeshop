package com.jiayuan.mail.other;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import com.jiayuan.util.a;

class j
  implements AbsListView.OnScrollListener
{
  j(f paramf)
  {
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    a.a("LocationDataProcessing", "OnScrollListener onScroll");
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    a.a("LocationDataProcessing", "OnScrollListener onScrollStateChanged");
    if (paramInt != 0)
      return;
    a.a("LocationDataProcessing", "OnScrollListener onScrollStateChanged boom~~~~~~~~~");
    f.d(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.j
 * JD-Core Version:    0.5.4
 */