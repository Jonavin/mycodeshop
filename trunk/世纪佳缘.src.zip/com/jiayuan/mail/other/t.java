package com.jiayuan.mail.other;

public abstract interface t
{
  public abstract void a();

  public abstract void a(String paramString);

  public abstract void b();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.t
 * JD-Core Version:    0.5.4
 */