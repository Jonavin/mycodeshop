package com.jiayuan.mail.other;

import org.json.JSONObject;

public abstract interface m
{
  public abstract void a();

  public abstract void a(String paramString);

  public abstract void a(JSONObject paramJSONObject);

  public abstract void b();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.m
 * JD-Core Version:    0.5.4
 */