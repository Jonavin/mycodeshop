package com.jiayuan.mail.other;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

class u
  implements AdapterView.OnItemSelectedListener
{
  u(SmsPay paramSmsPay)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.a.e = paramInt;
    if (this.a.e == 0)
      return;
    SmsPay localSmsPay = this.a;
    int i = this.a.e;
    SmsPay.a(localSmsPay, i);
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.u
 * JD-Core Version:    0.5.4
 */