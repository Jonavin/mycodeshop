package com.jiayuan.mail.other;

import android.app.Activity;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class e
  implements q
{
  public m a;
  private String b;
  private Activity c;

  public e(m paramm, String paramString)
  {
    Activity localActivity = (Activity)paramm;
    this.c = localActivity;
    this.a = paramm;
    this.b = paramString;
  }

  public void a()
  {
    a.a("SystemMailReadDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("msg/showmsg.php?");
    localStringBuffer.append("adm=");
    localStringBuffer.append("1");
    localStringBuffer.append("&msg_id=");
    String str1 = this.b;
    localStringBuffer.append(str1);
    localStringBuffer.append("&box=");
    localStringBuffer.append("inbox");
    localStringBuffer.append("&uid=");
    String str2 = o.e();
    localStringBuffer.append(str2);
    localStringBuffer.append("&token=");
    String str3 = o.f();
    localStringBuffer.append(str3);
    l locall = new l();
    locall.a = this;
    String str4 = localStringBuffer.toString();
    locall.b(str4);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject = "SystemMailReadDataProcessing";
    a.a((String)localObject, "onPostExecute()");
    try
    {
      localObject = new JSONObject(paramString);
      if (paramString.equalsIgnoreCase("NETWORK_ERROR"))
      {
        this.a.a(paramString);
        return;
      }
      StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
      String str1 = ((JSONObject)localObject).toString();
      String str2 = str1;
      a.a("SystemMailReadDataProcessing", str2);
      this.a.b();
      this.a.a((JSONObject)localObject);
    }
    catch (JSONException localJSONException)
    {
      StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
      String str3 = localJSONException.toString();
      String str4 = str3;
      a.a("SystemMailReadDataProcessing", str4);
      this.a.c();
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("SystemMailReadDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    a.a("SystemMailReadDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("SystemMailReadDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.e
 * JD-Core Version:    0.5.4
 */