package com.jiayuan.mail.other;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.a;
import com.jiayuan.service.ServiceActivity;

class v
  implements View.OnClickListener
{
  v(SmsPay paramSmsPay)
  {
  }

  public void onClick(View paramView)
  {
    if (this.a.h)
    {
      SmsPay localSmsPay = this.a;
      String str1 = this.a.f;
      String str2 = this.a.g;
      SmsPay.a(localSmsPay, str1, str2);
      this.a.finish();
      a locala = a.a();
      locala.b(MainActivity.class);
      MainActivity localMainActivity = (MainActivity)locala.d(MainActivity.class);
      super.a(3);
      ServiceActivity localServiceActivity = (ServiceActivity)super.getCurrentActivity();
      int i = ServiceActivity.c;
      super.a(i);
    }
    while (true)
    {
      return;
      Toast.makeText(this.a, 2131165479, 1).show();
      this.a.finish();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.v
 * JD-Core Version:    0.5.4
 */