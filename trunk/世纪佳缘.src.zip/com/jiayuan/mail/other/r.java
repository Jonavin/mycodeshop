package com.jiayuan.mail.other;

import com.jiayuan.a.l;
import com.jiayuan.a.q;

public class r
  implements q
{
  s a;
  int b;

  public r(s params, int paramInt)
  {
    this.a = params;
    this.b = paramInt;
  }

  public void a()
  {
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("uic/get_sendtype.php?");
    localStringBuffer.append("operator=");
    int i = this.b;
    localStringBuffer.append(i);
    l locall = new l();
    locall.a = this;
    String str = localStringBuffer.toString();
    locall.b(str);
  }

  public void a(int paramInt, String paramString)
  {
    this.a.a(paramInt, paramString);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.r
 * JD-Core Version:    0.5.4
 */