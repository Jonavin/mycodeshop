package com.jiayuan.mail.other;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import com.jiayuan.a.f;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.a.u;
import com.jiayuan.a.y;
import com.jiayuan.profile.ProfileActivity;
import com.jiayuan.util.a;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c
  implements AdapterView.OnItemClickListener, com.jiayuan.a.c, com.jiayuan.a.n, com.jiayuan.a.o, q
{
  public d a;
  private ArrayList b;
  private ArrayList c;
  private ArrayList d;
  private ArrayList e;
  private boolean f = true;
  private int g;
  private int h;
  private Activity i;
  private ListView j;
  private g k;

  public c(d paramd, ListView paramListView, int paramInt1, int paramInt2)
  {
    Activity localActivity = (Activity)paramd;
    this.i = localActivity;
    this.j = paramListView;
    this.a = paramd;
    this.g = paramInt1;
    this.h = paramInt2;
  }

  private void f()
  {
    a.a("WhoLookedMeDataProcessing", "loadRemainListItem loadRemainListItem");
  }

  public void a()
  {
    a.a("WhoLookedMeDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("relation/get_wholookme.php?");
    localStringBuffer.append("uid=");
    String str1 = com.jiayuan.util.o.e();
    localStringBuffer.append(str1);
    localStringBuffer.append("&token=");
    String str2 = com.jiayuan.util.o.f();
    localStringBuffer.append(str2);
    l locall = new l();
    locall.a = this;
    String str3 = localStringBuffer.toString();
    locall.b(str3);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject1 = 0;
    Object localObject2 = "onPostExecute()";
    a.a("WhoLookedMeDataProcessing", (String)localObject2);
    boolean bool = paramString.equalsIgnoreCase("NETWORK_ERROR");
    if (bool)
    {
      a.a("WhoLookedMeDataProcessing", "Get NETWORK_ERROR");
      this.a.a(paramString);
    }
    while (true)
    {
      label43: return;
      try
      {
        Object localObject3 = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = ((JSONObject)localObject3).toString();
        String str2 = str1;
        a.a("WhoLookedMeDataProcessing", str2);
        localObject2 = new ArrayList();
        this.b = ((ArrayList)localObject2);
        localObject2 = new ArrayList();
        this.c = ((ArrayList)localObject2);
        localObject2 = new ArrayList();
        this.e = ((ArrayList)localObject2);
        localObject3 = ((JSONObject)localObject3).getJSONArray("wholookme");
        localObject2 = localObject1;
        int l = ((JSONArray)localObject3).length();
        if (localObject2 >= l)
        {
          localObject3 = new ArrayList();
          this.d = ((ArrayList)localObject3);
        }
        for (localObject3 = localObject1; ; ++localObject3)
        {
          localObject2 = this.b.size();
          if (localObject3 >= localObject2)
          {
            ArrayList localArrayList1 = this.e;
            Integer localInteger1 = Integer.valueOf(3);
            localArrayList1.add(localInteger1);
            ArrayList localArrayList2 = this.e;
            Integer localInteger2 = Integer.valueOf(6);
            localArrayList2.add(localInteger2);
            ArrayList localArrayList3 = this.e;
            Integer localInteger3 = Integer.valueOf(5);
            localArrayList3.add(localInteger3);
            ArrayList localArrayList4 = this.e;
            Integer localInteger4 = Integer.valueOf(105);
            localArrayList4.add(localInteger4);
            ArrayList localArrayList5 = this.e;
            Integer localInteger5 = Integer.valueOf(104);
            localArrayList5.add(localInteger5);
            ArrayList localArrayList6 = this.e;
            Integer localInteger6 = Integer.valueOf(112);
            localArrayList6.add(localInteger6);
            ArrayList localArrayList7 = this.e;
            Integer localInteger7 = Integer.valueOf(114);
            localArrayList7.add(localInteger7);
            ArrayList localArrayList8 = this.e;
            Integer localInteger8 = Integer.valueOf(100);
            localArrayList8.add(localInteger8);
            ArrayList localArrayList9 = this.e;
            Integer localInteger9 = Integer.valueOf(101);
            localArrayList9.add(localInteger9);
            List localList = this.c.subList(0, 20);
            ArrayList localArrayList10 = new ArrayList(localList);
            ArrayList localArrayList11 = this.e;
            new y(this, localArrayList10, localArrayList11).a();
            this.a.b();
            e();
            int i1 = localObject1;
            while (true)
            {
              int i3 = this.b.size();
              if (i1 < i3);
              String str3 = ((n)this.b.get(i1)).a;
              int i4 = this.g;
              int i5 = this.h + 12;
              c localc = this;
              new f(localc, str3, "", i1, i4, i5).a();
              new u(this, str3, i1).a();
              i1 += 1;
            }
            JSONArray localJSONArray = ((JSONArray)localObject3).getJSONArray(localObject2);
            Object localObject4 = new StringBuilder("person.toString()=");
            String str4 = localJSONArray.toString();
            localObject4 = str4;
            a.a("WhoLookedMeDataProcessing", (String)localObject4);
            n localn = new n();
            localObject4 = localJSONArray.getString(0);
            localn.a = ((String)localObject4);
            localn.b = "";
            localn.c = null;
            localn.d = "";
            localn.e = null;
            localn.f = null;
            localn.g = null;
            localn.h = null;
            localn.i = null;
            localObject4 = localJSONArray.getString(1);
            localn.j = ((String)localObject4);
            localn.k = null;
            localn.l = "";
            this.b.add(localn);
            ArrayList localArrayList12 = this.c;
            int i2 = 0;
            String str5 = localJSONArray.getString(i2);
            localArrayList12.add(str5);
            ++localObject2;
          }
          localObject2 = com.jiayuan.util.o.l().equals("m");
          if (localObject2 == 0)
            break;
          localObject2 = this.i.getResources().openRawResource(2130837629);
          Bitmap localBitmap = BitmapFactory.decodeStream((InputStream)localObject2);
          this.d.add(localObject2);
        }
        localObject2 = this.i.getResources().openRawResource(2130837631);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str6 = localJSONException.toString();
        String str7 = str6;
        a.a("WhoLookedMeDataProcessing", str7);
        this.a.c();
        break label43:
      }
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    int l = 2130837628;
    if (paramBitmap == null)
    {
      boolean bool = com.jiayuan.util.o.l().equals("m");
      if (!bool);
    }
    for (Bitmap localBitmap = BitmapFactory.decodeResource(this.i.getResources(), l); ; localBitmap = paramBitmap)
      while (true)
      {
        this.d.set(paramInt, localBitmap);
        ((n)this.b.get(paramInt)).l = paramString;
        this.k.notifyDataSetChanged();
        return;
        localBitmap = BitmapFactory.decodeResource(this.i.getResources(), l);
      }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    ((n)this.b.get(paramInt)).k = paramJSONArray;
    this.k.notifyDataSetChanged();
  }

  public void a(JSONObject paramJSONObject)
  {
    int l = 0;
    int i1 = 20;
    String str1 = "WhoLookedMeDataProcessing";
    Object localObject = new StringBuilder("json.toString()=");
    String str2 = paramJSONObject.toString();
    localObject = str2;
    a.a(str1, (String)localObject);
    try
    {
      localObject = paramJSONObject.getJSONObject("userinfos");
      boolean bool = this.f;
      int i2;
      label84: int i3;
      if (bool)
      {
        i2 = this.b.size();
        if (i2 > i1)
        {
          i2 = i1;
          i3 = i2;
        }
      }
      while (l >= i3)
      {
        this.k.notifyDataSetChanged();
        if (this.f)
        {
          int i4 = this.b.size();
          if (i1 < i4)
          {
            ArrayList localArrayList1 = this.c;
            int i5 = this.c.size();
            List localList = localArrayList1.subList(20, i5);
            ArrayList localArrayList2 = new ArrayList(localList);
            ArrayList localArrayList3 = this.e;
            new y(this, localArrayList2, localArrayList3).a();
            this.f = null;
          }
        }
        label186: return;
        i2 = this.b.size();
        break label84:
        i3 = this.b.size();
        l = i1;
      }
      n localn = (n)this.b.get(l);
      String str3 = localn.a;
      JSONObject localJSONObject = ((JSONObject)localObject).getJSONObject(str3);
      String str4 = localJSONObject.getString("3");
      localn.b = str4;
      int i6 = localJSONObject.getInt("114");
      localn.c = i6;
      String str5 = localJSONObject.getString("112");
      localn.d = str5;
      int i7 = localJSONObject.getInt("6");
      localn.e = i7;
      String str6 = localJSONObject.getString("5");
      localn.f = str6;
      int i8 = localJSONObject.getInt("104");
      localn.g = i8;
      int i9 = localJSONObject.getInt("100");
      localn.h = i9;
      int i10 = localJSONObject.getInt("101");
      localn.i = i10;
      l += 1;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      this.a.c();
      break label186:
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("WhoLookedMeDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    a.a("WhoLookedMeDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("WhoLookedMeDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    Activity localActivity = this.i;
    ArrayList localArrayList = this.b;
    g localg1 = new g(this, localActivity, localArrayList);
    this.k = localg1;
    this.k.setNotifyOnChange(null);
    ListView localListView1 = this.j;
    g localg2 = this.k;
    localListView1.setAdapter(localg2);
    this.j.setOnItemClickListener(this);
    ListView localListView2 = this.j;
    p localp = new p(this);
    localListView2.setOnScrollListener(localp);
    ListView localListView3 = this.j;
    o localo = new o(this);
    localListView3.setOnItemSelectedListener(localo);
    this.k.notifyDataSetChanged();
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    Object localObject = "position=" + paramInt;
    a.a("WhoLookedMeDataProcessing", (String)localObject);
    localObject = new Intent();
    String str1 = ((n)this.b.get(paramInt)).a;
    ((Intent)localObject).putExtra("uid", str1);
    str1 = "sex";
    boolean bool = com.jiayuan.util.o.l().equals("m");
    if (bool);
    for (String str2 = "f"; ; str2 = "m")
    {
      ((Intent)localObject).putExtra(str1, str2);
      Activity localActivity = this.i;
      ((Intent)localObject).setClass(str1, ProfileActivity.class);
      this.i.startActivity((Intent)localObject);
      return;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.c
 * JD-Core Version:    0.5.4
 */