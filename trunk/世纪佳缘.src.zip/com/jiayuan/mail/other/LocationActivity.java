package com.jiayuan.mail.other;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager.BadTokenException;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.login.LoginActivity;
import com.jiayuan.util.o;

public class LocationActivity extends MyActivity
  implements t
{
  ProgressDialog a;
  Button b;
  private ListView c;

  public void a()
  {
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.a = localProgressDialog;
      this.a.setCancelable(true);
      com.jiayuan.util.a.a("LocationActivity", "---------onWaitingActivityStart()---------");
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void a(String paramString)
  {
    this.a.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    this.a.dismiss();
    com.jiayuan.util.a.a("LocationActivity", "---------onWaitingActivityFinish()---------");
  }

  public void c()
  {
    this.a.dismiss();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903049);
    com.jiayuan.util.a.a("LocationActivity", "LocationActivity onCreate");
    if ((o.e() == null) || (o.e().equals("")))
    {
      Intent localIntent = new Intent(this, LoginActivity.class);
      startActivity(localIntent);
      finish();
    }
    while (true)
    {
      return;
      ListView localListView1 = (ListView)findViewById(2131361826);
      this.c = localListView1;
      Button localButton1 = (Button)findViewById(2131361827);
      this.b = localButton1;
      this.b.setEnabled(null);
      int i = o.d(this);
      int j = o.e(this);
      int k = i / 2;
      int l = j / 2;
      ListView localListView2 = this.c;
      Button localButton2 = this.b;
      LocationActivity localLocationActivity = this;
      new f(localLocationActivity, localListView2, localButton2, k, l).a();
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool1 = null;
    Object localObject1 = 1;
    Object localObject2 = com.jiayuan.a.a();
    boolean bool2 = ((com.jiayuan.a)localObject2).a(this);
    if (paramInt == 4)
      if (bool2)
      {
        Intent localIntent = new Intent(this, MainActivity.class);
        localIntent.putExtra("tabIndex", localObject1);
        localIntent.putExtra("notify", bool1);
        startActivity(localIntent);
        ((com.jiayuan.a)localObject2).b(this);
        finish();
        localObject2 = localObject1;
      }
    while (true)
    {
      return localObject2;
      ((com.jiayuan.a)localObject2).b(this);
      finish();
      localObject2 = localObject1;
      continue;
      localObject2 = bool1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.LocationActivity
 * JD-Core Version:    0.5.4
 */