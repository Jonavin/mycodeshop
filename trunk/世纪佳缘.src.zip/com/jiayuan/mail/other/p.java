package com.jiayuan.mail.other;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import com.jiayuan.util.a;

class p
  implements AbsListView.OnScrollListener
{
  p(c paramc)
  {
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    a.a("WhoLookedMeDataProcessing", "OnScrollListener onScroll");
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    a.a("WhoLookedMeDataProcessing", "OnScrollListener onScrollStateChanged");
    if (paramInt != 0)
      return;
    a.a("WhoLookedMeDataProcessing", "OnScrollListener onScrollStateChanged boom~~~~~~~~~");
    c.d(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.other.p
 * JD-Core Version:    0.5.4
 */