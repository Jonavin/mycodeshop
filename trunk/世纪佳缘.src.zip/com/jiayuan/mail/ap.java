package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class ap
  implements View.OnClickListener
{
  ap(MailHomeActivity paramMailHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailHomeActivity.a(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ap
 * JD-Core Version:    0.5.4
 */