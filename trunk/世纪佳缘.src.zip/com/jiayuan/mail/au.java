package com.jiayuan.mail;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import com.jiayuan.util.a;

class au
  implements AbsListView.OnScrollListener
{
  au(o paramo)
  {
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    if (paramInt != 0)
      return;
    int i = paramAbsListView.getLastVisiblePosition();
    int j = paramAbsListView.getCount() - 1;
    if (i != j)
      return;
    a.a("MailSendedDataProcessing", "OnScrollListener onScrollStateChanged boom~~~~~~~~~boom~~~~~~~~~");
    o.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.au
 * JD-Core Version:    0.5.4
 */