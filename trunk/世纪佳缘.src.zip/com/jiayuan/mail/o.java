package com.jiayuan.mail;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.a.l;
import com.jiayuan.mail.detail.MailReadActivity;
import com.jiayuan.mail.detail.ag;
import com.jiayuan.mail.detail.b;
import com.jiayuan.util.a;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class o
  implements AdapterView.OnItemClickListener, com.jiayuan.a.q, b, q
{
  public al a;
  private String b;
  private ArrayList c;
  private ArrayList d;
  private ArrayList e;
  private int f = 1;
  private int g = 10;
  private Activity h;
  private ListView i;
  private ad j;
  private boolean k = null;

  public o(al paramal, ListView paramListView)
  {
    Activity localActivity = (Activity)paramal;
    this.h = localActivity;
    this.i = paramListView;
    this.a = paramal;
    String str = com.jiayuan.util.o.e();
    this.b = str;
    ArrayList localArrayList = new ArrayList();
    this.c = localArrayList;
    f();
    e();
  }

  private void l()
  {
    a.a("MailSendedDataProcessing", "loadRemainListItem loadRemainListItem");
    int l = this.f;
    int i1;
    ++i1;
    this.f = l;
    int i2 = this.f;
    int i3 = this.g;
    a(i2, i3);
  }

  public void a()
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    int l = 1;
    a.a("MailSendedDataProcessing", "execute()");
    if (this.k)
    {
      int i1 = this.f - l;
      this.f = i1;
      Toast.makeText(this.h, 2131165472, l).show();
    }
    while (true)
    {
      return;
      this.f = paramInt1;
      this.g = paramInt2;
      this.a.a();
      StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer.append("msg/list.php?");
      localStringBuffer.append("uid=");
      String str1 = com.jiayuan.util.o.e();
      localStringBuffer.append(str1);
      localStringBuffer.append("&token=");
      String str2 = com.jiayuan.util.o.f();
      localStringBuffer.append(str2);
      localStringBuffer.append("&p=");
      int i2 = this.f;
      localStringBuffer.append(i2);
      localStringBuffer.append("&page_size=");
      int i3 = this.g;
      localStringBuffer.append(i3);
      localStringBuffer.append("&boxtype=");
      localStringBuffer.append("outbox");
      l locall = new l();
      locall.a = this;
      String str3 = localStringBuffer.toString();
      locall.b(str3);
    }
  }

  public void a(int paramInt1, int paramInt2, String paramString)
  {
    this.a.e();
    if (1 == paramInt2)
    {
      String str1 = "Goto mail read activity, position=" + paramInt1 + ", sResult=" + paramString;
      a.a("MailSendedDataProcessing", str1);
    }
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      as localas = (as)this.c.get(paramInt1);
      String str2 = localJSONObject.getString("content");
      localas.i = str2;
      Intent localIntent = new Intent();
      String str3 = localJSONObject.getString("msg_id");
      localIntent.putExtra("msg_id", str3);
      String str4 = localJSONObject.getString("to_uid");
      localIntent.putExtra("uid", str4);
      localIntent.putExtra("box_type", "outbox");
      String str5 = localJSONObject.getString("send_time");
      localIntent.putExtra("send_time", str5);
      String str6 = localJSONObject.getString("content");
      localIntent.putExtra("content", str6);
      Activity localActivity1 = this.h;
      localIntent.setClass(localActivity1, MailReadActivity.class);
      this.h.startActivity(localIntent);
      label207: return;
    }
    catch (JSONException localJSONException1)
    {
      while (true)
      {
        localJSONException1.printStackTrace();
        this.a.c();
        break label207:
        if (paramInt2 == 0);
        try
        {
          int l = new JSONObject(paramString).getInt("retcode");
          if (-1 == l);
          a.a("MailSendedDataProcessing", "-8 == aResult");
          Activity localActivity2 = this.h;
          AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity2).setTitle(2131165465).setMessage(2131165466);
          ax localax = new ax(this);
          AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165467, localax);
          aw localaw = new aw(this);
          localBuilder2.setNegativeButton(2131165469, localaw).create().show();
        }
        catch (JSONException localJSONException2)
        {
          localJSONException2.printStackTrace();
          this.a.c();
        }
      }
    }
  }

  public void a(int paramInt, String paramString)
  {
    int l = 1;
    Object localObject1 = 0;
    Object localObject2 = "MailSendedDataProcessing";
    a.a((String)localObject2, paramString);
    label63: Object localObject3;
    try
    {
      localObject2 = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject2 != 0)
      {
        a.a("MailSendedDataProcessing", "Get NETWORK_ERROR");
        int i1 = this.f - l;
        this.f = i1;
        this.a.a("NETWORK_ERROR");
        return;
      }
      localObject2 = new ArrayList();
      this.d = ((ArrayList)localObject2);
      localObject2 = new ArrayList();
      this.e = ((ArrayList)localObject2);
      localObject3 = new StringBuilder("str.length()=");
      int i2 = paramString.length();
      localObject3 = i2;
      a.a("MailSendedDataProcessing", (String)localObject3);
      localObject2 = new JSONArray(paramString);
      localObject3 = ((JSONArray)localObject2).length();
      if (localObject3 != 0)
        break label249;
      int i3 = this.f - l;
      this.f = i3;
      this.k = true;
      Toast.makeText(this.h, 2131165472, 1).show();
      label249: this.a.b_();
    }
    catch (JSONException localJSONException)
    {
      StringBuilder localStringBuilder1 = new StringBuilder("JSONException");
      String str1 = localJSONException.toString();
      String str2 = str1;
      a.a("MailSendedDataProcessing", str2);
      this.a.c();
      break label63:
      for (localObject3 = localObject1; ; ++localObject3)
      {
        int i4 = ((JSONArray)localObject2).length();
        if (localObject3 >= i4)
        {
          this.a.b_();
          this.j.notifyDataSetChanged();
        }
        StringBuilder localStringBuilder2 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").toString()=");
        String str3 = ((JSONArray)localObject2).getJSONObject(localObject3).toString();
        String str4 = str3;
        a.a("MailSendedDataProcessing", str4);
        StringBuilder localStringBuilder3 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").getString(\"read_free\")=");
        String str5 = ((JSONArray)localObject2).getJSONObject(localObject3).getString("read_free");
        String str6 = str5;
        a.a("MailSendedDataProcessing", str6);
        as localas = new as();
        JSONObject localJSONObject = ((JSONArray)localObject2).getJSONObject(localObject3);
        String str7 = localJSONObject.getString("to_uid");
        localas.b = str7;
        String str8 = localJSONObject.getString("msg_id");
        localas.a = str8;
        String str9 = localJSONObject.getString("subject");
        localas.d = str9;
        int i5 = localJSONObject.getInt("to_status");
        localas.c = i5;
        String str10 = localJSONObject.getString("user_info_nickname");
        localas.g = str10;
        String str11 = localJSONObject.getString("user_info_detail");
        localas.f = str11;
        String str12 = localJSONObject.getString("read_free");
        localas.h = str12;
        int i6 = localJSONObject.getInt("rude_type");
        localas.e = i6;
        localas.j = null;
        localas.k = 1;
        localas.l = null;
        localas.m = 10;
        localas.o = 10;
        localas.n = 170;
        localas.p = null;
        localas.q = null;
        this.c.add(localas);
        ArrayList localArrayList = this.d;
        String str13 = localJSONObject.getString("to_uid");
        localArrayList.add(str13);
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailSendedDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    a.a("MailSendedDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailSendedDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    ListView localListView1 = this.i;
    au localau = new au(this);
    localListView1.setOnScrollListener(localau);
    ListView localListView2 = this.i;
    av localav = new av(this);
    localListView2.setOnItemSelectedListener(localav);
  }

  public void f()
  {
    Activity localActivity = this.h;
    ArrayList localArrayList = this.c;
    ad localad1 = new ad(this, localActivity, localArrayList);
    this.j = localad1;
    this.j.setNotifyOnChange(null);
    ListView localListView = this.i;
    ad localad2 = this.j;
    localListView.setAdapter(localad2);
    this.i.setOnItemClickListener(this);
  }

  public void g()
  {
    int l = 0;
    while (true)
    {
      int i1 = this.c.size();
      if (l >= i1)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((as)this.c.get(l)).q = true;
      l += 1;
    }
  }

  public void h()
  {
    ArrayList localArrayList = new ArrayList();
    int l = this.c.size() - 1;
    while (true)
    {
      if (l < 0)
      {
        this.j.notifyDataSetChanged();
        new v(this, "outbox", null, localArrayList).a();
        return;
      }
      if (((as)this.c.get(l)).q)
      {
        String str = ((as)this.c.get(l)).a;
        localArrayList.add(str);
        this.c.remove(l);
      }
      l += -1;
    }
  }

  public void i()
  {
    j();
  }

  public void j()
  {
    if (this.c != null)
      this.c.clear();
    if (this.d != null)
      this.d.clear();
    if (this.e != null)
      this.e.clear();
    this.f = 1;
    int l = this.f;
    int i1 = this.g;
    a(l, i1);
  }

  public void k()
  {
    int l = 0;
    int i1 = l;
    while (true)
    {
      int i2 = this.c.size();
      if (i1 >= i2)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((as)this.c.get(i1)).q = l;
      i1 += 1;
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str1 = "position=" + paramInt;
    a.a("MailSendedDataProcessing", str1);
    this.a.d();
    String str2 = ((as)this.c.get(paramInt)).a;
    new ag(this, paramInt, str2, "outbox").a();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.o
 * JD-Core Version:    0.5.4
 */