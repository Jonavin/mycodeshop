package com.jiayuan.mail;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

final class r
{
  CheckBox a;
  ImageView b;
  ImageView c;
  TextView d;
  TextView e;
  int f;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.r
 * JD-Core Version:    0.5.4
 */