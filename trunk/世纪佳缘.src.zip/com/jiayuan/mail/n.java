package com.jiayuan.mail;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.mail.other.SmsPay;

class n
  implements DialogInterface.OnClickListener
{
  n(ak paramak)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    Activity localActivity = ak.b(this.a);
    Intent localIntent = new Intent(localActivity, SmsPay.class);
    ak.b(this.a).startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.n
 * JD-Core Version:    0.5.4
 */