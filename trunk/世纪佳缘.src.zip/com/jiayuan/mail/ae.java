package com.jiayuan.mail;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.a.l;
import com.jiayuan.mail.detail.MailReadActivity;
import com.jiayuan.mail.detail.MailReadWebActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ae
  implements AdapterView.OnItemClickListener, com.jiayuan.a.q, com.jiayuan.mail.detail.b, q
{
  public ac a;
  private String b;
  private ArrayList c;
  private ArrayList d;
  private ArrayList e;
  private int f = 1;
  private int g = 10;
  private boolean h = null;
  private Activity i;
  private ListView j;
  private ag k;

  public ae(ac paramac, ListView paramListView)
  {
    Activity localActivity = (Activity)paramac;
    this.i = localActivity;
    this.j = paramListView;
    this.a = paramac;
    String str = o.e();
    this.b = str;
    ArrayList localArrayList = new ArrayList();
    this.c = localArrayList;
    if ((this.c == null) || (this.c.size() <= 0))
      return;
    f();
    e();
  }

  private void l()
  {
    a.a("MailUnreadDataProcessing", "loadRemainListItem loadRemainListItem");
    int l = this.f;
    int i1;
    ++i1;
    this.f = l;
    int i2 = this.f;
    int i3 = this.g;
    a(i2, i3);
  }

  public void a()
  {
  }

  public void a(int paramInt)
  {
    a.a("MailUnreadDataProcessing", "doPreReadForMail");
    this.a.d();
    String str = ((ab)this.c.get(paramInt)).a;
    new com.jiayuan.mail.detail.ag(this, paramInt, str, "inbox").a();
  }

  public void a(int paramInt1, int paramInt2)
  {
    int l = 1;
    a.a("MailUnreadDataProcessing", "execute()");
    if (this.h)
    {
      int i1 = this.f - l;
      this.f = i1;
      Toast.makeText(this.i, 2131165472, l).show();
    }
    while (true)
    {
      return;
      this.f = paramInt1;
      this.g = paramInt2;
      this.a.a();
      StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer.append("msg/list.php?");
      localStringBuffer.append("order=");
      localStringBuffer.append("1");
      localStringBuffer.append("&uid=");
      String str1 = o.e();
      localStringBuffer.append(str1);
      localStringBuffer.append("&token=");
      String str2 = o.f();
      localStringBuffer.append(str2);
      localStringBuffer.append("&p=");
      int i2 = this.f;
      localStringBuffer.append(i2);
      localStringBuffer.append("&page_size=");
      int i3 = this.g;
      localStringBuffer.append(i3);
      l locall = new l();
      locall.a = this;
      String str3 = localStringBuffer.toString();
      locall.b(str3);
    }
  }

  public void a(int paramInt1, int paramInt2, String paramString)
  {
    int l = 1;
    Object localObject = this.a;
    ((ac)localObject).e();
    if (l == paramInt2)
    {
      localObject = "MailUnreadDataProcessing";
      String str1 = "Goto mail read activity, position=" + paramInt1 + ", sResult=" + paramString;
      a.a((String)localObject, str1);
    }
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      localObject = (ab)this.c.get(paramInt1);
      String str2 = localJSONObject.getString("content");
      ((ab)localObject).i = str2;
      localObject = new Intent();
      String str3 = localJSONObject.getString("msg_id");
      ((Intent)localObject).putExtra("msg_id", str3);
      String str4 = localJSONObject.getString("from_uid");
      ((Intent)localObject).putExtra("uid", str4);
      ((Intent)localObject).putExtra("box_type", "inbox");
      String str5 = localJSONObject.getString("send_time");
      ((Intent)localObject).putExtra("send_time", str5);
      String str6 = localJSONObject.getString("content");
      ((Intent)localObject).putExtra("content", str6);
      if (s.b(localJSONObject.getString("from_uid")))
      {
        Activity localActivity1 = this.i;
        ((Intent)localObject).setClass(localActivity1, MailReadWebActivity.class);
        this.i.startActivity((Intent)localObject);
        this.a.f();
        if (((ab)this.c.get(paramInt1)).c == 0)
        {
          if (o.h > 0)
            label241: o.h -= l;
          this.c.remove(paramInt1);
          this.a.f();
          this.k.notifyDataSetChanged();
        }
        return;
      }
      Activity localActivity2 = this.i;
      ((Intent)localObject).setClass(localActivity2, MailReadActivity.class);
    }
    catch (JSONException localJSONException1)
    {
      while (true)
      {
        localJSONException1.printStackTrace();
        this.a.c();
        break label241:
        if (paramInt2 == 0);
        try
        {
          int i1 = new JSONObject(paramString).getInt("retcode");
          if (-1 == i1);
          a.a("MailUnreadDataProcessing", "-8 == aResult");
          Activity localActivity3 = this.i;
          AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity3).setTitle(2131165465).setMessage(2131165466);
          z localz = new z(this);
          AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165467, localz);
          aa localaa = new aa(this);
          localBuilder2.setNegativeButton(2131165469, localaa).create().show();
        }
        catch (JSONException localJSONException2)
        {
          localJSONException2.printStackTrace();
          this.a.c();
        }
      }
    }
  }

  public void a(int paramInt, String paramString)
  {
    int l = 10;
    int i1 = 1;
    Object localObject1 = 0;
    Object localObject2 = "MailUnreadDataProcessing";
    a.a((String)localObject2, paramString);
    label68: Object localObject3;
    try
    {
      localObject2 = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject2 != 0)
      {
        a.a("MailUnreadDataProcessing", "Get NETWORK_ERROR");
        int i2 = this.f - i1;
        this.f = i2;
        this.a.a("NETWORK_ERROR");
        return;
      }
      localObject2 = new ArrayList();
      this.d = ((ArrayList)localObject2);
      localObject2 = new ArrayList();
      this.e = ((ArrayList)localObject2);
      localObject3 = new StringBuilder("str.length()=");
      int i3 = paramString.length();
      localObject3 = i3;
      a.a("MailUnreadDataProcessing", (String)localObject3);
      localObject2 = new JSONArray(paramString);
      localObject3 = ((JSONArray)localObject2).length();
      if (localObject3 != 0)
        break label255;
      this.h = true;
      int i4 = this.f - i1;
      this.f = i4;
      Toast.makeText(this.i, 2131165472, 1).show();
      label255: this.a.b_();
    }
    catch (JSONException localJSONException)
    {
      this.a.c();
      StringBuilder localStringBuilder1 = new StringBuilder("JSONException");
      String str1 = localJSONException.toString();
      String str2 = str1;
      a.a("MailUnreadDataProcessing", str2);
      break label68:
      for (localObject3 = localObject1; ; ++localObject3)
      {
        int i5 = ((JSONArray)localObject2).length();
        if (localObject3 >= i5)
        {
          this.a.b_();
          if (this.k == null)
          {
            f();
            e();
          }
          this.k.notifyDataSetChanged();
          if (this.c.size() < l);
          o.h = this.c.size();
        }
        ab localab = new ab();
        JSONObject localJSONObject = ((JSONArray)localObject2).getJSONObject(localObject3);
        StringBuilder localStringBuilder2 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").toString()=");
        String str3 = ((JSONArray)localObject2).getJSONObject(localObject3).toString();
        String str4 = str3;
        a.a("MailUnreadDataProcessing", str4);
        StringBuilder localStringBuilder3 = new StringBuilder("arr.getJSONObject(").append(localObject3).append(").getInt(\"read_free\")=");
        int i6 = ((JSONArray)localObject2).getJSONObject(localObject3).getInt("read_free");
        String str5 = i6;
        a.a("MailUnreadDataProcessing", str5);
        String str6 = localJSONObject.getString("from_uid");
        localab.b = str6;
        String str7 = localJSONObject.getString("msg_id");
        localab.a = str7;
        String str8 = localJSONObject.getString("subject");
        localab.d = str8;
        int i7 = localJSONObject.getInt("to_status");
        localab.c = i7;
        String str9 = localJSONObject.getString("user_info_nickname");
        localab.g = str9;
        String str10 = localJSONObject.getString("user_info_detail");
        localab.f = str10;
        String str11 = localJSONObject.getString("read_free");
        localab.h = str11;
        int i8 = localJSONObject.getInt("rude_type");
        localab.e = i8;
        localab.j = null;
        localab.k = 1;
        localab.l = null;
        localab.m = 10;
        localab.o = 10;
        localab.n = 170;
        localab.p = null;
        localab.q = null;
        this.c.add(localab);
        ArrayList localArrayList = this.d;
        String str12 = localJSONObject.getString("from_uid");
        localArrayList.add(str12);
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailUnreadDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    a.a("MailUnreadDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailUnreadDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    ListView localListView1 = this.j;
    u localu = new u(this);
    localListView1.setOnScrollListener(localu);
    ListView localListView2 = this.j;
    w localw = new w(this);
    localListView2.setOnItemSelectedListener(localw);
  }

  public void f()
  {
    StringBuilder localStringBuilder1 = new StringBuilder("mData");
    ArrayList localArrayList1 = this.c;
    String str1 = localArrayList1;
    a.a("MailUnreadDataProcessing", str1);
    Activity localActivity = this.i;
    ArrayList localArrayList2 = this.c;
    ag localag1 = new ag(this, localActivity, localArrayList2);
    this.k = localag1;
    this.k.setNotifyOnChange(null);
    StringBuilder localStringBuilder2 = new StringBuilder("mAdapter");
    ag localag2 = this.k;
    String str2 = localag2;
    a.a("MailUnreadDataProcessing", str2);
    ListView localListView = this.j;
    ag localag3 = this.k;
    localListView.setAdapter(localag3);
    this.j.setOnItemClickListener(this);
  }

  public void g()
  {
    int l = 0;
    while (true)
    {
      int i1 = this.c.size();
      if (l >= i1)
      {
        this.k.notifyDataSetChanged();
        return;
      }
      ((ab)this.c.get(l)).q = true;
      l += 1;
    }
  }

  public void h()
  {
    int l = 1;
    ArrayList localArrayList = new ArrayList();
    int i1 = this.c.size() - l;
    while (true)
    {
      if (i1 < 0)
      {
        this.a.f();
        this.k.notifyDataSetChanged();
        new v(this, "inbox", null, localArrayList).a();
        return;
      }
      if (((ab)this.c.get(i1)).q)
      {
        String str = ((ab)this.c.get(i1)).a;
        localArrayList.add(str);
        this.c.remove(i1);
        if (o.h > 0)
          o.h -= l;
      }
      i1 += -1;
    }
  }

  public void i()
  {
    j();
  }

  public void j()
  {
    if (this.c != null)
      this.c.clear();
    if (this.d != null)
      this.d.clear();
    if (this.e != null)
      this.e.clear();
    this.f = 1;
    int l = this.f;
    int i1 = this.g;
    a(l, i1);
  }

  public void k()
  {
    int l = 0;
    int i1 = l;
    while (true)
    {
      int i2 = this.c.size();
      if (i1 >= i2)
      {
        this.k.notifyDataSetChanged();
        return;
      }
      ((ab)this.c.get(i1)).q = l;
      i1 += 1;
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    String str = "position=" + paramInt;
    a.a("MailUnreadDataProcessing", str);
    if (((ab)this.c.get(paramInt)).h.equalsIgnoreCase("1"))
      a(paramInt);
    while (true)
    {
      return;
      if (com.jiayuan.util.b.j(this.i).equalsIgnoreCase("1"))
        a(paramInt);
      Activity localActivity = this.i;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity).setTitle(2131165459).setMessage(2131165460);
      x localx = new x(this);
      AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165591, localx);
      y localy = new y(this, paramInt);
      localBuilder2.setNegativeButton(2131165454, localy).create().show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ae
 * JD-Core Version:    0.5.4
 */