package com.jiayuan.mail;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

final class ah
{
  CheckBox a;
  ImageView b;
  ImageView c;
  TextView d;
  TextView e;
  TextView f;
  int g;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ah
 * JD-Core Version:    0.5.4
 */