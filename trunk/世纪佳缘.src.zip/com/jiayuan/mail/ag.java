package com.jiayuan.mail;

import android.app.Activity;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

class ag extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  ag(ae paramae, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903064, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView)
  {
    int i = Integer.parseInt(paramView.getTag().toString());
    String str = "position=" + i;
    com.jiayuan.util.a.a("MailUnreadDataProcessing", str);
    ab localab = (ab)ae.a(this.b).get(i);
    boolean bool = ((ab)ae.a(this.b).get(i)).q;
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      localab.q = localObject;
      return;
      int j = 1;
    }
  }

  public void a(View paramView, int paramInt)
  {
    int i = 2130837672;
    int j = 0;
    t localt = (t)paramView.getTag();
    localt.g = paramInt;
    paramView.setTag(localt);
    if (((ab)ae.a(this.b).get(paramInt)).q)
    {
      CheckBox localCheckBox = localt.a;
      boolean bool = true;
      localCheckBox.setChecked(bool);
      switch (((ab)ae.a(this.b).get(paramInt)).c)
      {
      default:
        switch (((ab)ae.a(this.b).get(paramInt)).e)
        {
        default:
          label64: label108: localt.c.setImageResource(i);
          ImageView localImageView1 = localt.c;
          int k = 8;
          localImageView1.setVisibility(k);
          label187: Object localObject = localt.d;
          String str1 = ((ab)ae.a(this.b).get(paramInt)).f;
          ((TextView)localObject).setText(str1);
          localObject = ae.b(this.b).getResources();
          if (!((ab)ae.a(this.b).get(paramInt)).h.equalsIgnoreCase("1"))
            break label546;
          localt.f.setText(2131165453);
          TextView localTextView1 = localt.f;
          int i1 = ((Resources)localObject).getColor(2131034112);
          localTextView1.setTextColor(localObject);
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
      case 0:
      case 1:
      case 2:
      }
    }
    while (true)
    {
      TextView localTextView2 = localt.e;
      String str2 = ((ab)ae.a(this.b).get(paramInt)).g;
      localt.setText(str2);
      return;
      localt.a.setChecked(j);
      break label64:
      ImageView localImageView2 = localt.b;
      int l = 2130837655;
      localImageView2.setImageResource(l);
      break label108:
      ImageView localImageView3 = localt.b;
      l = 2130837651;
      localImageView3.setImageResource(l);
      break label108:
      ImageView localImageView4 = localt.b;
      l = 2130837652;
      localImageView4.setImageResource(l);
      break label108:
      localt.c.setVisibility(j);
      ImageView localImageView5 = localt.c;
      l = 2130837665;
      localImageView5.setImageResource(l);
      break label187:
      localt.c.setVisibility(j);
      ImageView localImageView6 = localt.c;
      l = 2130837653;
      localImageView6.setImageResource(l);
      break label187:
      localt.c.setVisibility(j);
      ImageView localImageView7 = localt.c;
      l = 2130837671;
      localImageView7.setImageResource(l);
      break label187:
      localt.c.setVisibility(j);
      ImageView localImageView8 = localt.c;
      l = 2130837650;
      localImageView8.setImageResource(l);
      break label187:
      localt.c.setVisibility(j);
      localt.c.setImageResource(i);
      break label187:
      label546: localt.f.setText(2131165454);
      TextView localTextView3 = localt.f;
      int i2 = l.getColor(2131034113);
      localTextView3.setTextColor(l);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903064, paramViewGroup, null);
      t localt = new t(null);
      CheckBox localCheckBox1 = (CheckBox)localView.findViewById(2131361921);
      localt.a = localCheckBox1;
      ImageView localImageView1 = (ImageView)localView.findViewById(2131361922);
      localt.b = localImageView1;
      ImageView localImageView2 = (ImageView)localView.findViewById(2131361924);
      localt.c = localImageView2;
      TextView localTextView1 = (TextView)localView.findViewById(2131361926);
      localt.d = localTextView1;
      TextView localTextView2 = (TextView)localView.findViewById(2131361925);
      localt.e = localTextView2;
      TextView localTextView3 = (TextView)localView.findViewById(2131361927);
      localt.f = localTextView3;
      localView.setTag(localt);
    }
    while (true)
    {
      CheckBox localCheckBox2 = ((t)localView.getTag()).a;
      Integer localInteger = Integer.valueOf(paramInt);
      localCheckBox2.setTag(localInteger);
      CheckBox localCheckBox3 = ((t)localView.getTag()).a;
      a locala = new a(this);
      localCheckBox3.setOnClickListener(locala);
      a(localView, paramInt);
      return localView;
      localView = paramView;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    t localt = (t)((View)paramView.getTag()).getTag();
    com.jiayuan.util.a.a("MailUnreadDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ag
 * JD-Core Version:    0.5.4
 */