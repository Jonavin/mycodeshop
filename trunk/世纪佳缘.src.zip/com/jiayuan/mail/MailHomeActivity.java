package com.jiayuan.mail;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager.BadTokenException;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.mail.detail.af;
import com.jiayuan.mail.detail.g;
import com.jiayuan.setting.SettingActivity;
import com.jiayuan.util.a;

public class MailHomeActivity extends Activity
  implements ac, al, aq, af, h
{
  private ListView a;
  private ae b;
  private ak c;
  private o d;
  private at e;
  private Button f;
  private Button g;
  private Button h;
  private Button i;
  private int j = null;
  private boolean k = null;
  private ProgressDialog l;

  private void k()
  {
    a.a("MailHomeActivity", "Mail home unread button clicked");
    ListView localListView = this.a;
    ae localae = new ae(this, localListView);
    this.b = localae;
    this.b.a(1, 10);
    this.j = null;
    Button localButton = this.f;
    a(localButton);
    this.k = null;
    new g(this).a();
  }

  private void l()
  {
    a.a("MailHomeActivity", "Mail home receive all button clicked");
    ListView localListView = this.a;
    ak localak = new ak(this, localListView);
    this.c = localak;
    this.c.a(1, 10);
    this.j = 1;
    Button localButton = this.g;
    a(localButton);
    this.k = null;
    new g(this).a();
  }

  private void m()
  {
    a.a("MailHomeActivity", "Mail home sended button clicked");
    ListView localListView = this.a;
    o localo = new o(this, localListView);
    this.d = localo;
    this.d.a(1, 10);
    this.j = 2;
    Button localButton = this.h;
    a(localButton);
    this.k = null;
  }

  private void n()
  {
    a.a("MailHomeActivity", "Mail home system button clicked");
    ListView localListView = this.a;
    at localat = new at(this, localListView);
    this.e = localat;
    this.e.a(1, 10);
    this.j = 3;
    Button localButton = this.i;
    a(localButton);
    this.k = null;
  }

  private void o()
  {
    switch (this.j)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      this.b.k();
      continue;
      this.c.k();
      continue;
      this.d.k();
      continue;
      this.e.j();
    }
  }

  public void a()
  {
    a.a("MailHomeActivity", "---------onWaitingActivityStart()---------");
    String str = getResources().getString(2131165471);
    ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
    this.l = localProgressDialog;
    this.l.setCancelable(true);
  }

  public void a(Button paramButton)
  {
    this.f.setEnabled(true);
    this.g.setEnabled(true);
    this.h.setEnabled(true);
    this.i.setEnabled(true);
    paramButton.setEnabled(null);
  }

  public void a(String paramString)
  {
    this.l.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
  }

  public void b(int paramInt)
  {
    a.a("MailHomeActivity", "onGetUnreadMailCount");
    com.jiayuan.util.o.h = paramInt;
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = getResources().getString(2131165448);
    localStringBuffer.append(str1);
    localStringBuffer.append("(");
    int i1 = com.jiayuan.util.o.h;
    localStringBuffer.append(i1);
    localStringBuffer.append(")");
    Button localButton = this.f;
    String str2 = localStringBuffer.toString();
    localButton.setText(str2);
    MainActivity.a();
  }

  public void b_()
  {
    a.a("MailHomeActivity", "---------onWaitingActivityFinish()---------");
    this.l.dismiss();
  }

  public void c()
  {
    this.l.dismiss();
  }

  public void d()
  {
    try
    {
      String str = getResources().getString(2131165447);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.l = localProgressDialog;
      this.l.setCancelable(true);
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void e()
  {
    this.l.dismiss();
  }

  public void f()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = getResources().getString(2131165448);
    localStringBuffer.append(str1);
    localStringBuffer.append("(");
    int i1 = com.jiayuan.util.o.h;
    localStringBuffer.append(i1);
    localStringBuffer.append(")");
    Button localButton = this.f;
    String str2 = localStringBuffer.toString();
    localButton.setText(str2);
    MainActivity.a();
  }

  public void g()
  {
    switch (this.j)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      this.b.g();
      continue;
      this.c.g();
      continue;
      this.d.g();
      continue;
      this.e.f();
    }
  }

  public void h()
  {
    switch (this.j)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      this.b.h();
      continue;
      this.c.h();
      continue;
      this.d.h();
      continue;
      this.e.g();
    }
  }

  public void i()
  {
    switch (this.j)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      this.b.j();
      continue;
      this.c.j();
      continue;
      this.d.j();
      continue;
      this.e.h();
    }
  }

  public void j()
  {
    a.a("MailHomeActivity", "Goto setting activity");
    Intent localIntent = new Intent(this, SettingActivity.class);
    startActivity(localIntent);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903054);
    if ((com.jiayuan.util.o.a == null) || (com.jiayuan.util.o.a.equals("")));
    while (true)
    {
      return;
      Button localButton1 = (Button)findViewById(2131361856);
      this.f = localButton1;
      Button localButton2 = this.f;
      ap localap = new ap(this);
      localButton2.setOnClickListener(localap);
      Button localButton3 = (Button)findViewById(2131361857);
      this.g = localButton3;
      Button localButton4 = this.g;
      ao localao = new ao(this);
      localButton4.setOnClickListener(localao);
      Button localButton5 = (Button)findViewById(2131361858);
      this.h = localButton5;
      Button localButton6 = this.h;
      an localan = new an(this);
      localButton6.setOnClickListener(localan);
      Button localButton7 = (Button)findViewById(2131361859);
      this.i = localButton7;
      Button localButton8 = this.i;
      am localam = new am(this);
      localButton8.setOnClickListener(localam);
      ListView localListView = (ListView)findViewById(2131361860);
      this.a = localListView;
      l();
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    a.a("MailHomeAcitivty", "onCreateOptionsMenu");
    getMenuInflater().inflate(2131296257, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    a.a("MailHomeActivity", "back key pressed");
    boolean bool1 = MainActivity.a(this, paramInt, paramKeyEvent);
    int i1;
    if (bool1)
    {
      a.a("MailHomeActivity", "back key pressed 000");
      i1 = 1;
    }
    while (true)
    {
      return i1;
      a.a("MailHomeActivity", "back key pressed 111");
      boolean bool2 = super.onKeyDown(paramInt, paramKeyEvent);
    }
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    Object localObject = null;
    int i1 = 1;
    int i2 = paramMenuItem.getItemId();
    boolean bool;
    switch (i2)
    {
    default:
      bool = super.onOptionsItemSelected(paramMenuItem);
    case 2131362244:
    case 2131362245:
    case 2131362246:
    case 2131362247:
    }
    while (true)
    {
      label51: return bool;
      bool = this.k;
      if (!bool)
      {
        g();
        i3 = 2131165649;
        paramMenuItem.setTitle(i3);
      }
      for (this.k = i1; ; this.k = localObject)
      {
        i3 = i1;
        break label51:
        o();
        i3 = 2131165648;
        paramMenuItem.setTitle(i3);
      }
      h();
      int i3 = i1;
      continue;
      i();
      this.k = localObject;
      i3 = i1;
      continue;
      j();
      i3 = i1;
    }
  }

  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    MenuItem localMenuItem = paramMenu.getItem(0);
    boolean bool1 = this.k;
    if (bool1)
    {
      int i1 = 2131165649;
      label21: localMenuItem.setTitle(i1);
      boolean bool2 = this.k;
      if (!bool2)
        break label63;
    }
    for (int i2 = 2130837668; ; i2 = 2130837647)
    {
      localMenuItem.setIcon(i2);
      return super.onPrepareOptionsMenu(paramMenu);
      i2 = 2131165648;
      label63: break label21:
    }
  }

  public void onStart()
  {
    super.onStart();
    if ((com.jiayuan.util.o.a == null) || (com.jiayuan.util.o.a.equals("")));
    while (true)
    {
      return;
      a.a("MailHomeActivity", "onStart");
      StringBuffer localStringBuffer = new StringBuffer();
      String str1 = getResources().getString(2131165448);
      localStringBuffer.append(str1);
      localStringBuffer.append("(");
      int i1 = com.jiayuan.util.o.h;
      localStringBuffer.append(i1);
      localStringBuffer.append(")");
      Button localButton = this.f;
      String str2 = localStringBuffer.toString();
      localButton.setText(str2);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.MailHomeActivity
 * JD-Core Version:    0.5.4
 */