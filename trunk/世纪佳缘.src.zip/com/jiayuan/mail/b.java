package com.jiayuan.mail;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.util.a;

class b
  implements DialogInterface.OnClickListener
{
  b(at paramat)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.a("MailSystemDataProcessing", "who_looked_me_cancel");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.b
 * JD-Core Version:    0.5.4
 */