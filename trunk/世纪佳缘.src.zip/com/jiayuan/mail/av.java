package com.jiayuan.mail;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;

class av
  implements AdapterView.OnItemSelectedListener
{
  av(o paramo)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    a.a("MailSendedDataProcessing", "OnItemSelectedListener onItemSelected!!!!!!!!!!!!!!!");
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
    a.a("MailSendedDataProcessing", "OnItemSelectedListener onNothingSelected@@@@@@@@@@@");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.av
 * JD-Core Version:    0.5.4
 */