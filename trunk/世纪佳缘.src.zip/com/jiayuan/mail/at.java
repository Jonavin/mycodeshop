package com.jiayuan.mail;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import com.jiayuan.a.l;
import com.jiayuan.a.u;
import com.jiayuan.mail.other.LocationActivity;
import com.jiayuan.mail.other.SystemMailReadActivity;
import com.jiayuan.mail.other.WhoLookedMeActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class at
  implements AdapterView.OnItemClickListener, com.jiayuan.a.c, com.jiayuan.a.q, q
{
  public h a;
  private String b;
  private ArrayList c;
  private int d = 1;
  private int e = 10;
  private final int f = null;
  private final int g = 1;
  private Activity h;
  private ListView i;
  private f j;
  private boolean k = null;

  public at(h paramh, ListView paramListView)
  {
    Activity localActivity = (Activity)paramh;
    this.h = localActivity;
    this.i = paramListView;
    this.a = paramh;
    String str = o.e();
    this.b = str;
    ArrayList localArrayList = new ArrayList();
    this.c = localArrayList;
    e();
    a();
  }

  private void k()
  {
    a.a("MailSystemDataProcessing", "loadRemainListItem loadRemainListItem");
    int l = this.d;
    int i1;
    ++i1;
    this.d = l;
    int i2 = this.d;
    int i3 = this.e;
    a(i2, i3);
  }

  public void a()
  {
    ListView localListView1 = this.i;
    d locald = new d(this);
    localListView1.setOnScrollListener(locald);
    ListView localListView2 = this.i;
    e locale = new e(this);
    localListView2.setOnItemSelectedListener(locale);
  }

  public void a(int paramInt1, int paramInt2)
  {
    int l = 1;
    a.a("MailSystemDataProcessing", "execute()");
    if (this.k)
    {
      int i1 = this.d - l;
      this.d = i1;
      Toast.makeText(this.h, 2131165472, l).show();
    }
    while (true)
    {
      return;
      this.d = paramInt1;
      this.e = paramInt2;
      this.a.a();
      StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
      localStringBuffer.append("msg/listadm.php?");
      localStringBuffer.append("uid=");
      String str1 = o.e();
      localStringBuffer.append(str1);
      localStringBuffer.append("&token=");
      String str2 = o.f();
      localStringBuffer.append(str2);
      localStringBuffer.append("&p=");
      int i2 = this.d;
      localStringBuffer.append(i2);
      localStringBuffer.append("&page_size=");
      int i3 = this.e;
      localStringBuffer.append(i3);
      l locall = new l();
      locall.a = this;
      String str3 = localStringBuffer.toString();
      locall.b(str3);
    }
  }

  public void a(int paramInt, String paramString)
  {
    Toast localToast1 = 0;
    int l = 1;
    Object localObject1 = "MailSystemDataProcessing";
    a.a((String)localObject1, paramString);
    label61: Object localObject2;
    Toast localToast2;
    try
    {
      localObject1 = paramString.equalsIgnoreCase("NETWORK_ERROR");
      if (localObject1 != 0)
      {
        a.a("MailSystemDataProcessing", "Get NETWORK_ERROR");
        int i2 = this.d - l;
        this.d = i2;
        this.a.a("NETWORK_ERROR");
        return;
      }
      int i1 = this.d;
      if (l == i1)
      {
        localObject2 = new ar();
        ((ar)localObject2).a = "";
        ((ar)localObject2).c = "";
        localObject3 = this.h.getString(2131165461);
        ((ar)localObject2).b = ((String)localObject3);
        localObject3 = this.h.getString(2131165462);
        ((ar)localObject2).d = ((String)localObject3);
        ((ar)localObject2).e = 1;
        ((ar)localObject2).f = null;
        this.c.add(localObject2);
        localObject2 = new ar();
        ((ar)localObject2).a = "";
        ((ar)localObject2).c = "";
        localObject3 = this.h.getString(2131165463);
        ((ar)localObject2).b = ((String)localObject3);
        localObject3 = this.h.getString(2131165464);
        ((ar)localObject2).d = ((String)localObject3);
        ((ar)localObject2).e = 1;
        ((ar)localObject2).f = null;
        localObject3 = this.c;
        ((ArrayList)localObject3).add(localObject2);
      }
      localObject2 = new JSONObject(paramString).getJSONArray("msg_list");
      Object localObject3 = ((JSONArray)localObject2).length();
      if (localObject3 == 0)
      {
        int i3 = this.d - l;
        this.d = i3;
        this.k = true;
        localToast2 = Toast.makeText(this.h, 2131165472, 1);
        localToast2.show();
      }
      localToast2 = localToast1;
      label308: int i4 = ((JSONArray)localObject2).length();
      if (localToast2 < i4)
        break label392;
      this.a.b_();
      label392: this.j.notifyDataSetChanged();
    }
    catch (JSONException localJSONException)
    {
      StringBuilder localStringBuilder = new StringBuilder("JSONException");
      String str1 = localJSONException.toString();
      String str2 = str1;
      a.a("MailSystemDataProcessing", str2);
      this.a.c();
      break label61:
      ar localar = new ar();
      String str3 = ((JSONArray)localObject2).getJSONObject(localToast2).getString("from_uid");
      localar.a = str3;
      String str4 = ((JSONArray)localObject2).getJSONObject(localToast2).getString("msg_id");
      localar.c = str4;
      String str5 = ((JSONArray)localObject2).getJSONObject(localToast2).getString("subject");
      localar.b = str5;
      String str6 = ((JSONArray)localObject2).getJSONObject(localToast2).getString("nickname");
      localar.d = str6;
      int i5 = ((JSONArray)localObject2).getJSONObject(localToast2).getInt("to_status");
      localar.e = i5;
      localar.f = null;
      this.c.add(localar);
      ++localToast2;
      break label308:
    }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    try
    {
      if (!s.a(paramJSONArray))
        break label124;
      if (paramInt == 0)
      {
        Intent localIntent1 = new Intent();
        String str1 = o.e();
        localIntent1.putExtra("uid", str1);
        Activity localActivity1 = this.h;
        localIntent1.setClass(localActivity1, WhoLookedMeActivity.class);
        this.h.startActivity(localIntent1);
      }
      do
        label58: return;
      while (1 != paramInt);
      Intent localIntent2 = new Intent();
      String str2 = o.e();
      localIntent2.putExtra("uid", str2);
      Activity localActivity2 = this.h;
      localIntent2.setClass(localActivity2, LocationActivity.class);
      label124: this.h.startActivity(localIntent2);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      break label58:
      Activity localActivity3 = this.h;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localActivity3).setIcon(2130837504).setTitle(2131165543).setMessage(2131165544);
      b localb = new b(this);
      AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165545, localb);
      c localc = new c(this);
      localBuilder2.setNegativeButton(2131165546, localc).create().show();
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    a.a("MailSystemDataProcessing", "onProgressUpdate()");
  }

  public void a_(String paramString)
  {
    this.a.a(paramString);
  }

  public void b()
  {
    a.a("MailSystemDataProcessing", "onCancelled()");
  }

  public void c()
  {
    a.a("MailSystemDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }

  public void e()
  {
    Activity localActivity = this.h;
    ArrayList localArrayList = this.c;
    f localf1 = new f(this, localActivity, localArrayList);
    this.j = localf1;
    this.j.setNotifyOnChange(null);
    ListView localListView = this.i;
    f localf2 = this.j;
    localListView.setAdapter(localf2);
    this.i.setOnItemClickListener(this);
  }

  public void f()
  {
    a.a("MailSystemDataProcessing", "selectAll");
    int l = 0;
    while (true)
    {
      int i1 = this.c.size();
      if (l >= i1)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((ar)this.c.get(l)).f = true;
      l += 1;
    }
  }

  public void g()
  {
    int l = 1;
    ArrayList localArrayList = new ArrayList();
    int i1 = this.c.size() - l;
    while (true)
    {
      if (i1 < 0)
      {
        this.j.notifyDataSetChanged();
        new v(this, "inbox", l, localArrayList).a();
        return;
      }
      if (((ar)this.c.get(i1)).f)
      {
        String str = ((ar)this.c.get(i1)).c;
        localArrayList.add(str);
        this.c.remove(i1);
      }
      i1 += -1;
    }
  }

  public void h()
  {
    if (this.c != null)
      this.c.clear();
    this.d = 1;
    int l = this.d;
    int i1 = this.e;
    a(l, i1);
  }

  public void i()
  {
    h();
  }

  public void j()
  {
    int l = 0;
    a.a("MailSystemDataProcessing", "invertAll");
    int i1 = l;
    while (true)
    {
      int i2 = this.c.size();
      if (i1 >= i2)
      {
        this.j.notifyDataSetChanged();
        return;
      }
      ((ar)this.c.get(i1)).f = l;
      i1 += 1;
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int l = 1;
    String str1 = "position=" + paramInt;
    a.a("MailSystemDataProcessing", str1);
    if (paramInt == 0)
    {
      String str2 = o.e();
      new u(this, str2, 0).a();
    }
    while (true)
    {
      return;
      if (l == paramInt)
      {
        Intent localIntent1 = new Intent();
        String str3 = o.e();
        localIntent1.putExtra("uid", str3);
        Activity localActivity1 = this.h;
        localIntent1.setClass(localActivity1, LocationActivity.class);
        this.h.startActivity(localIntent1);
      }
      Intent localIntent2 = new Intent();
      String str4 = ((ar)this.c.get(paramInt)).c;
      localIntent2.putExtra("msg_id", str4);
      Activity localActivity2 = this.h;
      localIntent2.setClass(localActivity2, SystemMailReadActivity.class);
      this.h.startActivity(localIntent2);
      ((ar)this.c.get(paramInt)).e = l;
      this.j.notifyDataSetChanged();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.at
 * JD-Core Version:    0.5.4
 */