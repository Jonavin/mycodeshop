package com.jiayuan.mail;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;

class w
  implements AdapterView.OnItemSelectedListener
{
  w(ae paramae)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    a.a("MailUnreadDataProcessing", "OnItemSelectedListener onItemSelected!!!!!!!!!!!!!!!");
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
    a.a("MailUnreadDataProcessing", "OnItemSelectedListener onNothingSelected@@@@@@@@@@@");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.w
 * JD-Core Version:    0.5.4
 */