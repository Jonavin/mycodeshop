package com.jiayuan.mail;

public abstract interface q
{
  public abstract void a_(String paramString);

  public abstract void d();

  public abstract void i();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.q
 * JD-Core Version:    0.5.4
 */