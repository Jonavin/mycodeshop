package com.jiayuan.mail;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;

class e
  implements AdapterView.OnItemSelectedListener
{
  e(at paramat)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    a.a("MailSystemDataProcessing", "OnItemSelectedListener onItemSelected!!!!!!!!!!!!!!!");
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
    a.a("MailSystemDataProcessing", "OnItemSelectedListener onNothingSelected@@@@@@@@@@@");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.e
 * JD-Core Version:    0.5.4
 */