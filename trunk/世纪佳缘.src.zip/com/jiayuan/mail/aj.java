package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class aj
  implements View.OnClickListener
{
  aj(ai paramai)
  {
  }

  public void onClick(View paramView)
  {
    this.a.a(paramView);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.aj
 * JD-Core Version:    0.5.4
 */