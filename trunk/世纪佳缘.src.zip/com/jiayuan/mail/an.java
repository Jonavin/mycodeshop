package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class an
  implements View.OnClickListener
{
  an(MailHomeActivity paramMailHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailHomeActivity.c(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.an
 * JD-Core Version:    0.5.4
 */