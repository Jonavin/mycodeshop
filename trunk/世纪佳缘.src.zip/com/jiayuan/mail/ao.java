package com.jiayuan.mail;

import android.view.View;
import android.view.View.OnClickListener;

class ao
  implements View.OnClickListener
{
  ao(MailHomeActivity paramMailHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    MailHomeActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ao
 * JD-Core Version:    0.5.4
 */