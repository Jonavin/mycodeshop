package com.jiayuan.mail;

import android.app.Activity;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class ai extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  ai(ak paramak, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903059, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView)
  {
    int i = Integer.parseInt(paramView.getTag().toString());
    String str = "position=" + i;
    a.a("MailRecvAllDataProcessing", str);
    af localaf = (af)ak.a(this.b).get(i);
    boolean bool = ((af)ak.a(this.b).get(i)).q;
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      localaf.q = localObject;
      return;
      int j = 1;
    }
  }

  public void a(View paramView, int paramInt)
  {
    int i = 2130837672;
    int j = 0;
    ah localah = (ah)paramView.getTag();
    localah.g = paramInt;
    paramView.setTag(localah);
    if (((af)ak.a(this.b).get(paramInt)).q)
    {
      CheckBox localCheckBox = localah.a;
      boolean bool = true;
      localCheckBox.setChecked(bool);
      switch (((af)ak.a(this.b).get(paramInt)).c)
      {
      default:
        switch (((af)ak.a(this.b).get(paramInt)).e)
        {
        default:
          label64: label108: localah.c.setImageResource(i);
          ImageView localImageView1 = localah.c;
          int k = 8;
          localImageView1.setVisibility(k);
          label187: Object localObject = localah.d;
          String str1 = ((af)ak.a(this.b).get(paramInt)).f;
          ((TextView)localObject).setText(str1);
          localObject = ak.b(this.b).getResources();
          if (!((af)ak.a(this.b).get(paramInt)).h.equalsIgnoreCase("1"))
            break label546;
          localah.f.setText(2131165453);
          TextView localTextView1 = localah.f;
          int i1 = ((Resources)localObject).getColor(2131034112);
          localTextView1.setTextColor(localObject);
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
      case 0:
      case 1:
      case 2:
      }
    }
    while (true)
    {
      TextView localTextView2 = localah.e;
      String str2 = ((af)ak.a(this.b).get(paramInt)).g;
      localah.setText(str2);
      return;
      localah.a.setChecked(j);
      break label64:
      ImageView localImageView2 = localah.b;
      int l = 2130837655;
      localImageView2.setImageResource(l);
      break label108:
      ImageView localImageView3 = localah.b;
      l = 2130837651;
      localImageView3.setImageResource(l);
      break label108:
      ImageView localImageView4 = localah.b;
      l = 2130837652;
      localImageView4.setImageResource(l);
      break label108:
      localah.c.setVisibility(j);
      ImageView localImageView5 = localah.c;
      l = 2130837665;
      localImageView5.setImageResource(l);
      break label187:
      localah.c.setVisibility(j);
      ImageView localImageView6 = localah.c;
      l = 2130837653;
      localImageView6.setImageResource(l);
      break label187:
      localah.c.setVisibility(j);
      ImageView localImageView7 = localah.c;
      l = 2130837671;
      localImageView7.setImageResource(l);
      break label187:
      localah.c.setVisibility(j);
      ImageView localImageView8 = localah.c;
      l = 2130837650;
      localImageView8.setImageResource(l);
      break label187:
      localah.c.setVisibility(j);
      localah.c.setImageResource(i);
      break label187:
      label546: localah.f.setText(2131165454);
      TextView localTextView3 = localah.f;
      int i2 = l.getColor(2131034113);
      localTextView3.setTextColor(l);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903059, paramViewGroup, null);
      ah localah = new ah(null);
      CheckBox localCheckBox1 = (CheckBox)localView.findViewById(2131361883);
      localah.a = localCheckBox1;
      ImageView localImageView1 = (ImageView)localView.findViewById(2131361884);
      localah.b = localImageView1;
      ImageView localImageView2 = (ImageView)localView.findViewById(2131361886);
      localah.c = localImageView2;
      TextView localTextView1 = (TextView)localView.findViewById(2131361888);
      localah.d = localTextView1;
      TextView localTextView2 = (TextView)localView.findViewById(2131361887);
      localah.e = localTextView2;
      TextView localTextView3 = (TextView)localView.findViewById(2131361889);
      localah.f = localTextView3;
      localView.setTag(localah);
    }
    while (true)
    {
      CheckBox localCheckBox2 = ((ah)localView.getTag()).a;
      Integer localInteger = Integer.valueOf(paramInt);
      localCheckBox2.setTag(localInteger);
      CheckBox localCheckBox3 = ((ah)localView.getTag()).a;
      aj localaj = new aj(this);
      localCheckBox3.setOnClickListener(localaj);
      a(localView, paramInt);
      return localView;
      localView = paramView;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    ah localah = (ah)((View)paramView.getTag()).getTag();
    a.a("MailRecvAllDataProcessing", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.ai
 * JD-Core Version:    0.5.4
 */