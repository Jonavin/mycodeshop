package com.jiayuan.mail;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

final class s
{
  CheckBox a;
  ImageView b;
  TextView c;
  TextView d;
  int e;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mail.s
 * JD-Core Version:    0.5.4
 */