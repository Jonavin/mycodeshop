package com.jiayuan.home;

import android.view.View;
import android.view.View.OnClickListener;

class f
  implements View.OnClickListener
{
  f(HomeActivity paramHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    HomeActivity.e(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.f
 * JD-Core Version:    0.5.4
 */