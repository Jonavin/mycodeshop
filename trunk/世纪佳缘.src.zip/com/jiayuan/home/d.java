package com.jiayuan.home;

import android.view.View;
import android.view.View.OnClickListener;

class d
  implements View.OnClickListener
{
  d(HomeActivity paramHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    HomeActivity.a(this.a, 3);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.d
 * JD-Core Version:    0.5.4
 */