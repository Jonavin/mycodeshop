package com.jiayuan.home;

import android.view.View;
import android.view.View.OnClickListener;

class e
  implements View.OnClickListener
{
  e(HomeActivity paramHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    HomeActivity.f(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.e
 * JD-Core Version:    0.5.4
 */