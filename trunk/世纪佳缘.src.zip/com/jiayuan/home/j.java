package com.jiayuan.home;

import android.widget.ImageView;

public final class j
{
  public ImageView a;
  public ImageView b;

  public j(HomeActivity paramHomeActivity)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.j
 * JD-Core Version:    0.5.4
 */