package com.jiayuan.home;

import android.view.View;
import android.view.View.OnClickListener;

class c
  implements View.OnClickListener
{
  c(HomeActivity paramHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    HomeActivity.a(this.a, 4);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.c
 * JD-Core Version:    0.5.4
 */