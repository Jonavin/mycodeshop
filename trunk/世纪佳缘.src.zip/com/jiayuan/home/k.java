package com.jiayuan.home;

import android.graphics.Bitmap;
import java.util.List;

public abstract interface k
{
  public abstract void a();

  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a(String paramString);

  public abstract void a(List paramList);

  public abstract void b();

  public abstract void c();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.k
 * JD-Core Version:    0.5.4
 */