package com.jiayuan.home;

import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(HomeActivity paramHomeActivity)
  {
  }

  public void onClick(View paramView)
  {
    HomeActivity.a(this.a, 0);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.g
 * JD-Core Version:    0.5.4
 */