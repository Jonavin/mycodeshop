package com.jiayuan.home;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.jiayuan.register.RegisterType;

class b
  implements AdapterView.OnItemClickListener
{
  b(HomeActivity paramHomeActivity)
  {
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    Intent localIntent = new Intent();
    HomeActivity localHomeActivity = this.a;
    localIntent.setClass(localHomeActivity, RegisterType.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.b
 * JD-Core Version:    0.5.4
 */