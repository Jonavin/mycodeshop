package com.jiayuan.home;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.o;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class m
  implements com.jiayuan.a.p, q
{
  public k a;
  private List b;
  private Context c;
  private int d;
  private int e;
  private int f;
  private int g;

  public m(k paramk, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramk;
    Activity localActivity = (Activity)paramk;
    this.c = paramk;
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
    this.g = paramInt4;
  }

  public void a()
  {
    com.jiayuan.util.a.a("HomeDataProcessing", "execute()");
    this.a.a();
    StringBuffer localStringBuffer1 = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer1.append("uic/vipinfo.php?");
    StringBuffer localStringBuffer2 = localStringBuffer1.append("channelid=");
    String str1 = o.c();
    localStringBuffer2.append(str1);
    StringBuffer localStringBuffer3 = localStringBuffer1.append("&clientid=");
    String str2 = o.b();
    localStringBuffer3.append(str2);
    StringBuffer localStringBuffer4 = localStringBuffer1.append("&deviceid=");
    String str3 = o.b(this.c);
    localStringBuffer4.append(str3);
    StringBuffer localStringBuffer5 = localStringBuffer1.append("&sysver=");
    String str4 = o.d();
    localStringBuffer5.append(str4);
    StringBuffer localStringBuffer6 = localStringBuffer1.append("&width=");
    int i = this.d;
    localStringBuffer6.append(i);
    StringBuffer localStringBuffer7 = localStringBuffer1.append("&height=");
    int j = this.e;
    localStringBuffer7.append(j);
    StringBuffer localStringBuffer8 = localStringBuffer1.append("&token=");
    String str5 = String.valueOf(o.b(this.c));
    StringBuilder localStringBuilder = new StringBuilder(str5).append("mobilejiayuan");
    String str6 = o.b();
    String str7 = com.jiayuan.util.p.a(str6);
    localStringBuffer8.append(str7);
    l locall = new l();
    locall.a = this;
    String str8 = localStringBuffer1.toString();
    locall.b(str8);
  }

  public void a(int paramInt, String paramString)
  {
    Object localObject1 = 0;
    Object localObject2 = "onPostExecute()";
    com.jiayuan.util.a.a("HomeDataProcessing", (String)localObject2);
    boolean bool = paramString.equals("NETWORK_ERROR");
    if (bool)
      this.a.a(paramString);
    while (true)
    {
      label36: return;
      try
      {
        Object localObject3 = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = ((JSONObject)localObject3).toString();
        String str2 = str1;
        com.jiayuan.util.a.a("HomeDataProcessing", str2);
        localObject2 = new ArrayList();
        this.b = ((List)localObject2);
        localObject3 = ((JSONObject)localObject3).getJSONArray("vip");
        localObject2 = localObject1;
        int j = ((JSONArray)localObject3).length();
        int i;
        if (localObject2 >= j)
        {
          this.a.b();
          k localk = this.a;
          localObject2 = this.b;
          localk.a((List)localObject2);
          localObject2 = localObject1;
          while (true)
          {
            int k = this.b.size();
            if (localObject2 < k);
            StringBuffer localStringBuffer = new StringBuffer("http://watermark.jiayuan.com/partner/i/vip_user_pic_change.php?url=");
            String str3 = ((a)this.b.get(localObject2)).b;
            localStringBuffer.append(str3);
            localStringBuffer.append("&width=");
            localStringBuffer.append(210);
            localStringBuffer.append("&height=");
            localStringBuffer.append(280);
            localStringBuffer.append("&qulity=");
            localStringBuffer.append(90);
            com.jiayuan.a.m localm = new com.jiayuan.a.m();
            Object[] arrayOfObject = new Object[7];
            String str4 = localStringBuffer.toString();
            arrayOfObject[0] = str4;
            arrayOfObject[1] = this;
            Integer localInteger = Integer.valueOf(localObject2);
            arrayOfObject[2] = localInteger;
            StringBuilder localStringBuilder2 = new StringBuilder();
            int l = this.f;
            String str5 = l;
            arrayOfObject[3] = str5;
            StringBuilder localStringBuilder3 = new StringBuilder();
            int i1 = this.g;
            localObject1 += 12;
            String str6 = i1;
            arrayOfObject[4] = str6;
            arrayOfObject[5] = "0";
            arrayOfObject[6] = "2";
            localm.execute(arrayOfObject);
            localObject2 += 1;
          }
        }
        JSONObject localJSONObject = ((JSONArray)localObject3).getJSONObject(i);
        a locala = new a();
        String str7 = localJSONObject.getString("uid");
        locala.a = str7;
        String str8 = localJSONObject.getString("pic");
        locala.b = str8;
        this.b.add(locala);
        ++i;
      }
      catch (JSONException localJSONException)
      {
        this.a.c();
        break label36:
      }
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    com.jiayuan.util.a.a("HomeDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    com.jiayuan.util.a.a("HomeDataProcessing", "onCancelled()");
  }

  public void c()
  {
    com.jiayuan.util.a.a("HomeDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.c();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.m
 * JD-Core Version:    0.5.4
 */