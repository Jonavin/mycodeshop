package com.jiayuan.home;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import java.util.List;

public class l extends BaseAdapter
{
  private LayoutInflater b;
  private Context c;

  public l(HomeActivity paramHomeActivity, Context paramContext)
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(paramContext);
    this.b = localLayoutInflater;
    this.c = paramContext;
  }

  public int getCount()
  {
    return HomeActivity.a(this.a).size();
  }

  public Object getItem(int paramInt)
  {
    return null;
  }

  public long getItemId(int paramInt)
  {
    return 0L;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Object localObject1;
    View localView;
    if (paramView == null)
    {
      localObject1 = this.a;
      localObject2 = new j((HomeActivity)localObject1);
      localView = this.b.inflate(2130903045, null);
      localObject1 = (ImageView)localView.findViewById(2131361814);
      ((j)localObject2).a = ((ImageView)localObject1);
      localObject1 = (ImageView)localView.findViewById(2131361815);
      ((j)localObject2).b = ((ImageView)localObject1);
      int i = HomeActivity.b(this.a) - 8;
      int j = HomeActivity.c(this.a);
      localObject1 = new AbsListView.LayoutParams(i, j);
      localView.setLayoutParams((ViewGroup.LayoutParams)localObject1);
      localView.setTag(localObject2);
      localObject1 = localObject2;
    }
    for (Object localObject2 = localView; ; localObject2 = paramView)
    {
      ImageView localImageView1 = ((j)localObject1).a;
      Bitmap localBitmap = (Bitmap)HomeActivity.d(this.a).get(paramInt);
      localImageView1.setImageBitmap(this);
      ImageView localImageView2 = ((j)localObject1).a;
      ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
      ((ImageView)localObject1).setScaleType(localScaleType);
      return localObject2;
      localObject1 = (j)paramView.getTag();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.l
 * JD-Core Version:    0.5.4
 */