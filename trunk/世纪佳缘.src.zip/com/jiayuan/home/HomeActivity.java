package com.jiayuan.home;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.login.LoginActivity;
import com.jiayuan.register.RegisterType;
import com.jiayuan.util.o;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends MyActivity
  implements k
{
  public l a;
  private List b;
  private List c;
  private View d;
  private int e;
  private int f;
  private int g = null;

  private void a(int paramInt)
  {
    int i = 2;
    String str = "TabHost button clicked index=" + paramInt;
    com.jiayuan.util.a.a("HomeActivity", str);
    Intent localIntent = new Intent();
    if ((o.a == null) || (o.a.equals("")))
      if (paramInt == i)
      {
        Bundle localBundle1 = new Bundle();
        localBundle1.putInt("tabIndex", i);
        localIntent.setClass(this, MainActivity.class);
        localIntent.putExtras(localBundle1);
      }
    while (true)
    {
      startActivity(localIntent);
      return;
      localIntent.setClass(this, LoginActivity.class);
      Toast.makeText(this, 2131165669, 1).show();
      continue;
      Bundle localBundle2 = new Bundle();
      localBundle2.putInt("tabIndex", paramInt);
      localIntent.setClass(this, MainActivity.class);
      localIntent.putExtras(localBundle2);
    }
  }

  private void d()
  {
    com.jiayuan.util.a.a("HomeActivity", "Login button clicked");
    Intent localIntent = new Intent(this, LoginActivity.class);
    startActivity(localIntent);
  }

  private void e()
  {
    com.jiayuan.util.a.a("HomeActivity", "Register button clicked");
    Intent localIntent = new Intent(this, RegisterType.class);
    startActivity(localIntent);
  }

  public void a()
  {
    com.jiayuan.util.a.a("HomeActivity", "---------onWaitingActivityStart()---------");
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    if (paramBitmap == null)
    {
      String str1 = "HomeActivity onGetPhoto index=" + paramInt + "null";
      com.jiayuan.util.a.a("HomeActivity", str1);
    }
    while (true)
    {
      int i = this.g;
      int j;
      ++j;
      this.g = i;
      this.c.set(paramInt, paramBitmap);
      ((a)this.b.get(paramInt)).b = paramString;
      this.a.notifyDataSetChanged();
      if (this.g == 9)
        this.d.setVisibility(8);
      return;
      String str2 = "HomeActivity onGetPhoto index=" + paramInt + "not null";
      com.jiayuan.util.a.a("HomeActivity", str2);
    }
  }

  public void a(String paramString)
  {
    this.d.setVisibility(8);
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void a(List paramList)
  {
    com.jiayuan.util.a.a("HomeActivity", "----------------onGetData()----------------");
    ArrayList localArrayList = new ArrayList(paramList);
    this.b = localArrayList;
    localArrayList = new ArrayList();
    this.c = localArrayList;
    localArrayList = null;
    while (true)
    {
      int i = this.b.size();
      if (localArrayList >= i)
      {
        GridView localGridView = (GridView)findViewById(2131361811);
        l locall1 = new l(this, this);
        this.a = locall1;
        l locall2 = this.a;
        localGridView.setAdapter(locall2);
        b localb = new b(this);
        localGridView.setOnItemClickListener(localb);
        return;
      }
      this.c.add(null);
      ++localArrayList;
    }
  }

  public void b()
  {
    com.jiayuan.util.a.a("HomeActivity", "---------onWaitingActivityFinish()---------");
  }

  public void c()
  {
    this.d.setVisibility(8);
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool = true;
    long l = 4602678819172646912L;
    super.onCreate(paramBundle);
    String str1 = com.jiayuan.util.b.e(this);
    String str2 = com.jiayuan.util.b.f(this);
    String str3 = "userName userName userName userName=" + str1;
    com.jiayuan.util.a.a("HomeActivity", str3);
    String str4 = "password password password password=" + str2;
    com.jiayuan.util.a.a("HomeActivity", str4);
    if (!str1.equalsIgnoreCase(""))
    {
      com.jiayuan.util.a.a("HomeActivity", "Goto Login activity");
      Intent localIntent = new Intent(this, LoginActivity.class);
      startActivity(localIntent);
      finish();
    }
    while (true)
    {
      return;
      com.jiayuan.util.a.a("HomeActivity", "Stay in Home activity");
      com.jiayuan.util.b.c(this, bool);
      int i = com.jiayuan.util.b.b;
      com.jiayuan.util.b.a(this, i);
      com.jiayuan.util.b.d(this, bool);
      setContentView(2130903044);
      View localView = findViewById(2131361812);
      this.d = localView;
      int j = o.d(this);
      int k = o.e(this);
      String str5 = "asdfasdfasdfasf screenWidth=" + j;
      com.jiayuan.util.a.a("HomeActivity", str5);
      String str6 = "asdfasdfasdfasf screenHeight=" + k;
      com.jiayuan.util.a.a("HomeActivity", str6);
      int i1 = j / 3;
      int i2;
      i2 += 5;
      this.e = i1;
      int i3 = (k - 155) / 3;
      this.f = i3;
      Button localButton1 = (Button)findViewById(2131361802);
      g localg = new g(this);
      localButton1.setOnClickListener(localg);
      Button localButton2 = (Button)findViewById(2131361803);
      i locali = new i(this);
      localButton2.setOnClickListener(locali);
      Button localButton3 = (Button)findViewById(2131361804);
      h localh = new h(this);
      localButton3.setOnClickListener(localh);
      Button localButton4 = (Button)findViewById(2131361805);
      d locald = new d(this);
      localButton4.setOnClickListener(locald);
      Button localButton5 = (Button)findViewById(2131361806);
      c localc = new c(this);
      localButton5.setOnClickListener(localc);
      Button localButton6 = (Button)findViewById(2131361808);
      f localf = new f(this);
      localButton6.setOnClickListener(localf);
      Button localButton7 = (Button)findViewById(2131361810);
      e locale = new e(this);
      localButton7.setOnClickListener(locale);
      DisplayMetrics localDisplayMetrics = new DisplayMetrics();
      getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
      float f1 = localDisplayMetrics.widthPixels;
      int i4 = localDisplayMetrics.density;
      int i5 = (int)(f1 * i4 + l);
      float f2 = localDisplayMetrics.heightPixels;
      int i6 = (int)(localDisplayMetrics.density * f2 + l);
      int i7 = this.e;
      int i8 = this.f;
      HomeActivity localHomeActivity = this;
      int i9;
      new m(localHomeActivity, i5, i6, i7, i9).a();
    }
  }

  public void onDestroy()
  {
    super.onDestroy();
    System.gc();
  }

  protected void onResume()
  {
    super.onResume();
    com.jiayuan.util.a.a("HomeActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.HomeActivity
 * JD-Core Version:    0.5.4
 */