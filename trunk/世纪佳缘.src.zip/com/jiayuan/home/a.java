package com.jiayuan.home;

public class a
{
  public String a;
  public String b;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.home.a
 * JD-Core Version:    0.5.4
 */