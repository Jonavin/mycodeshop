package com.jiayuan;

import android.app.Application;
import android.content.Intent;
import com.jiayuan.home.HomeActivity;

class h
  implements Runnable
{
  h(SplashActivity paramSplashActivity)
  {
  }

  public void run()
  {
    SplashActivity localSplashActivity = this.a;
    Application localApplication = this.a.getApplication();
    Intent localIntent = new Intent(localApplication, HomeActivity.class);
    localSplashActivity.startActivity(localIntent);
    this.a.finish();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.h
 * JD-Core Version:    0.5.4
 */