package com.jiayuan;

import android.content.Intent;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import com.jiayuan.login.LoginActivity;
import com.jiayuan.util.a;
import com.jiayuan.util.o;

class d
  implements TabHost.OnTabChangeListener
{
  d(MainActivity paramMainActivity)
  {
  }

  public void onTabChanged(String paramString)
  {
    String str = "CURRENT_TAB:" + paramString;
    a.a("MainActivity", str);
    if ((o.a != null) && (!o.a.equals("")))
      return;
    TabHost localTabHost = this.a.a;
    int i = MainActivity.a(this.a);
    localTabHost.setCurrentTab(i);
    if (paramString.equals("tabSpecSearch"))
      return;
    MainActivity localMainActivity = this.a;
    Intent localIntent = new Intent(localMainActivity, LoginActivity.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.d
 * JD-Core Version:    0.5.4
 */