package com.jiayuan.mateselection;

import android.view.View;
import android.view.View.OnClickListener;

class f
  implements View.OnClickListener
{
  f(MateSelectionActivity paramMateSelectionActivity)
  {
  }

  public void onClick(View paramView)
  {
    MateSelectionActivity.b(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.f
 * JD-Core Version:    0.5.4
 */