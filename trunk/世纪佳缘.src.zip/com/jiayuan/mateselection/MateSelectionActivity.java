package com.jiayuan.mateselection;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.jiayuan.MainActivity;
import com.jiayuan.MyActivity;
import com.jiayuan.util.picker.AgeRangePicker;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.picker.HeightRangePicker;
import com.jiayuan.util.picker.ab;
import com.jiayuan.util.picker.m;
import com.jiayuan.util.picker.z;
import com.jiayuan.util.t;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class MateSelectionActivity extends MyActivity
  implements AdapterView.OnItemClickListener, a, com.jiayuan.util.picker.a, ab
{
  private final int a = null;
  private final int b = 1;
  private final int c = 2;
  private final int d = 3;
  private final int e = 4;
  private final int f = 5;
  private final int g = 6;
  private ArrayList h;
  private ListView i;
  private j j;
  private b k;
  private Context l;
  private Spinner m;
  private Spinner n;
  private Spinner o;
  private Spinner p;

  public MateSelectionActivity()
  {
    b localb = new b();
    this.k = localb;
  }

  private int[] a(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int i1 = 0; ; ++i1)
    {
      if (i1 >= paramInt)
        return arrayOfInt;
      int i2 = t.a(i1);
      arrayOfInt[i1] = i2;
    }
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int i1 = paramArrayOfInt.length;
    if (i1 <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      i1 = 0;
      return i1;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    for (int i2 = 0; ; ++i2)
    {
      int i3 = paramArrayOfInt.length;
      if (i2 < i3);
      int i4 = paramArrayOfInt[i2];
      String[] arrayOfString2 = localResources.getStringArray(i4);
      arrayOfString1[i2] = arrayOfString2;
    }
  }

  private void e()
  {
    com.jiayuan.util.a.a("MateSelectionActivity", "Confirm button clicked");
    String str1 = ((b)this.h.get(0)).b;
    String str2 = ((b)this.h.get(0)).c;
    int i1 = ((b)this.h.get(1)).d;
    String str3 = t.d(this, i1);
    int i2 = ((b)this.h.get(1)).d;
    int i3 = ((b)this.h.get(1)).e;
    String str4 = t.b(this, i2, i3);
    String str5 = ((b)this.h.get(2)).b;
    String str6 = ((b)this.h.get(2)).c;
    String str7 = ((b)this.h.get(3)).b;
    String str8 = ((b)this.h.get(4)).b;
    String str9 = ((b)this.h.get(5)).b;
    String str10 = ((b)this.h.get(6)).b;
    MateSelectionActivity localMateSelectionActivity = this;
    new i(localMateSelectionActivity, str1, str2, str3, str4, str5, str6, str7, str8, str9, str10).a();
  }

  private void f()
  {
    b localb1 = this.k;
    String str1 = ((b)this.h.get(1)).a;
    localb1.a = str1;
    b localb2 = this.k;
    String str2 = ((b)this.h.get(1)).b;
    localb2.b = str2;
    b localb3 = this.k;
    String str3 = ((b)this.h.get(1)).c;
    localb3.c = str3;
    b localb4 = this.k;
    int i1 = ((b)this.h.get(1)).d;
    localb4.d = i1;
    b localb5 = this.k;
    int i2 = ((b)this.h.get(1)).e;
    localb5.e = i2;
  }

  private View g()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099840);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = a(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    f();
    g localg = new g(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(localg);
    int i2 = this.k.d;
    int i3 = this.k.e;
    localDoubleLevelSpinner.a(i2, true, i3, true);
    return localView;
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int i1 = ((b)this.h.get(paramInt3)).d;
    localSpinner.setSelection(i1, true);
    h localh = new h(this, paramInt3);
    localSpinner.setOnItemSelectedListener(localh);
    return localSpinner;
  }

  public void a()
  {
    Spinner localSpinner1 = a(2131361939, "璇烽��", 2131099754, 3);
    this.m = localSpinner1;
    Spinner localSpinner2 = a(2131361940, "璇烽�", 2131099787, 4);
    this.n = localSpinner2;
    Spinner localSpinner3 = a(2131361941, "璇烽�", 2131099786, 5);
    this.o = localSpinner3;
    Spinner localSpinner4 = a(2131361942, "璇烽��", 2131099755, 6);
    this.p = localSpinner4;
  }

  public void a(AgeRangePicker paramAgeRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    String str1 = "onAgeRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("MateSelectionActivity", str1);
    String str2 = "onAgeRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("MateSelectionActivity", str2);
    if (paramInt1 < paramInt2)
    {
      b localb1 = (b)this.h.get(i1);
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = com.jiayuan.util.f.r(this, paramInt1);
      String str4 = str3;
      localb1.b = str4;
      b localb2 = (b)this.h.get(i1);
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str5 = com.jiayuan.util.f.s(this, paramInt2);
      String str6 = str5;
      localb2.c = str6;
    }
    while (true)
    {
      this.j.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165336, i1).show();
    }
  }

  public void a(HeightRangePicker paramHeightRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 2;
    String str1 = "onHeightRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("MateSelectionActivity", str1);
    String str2 = "onHeightRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("MateSelectionActivity", str2);
    if (paramInt1 < paramInt2)
    {
      b localb1 = (b)this.h.get(i1);
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = com.jiayuan.util.f.t(this, paramInt1);
      String str4 = str3;
      localb1.b = str4;
      b localb2 = (b)this.h.get(i1);
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str5 = com.jiayuan.util.f.u(this, paramInt2);
      String str6 = str5;
      localb2.c = str6;
    }
    while (true)
    {
      this.j.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165337, 0).show();
    }
  }

  public void a(String paramString)
  {
    try
    {
      if (new JSONObject(paramString).getString("retcode").equalsIgnoreCase("1"))
      {
        Intent localIntent = new Intent();
        Bundle localBundle = new Bundle();
        localBundle.putInt("tabIndex", 0);
        localIntent.setClass(this, MainActivity.class);
        localIntent.putExtras(localBundle);
        startActivity(localIntent);
        com.jiayuan.a.a().b(MainActivity.class);
        finish();
        return;
      }
      Toast.makeText(this, 2131165338, 0).show();
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public void b()
  {
  }

  public void b(String paramString)
  {
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void c()
  {
  }

  public void d()
  {
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903066);
    this.l = this;
    b localb1 = new b();
    localb1.a = "骞";
    localb1.b = "18";
    localb1.c = "35";
    String str1 = localb1.b;
    int i1 = com.jiayuan.util.f.F(this, str1);
    localb1.d = i1;
    String str2 = localb1.c;
    int i2 = com.jiayuan.util.f.G(this, str2);
    localb1.e = i2;
    b localb2 = new b();
    localb2.a = "鍦";
    localb2.b = "鍖";
    localb2.c = "涓";
    localb2.d = null;
    localb2.e = null;
    b localb3 = new b();
    localb3.a = "韬";
    localb3.b = "160";
    localb3.c = "185";
    String str3 = localb3.b;
    int i3 = com.jiayuan.util.f.I(this, str3);
    localb3.d = i3;
    String str4 = localb3.c;
    int i4 = com.jiayuan.util.f.I(this, str4);
    localb3.e = i4;
    b localb4 = new b();
    localb4.a = "璇氫";
    localb4.b = "涓";
    localb4.c = "";
    localb4.d = null;
    localb4.e = null;
    b localb5 = new b();
    localb5.a = "濠";
    localb5.b = "涓";
    localb5.c = "";
    localb5.d = null;
    localb5.e = null;
    b localb6 = new b();
    localb6.a = "瀛";
    localb6.b = "涓";
    localb6.c = "";
    localb6.d = null;
    localb6.e = null;
    b localb7 = new b();
    localb7.a = "鏈夋";
    localb7.b = "涓";
    localb7.c = "";
    localb7.d = null;
    localb7.e = null;
    ArrayList localArrayList1 = new ArrayList();
    this.h = localArrayList1;
    this.h.add(localb1);
    this.h.add(localb2);
    this.h.add(localb3);
    this.h.add(localb4);
    this.h.add(localb5);
    this.h.add(localb6);
    this.h.add(localb7);
    a();
    ListView localListView1 = (ListView)findViewById(2131361936);
    this.i = localListView1;
    ArrayList localArrayList2 = this.h;
    j localj1 = new j(this, this, localArrayList2);
    this.j = localj1;
    this.j.setNotifyOnChange(null);
    ListView localListView2 = this.i;
    j localj2 = this.j;
    localListView2.setAdapter(localj2);
    this.i.setOnItemClickListener(this);
    Button localButton = (Button)findViewById(2131361935);
    f localf = new f(this);
    localButton.setOnClickListener(localf);
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    default:
      i1 = 0;
    case 1:
    }
    while (true)
    {
      return i1;
      Object localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView = g();
      localObject = ((AlertDialog.Builder)localObject).setView(localView);
      e locale = new e(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165642, locale);
      d locald = new d(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, locald).create();
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i1 = 0;
    int i2 = 2;
    int i3 = 1;
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("MateSelectionActivity", str);
    if (paramInt == 0)
    {
      int i4 = ((b)this.h.get(i1)).d;
      int i5 = ((b)this.h.get(i1)).e;
      new m(this, this, i4, i5).show();
    }
    while (true)
    {
      return;
      if (i3 == paramInt)
        showDialog(i3);
      if (i2 == paramInt)
      {
        int i6 = ((b)this.h.get(i2)).d;
        int i7 = ((b)this.h.get(i2)).e;
        new z(this, this, i6, i7).show();
      }
      if (3 == paramInt)
      {
        this.m.performClick();
        CharSequence localCharSequence1 = this.m.getPrompt();
        Toast.makeText(this, localCharSequence1, i3).show();
      }
      if (4 == paramInt)
      {
        this.n.performClick();
        CharSequence localCharSequence2 = this.n.getPrompt();
        Toast.makeText(this, localCharSequence2, i3).show();
      }
      if (5 == paramInt)
      {
        this.o.performClick();
        CharSequence localCharSequence3 = this.o.getPrompt();
        Toast.makeText(this, localCharSequence3, i3).show();
      }
      if (6 != paramInt)
        continue;
      this.p.performClick();
      CharSequence localCharSequence4 = this.p.getPrompt();
      Toast.makeText(this, localCharSequence4, i3).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.MateSelectionActivity
 * JD-Core Version:    0.5.4
 */