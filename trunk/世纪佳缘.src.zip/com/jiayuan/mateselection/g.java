package com.jiayuan.mateselection;

class g
  implements com.jiayuan.util.picker.b
{
  g(MateSelectionActivity paramMateSelectionActivity, String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    b localb1 = MateSelectionActivity.d(this.a);
    String str1 = this.b[paramInt1];
    localb1.b = str1;
    MateSelectionActivity.d(this.a).d = paramInt1;
    b localb2 = MateSelectionActivity.d(this.a);
    String str2 = this.c[paramInt1][paramInt2];
    localb2.c = str2;
    MateSelectionActivity.d(this.a).e = paramInt2;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.g
 * JD-Core Version:    0.5.4
 */