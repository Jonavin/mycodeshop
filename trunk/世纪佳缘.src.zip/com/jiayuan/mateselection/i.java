package com.jiayuan.mateselection;

import android.content.Context;
import com.jiayuan.a.q;
import com.jiayuan.a.s;
import com.jiayuan.util.f;
import com.jiayuan.util.o;
import org.json.JSONException;
import org.json.JSONObject;

public class i
  implements q
{
  public a a;
  public Context b;
  private JSONObject c;

  public i(a parama, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10)
  {
    this.a = parama;
    Context localContext = (Context)parama;
    this.b = parama;
    try
    {
      JSONObject localJSONObject1 = new JSONObject();
      this.c = localJSONObject1;
      localJSONObject1 = this.c;
      Object localObject = o.b();
      localJSONObject1.put("from", localObject);
      localJSONObject1 = this.c;
      localObject = o.e();
      localJSONObject1.put("uid", localObject);
      localJSONObject1 = this.c;
      localObject = o.f();
      localJSONObject1.put("token", localObject);
      localJSONObject1 = this.c;
      String str1 = "nemin_age";
      localObject = paramString1.equals("涓");
      if (localObject != 0)
      {
        localObject = Integer.valueOf(0);
        label127: localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "nemax_age";
        localObject = paramString2.equals("涓");
        if (localObject == 0)
          break label541;
        localObject = Integer.valueOf(0);
        label166: localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "nemin_height";
        localObject = paramString5.equals("涓");
        if (localObject == 0)
          break label547;
        localObject = Integer.valueOf(0);
        label206: localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "nemax_height";
        localObject = paramString6.equals("涓");
        if (localObject == 0)
          break label554;
        localObject = Integer.valueOf(0);
        label246: localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "work_location1";
        localObject = paramString3.equals("涓");
        if (localObject == 0)
          break label561;
        localObject = Integer.valueOf(0);
        label286: localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "work_sublocation1";
        localObject = paramString4.equals("涓");
        if (localObject == 0)
          break label568;
        localObject = Integer.valueOf(0);
        label326: localJSONObject1.put(str1, localObject);
        str1 = "mateselection marriage=" + paramString8;
        com.jiayuan.util.a.a("MateSelectionDataProcessing", str1);
        str1 = "mateselection education=" + paramString9;
        com.jiayuan.util.a.a("MateSelectionDataProcessing", str1);
        localJSONObject1 = this.c;
        str1 = "nemarriage";
        localObject = paramString8.equals("涓");
        if (localObject == 0)
          break label575;
      }
      for (localObject = Integer.valueOf(0); ; localObject = f.d(this.b, paramString8))
      {
        localJSONObject1.put(str1, localObject);
        localJSONObject1 = this.c;
        str1 = "needucation";
        localObject = paramString9.equals("涓");
        if (localObject == 0)
          break;
        localObject = Integer.valueOf(0);
        localJSONObject1.put(str1, localObject);
        this.c.put("needucation_up", "on");
        JSONObject localJSONObject2 = this.c;
        String str2 = f.p(this.b, paramString10);
        localJSONObject1.put("needphoto", localObject);
        JSONObject localJSONObject3 = this.c;
        String str3 = f.o(this.b, paramString7);
        localJSONObject1.put("needcer", localObject);
        label534: return;
        localObject = paramString1;
        break label127:
        label541: localObject = paramString2;
        break label166:
        label547: localObject = paramString5;
        break label206:
        label554: localObject = paramString6;
        break label246:
        label561: localObject = paramString3;
        break label286:
        label568: localObject = paramString4;
        label575: break label326:
      }
      localObject = f.f(this.b, paramString9);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      break label534:
    }
  }

  public void a()
  {
    com.jiayuan.util.a.a("MateSelectionDataProcessing", "execute()");
    this.a.b();
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("reg/register_match.php");
    s locals = new s();
    locals.a = this;
    Object[] arrayOfObject = new Object[3];
    String str1 = localStringBuffer.toString();
    arrayOfObject[0] = str1;
    String str2 = this.c.toString();
    arrayOfObject[1] = str2;
    arrayOfObject[2] = null;
    locals.execute(arrayOfObject);
  }

  public void a(int paramInt, String paramString)
  {
    com.jiayuan.util.a.a("MateSelectionDataProcessing", "onPostExecute()");
    if (paramString.equals("NETWORK_ERROR"))
      this.a.b(paramString);
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        StringBuilder localStringBuilder1 = new StringBuilder("firstReq result.toString():");
        String str1 = localJSONObject.toString();
        String str2 = str1;
        com.jiayuan.util.a.a("MateSelectionDataProcessing", str2);
        this.a.c();
        this.a.a(paramString);
      }
      catch (JSONException localJSONException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("JSONException");
        String str3 = localJSONException.toString();
        String str4 = str3;
        com.jiayuan.util.a.a("MateSelectionDataProcessing", str4);
        this.a.d();
      }
    }
  }

  public void a(Integer[] paramArrayOfInteger)
  {
    com.jiayuan.util.a.a("MateSelectionDataProcessing", "onProgressUpdate()");
  }

  public void b()
  {
    com.jiayuan.util.a.a("MateSelectionDataProcessing", "onCancelled()");
  }

  public void c()
  {
    com.jiayuan.util.a.a("MateSelectionDataProcessing", "onPreExecute()");
  }

  public void d()
  {
    this.a.d();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.i
 * JD-Core Version:    0.5.4
 */