package com.jiayuan.mateselection;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import com.jiayuan.util.a;
import java.util.ArrayList;

class h
  implements AdapterView.OnItemSelectedListener
{
  h(MateSelectionActivity paramMateSelectionActivity, int paramInt)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder("selected=");
    String str1 = paramAdapterView.getItemAtPosition(paramInt).toString();
    String str2 = str1;
    a.a("MateSelectionActivity", str2);
    ArrayList localArrayList1 = MateSelectionActivity.a(this.a);
    int i = this.b;
    b localb = (b)localArrayList1.get(i);
    String str3 = paramAdapterView.getItemAtPosition(paramInt).toString();
    localb.b = str3;
    ArrayList localArrayList2 = MateSelectionActivity.a(this.a);
    int j = this.b;
    ((b)localArrayList2.get(j)).d = paramInt;
    paramAdapterView.setVisibility(0);
    MateSelectionActivity.c(this.a).notifyDataSetChanged();
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.h
 * JD-Core Version:    0.5.4
 */