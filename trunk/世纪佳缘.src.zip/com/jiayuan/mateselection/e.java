package com.jiayuan.mateselection;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import java.util.ArrayList;

class e
  implements DialogInterface.OnClickListener
{
  e(MateSelectionActivity paramMateSelectionActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ArrayList localArrayList = MateSelectionActivity.a(this.a);
    b localb = MateSelectionActivity.d(this.a);
    localArrayList.set(1, localb);
    MateSelectionActivity.c(this.a).notifyDataSetChanged();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.e
 * JD-Core Version:    0.5.4
 */