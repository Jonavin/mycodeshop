package com.jiayuan.mateselection;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiayuan.util.a;
import java.util.ArrayList;
import java.util.List;

class j extends ArrayAdapter
  implements View.OnClickListener
{
  Activity a;

  j(MateSelectionActivity paramMateSelectionActivity, Activity paramActivity, List paramList)
  {
    super(paramActivity, 2130903067, paramList);
    this.a = paramActivity;
  }

  public void a(View paramView, int paramInt)
  {
    c localc = (c)paramView.getTag();
    localc.d = paramInt;
    paramView.setTag(localc);
    TextView localTextView1 = localc.a;
    String str1 = ((b)MateSelectionActivity.a(this.b).get(paramInt)).a;
    localTextView1.setText(str1);
    if (paramInt == 0)
    {
      TextView localTextView2 = localc.b;
      String str2 = String.valueOf(((b)MateSelectionActivity.a(this.b).get(paramInt)).b);
      StringBuilder localStringBuilder1 = new StringBuilder(localc).append(" - ");
      String str3 = ((b)MateSelectionActivity.a(this.b).get(paramInt)).c;
      String str4 = str3 + "�";
      localTextView2.setText(localc);
    }
    while (true)
    {
      return;
      if (1 == paramInt)
      {
        TextView localTextView3 = localc.b;
        String str5 = String.valueOf(((b)MateSelectionActivity.a(this.b).get(paramInt)).b);
        StringBuilder localStringBuilder2 = new StringBuilder(localc).append(" ");
        String str6 = ((b)MateSelectionActivity.a(this.b).get(paramInt)).c;
        String str7 = str6;
        localTextView3.setText(localc);
      }
      if (2 == paramInt)
      {
        TextView localTextView4 = localc.b;
        String str8 = String.valueOf(((b)MateSelectionActivity.a(this.b).get(paramInt)).b);
        StringBuilder localStringBuilder3 = new StringBuilder(localc).append(" - ");
        String str9 = ((b)MateSelectionActivity.a(this.b).get(paramInt)).c;
        String str10 = str9 + "鍘";
        localTextView4.setText(localc);
      }
      TextView localTextView5 = localc.b;
      String str11 = String.valueOf(((b)MateSelectionActivity.a(this.b).get(paramInt)).b);
      StringBuilder localStringBuilder4 = new StringBuilder(localc);
      String str12 = ((b)MateSelectionActivity.a(this.b).get(paramInt)).c;
      String str13 = localc;
      localTextView5.setText(localc);
    }
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView;
    if (paramView == null)
    {
      localView = ((LayoutInflater)this.a.getSystemService("layout_inflater")).inflate(2130903067, paramViewGroup, null);
      c localc = new c(null);
      localObject = (TextView)localView.findViewById(2131361944);
      localc.a = ((TextView)localObject);
      localObject = (TextView)localView.findViewById(2131361945);
      localc.b = ((TextView)localObject);
      localObject = (ImageView)localView.findViewById(2131361946);
      localc.c = ((ImageView)localObject);
      localView.setTag(localc);
    }
    for (Object localObject = localView; ; localObject = paramView)
    {
      a((View)localObject, paramInt);
      return localObject;
    }
  }

  public void notifyDataSetChanged()
  {
    super.notifyDataSetChanged();
  }

  public void onClick(View paramView)
  {
    c localc = (c)((View)paramView.getTag()).getTag();
    a.a("MateSelectionActivity", "adsfasdf onClick");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.mateselection.j
 * JD-Core Version:    0.5.4
 */