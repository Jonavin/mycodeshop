package com.jiayuan;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.os.Bundle;
import android.view.KeyEvent;

public class MyActivity extends Activity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    a locala = a.a();
    locala.c(this);
    locala.d(this);
  }

  protected void onDestroy()
  {
    a locala = a.a();
    locala.b(this);
    locala.d(this);
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    switch (paramInt)
    {
    default:
    case 4:
    }
    Object localObject;
    for (boolean bool = super.onKeyDown(paramInt, paramKeyEvent); ; localObject = super.onKeyDown(paramInt, paramKeyEvent))
    {
      while (true)
      {
        return bool;
        com.jiayuan.util.a.a(super.getClass().toString(), "back key pressed");
        int i = a.a().c();
        if (1 != i)
          break;
        localObject = new AlertDialog.Builder(this).setTitle(2131165201).setMessage(2131165202);
        e locale = new e(this);
        localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165204, locale);
        f localf = new f(this);
        ((AlertDialog.Builder)localObject).setNegativeButton(2131165203, localf).create().show();
        com.jiayuan.util.a.a(super.getClass().toString(), "back key pressed 000");
        localObject = null;
      }
      com.jiayuan.util.a.a(super.getClass().toString(), "back key pressed 111");
    }
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.MyActivity
 * JD-Core Version:    0.5.4
 */