package com.jiayuan.profile;

import android.app.Activity;
import android.graphics.Bitmap;
import com.jiayuan.a.ab;
import com.jiayuan.a.ac;
import com.jiayuan.a.d;
import com.jiayuan.a.e;
import com.jiayuan.a.f;
import com.jiayuan.a.i;
import com.jiayuan.a.k;
import com.jiayuan.a.n;
import com.jiayuan.a.v;
import com.jiayuan.a.w;
import com.jiayuan.a.x;
import com.jiayuan.a.z;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import com.jiayuan.util.s;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class y
  implements ab, e, i, n, v, w
{
  public aa a;
  private String b;
  private int c;
  private int d;
  private Activity e;
  private int f;

  public y(aa paramaa, String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    Activity localActivity = (Activity)paramaa;
    this.e = localActivity;
    this.a = paramaa;
    this.f = paramInt3;
    this.b = paramString;
    this.c = paramInt1;
    this.d = paramInt2;
  }

  public void a()
  {
    a.a("ProfileDataProcessing", "execute()");
    this.a.b();
    ArrayList localArrayList = new ArrayList();
    Integer localInteger1 = Integer.valueOf(3);
    localArrayList.add(localInteger1);
    Integer localInteger2 = Integer.valueOf(2);
    localArrayList.add(localInteger2);
    Integer localInteger3 = Integer.valueOf(105);
    localArrayList.add(localInteger3);
    Integer localInteger4 = Integer.valueOf(5);
    localArrayList.add(localInteger4);
    Integer localInteger5 = Integer.valueOf(6);
    localArrayList.add(localInteger5);
    Integer localInteger6 = Integer.valueOf(112);
    localArrayList.add(localInteger6);
    Integer localInteger7 = Integer.valueOf(104);
    localArrayList.add(localInteger7);
    Integer localInteger8 = Integer.valueOf(100);
    localArrayList.add(localInteger8);
    Integer localInteger9 = Integer.valueOf(101);
    localArrayList.add(localInteger9);
    Integer localInteger10 = Integer.valueOf(114);
    localArrayList.add(localInteger10);
    Integer localInteger11 = Integer.valueOf(1);
    localArrayList.add(localInteger11);
    Integer localInteger12 = Integer.valueOf(111);
    localArrayList.add(localInteger12);
    Integer localInteger13 = Integer.valueOf(117);
    localArrayList.add(localInteger13);
    Integer localInteger14 = Integer.valueOf(114);
    localArrayList.add(localInteger14);
    Integer localInteger15 = Integer.valueOf(116);
    localArrayList.add(localInteger15);
    Integer localInteger16 = Integer.valueOf(121);
    localArrayList.add(localInteger16);
    Integer localInteger17 = Integer.valueOf(122);
    localArrayList.add(localInteger17);
    Integer localInteger18 = Integer.valueOf(127);
    localArrayList.add(localInteger18);
    Integer localInteger19 = Integer.valueOf(128);
    localArrayList.add(localInteger19);
    Integer localInteger20 = Integer.valueOf(129);
    localArrayList.add(localInteger20);
    Integer localInteger21 = Integer.valueOf(130);
    localArrayList.add(localInteger21);
    Integer localInteger22 = Integer.valueOf(131);
    localArrayList.add(localInteger22);
    Integer localInteger23 = Integer.valueOf(132);
    localArrayList.add(localInteger23);
    Integer localInteger24 = Integer.valueOf(133);
    localArrayList.add(localInteger24);
    Integer localInteger25 = Integer.valueOf(134);
    localArrayList.add(localInteger25);
    Integer localInteger26 = Integer.valueOf(135);
    localArrayList.add(localInteger26);
    Integer localInteger27 = Integer.valueOf(136);
    localArrayList.add(localInteger27);
    Integer localInteger28 = Integer.valueOf(137);
    localArrayList.add(localInteger28);
    Integer localInteger29 = Integer.valueOf(206);
    localArrayList.add(localInteger29);
    Integer localInteger30 = Integer.valueOf(221);
    localArrayList.add(localInteger30);
    Integer localInteger31 = Integer.valueOf(158);
    localArrayList.add(localInteger31);
    Integer localInteger32 = Integer.valueOf(124);
    localArrayList.add(localInteger32);
    Integer localInteger33 = Integer.valueOf(148);
    localArrayList.add(localInteger33);
    Integer localInteger34 = Integer.valueOf(149);
    localArrayList.add(localInteger34);
    Integer localInteger35 = Integer.valueOf(147);
    localArrayList.add(localInteger35);
    Integer localInteger36 = Integer.valueOf(123);
    localArrayList.add(localInteger36);
    Integer localInteger37 = Integer.valueOf(146);
    localArrayList.add(localInteger37);
    Integer localInteger38 = Integer.valueOf(113);
    localArrayList.add(localInteger38);
    Integer localInteger39 = Integer.valueOf(181);
    localArrayList.add(localInteger39);
    Integer localInteger40 = Integer.valueOf(184);
    localArrayList.add(localInteger40);
    Integer localInteger41 = Integer.valueOf(74);
    localArrayList.add(localInteger41);
    Integer localInteger42 = Integer.valueOf(179);
    localArrayList.add(localInteger42);
    Integer localInteger43 = Integer.valueOf(180);
    localArrayList.add(localInteger43);
    Integer localInteger44 = Integer.valueOf(160);
    localArrayList.add(localInteger44);
    Integer localInteger45 = Integer.valueOf(152);
    localArrayList.add(localInteger45);
    Integer localInteger46 = Integer.valueOf(150);
    localArrayList.add(localInteger46);
    Integer localInteger47 = Integer.valueOf(151);
    localArrayList.add(localInteger47);
    Integer localInteger48 = Integer.valueOf(162);
    localArrayList.add(localInteger48);
    Integer localInteger49 = Integer.valueOf(161);
    localArrayList.add(localInteger49);
    Integer localInteger50 = Integer.valueOf(155);
    localArrayList.add(localInteger50);
    Integer localInteger51 = Integer.valueOf(182);
    localArrayList.add(localInteger51);
    Integer localInteger52 = Integer.valueOf(102);
    localArrayList.add(localInteger52);
    Integer localInteger53 = Integer.valueOf(103);
    localArrayList.add(localInteger53);
    Integer localInteger54 = Integer.valueOf(185);
    localArrayList.add(localInteger54);
    Integer localInteger55 = Integer.valueOf(186);
    localArrayList.add(localInteger55);
    Integer localInteger56 = Integer.valueOf(145);
    localArrayList.add(localInteger56);
    Integer localInteger57 = Integer.valueOf(187);
    localArrayList.add(localInteger57);
    Integer localInteger58 = Integer.valueOf(156);
    localArrayList.add(localInteger58);
    Integer localInteger59 = Integer.valueOf(153);
    localArrayList.add(localInteger59);
    Integer localInteger60 = Integer.valueOf(163);
    localArrayList.add(localInteger60);
    Integer localInteger61 = Integer.valueOf(119);
    localArrayList.add(localInteger61);
    Integer localInteger62 = Integer.valueOf(154);
    localArrayList.add(localInteger62);
    Integer localInteger63 = Integer.valueOf(171);
    localArrayList.add(localInteger63);
    Integer localInteger64 = Integer.valueOf(120);
    localArrayList.add(localInteger64);
    Integer localInteger65 = Integer.valueOf(175);
    localArrayList.add(localInteger65);
    Integer localInteger66 = Integer.valueOf(176);
    localArrayList.add(localInteger66);
    String str1 = this.b;
    int i = this.f;
    new d(this, str1, localArrayList, i).a();
    String str2 = this.b;
    new k(this, str2).a();
    Activity localActivity1 = this.e;
    String str3 = this.b;
    int j = this.c;
    int k = this.d;
    y localy = this;
    new z(localActivity1, localy, str3, 0, "100", -1, j, k).a();
    Activity localActivity2 = this.e;
    String str4 = this.b;
    new x(this, localActivity2, str4).a();
    if (!s.a(o.k()))
      return;
    String str5 = this.b;
    new ac(this, str5).a();
  }

  public void a(int paramInt, String paramString)
  {
    this.a.a(paramInt, paramString);
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }

  public void a(ArrayList paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder("onGetPhotoAmount photoUrls.size()=");
    int i = paramArrayList.size();
    String str = i;
    a.a("ProfileDataProcessing", str);
    this.a.a(paramArrayList);
  }

  public void a(JSONObject paramJSONObject)
  {
    StringBuilder localStringBuilder = new StringBuilder("json.toString()=");
    String str1 = paramJSONObject.toString();
    String str2 = str1;
    a.a("ProfileDataProcessing", str2);
    this.a.b(paramJSONObject);
    String str3 = "";
    String str4;
    try
    {
      str3 = paramJSONObject.getJSONObject("userinfo").getString("221");
      str4 = str3;
      String str5 = this.b;
      int i = this.c;
      int j = this.d + 12;
      y localy = this;
      new f(localy, str5, str4, -1, i, j).a();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      str4 = str3;
    }
  }

  public void a_(int paramInt, String paramString, Bitmap paramBitmap)
  {
    String str = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    a.a("ProfileDataProcessing", str);
    this.a.b(paramInt, paramString, paramBitmap);
  }

  public void a_(String paramString)
  {
    this.a.a_(paramString);
  }

  public void b(JSONObject paramJSONObject)
  {
    this.a.c(paramJSONObject);
  }

  public void d()
  {
    this.a.d();
  }

  public void d(String paramString)
  {
    this.a.a(paramString);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.y
 * JD-Core Version:    0.5.4
 */