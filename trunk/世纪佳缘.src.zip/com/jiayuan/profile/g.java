package com.jiayuan.profile;

import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    ProfileActivity.g(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.g
 * JD-Core Version:    0.5.4
 */