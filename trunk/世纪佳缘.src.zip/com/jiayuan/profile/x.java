package com.jiayuan.profile;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Gallery;
import java.util.ArrayList;

class x
  implements AdapterView.OnItemClickListener
{
  x(ProfileActivity paramProfileActivity)
  {
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i = ProfileActivity.h(this.a).getSelectedItemPosition();
    if (paramInt != i)
      return;
    Intent localIntent = new Intent();
    String str1 = ProfileActivity.a(this.a).a;
    localIntent.putExtra("uid", str1);
    String str2 = ProfileActivity.a(this.a).b;
    localIntent.putExtra("nick_name", str2);
    int j = ProfileActivity.h(this.a).getSelectedItemPosition();
    localIntent.putExtra("selected_index", j);
    ArrayList localArrayList = ProfileActivity.i(this.a);
    localIntent.putStringArrayListExtra("photo_urls", localArrayList);
    String str3 = ProfileActivity.a(this.a).g;
    localIntent.putExtra("sex", str3);
    ProfileActivity localProfileActivity = this.a;
    localIntent.setClass(localProfileActivity, ProfilePhotoGalleryActivity.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.x
 * JD-Core Version:    0.5.4
 */