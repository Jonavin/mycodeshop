package com.jiayuan.profile;

import android.graphics.Bitmap;
import com.jiayuan.a.m;
import com.jiayuan.a.p;
import com.jiayuan.util.a;
import java.util.ArrayList;

public class k
  implements p
{
  public l a;
  private ArrayList b;
  private int c;
  private int d;

  public k(l paraml, ArrayList paramArrayList, int paramInt1, int paramInt2)
  {
    this.a = paraml;
    this.b = paramArrayList;
    this.c = paramInt1;
    this.d = paramInt2;
  }

  public void a()
  {
    int i = 0;
    a.a("ProfilePhotoGalleryDataProcessing", "execute()");
    int j = this.b.size();
    if (j <= 0)
      return;
    for (j = i; ; ++j)
    {
      int k = this.b.size();
      if (j < k);
      m localm = new m();
      Object[] arrayOfObject = new Object[7];
      Object localObject = this.b.get(j);
      arrayOfObject[i] = localObject;
      arrayOfObject[1] = this;
      Integer localInteger = Integer.valueOf(j);
      arrayOfObject[2] = localInteger;
      StringBuilder localStringBuilder1 = new StringBuilder();
      int l = this.c;
      String str1 = l;
      arrayOfObject[3] = str1;
      StringBuilder localStringBuilder2 = new StringBuilder();
      int i1 = this.d;
      String str2 = i1;
      arrayOfObject[4] = str2;
      arrayOfObject[5] = "1";
      arrayOfObject[6] = "0";
      localm.execute(arrayOfObject);
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    this.a.a(paramInt, paramString, paramBitmap);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.k
 * JD-Core Version:    0.5.4
 */