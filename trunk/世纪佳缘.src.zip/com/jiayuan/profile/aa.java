package com.jiayuan.profile;

import android.graphics.Bitmap;
import java.util.ArrayList;
import org.json.JSONObject;

public abstract interface aa
{
  public abstract void a(int paramInt, String paramString);

  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void a(String paramString);

  public abstract void a(ArrayList paramArrayList);

  public abstract void a_(String paramString);

  public abstract void b();

  public abstract void b(int paramInt, String paramString, Bitmap paramBitmap);

  public abstract void b(JSONObject paramJSONObject);

  public abstract void c(JSONObject paramJSONObject);

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.aa
 * JD-Core Version:    0.5.4
 */