package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.login.LoginActivity;

class t
  implements DialogInterface.OnClickListener
{
  t(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    com.jiayuan.util.o.i = ProfileActivity.a(this.a).a;
    ProfileActivity localProfileActivity = this.a;
    Intent localIntent = new Intent(localProfileActivity, LoginActivity.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.t
 * JD-Core Version:    0.5.4
 */