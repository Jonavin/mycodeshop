package com.jiayuan.profile;

import android.content.Context;
import com.jiayuan.a.l;
import com.jiayuan.a.q;
import com.jiayuan.util.a;
import com.jiayuan.util.o;
import java.io.PrintStream;

public class z
  implements q
{
  private String a = "RecommendDataProcessing";
  private Context b;
  private String c;
  private String d;

  public z(Context paramContext, String paramString1, String paramString2)
  {
    this.b = paramContext;
    this.c = paramString1;
    this.d = paramString2;
  }

  public void a()
  {
    StringBuffer localStringBuffer = new StringBuffer("http://api.jiayuan.com/");
    localStringBuffer.append("relation/http_invite.php?uid=");
    if ((o.a == null) || (o.a.equals("")))
      localStringBuffer.append("29077833");
    while (true)
    {
      localStringBuffer.append("&token=");
      String str1 = o.f();
      localStringBuffer.append(str1);
      localStringBuffer.append("&by_uid=");
      String str2 = this.d;
      localStringBuffer.append(str2);
      localStringBuffer.append("&invite_type=");
      String str3 = this.c;
      localStringBuffer.append(str3);
      localStringBuffer.append("&clientid=");
      String str4 = o.b();
      localStringBuffer.append(str4);
      String str5 = this.a;
      StringBuilder localStringBuilder = new StringBuilder("----");
      String str6 = localStringBuffer.toString();
      String str7 = str6;
      a.a(str5, str7);
      PrintStream localPrintStream = System.out;
      String str8 = localStringBuffer.toString();
      localPrintStream.println(str8);
      l locall = new l();
      locall.a = this;
      String str9 = localStringBuffer.toString();
      locall.b(localStringBuffer);
      return;
      String str10 = o.e();
      localStringBuffer.append(str10);
    }
  }

  public void a(int paramInt, String paramString)
  {
    if (paramString.equals("NETWORK_ERROR"))
      a(paramString);
    while (true)
    {
      return;
      System.out.println(paramString);
      String str1 = this.a;
      String str2 = "result----" + paramString;
      a.a(str1, str2);
    }
  }

  public void a(String paramString)
  {
  }

  public void a(Integer[] paramArrayOfInteger)
  {
  }

  public void b()
  {
  }

  public void c()
  {
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.z
 * JD-Core Version:    0.5.4
 */