package com.jiayuan.profile;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import java.util.ArrayList;

public class ab extends BaseAdapter
{
  private Context b;

  public ab(ProfilePhotoGalleryActivity paramProfilePhotoGalleryActivity, Context paramContext)
  {
    this.b = paramContext;
  }

  public int getCount()
  {
    return ProfilePhotoGalleryActivity.c(this.a).size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Object localObject = (BitmapDrawable)ProfilePhotoGalleryActivity.c(this.a).get(paramInt);
    if (paramView == null);
    for (localObject = this.a.getLayoutInflater().inflate(2130903088, null); ; localObject = paramView)
    {
      ImageView localImageView = (ImageView)((View)localObject).findViewById(2131362016);
      Gallery.LayoutParams localLayoutParams = new Gallery.LayoutParams(-1, 60);
      ((ImageView)localObject).setLayoutParams(localLayoutParams);
      ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
      ((ImageView)localObject).setScaleType(localScaleType);
      Drawable localDrawable = (Drawable)ProfilePhotoGalleryActivity.c(this.a).get(paramInt);
      ((ImageView)localObject).setImageDrawable(this);
      ((ImageView)localObject).setBackgroundResource(2130837625);
      return localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.ab
 * JD-Core Version:    0.5.4
 */