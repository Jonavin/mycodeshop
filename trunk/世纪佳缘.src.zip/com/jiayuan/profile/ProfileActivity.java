package com.jiayuan.profile;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.BadTokenException;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.login.l;
import com.jiayuan.mail.detail.MailSendActivity;
import com.jiayuan.util.o;
import com.jiayuan.util.q;
import com.jiayuan.util.s;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ProfileActivity extends MyActivity
  implements com.jiayuan.a.aa, l, aa
{
  ImageView a;
  Button b;
  boolean c;
  ProgressDialog d;
  private Context e;
  private ac f;
  private ArrayList g;
  private ArrayList h;
  private Gallery i;
  private a j;
  private int k;
  private int l;
  private TextView m;
  private int n;
  private View.OnClickListener o;
  private int p;
  private int q;

  public ProfileActivity()
  {
    b localb = new b(this);
    this.o = localb;
  }

  private CharSequence a(int paramInt, int[] paramArrayOfInt)
  {
    int i1 = 1;
    if (paramArrayOfInt != null)
    {
      int i2 = paramArrayOfInt.length;
      if (i2 != 0)
        break label22;
    }
    Object localObject1 = "鏈�";
    return localObject1;
    label22: localObject1 = new StringBuffer();
    String[] arrayOfString = getResources().getStringArray(paramInt);
    Object localObject2 = null;
    while (true)
    {
      int i3 = paramArrayOfInt.length;
      if (localObject2 >= i3)
      {
        int i4 = ((StringBuffer)localObject1).length() - i1;
        ((StringBuffer)localObject1).deleteCharAt(i4);
      }
      if (paramArrayOfInt[localObject2] > 0)
      {
        int i5 = paramArrayOfInt[localObject2] - i1;
        String str = arrayOfString[i5];
        ((StringBuffer)localObject1).append(str);
      }
      ((StringBuffer)localObject1).append(",");
      ++localObject2;
    }
  }

  private String a(int paramInt1, int paramInt2)
  {
    Object localObject = getResources().getStringArray(paramInt1);
    int i1 = localObject.length;
    if ((paramInt2 < i1) && (paramInt2 >= 0));
    for (localObject = localObject[paramInt2]; ; localObject = "鏈�")
      return localObject;
  }

  private void c()
  {
    String str = this.f.a;
    int i1 = this.k;
    int i2 = this.l;
    int i3 = this.q;
    ProfileActivity localProfileActivity = this;
    new y(localProfileActivity, str, i1, i2, i3).a();
  }

  private void e()
  {
    com.jiayuan.util.a.a("ProfileActivity", "Last login time button clicked");
    if ((o.a == null) || (o.a.equals("")))
      showDialog(0);
    while (true)
    {
      return;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(this).setTitle(2131165543).setMessage(2131165544);
      j localj = new j(this);
      AlertDialog.Builder localBuilder2 = localBuilder1.setPositiveButton(2131165545, localj);
      i locali = new i(this);
      localBuilder2.setNegativeButton(2131165546, locali).create().show();
    }
  }

  private void f()
  {
    com.jiayuan.util.a.a("ProfileActivity", "Mail button clicked");
    if ((o.a == null) || (o.a.equals("")))
      showDialog(0);
    while (true)
    {
      return;
      Intent localIntent = new Intent();
      String str1 = this.f.a;
      localIntent.putExtra("to_id", str1);
      String str2 = this.f.b;
      localIntent.putExtra("nickname", str2);
      int i1 = this.n;
      localIntent.putExtra("src", i1);
      localIntent.setClass(this, MailSendActivity.class);
      startActivity(localIntent);
    }
  }

  private void g()
  {
    com.jiayuan.util.a.a("ProfileActivity", "Recommend button clicked");
    showDialog(2);
  }

  private void h()
  {
    int i1 = 0;
    com.jiayuan.util.a.a("ProfileActivity", "Match ok button clicked");
    Object localObject = o.a;
    if (localObject != null)
    {
      localObject = o.a.equals("");
      if (localObject == 0)
        break label36;
    }
    showDialog(i1);
    while (true)
    {
      return;
      label36: String str1 = this.f.a;
      int i2 = this.p;
      new com.jiayuan.a.h(this, str1, -1, i2).a();
      localObject = null;
      try
      {
        localObject = o.l();
        if (localObject == null)
        {
          String str2 = o.e();
          new com.jiayuan.login.j(this, str2).a();
        }
        label94: if (localObject != null);
        String str3 = this.f.g;
        if (!((String)localObject).equals(str3));
        this.c = i1;
        Button localButton = this.b;
        boolean bool = this.c;
        localButton.setEnabled(bool);
      }
      catch (Exception localException)
      {
        break label94:
      }
    }
  }

  private void i()
  {
    int i1 = 2131165390;
    boolean bool = null;
    int i2 = 1;
    com.jiayuan.util.a.a("ProfileActivity", "updateProfile");
    TextView localTextView = this.m;
    String str1 = String.valueOf(this.f.b);
    Object localObject8 = new StringBuilder(str1);
    str1 = getText(2131165385).toString();
    localObject8 = str1;
    localTextView.setText((CharSequence)localObject8);
    localObject8 = new StringBuffer();
    int i3 = this.f.i;
    str1 = this.f.j;
    int i4 = s.a(i3, str1);
    ((StringBuffer)localObject8).append(i4);
    Object localObject1 = new StringBuilder("宀");
    int i7 = this.f.h;
    String str2 = com.jiayuan.util.f.d(this, i7);
    localObject1 = str2;
    ((StringBuffer)localObject8).append((String)localObject1);
    localObject1 = new StringBuilder("/");
    int i8 = this.f.l;
    String str3 = com.jiayuan.util.f.c(this, i8);
    localObject1 = str3;
    ((StringBuffer)localObject8).append((String)localObject1);
    localObject1 = new StringBuilder("/");
    int i9 = this.f.k;
    localObject1 = i9 + "鍘";
    ((StringBuffer)localObject8).append((String)localObject1);
    ((TextView)findViewById(2131362021)).setText((CharSequence)localObject8);
    localObject8 = new StringBuffer();
    localObject1 = new StringBuilder();
    i9 = this.f.m;
    localObject1 = i9;
    int i10 = com.jiayuan.util.t.b(this, (String)localObject1);
    localObject1 = new StringBuilder();
    int i30 = this.f.n;
    localObject1 = i30;
    localObject1 = com.jiayuan.util.t.b(this, i10, (String)localObject1);
    String str15 = String.valueOf(com.jiayuan.util.t.a(this, i10));
    StringBuilder localStringBuilder = new StringBuilder(str15);
    localObject1 = com.jiayuan.util.t.a(this, i10, localObject1, bool);
    localObject1 = (String)localObject1;
    ((StringBuffer)localObject8).append((String)localObject1);
    localObject1 = new StringBuilder("/");
    int i31 = this.f.o;
    String str8 = com.jiayuan.util.f.h(this, i31);
    localObject1 = str8;
    ((StringBuffer)localObject8).append((String)localObject1);
    ((TextView)findViewById(2131362022)).setText((CharSequence)localObject8);
    localObject8 = new StringBuffer();
    int i5 = this.f.d;
    Object localObject2 = com.jiayuan.util.f.p(this, i5);
    ((StringBuffer)localObject8).append((String)localObject2);
    localObject2 = this.f.e;
    if (localObject2 != null);
    label618: Object localObject3;
    label712: label1000: Object localObject10;
    label1076: label1216: label1349: Object localObject22;
    label1794: label1982: int i12;
    try
    {
      localObject2 = this.f.e.getString("code");
      str8 = "0";
      localObject2 = ((String)localObject2).equalsIgnoreCase(str8);
      if (localObject2 != 0)
      {
        localObject2 = new StringBuilder("/");
        str8 = s.a(this.f.e.getString("dis"));
        localObject2 = str8;
        ((StringBuffer)localObject8).append((String)localObject2);
        ((TextView)findViewById(2131362023)).setText((CharSequence)localObject8);
        localObject8 = new StringBuffer();
        localObject2 = s.a(o.k());
        if (localObject2 == 0)
          break label4115;
        localObject2 = this.f.f;
        if (localObject2 != null)
        {
          localObject2 = this.f.f;
          str8 = "null";
          localObject2 = ((String)localObject2).equals(str8);
          if (localObject2 == 0)
            break label4032;
        }
        localObject2 = getString(i1);
        ((StringBuffer)localObject8).append((String)localObject2);
        ((TextView)findViewById(2131362024)).setText((CharSequence)localObject8);
        localObject8 = new StringBuffer();
        int i6 = this.f.p;
        localObject3 = com.jiayuan.util.f.g(this, i6);
        ((StringBuffer)localObject8).append((String)localObject3);
        localObject3 = new StringBuilder("/");
        int i32 = this.f.q;
        String str9 = com.jiayuan.util.f.j(this, i32);
        localObject3 = str9;
        ((StringBuffer)localObject8).append((String)localObject3);
        localObject3 = new StringBuilder("/");
        int i33 = this.f.o;
        String str10 = com.jiayuan.util.f.h(this, i33);
        localObject3 = str10;
        ((StringBuffer)localObject8).append((String)localObject3);
        localObject3 = new StringBuilder("/");
        int i34 = this.f.r;
        Object localObject19 = com.jiayuan.util.f.i(this, i34);
        localObject3 = (String)localObject19;
        ((StringBuffer)localObject8).append((String)localObject3);
        ((TextView)findViewById(2131362034)).setText((CharSequence)localObject8);
        localObject3 = (TextView)findViewById(2131362035);
        localObject8 = new StringBuffer();
        localObject19 = o.e().equalsIgnoreCase("");
        if (localObject19 == 0)
        {
          localObject19 = o.f().equalsIgnoreCase("");
          if (localObject19 == 0)
            break label4135;
        }
        ((StringBuffer)localObject8).append("灞呬綇鎯呭�");
        localObject19 = new f(this);
        ((TextView)localObject3).setOnClickListener((View.OnClickListener)localObject19);
        ((TextView)localObject3).setText((CharSequence)localObject8);
        localObject8 = (TextView)findViewById(2131362036);
        localObject19 = new StringBuffer();
        if ((!o.e().equalsIgnoreCase("")) && (!o.f().equalsIgnoreCase("")))
          break label4187;
        ((StringBuffer)localObject19).append("璐溅鎯呭�");
        e locale = new e(this);
        ((TextView)localObject3).setOnClickListener(locale);
        ((TextView)localObject8).setText((CharSequence)localObject19);
        localObject8 = new StringBuffer();
        localObject3 = new StringBuilder("骞撮");
        int i35 = this.f.u;
        localObject3 = ((StringBuilder)localObject3).append(i35).append("-");
        i35 = this.f.v;
        localObject3 = i35;
        ((StringBuffer)localObject8).append((String)localObject3);
        localObject3 = (TextView)findViewById(2131362039);
        ((TextView)localObject3).setText((CharSequence)localObject8);
        int i18 = this.f.u;
        if (i18 != 0)
        {
          i18 = this.f.v;
          if (i18 != 0)
            break label1216;
        }
        Object localObject9 = "骞撮�";
        ((TextView)localObject3).setText((CharSequence)localObject9);
        localObject9 = new StringBuffer();
        localObject3 = new StringBuilder("韬");
        i35 = this.f.w;
        localObject3 = ((StringBuilder)localObject3).append(i35).append("-");
        i35 = this.f.x;
        localObject3 = i35;
        ((StringBuffer)localObject9).append((String)localObject3);
        localObject3 = (TextView)findViewById(2131362040);
        ((TextView)localObject3).setText((CharSequence)localObject9);
        int i19 = this.f.w;
        if (i19 != 0)
        {
          i19 = this.f.x;
          if (i19 != 0)
            break label1349;
        }
        localObject10 = "韬�";
        ((TextView)localObject3).setText((CharSequence)localObject10);
        localObject10 = new StringBuffer();
        localObject3 = new StringBuilder("瀛�");
        i35 = this.f.A;
        String str11 = com.jiayuan.util.f.c(this, i35);
        localObject3 = str11;
        ((StringBuffer)localObject10).append((String)localObject3);
        ((TextView)findViewById(2131362041)).setText((CharSequence)localObject10);
        localObject10 = new StringBuffer();
        localObject3 = new StringBuilder("璇氫�");
        int i36 = this.f.y;
        String str12 = com.jiayuan.util.f.n(this, i36);
        localObject3 = str12;
        ((StringBuffer)localObject10).append((String)localObject3);
        ((TextView)findViewById(2131362042)).setText((CharSequence)localObject10);
        localObject10 = new StringBuffer();
        localObject3 = new StringBuilder("濠氬�");
        int i37 = this.f.z;
        String str13 = com.jiayuan.util.f.d(this, i37);
        localObject3 = str13;
        ((StringBuffer)localObject10).append((String)localObject3);
        ((TextView)findViewById(2131362043)).setText((CharSequence)localObject10);
        localObject10 = new StringBuffer();
        localObject3 = new StringBuilder("鏈夋�");
        int i38 = this.f.C;
        String str14 = com.jiayuan.util.f.o(this, i38);
        localObject3 = str14;
        ((StringBuffer)localObject10).append((String)localObject3);
        ((TextView)findViewById(2131362044)).setText((CharSequence)localObject10);
        localObject10 = new StringBuffer();
        localObject3 = new StringBuilder();
        int i39 = this.f.D;
        localObject3 = i39;
        localObject3 = com.jiayuan.util.t.b(this, (String)localObject3);
        Object localObject20 = new StringBuilder();
        int i41 = this.f.E;
        localObject20 = i41;
        i10 = com.jiayuan.util.t.b(this, i10, (String)localObject20);
        localObject20 = new StringBuffer();
        String str16 = com.jiayuan.util.t.a(this, localObject3);
        ((StringBuffer)localObject20).append(str16);
        localObject3 = com.jiayuan.util.t.a(this, localObject3, i10, bool);
        ((StringBuffer)localObject20).append((String)localObject3);
        localObject3 = ((StringBuffer)localObject20).toString().length();
        if (localObject3 <= 0)
          break label4239;
        localObject3 = ((StringBuffer)localObject20).toString();
        localObject3 = "鎵��" + (String)localObject3;
        ((StringBuffer)localObject10).append((String)localObject3);
        ((TextView)findViewById(2131362045)).setText((CharSequence)localObject10);
        localObject3 = (TextView)findViewById(2131362037);
        Object localObject5 = String.valueOf(getString(2131165405));
        localObject10 = new StringBuilder((String)localObject5);
        localObject5 = Integer.parseInt(this.f.a);
        Object localObject21 = 1000000;
        int i11;
        localObject5 += localObject21;
        localObject10 = i11;
        ((TextView)localObject3).setText((CharSequence)localObject10);
        localObject3 = (TextView)findViewById(2131362047);
        localObject10 = this.f.g;
        Object localObject6 = "f";
        localObject10 = ((String)localObject10).equals(localObject6);
        if (localObject10 == 0)
          break label4246;
        localObject6 = this.f.L;
        localObject10 = a(2131099760, localObject6);
        ((TextView)localObject3).setText((CharSequence)localObject10);
        localObject3 = (TextView)findViewById(2131362064);
        localObject6 = new StringBuilder("evaluation=");
        int i40 = this.f.M;
        localObject6 = ((StringBuilder)localObject6).append(i40).append(" sex=");
        localObject22 = this.f.g;
        localObject6 = (String)localObject22;
        com.jiayuan.util.a.a("ProfileActivity", (String)localObject6);
        localObject10 = this.f.g;
        localObject6 = "f";
        localObject10 = ((String)localObject10).equals(localObject6);
        if (localObject10 == 0)
          break label4276;
        i12 = this.f.M / 10 - i2;
        localObject10 = a(2131099758, i12);
        ((TextView)localObject3).setText((CharSequence)localObject10);
        label4482: label4239: label2576: label2194: label4115: label4246: label4504: label4005: label4518: label4135: label3882: label2350: label4276: label4409: label4538: label4032: label2246: label2118: label4187: label2142: label4448: label2787: label2668: label2415: label2298: localObject3 = (TextView)findViewById(2131362054);
      }
    }
    catch (NumberFormatException localNumberFormatException5)
    {
      Object localObject11;
      try
      {
        localObject10 = Integer.parseInt(this.f.N);
        i12 = 2131099762;
        int i20 = localObject10 - i2;
        localObject11 = a(i12, i20);
        ((TextView)localObject3).setText((CharSequence)localObject11);
        localObject3 = (TextView)findViewById(2131362060);
      }
      catch (NumberFormatException localNumberFormatException5)
      {
        Object localObject12;
        try
        {
          localObject11 = Integer.parseInt(this.f.O);
          i12 = 2131099763;
          int i21 = localObject11 - i2;
          localObject12 = a(i12, i21);
          ((TextView)localObject3).setText((CharSequence)localObject12);
          localObject3 = (TextView)findViewById(2131362050);
        }
        catch (NumberFormatException localNumberFormatException5)
        {
          Object localObject13;
          try
          {
            localObject12 = Integer.parseInt(this.f.P);
            i12 = 2131099764;
            int i22 = localObject12 - i2;
            localObject13 = a(i12, i22);
            ((TextView)localObject3).setText((CharSequence)localObject13);
            localObject3 = (TextView)findViewById(2131362052);
          }
          catch (NumberFormatException localNumberFormatException5)
          {
            Object localObject14;
            try
            {
              localObject13 = Integer.parseInt(this.f.Q);
              i12 = 2131099765;
              int i23 = localObject13 - i2;
              localObject14 = a(i12, i23);
              ((TextView)localObject3).setText((CharSequence)localObject14);
              localObject3 = (TextView)findViewById(2131362056);
            }
            catch (NumberFormatException localNumberFormatException5)
            {
              Object localObject17;
              try
              {
                localObject14 = Integer.parseInt(this.f.R);
                i12 = 2131099766;
                int i24 = localObject14 - i2;
                String str7 = a(i12, i24);
                ((TextView)localObject3).setText(str7);
                localObject3 = (TextView)findViewById(2131362058);
                int i25 = this.f.S;
                if (i25 == 0)
                {
                  Object localObject15 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362062);
                  i12 = this.f.T - i2;
                  localObject15 = a(2131099767, i12);
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362067);
                  localObject15 = this.f.U;
                  String str4;
                  if (localObject15 != null)
                  {
                    localObject15 = this.f.U;
                    str4 = "null";
                    localObject15 = ((String)localObject15).equals(str4);
                    if (localObject15 == 0)
                    {
                      localObject15 = this.f.U;
                      str4 = "";
                      localObject15 = ((String)localObject15).equals(str4);
                      if (localObject15 == 0)
                      {
                        localObject15 = this.f.U;
                        str4 = "0";
                        localObject15 = ((String)localObject15).equals(str4);
                        if (localObject15 == 0)
                          break label4409;
                      }
                    }
                  }
                  localObject15 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362069);
                  localObject15 = this.f.V;
                  if (localObject15 != null)
                  {
                    localObject15 = this.f.V;
                    str4 = "null";
                    localObject15 = ((String)localObject15).equals(str4);
                    if (localObject15 == 0)
                    {
                      localObject15 = this.f.V;
                      str4 = "";
                      localObject15 = ((String)localObject15).equals(str4);
                      if (localObject15 == 0)
                        break label4448;
                    }
                  }
                  localObject15 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362071);
                  int i13 = this.f.W - i2;
                  localObject15 = a(2131099769, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362073);
                  i13 = this.f.X - i2;
                  localObject15 = a(2131099770, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject15);
                  localObject3 = (TextView)findViewById(2131362075);
                  int i26 = this.f.Y;
                  if (i26 != 0)
                    break label4482;
                  Object localObject16 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362077);
                  i13 = this.f.Z - i2;
                  localObject16 = a(2131099771, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362079);
                  i13 = this.f.aa - i2;
                  localObject16 = a(2131099772, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362081);
                  i13 = this.f.ab - i2;
                  localObject16 = a(2131099773, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362083);
                  i13 = this.f.ac - i2;
                  localObject16 = a(2131099774, i13);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362085);
                  Object localObject7 = new StringBuilder("language index=");
                  localObject22 = this.f.ad;
                  localObject7 = localObject22;
                  com.jiayuan.util.a.a("ProfileActivity", (String)localObject7);
                  localObject7 = this.f.ad;
                  localObject16 = a(2131099775, localObject7);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362087);
                  int i14 = this.f.ae - i2;
                  localObject16 = a(2131099776, i14);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = (TextView)findViewById(2131362089);
                  i14 = this.f.af / 10 - i2;
                  localObject16 = a(2131099777, i14);
                  ((TextView)localObject3).setText((CharSequence)localObject16);
                  localObject3 = new StringBuilder();
                  int i27 = this.f.ag;
                  localObject3 = i27;
                  int i28 = com.jiayuan.util.t.b(this, (String)localObject3);
                  localObject3 = new StringBuilder();
                  i14 = this.f.ah;
                  localObject3 = i14;
                  int i15 = com.jiayuan.util.t.b(this, i28, (String)localObject3);
                  localObject3 = (TextView)findViewById(2131362091);
                  localObject22 = new StringBuffer();
                  String str17 = com.jiayuan.util.t.a(this, i28);
                  ((StringBuffer)localObject22).append(str17);
                  String str18 = com.jiayuan.util.t.a(this, i28, i15, bool);
                  ((StringBuffer)localObject22).append(str18);
                  localObject22 = ((StringBuffer)localObject22).toString().trim();
                  String str19 = "homeLoc=" + (String)localObject22 + "end";
                  com.jiayuan.util.a.a("ProfileActivity", str19);
                  if ((localObject22 == null) || (((String)localObject22).equals("")) || (((String)localObject22).length() == 0))
                    localObject22 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject22);
                  localObject3 = String.valueOf(this.f.ai);
                  localObject3 = com.jiayuan.util.t.b(this, (String)localObject3);
                  String str20 = String.valueOf(this.f.aj);
                  com.jiayuan.util.t.b(this, localObject3, (String)localObject22);
                  localObject3 = (TextView)findViewById(2131362093);
                  StringBuffer localStringBuffer = new StringBuffer();
                  String str21 = com.jiayuan.util.t.a(this, i28);
                  ((StringBuffer)localObject22).append(str21);
                  localObject17 = com.jiayuan.util.t.a(this, i28, i15, bool);
                  ((StringBuffer)localObject22).append((String)localObject17);
                  localObject17 = ((StringBuffer)localObject22).toString().trim();
                  String str22 = "loveLocation=" + (String)localObject17 + "end";
                  com.jiayuan.util.a.a("ProfileActivity", (String)localObject22);
                  if ((localObject17 == null) || (((String)localObject17).equals("")) || (((String)localObject17).length() == 0))
                    localObject17 = "鏈�";
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362095);
                  localObject17 = this.f.ak;
                  localObject17 = com.jiayuan.util.j.a(this, (String)localObject17);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362097);
                  int i42 = this.f.al - i2;
                  localObject17 = a(2131099779, i42);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362099);
                  int i43 = this.f.am - i2;
                  localObject17 = a(2131099780, i43);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362101);
                  int i44 = this.f.an - i2;
                  localObject17 = a(2131099781, i44);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362103);
                  int i45 = this.f.ao - i2;
                  localObject17 = a(2131099782, i45);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362105);
                  int i46 = this.f.ap - i2;
                  localObject17 = a(2131099783, i46);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362107);
                  int i47 = this.f.aq - i2;
                  localObject17 = a(2131099784, i47);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362109);
                  int[] arrayOfInt2 = this.f.ar;
                  localObject17 = a(2131099785, arrayOfInt2);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362111);
                  localObject17 = this.f.at;
                  if (localObject17 == null)
                    break label4504;
                  localObject17 = this.f.at.equals("");
                  if (localObject17 != 0)
                    break label4504;
                  localObject17 = this.f.at;
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362113);
                  localObject17 = this.f.au;
                  if (localObject17 == null)
                    break label4518;
                  localObject17 = this.f.au.equals("");
                  if (localObject17 != 0)
                    break label4518;
                  localObject17 = this.f.au;
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  localObject3 = (TextView)findViewById(2131362115);
                  localObject17 = s.a(this.e, "university_array.txt");
                  if (this.f.as == 0)
                    break label4538;
                }
              }
              catch (NumberFormatException localNumberFormatException5)
              {
                Object localObject4;
                try
                {
                  String str23 = String.valueOf(this.f.as);
                  String str24 = ((JSONObject)localObject17).getString(str23);
                  ((TextView)localObject3).setText((CharSequence)localObject17);
                  return;
                  localObject3 = "/璺濈�";
                  ((StringBuffer)localObject17).append((String)localObject3);
                  break label618:
                  localJSONException1 = localJSONException1;
                  localJSONException1.printStackTrace();
                  break label618:
                  localObject4 = getString(i1);
                  ((StringBuffer)localObject17).append((String)localObject4);
                  localObject4 = new Date();
                  long l1 = Integer.parseInt(this.f.f);
                  Object localObject23;
                  long l2 = 1000L * localObject23;
                  ((Date)localObject4).setTime(l2);
                  localObject22 = "\n";
                  ((StringBuffer)localObject17).append((String)localObject22);
                  localObject4 = ((Date)localObject4).toLocaleString();
                  ((StringBuffer)localObject17).append((String)localObject4);
                  break label712:
                  localObject4 = getString(2131165389);
                  ((StringBuffer)localObject17).append((String)localObject4);
                  break label712:
                  localObject22 = new StringBuilder("灞呬綇");
                  int i48 = this.f.s;
                  String str25 = com.jiayuan.util.f.k(this, i48);
                  localObject22 = str25;
                  ((StringBuffer)localObject17).append((String)localObject22);
                  break label1000:
                  localObject4 = new StringBuilder("璐溅");
                  int i49 = this.f.t;
                  String str26 = com.jiayuan.util.f.l(this, i49);
                  localObject4 = str26;
                  ((StringBuffer)localObject22).append((String)localObject4);
                  break label1076:
                  localObject4 = "鏈�";
                  break label1794:
                  int[] arrayOfInt1 = this.f.L;
                  localObject17 = a(2131099761, arrayOfInt1);
                  ((TextView)localObject4).setText((CharSequence)localObject17);
                  break label1982:
                  int i16 = this.f.M / 10 - i2;
                  localObject17 = a(2131099759, i16);
                  ((TextView)localObject4).setText((CharSequence)localObject17);
                  break label2118:
                  localNumberFormatException1.printStackTrace();
                  localObject17 = bool;
                  break label2142:
                  localNumberFormatException2.printStackTrace();
                  localObject17 = bool;
                  break label2194:
                  localNumberFormatException3.printStackTrace();
                  localObject17 = bool;
                  break label2246:
                  localNumberFormatException4.printStackTrace();
                  localObject17 = bool;
                  break label2298:
                  localNumberFormatException5.printStackTrace();
                  localObject17 = bool;
                  break label2350:
                  String str5 = String.valueOf(String.valueOf(this.f.S));
                  localObject17 = new StringBuilder(str5);
                  str5 = "kg";
                  localObject17 = str5;
                  ((TextView)localObject4).setText((CharSequence)localObject17);
                  break label2415:
                  int i29 = Integer.parseInt(this.f.U) - i2;
                  int i17 = 2131099768;
                  Object localObject18 = a(i17, i29);
                  ((TextView)localObject4).setText((CharSequence)localObject18);
                  break label2576:
                  localObject18 = this.e;
                  String str6 = this.f.V;
                  localObject18 = com.jiayuan.util.g.a((Context)localObject18, str6);
                  ((TextView)localObject4).setText((CharSequence)localObject18);
                  break label2668:
                  localObject18 = String.valueOf(this.f.Y);
                  ((TextView)localObject4).setText((CharSequence)localObject18);
                  break label2787:
                  localObject18 = "鏈�";
                  ((TextView)localObject4).setText((CharSequence)localObject18);
                  break label3882:
                  localObject18 = "鏈�";
                  ((TextView)localObject4).setText((CharSequence)localObject18);
                }
                catch (JSONException localJSONException2)
                {
                  localJSONException2.printStackTrace();
                  break label4005:
                  ((TextView)localObject4).setText("鏈�");
                  break label4005:
                }
              }
            }
          }
        }
      }
    }
  }

  private void j()
  {
    ((ScrollView)findViewById(2131362019)).scrollTo(0, 0);
  }

  public void a()
  {
    com.jiayuan.util.a.a("ProfileActivity", "onGotoLoginClicked");
  }

  public void a(int paramInt)
  {
    Toast localToast = Toast.makeText(this, paramInt, 0);
    localToast.setGravity(48, 0, 70);
    localToast.show();
  }

  public void a(int paramInt, String paramString)
  {
    int i1 = 2131165390;
    Object localObject = "lastLoginDate" + paramString;
    com.jiayuan.util.a.a("ProfileActivity", (String)localObject);
    TextView localTextView = (TextView)findViewById(2131362024);
    try
    {
      this.f.f = paramString;
      localObject = new Date();
      long l1 = Integer.parseInt(this.f.f);
      long l2 = 1000L * l1;
      ((Date)localObject).setTime(l2);
      if (s.a(o.k()))
      {
        StringBuffer localStringBuffer = new StringBuffer();
        String str1 = getString(2131165390);
        localStringBuffer.append(str1);
        localStringBuffer.append("\n");
        String str2 = ((Date)localObject).toLocaleString();
        localStringBuffer.append((String)localObject);
        String str3 = localStringBuffer.toString();
        localTextView.setText((CharSequence)localObject);
        return;
      }
      String str4 = getString(2131165389);
      localTextView.setText(str4);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      String str5 = String.valueOf(getString(i1));
      String str6 = str5 + "鏈";
      localTextView.setText(str6);
    }
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    Object localObject = this.f;
    ((ac)localObject).c = paramString;
    if (paramBitmap == null)
    {
      localObject = this.f.g.equals("f");
      if (localObject == 0);
    }
    for (localObject = BitmapFactory.decodeResource(getResources(), 2130837628); ; localObject = paramBitmap)
      while (true)
      {
        Bitmap localBitmap = s.a((Bitmap)localObject, 1084227584);
        this.a.setImageBitmap((Bitmap)localObject);
        return;
        localObject = BitmapFactory.decodeResource(getResources(), 2130837630);
      }
  }

  public void a(String paramString)
  {
    TextView localTextView = (TextView)findViewById(2131362031);
    Spanned localSpanned = Html.fromHtml(Html.fromHtml(paramString).toString());
    super.setText(localSpanned);
  }

  public void a(ArrayList paramArrayList)
  {
    Object localObject1 = 1;
    int i1 = null;
    Object localObject2 = new StringBuilder("onGetPhotoAmount photoUrls.size()=");
    int i2 = paramArrayList.size();
    localObject2 = i2;
    com.jiayuan.util.a.a("ProfileActivity", (String)localObject2);
    int i3 = paramArrayList.size();
    if (i3 == 0)
    {
      com.jiayuan.util.a.a("ProfileActivity", "abort gallery construct");
      label60: return;
    }
    Object localObject3 = new ArrayList(paramArrayList);
    this.g = ((ArrayList)localObject3);
    localObject3 = new ArrayList();
    this.h = ((ArrayList)localObject3);
    localObject3 = i1;
    label95: localObject2 = paramArrayList.size();
    if (localObject3 >= localObject2)
    {
      localObject3 = new a(this, this);
      this.j = ((a)localObject3);
      localObject3 = (Gallery)findViewById(2131362025);
      this.i = ((Gallery)localObject3);
      this.i.setVisibility(i1);
      localObject3 = this.i;
      localObject2 = this.j;
      ((Gallery)localObject3).setAdapter((SpinnerAdapter)localObject2);
      localObject3 = this.i;
      localObject2 = paramArrayList.size();
      if (localObject1 >= localObject2)
        break label294;
      localObject2 = localObject1;
    }
    while (true)
    {
      ((Gallery)localObject3).setSelection(localObject2);
      Gallery localGallery = this.i;
      x localx = new x(this);
      ((Gallery)localObject3).setOnItemClickListener((AdapterView.OnItemClickListener)localObject2);
      break label60:
      localObject2 = this.f.g.equals("f");
      if (localObject2 != 0);
      for (localObject2 = getResources().openRawResource(2130837629); ; localObject2 = getResources().openRawResource(2130837631))
      {
        localObject2 = BitmapFactory.decodeStream((InputStream)localObject2);
        this.h.add(localObject2);
        ++localObject3;
        break label95:
      }
      label294: localObject2 = i1;
    }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    o.a(paramJSONArray);
  }

  public void a(JSONObject paramJSONObject)
  {
    try
    {
      JSONObject localJSONObject1 = paramJSONObject.getJSONObject("userinfos");
      String str1 = o.e();
      JSONObject localJSONObject2 = localJSONObject1.getJSONObject(str1);
      o.a(s.a(localJSONObject2));
      String str2 = String.valueOf(2);
      o.f(localJSONObject2.getString(str2));
      StringBuilder localStringBuilder = new StringBuilder("onGetProfiles profile=");
      String str3 = o.j().toString();
      String str4 = str3;
      com.jiayuan.util.a.a("ProfileActivity", str4);
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public void a_(String paramString)
  {
    this.d.dismiss();
    Toast.makeText(this, 2131165663, 1).show();
  }

  public void b()
  {
    try
    {
      String str = getResources().getString(2131165195);
      ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
      this.d = localProgressDialog;
      this.d.setCancelable(true);
      com.jiayuan.util.a.a("ProfileActivity", "---------onWaitingActivityStart()---------");
      return;
    }
    catch (Exception localException)
    {
    }
    catch (WindowManager.BadTokenException localBadTokenException)
    {
    }
  }

  public void b(int paramInt1, int paramInt2)
  {
    String str = "onMatchOkResult index=" + paramInt1 + ", result=" + paramInt2;
    com.jiayuan.util.a.a("ProfileActivity", str);
    switch (paramInt2)
    {
    case -126:
    default:
    case 1:
    case -100:
    case -123:
    case -111:
    case -125:
    case -115:
    case -113:
    case -112:
    case -116:
    case -117:
    case -118:
    case -119:
    case -120:
    case -121:
    case -122:
    case -124:
    case -127:
    case -128:
    case -129:
    case -130:
    }
    while (true)
    {
      return;
      a(2131165353);
      continue;
      a(2131165496);
      continue;
      a(2131165497);
      continue;
      a(2131165495);
      continue;
      a(2131165498);
      continue;
      a(2131165502);
      continue;
      a(2131165504);
      continue;
      showDialog(1);
      continue;
      a(2131165506);
      continue;
      a(2131165507);
      continue;
      a(2131165508);
      continue;
      a(2131165509);
      continue;
      a(2131165511);
      continue;
      a(2131165512);
      continue;
      a(2131165501);
      continue;
      a(2131165503);
    }
  }

  public void b(int paramInt, String paramString, Bitmap paramBitmap)
  {
    Object localObject = "ProfileActivity";
    String str = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    com.jiayuan.util.a.a((String)localObject, str);
    if (paramBitmap != null)
    {
      this.h.set(paramInt, paramBitmap);
      label54: this.j.notifyDataSetChanged();
      return;
    }
    localObject = this.f.g.equals("f");
    if (localObject != 0);
    for (localObject = BitmapFactory.decodeResource(getResources(), 2130837628); ; localObject = BitmapFactory.decodeResource(getResources(), 2130837630))
    {
      this.h.set(paramInt, localObject);
      break label54:
    }
  }

  // ERROR //
  public void b(JSONObject paramJSONObject)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: getfield 873	com/jiayuan/profile/ProfileActivity:d	Landroid/app/ProgressDialog;
    //   6: invokevirtual 878	android/app/ProgressDialog:dismiss	()V
    //   9: ldc 112
    //   11: astore_3
    //   12: new 267	java/lang/StringBuilder
    //   15: dup
    //   16: ldc_w 925
    //   19: invokespecial 270	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   22: astore 4
    //   24: aload_1
    //   25: invokevirtual 870	org/json/JSONObject:toString	()Ljava/lang/String;
    //   28: astore 5
    //   30: aload 4
    //   32: aload 5
    //   34: invokevirtual 283	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: invokevirtual 284	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   40: astore 4
    //   42: aload_3
    //   43: aload 4
    //   45: invokestatic 119	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   48: aload_1
    //   49: ldc_w 927
    //   52: invokevirtual 857	org/json/JSONObject:getJSONObject	(Ljava/lang/String;)Lorg/json/JSONObject;
    //   55: astore_3
    //   56: aload_0
    //   57: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   60: astore 4
    //   62: iconst_3
    //   63: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   66: astore 5
    //   68: aload_3
    //   69: aload 5
    //   71: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   74: astore 5
    //   76: aload 4
    //   78: aload 5
    //   80: putfield 187	com/jiayuan/profile/ac:b	Ljava/lang/String;
    //   83: aload_0
    //   84: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   87: astore 4
    //   89: iconst_2
    //   90: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   93: astore 5
    //   95: aload_3
    //   96: aload 5
    //   98: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   101: astore 5
    //   103: aload 4
    //   105: aload 5
    //   107: putfield 240	com/jiayuan/profile/ac:g	Ljava/lang/String;
    //   110: aload_0
    //   111: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   114: astore 4
    //   116: bipush 105
    //   118: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   121: astore 5
    //   123: aload_3
    //   124: aload 5
    //   126: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   129: astore 5
    //   131: aload 4
    //   133: iload 5
    //   135: putfield 305	com/jiayuan/profile/ac:h	I
    //   138: aload_0
    //   139: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   142: astore 4
    //   144: iconst_5
    //   145: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   148: astore 5
    //   150: aload_3
    //   151: aload 5
    //   153: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   156: astore 5
    //   158: aload 4
    //   160: aload 5
    //   162: putfield 294	com/jiayuan/profile/ac:j	Ljava/lang/String;
    //   165: aload_0
    //   166: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   169: astore 4
    //   171: bipush 6
    //   173: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   176: astore 5
    //   178: aload_3
    //   179: aload 5
    //   181: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   184: astore 5
    //   186: aload 4
    //   188: iload 5
    //   190: putfield 292	com/jiayuan/profile/ac:i	I
    //   193: aload_0
    //   194: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   197: astore 4
    //   199: bipush 112
    //   201: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   204: astore 5
    //   206: aload_3
    //   207: aload 5
    //   209: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   212: astore 5
    //   214: aload 4
    //   216: iload 5
    //   218: putfield 316	com/jiayuan/profile/ac:k	I
    //   221: aload_0
    //   222: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   225: astore 4
    //   227: bipush 104
    //   229: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   232: astore 5
    //   234: aload_3
    //   235: aload 5
    //   237: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   240: astore 5
    //   242: aload 4
    //   244: iload 5
    //   246: putfield 313	com/jiayuan/profile/ac:l	I
    //   249: aload_0
    //   250: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   253: astore 4
    //   255: bipush 100
    //   257: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   260: astore 5
    //   262: aload_3
    //   263: aload 5
    //   265: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   268: astore 5
    //   270: aload 4
    //   272: iload 5
    //   274: putfield 329	com/jiayuan/profile/ac:m	I
    //   277: aload_0
    //   278: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   281: astore 4
    //   283: bipush 101
    //   285: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   288: astore 5
    //   290: aload_3
    //   291: aload 5
    //   293: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   296: astore 5
    //   298: aload 4
    //   300: iload 5
    //   302: putfield 335	com/jiayuan/profile/ac:n	I
    //   305: aload_0
    //   306: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   309: astore 4
    //   311: bipush 114
    //   313: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   316: astore 5
    //   318: aload_3
    //   319: aload 5
    //   321: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   324: astore 5
    //   326: aload 4
    //   328: iload 5
    //   330: putfield 345	com/jiayuan/profile/ac:o	I
    //   333: aload_0
    //   334: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   337: astore 4
    //   339: bipush 127
    //   341: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   344: astore 5
    //   346: aload_3
    //   347: aload 5
    //   349: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   352: astore 5
    //   354: aload 4
    //   356: iload 5
    //   358: putfield 423	com/jiayuan/profile/ac:u	I
    //   361: aload_0
    //   362: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   365: astore 4
    //   367: sipush 128
    //   370: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   373: astore 5
    //   375: aload_3
    //   376: aload 5
    //   378: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   381: astore 5
    //   383: aload 4
    //   385: iload 5
    //   387: putfield 428	com/jiayuan/profile/ac:v	I
    //   390: aload_0
    //   391: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   394: astore 4
    //   396: sipush 129
    //   399: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   402: astore 5
    //   404: aload_3
    //   405: aload 5
    //   407: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   410: astore 5
    //   412: aload 4
    //   414: iload 5
    //   416: putfield 436	com/jiayuan/profile/ac:w	I
    //   419: aload_0
    //   420: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   423: astore 4
    //   425: sipush 130
    //   428: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   431: astore 5
    //   433: aload_3
    //   434: aload 5
    //   436: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   439: astore 5
    //   441: aload 4
    //   443: iload 5
    //   445: putfield 439	com/jiayuan/profile/ac:x	I
    //   448: aload_0
    //   449: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   452: astore 4
    //   454: sipush 131
    //   457: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   460: astore 5
    //   462: aload_3
    //   463: aload 5
    //   465: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   468: astore 5
    //   470: aload 4
    //   472: iload 5
    //   474: putfield 453	com/jiayuan/profile/ac:y	I
    //   477: aload_0
    //   478: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   481: astore 4
    //   483: sipush 132
    //   486: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   489: astore 5
    //   491: aload_3
    //   492: aload 5
    //   494: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   497: astore 5
    //   499: aload 4
    //   501: iload 5
    //   503: putfield 461	com/jiayuan/profile/ac:z	I
    //   506: aload_0
    //   507: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   510: astore 4
    //   512: sipush 133
    //   515: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   518: astore 5
    //   520: aload_3
    //   521: aload 5
    //   523: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   526: astore 5
    //   528: aload 4
    //   530: iload 5
    //   532: putfield 447	com/jiayuan/profile/ac:A	I
    //   535: aload_0
    //   536: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   539: astore 4
    //   541: sipush 134
    //   544: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   547: astore 5
    //   549: aload_3
    //   550: aload 5
    //   552: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   555: astore 5
    //   557: aload 4
    //   559: iload 5
    //   561: putfield 933	com/jiayuan/profile/ac:B	I
    //   564: aload_0
    //   565: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   568: astore 4
    //   570: sipush 135
    //   573: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   576: astore 5
    //   578: aload_3
    //   579: aload 5
    //   581: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   584: astore 5
    //   586: aload 4
    //   588: iload 5
    //   590: putfield 467	com/jiayuan/profile/ac:C	I
    //   593: aload_0
    //   594: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   597: astore 4
    //   599: sipush 136
    //   602: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   605: astore 5
    //   607: aload_3
    //   608: aload 5
    //   610: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   613: astore 5
    //   615: aload 4
    //   617: iload 5
    //   619: putfield 473	com/jiayuan/profile/ac:D	I
    //   622: aload_0
    //   623: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   626: astore 4
    //   628: sipush 137
    //   631: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   634: astore 5
    //   636: aload_3
    //   637: aload 5
    //   639: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   642: astore 5
    //   644: aload 4
    //   646: iload 5
    //   648: putfield 476	com/jiayuan/profile/ac:E	I
    //   651: aload_0
    //   652: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   655: astore 4
    //   657: sipush 200
    //   660: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   663: astore 5
    //   665: aload_3
    //   666: aload 5
    //   668: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   671: astore 5
    //   673: aload 4
    //   675: iload 5
    //   677: putfield 936	com/jiayuan/profile/ac:F	I
    //   680: aload_0
    //   681: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   684: astore 4
    //   686: sipush 201
    //   689: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   692: astore 5
    //   694: aload_3
    //   695: aload 5
    //   697: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   700: astore 5
    //   702: aload 4
    //   704: iload 5
    //   706: putfield 939	com/jiayuan/profile/ac:G	I
    //   709: aload_0
    //   710: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   713: astore 4
    //   715: sipush 202
    //   718: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   721: astore 5
    //   723: aload_3
    //   724: aload 5
    //   726: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   729: astore 5
    //   731: aload 4
    //   733: iload 5
    //   735: putfield 942	com/jiayuan/profile/ac:H	I
    //   738: aload_0
    //   739: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   742: astore 4
    //   744: sipush 203
    //   747: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   750: astore 5
    //   752: aload_3
    //   753: aload 5
    //   755: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   758: astore 5
    //   760: aload 4
    //   762: iload 5
    //   764: putfield 944	com/jiayuan/profile/ac:I	I
    //   767: aload_0
    //   768: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   771: astore 4
    //   773: sipush 204
    //   776: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   779: astore 5
    //   781: aload_3
    //   782: aload 5
    //   784: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   787: astore 5
    //   789: aload 4
    //   791: iload 5
    //   793: putfield 947	com/jiayuan/profile/ac:J	I
    //   796: aload_0
    //   797: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   800: astore 4
    //   802: sipush 205
    //   805: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   808: astore 5
    //   810: aload_3
    //   811: aload 5
    //   813: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   816: astore 5
    //   818: aload 4
    //   820: iload 5
    //   822: putfield 950	com/jiayuan/profile/ac:K	I
    //   825: aload_0
    //   826: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   829: astore 4
    //   831: sipush 206
    //   834: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   837: astore 5
    //   839: aload_3
    //   840: aload 5
    //   842: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   845: astore 5
    //   847: aload 4
    //   849: iload 5
    //   851: putfield 350	com/jiayuan/profile/ac:d	I
    //   854: aload_0
    //   855: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   858: astore 4
    //   860: sipush 221
    //   863: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   866: astore 5
    //   868: aload_3
    //   869: aload 5
    //   871: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   874: astore 5
    //   876: aload 4
    //   878: aload 5
    //   880: putfield 762	com/jiayuan/profile/ac:c	Ljava/lang/String;
    //   883: aload_0
    //   884: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   887: astore 4
    //   889: bipush 111
    //   891: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   894: astore 5
    //   896: aload_3
    //   897: aload 5
    //   899: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   902: astore 5
    //   904: aload 4
    //   906: iload 5
    //   908: putfield 389	com/jiayuan/profile/ac:p	I
    //   911: aload_0
    //   912: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   915: astore 4
    //   917: bipush 116
    //   919: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   922: astore 5
    //   924: aload_3
    //   925: aload 5
    //   927: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   930: astore 5
    //   932: aload 4
    //   934: iload 5
    //   936: putfield 397	com/jiayuan/profile/ac:r	I
    //   939: aload_0
    //   940: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   943: astore 4
    //   945: bipush 121
    //   947: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   950: astore 5
    //   952: aload_3
    //   953: aload 5
    //   955: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   958: astore 5
    //   960: aload 4
    //   962: iload 5
    //   964: putfield 716	com/jiayuan/profile/ac:s	I
    //   967: aload_0
    //   968: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   971: astore 4
    //   973: bipush 122
    //   975: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   978: astore 5
    //   980: aload_3
    //   981: aload 5
    //   983: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   986: astore 5
    //   988: aload 4
    //   990: iload 5
    //   992: putfield 723	com/jiayuan/profile/ac:t	I
    //   995: aload_0
    //   996: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   999: astore 4
    //   1001: bipush 117
    //   1003: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1006: astore 5
    //   1008: aload_3
    //   1009: aload 5
    //   1011: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1014: astore 5
    //   1016: aload 4
    //   1018: iload 5
    //   1020: putfield 392	com/jiayuan/profile/ac:q	I
    //   1023: sipush 158
    //   1026: istore 4
    //   1028: iload 4
    //   1030: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1033: astore 4
    //   1035: aload_3
    //   1036: aload 4
    //   1038: invokevirtual 954	org/json/JSONObject:getJSONArray	(Ljava/lang/String;)Lorg/json/JSONArray;
    //   1041: astore 4
    //   1043: aload 4
    //   1045: invokevirtual 957	org/json/JSONArray:length	()I
    //   1048: newarray int
    //   1050: astore 5
    //   1052: iload_2
    //   1053: istore 6
    //   1055: aload 5
    //   1057: arraylength
    //   1058: istore 7
    //   1060: iload 6
    //   1062: iload 7
    //   1064: if_icmplt +1104 -> 2168
    //   1067: aload_0
    //   1068: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1071: astore 4
    //   1073: aload 4
    //   1075: aload 5
    //   1077: putfield 496	com/jiayuan/profile/ac:L	[I
    //   1080: aload_0
    //   1081: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1084: astore 4
    //   1086: bipush 124
    //   1088: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1091: astore 5
    //   1093: aload_3
    //   1094: aload 5
    //   1096: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1099: astore 5
    //   1101: aload 4
    //   1103: iload 5
    //   1105: putfield 505	com/jiayuan/profile/ac:M	I
    //   1108: aload_0
    //   1109: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1112: astore 4
    //   1114: sipush 148
    //   1117: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1120: astore 5
    //   1122: aload_3
    //   1123: aload 5
    //   1125: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1128: astore 5
    //   1130: aload 4
    //   1132: aload 5
    //   1134: putfield 514	com/jiayuan/profile/ac:N	Ljava/lang/String;
    //   1137: aload_0
    //   1138: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1141: astore 4
    //   1143: sipush 149
    //   1146: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1149: astore 5
    //   1151: aload_3
    //   1152: aload 5
    //   1154: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1157: astore 5
    //   1159: aload 4
    //   1161: aload 5
    //   1163: putfield 519	com/jiayuan/profile/ac:O	Ljava/lang/String;
    //   1166: aload_0
    //   1167: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1170: astore 4
    //   1172: sipush 147
    //   1175: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1178: astore 5
    //   1180: aload_3
    //   1181: aload 5
    //   1183: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1186: astore 5
    //   1188: aload 4
    //   1190: aload 5
    //   1192: putfield 524	com/jiayuan/profile/ac:P	Ljava/lang/String;
    //   1195: aload_0
    //   1196: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1199: astore 4
    //   1201: bipush 123
    //   1203: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1206: astore 5
    //   1208: aload_3
    //   1209: aload 5
    //   1211: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1214: astore 5
    //   1216: aload 4
    //   1218: aload 5
    //   1220: putfield 529	com/jiayuan/profile/ac:Q	Ljava/lang/String;
    //   1223: aload_0
    //   1224: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1227: astore 4
    //   1229: sipush 146
    //   1232: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1235: astore 5
    //   1237: aload_3
    //   1238: aload 5
    //   1240: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1243: astore 5
    //   1245: aload 4
    //   1247: aload 5
    //   1249: putfield 534	com/jiayuan/profile/ac:R	Ljava/lang/String;
    //   1252: aload_0
    //   1253: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1256: astore 4
    //   1258: bipush 113
    //   1260: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1263: astore 5
    //   1265: aload_3
    //   1266: aload 5
    //   1268: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1271: astore 5
    //   1273: aload 4
    //   1275: iload 5
    //   1277: putfield 539	com/jiayuan/profile/ac:S	I
    //   1280: aload_0
    //   1281: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1284: astore 4
    //   1286: sipush 181
    //   1289: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1292: astore 5
    //   1294: aload_3
    //   1295: aload 5
    //   1297: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1300: astore 5
    //   1302: aload 4
    //   1304: iload 5
    //   1306: putfield 543	com/jiayuan/profile/ac:T	I
    //   1309: aload_0
    //   1310: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1313: astore 4
    //   1315: sipush 179
    //   1318: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1321: astore 5
    //   1323: aload_3
    //   1324: aload 5
    //   1326: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1329: astore 5
    //   1331: aload 4
    //   1333: iload 5
    //   1335: putfield 556	com/jiayuan/profile/ac:W	I
    //   1338: aload_0
    //   1339: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1342: astore 4
    //   1344: sipush 184
    //   1347: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1350: astore 5
    //   1352: aload_3
    //   1353: aload 5
    //   1355: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1358: astore 5
    //   1360: aload 4
    //   1362: aload 5
    //   1364: putfield 548	com/jiayuan/profile/ac:U	Ljava/lang/String;
    //   1367: aload_0
    //   1368: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1371: astore 4
    //   1373: bipush 74
    //   1375: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1378: astore 5
    //   1380: aload_3
    //   1381: aload 5
    //   1383: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1386: astore 5
    //   1388: aload 4
    //   1390: aload 5
    //   1392: putfield 552	com/jiayuan/profile/ac:V	Ljava/lang/String;
    //   1395: aload_0
    //   1396: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1399: astore 4
    //   1401: sipush 180
    //   1404: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1407: astore 5
    //   1409: aload_3
    //   1410: aload 5
    //   1412: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1415: astore 5
    //   1417: aload 4
    //   1419: iload 5
    //   1421: putfield 561	com/jiayuan/profile/ac:X	I
    //   1424: aload_0
    //   1425: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1428: astore 4
    //   1430: sipush 160
    //   1433: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1436: astore 5
    //   1438: aload_3
    //   1439: aload 5
    //   1441: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1444: astore 5
    //   1446: aload 4
    //   1448: iload 5
    //   1450: putfield 566	com/jiayuan/profile/ac:Y	I
    //   1453: aload_0
    //   1454: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1457: astore 4
    //   1459: sipush 152
    //   1462: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1465: astore 5
    //   1467: aload_3
    //   1468: aload 5
    //   1470: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1473: astore 5
    //   1475: aload 4
    //   1477: iload 5
    //   1479: putfield 569	com/jiayuan/profile/ac:Z	I
    //   1482: aload_0
    //   1483: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1486: astore 4
    //   1488: sipush 150
    //   1491: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1494: astore 5
    //   1496: aload_3
    //   1497: aload 5
    //   1499: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1502: astore 5
    //   1504: aload 4
    //   1506: iload 5
    //   1508: putfield 574	com/jiayuan/profile/ac:aa	I
    //   1511: aload_0
    //   1512: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1515: astore 4
    //   1517: sipush 151
    //   1520: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1523: astore 5
    //   1525: aload_3
    //   1526: aload 5
    //   1528: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1531: astore 5
    //   1533: aload 4
    //   1535: iload 5
    //   1537: putfield 579	com/jiayuan/profile/ac:ab	I
    //   1540: aload_0
    //   1541: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1544: astore 4
    //   1546: sipush 162
    //   1549: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1552: astore 5
    //   1554: aload_3
    //   1555: aload 5
    //   1557: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1560: astore 5
    //   1562: aload 4
    //   1564: iload 5
    //   1566: putfield 584	com/jiayuan/profile/ac:ac	I
    //   1569: sipush 161
    //   1572: istore 4
    //   1574: iload 4
    //   1576: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1579: astore 4
    //   1581: aload_3
    //   1582: aload 4
    //   1584: invokevirtual 954	org/json/JSONObject:getJSONArray	(Ljava/lang/String;)Lorg/json/JSONArray;
    //   1587: astore 4
    //   1589: aload 4
    //   1591: invokevirtual 957	org/json/JSONArray:length	()I
    //   1594: newarray int
    //   1596: astore 5
    //   1598: iload_2
    //   1599: istore 6
    //   1601: aload 5
    //   1603: arraylength
    //   1604: istore 8
    //   1606: iload 6
    //   1608: iload 8
    //   1610: if_icmplt +599 -> 2209
    //   1613: aload_0
    //   1614: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1617: astore 4
    //   1619: aload 4
    //   1621: aload 5
    //   1623: putfield 591	com/jiayuan/profile/ac:ad	[I
    //   1626: aload_0
    //   1627: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1630: astore 4
    //   1632: sipush 155
    //   1635: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1638: astore 5
    //   1640: aload_3
    //   1641: aload 5
    //   1643: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1646: astore 5
    //   1648: aload 4
    //   1650: iload 5
    //   1652: putfield 599	com/jiayuan/profile/ac:ae	I
    //   1655: aload_0
    //   1656: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1659: astore 4
    //   1661: sipush 182
    //   1664: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1667: astore 5
    //   1669: aload_3
    //   1670: aload 5
    //   1672: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1675: astore 5
    //   1677: aload 4
    //   1679: iload 5
    //   1681: putfield 604	com/jiayuan/profile/ac:af	I
    //   1684: aload_0
    //   1685: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1688: astore 4
    //   1690: bipush 102
    //   1692: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1695: astore 5
    //   1697: aload_3
    //   1698: aload 5
    //   1700: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1703: astore 5
    //   1705: aload 4
    //   1707: iload 5
    //   1709: putfield 608	com/jiayuan/profile/ac:ag	I
    //   1712: aload_0
    //   1713: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1716: astore 4
    //   1718: bipush 103
    //   1720: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1723: astore 5
    //   1725: aload_3
    //   1726: aload 5
    //   1728: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1731: astore 5
    //   1733: aload 4
    //   1735: iload 5
    //   1737: putfield 611	com/jiayuan/profile/ac:ah	I
    //   1740: aload_0
    //   1741: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1744: astore 4
    //   1746: sipush 185
    //   1749: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1752: astore 5
    //   1754: aload_3
    //   1755: aload 5
    //   1757: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1760: astore 5
    //   1762: aload 4
    //   1764: iload 5
    //   1766: putfield 622	com/jiayuan/profile/ac:ai	I
    //   1769: aload_0
    //   1770: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1773: astore 4
    //   1775: sipush 186
    //   1778: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1781: astore 5
    //   1783: aload_3
    //   1784: aload 5
    //   1786: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1789: astore 5
    //   1791: aload 4
    //   1793: iload 5
    //   1795: putfield 627	com/jiayuan/profile/ac:aj	I
    //   1798: aload_0
    //   1799: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1802: astore 4
    //   1804: sipush 145
    //   1807: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1810: astore 5
    //   1812: aload_3
    //   1813: aload 5
    //   1815: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   1818: astore 5
    //   1820: aload 4
    //   1822: aload 5
    //   1824: putfield 634	com/jiayuan/profile/ac:ak	Ljava/lang/String;
    //   1827: aload_0
    //   1828: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1831: astore 4
    //   1833: sipush 187
    //   1836: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1839: astore 5
    //   1841: aload_3
    //   1842: aload 5
    //   1844: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1847: astore 5
    //   1849: aload 4
    //   1851: iload 5
    //   1853: putfield 643	com/jiayuan/profile/ac:al	I
    //   1856: aload_0
    //   1857: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1860: astore 4
    //   1862: sipush 156
    //   1865: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1868: astore 5
    //   1870: aload_3
    //   1871: aload 5
    //   1873: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1876: astore 5
    //   1878: aload 4
    //   1880: iload 5
    //   1882: putfield 648	com/jiayuan/profile/ac:am	I
    //   1885: aload_0
    //   1886: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1889: astore 4
    //   1891: sipush 153
    //   1894: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1897: astore 5
    //   1899: aload_3
    //   1900: aload 5
    //   1902: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1905: astore 5
    //   1907: aload 4
    //   1909: iload 5
    //   1911: putfield 653	com/jiayuan/profile/ac:an	I
    //   1914: aload_0
    //   1915: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1918: astore 4
    //   1920: sipush 163
    //   1923: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1926: astore 5
    //   1928: aload_3
    //   1929: aload 5
    //   1931: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1934: astore 5
    //   1936: aload 4
    //   1938: iload 5
    //   1940: putfield 658	com/jiayuan/profile/ac:ao	I
    //   1943: aload_0
    //   1944: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1947: astore 4
    //   1949: bipush 119
    //   1951: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1954: astore 5
    //   1956: aload_3
    //   1957: aload 5
    //   1959: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1962: astore 5
    //   1964: aload 4
    //   1966: iload 5
    //   1968: putfield 663	com/jiayuan/profile/ac:ap	I
    //   1971: aload_0
    //   1972: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   1975: astore 4
    //   1977: sipush 154
    //   1980: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   1983: astore 5
    //   1985: aload_3
    //   1986: aload 5
    //   1988: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   1991: astore 5
    //   1993: aload 4
    //   1995: iload 5
    //   1997: putfield 668	com/jiayuan/profile/ac:aq	I
    //   2000: sipush 171
    //   2003: istore 4
    //   2005: iload 4
    //   2007: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   2010: astore 4
    //   2012: aload_3
    //   2013: aload 4
    //   2015: invokevirtual 954	org/json/JSONObject:getJSONArray	(Ljava/lang/String;)Lorg/json/JSONArray;
    //   2018: astore 4
    //   2020: aload 4
    //   2022: invokevirtual 957	org/json/JSONArray:length	()I
    //   2025: newarray int
    //   2027: astore 5
    //   2029: iload_2
    //   2030: istore 6
    //   2032: aload 5
    //   2034: arraylength
    //   2035: istore 9
    //   2037: iload 6
    //   2039: iload 9
    //   2041: if_icmplt +238 -> 2279
    //   2044: aload_0
    //   2045: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   2048: astore 4
    //   2050: aload 4
    //   2052: aload 5
    //   2054: putfield 673	com/jiayuan/profile/ac:ar	[I
    //   2057: aload_0
    //   2058: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   2061: astore 10
    //   2063: bipush 120
    //   2065: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   2068: astore 11
    //   2070: aload_3
    //   2071: aload 11
    //   2073: invokevirtual 930	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   2076: astore 12
    //   2078: aload 10
    //   2080: iload 12
    //   2082: putfield 691	com/jiayuan/profile/ac:as	I
    //   2085: aload_0
    //   2086: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   2089: astore 13
    //   2091: sipush 175
    //   2094: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   2097: astore 14
    //   2099: aload_3
    //   2100: aload 14
    //   2102: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   2105: astore 15
    //   2107: aload 13
    //   2109: aload 15
    //   2111: putfield 678	com/jiayuan/profile/ac:at	Ljava/lang/String;
    //   2114: aload_0
    //   2115: getfield 53	com/jiayuan/profile/ProfileActivity:f	Lcom/jiayuan/profile/ac;
    //   2118: astore 16
    //   2120: sipush 176
    //   2123: invokestatic 624	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   2126: astore 17
    //   2128: aload_3
    //   2129: aload 17
    //   2131: invokevirtual 363	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   2134: astore_3
    //   2135: aload 16
    //   2137: aload_3
    //   2138: putfield 682	com/jiayuan/profile/ac:au	Ljava/lang/String;
    //   2141: aload_0
    //   2142: invokespecial 959	com/jiayuan/profile/ProfileActivity:i	()V
    //   2145: return
    //   2146: astore 4
    //   2148: aload 4
    //   2150: invokevirtual 960	java/lang/Exception:printStackTrace	()V
    //   2153: goto -1328 -> 825
    //   2156: astore_3
    //   2157: aload_3
    //   2158: invokevirtual 696	org/json/JSONException:printStackTrace	()V
    //   2161: aload_0
    //   2162: invokespecial 959	com/jiayuan/profile/ProfileActivity:i	()V
    //   2165: goto -20 -> 2145
    //   2168: aload 4
    //   2170: iload 6
    //   2172: invokevirtual 963	org/json/JSONArray:getInt	(I)I
    //   2175: astore 18
    //   2177: aload 5
    //   2179: iload 6
    //   2181: iload 18
    //   2183: iastore
    //   2184: iinc 6 1
    //   2187: goto -1132 -> 1055
    //   2190: astore 4
    //   2192: aload 4
    //   2194: invokevirtual 960	java/lang/Exception:printStackTrace	()V
    //   2197: goto -1117 -> 1080
    //   2200: astore 19
    //   2202: aload_0
    //   2203: invokespecial 959	com/jiayuan/profile/ProfileActivity:i	()V
    //   2206: aload 19
    //   2208: athrow
    //   2209: aload 4
    //   2211: iload 6
    //   2213: invokevirtual 963	org/json/JSONArray:getInt	(I)I
    //   2216: astore 20
    //   2218: aload 5
    //   2220: iload 6
    //   2222: iload 20
    //   2224: iastore
    //   2225: new 267	java/lang/StringBuilder
    //   2228: dup
    //   2229: ldc_w 965
    //   2232: invokespecial 270	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   2235: astore 21
    //   2237: aload 5
    //   2239: iload 6
    //   2241: iaload
    //   2242: istore 22
    //   2244: aload 21
    //   2246: iload 22
    //   2248: invokevirtual 319	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   2251: invokevirtual 284	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   2254: astore 23
    //   2256: ldc 112
    //   2258: aload 23
    //   2260: invokestatic 119	com/jiayuan/util/a:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   2263: iinc 6 1
    //   2266: goto -665 -> 1601
    //   2269: astore 4
    //   2271: aload 4
    //   2273: invokevirtual 960	java/lang/Exception:printStackTrace	()V
    //   2276: goto -650 -> 1626
    //   2279: aload 4
    //   2281: iload 6
    //   2283: invokevirtual 963	org/json/JSONArray:getInt	(I)I
    //   2286: astore 24
    //   2288: aload 5
    //   2290: iload 6
    //   2292: iload 24
    //   2294: iastore
    //   2295: iinc 6 1
    //   2298: goto -266 -> 2032
    //   2301: astore 4
    //   2303: aload 4
    //   2305: invokevirtual 960	java/lang/Exception:printStackTrace	()V
    //   2308: goto -251 -> 2057
    //
    // Exception table:
    //   from	to	target	type
    //   593	825	2146	java/lang/Exception
    //   48	593	2156	org/json/JSONException
    //   593	825	2156	org/json/JSONException
    //   825	1023	2156	org/json/JSONException
    //   1028	1080	2156	org/json/JSONException
    //   1080	1569	2156	org/json/JSONException
    //   1574	1626	2156	org/json/JSONException
    //   1626	2000	2156	org/json/JSONException
    //   2005	2057	2156	org/json/JSONException
    //   2057	2141	2156	org/json/JSONException
    //   2148	2153	2156	org/json/JSONException
    //   2168	2184	2156	org/json/JSONException
    //   2192	2197	2156	org/json/JSONException
    //   2209	2263	2156	org/json/JSONException
    //   2271	2276	2156	org/json/JSONException
    //   2279	2295	2156	org/json/JSONException
    //   2303	2308	2156	org/json/JSONException
    //   1028	1080	2190	java/lang/Exception
    //   2168	2184	2190	java/lang/Exception
    //   48	593	2200	finally
    //   593	825	2200	finally
    //   825	1023	2200	finally
    //   1028	1080	2200	finally
    //   1080	1569	2200	finally
    //   1574	1626	2200	finally
    //   1626	2000	2200	finally
    //   2005	2057	2200	finally
    //   2057	2141	2200	finally
    //   2148	2153	2200	finally
    //   2157	2161	2200	finally
    //   2168	2184	2200	finally
    //   2192	2197	2200	finally
    //   2209	2263	2200	finally
    //   2271	2276	2200	finally
    //   2279	2295	2200	finally
    //   2303	2308	2200	finally
    //   1574	1626	2269	java/lang/Exception
    //   2209	2263	2269	java/lang/Exception
    //   2005	2057	2301	java/lang/Exception
    //   2279	2295	2301	java/lang/Exception
  }

  public void c(String paramString)
  {
  }

  public void c(JSONObject paramJSONObject)
  {
    this.f.e = paramJSONObject;
    TextView localTextView = (TextView)findViewById(2131362023);
    while (true)
      try
      {
        if (paramJSONObject.getString("code").equalsIgnoreCase("0"))
        {
          int i1 = this.f.d;
          String str1 = String.valueOf(com.jiayuan.util.f.p(this, i1));
          StringBuilder localStringBuilder = new StringBuilder(str1).append("/");
          String str2 = s.a(this.f.e.getString("dis"));
          String str3 = str2;
          localTextView.setText(str3);
          return;
        }
        int i2 = this.f.d;
        String str4 = String.valueOf(com.jiayuan.util.f.p(this, i2));
        String str5 = str4 + "/" + "璺濈�";
        localTextView.setText(str5);
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
  }

  public void d()
  {
    this.d.dismiss();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903090);
    this.e = this;
    com.jiayuan.util.a.a("ProfileActivity", "onCreate");
    Object localObject1 = new ac();
    this.f = ((ac)localObject1);
    localObject1 = o.i;
    if (localObject1 != null)
    {
      int i1 = 0;
      o.i = i1;
    }
    Object localObject2 = getIntent().getExtras();
    ac localac1 = this.f;
    String str1 = ((Bundle)localObject2).getString("uid");
    localac1.a = str1;
    ac localac2 = this.f;
    String str2 = ((Bundle)localObject2).getString("sex");
    localac2.g = str2;
    int i3 = ((Bundle)localObject2).getInt("src");
    this.n = i3;
    int i4 = ((Bundle)localObject2).getInt("profileSrc");
    this.q = i4;
    int i5 = ((Bundle)localObject2).getInt("matchSrc");
    this.p = i5;
    localObject2 = ((Bundle)localObject2).getBoolean("isMatchBtnEnable", true);
    this.c = localObject2;
    localObject2 = (Gallery)findViewById(2131362025);
    this.i = ((Gallery)localObject2);
    this.i.setVisibility(8);
    localObject2 = o.d(this);
    int i6 = o.e(this);
    localObject2 /= 2;
    this.k = i2;
    int i2 = i6 / 2;
    this.l = i2;
    Object localObject3 = (ImageView)findViewById(2131362020);
    this.a = ((ImageView)localObject3);
    localObject3 = this.f.g;
    if (localObject3 == null);
    for (localObject3 = BitmapFactory.decodeResource(getResources(), 2130837632); ; localObject3 = BitmapFactory.decodeResource(getResources(), 2130837631))
      while (true)
      {
        Bitmap localBitmap = s.a((Bitmap)localObject3, 1084227584);
        this.a.setImageBitmap((Bitmap)localObject3);
        String str3 = this.f.a;
        int i7 = this.k;
        int i8 = this.l;
        int i9 = this.q;
        ProfileActivity localProfileActivity = this;
        new y(localProfileActivity, str3, i7, i8, i9).a();
        TextView localTextView = (TextView)findViewById(2131362018);
        this.m = ((TextView)localObject3);
        Button localButton1 = (Button)findViewById(2131362028);
        c localc = new c(this);
        ((Button)localObject3).setOnClickListener(localc);
        Button localButton2 = (Button)findViewById(2131362029);
        d locald = new d(this);
        ((Button)localObject3).setOnClickListener(locald);
        Button localButton3 = (Button)findViewById(2131362027);
        this.b = ((Button)localObject3);
        if (!this.c)
          this.b.setEnabled(null);
        Button localButton4 = this.b;
        h localh = new h(this);
        localButton4.setOnClickListener(localh);
        if (!s.a(o.k()))
        {
          View localView = findViewById(2131362024);
          g localg = new g(this);
          localView.setOnClickListener(localg);
        }
        return;
        localObject3 = this.f.g.equals("f");
        if (localObject3 == 0)
          break;
        localObject3 = BitmapFactory.decodeResource(getResources(), 2130837629);
      }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1 = 0;
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    case 2:
    }
    for (Object localObject = i1; ; localObject = new AlertDialog.Builder(this).setTitle(2131165443).setView(i1).create())
    {
      while (true)
      {
        return localObject;
        localObject = new AlertDialog.Builder(this).setTitle(2131165670).setMessage(2131165669);
        t localt = new t(this);
        localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165640, localt);
        u localu = new u(this);
        localObject = ((AlertDialog.Builder)localObject).setNeutralButton(2131165641, localu);
        v localv = new v(this);
        localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, localv).create();
        continue;
        localObject = new AlertDialog.Builder(this).setTitle(2131165644).setMessage(2131165645);
        w localw = new w(this);
        localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165482, localw).create();
      }
      View localView = getLayoutInflater().inflate(2130903092, i1);
      localObject = (Button)i1.findViewById(2131362119);
      Button localButton = (Button)i1.findViewById(2131362120);
      View.OnClickListener localOnClickListener = this.o;
      ((Button)localObject).setOnClickListener(localOnClickListener);
      localObject = this.o;
      localButton.setOnClickListener((View.OnClickListener)localObject);
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131296261, paramMenu);
    return true;
  }

  public void onDestroy()
  {
    q.a(this);
    super.onDestroy();
    System.gc();
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i1 = 1;
    int i2 = paramMenuItem.getItemId();
    switch (i2)
    {
    default:
    case 2131362256:
    case 2131362257:
    }
    for (i2 = i1; ; i2 = i1)
    {
      while (true)
      {
        return i2;
        j();
        i2 = i1;
      }
      c();
    }
  }

  protected void onResume()
  {
    super.onResume();
    com.jiayuan.util.a.a("ProfileActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.ProfileActivity
 * JD-Core Version:    0.5.4
 */