package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class w
  implements DialogInterface.OnClickListener
{
  w(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.w
 * JD-Core Version:    0.5.4
 */