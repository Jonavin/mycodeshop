package com.jiayuan.profile;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.jiayuan.setting.ContactPicker;
import com.jiayuan.util.a;

class n
  implements View.OnClickListener
{
  n(ProfilePhotoGalleryActivity paramProfilePhotoGalleryActivity)
  {
  }

  public void onClick(View paramView)
  {
    int i = 2131165446;
    Object localObject = this.a.getString(2131165445);
    StringBuilder localStringBuilder1 = new StringBuilder((String)localObject);
    localObject = this.a.e.equals("f");
    if (localObject != 0)
    {
      localObject = "�";
      label43: localStringBuilder1.append((String)localObject);
      localObject = this.a.getString(i);
      localStringBuilder1.append((String)localObject);
      int j = Integer.parseInt(this.a.f) + 1000000;
      localStringBuilder1.append(j);
      String str2 = this.a.getString(i);
      a.a("ProfilePhotoGalleryActivity", str2);
      StringBuilder localStringBuilder2 = new StringBuilder("uid:");
      String str3 = this.a.f;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(i).append("nickName:");
      String str4 = this.a.g;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(i).append("sex:");
      String str5 = this.a.e;
      String str6 = i;
      a.a("ProfilePhotoGalleryActivity", str6);
      String str7 = localStringBuilder1.toString();
      a.a("ProfilePhotoGalleryActivity", str7);
      int k = paramView.getId();
      switch (k)
      {
      default:
      case 2131362119:
      case 2131362120:
      }
    }
    while (true)
    {
      return;
      String str1 = "�";
      break label43:
      str1 = this.a.getString(2131165444);
      try
      {
        ProfilePhotoGalleryActivity localProfilePhotoGalleryActivity1 = this.a;
        String str8 = this.a.f;
        new z(localProfilePhotoGalleryActivity1, "1", str8).a();
        Intent localIntent1 = new Intent("android.intent.action.SEND");
        localIntent1.setType("plain/text");
        String[] arrayOfString = new String[null];
        localIntent1.putExtra("android.intent.extra.EMAIL", arrayOfString);
        localIntent1.putExtra("android.intent.extra.SUBJECT", str1);
        String str9 = localStringBuilder1.toString();
        localIntent1.putExtra("android.intent.extra.TEXT", localStringBuilder1);
        ProfilePhotoGalleryActivity localProfilePhotoGalleryActivity2 = this.a;
        String str10 = this.a.getString(2131165605);
        Intent localIntent2 = Intent.createChooser(localIntent1, str1);
        localStringBuilder1.startActivity(str1);
      }
      catch (Exception localException)
      {
        Toast.makeText(ProfilePhotoGalleryActivity.a(this.a), 2131165612, 1).show();
        localException.printStackTrace();
      }
      continue;
      Context localContext = ProfilePhotoGalleryActivity.a(this.a);
      Intent localIntent3 = new Intent(localContext, ContactPicker.class);
      String str11 = localStringBuilder1.toString();
      localIntent3.putExtra("content", localStringBuilder1);
      String str12 = this.a.f;
      localIntent3.putExtra("mUid", str12);
      this.a.startActivity(localIntent3);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.n
 * JD-Core Version:    0.5.4
 */