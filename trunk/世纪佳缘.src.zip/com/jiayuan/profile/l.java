package com.jiayuan.profile;

import android.graphics.Bitmap;

public abstract interface l
{
  public abstract void a(int paramInt, String paramString, Bitmap paramBitmap);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.l
 * JD-Core Version:    0.5.4
 */