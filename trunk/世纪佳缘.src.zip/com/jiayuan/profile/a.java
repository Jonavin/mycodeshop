package com.jiayuan.profile;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import java.util.ArrayList;

public class a extends BaseAdapter
{
  private Context b;

  public a(ProfileActivity paramProfileActivity, Context paramContext)
  {
    this.b = paramContext;
  }

  public int getCount()
  {
    return ProfileActivity.c(this.a).size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    int i = 1;
    if (paramView == null);
    for (View localView = this.a.getLayoutInflater().inflate(2130903088, null); ; localView = paramView)
    {
      ImageView localImageView = (ImageView)localView.findViewById(2131362016);
      Gallery.LayoutParams localLayoutParams = new Gallery.LayoutParams(105, 140);
      localView.setLayoutParams(localLayoutParams);
      ImageView.ScaleType localScaleType = ImageView.ScaleType.CENTER_INSIDE;
      localView.setScaleType(localScaleType);
      Bitmap localBitmap = (Bitmap)ProfileActivity.c(this.a).get(paramInt);
      localView.setImageBitmap(this);
      localView.setBackgroundResource(2130837625);
      localView.setPadding(i, i, i, i);
      return localView;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.a
 * JD-Core Version:    0.5.4
 */