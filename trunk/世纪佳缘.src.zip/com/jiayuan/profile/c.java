package com.jiayuan.profile;

import android.view.View;
import android.view.View.OnClickListener;

class c
  implements View.OnClickListener
{
  c(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    ProfileActivity.d(this.a);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.c
 * JD-Core Version:    0.5.4
 */