package com.jiayuan.profile;

import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.widget.Gallery;
import java.util.ArrayList;

class o
  implements GestureDetector.OnGestureListener
{
  o(ProfilePhotoGalleryActivity paramProfilePhotoGalleryActivity)
  {
  }

  public boolean onDown(MotionEvent paramMotionEvent)
  {
    return null;
  }

  public boolean onFling(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    Object localObject = null;
    int i = 1;
    float f1 = paramMotionEvent1.getX();
    float f2 = paramMotionEvent2.getX();
    f1 = Math.abs(f1 - f2);
    float f3 = paramMotionEvent1.getX();
    float f4 = paramMotionEvent2.getX();
    if (f3 - f4 > localObject)
    {
      float f5 = com.jiayuan.util.o.d(ProfilePhotoGalleryActivity.a(this.a)) / 4;
      if (f1 > f5)
      {
        int j = ProfilePhotoGalleryActivity.b(this.a);
        int k = ProfilePhotoGalleryActivity.c(this.a).size() - i;
        if (j < k)
        {
          Gallery localGallery1 = ProfilePhotoGalleryActivity.d(this.a);
          ProfilePhotoGalleryActivity localProfilePhotoGalleryActivity1 = this.a;
          int l = ProfilePhotoGalleryActivity.b(localProfilePhotoGalleryActivity1);
          int i1;
          ++i1;
          ProfilePhotoGalleryActivity.a(localProfilePhotoGalleryActivity1, l);
          localGallery1.setSelection(l);
        }
      }
    }
    while (true)
    {
      return i;
      float f6 = paramMotionEvent1.getX();
      float f7 = paramMotionEvent2.getX();
      if (f6 - f7 >= localObject)
        continue;
      float f8 = com.jiayuan.util.o.d(ProfilePhotoGalleryActivity.a(this.a)) / 4;
      if ((f1 <= f8) || (ProfilePhotoGalleryActivity.b(this.a) <= 0))
        continue;
      Gallery localGallery2 = ProfilePhotoGalleryActivity.d(this.a);
      ProfilePhotoGalleryActivity localProfilePhotoGalleryActivity2 = this.a;
      int i2 = ProfilePhotoGalleryActivity.b(localProfilePhotoGalleryActivity2) - i;
      ProfilePhotoGalleryActivity.a(localProfilePhotoGalleryActivity2, i2);
      localGallery2.setSelection(i2);
    }
  }

  public void onLongPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onScroll(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    return null;
  }

  public void onShowPress(MotionEvent paramMotionEvent)
  {
  }

  public boolean onSingleTapUp(MotionEvent paramMotionEvent)
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.o
 * JD-Core Version:    0.5.4
 */