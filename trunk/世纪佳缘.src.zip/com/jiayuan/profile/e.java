package com.jiayuan.profile;

import android.view.View;
import android.view.View.OnClickListener;

class e
  implements View.OnClickListener
{
  e(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    this.a.a();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.e
 * JD-Core Version:    0.5.4
 */