package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.register.RegisterType;

class p
  implements DialogInterface.OnClickListener
{
  p(ProfilePhotoGalleryActivity paramProfilePhotoGalleryActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    com.jiayuan.util.o.i = this.a.f;
    ProfilePhotoGalleryActivity localProfilePhotoGalleryActivity = this.a;
    Intent localIntent = new Intent(localProfilePhotoGalleryActivity, RegisterType.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.p
 * JD-Core Version:    0.5.4
 */