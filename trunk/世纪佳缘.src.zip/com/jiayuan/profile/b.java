package com.jiayuan.profile;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.jiayuan.setting.ContactPicker;
import com.jiayuan.util.a;

class b
  implements View.OnClickListener
{
  b(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(View paramView)
  {
    int i = 2131165446;
    Object localObject = this.a.getString(2131165445);
    StringBuilder localStringBuilder1 = new StringBuilder((String)localObject);
    localObject = ProfileActivity.a(this.a).g.equals("f");
    if (localObject != 0)
    {
      localObject = "�";
      label46: localStringBuilder1.append((String)localObject);
      localObject = this.a.getString(i);
      localStringBuilder1.append((String)localObject);
      int j = Integer.parseInt(ProfileActivity.a(this.a).a) + 1000000;
      localStringBuilder1.append(j);
      String str2 = this.a.getString(i);
      a.a("ProfileActivity", str2);
      StringBuilder localStringBuilder2 = new StringBuilder("uid:");
      String str3 = ProfileActivity.a(this.a).a;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(i).append("nickName:");
      String str4 = ProfileActivity.a(this.a).b;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(i).append("sex:");
      String str5 = ProfileActivity.a(this.a).g;
      String str6 = i;
      a.a("ProfileActivity", str6);
      String str7 = localStringBuilder1.toString();
      a.a("ProfileActivity", str7);
      int k = paramView.getId();
      switch (k)
      {
      default:
      case 2131362119:
      case 2131362120:
      }
    }
    while (true)
    {
      return;
      String str1 = "�";
      break label46:
      str1 = this.a.getString(2131165444);
      try
      {
        ProfileActivity localProfileActivity1 = this.a;
        String str8 = ProfileActivity.a(this.a).a;
        new z(localProfileActivity1, "1", str8).a();
        Intent localIntent1 = new Intent("android.intent.action.SEND");
        localIntent1.setType("plain/text");
        String[] arrayOfString = new String[null];
        localIntent1.putExtra("android.intent.extra.EMAIL", arrayOfString);
        localIntent1.putExtra("android.intent.extra.SUBJECT", str1);
        String str9 = localStringBuilder1.toString();
        localIntent1.putExtra("android.intent.extra.TEXT", localStringBuilder1);
        ProfileActivity localProfileActivity2 = this.a;
        String str10 = this.a.getString(2131165605);
        Intent localIntent2 = Intent.createChooser(localIntent1, str1);
        localStringBuilder1.startActivity(str1);
      }
      catch (Exception localException)
      {
        Toast.makeText(ProfileActivity.b(this.a), 2131165612, 1).show();
        localException.printStackTrace();
      }
      continue;
      Context localContext = ProfileActivity.b(this.a);
      Intent localIntent3 = new Intent(localContext, ContactPicker.class);
      String str11 = localStringBuilder1.toString();
      localIntent3.putExtra("content", localStringBuilder1);
      String str12 = ProfileActivity.a(this.a).a;
      localIntent3.putExtra("mUid", str12);
      this.a.startActivity(localIntent3);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.b
 * JD-Core Version:    0.5.4
 */