package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import com.jiayuan.register.RegisterType;

class u
  implements DialogInterface.OnClickListener
{
  u(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    com.jiayuan.util.o.i = ProfileActivity.a(this.a).a;
    ProfileActivity localProfileActivity = this.a;
    Intent localIntent = new Intent(localProfileActivity, RegisterType.class);
    this.a.startActivity(localIntent);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.u
 * JD-Core Version:    0.5.4
 */