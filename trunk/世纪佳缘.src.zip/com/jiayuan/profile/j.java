package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.util.a;

class j
  implements DialogInterface.OnClickListener
{
  j(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.a("ProfileActivity", "last_login_time_cancel");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.j
 * JD-Core Version:    0.5.4
 */