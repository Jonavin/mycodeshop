package com.jiayuan.profile;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.BadTokenException;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.FrameLayout.LayoutParams;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.ViewSwitcher.ViewFactory;
import com.jiayuan.MyActivity;
import com.jiayuan.util.a;
import java.util.ArrayList;

public class ProfilePhotoGalleryActivity extends MyActivity
  implements AdapterView.OnItemSelectedListener, ViewSwitcher.ViewFactory, l
{
  int a;
  int b;
  ProgressDialog c;
  int d = null;
  String e = null;
  String f = null;
  String g = null;
  private ArrayList h;
  private ArrayList i;
  private Gallery j;
  private ImageSwitcher k;
  private ab l;
  private int m = null;
  private GestureDetector n;
  private Context o = this;
  private GestureDetector.OnGestureListener p;
  private View.OnClickListener q;

  public ProfilePhotoGalleryActivity()
  {
    o localo = new o(this);
    this.p = localo;
    n localn = new n(this);
    this.q = localn;
  }

  public void a()
  {
    showDialog(2);
  }

  public void a(int paramInt, String paramString, Bitmap paramBitmap)
  {
    Object localObject1 = "onGetPhoto index=" + paramInt + "sPhotoUrl=" + paramString;
    a.a("ProfilePhotoGalleryActivity", (String)localObject1);
    Object localObject2 = this.d;
    this.d = (++localObject2);
    localObject2 = this.d;
    localObject1 = this.i.size();
    if (localObject2 == localObject1)
    {
      localObject2 = this.c;
      ((ProgressDialog)localObject2).dismiss();
    }
    int i1;
    if (paramBitmap == null)
    {
      localObject2 = this.e;
      localObject1 = "f";
      localObject2 = ((String)localObject2).equals(localObject1);
      if (localObject2 != 0)
      {
        localObject2 = getResources();
        i1 = 2130837628;
      }
    }
    for (localObject2 = BitmapFactory.decodeResource((Resources)localObject2, i1); ; localObject2 = paramBitmap)
      while (true)
      {
        BitmapDrawable localBitmapDrawable = new BitmapDrawable((Bitmap)localObject2);
        this.i.set(paramInt, localBitmapDrawable);
        this.l.notifyDataSetChanged();
        int i3 = this.m;
        if (paramInt == localObject2)
          this.k.setImageDrawable(localBitmapDrawable);
        return;
        localObject2 = getResources();
        int i2 = 2130837630;
        localObject2 = BitmapFactory.decodeResource((Resources)localObject2, i2);
      }
  }

  public View makeView()
  {
    ImageView localImageView = new ImageView(this);
    localImageView.setBackgroundColor(-16777216);
    ImageView.ScaleType localScaleType = ImageView.ScaleType.FIT_CENTER;
    localImageView.setScaleType(localScaleType);
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    localImageView.setLayoutParams(localLayoutParams);
    return localImageView;
  }

  public void onCreate(Bundle paramBundle)
  {
    int i1 = 1;
    super.onCreate(paramBundle);
    getWindow().setFlags(1024, 1024);
    requestWindowFeature(i1);
    setContentView(2130903091);
    a.a("ProfilePhotoGalleryActivity", "onCreate");
    GestureDetector.OnGestureListener localOnGestureListener = this.p;
    Object localObject = new GestureDetector(this, localOnGestureListener);
    this.n = ((GestureDetector)localObject);
    localObject = com.jiayuan.util.o.d(this);
    this.a = localObject;
    localObject = com.jiayuan.util.o.e(this);
    this.b = localObject;
    localObject = getIntent();
    Bundle localBundle = ((Intent)localObject).getExtras();
    int i2 = localBundle.getInt("selected_index");
    this.m = i2;
    localObject = ((Intent)localObject).getStringArrayListExtra("photo_urls");
    this.h = ((ArrayList)localObject);
    localObject = localBundle.getString("sex");
    this.e = ((String)localObject);
    localObject = localBundle.getString("uid");
    this.f = ((String)localObject);
    localObject = localBundle.getString("nick_name");
    this.g = ((String)localObject);
    localObject = new ArrayList();
    this.i = ((ArrayList)localObject);
    localObject = null;
    while (true)
    {
      int i3 = this.h.size();
      if (localObject >= i3)
      {
        ArrayList localArrayList = this.h;
        int i4 = this.a;
        int i5 = this.b;
        new k(this, localArrayList, i4, i5).a();
        ab localab1 = new ab(this, this);
        this.l = localab1;
        Gallery localGallery1 = (Gallery)findViewById(2131362116);
        this.j = localGallery1;
        Gallery localGallery2 = this.j;
        ab localab2 = this.l;
        localGallery2.setAdapter(localab2);
        Gallery localGallery3 = this.j;
        int i6 = this.m;
        localGallery3.setSelection(i6);
        this.j.setOnItemSelectedListener(this);
        ImageSwitcher localImageSwitcher1 = (ImageSwitcher)findViewById(2131362117);
        this.k = localImageSwitcher1;
        this.k.setFactory(this);
        ImageSwitcher localImageSwitcher2 = this.k;
        Animation localAnimation1 = AnimationUtils.loadAnimation(this, 17432576);
        localImageSwitcher2.setInAnimation(localAnimation1);
        ImageSwitcher localImageSwitcher3 = this.k;
        Animation localAnimation2 = AnimationUtils.loadAnimation(this, 17432577);
        localImageSwitcher3.setOutAnimation(localAnimation2);
        this.k.setLongClickable(i1);
        ImageSwitcher localImageSwitcher4 = this.k;
        m localm = new m(this);
        localImageSwitcher4.setOnTouchListener(localm);
      }
      try
      {
        String str = getResources().getString(2131165195);
        ProgressDialog localProgressDialog = ProgressDialog.show(this, "", str);
        this.c = localProgressDialog;
        this.c.setCancelable(true);
        label465: Button localButton = (Button)findViewById(2131362118);
        r localr = new r(this);
        localButton.setOnClickListener(localr);
        return;
        this.i.add(null);
        ++localObject;
      }
      catch (Exception localException)
      {
        break label465:
      }
      catch (WindowManager.BadTokenException localBadTokenException)
      {
        break label465:
      }
    }
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1 = 0;
    switch (paramInt)
    {
    case 1:
    default:
    case 0:
    case 2:
    }
    for (Object localObject = i1; ; localObject = new AlertDialog.Builder(this).setTitle(2131165443).setView(i1).create())
    {
      while (true)
      {
        return localObject;
        localObject = new AlertDialog.Builder(this).setTitle(2131165670).setMessage(2131165669);
        s locals = new s(this);
        localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165640, locals);
        p localp = new p(this);
        localObject = ((AlertDialog.Builder)localObject).setNeutralButton(2131165641, localp);
        q localq = new q(this);
        localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, localq).create();
      }
      View localView = getLayoutInflater().inflate(2130903092, i1);
      localObject = (Button)i1.findViewById(2131362119);
      Button localButton = (Button)i1.findViewById(2131362120);
      View.OnClickListener localOnClickListener = this.q;
      ((Button)localObject).setOnClickListener(localOnClickListener);
      localObject = this.q;
      localButton.setOnClickListener((View.OnClickListener)localObject);
    }
  }

  public void onDestroy()
  {
    super.onDestroy();
    System.gc();
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    ImageSwitcher localImageSwitcher = this.k;
    Drawable localDrawable = (Drawable)this.i.get(paramInt);
    localImageSwitcher.setImageDrawable(this);
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }

  protected void onResume()
  {
    super.onResume();
    a.a("ProfilePhotoGalleryActivity", "onResume");
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.ProfilePhotoGalleryActivity
 * JD-Core Version:    0.5.4
 */