package com.jiayuan.profile;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.jiayuan.MainActivity;
import com.jiayuan.service.ServiceActivity;

class i
  implements DialogInterface.OnClickListener
{
  i(ProfileActivity paramProfileActivity)
  {
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    com.jiayuan.util.a.a("ProfileActivity", "last_login_time_buy");
    this.a.finish();
    com.jiayuan.a locala = com.jiayuan.a.a();
    locala.b(MainActivity.class);
    MainActivity localMainActivity = (MainActivity)locala.d(MainActivity.class);
    super.a(3);
    ServiceActivity localServiceActivity = (ServiceActivity)super.getCurrentActivity();
    int i = ServiceActivity.b;
    super.a(i);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.profile.i
 * JD-Core Version:    0.5.4
 */