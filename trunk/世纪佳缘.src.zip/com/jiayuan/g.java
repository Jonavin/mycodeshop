package com.jiayuan;

import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(LicenseActivity paramLicenseActivity)
  {
  }

  public void onClick(View paramView)
  {
    this.a.finish();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.g
 * JD-Core Version:    0.5.4
 */