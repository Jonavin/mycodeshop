package com.jiayuan;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import com.a.a.ai;
import com.a.a.cd;
import com.jiayuan.system.service.JiayuanService;
import com.jiayuan.util.a;
import com.jiayuan.util.b;
import com.jiayuan.util.o;
import com.jiayuan.util.p;

public class SplashActivity extends Activity
{
  String a;
  String b;
  String c;
  Context d;
  final String e = "SplashActivity";
  com.a.a.h f;

  public SplashActivity()
  {
    i locali = new i(this);
    this.f = locali;
  }

  private String a()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String str = o.a(this.d);
    localStringBuffer.append(str);
    long l = System.currentTimeMillis();
    Object localObject;
    localStringBuffer.append(localObject);
    return p.a(localStringBuffer.toString());
  }

  public void onCreate(Bundle paramBundle)
  {
    String[] arrayOfString1 = null;
    int i = 2131165190;
    int j = 1;
    super.onCreate(paramBundle);
    requestWindowFeature(j);
    getWindow().setFlags(1024, 1024);
    setContentView(2130903111);
    a.a("JiayuanService", "onCreate");
    boolean bool = b.d(this);
    if (!bool)
    {
      Object localObject = getContentResolver();
      Uri localUri = Uri.parse("content://com.android.launcher.settings/favorites?notify=true");
      String[] arrayOfString2 = new String[j];
      String str1 = getString(i);
      j[0] = str1;
      String[] arrayOfString3 = arrayOfString1;
      localObject = ((ContentResolver)localObject).query(localUri, arrayOfString1, "title=?", j, arrayOfString3);
      if (localObject != null)
        ((Cursor)localObject).moveToFirst();
      if ((localObject == null) || (((Cursor)localObject).getCount() == 0))
      {
        Intent localIntent1 = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        Intent localIntent2 = getIntent();
        localIntent1.putExtra("android.intent.extra.shortcut.INTENT", localIntent2);
        String str2 = getString(i);
        localIntent1.putExtra("android.intent.extra.shortcut.NAME", str2);
        Intent.ShortcutIconResource localShortcutIconResource = Intent.ShortcutIconResource.fromContext(this, 2130837642);
        localIntent1.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", localShortcutIconResource);
        sendBroadcast(localIntent1);
      }
      b.c(this);
    }
    this.d = this;
    String str3 = b.l(this);
    this.a = str3;
    String str4 = getString(2131165199);
    this.b = str4;
    String str5 = getString(2131165200);
    this.c = str5;
    if ((this.a != null) && (!this.a.equals("")))
    {
      StringBuilder localStringBuilder1 = new StringBuilder("splash username=");
      String str6 = this.a;
      String str7 = str6;
      a.a("SplashActivity", str7);
      Context localContext = this.d;
      Intent localIntent3 = new Intent(localContext, JiayuanService.class);
      this.d.startService(localIntent3);
      Handler localHandler = new Handler();
      h localh = new h(this);
      localHandler.postDelayed(localh, 3000L);
    }
    while (true)
    {
      return;
      a.a("SplashActivity", "splash register username");
      cd localcd = new cd(this);
      String str8 = this.b;
      String str9 = this.c;
      ai localai1 = new ai(str8, str9);
      String str10 = a();
      this.a = str10;
      StringBuilder localStringBuilder2 = new StringBuilder("splash gen username=");
      String str11 = this.a;
      String str12 = str11;
      a.a("SplashActivity", str12);
      String str13 = this.a;
      String str14 = this.c;
      ai localai2 = new ai(str13, str14);
      com.a.a.h localh1 = this.f;
      localcd.a(localai1, localai2, localh1);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.SplashActivity
 * JD-Core Version:    0.5.4
 */