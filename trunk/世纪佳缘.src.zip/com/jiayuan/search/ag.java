package com.jiayuan.search;

public abstract interface ag
{
  public abstract void a(String paramString);

  public abstract void b();

  public abstract void c();

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.ag
 * JD-Core Version:    0.5.4
 */