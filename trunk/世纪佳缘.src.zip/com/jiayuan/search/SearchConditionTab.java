package com.jiayuan.search;

import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;

public class SearchConditionTab extends ActivityGroup
{
  Button a;
  Button b;
  Button c;
  Context d;
  int e = 2131362153;
  private LocalActivityManager f;
  private FrameLayout g;
  private View.OnClickListener h;

  public SearchConditionTab()
  {
    ak localak = new ak(this);
    this.h = localak;
  }

  private void a()
  {
    Context localContext = this.d;
    Intent localIntent = new Intent(localContext, SearchConditionActivity.class);
    View localView = this.f.startActivity("tab_search_condition_common", localIntent).getDecorView();
    this.g.addView(localView);
  }

  private void a(View paramView)
  {
    this.a.setEnabled(true);
    this.b.setEnabled(true);
    this.c.setEnabled(true);
    paramView.setEnabled(null);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903100);
    this.d = this;
    LocalActivityManager localLocalActivityManager = getLocalActivityManager();
    this.f = localLocalActivityManager;
    FrameLayout localFrameLayout = (FrameLayout)findViewById(2131362156);
    this.g = localFrameLayout;
    Button localButton1 = (Button)findViewById(2131362153);
    this.a = localButton1;
    Button localButton2 = (Button)findViewById(2131362154);
    this.b = localButton2;
    Button localButton3 = (Button)findViewById(2131362155);
    this.c = localButton3;
    Button localButton4 = this.a;
    View.OnClickListener localOnClickListener1 = this.h;
    localButton4.setOnClickListener(localOnClickListener1);
    Button localButton5 = this.b;
    View.OnClickListener localOnClickListener2 = this.h;
    localButton5.setOnClickListener(localOnClickListener2);
    Button localButton6 = this.c;
    View.OnClickListener localOnClickListener3 = this.h;
    localButton6.setOnClickListener(localOnClickListener3);
    a();
    Button localButton7 = this.a;
    a(localButton7);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.SearchConditionTab
 * JD-Core Version:    0.5.4
 */