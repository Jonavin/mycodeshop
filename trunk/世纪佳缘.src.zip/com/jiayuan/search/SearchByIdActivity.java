package com.jiayuan.search;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import com.jiayuan.a.d;
import com.jiayuan.a.h;
import com.jiayuan.profile.ProfileActivity;

public class SearchByIdActivity extends Activity
  implements m
{
  ProgressDialog a;

  public void a(String paramString1, String paramString2)
  {
    if (this.a != null)
      this.a.dismiss();
    Intent localIntent = new Intent(this, ProfileActivity.class);
    localIntent.putExtra("uid", paramString1);
    localIntent.putExtra("sex", paramString2);
    localIntent.putExtra("src", 2);
    int i = h.f;
    localIntent.putExtra("matchSrc", i);
    int j = d.b;
    localIntent.putExtra("profileSrc", j);
    localIntent.putExtra("isMatchBtnEnable", true);
    startActivity(localIntent);
    finish();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903098);
    EditText localEditText = (EditText)findViewById(2131362146);
    Button localButton = (Button)findViewById(2131362147);
    j localj = new j(this, localEditText);
    localButton.setOnClickListener(localj);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.SearchByIdActivity
 * JD-Core Version:    0.5.4
 */