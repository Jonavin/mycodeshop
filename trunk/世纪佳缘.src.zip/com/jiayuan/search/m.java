package com.jiayuan.search;

public abstract interface m
{
  public abstract void a(String paramString1, String paramString2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.m
 * JD-Core Version:    0.5.4
 */