package com.jiayuan.search;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.jiayuan.util.b;
import com.jiayuan.util.f;
import com.jiayuan.util.picker.AgeRangePicker;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.picker.m;
import com.jiayuan.util.t;
import java.util.ArrayList;
import java.util.List;

public class SearchByNicknameActivity extends Activity
  implements AdapterView.OnItemClickListener, com.jiayuan.util.picker.a
{
  Context a;
  EditText b;
  Button c;
  ListView d;
  ArrayList e;
  protected aj f;
  protected as g;
  private Spinner h;
  private View.OnClickListener i;

  public SearchByNicknameActivity()
  {
    az localaz = new az(this);
    this.i = localaz;
  }

  private int[] a(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int j = 0; ; ++j)
    {
      if (j >= paramInt)
        return arrayOfInt;
      int k = t.a(j);
      arrayOfInt[j] = k;
    }
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int j = paramArrayOfInt.length;
    if (j <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      j = 0;
      return j;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    for (int k = 0; ; ++k)
    {
      int l = paramArrayOfInt.length;
      if (k < l);
      int i1 = paramArrayOfInt[k];
      String[] arrayOfString2 = localResources.getStringArray(i1);
      arrayOfString1[k] = arrayOfString2;
    }
  }

  private void b()
  {
    int j = 2;
    if (this.g == null)
    {
      as localas1 = new as();
      this.g = localas1;
    }
    as localas2 = this.g;
    String str1 = ((as)this.e.get(j)).a;
    localas2.a = str1;
    as localas3 = this.g;
    String str2 = ((as)this.e.get(j)).b;
    localas3.b = str2;
    as localas4 = this.g;
    String str3 = ((as)this.e.get(j)).c;
    localas4.c = str3;
    as localas5 = this.g;
    int k = ((as)this.e.get(j)).d;
    localas5.d = k;
    as localas6 = this.g;
    int l = ((as)this.e.get(j)).e;
    localas6.e = l;
  }

  private View c()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099840);
    int j = arrayOfString.length;
    int[] arrayOfInt = a(j);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    b();
    ao localao = new ao(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(localao);
    int k = this.g.d;
    int l = this.g.e;
    localDoubleLevelSpinner.a(k, true, l, true);
    return localView;
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int j = ((as)this.e.get(paramInt3)).d;
    localSpinner.setSelection(j, true);
    ay localay = new ay(this, paramInt3);
    localSpinner.setOnItemSelectedListener(localay);
    return localSpinner;
  }

  public void a()
  {
    Spinner localSpinner = a(2131362151, "璇烽�", 2131099735, 0);
    this.h = localSpinner;
  }

  public void a(AgeRangePicker paramAgeRangePicker, int paramInt1, int paramInt2)
  {
    int j = 1;
    if (paramInt1 < paramInt2)
    {
      as localas1 = (as)this.e.get(j);
      String str1 = f.r(this, paramInt1);
      localas1.b = str1;
      as localas2 = (as)this.e.get(j);
      String str2 = f.s(this, paramInt2);
      localas2.c = str2;
    }
    while (true)
    {
      this.f.notifyDataSetChanged();
      return;
      if ((paramInt1 == 0) && (paramInt2 == 0))
      {
        as localas3 = (as)this.e.get(j);
        String str3 = f.r(this, paramInt1);
        localas3.b = str3;
        as localas4 = (as)this.e.get(j);
        String str4 = f.s(this, paramInt2);
        localas4.c = str4;
      }
      Toast.makeText(this, 2131165336, 0).show();
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    boolean bool = null;
    super.onCreate(paramBundle);
    setContentView(2130903099);
    this.a = this;
    Object localObject1 = new ArrayList();
    this.e = ((ArrayList)localObject1);
    localObject1 = (EditText)findViewById(2131362148);
    this.b = ((EditText)localObject1);
    localObject1 = (Button)findViewById(2131362150);
    this.c = ((Button)localObject1);
    localObject1 = this.c;
    Object localObject2 = this.i;
    ((Button)localObject1).setOnClickListener((View.OnClickListener)localObject2);
    localObject1 = (ListView)findViewById(2131362149);
    this.d = ((ListView)localObject1);
    localObject1 = new as();
    ((as)localObject1).a = "鎬";
    localObject2 = b.b(this, 2131165217);
    localObject2 = f.a(this, (String)localObject2);
    ((as)localObject1).b = ((String)localObject2);
    ((as)localObject1).c = "";
    localObject2 = ((as)localObject1).b;
    localObject2 = f.q(this, (String)localObject2);
    ((as)localObject1).d = localObject2;
    ((as)localObject1).e = bool;
    localObject2 = new as();
    ((as)localObject2).a = "骞";
    String str1 = b.b(this, 2131165218);
    ((as)localObject2).b = str1;
    if (((as)localObject2).b.equals("0"))
      ((as)localObject2).b = "涓";
    String str2 = b.b(this, 2131165219);
    ((as)localObject2).c = str2;
    if (((as)localObject2).c.equals("0"))
      ((as)localObject2).c = "涓";
    String str3 = ((as)localObject2).b;
    int j = f.F(this, str3);
    ((as)localObject2).d = j;
    String str4 = ((as)localObject2).c;
    int k = f.G(this, str4);
    ((as)localObject2).e = k;
    String str5 = b.b(this, 2131165220);
    int l = t.c(this, str5);
    String str6 = b.b(this, 2131165221);
    int i1 = t.c(this, l, str6);
    as localas = new as();
    localas.a = "鍦";
    String str7 = t.b(this, l);
    localas.b = str7;
    String str8 = t.b(this, l, i1, bool);
    localas.c = str8;
    localas.d = l;
    localas.e = i1;
    this.e.add(localObject1);
    this.e.add(localObject2);
    this.e.add(localas);
    a();
    ArrayList localArrayList = this.e;
    aj localaj1 = new aj(this, this, (List)localObject2);
    this.f = ((aj)localObject1);
    ListView localListView = this.d;
    aj localaj2 = this.f;
    ((ListView)localObject1).setAdapter((ListAdapter)localObject2);
    this.d.setOnItemClickListener(this);
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int j;
    switch (paramInt)
    {
    default:
      j = 0;
    case 0:
    }
    while (true)
    {
      return j;
      Object localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView = c();
      localObject = ((AlertDialog.Builder)localObject).setView(localView);
      an localan = new an(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(2131165642, localan);
      am localam = new am(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(2131165643, localam).create();
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int j = 1;
    if (paramInt == 0)
    {
      this.h.performClick();
      CharSequence localCharSequence = this.h.getPrompt();
      Toast.makeText(this, localCharSequence, j).show();
    }
    while (true)
    {
      return;
      if (j == paramInt)
      {
        int k = ((as)this.e.get(j)).d;
        int l = ((as)this.e.get(j)).e;
        new m(this, this, k, l).show();
      }
      if (2 != paramInt)
        continue;
      showDialog(0);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.SearchByNicknameActivity
 * JD-Core Version:    0.5.4
 */