package com.jiayuan.search;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.jiayuan.MyActivity;
import com.jiayuan.util.o;
import com.jiayuan.util.picker.AgeRangePicker;
import com.jiayuan.util.picker.DoubleLevelSpinner;
import com.jiayuan.util.picker.HeightRangePicker;
import com.jiayuan.util.picker.ab;
import com.jiayuan.util.picker.m;
import com.jiayuan.util.picker.z;
import com.jiayuan.util.t;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;

public class SearchConditionActivity extends MyActivity
  implements AdapterView.OnItemClickListener, com.jiayuan.a.c, com.jiayuan.util.picker.a, ab
{
  private Spinner A;
  private Spinner B;
  private Spinner C;
  private Spinner D;
  private Spinner E;
  private Spinner F;
  private Spinner G;
  private Spinner H;
  private Spinner I;
  private Spinner J;
  private Spinner K;
  private Spinner L;
  private Spinner M;
  private Spinner N;
  private boolean O;
  as a;
  as b;
  private final int c = null;
  private final int d = 1;
  private final int e = 2;
  private final int f = 3;
  private final int g = 4;
  private final int h = 5;
  private final int i = 6;
  private final int j = 7;
  private final int k = 8;
  private final int l = 9;
  private final int m = 10;
  private final int n = 11;
  private final int o = 12;
  private final int p = 13;
  private final int q = 14;
  private final int r = 15;
  private final int s = 16;
  private final int t = 17;
  private final int u = 18;
  private ArrayList v;
  private ListView w;
  private ar x;
  private Context y;
  private Spinner z;

  public SearchConditionActivity()
  {
    as localas1 = new as();
    this.a = localas1;
    as localas2 = new as();
    this.b = localas2;
    this.O = null;
  }

  private int[] a(int paramInt)
  {
    int[] arrayOfInt = new int[paramInt];
    for (int i1 = 0; ; ++i1)
    {
      if (i1 >= paramInt)
        return arrayOfInt;
      int i2 = t.a(i1);
      arrayOfInt[i1] = i2;
    }
  }

  private String[][] a(int[] paramArrayOfInt)
  {
    int i1 = paramArrayOfInt.length;
    if (i1 <= 0)
    {
      com.jiayuan.util.a.a("DoubleLevelSpinner", "Please set secondary arrays resources ids.");
      i1 = 0;
      return i1;
    }
    String[] arrayOfString1 = new String[paramArrayOfInt.length];
    Resources localResources = getResources();
    for (int i2 = 0; ; ++i2)
    {
      int i3 = paramArrayOfInt.length;
      if (i2 < i3);
      int i4 = paramArrayOfInt[i2];
      String[] arrayOfString2 = localResources.getStringArray(i4);
      arrayOfString1[i2] = arrayOfString2;
    }
  }

  private void c()
  {
    int i1 = this.v.size();
    if (i1 > 7)
      i1 -= 1;
    while (true)
    {
      if (i1 <= 6)
        return;
      this.v.remove(i1);
      --i1;
    }
  }

  private void e()
  {
    as localas1 = new as();
    localas1.a = "鏄";
    localas1.b = "涓";
    as localas2 = new as();
    localas2.a = "琛";
    localas2.b = "涓";
    as localas3 = new as();
    localas3.a = "浣";
    localas3.b = "涓";
    as localas4 = new as();
    localas4.a = "璐";
    localas4.b = "涓";
    as localas5 = new as();
    localas5.a = "鏈夋";
    localas5.b = "涓";
    as localas6 = new as();
    localas6.a = "璇氫";
    localas6.b = "涓";
    as localas7 = new as();
    localas7.a = "鑱";
    localas7.b = "涓";
    as localas8 = new as();
    localas8.a = "鍏";
    localas8.b = "涓";
    as localas9 = new as();
    localas9.a = "鎴峰";
    localas9.b = "涓";
    localas9.c = "涓";
    as localas10 = new as();
    localas10.a = "姘";
    localas10.b = "涓";
    as localas11 = new as();
    localas11.a = "瀹楁";
    localas11.b = "涓";
    as localas12 = new as();
    localas12.a = "鐓";
    localas12.b = "涓";
    this.v.add(localas1);
    this.v.add(localas2);
    this.v.add(localas3);
    this.v.add(localas4);
    this.v.add(localas5);
    this.v.add(localas6);
    this.v.add(localas7);
    this.v.add(localas8);
    this.v.add(localas9);
    this.v.add(localas10);
    this.v.add(localas11);
    this.v.add(localas12);
    b();
  }

  private void f()
  {
    int i1 = 0;
    int i2 = 15;
    int i3 = 3;
    int i4 = 1;
    int i5 = 2;
    com.jiayuan.util.a.a("SearchConditionActivity2", "Confirm button clicked");
    Object localObject1 = this.y;
    Object localObject3 = ((as)this.v.get(i1)).b;
    localObject3 = com.jiayuan.util.f.b((Context)localObject1, (String)localObject3);
    com.jiayuan.util.b.b(this, 2131165217, (String)localObject3);
    int i10 = 2131165218;
    localObject3 = ((as)this.v.get(i4)).b;
    localObject1 = "涓";
    localObject3 = ((String)localObject3).equals(localObject1);
    label102: Object localObject2;
    if (localObject3 != 0)
    {
      localObject3 = "0";
      com.jiayuan.util.b.b(this, i10, (String)localObject3);
      i10 = 2131165219;
      localObject3 = ((as)this.v.get(i4)).c;
      localObject1 = "涓";
      localObject3 = ((String)localObject3).equals(localObject1);
      if (localObject3 == 0)
        break label1352;
      localObject3 = "0";
      label153: com.jiayuan.util.b.b(this, i10, (String)localObject3);
      int i7 = ((as)this.v.get(i5)).d;
      String str1 = t.d(this, i7);
      com.jiayuan.util.b.b(this, 2131165220, str1);
      int i6 = ((as)this.v.get(i5)).d;
      int i8 = ((as)this.v.get(i5)).e;
      String str2 = t.b(this, i6, i8);
      com.jiayuan.util.b.b(this, 2131165221, str2);
      localObject2 = new StringBuilder(" init cell2.index=");
      int i9 = ((as)this.v.get(i5)).d;
      localObject2 = ((StringBuilder)localObject2).append(i9).append("cell2.index1=");
      i9 = ((as)this.v.get(i5)).e;
      localObject4 = i9;
      com.jiayuan.util.a.a("SearchConditionActivity2", (String)localObject4);
      i10 = 2131165222;
      localObject4 = ((as)this.v.get(i3)).b;
      localObject2 = "涓";
      localObject4 = ((String)localObject4).equals(localObject2);
      if (localObject4 == 0)
        break label1372;
      localObject4 = "0";
      label367: com.jiayuan.util.b.b(this, i10, (String)localObject4);
      i10 = 2131165223;
      localObject4 = ((as)this.v.get(i3)).c;
      localObject2 = "涓";
      localObject4 = ((String)localObject4).equals(localObject2);
      if (localObject4 == 0)
        break label1391;
    }
    for (Object localObject4 = "0"; ; localObject4 = ((as)this.v.get(i3)).c)
    {
      com.jiayuan.util.b.b(this, i10, (String)localObject4);
      localObject2 = this.y;
      String str3 = ((as)this.v.get(4)).b;
      String str4 = com.jiayuan.util.f.g((Context)localObject2, (String)localObject4);
      com.jiayuan.util.b.b(this, 2131165224, (String)localObject4);
      localObject2 = this.y;
      String str5 = ((as)this.v.get(5)).b;
      String str6 = com.jiayuan.util.f.c((Context)localObject2, (String)localObject4);
      com.jiayuan.util.b.b(this, 2131165225, (String)localObject4);
      localObject2 = this.y;
      String str7 = ((as)this.v.get(6)).b;
      String str8 = com.jiayuan.util.f.e((Context)localObject2, (String)localObject4);
      com.jiayuan.util.b.b(this, 2131165226, (String)localObject4);
      Intent localIntent = new Intent("com.jiayuan.search.CODITION_COMMON");
      localObject2 = new Bundle();
      boolean bool = this.O;
      ((Bundle)localObject2).putBoolean("isExpand", bool);
      Context localContext1 = this.y;
      String str9 = ((as)this.v.get(i1)).b;
      String str10 = com.jiayuan.util.f.b(localContext1, (String)localObject4);
      ((Bundle)localObject2).putString("sex", (String)localObject4);
      String str11 = ((as)this.v.get(i4)).b;
      ((Bundle)localObject2).putString("min_age", (String)localObject4);
      String str12 = ((as)this.v.get(i4)).c;
      ((Bundle)localObject2).putString("max_age", (String)localObject4);
      String str13 = ((as)this.v.get(i5)).b;
      ((Bundle)localObject2).putString("work_location", (String)localObject4);
      String str14 = ((as)this.v.get(i5)).c;
      ((Bundle)localObject2).putString("work_sublocation", (String)localObject4);
      String str15 = ((as)this.v.get(i3)).b;
      ((Bundle)localObject2).putString("min_height", (String)localObject4);
      String str16 = ((as)this.v.get(i3)).c;
      ((Bundle)localObject2).putString("max_height", (String)localObject4);
      Context localContext2 = this.y;
      String str17 = ((as)this.v.get(4)).b;
      String str18 = com.jiayuan.util.f.g(localContext2, (String)localObject4);
      ((Bundle)localObject2).putString("income", (String)localObject4);
      Context localContext3 = this.y;
      String str19 = ((as)this.v.get(5)).b;
      String str20 = com.jiayuan.util.f.c(localContext3, (String)localObject4);
      ((Bundle)localObject2).putString("marriage", (String)localObject4);
      Context localContext4 = this.y;
      String str21 = ((as)this.v.get(6)).b;
      String str22 = com.jiayuan.util.f.e(localContext4, (String)localObject4);
      ((Bundle)localObject2).putString("education", (String)localObject4);
      if (this.O)
      {
        int i11 = ((as)this.v.get(7)).d;
        ((Bundle)localObject2).putInt("astro", i11);
        int i12 = ((as)this.v.get(8)).d;
        ((Bundle)localObject2).putInt("bloodtype", i12);
        int i13 = ((as)this.v.get(9)).d;
        ((Bundle)localObject2).putInt("house", i13);
        int i14 = ((as)this.v.get(10)).d;
        ((Bundle)localObject2).putInt("auto", i14);
        int i15 = ((as)this.v.get(11)).d;
        ((Bundle)localObject2).putInt("children", i15);
        int i16 = ((as)this.v.get(12)).d;
        ((Bundle)localObject2).putInt("level", i16);
        int i17 = ((as)this.v.get(13)).d;
        ((Bundle)localObject2).putInt("industry", i17);
        int i18 = ((as)this.v.get(14)).d;
        ((Bundle)localObject2).putInt("company", i18);
        Context localContext5 = this.y;
        int i19 = ((as)this.v.get(i2)).d;
        String str23 = t.d(localContext5, i19);
        Context localContext6 = this.y;
        int i20 = ((as)this.v.get(i2)).d;
        int i21 = ((as)this.v.get(i2)).e;
        String str24 = t.b(localContext6, i20, i21);
        ((Bundle)localObject2).putString("home_location", str23);
        ((Bundle)localObject2).putString("home_sublocation", str24);
        int i22 = ((as)this.v.get(16)).d;
        ((Bundle)localObject2).putInt("nation", i22);
        int i23 = ((as)this.v.get(17)).d;
        ((Bundle)localObject2).putInt("belief", i23);
        int i24 = ((as)this.v.get(18)).d;
        ((Bundle)localObject2).putInt("avatar", i24);
      }
      localIntent.putExtras((Bundle)localObject2);
      sendBroadcast(localIntent);
      finish();
      return;
      localObject4 = ((as)this.v.get(i4)).b;
      break label102:
      label1352: localObject4 = ((as)this.v.get(i4)).c;
      break label153:
      label1372: localObject4 = ((as)this.v.get(i3)).b;
      label1391: break label367:
    }
  }

  private void g()
  {
    as localas1 = this.a;
    String str1 = ((as)this.v.get(2)).a;
    localas1.a = str1;
    as localas2 = this.a;
    String str2 = ((as)this.v.get(2)).b;
    localas2.b = str2;
    as localas3 = this.a;
    String str3 = ((as)this.v.get(2)).c;
    localas3.c = str3;
    as localas4 = this.a;
    int i1 = ((as)this.v.get(2)).d;
    localas4.d = i1;
    as localas5 = this.a;
    int i2 = ((as)this.v.get(2)).e;
    localas5.e = i2;
    StringBuilder localStringBuilder1 = new StringBuilder("locationTempCell.detail=");
    String str4 = this.a.b;
    String str5 = str4;
    com.jiayuan.util.a.a("SearchConditionActivity2", str5);
    StringBuilder localStringBuilder2 = new StringBuilder("locationTempCell.detail1=");
    String str6 = this.a.c;
    String str7 = str6;
    com.jiayuan.util.a.a("SearchConditionActivity2", str7);
  }

  private void h()
  {
    as localas1 = this.b;
    String str1 = ((as)this.v.get(15)).a;
    localas1.a = str1;
    as localas2 = this.b;
    String str2 = ((as)this.v.get(15)).b;
    localas2.b = str2;
    as localas3 = this.b;
    String str3 = ((as)this.v.get(15)).c;
    localas3.c = str3;
    as localas4 = this.b;
    int i1 = ((as)this.v.get(15)).d;
    localas4.d = i1;
    as localas5 = this.b;
    int i2 = ((as)this.v.get(15)).e;
    localas5.e = i2;
    StringBuilder localStringBuilder1 = new StringBuilder("birthplaceTempCell.detail=");
    String str4 = this.b.b;
    String str5 = str4;
    com.jiayuan.util.a.a("SearchConditionActivity2", str5);
    StringBuilder localStringBuilder2 = new StringBuilder("birthplaceTempCell.detail1=");
    String str6 = this.b.c;
    String str7 = str6;
    com.jiayuan.util.a.a("SearchConditionActivity2", str7);
  }

  private View i()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099840);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = a(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    g();
    g localg = new g(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(localg);
    int i2 = this.a.d;
    int i3 = this.a.e;
    localDoubleLevelSpinner.a(i2, true, i3, true);
    return localView;
  }

  private View j()
  {
    View localView = getLayoutInflater().inflate(2130903048, null);
    DoubleLevelSpinner localDoubleLevelSpinner = (DoubleLevelSpinner)localView.findViewById(2131361823);
    String[] arrayOfString = getResources().getStringArray(2131099840);
    int i1 = arrayOfString.length;
    int[] arrayOfInt = a(i1);
    String[][] arrayOfString1 = a(arrayOfInt);
    localDoubleLevelSpinner.a(arrayOfString, arrayOfString1);
    h();
    d locald = new d(this, arrayOfString, arrayOfString1);
    localDoubleLevelSpinner.a(locald);
    int i2 = this.b.d;
    int i3 = this.b.e;
    localDoubleLevelSpinner.a(i2, true, i3, true);
    return localView;
  }

  public Spinner a(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    Spinner localSpinner = (Spinner)findViewById(paramInt1);
    localSpinner.setPrompt(paramString);
    String[] arrayOfString = getResources().getStringArray(paramInt2);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    int i1 = ((as)this.v.get(paramInt3)).d;
    localSpinner.setSelection(i1, true);
    f localf = new f(this, paramInt3);
    localSpinner.setOnItemSelectedListener(localf);
    return localSpinner;
  }

  public void a()
  {
    Spinner localSpinner1 = a(2131362163, "璇烽�", 2131099735, 0);
    this.z = localSpinner1;
    Spinner localSpinner2 = a(2131362164, "璇烽�", 2131099791, 4);
    this.A = localSpinner2;
    Spinner localSpinner3 = a(2131362165, "璇烽�", 2131099787, 5);
    this.B = localSpinner3;
    Spinner localSpinner4 = a(2131362166, "璇烽�", 2131099786, 6);
    this.C = localSpinner4;
  }

  public void a(AgeRangePicker paramAgeRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 1;
    String str1 = "onAgeRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("SearchConditionActivity2", str1);
    String str2 = "onAgeRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("SearchConditionActivity2", str2);
    if ((paramInt1 < paramInt2) || (paramInt2 == 0))
    {
      as localas1 = (as)this.v.get(i1);
      String str3 = com.jiayuan.util.f.r(this, paramInt1);
      localas1.b = str3;
      as localas2 = (as)this.v.get(i1);
      String str4 = com.jiayuan.util.f.s(this, paramInt2);
      localas2.c = str4;
    }
    while (true)
    {
      this.x.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165336, 0).show();
    }
  }

  public void a(HeightRangePicker paramHeightRangePicker, int paramInt1, int paramInt2)
  {
    int i1 = 3;
    String str1 = "onHeightRangeChanged min=" + paramInt1;
    com.jiayuan.util.a.a("SearchConditionActivity2", str1);
    String str2 = "onHeightRangeChanged max=" + paramInt2;
    com.jiayuan.util.a.a("SearchConditionActivity2", str2);
    if ((paramInt1 < paramInt2) || (paramInt2 == 0))
    {
      as localas1 = (as)this.v.get(i1);
      String str3 = com.jiayuan.util.f.t(this, paramInt1);
      localas1.b = str3;
      as localas2 = (as)this.v.get(i1);
      String str4 = com.jiayuan.util.f.u(this, paramInt2);
      localas2.c = str4;
    }
    while (true)
    {
      this.x.notifyDataSetChanged();
      return;
      Toast.makeText(this, 2131165337, 0).show();
    }
  }

  public void a(JSONArray paramJSONArray, int paramInt)
  {
    o.a(paramJSONArray);
    this.x.notifyDataSetChanged();
  }

  public void a_(String paramString)
  {
  }

  public void b()
  {
    Spinner localSpinner1 = a(2131362167, "璇烽�", 2131099793, 7);
    this.D = localSpinner1;
    Spinner localSpinner2 = a(2131362169, "璇烽�", 2131099792, 8);
    this.E = localSpinner2;
    Spinner localSpinner3 = a(2131362170, "璇烽��", 2131099795, 9);
    this.F = localSpinner3;
    Spinner localSpinner4 = a(2131362171, "璇烽��", 2131099796, 10);
    this.G = localSpinner4;
    Spinner localSpinner5 = a(2131362172, "璇烽��", 2131099788, 11);
    this.H = localSpinner5;
    Spinner localSpinner6 = a(2131362173, "璇烽��", 2131099789, 12);
    this.I = localSpinner6;
    Spinner localSpinner7 = a(2131362174, "璇烽�", 2131099797, 13);
    this.J = localSpinner7;
    Spinner localSpinner8 = a(2131362175, "璇烽��", 2131099798, 14);
    this.K = localSpinner8;
    Spinner localSpinner9 = a(2131362176, "璇烽�", 2131099790, 16);
    this.L = localSpinner9;
    Spinner localSpinner10 = a(2131362177, "璇烽�", 2131099799, 17);
    this.M = localSpinner10;
    Spinner localSpinner11 = a(2131362178, "璇烽�鎷", 2131099801, 18);
    this.N = localSpinner11;
  }

  public void d()
  {
  }

  public void onCreate(Bundle paramBundle)
  {
    int i1 = 2131165220;
    int i2 = 14;
    int i3 = 12;
    boolean bool = null;
    int i4 = 1;
    super.onCreate(paramBundle);
    setContentView(2130903101);
    this.y = this;
    Object localObject1 = new StringBuilder("Preference.prefsGetSearchCondition(this, R.string.prefs_search_work_location)=");
    Object localObject2 = com.jiayuan.util.b.b(this, i1);
    localObject1 = (String)localObject2;
    com.jiayuan.util.a.a("SearchConditionActivity2", (String)localObject1);
    localObject1 = new StringBuilder("Preference.prefsGetSearchCondition(this, R.string.prefs_search_work_sublocation)=");
    localObject2 = com.jiayuan.util.b.b(this, 2131165221);
    localObject1 = (String)localObject2;
    com.jiayuan.util.a.a("SearchConditionActivity2", (String)localObject1);
    as localas2 = new as();
    localas2.a = "鎬";
    localObject1 = com.jiayuan.util.b.b(this, 2131165217);
    localObject1 = com.jiayuan.util.f.a(this, (String)localObject1);
    localas2.b = ((String)localObject1);
    localas2.c = "";
    localObject1 = localas2.b;
    localObject1 = com.jiayuan.util.f.q(this, (String)localObject1);
    localas2.d = localObject1;
    localas2.e = bool;
    localObject1 = new as();
    ((as)localObject1).a = "骞";
    localObject2 = com.jiayuan.util.b.b(this, 2131165218);
    ((as)localObject1).b = ((String)localObject2);
    localObject2 = ((as)localObject1).b.equals("0");
    if (localObject2 != 0)
    {
      localObject2 = "涓";
      ((as)localObject1).b = ((String)localObject2);
    }
    localObject2 = com.jiayuan.util.b.b(this, 2131165219);
    ((as)localObject1).c = ((String)localObject2);
    localObject2 = ((as)localObject1).c.equals("0");
    if (localObject2 != 0)
    {
      localObject2 = "涓";
      ((as)localObject1).c = ((String)localObject2);
    }
    localObject2 = ((as)localObject1).b;
    localObject2 = com.jiayuan.util.f.F(this, (String)localObject2);
    ((as)localObject1).d = localObject2;
    localObject2 = ((as)localObject1).c;
    localObject2 = com.jiayuan.util.f.G(this, (String)localObject2);
    ((as)localObject1).e = localObject2;
    localObject2 = com.jiayuan.util.b.b(this, i1);
    localObject2 = t.c(this, (String)localObject2);
    String str1 = com.jiayuan.util.b.b(this, 2131165221);
    int i5 = t.c(this, localObject2, str1);
    as localas1 = new as();
    localas1.a = "鍦";
    String str2 = t.b(this, localObject2);
    localas1.b = str2;
    String str3 = t.b(this, localObject2, i5, bool);
    localas1.c = str3;
    localas1.d = localObject2;
    localas1.e = i5;
    StringBuilder localStringBuilder1 = new StringBuilder(" init cell2.index=");
    int i6 = localas1.d;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i6).append("cell2.index1=");
    int i7 = localas1.e;
    String str4 = i7;
    com.jiayuan.util.a.a("SearchConditionActivity2", str4);
    localObject2 = new as();
    ((as)localObject2).a = "韬";
    String str5 = com.jiayuan.util.b.b(this, 2131165222);
    ((as)localObject2).b = str5;
    if (((as)localObject2).b.equals("0"))
      ((as)localObject2).b = "涓";
    String str6 = com.jiayuan.util.b.b(this, 2131165223);
    ((as)localObject2).c = str6;
    if (((as)localObject2).c.equals("0"))
      ((as)localObject2).c = "涓";
    String str7 = ((as)localObject2).b;
    int i8 = com.jiayuan.util.f.I(this, str7);
    ((as)localObject2).d = i8;
    String str8 = ((as)localObject2).c;
    int i9 = com.jiayuan.util.f.J(this, str8);
    ((as)localObject2).e = i9;
    as localas3 = new as();
    localas3.a = "鏈";
    StringBuilder localStringBuilder3 = new StringBuilder("income=");
    int i10 = Integer.parseInt(com.jiayuan.util.b.b(this, 2131165224));
    String str9 = i10;
    com.jiayuan.util.a.a("SearchConditionActivity2", str9);
    int i11 = Integer.parseInt(com.jiayuan.util.b.b(this, 2131165224));
    String str10 = com.jiayuan.util.f.h(this, i11);
    localas3.b = str10;
    localas3.c = "";
    String str11 = localas3.b;
    int i12 = com.jiayuan.util.f.z(this, str11);
    int i13;
    ++i13;
    localas3.d = i12;
    localas3.e = i4;
    as localas4 = new as();
    localas4.a = "濠";
    int i14 = Integer.parseInt(com.jiayuan.util.b.b(this, 2131165225));
    String str12 = com.jiayuan.util.f.d(this, i14);
    localas4.b = str12;
    localas4.c = "";
    String str13 = localas4.b;
    int i15 = com.jiayuan.util.f.t(this, str13);
    int i16;
    ++i16;
    localas4.d = i15;
    localas4.e = i4;
    as localas5 = new as();
    localas5.a = "瀛";
    int i17 = Integer.parseInt(com.jiayuan.util.b.b(this, 2131165226));
    String str14 = com.jiayuan.util.f.c(this, i17);
    localas5.b = str14;
    localas5.c = "";
    String str15 = localas5.b;
    int i18 = com.jiayuan.util.f.u(this, str15);
    int i19;
    ++i19;
    localas5.d = i18;
    localas5.e = i4;
    ArrayList localArrayList1 = new ArrayList();
    this.v = localArrayList1;
    this.v.add(localas2);
    this.v.add(localObject1);
    this.v.add(localas1);
    this.v.add(localObject2);
    this.v.add(localas3);
    this.v.add(localas4);
    this.v.add(localas5);
    a();
    ListView localListView1 = (ListView)findViewById(2131362158);
    this.w = localas2;
    TextView localTextView = new TextView(this);
    localas2.setClickable(i4);
    h localh = new h(this, localas2);
    localas2.setOnClickListener((View.OnClickListener)localObject1);
    localas2.setText(2131165367);
    localas2.setTextSize(1101004800);
    localas2.setPadding(i2, i3, i2, i3);
    LinearLayout localLinearLayout = new LinearLayout(this);
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -1);
    localas2.setGravity(i4);
    ((LinearLayout)localObject1).addView(localas2, (ViewGroup.LayoutParams)localObject2);
    this.w.addFooterView((View)localObject1);
    ArrayList localArrayList2 = this.v;
    ar localar1 = new ar(this, this, (List)localObject1);
    this.x = localas2;
    this.x.setNotifyOnChange(bool);
    ListView localListView2 = this.w;
    ar localar2 = this.x;
    localas2.setAdapter((ListAdapter)localObject1);
    this.w.setOnItemClickListener(this);
    Button localButton = (Button)findViewById(2131362157);
    i locali = new i(this);
    localas2.setOnClickListener((View.OnClickListener)localObject1);
  }

  protected Dialog onCreateDialog(int paramInt)
  {
    int i1 = 2131165643;
    int i2 = 2131165642;
    int i3;
    switch (paramInt)
    {
    default:
      i3 = 0;
    case 0:
    case 1:
    }
    while (true)
    {
      return i3;
      Object localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView1 = i();
      localObject = ((AlertDialog.Builder)localObject).setView(localView1);
      e locale = new e(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(i2, locale);
      b localb = new b(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(i1, localb).create();
      continue;
      localObject = new AlertDialog.Builder(this).setTitle("璇烽�");
      View localView2 = j();
      localObject = ((AlertDialog.Builder)localObject).setView(localView2);
      a locala = new a(this);
      localObject = ((AlertDialog.Builder)localObject).setPositiveButton(i2, locala);
      c localc = new c(this);
      localObject = ((AlertDialog.Builder)localObject).setNegativeButton(i1, localc).create();
    }
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    int i1 = 3;
    int i2 = 1;
    String str = "position=" + paramInt;
    com.jiayuan.util.a.a("SearchConditionActivity2", str);
    if (paramInt == 0)
    {
      this.z.performClick();
      CharSequence localCharSequence1 = this.z.getPrompt();
      Toast.makeText(this, localCharSequence1, i2).show();
    }
    while (true)
    {
      return;
      if (i2 == paramInt)
      {
        int i3 = ((as)this.v.get(i2)).d;
        int i4 = ((as)this.v.get(i2)).e;
        new m(this, this, i3, i4).show();
      }
      if (2 == paramInt)
        showDialog(0);
      if (i1 == paramInt)
      {
        int i5 = ((as)this.v.get(i1)).d;
        int i6 = ((as)this.v.get(i1)).e;
        new z(this, this, i5, i6).show();
      }
      if (4 == paramInt)
      {
        this.A.performClick();
        CharSequence localCharSequence2 = this.A.getPrompt();
        Toast.makeText(this, localCharSequence2, i2).show();
      }
      if (5 == paramInt)
      {
        this.B.performClick();
        CharSequence localCharSequence3 = this.B.getPrompt();
        Toast.makeText(this, localCharSequence3, i2).show();
      }
      if (6 == paramInt)
      {
        this.C.performClick();
        CharSequence localCharSequence4 = this.C.getPrompt();
        Toast.makeText(this, localCharSequence4, i2).show();
      }
      if (7 == paramInt)
      {
        this.D.performClick();
        Context localContext1 = this.y;
        CharSequence localCharSequence5 = this.D.getPrompt();
        Toast.makeText(localContext1, localCharSequence5, i2).show();
      }
      if (8 == paramInt)
      {
        this.E.performClick();
        Context localContext2 = this.y;
        CharSequence localCharSequence6 = this.E.getPrompt();
        Toast.makeText(localContext2, localCharSequence6, i2).show();
      }
      if (9 == paramInt)
      {
        this.F.performClick();
        Context localContext3 = this.y;
        CharSequence localCharSequence7 = this.F.getPrompt();
        Toast.makeText(localContext3, localCharSequence7, i2).show();
      }
      if (10 == paramInt)
      {
        this.G.performClick();
        Context localContext4 = this.y;
        CharSequence localCharSequence8 = this.G.getPrompt();
        Toast.makeText(localContext4, localCharSequence8, i2).show();
      }
      if (11 == paramInt)
      {
        this.H.performClick();
        Context localContext5 = this.y;
        CharSequence localCharSequence9 = this.H.getPrompt();
        Toast.makeText(localContext5, localCharSequence9, i2).show();
      }
      if (12 == paramInt)
      {
        this.I.performClick();
        Context localContext6 = this.y;
        CharSequence localCharSequence10 = this.I.getPrompt();
        Toast.makeText(localContext6, localCharSequence10, i2).show();
      }
      if (13 == paramInt)
      {
        this.J.performClick();
        Context localContext7 = this.y;
        CharSequence localCharSequence11 = this.J.getPrompt();
        Toast.makeText(localContext7, localCharSequence11, i2).show();
      }
      if (14 == paramInt)
      {
        this.K.performClick();
        Context localContext8 = this.y;
        CharSequence localCharSequence12 = this.K.getPrompt();
        Toast.makeText(localContext8, localCharSequence12, i2).show();
      }
      if (15 == paramInt)
        showDialog(i2);
      if (16 == paramInt)
      {
        this.L.performClick();
        Context localContext9 = this.y;
        CharSequence localCharSequence13 = this.L.getPrompt();
        Toast.makeText(localContext9, localCharSequence13, i2).show();
      }
      if (17 == paramInt)
      {
        this.M.performClick();
        Context localContext10 = this.y;
        CharSequence localCharSequence14 = this.M.getPrompt();
        Toast.makeText(localContext10, localCharSequence14, i2).show();
      }
      if (18 != paramInt)
        continue;
      this.N.performClick();
      Context localContext11 = this.y;
      CharSequence localCharSequence15 = this.N.getPrompt();
      Toast.makeText(localContext11, localCharSequence15, i2).show();
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.search.SearchConditionActivity
 * JD-Core Version:    0.5.4
 */