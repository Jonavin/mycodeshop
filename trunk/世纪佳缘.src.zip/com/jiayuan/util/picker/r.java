package com.jiayuan.util.picker;

public abstract interface r
{
  public abstract void a(NumberPicker paramNumberPicker, int paramInt1, int paramInt2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.picker.r
 * JD-Core Version:    0.5.4
 */