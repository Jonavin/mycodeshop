package com.jiayuan.util.picker;

public abstract interface ab
{
  public abstract void a(HeightRangePicker paramHeightRangePicker, int paramInt1, int paramInt2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.picker.ab
 * JD-Core Version:    0.5.4
 */