package com.jiayuan.util.picker;

public abstract interface y
{
  public abstract void a(HeightPicker paramHeightPicker, int paramInt);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.picker.y
 * JD-Core Version:    0.5.4
 */