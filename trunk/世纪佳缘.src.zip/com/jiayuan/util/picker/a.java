package com.jiayuan.util.picker;

public abstract interface a
{
  public abstract void a(AgeRangePicker paramAgeRangePicker, int paramInt1, int paramInt2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.picker.a
 * JD-Core Version:    0.5.4
 */