package com.jiayuan.util;

import android.graphics.Bitmap;

public abstract interface e
{
  public abstract void a(int paramInt, Bitmap paramBitmap);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.e
 * JD-Core Version:    0.5.4
 */