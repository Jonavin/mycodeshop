package com.jiayuan.util;

public abstract interface n
{
  public abstract void a(String paramString);

  public abstract void a_(String paramString);

  public abstract void d();

  public abstract void g();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.jiayuan.util.n
 * JD-Core Version:    0.5.4
 */