package com.a;

import java.util.concurrent.Callable;

class au
  implements Callable
{
  private static final String[] b;
  final bn a;

  static
  {
    Object localObject1 = 80;
    Object localObject2 = 33;
    Object localObject3 = 18;
    int i = 1;
    Object localObject4 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "b8N5\037".toCharArray();
    Object localObject9 = arrayOfChar1.length;
    Object localObject19;
    Object localObject21;
    Object localObject10;
    Object localObject16;
    int k;
    int l;
    label116: Object localObject6;
    if (localObject9 <= i)
    {
      Object localObject15 = localObject4;
      localObject19 = localObject9;
      localObject21 = localObject15;
      localObject10 = arrayOfChar1;
      char[] arrayOfChar2 = localObject15;
      localObject16 = arrayOfChar1;
      Object localObject5;
      for (arrayOfChar1 = arrayOfChar2; ; localObject5 = localObject19)
      {
        k = localObject10[arrayOfChar1];
        l = localObject21 % 5;
        switch (l)
        {
        default:
          l = 122;
          k = (char)(k ^ l);
          localObject10[arrayOfChar1] = k;
          localObject5 = localObject21 + 1;
          if (localObject19 != 0)
            break;
          localObject10 = localObject16;
          localObject21 = localObject5;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject10 = localObject19;
      Object localObject22 = localObject16;
      localObject16 = localObject5;
      localObject6 = localObject22;
    }
    while (true)
    {
      if (localObject10 <= localObject16);
      localObject6 = new String(localObject6).intern();
      arrayOfString[localObject4] = localObject6;
      localObject6 = "b8N5\0372$X+\0372m\001".toCharArray();
      Object localObject11 = localObject6.length;
      Object localObject12;
      label296: Object localObject8;
      if (localObject11 <= i)
      {
        localObject16 = localObject4;
        localObject19 = localObject11;
        localObject21 = localObject16;
        localObject12 = localObject6;
        Object localObject23 = localObject16;
        localObject16 = localObject6;
        Object localObject7;
        for (localObject6 = localObject23; ; localObject7 = localObject19)
        {
          k = localObject12[localObject6];
          l = localObject21 % 5;
          switch (l)
          {
          default:
            l = 122;
            k = (char)(k ^ l);
            localObject12[localObject6] = k;
            localObject7 = localObject21 + 1;
            if (localObject19 != 0)
              break;
            localObject12 = localObject16;
            localObject21 = localObject7;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject12 = localObject19;
        Object localObject24 = localObject16;
        localObject16 = localObject7;
        localObject8 = localObject24;
      }
      while (true)
      {
        if (localObject12 <= localObject16);
        localObject8 = new String(localObject8).intern();
        arrayOfString[i] = localObject8;
        int j = 2;
        localObject12 = "\\?\001\034)_p`?\033b$D)Zt?T5\036".toCharArray();
        Object localObject17 = localObject12.length;
        Object localObject20;
        label480: Object localObject14;
        if (localObject17 <= i)
        {
          localObject19 = localObject4;
          localObject21 = localObject17;
          k = localObject19;
          localObject18 = localObject12;
          Object localObject25 = localObject19;
          localObject20 = localObject12;
          Object localObject13;
          for (localObject12 = localObject25; ; localObject13 = localObject21)
          {
            l = localObject18[localObject12];
            localObject4 = k % 5;
            switch (localObject4)
            {
            default:
              localObject4 = 122;
              int i1 = (char)(l ^ localObject4);
              localObject18[localObject12] = l;
              localObject13 = k + 1;
              if (localObject21 != 0)
                break;
              localObject18 = localObject20;
              k = localObject13;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject18 = localObject21;
          Object localObject26 = localObject20;
          localObject20 = localObject13;
          localObject14 = localObject26;
        }
        while (true)
        {
          if (localObject18 <= localObject20);
          String str = new String(localObject14).intern();
          arrayOfString[j] = localObject14;
          b = arrayOfString;
          return;
          l = localObject3;
          break label116:
          l = localObject1;
          break label116:
          l = localObject2;
          break label116:
          l = 91;
          break label116:
          l = localObject3;
          break label296:
          l = localObject1;
          break label296:
          l = localObject2;
          break label296:
          l = 91;
          break label296:
          localObject4 = localObject3;
          break label480:
          localObject4 = localObject1;
          break label480:
          localObject4 = localObject2;
          break label480:
          localObject4 = 91;
          break label480:
          localObject20 = localObject4;
        }
        localObject18 = localObject4;
      }
      Object localObject18 = localObject4;
    }
  }

  au(bn parambn)
  {
  }

  // ERROR //
  public java.lang.Boolean a()
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: iload_2
    //   3: putstatic 45	com/a/ad:b	Z
    //   6: new 47	com/a/al
    //   9: dup
    //   10: aload_0
    //   11: invokespecial 50	com/a/al:<init>	(Lcom/a/au;)V
    //   14: astore_3
    //   15: aload_0
    //   16: getfield 37	com/a/au:a	Lcom/a/bn;
    //   19: astore 4
    //   21: aload 4
    //   23: monitorenter
    //   24: aload_0
    //   25: getfield 37	com/a/au:a	Lcom/a/bn;
    //   28: astore 5
    //   30: aload_0
    //   31: getfield 37	com/a/au:a	Lcom/a/bn;
    //   34: invokestatic 56	com/a/bn:i	(Lcom/a/bn;)Landroid/content/Context;
    //   37: astore 6
    //   39: getstatic 34	com/a/au:b	[Ljava/lang/String;
    //   42: aconst_null
    //   43: aaload
    //   44: astore 7
    //   46: aload 6
    //   48: aload 7
    //   50: invokevirtual 62	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   53: checkcast 64	android/telephony/TelephonyManager
    //   56: astore 6
    //   58: aload 5
    //   60: aload 6
    //   62: invokestatic 67	com/a/bn:a	(Lcom/a/bn;Landroid/telephony/TelephonyManager;)Landroid/telephony/TelephonyManager;
    //   65: pop
    //   66: aload_0
    //   67: getfield 37	com/a/au:a	Lcom/a/bn;
    //   70: invokestatic 70	com/a/bn:b	(Lcom/a/bn;)Landroid/telephony/TelephonyManager;
    //   73: invokevirtual 74	android/telephony/TelephonyManager:getPhoneType	()I
    //   76: astore 6
    //   78: aload_0
    //   79: getfield 37	com/a/au:a	Lcom/a/bn;
    //   82: invokestatic 77	com/a/bn:a	(Lcom/a/bn;)Lcom/a/ag;
    //   85: astore 8
    //   87: new 79	java/lang/StringBuilder
    //   90: dup
    //   91: invokespecial 80	java/lang/StringBuilder:<init>	()V
    //   94: astore 9
    //   96: getstatic 34	com/a/au:b	[Ljava/lang/String;
    //   99: iconst_1
    //   100: aaload
    //   101: astore 10
    //   103: aload 9
    //   105: aload 10
    //   107: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: iload 6
    //   112: invokevirtual 87	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   115: invokevirtual 90	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   118: astore 11
    //   120: aload 8
    //   122: aload 11
    //   124: invokevirtual 95	com/a/ag:b	(Ljava/lang/String;)V
    //   127: iload 6
    //   129: iload_1
    //   130: if_icmpeq +41 -> 171
    //   133: aload_0
    //   134: getfield 37	com/a/au:a	Lcom/a/bn;
    //   137: aconst_null
    //   138: invokestatic 67	com/a/bn:a	(Lcom/a/bn;Landroid/telephony/TelephonyManager;)Landroid/telephony/TelephonyManager;
    //   141: pop
    //   142: getstatic 34	com/a/au:b	[Ljava/lang/String;
    //   145: iconst_2
    //   146: aaload
    //   147: astore 12
    //   149: new 97	com/a/x
    //   152: dup
    //   153: aload 12
    //   155: invokespecial 99	com/a/x:<init>	(Ljava/lang/String;)V
    //   158: astore 6
    //   160: aload 6
    //   162: athrow
    //   163: astore 6
    //   165: aload 4
    //   167: monitorexit
    //   168: aload 6
    //   170: athrow
    //   171: aload_0
    //   172: getfield 37	com/a/au:a	Lcom/a/bn;
    //   175: astore 6
    //   177: aload 6
    //   179: aload_3
    //   180: invokestatic 102	com/a/bn:a	(Lcom/a/bn;Landroid/telephony/PhoneStateListener;)Landroid/telephony/PhoneStateListener;
    //   183: pop
    //   184: aload 4
    //   186: monitorexit
    //   187: iload_1
    //   188: invokestatic 108	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   191: astore 6
    //   193: iload_2
    //   194: ifeq +16 -> 210
    //   197: getstatic 114	com/a/bf:d	I
    //   200: istore 13
    //   202: iinc 2 1
    //   205: iload 13
    //   207: putstatic 114	com/a/bf:d	I
    //   210: aload 6
    //   212: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   24	168	163	finally
    //   171	187	163	finally
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.au
 * JD-Core Version:    0.5.4
 */