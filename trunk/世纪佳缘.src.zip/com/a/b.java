package com.a;

import java.util.Comparator;

final class b
  implements Comparator
{
  public int a(f paramf1, f paramf2)
  {
    bv localbv1 = paramf1.a();
    bv localbv2 = paramf2.a();
    return localbv1.a(localbv2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.b
 * JD-Core Version:    0.5.4
 */