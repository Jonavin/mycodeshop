package com.a;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class c
{
  static final boolean a;
  public static int b;
  private static final Comparator c;

  static
  {
    if (!c.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      c = new bw();
      return;
    }
  }

  public static double a(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    int i;
    a = i;
    if ((i == 0) && (??? > paramDouble2))
      throw new AssertionError();
    double paramDouble3 = Math.min(paramDouble1, paramDouble2);
    return Math.max(???, paramDouble3);
  }

  public static int a(List paramList1, List paramList2, Comparator paramComparator)
  {
    Object localObject1 = b;
    int i;
    a = i;
    boolean bool1;
    if (i == 0)
    {
      bool1 = b(paramList1, paramComparator);
      if (!bool1)
        throw new AssertionError();
    }
    a = bool1;
    if (!bool1)
    {
      bool1 = b(paramList2, paramComparator);
      if (!bool1)
        throw new AssertionError();
    }
    int j = paramList1.size();
    int k = paramList2.size();
    j += k;
    Iterator localIterator1 = paramList1.iterator();
    Object localObject5;
    label112: Object localObject4;
    Object localObject6;
    do
    {
      int l = localIterator1.hasNext();
      localObject5 = j;
      j = l;
      if (j == 0)
        break;
      localObject4 = localIterator1.next();
      if (localObject1 != 0)
        break;
      Iterator localIterator2 = paramList2.iterator();
      do
      {
        boolean bool2 = localIterator2.hasNext();
        if (!bool2)
          break;
        localObject6 = localIterator2.next();
        localObject6 = paramComparator.compare(localObject4, localObject6);
        if (localObject1 != 0)
          break label258;
        if (localObject6 != 0)
          continue;
        localObject5 -= 2;
      }
      while ((localObject1 != 0) && (localObject1 == 0));
      localObject4 = localObject5;
    }
    while (localObject1 == 0);
    label258: List localList;
    for (localObject1 = localObject4; ; localList = localObject5)
    {
      a = localObject4;
      Object localObject2;
      if (localObject4 == 0)
      {
        localObject4 = localObject1;
        localObject2 = paramList1;
      }
      while (true)
      {
        localObject2 = ((List)localObject2).size();
        int i1 = paramList2.size();
        localObject2 += i1;
        if (localObject3 < localObject4)
          throw new AssertionError();
        Object localObject3 = localObject4;
        return localObject3;
        localObject4 = localObject6;
        break label112:
        localList = paramList2;
        localObject4 = localObject5;
      }
    }
  }

  public static Comparable a(Comparable paramComparable1, Comparable paramComparable2)
  {
    Comparator localComparator = c;
    return (Comparable)a(paramComparable1, paramComparable2, localComparator);
  }

  public static Object a(Object paramObject1, Object paramObject2, Comparator paramComparator)
  {
    int i = paramComparator.compare(paramObject1, paramObject2);
    if (i >= 0);
    for (Object localObject = paramObject1; ; localObject = paramObject2)
      return localObject;
  }

  public static void a(Iterable paramIterable, bu parambu)
  {
    int i = b;
    Iterator localIterator = paramIterable.iterator();
    do
    {
      Object localObject;
      do
      {
        if (!localIterator.hasNext())
          return;
        localObject = localIterator.next();
      }
      while (!parambu.a(localObject));
      localIterator.remove();
    }
    while (i == 0);
  }

  public static void a(List paramList1, List paramList2, cb paramcb, Comparator paramComparator)
  {
    boolean bool1 = false;
    int i = b;
    int j;
    a = j;
    if (j == 0)
    {
      bool2 = a(paramList1, paramComparator);
      if (!bool2)
        throw new AssertionError();
    }
    a = bool2;
    if (!bool2)
    {
      bool2 = a(paramList2, paramComparator);
      if (!bool2)
        throw new AssertionError();
    }
    a = bool2;
    if (!bool2)
    {
      bool2 = b(paramList1, paramComparator);
      if (!bool2)
        throw new AssertionError();
    }
    a = bool2;
    if (!bool2)
    {
      bool2 = b(paramList2, paramComparator);
      if (!bool2)
        throw new AssertionError();
    }
    boolean bool2 = bool1;
    do
    {
      int l = paramList1.size();
      if (bool1 >= l)
        break;
      l = paramList2.size();
      if (i != 0)
        break label444;
      if (bool2 >= l)
        break;
      Object localObject1 = paramList1.get(bool1);
      Object localObject2 = paramList2.get(bool2);
      localObject1 = paramComparator.compare(localObject1, localObject2);
      if (localObject1 < 0)
      {
        bool4 = bool1 + true;
        paramcb.c(bool1, bool2);
        if (i == 0)
          break label437;
        bool1 = bool4;
      }
      if (localObject1 > 0)
      {
        bool3 = bool2 + true;
        paramcb.b(bool1, bool2);
        if (i == 0)
          break label430;
        bool2 = bool3;
      }
      boolean bool3 = bool1 + true;
      boolean bool4 = bool2 + true;
      paramcb.a(bool1, bool2);
      bool2 = bool4;
      label289: bool1 = bool3;
    }
    while (i == 0);
    label294: int i1 = paramList1.size();
    boolean bool5 = bool1;
    int i2 = bool2;
    bool2 = i1;
    label404: label419: label430: label437: label444: int i5;
    for (i1 = i2; ; i1 = i5)
    {
      if (bool1 < bool2)
      {
        k = paramList2.size();
        paramcb.c(bool5, k);
        k = bool5 + true;
        if (i != 0)
          break label404;
        if (i == 0)
          break label419;
      }
      int k = i1;
      do
      {
        int i3 = paramList2.size();
        if (k >= i3)
          break;
        int i4 = paramList1.size();
        paramcb.b(i4, k);
        ++k;
      }
      while (i == 0);
      if (bf.d != 0)
        b = ++i;
      return;
      bool1 = k;
      k = i1;
      break label294:
      k = i1;
      break label289:
      bool1 = bool5;
      break label289:
      boolean bool6 = bool1;
      bool1 = k;
      i5 = k;
      k = i1;
    }
  }

  public static void a(List paramList, boolean[] paramArrayOfBoolean)
  {
    int i = b;
    Iterator localIterator = paramList.iterator();
    Object localObject = null;
    do
    {
      if (!localIterator.hasNext())
        return;
      localIterator.next();
      if (paramArrayOfBoolean[localObject] == 0)
        localIterator.remove();
      ++localObject;
    }
    while (i == 0);
  }

  public static boolean a(Iterable paramIterable)
  {
    Comparator localComparator = c;
    return a(paramIterable, localComparator);
  }

  public static boolean a(Iterable paramIterable, Comparator paramComparator)
  {
    Object localObject1 = 1;
    int i = b;
    cd.b();
    Iterator localIterator = paramIterable.iterator();
    boolean bool1 = localIterator.hasNext();
    if (!bool1);
    label33: Object localObject3;
    Object localObject2;
    for (i = localObject1; ; localObject2 = localObject3)
    {
      return i;
      Object localObject4;
      for (localObject3 = localIterator.next(); ; localObject3 = localObject4)
      {
        boolean bool2 = localIterator.hasNext();
        if (bool2)
        {
          localObject4 = localIterator.next();
          localObject3 = paramComparator.compare(localObject3, localObject4);
          if (i != 0)
            break;
          if (localObject3 > 0)
            localObject2 = null;
          if (localObject2 == 0)
            continue;
        }
        localObject2 = localObject1;
        break label33:
      }
    }
  }

  public static boolean a(ArrayList paramArrayList1, ArrayList paramArrayList2, Comparator paramComparator)
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int i = b;
    int j = paramArrayList1.size();
    int k = paramArrayList2.size();
    if (j > k);
    for (Object localObject3 = localObject2; ; localObject3 = localObject2)
    {
      label33: return localObject3;
      Iterator localIterator1 = paramArrayList1.iterator();
      boolean bool1 = localIterator1.hasNext();
      Object localObject4;
      Object localObject6;
      if (bool1)
      {
        localObject4 = localIterator1.next();
        if (localObject3 != 0)
          continue;
        Iterator localIterator2 = paramArrayList2.iterator();
        Object localObject5 = localObject2;
        do
        {
          boolean bool2 = localIterator2.hasNext();
          if (!bool2)
            break;
          localObject6 = localIterator2.next();
          localObject6 = paramComparator.compare(localObject6, localObject4);
          if (localObject3 != 0)
            break label171;
          if (localObject6 != 0)
            continue;
          if (localObject3 == 0)
            break label165;
          localObject5 = localObject1;
        }
        while (localObject3 == 0);
        localObject4 = localObject5;
      }
      while (true)
      {
        if (localObject4 == null)
          localObject3 = localObject2;
        if (localObject3 != 0);
        localObject3 = localObject1;
        break label33:
        label165: localObject4 = localObject1;
        continue;
        label171: localObject4 = localObject6;
      }
    }
  }

  public static Comparable b(Comparable paramComparable1, Comparable paramComparable2)
  {
    Comparator localComparator = c;
    return (Comparable)b(paramComparable1, paramComparable2, localComparator);
  }

  public static Iterable b(Iterable paramIterable, bu parambu)
  {
    return new bg(paramIterable, parambu);
  }

  public static Object b(Object paramObject1, Object paramObject2, Comparator paramComparator)
  {
    int i = paramComparator.compare(paramObject1, paramObject2);
    if (i >= 0);
    for (Object localObject = paramObject2; ; localObject = paramObject1)
      return localObject;
  }

  public static boolean b(Iterable paramIterable, Comparator paramComparator)
  {
    Object localObject1 = 1;
    int i = b;
    cd.b();
    Object localObject3 = new ArrayList();
    Object localObject4 = paramIterable.iterator();
    Object localObject5;
    do
    {
      boolean bool = ((Iterator)localObject4).hasNext();
      if (!bool)
        break;
      localObject5 = ((Iterator)localObject4).next();
      ((ArrayList)localObject3).add(localObject5);
      if (i != 0)
        break label173;
    }
    while (i == 0);
    Collections.sort((List)localObject3, paramComparator);
    for (localObject3 = ((ArrayList)localObject3).iterator(); ; localObject3 = localObject4)
    {
      localObject4 = ((Iterator)localObject3).hasNext();
      if (localObject4 == 0);
      label94: Object localObject2;
      for (i = localObject1; ; localObject2 = localObject4)
      {
        return i;
        for (localObject4 = ((Iterator)localObject3).next(); ; localObject4 = localObject5)
        {
          localObject5 = ((Iterator)localObject3).hasNext();
          if (localObject5 != 0)
          {
            localObject5 = ((Iterator)localObject3).next();
            localObject4 = localObject4.equals(localObject5);
            if (i != 0)
              break;
            if (localObject4 != 0)
              localObject2 = null;
            if (localObject2 == 0)
              continue;
          }
          localObject2 = localObject1;
          label173: break label94:
        }
      }
    }
  }

  public static void c(Iterable paramIterable, Comparator paramComparator)
  {
    int i = b;
    int j;
    a = j;
    if (j == 0)
    {
      boolean bool1 = a(paramIterable, paramComparator);
      if (!bool1)
        throw new AssertionError();
    }
    Iterator localIterator = paramIterable.iterator();
    boolean bool2 = localIterator.hasNext();
    if (!bool2)
      return;
    Object localObject1 = localIterator.next();
    label59: boolean bool3 = localIterator.hasNext();
    Object localObject2;
    if (bool3)
    {
      localObject2 = localIterator.next();
      localObject1 = paramComparator.compare(localObject1, localObject2);
      if (i != 0)
        break label142;
      if (localObject1 == 0)
        localIterator.remove();
      if (i == 0)
        break label135;
    }
    a = i;
    while (true)
    {
      if ((i == 0) && (!b(paramIterable, paramComparator)));
      throw new AssertionError();
      label135: localObject1 = localObject2;
      break label59:
      label142: i = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.c
 * JD-Core Version:    0.5.4
 */