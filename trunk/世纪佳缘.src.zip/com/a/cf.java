package com.a;

import android.content.Context;
import android.location.LocationManager;
import java.util.concurrent.Callable;

class cf
  implements Callable
{
  private static final String b;
  final u a;

  static
  {
    char[] arrayOfChar1 = "*(1|$/(<".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 80; ; k = 29)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        return;
        k = 70;
        continue;
        k = 71;
        continue;
        k = 82;
      }
  }

  cf(u paramu)
  {
  }

  public LocationManager a()
  {
    Context localContext = u.a(this.a);
    String str = b;
    return (LocationManager)localContext.getSystemService(str);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.cf
 * JD-Core Version:    0.5.4
 */