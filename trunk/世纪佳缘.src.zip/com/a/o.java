package com.a;

import java.util.List;

public abstract class o extends bf
{
  public static final o a;
  public static boolean b;
  private static o c;
  private static final String e;

  static
  {
    char[] arrayOfChar1 = "h\016g6\t+\034le]{\035fe\022\026yt\016".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 125; ; k = 17)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        e = new String(localObject1).intern();
        a = new m();
        c = null;
        return;
        k = 11;
        continue;
        k = 111;
        continue;
        k = 9;
      }
  }

  public static o b(av paramav)
  {
    Object localObject = c;
    if (localObject == null);
    for (localObject = new j(paramav); ; localObject = c.a(paramav))
      return localObject;
  }

  protected abstract o a(av paramav);

  public abstract void b();

  public abstract void c();

  public abstract List d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.o
 * JD-Core Version:    0.5.4
 */