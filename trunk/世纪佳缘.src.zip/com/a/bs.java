package com.a;

class bs
{
  static final int[] a;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bs
 * JD-Core Version:    0.5.4
 */