package com.a;

public abstract interface bu
{
  public abstract boolean a(Object paramObject);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bu
 * JD-Core Version:    0.5.4
 */