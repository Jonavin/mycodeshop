package com.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

public final class p extends s
{
  private static final String[] g;
  private final ag b;
  private Context c;
  private BroadcastReceiver e;
  private az f;

  static
  {
    int i = 60;
    int j = 43;
    int k = 39;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[4];
    char[] arrayOfChar1 = "\034K+N]\031^yDL\030I".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject20;
    Object localObject22;
    Object localObject7;
    Object localObject15;
    int i2;
    int i4;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject14 = localObject1;
      localObject20 = localObject6;
      localObject22 = localObject14;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject14;
      localObject15 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject20)
      {
        i2 = localObject7[arrayOfChar1];
        i4 = localObject22 % 5;
        switch (i4)
        {
        default:
          i4 = i;
          i2 = (char)(i2 ^ i4);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject22 + 1;
          if (localObject20 != 0)
            break;
          localObject7 = localObject15;
          localObject22 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject20;
      Object localObject23 = localObject15;
      localObject15 = localObject2;
      localObject3 = localObject23;
    }
    while (true)
    {
      if (localObject7 <= localObject15);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "\034I=YS\024CwBR\tB7_\022\034D-BS\023\t\033jh)b\013rc>o\030e{8c".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject15 = localObject1;
        localObject20 = localObject8;
        localObject22 = localObject15;
        localObject9 = localObject3;
        Object localObject24 = localObject15;
        localObject15 = localObject3;
        Object localObject4;
        for (localObject3 = localObject24; ; localObject4 = localObject20)
        {
          i2 = localObject9[localObject3];
          i4 = localObject22 % 5;
          switch (i4)
          {
          default:
            i4 = i;
            i2 = (char)(i2 ^ i4);
            localObject9[localObject3] = i2;
            localObject4 = localObject22 + 1;
            if (localObject20 != 0)
              break;
            localObject9 = localObject15;
            localObject22 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject20;
        Object localObject25 = localObject15;
        localObject15 = localObject4;
        localObject5 = localObject25;
      }
      while (true)
      {
        if (localObject9 <= localObject15);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "\034K+N]\031^yHP\022T<O".toCharArray();
        Object localObject16 = localObject9.length;
        Object localObject17;
        Object localObject21;
        int i5;
        label475: Object localObject11;
        if (localObject16 <= l)
        {
          localObject20 = localObject1;
          localObject22 = localObject16;
          i2 = localObject20;
          localObject17 = localObject9;
          Object localObject26 = localObject20;
          localObject21 = localObject9;
          Object localObject10;
          for (localObject9 = localObject26; ; localObject10 = localObject22)
          {
            i4 = localObject17[localObject9];
            i5 = i2 % 5;
            switch (i5)
            {
            default:
              i5 = i;
              i4 = (char)(i4 ^ i5);
              localObject17[localObject9] = i4;
              localObject10 = i2 + 1;
              if (localObject22 != 0)
                break;
              localObject17 = localObject21;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject17 = localObject22;
          Object localObject27 = localObject21;
          localObject21 = localObject10;
          localObject11 = localObject27;
        }
        while (true)
        {
          if (localObject17 <= localObject21);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "\030U+DN]R7YY\032N*_Y\017N7L\034\017B:NU\013B+".toCharArray();
          Object localObject18 = localObject11.length;
          label659: Object localObject13;
          if (localObject18 <= l)
          {
            localObject21 = localObject1;
            localObject22 = localObject18;
            int i3 = localObject21;
            localObject19 = localObject11;
            Object localObject28 = localObject21;
            localObject21 = localObject11;
            Object localObject12;
            for (localObject11 = localObject28; ; localObject12 = localObject22)
            {
              i4 = localObject19[localObject11];
              i5 = i3 % 5;
              switch (i5)
              {
              default:
                i5 = i;
                int i6 = (char)(i4 ^ i5);
                localObject19[localObject11] = i4;
                localObject12 = i3 + 1;
                if (localObject22 != 0)
                  break;
                localObject19 = localObject21;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject19 = localObject22;
            Object localObject29 = localObject21;
            localObject21 = localObject12;
            localObject13 = localObject29;
          }
          while (true)
          {
            if (localObject19 <= localObject21);
            String str = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            g = arrayOfString;
            return;
            i4 = 125;
            break label115:
            i4 = k;
            break label115:
            i4 = 89;
            break label115:
            i4 = j;
            break label115:
            i4 = 125;
            break label295:
            i4 = k;
            break label295:
            i4 = 89;
            break label295:
            i4 = j;
            break label295:
            i5 = 125;
            break label475:
            i5 = k;
            break label475:
            i5 = 89;
            break label475:
            i5 = j;
            break label475:
            i5 = 125;
            break label659:
            i5 = k;
            break label659:
            i5 = 89;
            break label659:
            i5 = j;
            break label659:
            localObject21 = localObject1;
          }
          localObject21 = localObject1;
        }
        localObject19 = localObject1;
      }
      Object localObject19 = localObject1;
    }
  }

  public p(av paramav)
  {
    ag localag = ag.b(p.class);
    this.b = localag;
    Context localContext = ((aq)paramav).a();
    this.c = localContext;
    az localaz = az.c;
    this.f = localaz;
    if (i == 0)
      return;
    int j = bf.d;
    ++i;
    bf.d = j;
  }

  static ag a(p paramp)
  {
    return paramp.b;
  }

  static az a(p paramp, az paramaz)
  {
    paramp.f = paramaz;
    return paramaz;
  }

  static az b(p paramp)
  {
    return paramp.f;
  }

  static void c(p paramp)
  {
    paramp.a();
  }

  public s a(av paramav)
  {
    return new p(paramav);
  }

  public void b()
  {
    if (this.e != null)
    {
      ag localag = this.b;
      String str1 = g[null];
      localag.b(str1);
    }
    while (true)
    {
      return;
      ai localai = new ai(this);
      this.e = localai;
      az localaz = az.c;
      this.f = localaz;
      String str2 = g[1];
      IntentFilter localIntentFilter = new IntentFilter(str2);
      Context localContext = this.c;
      BroadcastReceiver localBroadcastReceiver = this.e;
      localContext.registerReceiver(localBroadcastReceiver, localIntentFilter);
    }
  }

  /** @deprecated */
  public az c()
  {
    monitorenter;
    try
    {
      az localaz = this.f;
      monitorexit;
      return localaz;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  public void d()
  {
    int i = 0;
    Object localObject1 = this.e;
    if (localObject1 == null)
    {
      ag localag1 = this.b;
      String str1 = g[2];
      localag1.b(str1);
    }
    while (true)
    {
      return;
      try
      {
        localObject1 = this.c;
        BroadcastReceiver localBroadcastReceiver = this.e;
        ((Context)localObject1).unregisterReceiver(localBroadcastReceiver);
      }
      catch (Throwable localThrowable)
      {
        az localaz1;
        ag localag2 = this.b;
        String str2 = g[3];
        localag2.a(str2, localThrowable);
      }
      finally
      {
        az localaz2;
        this.e = i;
        az localaz3 = az.c;
        this.f = localaz3;
      }
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.p
 * JD-Core Version:    0.5.4
 */