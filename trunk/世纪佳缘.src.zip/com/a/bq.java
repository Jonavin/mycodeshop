package com.a;

import java.io.File;

final class bq
{
  private static final String[] a;
  private static final char[] b;
  private static int c;
  private static File d;
  private static long e;
  private static ba f;

  static
  {
    int i = 90;
    int j = 23;
    int k = 2;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "Qfv.\002Qqn)\027\033o86\f\035cc3\f\020-o*\020Qq|#\013\021m|\026\f\031,t5\r\030".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject15;
    int i1;
    Object localObject9;
    Object localObject14;
    int i2;
    int i3;
    label116: Object localObject3;
    if (localObject8 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject15 = localObject8;
      i1 = arrayOfChar2;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject14 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject15)
      {
        i2 = localObject9[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 99;
          i2 = (char)(i2 ^ i3);
          localObject9[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject15 != 0)
            break;
          localObject9 = localObject14;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject15;
      Object localObject16 = localObject14;
      localObject14 = localObject2;
      localObject3 = localObject16;
    }
    while (true)
    {
      if (localObject9 <= localObject14);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "P-d1\032\026mx1/\021e99\f\020d".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label296: Object localObject5;
      if (localObject10 <= l)
      {
        localObject14 = localObject1;
        localObject15 = localObject10;
        i1 = localObject14;
        localObject11 = localObject3;
        Object localObject17 = localObject14;
        localObject14 = localObject3;
        Object localObject4;
        for (localObject3 = localObject17; ; localObject4 = localObject15)
        {
          i2 = localObject11[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 99;
            i2 = (char)(i2 ^ i3);
            localObject11[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject15 != 0)
              break;
            localObject11 = localObject14;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject15;
        Object localObject18 = localObject14;
        localObject14 = localObject4;
        localObject5 = localObject18;
      }
      while (true)
      {
        if (localObject11 <= localObject14);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        localObject5 = "Qqs9\002\ff8)\b\007jx5\b2mpt纮\021l".toCharArray();
        Object localObject12 = localObject5.length;
        Object localObject13;
        label476: Object localObject7;
        if (localObject12 <= l)
        {
          localObject14 = localObject1;
          localObject15 = localObject12;
          i1 = localObject14;
          localObject13 = localObject5;
          Object localObject19 = localObject14;
          localObject14 = localObject5;
          Object localObject6;
          for (localObject5 = localObject19; ; localObject6 = localObject15)
          {
            i2 = localObject13[localObject5];
            i3 = i1 % 5;
            switch (i3)
            {
            default:
              i3 = 99;
              int i4 = (char)(i2 ^ i3);
              localObject13[localObject5] = i2;
              localObject6 = i1 + 1;
              if (localObject15 != 0)
                break;
              localObject13 = localObject14;
              i1 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject13 = localObject15;
          Object localObject20 = localObject14;
          localObject14 = localObject6;
          localObject7 = localObject20;
        }
        while (true)
        {
          if (localObject13 <= localObject14);
          String str = new String(localObject7).intern();
          arrayOfString[k] = localObject7;
          a = arrayOfString;
          b = new char[32];
          c = localObject1;
          d = null;
          e = 0L;
          f = null;
          return;
          i3 = 126;
          break label116:
          i3 = k;
          break label116:
          i3 = j;
          break label116:
          i3 = i;
          break label116:
          i3 = 126;
          break label296:
          i3 = k;
          break label296:
          i3 = j;
          break label296:
          i3 = i;
          break label296:
          i3 = 126;
          break label476:
          i3 = k;
          break label476:
          i3 = j;
          break label476:
          i3 = i;
          break label476:
          localObject14 = localObject1;
        }
        localObject14 = localObject1;
      }
      localObject14 = localObject1;
    }
  }

  static boolean a(ba paramba)
  {
    return b(paramba);
  }

  /** @deprecated */
  // ERROR //
  private static final boolean b(ba paramba)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: ldc 2
    //   6: astore_3
    //   7: aload_3
    //   8: monitorenter
    //   9: getstatic 44	com/a/bq:c	I
    //   12: istore 4
    //   14: iload 4
    //   16: iconst_1
    //   17: iadd
    //   18: istore 5
    //   20: iload 5
    //   22: putstatic 44	com/a/bq:c	I
    //   25: iload 4
    //   27: sipush 1023
    //   30: iand
    //   31: istore 4
    //   33: iload 4
    //   35: ifne +105 -> 140
    //   38: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   41: astore 4
    //   43: aload 4
    //   45: ifnonnull +54 -> 99
    //   48: getstatic 40	com/a/bq:a	[Ljava/lang/String;
    //   51: astore 4
    //   53: aload 4
    //   55: arraylength
    //   56: istore 5
    //   58: aload_2
    //   59: astore 6
    //   61: aload 6
    //   63: iload 5
    //   65: if_icmpge +34 -> 99
    //   68: aload 4
    //   70: aload 6
    //   72: aaload
    //   73: astore 7
    //   75: new 59	java/io/File
    //   78: dup
    //   79: aload 7
    //   81: invokespecial 62	java/io/File:<init>	(Ljava/lang/String;)V
    //   84: astore 8
    //   86: aload 8
    //   88: invokevirtual 66	java/io/File:exists	()Z
    //   91: ifeq +81 -> 172
    //   94: aload 8
    //   96: putstatic 46	com/a/bq:d	Ljava/io/File;
    //   99: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   102: astore 4
    //   104: aload 4
    //   106: ifnull +34 -> 140
    //   109: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   112: invokevirtual 66	java/io/File:exists	()Z
    //   115: astore 4
    //   117: iload 4
    //   119: ifne +59 -> 178
    //   122: aconst_null
    //   123: putstatic 46	com/a/bq:d	Ljava/io/File;
    //   126: ldc2_w 47
    //   129: putstatic 50	com/a/bq:e	J
    //   132: aconst_null
    //   133: istore 4
    //   135: aload 4
    //   137: putstatic 52	com/a/bq:f	Lcom/a/ba;
    //   140: getstatic 52	com/a/bq:f	Lcom/a/ba;
    //   143: astore 4
    //   145: aload 4
    //   147: ifnull +203 -> 350
    //   150: getstatic 52	com/a/bq:f	Lcom/a/ba;
    //   153: aload_0
    //   154: invokevirtual 72	com/a/ba:compareTo	(Ljava/lang/Enum;)I
    //   157: astore 4
    //   159: iload 4
    //   161: ifgt +183 -> 344
    //   164: iconst_1
    //   165: istore 4
    //   167: aload_3
    //   168: monitorexit
    //   169: aload 4
    //   171: ireturn
    //   172: iinc 6 1
    //   175: goto -114 -> 61
    //   178: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   181: invokevirtual 76	java/io/File:lastModified	()J
    //   184: astore 4
    //   186: getstatic 50	com/a/bq:e	J
    //   189: lstore 9
    //   191: lload 11
    //   193: lload 9
    //   195: lcmp
    //   196: lstore 11
    //   198: iload 4
    //   200: ifle -60 -> 140
    //   203: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   206: invokevirtual 76	java/io/File:lastModified	()J
    //   209: astore 4
    //   211: lload 11
    //   213: putstatic 50	com/a/bq:e	J
    //   216: getstatic 46	com/a/bq:d	Ljava/io/File;
    //   219: astore 5
    //   221: new 78	java/io/FileReader
    //   224: dup
    //   225: aload 5
    //   227: invokespecial 81	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   230: astore 4
    //   232: getstatic 42	com/a/bq:b	[C
    //   235: astore 5
    //   237: aload 4
    //   239: aload 5
    //   241: invokevirtual 85	java/io/FileReader:read	([C)I
    //   244: astore 5
    //   246: iload 5
    //   248: ifle +30 -> 278
    //   251: getstatic 42	com/a/bq:b	[C
    //   254: astore 13
    //   256: new 20	java/lang/String
    //   259: dup
    //   260: aload 13
    //   262: aconst_null
    //   263: iload 5
    //   265: invokespecial 88	java/lang/String:<init>	([CII)V
    //   268: invokestatic 92	com/a/ba:valueOf	(Ljava/lang/String;)Lcom/a/ba;
    //   271: astore 5
    //   273: aload 5
    //   275: putstatic 52	com/a/bq:f	Lcom/a/ba;
    //   278: aload 4
    //   280: ifnull -140 -> 140
    //   283: aload 4
    //   285: invokevirtual 95	java/io/FileReader:close	()V
    //   288: goto -148 -> 140
    //   291: astore 4
    //   293: goto -153 -> 140
    //   296: astore 4
    //   298: aload_1
    //   299: astore 4
    //   301: aload 4
    //   303: ifnull -163 -> 140
    //   306: aload 4
    //   308: invokevirtual 95	java/io/FileReader:close	()V
    //   311: goto -171 -> 140
    //   314: astore 4
    //   316: goto -176 -> 140
    //   319: astore 4
    //   321: aload_1
    //   322: astore 5
    //   324: aload 5
    //   326: ifnull +8 -> 334
    //   329: aload 5
    //   331: invokevirtual 95	java/io/FileReader:close	()V
    //   334: aload 4
    //   336: athrow
    //   337: astore 14
    //   339: aload_3
    //   340: monitorexit
    //   341: aload 14
    //   343: athrow
    //   344: aload_2
    //   345: astore 4
    //   347: goto -180 -> 167
    //   350: aload_2
    //   351: astore 4
    //   353: goto -186 -> 167
    //   356: astore 15
    //   358: goto -24 -> 334
    //   361: astore 16
    //   363: aload 4
    //   365: astore 5
    //   367: aload 16
    //   369: astore 4
    //   371: goto -47 -> 324
    //   374: astore 17
    //   376: goto -75 -> 301
    //
    // Exception table:
    //   from	to	target	type
    //   283	288	291	java/lang/Throwable
    //   216	232	296	java/lang/Throwable
    //   306	311	314	java/lang/Throwable
    //   216	232	319	finally
    //   9	159	337	finally
    //   178	216	337	finally
    //   283	288	337	finally
    //   306	311	337	finally
    //   329	334	337	finally
    //   334	337	337	finally
    //   329	334	356	java/lang/Throwable
    //   232	278	361	finally
    //   232	278	374	java/lang/Throwable
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bq
 * JD-Core Version:    0.5.4
 */