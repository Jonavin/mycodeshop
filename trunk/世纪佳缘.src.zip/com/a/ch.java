package com.a;

import java.util.ArrayList;
import java.util.List;

public class ch
  implements ac
{
  private ArrayList a;

  public ch(ao[] paramArrayOfao)
  {
    int j = paramArrayOfao.length;
    ArrayList localArrayList = new ArrayList(j);
    this.a = localArrayList;
    int k = paramArrayOfao.length;
    Object localObject = null;
    ao localao;
    if (localObject < k)
    {
      localao = paramArrayOfao[localObject];
      if (localao != null)
        break label57;
    }
    while (true)
    {
      ++localObject;
      if (i != 0);
      return;
      label57: localao.a(this);
    }
  }

  /** @deprecated */
  public List a(long paramLong)
  {
    monitorenter;
    try
    {
      boolean bool = this.a.isEmpty();
      if (bool)
        super.wait(paramLong);
      ArrayList localArrayList1 = this.a;
      ArrayList localArrayList2 = new ArrayList();
      this.a = localArrayList2;
      monitorexit;
      return localArrayList1;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  /** @deprecated */
  public void a(ao paramao)
  {
    monitorenter;
    try
    {
      if (!this.a.contains(paramao))
        this.a.add(paramao);
      super.notifyAll();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ch
 * JD-Core Version:    0.5.4
 */