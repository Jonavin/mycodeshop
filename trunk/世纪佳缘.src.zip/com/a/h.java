package com.a;

import java.io.Serializable;

public abstract class h
  implements Serializable, Comparable
{
  public static int a;
  private static h c;
  private static final String d;
  private long b;

  static
  {
    int i = 111;
    char[] arrayOfChar1 = "\fx(Q\033Oj#\002O\037k)\002纮\033`6\023".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int j;
    Object localObject3;
    char[] arrayOfChar4;
    int k;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      j = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      k = localObject3[arrayOfChar1];
      l = j % 5;
      switch (l)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int l = i; ; l = 118)
      while (true)
      {
        int i1 = (char)(k ^ l);
        localObject3[arrayOfChar1] = k;
        char[] arrayOfChar2 = j + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          j = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        d = new String(localObject1).intern();
        c = null;
        return;
        l = i;
        continue;
        l = 25;
        continue;
        l = 70;
      }
  }

  protected h()
  {
    long l = a();
    Object localObject;
    this.b = localObject;
  }

  public static final h a(long paramLong)
  {
    h localh = d();
    long l = localh.b - paramLong;
    localh.b = l;
    return localh;
  }

  public static final h d()
  {
    Object localObject = c;
    if (localObject == null);
    for (localObject = new e(); ; localObject = c.b())
      return localObject;
  }

  protected abstract long a();

  public long a(h paramh)
  {
    return paramh.b(this);
  }

  public long b(h paramh)
  {
    long l1 = this.b;
    long l2 = paramh.b;
    return l1 - l2;
  }

  protected abstract h b();

  public int c(h paramh)
  {
    long l1 = this.b;
    long l2 = paramh.b;
    l1 <= l2;
    int i;
    if (i > 0)
      i = -1;
    while (true)
    {
      return i;
      l1 = this.b;
      long l3 = paramh.b;
      l1 <= l3;
      if (i < 0)
        i = 1;
      Object localObject = null;
    }
  }

  public long c()
  {
    long l1 = a();
    long l2 = this.b;
    Object localObject;
    return localObject - l2;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      try
      {
        long l1 = this.b;
        long l2 = ((h)paramObject).b;
        l1 <= l2;
        if (localObject2 == 0)
          int i = 1;
        Object localObject3 = localObject1;
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    return (int)this.b;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.h
 * JD-Core Version:    0.5.4
 */