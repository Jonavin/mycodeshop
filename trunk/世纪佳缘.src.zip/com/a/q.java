package com.a;

import com.a.a.bd;
import java.io.InterruptedIOException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

final class q extends v
{
  private static final DefaultHttpClient d;
  private static final String[] e;
  private HttpUriRequest c = null;

  static
  {
    int i = 54;
    int j = 47;
    int k = 26;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[11];
    char[] arrayOfChar1 = "Y\036X[\031t\005\033{\005j\024".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject48;
    Object localObject50;
    Object localObject7;
    Object localObject29;
    int i2;
    int i11;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject28 = localObject1;
      localObject48 = localObject6;
      localObject50 = localObject28;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject28;
      localObject29 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject48)
      {
        i2 = localObject7[arrayOfChar1];
        i11 = localObject50 % 5;
        switch (i11)
        {
        default:
          i11 = 124;
          i2 = (char)(i2 ^ i11);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject50 + 1;
          if (localObject48 != 0)
            break;
          localObject7 = localObject29;
          localObject50 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject48;
      Object localObject51 = localObject29;
      localObject29 = localObject2;
      localObject3 = localObject51;
    }
    while (true)
    {
      if (localObject7 <= localObject29);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "n\024N[Sb\034Z".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject29 = localObject1;
        localObject48 = localObject8;
        localObject50 = localObject29;
        localObject9 = localObject3;
        Object localObject52 = localObject29;
        localObject29 = localObject3;
        Object localObject4;
        for (localObject3 = localObject52; ; localObject4 = localObject48)
        {
          i2 = localObject9[localObject3];
          i11 = localObject50 % 5;
          switch (i11)
          {
          default:
            i11 = 124;
            i2 = (char)(i2 ^ i11);
            localObject9[localObject3] = i2;
            localObject4 = localObject50 + 1;
            if (localObject48 != 0)
              break;
            localObject9 = localObject29;
            localObject50 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject48;
        Object localObject53 = localObject29;
        localObject29 = localObject4;
        localObject5 = localObject53;
      }
      while (true)
      {
        if (localObject9 <= localObject29);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "M!e\017=J8\026\007".toCharArray();
        Object localObject30 = localObject9.length;
        Object localObject31;
        Object localObject49;
        int i12;
        label480: Object localObject11;
        if (localObject30 <= l)
        {
          localObject48 = localObject1;
          localObject50 = localObject30;
          i2 = localObject48;
          localObject31 = localObject9;
          Object localObject54 = localObject48;
          localObject49 = localObject9;
          Object localObject10;
          for (localObject9 = localObject54; ; localObject10 = localObject50)
          {
            i11 = localObject31[localObject9];
            i12 = i2 % 5;
            switch (i12)
            {
            default:
              i12 = 124;
              i11 = (char)(i11 ^ i12);
              localObject31[localObject9] = i11;
              localObject10 = i2 + 1;
              if (localObject50 != 0)
                break;
              localObject31 = localObject49;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject31 = localObject50;
          Object localObject55 = localObject49;
          localObject49 = localObject10;
          localObject11 = localObject55;
        }
        while (true)
        {
          if (localObject31 <= localObject49);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "r\020R\017\f\037RF\022}Q_A\b\003DZ\fn".toCharArray();
          Object localObject32 = localObject11.length;
          Object localObject33;
          label664: Object localObject13;
          if (localObject32 <= l)
          {
            localObject49 = localObject1;
            localObject50 = localObject32;
            int i3 = localObject49;
            localObject33 = localObject11;
            Object localObject56 = localObject49;
            localObject49 = localObject11;
            Object localObject12;
            for (localObject11 = localObject56; ; localObject12 = localObject50)
            {
              i11 = localObject33[localObject11];
              i12 = i3 % 5;
              switch (i12)
              {
              default:
                i12 = 124;
                i11 = (char)(i11 ^ i12);
                localObject33[localObject11] = i11;
                localObject12 = i3 + 1;
                if (localObject50 != 0)
                  break;
                localObject33 = localObject49;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject33 = localObject50;
            Object localObject57 = localObject49;
            localObject49 = localObject12;
            localObject13 = localObject57;
          }
          while (true)
          {
            if (localObject33 <= localObject49);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "O\002S]Q[\026SA\b".toCharArray();
            Object localObject34 = localObject13.length;
            Object localObject35;
            label848: Object localObject15;
            if (localObject34 <= l)
            {
              localObject49 = localObject1;
              localObject50 = localObject34;
              int i4 = localObject49;
              localObject35 = localObject13;
              Object localObject58 = localObject49;
              localObject49 = localObject13;
              Object localObject14;
              for (localObject13 = localObject58; ; localObject14 = localObject50)
              {
                i11 = localObject35[localObject13];
                i12 = i4 % 5;
                switch (i12)
                {
                default:
                  i12 = 124;
                  i11 = (char)(i11 ^ i12);
                  localObject35[localObject13] = i11;
                  localObject14 = i4 + 1;
                  if (localObject50 != 0)
                    break;
                  localObject35 = localObject49;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject35 = localObject50;
              Object localObject59 = localObject49;
              localObject49 = localObject14;
              localObject15 = localObject59;
            }
            while (true)
            {
              if (localObject35 <= localObject49);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "h\024GZ\031i\005\026[\023u\032\026".toCharArray();
              Object localObject36 = localObject15.length;
              Object localObject37;
              label1032: Object localObject17;
              if (localObject36 <= l)
              {
                localObject49 = localObject1;
                localObject50 = localObject36;
                int i5 = localObject49;
                localObject37 = localObject15;
                Object localObject60 = localObject49;
                localObject49 = localObject15;
                Object localObject16;
                for (localObject15 = localObject60; ; localObject16 = localObject50)
                {
                  i11 = localObject37[localObject15];
                  i12 = i5 % 5;
                  switch (i12)
                  {
                  default:
                    i12 = 124;
                    i11 = (char)(i11 ^ i12);
                    localObject37[localObject15] = i11;
                    localObject16 = i5 + 1;
                    if (localObject50 != 0)
                      break;
                    localObject37 = localObject49;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject37 = localObject50;
                Object localObject61 = localObject49;
                localObject49 = localObject16;
                localObject17 = localObject61;
              }
              while (true)
              {
                if (localObject37 <= localObject49);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "XQ".toCharArray();
                Object localObject38 = localObject17.length;
                Object localObject39;
                label1216: Object localObject19;
                if (localObject38 <= l)
                {
                  localObject49 = localObject1;
                  localObject50 = localObject38;
                  int i6 = localObject49;
                  localObject39 = localObject17;
                  Object localObject62 = localObject49;
                  localObject49 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject62; ; localObject18 = localObject50)
                  {
                    i11 = localObject39[localObject17];
                    i12 = i6 % 5;
                    switch (i12)
                    {
                    default:
                      i12 = 124;
                      i11 = (char)(i11 ^ i12);
                      localObject39[localObject17] = i11;
                      localObject18 = i6 + 1;
                      if (localObject50 != 0)
                        break;
                      localObject39 = localObject49;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject39 = localObject50;
                  Object localObject63 = localObject49;
                  localObject49 = localObject18;
                  localObject19 = localObject63;
                }
                while (true)
                {
                  if (localObject39 <= localObject49);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  i1 = 7;
                  localObject19 = "X\001E".toCharArray();
                  Object localObject40 = localObject19.length;
                  Object localObject41;
                  label1400: Object localObject21;
                  if (localObject40 <= l)
                  {
                    localObject49 = localObject1;
                    localObject50 = localObject40;
                    int i7 = localObject49;
                    localObject41 = localObject19;
                    Object localObject64 = localObject49;
                    localObject49 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject64; ; localObject20 = localObject50)
                    {
                      i11 = localObject41[localObject19];
                      i12 = i7 % 5;
                      switch (i12)
                      {
                      default:
                        i12 = 124;
                        i11 = (char)(i11 ^ i12);
                        localObject41[localObject19] = i11;
                        localObject20 = i7 + 1;
                        if (localObject50 != 0)
                          break;
                        localObject41 = localObject49;
                        i7 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject41 = localObject50;
                    Object localObject65 = localObject49;
                    localObject49 = localObject20;
                    localObject21 = localObject65;
                  }
                  while (true)
                  {
                    if (localObject41 <= localObject49);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i1] = localObject21;
                    i1 = 8;
                    localObject21 = "w\002\026".toCharArray();
                    Object localObject42 = localObject21.length;
                    Object localObject43;
                    label1584: Object localObject23;
                    if (localObject42 <= l)
                    {
                      localObject49 = localObject1;
                      localObject50 = localObject42;
                      int i8 = localObject49;
                      localObject43 = localObject21;
                      Object localObject66 = localObject49;
                      localObject49 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject66; ; localObject22 = localObject50)
                      {
                        i11 = localObject43[localObject21];
                        i12 = i8 % 5;
                        switch (i12)
                        {
                        default:
                          i12 = 124;
                          i11 = (char)(i11 ^ i12);
                          localObject43[localObject21] = i11;
                          localObject22 = i8 + 1;
                          if (localObject50 != 0)
                            break;
                          localObject43 = localObject49;
                          i8 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject43 = localObject50;
                      Object localObject67 = localObject49;
                      localObject49 = localObject22;
                      localObject23 = localObject67;
                    }
                    while (true)
                    {
                      if (localObject43 <= localObject49);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i1] = localObject23;
                      i1 = 9;
                      localObject23 = "r\005B_\017".toCharArray();
                      Object localObject44 = localObject23.length;
                      Object localObject45;
                      label1768: Object localObject25;
                      if (localObject44 <= l)
                      {
                        localObject49 = localObject1;
                        localObject50 = localObject44;
                        int i9 = localObject49;
                        localObject45 = localObject23;
                        Object localObject68 = localObject49;
                        localObject49 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject68; ; localObject24 = localObject50)
                        {
                          i11 = localObject45[localObject23];
                          i12 = i9 % 5;
                          switch (i12)
                          {
                          default:
                            i12 = 124;
                            i11 = (char)(i11 ^ i12);
                            localObject45[localObject23] = i11;
                            localObject24 = i9 + 1;
                            if (localObject50 != 0)
                              break;
                            localObject45 = localObject49;
                            i9 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject45 = localObject50;
                        Object localObject69 = localObject49;
                        localObject49 = localObject24;
                        localObject25 = localObject69;
                      }
                      while (true)
                      {
                        if (localObject45 <= localObject49);
                        localObject25 = new String(localObject25).intern();
                        arrayOfString[i1] = localObject25;
                        i1 = 10;
                        localObject25 = "r\005B_".toCharArray();
                        Object localObject46 = localObject25.length;
                        label1952: Object localObject27;
                        if (localObject46 <= l)
                        {
                          localObject49 = localObject1;
                          localObject50 = localObject46;
                          int i10 = localObject49;
                          localObject47 = localObject25;
                          Object localObject70 = localObject49;
                          localObject49 = localObject25;
                          Object localObject26;
                          for (localObject25 = localObject70; ; localObject26 = localObject50)
                          {
                            i11 = localObject47[localObject25];
                            i12 = i10 % 5;
                            switch (i12)
                            {
                            default:
                              i12 = 124;
                              int i13 = (char)(i11 ^ i12);
                              localObject47[localObject25] = i11;
                              localObject26 = i10 + 1;
                              if (localObject50 != 0)
                                break;
                              localObject47 = localObject49;
                              i10 = localObject26;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject47 = localObject50;
                          Object localObject71 = localObject49;
                          localObject49 = localObject26;
                          localObject27 = localObject71;
                        }
                        while (true)
                        {
                          if (localObject47 <= localObject49);
                          String str1 = new String(localObject27).intern();
                          arrayOfString[i1] = localObject27;
                          e = arrayOfString;
                          BasicHttpParams localBasicHttpParams = new BasicHttpParams();
                          HttpConnectionParams.setConnectionTimeout(arrayOfString, 30000);
                          HttpConnectionParams.setSoTimeout(arrayOfString, 30000);
                          SSLSocketFactory localSSLSocketFactory = SSLSocketFactory.getSocketFactory();
                          X509HostnameVerifier localX509HostnameVerifier = SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
                          i1.setHostnameVerifier(localObject27);
                          SchemeRegistry localSchemeRegistry = new SchemeRegistry();
                          String str2 = e[10];
                          PlainSocketFactory localPlainSocketFactory = PlainSocketFactory.getSocketFactory();
                          Scheme localScheme1 = new Scheme(str2, localPlainSocketFactory, 80);
                          localObject27.register(localScheme1);
                          String str3 = e[9];
                          Scheme localScheme2 = new Scheme(str3, i1, 443);
                          localObject27.register(localScheme2);
                          ThreadSafeClientConnManager localThreadSafeClientConnManager = new ThreadSafeClientConnManager(arrayOfString, localObject27);
                          d = new DefaultHttpClient(i1, arrayOfString);
                          return;
                          i11 = k;
                          break label116:
                          i11 = 113;
                          break label116:
                          i11 = i;
                          break label116:
                          i11 = j;
                          break label116:
                          i11 = k;
                          break label296:
                          i11 = 113;
                          break label296:
                          i11 = i;
                          break label296:
                          i11 = j;
                          break label296:
                          i12 = k;
                          break label480:
                          i12 = 113;
                          break label480:
                          i12 = i;
                          break label480:
                          i12 = j;
                          break label480:
                          i12 = k;
                          break label664:
                          i12 = 113;
                          break label664:
                          i12 = i;
                          break label664:
                          i12 = j;
                          break label664:
                          i12 = k;
                          break label848:
                          i12 = 113;
                          break label848:
                          i12 = i;
                          break label848:
                          i12 = j;
                          break label848:
                          i12 = k;
                          break label1032:
                          i12 = 113;
                          break label1032:
                          i12 = i;
                          break label1032:
                          i12 = j;
                          break label1032:
                          i12 = k;
                          break label1216:
                          i12 = 113;
                          break label1216:
                          i12 = i;
                          break label1216:
                          i12 = j;
                          break label1216:
                          i12 = k;
                          break label1400:
                          i12 = 113;
                          break label1400:
                          i12 = i;
                          break label1400:
                          i12 = j;
                          break label1400:
                          i12 = k;
                          break label1584:
                          i12 = 113;
                          break label1584:
                          i12 = i;
                          break label1584:
                          i12 = j;
                          break label1584:
                          i12 = k;
                          break label1768:
                          i12 = 113;
                          break label1768:
                          i12 = i;
                          break label1768:
                          i12 = j;
                          break label1768:
                          i12 = k;
                          break label1952:
                          i12 = 113;
                          break label1952:
                          i12 = i;
                          break label1952:
                          i12 = j;
                          break label1952:
                          localObject49 = localObject1;
                        }
                        localObject49 = localObject1;
                      }
                      localObject49 = localObject1;
                    }
                    localObject49 = localObject1;
                  }
                  localObject49 = localObject1;
                }
                localObject49 = localObject1;
              }
              localObject49 = localObject1;
            }
            localObject49 = localObject1;
          }
          localObject49 = localObject1;
        }
        localObject47 = localObject1;
      }
      Object localObject47 = localObject1;
    }
  }

  private void a(HttpEntity paramHttpEntity1, HttpEntity paramHttpEntity2, long paramLong)
  {
    long l1 = 0L;
    long l2;
    label13: long l3;
    if (paramHttpEntity1 == null)
    {
      l2 = l1;
      l3 = l2 < l1;
      int i;
      if (i <= 0)
        break label225;
      l3 = l1 + l2;
    }
    while (true)
    {
      long l4;
      if (paramHttpEntity2 == null)
        l4 = l1;
      while (true)
      {
        if (l4 > l1)
          l3 += l4;
        float f1 = (float)l3 * 1148846080;
        float f2 = (float)paramLong;
        int j = Math.round(f1 / f2);
        ag localag = a;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str1 = e[5];
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(paramLong);
        String str2 = e[8];
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(l2).append("+").append(l4).append("=").append(l3);
        String str3 = e[6];
        StringBuilder localStringBuilder4 = ((StringBuilder)localObject).append(str3).append(j);
        String str4 = e[7];
        String str5 = str4;
        localag.b((String)localObject);
        return;
        Object localObject = paramHttpEntity1.getContentLength();
        break label13:
        long l5 = paramHttpEntity2.getContentLength();
      }
      label225: l3 = l1;
    }
  }

  public aa a(String paramString)
  {
    int i = v.b;
    boolean bool = Thread.interrupted();
    if (bool)
    {
      String str1 = e[3];
      throw new InterruptedIOException(str1);
    }
    Object localObject2 = new HttpGet(paramString);
    Object localObject3 = e[4];
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str2 = e[2];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str2);
    String str3 = bd.c();
    String str4 = str3 + ")";
    ((HttpGet)localObject2).setHeader((String)localObject3, str4);
    monitorenter;
    try
    {
      this.c = ((HttpUriRequest)localObject2);
      monitorexit;
      localObject3 = h.d();
      localObject2 = d.execute((HttpUriRequest)localObject2);
      if (a.a())
      {
        HttpEntity localHttpEntity = ((HttpResponse)localObject2).getEntity();
        long l = ((h)localObject3).c();
        Object localObject4;
        a(null, localHttpEntity, localObject4);
      }
      localObject3 = new w((HttpResponse)localObject2);
      if (bf.d != 0);
      return localObject3;
    }
    finally
    {
      monitorexit;
    }
  }

  public aa a(String paramString1, String paramString2)
  {
    int i = v.b;
    boolean bool = Thread.interrupted();
    if (bool)
    {
      String str1 = e[3];
      throw new InterruptedIOException(str1);
    }
    Object localObject2 = new HttpPost(paramString1);
    Object localObject3 = new StringEntity(paramString2);
    ((HttpPost)localObject2).setEntity((HttpEntity)localObject3);
    Object localObject4 = e[4];
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str2 = e[2];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str2);
    String str3 = bd.c();
    String str4 = str3 + ")";
    ((HttpPost)localObject2).setHeader((String)localObject4, str4);
    localObject4 = e[null];
    String str5 = e[1];
    ((HttpPost)localObject2).setHeader((String)localObject4, str5);
    monitorenter;
    try
    {
      this.c = ((HttpUriRequest)localObject2);
      monitorexit;
      localObject4 = h.d();
      localObject2 = d.execute((HttpUriRequest)localObject2);
      if (a.a())
      {
        HttpEntity localHttpEntity = ((HttpResponse)localObject2).getEntity();
        long l = ((h)localObject4).c();
        Object localObject5;
        a((HttpEntity)localObject3, localHttpEntity, localObject5);
      }
      localObject3 = new w((HttpResponse)localObject2);
      int j;
      if (i != 0)
      {
        j = bf.d;
        ++i;
      }
      return localObject3;
    }
    finally
    {
      monitorexit;
    }
  }

  public void a()
  {
    monitorenter;
    try
    {
      HttpUriRequest localHttpUriRequest = this.c;
      if (localHttpUriRequest != null)
      {
        localHttpUriRequest = this.c;
        localHttpUriRequest.abort();
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  protected v b()
  {
    return new q();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.q
 * JD-Core Version:    0.5.4
 */