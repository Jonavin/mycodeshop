package com.a;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import com.a.a.be;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public final class z extends bt
{
  public static boolean a;
  private static final String[] n;
  private final PhoneStateListener h;
  private final ag i;
  private final Context j;
  private final TelephonyManager k;
  private boolean l;
  private be m;

  static
  {
    int i1 = 46;
    int i2 = 35;
    int i3 = 18;
    int i4 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[14];
    char[] arrayOfChar1 = "s@GEY{J\rGS`CJDE{AM\031u]`wey^qoxuSzjxxM{sswFkp".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject60;
    Object localObject62;
    Object localObject7;
    Object localObject35;
    int i6;
    int i18;
    label116: Object localObject3;
    if (localObject6 <= i4)
    {
      Object localObject34 = localObject1;
      localObject60 = localObject6;
      localObject62 = localObject34;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject34;
      localObject35 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject60)
      {
        i6 = localObject7[arrayOfChar1];
        i18 = localObject62 % 5;
        switch (i18)
        {
        default:
          i18 = 54;
          i6 = (char)(i6 ^ i18);
          localObject7[arrayOfChar1] = i6;
          localObject2 = localObject62 + 1;
          if (localObject60 != 0)
            break;
          localObject7 = localObject35;
          localObject62 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject60;
      Object localObject63 = localObject35;
      localObject35 = localObject2;
      localObject3 = localObject63;
    }
    while (true)
    {
      if (localObject7 <= localObject35);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "vGPVT~KoXUsZJXXG^GVBw]".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= i4)
      {
        localObject35 = localObject1;
        localObject60 = localObject8;
        localObject62 = localObject35;
        localObject9 = localObject3;
        Object localObject64 = localObject35;
        localObject35 = localObject3;
        Object localObject4;
        for (localObject3 = localObject64; ; localObject4 = localObject60)
        {
          i6 = localObject9[localObject3];
          i18 = localObject62 % 5;
          switch (i18)
          {
          default:
            i18 = 54;
            i6 = (char)(i6 ^ i18);
            localObject9[localObject3] = i6;
            localObject4 = localObject62 + 1;
            if (localObject60 != 0)
              break;
            localObject9 = localObject35;
            localObject62 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject60;
        Object localObject65 = localObject35;
        localObject35 = localObject4;
        localObject5 = localObject65;
      }
      while (true)
      {
        if (localObject9 <= localObject35);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i4] = localObject5;
        int i5 = 2;
        localObject9 = "qAV[R|\tW\027R{]BUZw\016OXUsZJXX2[SSWfKP\r\026".toCharArray();
        Object localObject36 = localObject9.length;
        Object localObject37;
        Object localObject61;
        int i19;
        label480: Object localObject11;
        if (localObject36 <= i4)
        {
          localObject60 = localObject1;
          localObject62 = localObject36;
          i6 = localObject60;
          localObject37 = localObject9;
          Object localObject66 = localObject60;
          localObject61 = localObject9;
          Object localObject10;
          for (localObject9 = localObject66; ; localObject10 = localObject62)
          {
            i18 = localObject37[localObject9];
            i19 = i6 % 5;
            switch (i19)
            {
            default:
              i19 = 54;
              i18 = (char)(i18 ^ i19);
              localObject37[localObject9] = i18;
              localObject10 = i6 + 1;
              if (localObject62 != 0)
                break;
              localObject37 = localObject61;
              i6 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject37 = localObject62;
          Object localObject67 = localObject61;
          localObject61 = localObject10;
          localObject11 = localObject67;
        }
        while (true)
        {
          if (localObject37 <= localObject61);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i5] = localObject11;
          i5 = 3;
          localObject11 = "bFLYS".toCharArray();
          Object localObject38 = localObject11.length;
          Object localObject39;
          label664: Object localObject13;
          if (localObject38 <= i4)
          {
            localObject61 = localObject1;
            localObject62 = localObject38;
            int i7 = localObject61;
            localObject39 = localObject11;
            Object localObject68 = localObject61;
            localObject61 = localObject11;
            Object localObject12;
            for (localObject11 = localObject68; ; localObject12 = localObject62)
            {
              i18 = localObject39[localObject11];
              i19 = i7 % 5;
              switch (i19)
              {
              default:
                i19 = 54;
                i18 = (char)(i18 ^ i19);
                localObject39[localObject11] = i18;
                localObject12 = i7 + 1;
                if (localObject62 != 0)
                  break;
                localObject39 = localObject61;
                i7 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject39 = localObject62;
            Object localObject69 = localObject61;
            localObject61 = localObject12;
            localObject13 = localObject69;
          }
          while (true)
          {
            if (localObject39 <= localObject61);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i5] = localObject13;
            i5 = 4;
            localObject13 = "bFLYS2ZZGS2\023\003".toCharArray();
            Object localObject40 = localObject13.length;
            Object localObject41;
            label848: Object localObject15;
            if (localObject40 <= i4)
            {
              localObject61 = localObject1;
              localObject62 = localObject40;
              int i8 = localObject61;
              localObject41 = localObject13;
              Object localObject70 = localObject61;
              localObject61 = localObject13;
              Object localObject14;
              for (localObject13 = localObject70; ; localObject14 = localObject62)
              {
                i18 = localObject41[localObject13];
                i19 = i8 % 5;
                switch (i19)
                {
                default:
                  i19 = 54;
                  i18 = (char)(i18 ^ i19);
                  localObject41[localObject13] = i18;
                  localObject14 = i8 + 1;
                  if (localObject62 != 0)
                    break;
                  localObject41 = localObject61;
                  i8 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject41 = localObject62;
              Object localObject71 = localObject61;
              localObject61 = localObject14;
              localObject15 = localObject71;
            }
            while (true)
            {
              if (localObject41 <= localObject61);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i5] = localObject15;
              i5 = 5;
              localObject15 = "|A\003TRO\003DS`XJYQ2MF[Z".toCharArray();
              Object localObject42 = localObject15.length;
              Object localObject43;
              label1032: Object localObject17;
              if (localObject42 <= i4)
              {
                localObject61 = localObject1;
                localObject62 = localObject42;
                int i9 = localObject61;
                localObject43 = localObject15;
                Object localObject72 = localObject61;
                localObject61 = localObject15;
                Object localObject16;
                for (localObject15 = localObject72; ; localObject16 = localObject62)
                {
                  i18 = localObject43[localObject15];
                  i19 = i9 % 5;
                  switch (i19)
                  {
                  default:
                    i19 = 54;
                    i18 = (char)(i18 ^ i19);
                    localObject43[localObject15] = i18;
                    localObject16 = i9 + 1;
                    if (localObject62 != 0)
                      break;
                    localObject43 = localObject61;
                    i9 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject43 = localObject62;
                Object localObject73 = localObject61;
                localObject61 = localObject16;
                localObject17 = localObject73;
              }
              while (true)
              {
                if (localObject43 <= localObject61);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i5] = localObject17;
                i5 = 6;
                localObject17 = "{@UVZ{J\003TRO\003[YqOW^Y|".toCharArray();
                Object localObject44 = localObject17.length;
                Object localObject45;
                label1216: Object localObject19;
                if (localObject44 <= i4)
                {
                  localObject61 = localObject1;
                  localObject62 = localObject44;
                  int i10 = localObject61;
                  localObject45 = localObject17;
                  Object localObject74 = localObject61;
                  localObject61 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject74; ; localObject18 = localObject62)
                  {
                    i18 = localObject45[localObject17];
                    i19 = i10 % 5;
                    switch (i19)
                    {
                    default:
                      i19 = 54;
                      i18 = (char)(i18 ^ i19);
                      localObject45[localObject17] = i18;
                      localObject18 = i10 + 1;
                      if (localObject62 != 0)
                        break;
                      localObject45 = localObject61;
                      i10 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject45 = localObject62;
                  Object localObject75 = localObject61;
                  localObject61 = localObject18;
                  localObject19 = localObject75;
                }
                while (true)
                {
                  if (localObject45 <= localObject61);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i5] = localObject19;
                  i5 = 7;
                  localObject19 = "g@HYYe@\003TRO\003[YqOW^Y|".toCharArray();
                  Object localObject46 = localObject19.length;
                  Object localObject47;
                  label1400: Object localObject21;
                  if (localObject46 <= i4)
                  {
                    localObject61 = localObject1;
                    localObject62 = localObject46;
                    int i11 = localObject61;
                    localObject47 = localObject19;
                    Object localObject76 = localObject61;
                    localObject61 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject76; ; localObject20 = localObject62)
                    {
                      i18 = localObject47[localObject19];
                      i19 = i11 % 5;
                      switch (i19)
                      {
                      default:
                        i19 = 54;
                        i18 = (char)(i18 ^ i19);
                        localObject47[localObject19] = i18;
                        localObject20 = i11 + 1;
                        if (localObject62 != 0)
                          break;
                        localObject47 = localObject61;
                        i11 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject47 = localObject62;
                    Object localObject77 = localObject61;
                    localObject61 = localObject20;
                    localObject21 = localObject77;
                  }
                  while (true)
                  {
                    if (localObject47 <= localObject61);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i5] = localObject21;
                    i5 = 8;
                    localObject21 = "qJNV\026~A@VB{AM\r\026".toCharArray();
                    Object localObject48 = localObject21.length;
                    Object localObject49;
                    label1584: Object localObject23;
                    if (localObject48 <= i4)
                    {
                      localObject61 = localObject1;
                      localObject62 = localObject48;
                      int i12 = localObject61;
                      localObject49 = localObject21;
                      Object localObject78 = localObject61;
                      localObject61 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject78; ; localObject22 = localObject62)
                      {
                        i18 = localObject49[localObject21];
                        i19 = i12 % 5;
                        switch (i19)
                        {
                        default:
                          i19 = 54;
                          i18 = (char)(i18 ^ i19);
                          localObject49[localObject21] = i18;
                          localObject22 = i12 + 1;
                          if (localObject62 != 0)
                            break;
                          localObject49 = localObject61;
                          i12 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject49 = localObject62;
                      Object localObject79 = localObject61;
                      localObject61 = localObject22;
                      localObject23 = localObject79;
                    }
                    while (true)
                    {
                      if (localObject49 <= localObject61);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i5] = localObject23;
                      i5 = 9;
                      localObject23 = "uAW\027XwY\003[YqOW^Y|\016T__~K\003YYf\016WEWqEJYQ".toCharArray();
                      Object localObject50 = localObject23.length;
                      Object localObject51;
                      label1768: Object localObject25;
                      if (localObject50 <= i4)
                      {
                        localObject61 = localObject1;
                        localObject62 = localObject50;
                        int i13 = localObject61;
                        localObject51 = localObject23;
                        Object localObject80 = localObject61;
                        localObject61 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject80; ; localObject24 = localObject62)
                        {
                          i18 = localObject51[localObject23];
                          i19 = i13 % 5;
                          switch (i19)
                          {
                          default:
                            i19 = 54;
                            i18 = (char)(i18 ^ i19);
                            localObject51[localObject23] = i18;
                            localObject24 = i13 + 1;
                            if (localObject62 != 0)
                              break;
                            localObject51 = localObject61;
                            i13 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject51 = localObject62;
                        Object localObject81 = localObject61;
                        localObject61 = localObject24;
                        localObject25 = localObject81;
                      }
                      while (true)
                      {
                        if (localObject51 <= localObject61);
                        localObject25 = new String(localObject25).intern();
                        arrayOfString[i5] = localObject25;
                        i5 = 10;
                        localObject25 = "w@BUZwbLTWfGLYcbJBCSa".toCharArray();
                        Object localObject52 = localObject25.length;
                        Object localObject53;
                        label1952: Object localObject27;
                        if (localObject52 <= i4)
                        {
                          localObject61 = localObject1;
                          localObject62 = localObject52;
                          int i14 = localObject61;
                          localObject53 = localObject25;
                          Object localObject82 = localObject61;
                          localObject61 = localObject25;
                          Object localObject26;
                          for (localObject25 = localObject82; ; localObject26 = localObject62)
                          {
                            i18 = localObject53[localObject25];
                            i19 = i14 % 5;
                            switch (i19)
                            {
                            default:
                              i19 = 54;
                              i18 = (char)(i18 ^ i19);
                              localObject53[localObject25] = i18;
                              localObject26 = i14 + 1;
                              if (localObject62 != 0)
                                break;
                              localObject53 = localObject61;
                              i14 = localObject26;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject53 = localObject62;
                          Object localObject83 = localObject61;
                          localObject61 = localObject26;
                          localObject27 = localObject83;
                        }
                        while (true)
                        {
                          if (localObject53 <= localObject61);
                          localObject27 = new String(localObject27).intern();
                          arrayOfString[i5] = localObject27;
                          i5 = 11;
                          localObject27 = "qAV[R|\tW\027S|OA[S2BLTWfGLY\026g^GVBw]\031\027".toCharArray();
                          Object localObject54 = localObject27.length;
                          Object localObject55;
                          label2136: Object localObject29;
                          if (localObject54 <= i4)
                          {
                            localObject61 = localObject1;
                            localObject62 = localObject54;
                            int i15 = localObject61;
                            localObject55 = localObject27;
                            Object localObject84 = localObject61;
                            localObject61 = localObject27;
                            Object localObject28;
                            for (localObject27 = localObject84; ; localObject28 = localObject62)
                            {
                              i18 = localObject55[localObject27];
                              i19 = i15 % 5;
                              switch (i19)
                              {
                              default:
                                i19 = 54;
                                i18 = (char)(i18 ^ i19);
                                localObject55[localObject27] = i18;
                                localObject28 = i15 + 1;
                                if (localObject62 != 0)
                                  break;
                                localObject55 = localObject61;
                                i15 = localObject28;
                              case 0:
                              case 1:
                              case 2:
                              case 3:
                              }
                            }
                            localObject55 = localObject62;
                            Object localObject85 = localObject61;
                            localObject61 = localObject28;
                            localObject29 = localObject85;
                          }
                          while (true)
                          {
                            if (localObject55 <= localObject61);
                            localObject29 = new String(localObject29).intern();
                            arrayOfString[i5] = localObject29;
                            i5 = 12;
                            localObject29 = "~A@VB{AM\027CbJBCSa\016FYWpBFS".toCharArray();
                            Object localObject56 = localObject29.length;
                            Object localObject57;
                            label2320: Object localObject31;
                            if (localObject56 <= i4)
                            {
                              localObject61 = localObject1;
                              localObject62 = localObject56;
                              int i16 = localObject61;
                              localObject57 = localObject29;
                              Object localObject86 = localObject61;
                              localObject61 = localObject29;
                              Object localObject30;
                              for (localObject29 = localObject86; ; localObject30 = localObject62)
                              {
                                i18 = localObject57[localObject29];
                                i19 = i16 % 5;
                                switch (i19)
                                {
                                default:
                                  i19 = 54;
                                  i18 = (char)(i18 ^ i19);
                                  localObject57[localObject29] = i18;
                                  localObject30 = i16 + 1;
                                  if (localObject62 != 0)
                                    break;
                                  localObject57 = localObject61;
                                  i16 = localObject30;
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                }
                              }
                              localObject57 = localObject62;
                              Object localObject87 = localObject61;
                              localObject61 = localObject30;
                              localObject31 = localObject87;
                            }
                            while (true)
                            {
                              if (localObject57 <= localObject61);
                              localObject31 = new String(localObject31).intern();
                              arrayOfString[i5] = localObject31;
                              i5 = 13;
                              localObject31 = "|AW\027W~BL@Sv\016WX\026w@BUZw\001G^EsLOR\026~A@VB{AM\027CbJBCSa".toCharArray();
                              Object localObject58 = localObject31.length;
                              label2504: Object localObject33;
                              if (localObject58 <= i4)
                              {
                                localObject61 = localObject1;
                                localObject62 = localObject58;
                                int i17 = localObject61;
                                localObject59 = localObject31;
                                Object localObject88 = localObject61;
                                localObject61 = localObject31;
                                Object localObject32;
                                for (localObject31 = localObject88; ; localObject32 = localObject62)
                                {
                                  i18 = localObject59[localObject31];
                                  i19 = i17 % 5;
                                  switch (i19)
                                  {
                                  default:
                                    i19 = 54;
                                    int i20 = (char)(i18 ^ i19);
                                    localObject59[localObject31] = i18;
                                    localObject32 = i17 + 1;
                                    if (localObject62 != 0)
                                      break;
                                    localObject59 = localObject61;
                                    i17 = localObject32;
                                  case 0:
                                  case 1:
                                  case 2:
                                  case 3:
                                  }
                                }
                                localObject59 = localObject62;
                                Object localObject89 = localObject61;
                                localObject61 = localObject32;
                                localObject33 = localObject89;
                              }
                              while (true)
                              {
                                if (localObject59 <= localObject61);
                                String str = new String(localObject33).intern();
                                arrayOfString[i5] = localObject33;
                                n = arrayOfString;
                                return;
                                i18 = i3;
                                break label116:
                                i18 = i1;
                                break label116:
                                i18 = i2;
                                break label116:
                                i18 = 55;
                                break label116:
                                i18 = i3;
                                break label296:
                                i18 = i1;
                                break label296:
                                i18 = i2;
                                break label296:
                                i18 = 55;
                                break label296:
                                i19 = i3;
                                break label480:
                                i19 = i1;
                                break label480:
                                i19 = i2;
                                break label480:
                                i19 = 55;
                                break label480:
                                i19 = i3;
                                break label664:
                                i19 = i1;
                                break label664:
                                i19 = i2;
                                break label664:
                                i19 = 55;
                                break label664:
                                i19 = i3;
                                break label848:
                                i19 = i1;
                                break label848:
                                i19 = i2;
                                break label848:
                                i19 = 55;
                                break label848:
                                i19 = i3;
                                break label1032:
                                i19 = i1;
                                break label1032:
                                i19 = i2;
                                break label1032:
                                i19 = 55;
                                break label1032:
                                i19 = i3;
                                break label1216:
                                i19 = i1;
                                break label1216:
                                i19 = i2;
                                break label1216:
                                i19 = 55;
                                break label1216:
                                i19 = i3;
                                break label1400:
                                i19 = i1;
                                break label1400:
                                i19 = i2;
                                break label1400:
                                i19 = 55;
                                break label1400:
                                i19 = i3;
                                break label1584:
                                i19 = i1;
                                break label1584:
                                i19 = i2;
                                break label1584:
                                i19 = 55;
                                break label1584:
                                i19 = i3;
                                break label1768:
                                i19 = i1;
                                break label1768:
                                i19 = i2;
                                break label1768:
                                i19 = 55;
                                break label1768:
                                i19 = i3;
                                break label1952:
                                i19 = i1;
                                break label1952:
                                i19 = i2;
                                break label1952:
                                i19 = 55;
                                break label1952:
                                i19 = i3;
                                break label2136:
                                i19 = i1;
                                break label2136:
                                i19 = i2;
                                break label2136:
                                i19 = 55;
                                break label2136:
                                i19 = i3;
                                break label2320:
                                i19 = i1;
                                break label2320:
                                i19 = i2;
                                break label2320:
                                i19 = 55;
                                break label2320:
                                i19 = i3;
                                break label2504:
                                i19 = i1;
                                break label2504:
                                i19 = i2;
                                break label2504:
                                i19 = 55;
                                break label2504:
                                localObject61 = localObject1;
                              }
                              localObject61 = localObject1;
                            }
                            localObject61 = localObject1;
                          }
                          localObject61 = localObject1;
                        }
                        localObject61 = localObject1;
                      }
                      localObject61 = localObject1;
                    }
                    localObject61 = localObject1;
                  }
                  localObject61 = localObject1;
                }
                localObject61 = localObject1;
              }
              localObject61 = localObject1;
            }
            localObject61 = localObject1;
          }
          localObject61 = localObject1;
        }
        localObject59 = localObject1;
      }
      Object localObject59 = localObject1;
    }
  }

  public z(av paramav)
  {
    Object localObject = new ak(this);
    this.h = ((PhoneStateListener)localObject);
    this.m = i1;
    localObject = ag.b(z.class);
    this.i = ((ag)localObject);
    localObject = ((aq)paramav).a();
    this.j = ((Context)localObject);
    try
    {
      localObject = at.a(new as(this));
      TimeUnit localTimeUnit = TimeUnit.SECONDS;
      localObject = (TelephonyManager)((Future)localObject).get(2L, localTimeUnit);
      this.k = ((TelephonyManager)localObject);
      localObject = this.k.getPhoneType();
      if (localObject != 2)
      {
        ag localag = this.i;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str1 = n[i2];
        String str2 = str1 + localObject;
        localag.b(str2);
        StringBuilder localStringBuilder2 = new StringBuilder();
        String str3 = n[i2];
        String str4 = str3 + localObject;
        throw new bc((String)localObject);
      }
    }
    catch (Exception localException)
    {
      String str5 = n[3];
      throw new bc(str5, localException);
    }
    this.l = null;
    this.m = i1;
    if (i3 == 0)
      return;
    int i4 = bf.d;
    ++localObject;
    bf.d = i4;
  }

  static Context a(z paramz)
  {
    return paramz.j;
  }

  /** @deprecated */
  private void a(CdmaCellLocation paramCdmaCellLocation)
  {
    Object localObject1 = 2147483647;
    long l1 = 4544752519965490399L;
    monitorenter;
    ag localag3;
    String str6;
    try
    {
      int i1;
      a = i1;
      boolean bool = c();
      if (!bool)
      {
        ag localag1 = this.i;
        String str1 = n[9];
        localag1.b(str1);
      }
      do
      {
        double d1;
        double d2;
        do
        {
          do
          {
            do
            {
              return;
              if (paramCdmaCellLocation != null)
                break;
              int i2 = 0;
              this.m = i2;
              localObject2 = this.i;
              String[] arrayOfString1 = n;
              i3 = 5;
              String str2 = arrayOfString1[i3];
              ((ag)localObject2).b(str2);
            }
            while (i1 == 0);
            Object localObject2 = paramCdmaCellLocation.getBaseStationLatitude();
            if (localObject2 != localObject1)
            {
              localObject2 = paramCdmaCellLocation.getBaseStationLongitude();
              if (localObject2 != localObject1)
                break;
            }
            this.m = null;
            localObject2 = this.i;
            String[] arrayOfString2 = n;
            int i3 = 7;
            String str3 = arrayOfString2[i3];
            ((ag)localObject2).b(str3);
          }
          while (i1 == 0);
          d1 = paramCdmaCellLocation.getBaseStationLatitude() * l1;
          d2 = paramCdmaCellLocation.getBaseStationLongitude() * l1;
          if ((d1 >= -4587338432941916160L) && (4636033603912859648L >= d1) && (d2 >= -4582834833314545664L) && (4640537203540230144L >= d2))
            break;
          this.m = null;
          ag localag2 = this.i;
          String str4 = n[6];
          localag2.d(str4);
        }
        while (i1 == 0);
        be localbe1 = new be();
        this.m = localbe1;
        be localbe2 = this.m;
        long l2 = System.currentTimeMillis();
        Object localObject3;
        localbe2.a(localObject3);
        this.m.a(d1);
        this.m.b(d2);
        this.m.c(1);
      }
      while (!this.i.a());
      localag3 = this.i;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str5 = n[8];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str5);
      be localbe3 = this.m;
      str6 = localbe3;
    }
    finally
    {
      monitorexit;
    }
  }

  static void a(z paramz, CdmaCellLocation paramCdmaCellLocation)
  {
    paramz.a(paramCdmaCellLocation);
  }

  static ag b(z paramz)
  {
    return paramz.i;
  }

  protected bt a(av paramav, String paramString)
  {
    return new z(paramav);
  }

  /** @deprecated */
  // ERROR //
  public void a(long paramLong)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 151	com/a/z:l	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: iconst_1
    //   15: istore_2
    //   16: aload_0
    //   17: iload_2
    //   18: putfield 151	com/a/z:l	Z
    //   21: aload_0
    //   22: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   25: astore_2
    //   26: aload_0
    //   27: getfield 79	com/a/z:h	Landroid/telephony/PhoneStateListener;
    //   30: astore_3
    //   31: aload_2
    //   32: aload_3
    //   33: bipush 17
    //   35: invokevirtual 224	android/telephony/TelephonyManager:listen	(Landroid/telephony/PhoneStateListener;I)V
    //   38: aload_0
    //   39: getfield 96	com/a/z:j	Landroid/content/Context;
    //   42: astore_2
    //   43: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   46: aconst_null
    //   47: aaload
    //   48: astore 4
    //   50: aload_2
    //   51: aload 4
    //   53: invokevirtual 230	android/content/Context:checkCallingOrSelfPermission	(Ljava/lang/String;)I
    //   56: astore_2
    //   57: iload_2
    //   58: ifeq +30 -> 88
    //   61: aload_0
    //   62: getfield 89	com/a/z:i	Lcom/a/ag;
    //   65: astore_2
    //   66: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   69: bipush 13
    //   71: aaload
    //   72: astore 5
    //   74: aload_2
    //   75: aload 5
    //   77: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   80: aload_2
    //   81: putstatic 70	com/a/z:a	Z
    //   84: aload_2
    //   85: ifnull +86 -> 171
    //   88: aload_0
    //   89: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   92: invokevirtual 236	java/lang/Object:getClass	()Ljava/lang/Class;
    //   95: astore_2
    //   96: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   99: bipush 10
    //   101: aaload
    //   102: astore 6
    //   104: aconst_null
    //   105: anewarray 238	java/lang/Class
    //   108: astore 7
    //   110: aload_2
    //   111: aload 6
    //   113: aload 7
    //   115: invokevirtual 242	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   118: astore_2
    //   119: aload_2
    //   120: invokevirtual 247	java/lang/reflect/Method:isAccessible	()Z
    //   123: ifne +8 -> 131
    //   126: aload_2
    //   127: iconst_1
    //   128: invokevirtual 251	java/lang/reflect/Method:setAccessible	(Z)V
    //   131: aload_0
    //   132: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   135: astore 8
    //   137: aconst_null
    //   138: anewarray 232	java/lang/Object
    //   141: astore 9
    //   143: aload_2
    //   144: aload 8
    //   146: aload 9
    //   148: invokevirtual 255	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   151: pop
    //   152: aload_0
    //   153: getfield 89	com/a/z:i	Lcom/a/ag;
    //   156: astore_2
    //   157: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   160: bipush 12
    //   162: aaload
    //   163: astore 10
    //   165: aload_2
    //   166: aload 10
    //   168: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   171: invokestatic 260	android/telephony/CellLocation:requestLocationUpdate	()V
    //   174: goto -163 -> 11
    //   177: astore 11
    //   179: aload_0
    //   180: monitorexit
    //   181: aload 11
    //   183: athrow
    //   184: astore_2
    //   185: aload_0
    //   186: getfield 89	com/a/z:i	Lcom/a/ag;
    //   189: astore 12
    //   191: new 128	java/lang/StringBuilder
    //   194: dup
    //   195: invokespecial 129	java/lang/StringBuilder:<init>	()V
    //   198: astore 13
    //   200: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   203: bipush 11
    //   205: aaload
    //   206: astore 14
    //   208: aload 13
    //   210: aload 14
    //   212: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: astore 15
    //   217: aload_2
    //   218: invokevirtual 264	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
    //   221: astore 16
    //   223: aload 15
    //   225: aload_2
    //   226: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   229: invokevirtual 139	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   232: astore 17
    //   234: aload 12
    //   236: aload_2
    //   237: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   240: goto -69 -> 171
    //   243: astore 18
    //   245: aload_0
    //   246: getfield 89	com/a/z:i	Lcom/a/ag;
    //   249: astore 19
    //   251: new 128	java/lang/StringBuilder
    //   254: dup
    //   255: invokespecial 129	java/lang/StringBuilder:<init>	()V
    //   258: astore 20
    //   260: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   263: bipush 11
    //   265: aaload
    //   266: astore 21
    //   268: aload 20
    //   270: aload 21
    //   272: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: aload 18
    //   277: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   280: invokevirtual 139	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   283: astore 22
    //   285: aload 19
    //   287: aload 22
    //   289: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   292: goto -121 -> 171
    //
    // Exception table:
    //   from	to	target	type
    //   2	7	177	finally
    //   16	84	177	finally
    //   88	171	177	finally
    //   171	174	177	finally
    //   185	292	177	finally
    //   88	171	184	java/lang/reflect/InvocationTargetException
    //   88	171	243	java/lang/Throwable
  }

  /** @deprecated */
  public be b()
  {
    monitorenter;
    try
    {
      be localbe1 = this.m;
      if (localbe1 == null)
      {
        int i1 = 0;
        return i1;
      }
    }
    finally
    {
      be localbe2;
      monitorexit;
    }
  }

  /** @deprecated */
  public boolean c()
  {
    monitorenter;
    try
    {
      boolean bool = this.l;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  /** @deprecated */
  // ERROR //
  public void d()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 151	com/a/z:l	Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifne +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield 96	com/a/z:j	Landroid/content/Context;
    //   18: astore_1
    //   19: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   22: aconst_null
    //   23: aaload
    //   24: astore_2
    //   25: aload_1
    //   26: aload_2
    //   27: invokevirtual 230	android/content/Context:checkCallingOrSelfPermission	(Ljava/lang/String;)I
    //   30: astore_1
    //   31: iload_1
    //   32: ifne +64 -> 96
    //   35: aload_0
    //   36: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   39: invokevirtual 236	java/lang/Object:getClass	()Ljava/lang/Class;
    //   42: astore_1
    //   43: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   46: iconst_1
    //   47: aaload
    //   48: astore_3
    //   49: aconst_null
    //   50: anewarray 238	java/lang/Class
    //   53: astore 4
    //   55: aload_1
    //   56: aload_3
    //   57: aload 4
    //   59: invokevirtual 242	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   62: astore_1
    //   63: aload_1
    //   64: invokevirtual 247	java/lang/reflect/Method:isAccessible	()Z
    //   67: ifne +8 -> 75
    //   70: aload_1
    //   71: iconst_1
    //   72: invokevirtual 251	java/lang/reflect/Method:setAccessible	(Z)V
    //   75: aload_0
    //   76: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   79: astore 5
    //   81: aconst_null
    //   82: anewarray 232	java/lang/Object
    //   85: astore 6
    //   87: aload_1
    //   88: aload 5
    //   90: aload 6
    //   92: invokevirtual 255	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: aload_0
    //   97: getfield 122	com/a/z:k	Landroid/telephony/TelephonyManager;
    //   100: astore 7
    //   102: aload_0
    //   103: getfield 79	com/a/z:h	Landroid/telephony/PhoneStateListener;
    //   106: astore 8
    //   108: aload 7
    //   110: aload 8
    //   112: aconst_null
    //   113: invokevirtual 224	android/telephony/TelephonyManager:listen	(Landroid/telephony/PhoneStateListener;I)V
    //   116: aload_0
    //   117: aconst_null
    //   118: putfield 151	com/a/z:l	Z
    //   121: aload_0
    //   122: aconst_null
    //   123: putfield 81	com/a/z:m	Lcom/a/a/be;
    //   126: goto -115 -> 11
    //   129: astore 9
    //   131: aload_0
    //   132: monitorexit
    //   133: aload 9
    //   135: athrow
    //   136: astore_1
    //   137: aload_0
    //   138: getfield 89	com/a/z:i	Lcom/a/ag;
    //   141: astore 10
    //   143: new 128	java/lang/StringBuilder
    //   146: dup
    //   147: invokespecial 129	java/lang/StringBuilder:<init>	()V
    //   150: astore 11
    //   152: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   155: iconst_2
    //   156: aaload
    //   157: astore 12
    //   159: aload 11
    //   161: aload 12
    //   163: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: astore 13
    //   168: aload_1
    //   169: invokevirtual 264	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
    //   172: astore 14
    //   174: aload 13
    //   176: aload_1
    //   177: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   180: invokevirtual 139	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   183: astore 15
    //   185: aload 10
    //   187: aload_1
    //   188: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   191: goto -95 -> 96
    //   194: astore 16
    //   196: aload_0
    //   197: getfield 89	com/a/z:i	Lcom/a/ag;
    //   200: astore 17
    //   202: new 128	java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial 129	java/lang/StringBuilder:<init>	()V
    //   209: astore 18
    //   211: getstatic 65	com/a/z:n	[Ljava/lang/String;
    //   214: iconst_2
    //   215: aaload
    //   216: astore 19
    //   218: aload 18
    //   220: aload 19
    //   222: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: aload 16
    //   227: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   230: invokevirtual 139	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   233: astore 20
    //   235: aload 17
    //   237: aload 20
    //   239: invokevirtual 142	com/a/ag:b	(Ljava/lang/String;)V
    //   242: goto -146 -> 96
    //
    // Exception table:
    //   from	to	target	type
    //   2	7	129	finally
    //   14	31	129	finally
    //   35	96	129	finally
    //   96	126	129	finally
    //   137	242	129	finally
    //   35	96	136	java/lang/reflect/InvocationTargetException
    //   35	96	194	java/lang/Throwable
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.z
 * JD-Core Version:    0.5.4
 */