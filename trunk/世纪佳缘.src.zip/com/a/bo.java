package com.a;

public class bo
{
  public final Object a;
  public final Object b;

  public bo(Object paramObject1, Object paramObject2)
  {
    this.a = paramObject1;
    this.b = paramObject2;
  }

  public static bo a(Object paramObject1, Object paramObject2)
  {
    return new bo(paramObject1, paramObject2);
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int i;
    if (this == paramObject)
      i = localObject1;
    while (true)
    {
      label12: return i;
      Object localObject3;
      if (paramObject == null)
        localObject3 = localObject2;
      try
      {
        paramObject = (bo)paramObject;
        localObject3 = this.a;
        if (localObject3 != null)
        {
          localObject3 = this.a;
          Object localObject5 = paramObject.a;
          localObject3 = localObject3.equals(localObject5);
          if (localObject3 == 0)
            break label121;
        }
        do
        {
          localObject3 = this.b;
          if (localObject3 == null)
            break;
          localObject3 = this.b;
          Object localObject6 = paramObject.b;
          localObject3 = localObject3.equals(localObject6);
          if (localObject3 == 0)
            break;
          localObject3 = localObject1;
          break label12:
          localObject3 = paramObject.a;
        }
        while (localObject3 == null);
        do
        {
          label121: localObject3 = localObject2;
          break label12:
          localObject3 = paramObject.b;
        }
        while (localObject3 != null);
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject2;
        break label12:
      }
    }
  }

  public int hashCode()
  {
    Object localObject1 = null;
    int i = 17 * 37;
    Object localObject2 = this.a;
    label19: int j;
    if (localObject2 == null)
    {
      localObject2 = localObject1;
      j = (localObject2 + 629) * 37;
      localObject3 = this.b;
      if (localObject3 != null)
        break label54;
    }
    for (Object localObject3 = localObject1; ; localObject3 = this.b.hashCode())
    {
      return j + localObject3;
      int k = this.a.hashCode();
      label54: break label19:
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("(");
    Object localObject1 = this.a;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localObject1).append(",");
    Object localObject2 = this.b;
    return localObject2 + ")";
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bo
 * JD-Core Version:    0.5.4
 */