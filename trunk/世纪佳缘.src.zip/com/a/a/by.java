package com.a.a;

public class by extends Thread
{
  private final r a;

  public by(r paramr)
  {
    super(paramr);
    this.a = paramr;
  }

  public final void a()
  {
    this.a.a();
    interrupt();
    interrupted();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.by
 * JD-Core Version:    0.5.4
 */