package com.a.a;

import com.a.ag;
import com.a.bo;
import com.a.bv;
import java.util.Iterator;
import java.util.LinkedList;

final class ap
{
  private static final String[] g;
  private final ag b;
  private final ai c;
  private final LinkedList d;
  private final af e;
  private int f;

  static
  {
    int i = 92;
    int j = 22;
    int k = 19;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[8];
    char[] arrayOfChar1 = "|w\0333f9x\na`(纮}".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject36;
    Object localObject38;
    Object localObject7;
    Object localObject23;
    int i2;
    int i8;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject22 = localObject1;
      localObject36 = localObject6;
      localObject38 = localObject22;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject22;
      localObject23 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject36)
      {
        i2 = localObject7[arrayOfChar1];
        i8 = localObject38 % 5;
        switch (i8)
        {
        default:
          i8 = l;
          i2 = (char)(i2 ^ i8);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject38 + 1;
          if (localObject36 != 0)
            break;
          localObject7 = localObject23;
          localObject38 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject36;
      Object localObject39 = localObject23;
      localObject23 = localObject2;
      localObject3 = localObject39;
    }
    while (true)
    {
      if (localObject7 <= localObject23);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "|x纮g!:y\032}e|\0013c0w\fxm5e".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject23 = localObject1;
        localObject36 = localObject8;
        localObject38 = localObject23;
        localObject9 = localObject3;
        Object localObject40 = localObject23;
        localObject23 = localObject3;
        Object localObject4;
        for (localObject3 = localObject40; ; localObject4 = localObject36)
        {
          i2 = localObject9[localObject3];
          i8 = localObject38 % 5;
          switch (i8)
          {
          default:
            i8 = l;
            i2 = (char)(i2 ^ i8);
            localObject9[localObject3] = i2;
            localObject4 = localObject38 + 1;
            if (localObject36 != 0)
              break;
            localObject9 = localObject23;
            localObject38 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject36;
        Object localObject41 = localObject23;
        localObject23 = localObject4;
        localObject5 = localObject41;
      }
      while (true)
      {
        if (localObject9 <= localObject23);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = ">z\016pj0\034gh2qO".toCharArray();
        Object localObject24 = localObject9.length;
        Object localObject25;
        Object localObject37;
        int i9;
        label480: Object localObject11;
        if (localObject24 <= l)
        {
          localObject36 = localObject1;
          localObject38 = localObject24;
          i2 = localObject36;
          localObject25 = localObject9;
          Object localObject42 = localObject36;
          localObject37 = localObject9;
          Object localObject10;
          for (localObject9 = localObject42; ; localObject10 = localObject38)
          {
            i8 = localObject25[localObject9];
            i9 = i2 % 5;
            switch (i9)
            {
            default:
              i9 = l;
              i8 = (char)(i8 ^ i9);
              localObject25[localObject9] = i8;
              localObject10 = i2 + 1;
              if (localObject38 != 0)
                break;
              localObject25 = localObject37;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject25 = localObject38;
          Object localObject43 = localObject37;
          localObject37 = localObject10;
          localObject11 = localObject43;
        }
        while (true)
        {
          if (localObject25 <= localObject37);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = ":y\032}e|".toCharArray();
          Object localObject26 = localObject11.length;
          Object localObject27;
          label664: Object localObject13;
          if (localObject26 <= l)
          {
            localObject37 = localObject1;
            localObject38 = localObject26;
            int i3 = localObject37;
            localObject27 = localObject11;
            Object localObject44 = localObject37;
            localObject37 = localObject11;
            Object localObject12;
            for (localObject11 = localObject44; ; localObject12 = localObject38)
            {
              i8 = localObject27[localObject11];
              i9 = i3 % 5;
              switch (i9)
              {
              default:
                i9 = l;
                i8 = (char)(i8 ^ i9);
                localObject27[localObject11] = i8;
                localObject12 = i3 + 1;
                if (localObject38 != 0)
                  break;
                localObject27 = localObject37;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject27 = localObject38;
            Object localObject45 = localObject37;
            localObject37 = localObject12;
            localObject13 = localObject45;
          }
          while (true)
          {
            if (localObject27 <= localObject37);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "|\0013c0w\fxm5e\0333v5b\0073f9x\na`(纮}".toCharArray();
            Object localObject28 = localObject13.length;
            Object localObject29;
            label848: Object localObject15;
            if (localObject28 <= l)
            {
              localObject37 = localObject1;
              localObject38 = localObject28;
              int i4 = localObject37;
              localObject29 = localObject13;
              Object localObject46 = localObject37;
              localObject37 = localObject13;
              Object localObject14;
              for (localObject13 = localObject46; ; localObject14 = localObject38)
              {
                i8 = localObject29[localObject13];
                i9 = i4 % 5;
                switch (i9)
                {
                default:
                  i9 = l;
                  i8 = (char)(i8 ^ i9);
                  localObject29[localObject13] = i8;
                  localObject14 = i4 + 1;
                  if (localObject38 != 0)
                    break;
                  localObject29 = localObject37;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject29 = localObject38;
              Object localObject47 = localObject37;
              localObject37 = localObject14;
              localObject15 = localObject47;
            }
            while (true)
            {
              if (localObject29 <= localObject37);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "2s\030vr(6\tzm96\bvo9d\016gh3xOzr|".toCharArray();
              Object localObject30 = localObject15.length;
              Object localObject31;
              label1032: Object localObject17;
              if (localObject30 <= l)
              {
                localObject37 = localObject1;
                localObject38 = localObject30;
                int i5 = localObject37;
                localObject31 = localObject15;
                Object localObject48 = localObject37;
                localObject37 = localObject15;
                Object localObject16;
                for (localObject15 = localObject48; ; localObject16 = localObject38)
                {
                  i8 = localObject31[localObject15];
                  i9 = i5 % 5;
                  switch (i9)
                  {
                  default:
                    i9 = l;
                    i8 = (char)(i8 ^ i9);
                    localObject31[localObject15] = i8;
                    localObject16 = i5 + 1;
                    if (localObject38 != 0)
                      break;
                    localObject31 = localObject37;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject31 = localObject38;
                Object localObject49 = localObject37;
                localObject37 = localObject16;
                localObject17 = localObject49;
              }
              while (true)
              {
                if (localObject31 <= localObject37);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = ",y\037;(|u\016m9rOdh(~O}n|p\006d/".toCharArray();
                Object localObject32 = localObject17.length;
                Object localObject33;
                label1216: Object localObject19;
                if (localObject32 <= l)
                {
                  localObject37 = localObject1;
                  localObject38 = localObject32;
                  int i6 = localObject37;
                  localObject33 = localObject17;
                  Object localObject50 = localObject37;
                  localObject37 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject50; ; localObject18 = localObject38)
                  {
                    i8 = localObject33[localObject17];
                    i9 = i6 % 5;
                    switch (i9)
                    {
                    default:
                      i9 = l;
                      i8 = (char)(i8 ^ i9);
                      localObject33[localObject17] = i8;
                      localObject18 = i6 + 1;
                      if (localObject38 != 0)
                        break;
                      localObject33 = localObject37;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject33 = localObject38;
                  Object localObject51 = localObject37;
                  localObject37 = localObject18;
                  localObject19 = localObject51;
                }
                while (true)
                {
                  if (localObject33 <= localObject37);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  i1 = 7;
                  localObject19 = "9n\fvq(纮}!+~\006d|z纮re5x\b3g5z".toCharArray();
                  Object localObject34 = localObject19.length;
                  label1400: Object localObject21;
                  if (localObject34 <= l)
                  {
                    localObject37 = localObject1;
                    localObject38 = localObject34;
                    int i7 = localObject37;
                    localObject35 = localObject19;
                    Object localObject52 = localObject37;
                    localObject37 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject52; ; localObject20 = localObject38)
                    {
                      i8 = localObject35[localObject19];
                      i9 = i7 % 5;
                      switch (i9)
                      {
                      default:
                        i9 = l;
                        int i10 = (char)(i8 ^ i9);
                        localObject35[localObject19] = i8;
                        localObject20 = i7 + 1;
                        if (localObject38 != 0)
                          break;
                        localObject35 = localObject37;
                        i7 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject35 = localObject38;
                    Object localObject53 = localObject37;
                    localObject37 = localObject20;
                    localObject21 = localObject53;
                  }
                  while (true)
                  {
                    if (localObject35 <= localObject37);
                    String str = new String(localObject21).intern();
                    arrayOfString[i1] = localObject21;
                    g = arrayOfString;
                    if (!ap.class.desiredAssertionStatus())
                      int i11 = l;
                    while (true)
                    {
                      boolean bool = a;
                      return;
                      int i12 = localObject1;
                    }
                    i8 = i;
                    break label116:
                    i8 = j;
                    break label116:
                    i8 = 111;
                    break label116:
                    i8 = k;
                    break label116:
                    i8 = i;
                    break label296:
                    i8 = j;
                    break label296:
                    i8 = 111;
                    break label296:
                    i8 = k;
                    break label296:
                    i9 = i;
                    break label480:
                    i9 = j;
                    break label480:
                    i9 = 111;
                    break label480:
                    i9 = k;
                    break label480:
                    i9 = i;
                    break label664:
                    i9 = j;
                    break label664:
                    i9 = 111;
                    break label664:
                    i9 = k;
                    break label664:
                    i9 = i;
                    break label848:
                    i9 = j;
                    break label848:
                    i9 = 111;
                    break label848:
                    i9 = k;
                    break label848:
                    i9 = i;
                    break label1032:
                    i9 = j;
                    break label1032:
                    i9 = 111;
                    break label1032:
                    i9 = k;
                    break label1032:
                    i9 = i;
                    break label1216:
                    i9 = j;
                    break label1216:
                    i9 = 111;
                    break label1216:
                    i9 = k;
                    break label1216:
                    i9 = i;
                    break label1400:
                    i9 = j;
                    break label1400:
                    i9 = 111;
                    break label1400:
                    i9 = k;
                    break label1400:
                    localObject37 = localObject1;
                  }
                  localObject37 = localObject1;
                }
                localObject37 = localObject1;
              }
              localObject37 = localObject1;
            }
            localObject37 = localObject1;
          }
          localObject37 = localObject1;
        }
        localObject35 = localObject1;
      }
      Object localObject35 = localObject1;
    }
  }

  ap(ai paramai)
  {
    LinkedList localLinkedList = new LinkedList();
    this.d = localLinkedList;
    ag localag = ag.b(ap.class);
    this.b = localag;
    this.c = paramai;
    this.f = -1;
    af localaf = new af(256);
    this.e = localaf;
  }

  au a()
  {
    boolean bool = this.d.isEmpty();
    Object localObject;
    if (!bool)
      localObject = (au)((bo)this.d.removeLast()).a;
    while (true)
    {
      return localObject;
      localObject = this.b;
      String str = g[6];
      ((ag)localObject).e(str);
      int i = 0;
    }
  }

  au a(String paramString)
  {
    try
    {
      au localau = au.b(this.c.b(), paramString);
      LinkedList localLinkedList = this.d;
      boolean bool = this.d.isEmpty();
      if (bool)
      {
        i = 0;
        int j = this.f;
        int k;
        ++k;
        this.f = j;
        Integer localInteger = Integer.valueOf(j);
        bo localbo = bo.a(localau, localInteger);
        localLinkedList.add(i, localbo);
        label72: return localau;
      }
      int i = 1;
    }
    catch (Exception localException)
    {
      ag localag = this.b;
      StringBuilder localStringBuilder = new StringBuilder();
      String str1 = g[7];
      String str2 = str1 + paramString;
      localag.d(str2, localException);
      localException = null;
      break label72:
    }
  }

  bo a(bv parambv)
  {
    int i = 0;
    int j = -1;
    int k = au.a;
    af localaf = this.e;
    int i2 = localaf.a(parambv);
    a = localaf;
    if ((localaf == null) && (i2 < j))
      throw new AssertionError();
    a = localaf;
    if (localaf == null)
    {
      int l = this.f;
      if (i2 > l)
        throw new AssertionError();
    }
    boolean bool = this.b.a();
    Object localObject2;
    if (bool)
    {
      if (i2 == j)
      {
        localag = this.b;
        localObject2 = new StringBuilder().append(parambv);
        str1 = g[1];
        localObject2 = str1;
        localag.b((String)localObject2);
        if (k == 0)
          break label215;
      }
      ag localag = this.b;
      localObject2 = new StringBuilder();
      String str1 = g[3];
      localObject2 = ((StringBuilder)localObject2).append(str1).append(parambv);
      str1 = g[4];
      localObject2 = str1 + i2;
      localag.b((String)localObject2);
      label215: localag = this.b;
      localObject2 = new StringBuilder();
      str1 = g[5];
      localObject2 = ((StringBuilder)localObject2).append(str1);
      int i3 = this.f;
      localObject2 = i3;
      localag.b((String)localObject2);
    }
    int i1 = this.f;
    if (i2 == i1)
    {
      localObject1 = i;
      label287: return localObject1;
    }
    Object localObject1 = this.d;
    Iterator localIterator = ((LinkedList)localObject1).iterator();
    do
    {
      localObject1 = localIterator.hasNext();
      if (localObject1 == 0)
        break;
      localObject1 = (bo)localIterator.next();
      localObject2 = ((Integer)((bo)localObject1).b).intValue();
      if (k != 0)
        break label539;
      if (localObject2 <= i2)
        continue;
      localObject2 = ((au)((bo)localObject1).a).a(parambv);
      if (localObject2 == null)
        continue;
      if (i2 > j)
        this.e.b(parambv);
      localIterator.remove();
      this.d.addFirst(localObject1);
      localObject1 = bo.a(((bo)localObject1).a, localObject2);
      break label287:
    }
    while (k == 0);
    localObject1 = this.b.a();
    while (true)
    {
      if (localObject1 != 0)
      {
        localObject1 = this.b;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str2 = g[2];
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str2).append(parambv);
        String str3 = g[null];
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str3);
        int i4 = this.f;
        String str4 = i4;
        ((ag)localObject1).b(str4);
      }
      localObject1 = this.e;
      int i5 = this.f;
      ((af)localObject1).a(parambv, i5);
      localObject1 = i;
      break label287:
      label539: localObject1 = localObject2;
    }
  }

  void a(au paramau)
  {
    this.d.remove(paramau);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ap
 * JD-Core Version:    0.5.4
 */