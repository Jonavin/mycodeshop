package com.a.a;

import java.io.Serializable;

public final class ah
  implements Serializable, Cloneable
{
  private static final String[] l;
  String a = null;
  String b = null;
  String c = null;
  String d = null;
  String e = null;
  String f = null;
  String g = null;
  String h = null;
  String i = null;
  String j = null;
  String[] k = null;

  static
  {
    int i1 = 37;
    int i2 = 18;
    int i3 = 14;
    int i4 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = ">\005".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i5;
    Object localObject7;
    Object localObject10;
    int i6;
    int i7;
    label116: Object localObject3;
    if (localObject6 <= i4)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i5 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i6 = localObject7[arrayOfChar1];
        i7 = i5 % 5;
        switch (i7)
        {
        default:
          i7 = 112;
          i6 = (char)(i6 ^ i7);
          localObject7[arrayOfChar1] = i6;
          localObject2 = i5 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i5 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "2\r".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= i4)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i5 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i6 = localObject9[localObject3];
          i7 = i5 % 5;
          switch (i7)
          {
          default:
            i7 = 112;
            int i8 = (char)(i6 ^ i7);
            localObject9[localObject3] = i6;
            localObject4 = i5 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i5 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[i4] = localObject5;
        l = arrayOfString;
        return;
        i7 = i2;
        break label116:
        i7 = i1;
        break label116:
        i7 = i3;
        break label116:
        i7 = 123;
        break label116:
        i7 = i2;
        break label296:
        i7 = i1;
        break label296:
        i7 = i3;
        break label296:
        i7 = 123;
        break label296:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  public ah a()
  {
    try
    {
      ah localah = (ah)super.clone();
      if (this.k != null)
      {
        String[] arrayOfString = (String[])this.k.clone();
        localah.k = this;
      }
      return localah;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new RuntimeException(localCloneNotSupportedException);
    }
  }

  public String toString()
  {
    Object localObject1 = null;
    int i1;
    g.d = i1;
    StringBuilder localStringBuilder1 = new StringBuilder();
    Object localObject2 = this.a;
    if (localObject2 != null)
    {
      localObject2 = this.k;
      if (localObject2 != null)
      {
        localObject2 = this.a;
        localStringBuilder1.append((String)localObject2).append(" ");
        localObject2 = this.k;
        int i2 = localObject2.length;
        Object localObject3 = localObject1;
        do
        {
          if (localObject3 >= i2)
            break;
          String str1 = localObject2[localObject3];
          String str2 = str1 + "\n";
          localStringBuilder1.append(str2);
          ++localObject3;
          if (i1 != 0)
            break label317;
        }
        while (i1 == 0);
      }
    }
    if ((this.i != null) && (this.j != null))
    {
      if ((this.b != null) && (this.h != null) && (this.c != null))
      {
        StringBuilder localStringBuilder2 = new StringBuilder();
        String str3 = this.b;
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str3);
        String str4 = l[localObject1];
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str4);
        String str5 = this.h;
        StringBuilder localStringBuilder5 = localStringBuilder4.append(str5).append(" ");
        String str6 = this.c;
        String str7 = str6 + "\n";
        localStringBuilder1.append(str7);
      }
      String str8 = this.i;
      StringBuilder localStringBuilder6 = localStringBuilder1.append(str8);
      StringBuilder localStringBuilder7 = new StringBuilder();
      String str9 = l[1];
      StringBuilder localStringBuilder8 = localStringBuilder7.append(str9);
      String str10 = this.j;
      String str11 = str10 + ")";
      localStringBuilder6.append(str11);
    }
    label317: return (String)localStringBuilder1.toString();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ah
 * JD-Core Version:    0.5.4
 */