package com.a.a;

import java.io.IOException;

public final class p extends IOException
{
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.p
 * JD-Core Version:    0.5.4
 */