package com.a.a;

public enum bv
{
  private static final String[] d;

  static
  {
    int i = 36;
    int j = 32;
    int k = 2;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[k];
    char[] arrayOfChar1 = "sb\002\fk|\005i\001qw".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 79;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "sb\002\034p}\001".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 79;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str1 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        d = arrayOfString;
        String str2 = d[localObject1];
        a = new bv(localObject5, localObject1);
        String str3 = d[l];
        b = new bv(localObject5, l);
        bv[] arrayOfbv = new bv[k];
        bv localbv1 = a;
        arrayOfString[localObject1] = localObject5;
        bv localbv2 = b;
        arrayOfString[l] = localObject5;
        c = arrayOfString;
        return;
        i3 = i;
        break label116:
        i3 = 50;
        break label116:
        i3 = 81;
        break label116:
        i3 = j;
        break label116:
        i3 = i;
        break label296:
        i3 = 50;
        break label296:
        i3 = 81;
        break label296:
        i3 = j;
        break label296:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bv
 * JD-Core Version:    0.5.4
 */