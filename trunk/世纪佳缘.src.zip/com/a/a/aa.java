package com.a.a;

import com.a.af;
import com.a.c;
import com.a.h;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;

class aa
  implements Iterable
{
  static final boolean a;
  private final long b;
  private final LinkedList c;

  static
  {
    if (!aa.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  aa(long paramLong)
  {
    this.b = paramLong;
    LinkedList localLinkedList = new LinkedList();
    this.c = localLinkedList;
  }

  int a()
  {
    return this.c.size();
  }

  int a(h paramh, long paramLong)
  {
    int i;
    g.d = i;
    Object localObject = null;
    Iterator localIterator = c(paramh, paramLong).iterator();
    do
    {
      if (!localIterator.hasNext())
        break;
      af localaf = (af)localIterator.next();
      ++localObject;
    }
    while (i == 0);
    return localObject;
  }

  void a(af paramaf)
  {
    LinkedList localLinkedList1 = this.c;
    localLinkedList1.addFirst(paramaf);
    a = localLinkedList1;
    if (localLinkedList1 != null)
      return;
    LinkedList localLinkedList2 = this.c;
    Comparator localComparator = af.f;
    if (c.a(localLinkedList2, localComparator))
      return;
    throw new AssertionError();
  }

  void a(h paramh)
  {
    int i;
    g.d = i;
    do
    {
      if (this.c.isEmpty())
        return;
      long l1 = ((af)this.c.getLast()).e().a(paramh);
      long l2 = this.b;
      Object localObject;
      if (localObject <= l2)
        return;
      this.c.removeLast();
    }
    while (i == 0);
  }

  void a(Collection paramCollection)
  {
    int i;
    g.d = i;
    Iterator localIterator = paramCollection.iterator();
    af localaf;
    do
    {
      boolean bool = localIterator.hasNext();
      if (!bool)
        break;
      localaf = (af)localIterator.next();
      this.c.addFirst(localaf);
      if (i != 0)
        return;
    }
    while (i == 0);
    a = localaf;
    if (localaf != 0)
      return;
    LinkedList localLinkedList = this.c;
    Comparator localComparator = af.f;
    if (c.a(localLinkedList, localComparator))
      return;
    throw new AssertionError();
  }

  af b(h paramh, long paramLong)
  {
    af localaf = c();
    int i;
    if ((localaf == null) || (localaf.e().a(paramh) > paramLong))
      i = 0;
    return i;
  }

  void b()
  {
    this.c.clear();
  }

  af c()
  {
    boolean bool = this.c.isEmpty();
    af localaf;
    if (!bool)
      localaf = (af)this.c.getFirst();
    while (true)
    {
      return localaf;
      int i = 0;
    }
  }

  Iterable c(h paramh, long paramLong)
  {
    LinkedList localLinkedList = this.c;
    x localx = new x(this, paramh, paramLong);
    return c.b(localLinkedList, localx);
  }

  public Iterator iterator()
  {
    return this.c.iterator();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.aa
 * JD-Core Version:    0.5.4
 */