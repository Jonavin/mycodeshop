package com.a.a;

import java.io.Serializable;

public final class ai
  implements Serializable
{
  private final String a;
  private final String b;

  public ai(String paramString1, String paramString2)
  {
    this.a = paramString1;
    this.b = paramString2;
  }

  public String a()
  {
    return this.a;
  }

  public String b()
  {
    return this.b;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      label8: return localObject2;
      try
      {
        paramObject = (ai)paramObject;
        localObject2 = this.a;
        String str1 = paramObject.a;
        if (localObject2 != str1)
        {
          localObject2 = this.a;
          if (localObject2 == null)
            break label116;
          localObject2 = this.a;
          String str2 = paramObject.a;
          localObject2 = ((String)localObject2).equals(str2);
          if (localObject2 == 0)
            break label116;
        }
        localObject2 = this.b;
        String str3 = paramObject.b;
        if (localObject2 != str3)
        {
          localObject2 = this.b;
          if (localObject2 == null)
            break label116;
          localObject2 = this.b;
          String str4 = paramObject.b;
          localObject2 = ((String)localObject2).equals(str4);
          if (localObject2 == 0)
            break label116;
        }
        int i = 1;
        break label8:
        label116: Object localObject3 = localObject1;
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    int i = 17 * 37;
    int j = (this.a.hashCode() + 629) * 37;
    int k = this.b.hashCode();
    return j + k;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ai
 * JD-Core Version:    0.5.4
 */