package com.a.a;

import com.a.ag;
import com.a.bv;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public final class aw extends au
{
  private static final String[] f;
  private final ag b;
  private final String c;
  private ByteBuffer d;
  private ArrayList e;

  static
  {
    Object localObject1 = 37;
    Object localObject2 = 33;
    Object localObject3 = 20;
    int i = 1;
    Object localObject4 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "\f}K\001\002@uG\001".toCharArray();
    Object localObject9 = arrayOfChar1.length;
    Object localObject19;
    Object localObject21;
    Object localObject10;
    Object localObject16;
    int k;
    int l;
    label116: Object localObject6;
    if (localObject9 <= i)
    {
      Object localObject15 = localObject4;
      localObject19 = localObject9;
      localObject21 = localObject15;
      localObject10 = arrayOfChar1;
      char[] arrayOfChar2 = localObject15;
      localObject16 = arrayOfChar1;
      Object localObject5;
      for (arrayOfChar1 = arrayOfChar2; ; localObject5 = localObject19)
      {
        k = localObject10[arrayOfChar1];
        l = localObject21 % 5;
        switch (l)
        {
        default:
          l = 113;
          k = (char)(k ^ l);
          localObject10[arrayOfChar1] = k;
          localObject5 = localObject21 + 1;
          if (localObject19 != 0)
            break;
          localObject10 = localObject16;
          localObject21 = localObject5;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject10 = localObject19;
      Object localObject22 = localObject16;
      localObject16 = localObject5;
      localObject6 = localObject22;
    }
    while (true)
    {
      if (localObject10 <= localObject16);
      localObject6 = new String(localObject6).intern();
      arrayOfString[localObject4] = localObject6;
      localObject6 = "mD\005M\036CPQQJuLM\024H4CN\003\f".toCharArray();
      Object localObject11 = localObject6.length;
      Object localObject12;
      label296: Object localObject8;
      if (localObject11 <= i)
      {
        localObject16 = localObject4;
        localObject19 = localObject11;
        localObject21 = localObject16;
        localObject12 = localObject6;
        Object localObject23 = localObject16;
        localObject16 = localObject6;
        Object localObject7;
        for (localObject6 = localObject23; ; localObject7 = localObject19)
        {
          k = localObject12[localObject6];
          l = localObject21 % 5;
          switch (l)
          {
          default:
            l = 113;
            k = (char)(k ^ l);
            localObject12[localObject6] = k;
            localObject7 = localObject21 + 1;
            if (localObject19 != 0)
              break;
            localObject12 = localObject16;
            localObject21 = localObject7;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject12 = localObject19;
        Object localObject24 = localObject16;
        localObject16 = localObject7;
        localObject8 = localObject24;
      }
      while (true)
      {
        if (localObject12 <= localObject16);
        localObject8 = new String(localObject8).intern();
        arrayOfString[i] = localObject8;
        int j = 2;
        localObject12 = "{Dv\023".toCharArray();
        Object localObject17 = localObject12.length;
        Object localObject20;
        label480: Object localObject14;
        if (localObject17 <= i)
        {
          localObject19 = localObject4;
          localObject21 = localObject17;
          k = localObject19;
          localObject18 = localObject12;
          Object localObject25 = localObject19;
          localObject20 = localObject12;
          Object localObject13;
          for (localObject12 = localObject25; ; localObject13 = localObject21)
          {
            l = localObject18[localObject12];
            localObject4 = k % 5;
            switch (localObject4)
            {
            default:
              localObject4 = 113;
              int i1 = (char)(l ^ localObject4);
              localObject18[localObject12] = l;
              localObject13 = k + 1;
              if (localObject21 != 0)
                break;
              localObject18 = localObject20;
              k = localObject13;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject18 = localObject21;
          Object localObject26 = localObject20;
          localObject20 = localObject13;
          localObject14 = localObject26;
        }
        while (true)
        {
          if (localObject18 <= localObject20);
          String str = new String(localObject14).intern();
          arrayOfString[j] = localObject14;
          f = arrayOfString;
          return;
          l = 44;
          break label116:
          l = localObject3;
          break label116:
          l = localObject1;
          break label116:
          l = localObject2;
          break label116:
          l = 44;
          break label296:
          l = localObject3;
          break label296:
          l = localObject1;
          break label296:
          l = localObject2;
          break label296:
          localObject4 = 44;
          break label480:
          localObject4 = localObject3;
          break label480:
          localObject4 = localObject1;
          break label480:
          localObject4 = localObject2;
          break label480:
          localObject20 = localObject4;
        }
        localObject18 = localObject4;
      }
      Object localObject18 = localObject4;
    }
  }

  public aw(String paramString1, String paramString2)
  {
    ag localag = ag.b(aw.class);
    this.b = localag;
    String str1 = paramString1;
    this.c = str1;
    Object localObject1 = new java/io/File;
    Object localObject2 = localObject1;
    String str2 = paramString2;
    localObject2.<init>(str2);
    FileChannel localFileChannel = new RandomAccessFile((File)localObject1, "r").getChannel();
    localObject1 = FileChannel.MapMode.READ_ONLY;
    long l1 = 0L;
    long l2 = (int)localFileChannel.size();
    MappedByteBuffer localMappedByteBuffer = localFileChannel.map((FileChannel.MapMode)localObject1, l1, l2);
    this.d = localMappedByteBuffer;
    a();
    this.d.rewind();
    int l = this.d.capacity() - 16;
    int j = 2;
    if (l < j)
      throw new p();
    j = l - 2;
    aw localaw1 = this;
    int i1 = j;
    int i2 = 2;
    int k = localaw1.a(i1, i2).b(16);
    int i3 = k * 4;
    l = l - 2 - i3;
    aw localaw2 = this;
    int i4 = l;
    int i5 = i3;
    k localk = localaw2.a(i4, i5);
    ArrayList localArrayList1 = new ArrayList();
    this.e = localArrayList1;
    l1 = f[2].length();
    int i6 = 0;
    long l3 = l1;
    i3 = i6;
    do
    {
      if (i3 >= k)
        return;
      long l4 = localk.c(32);
      ArrayList localArrayList2 = this.e;
      ByteBuffer localByteBuffer = this.d;
      int i7 = (int)l3;
      Object localObject3;
      int i8 = (int)localObject3;
      i locali = new i(localByteBuffer, i7, i8);
      String str3 = this.c;
      am localam = new am(locali, str3, i3);
      localArrayList2.add(localam);
      long l5 = l3 + localObject3;
      ++i3;
    }
    while (i == 0);
  }

  private k a(int paramInt1, int paramInt2)
  {
    ByteBuffer localByteBuffer = this.d;
    i locali = new i(localByteBuffer, paramInt1, paramInt2);
    return new k(locali);
  }

  private void a()
  {
    int i = 16;
    int j = 2;
    int k = this.d.capacity();
    int l = f[j].length();
    int i1;
    i1 += 16;
    if (k < l)
      throw new p();
    byte[] arrayOfByte1 = new byte[4];
    this.d.get(arrayOfByte1);
    if ((arrayOfByte1[null] != 87) || (arrayOfByte1[1] != 80) || (arrayOfByte1[j] != 83) || (arrayOfByte1[3] != 50))
      throw new p();
    ad localad = new ad();
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = f[j];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = this.c;
    byte[] arrayOfByte2 = str2.getBytes();
    localad.a(arrayOfByte2);
    byte[] arrayOfByte3 = localad.a();
    byte[] arrayOfByte4 = new byte[i];
    ByteBuffer localByteBuffer = this.d;
    int i2 = this.d.capacity() - i;
    localByteBuffer.position(j);
    this.d.get(arrayOfByte4);
    if (Arrays.equals(arrayOfByte4, arrayOfByte3))
      return;
    throw new p();
  }

  public aq a(bv parambv)
  {
    int i = au.a;
    Object localObject = this.e;
    Iterator localIterator = ((ArrayList)localObject).iterator();
    localObject = localIterator.hasNext();
    if (localObject != 0)
      localObject = (am)localIterator.next();
    while (true)
    {
      try
      {
        localObject = ((am)localObject).a(parambv);
        if (localObject == null)
          break label126;
        return localObject;
      }
      catch (IOException localIOException)
      {
        ag localag = this.b;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str1 = f[1];
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(parambv);
        String str2 = f[null];
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str2);
        localObject = ((am)localObject).a();
        localObject = localObject;
        localag.d((String)localObject, localIOException);
      }
      label126: if (i != 0);
      localObject = null;
    }
  }

  protected au a(String paramString1, String paramString2)
  {
    return new aw(paramString1, paramString2);
  }

  public void close()
  {
    this.d = null;
    this.e = null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.aw
 * JD-Core Version:    0.5.4
 */