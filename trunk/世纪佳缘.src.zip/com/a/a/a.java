package com.a.a;

import com.a.af;
import com.a.bu;
import com.a.h;

final class a
  implements bu
{
  final af a;

  a(af paramaf)
  {
  }

  public boolean a(af paramaf)
  {
    h localh1 = this.a.e();
    h localh2 = paramaf.e();
    long l = localh1.b(localh2) < 5000L;
    int i;
    if (localh1 > 0)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.a
 * JD-Core Version:    0.5.4
 */