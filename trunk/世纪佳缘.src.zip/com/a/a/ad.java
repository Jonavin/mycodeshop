package com.a.a;

final class ad
{
  private static final byte[] b;
  private static final String[] f;
  private int[] c;
  private long d;
  private byte[] e;

  static
  {
    int i = 68;
    int j = 61;
    int k = 23;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[5];
    char[] arrayOfChar1 = "\\u\021e![p\032h.V{\037o+Mf纮r0Ha\005y=".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject24;
    Object localObject26;
    Object localObject7;
    Object localObject17;
    int i2;
    int i5;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject16 = localObject1;
      localObject24 = localObject6;
      localObject26 = localObject16;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject16;
      localObject17 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject24)
      {
        i2 = localObject7[arrayOfChar1];
        i5 = localObject26 % 5;
        switch (i5)
        {
        default:
          i5 = i;
          i2 = (char)(i2 ^ i5);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject26 + 1;
          if (localObject24 != 0)
            break;
          localObject7 = localObject17;
          localObject26 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject24;
      Object localObject27 = localObject17;
      localObject17 = localObject2;
      localObject3 = localObject27;
    }
    while (true)
    {
      if (localObject7 <= localObject17);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "Pr\001r%ZrRe-Zr\001u".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject17 = localObject1;
        localObject24 = localObject8;
        localObject26 = localObject17;
        localObject9 = localObject3;
        Object localObject28 = localObject17;
        localObject17 = localObject3;
        Object localObject4;
        for (localObject3 = localObject28; ; localObject4 = localObject24)
        {
          i2 = localObject9[localObject3];
          i5 = localObject26 % 5;
          switch (i5)
          {
          default:
            i5 = i;
            i2 = (char)(i2 ^ i5);
            localObject9[localObject3] = i2;
            localObject4 = localObject26 + 1;
            if (localObject24 != 0)
              break;
            localObject9 = localObject17;
            localObject26 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject24;
        Object localObject29 = localObject17;
        localObject17 = localObject4;
        localObject5 = localObject29;
      }
      while (true)
      {
        if (localObject9 <= localObject17);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "\\u\021".toCharArray();
        Object localObject18 = localObject9.length;
        Object localObject19;
        Object localObject25;
        int i6;
        label479: Object localObject11;
        if (localObject18 <= l)
        {
          localObject24 = localObject1;
          localObject26 = localObject18;
          i2 = localObject24;
          localObject19 = localObject9;
          Object localObject30 = localObject24;
          localObject25 = localObject9;
          Object localObject10;
          for (localObject9 = localObject30; ; localObject10 = localObject26)
          {
            i5 = localObject19[localObject9];
            i6 = i2 % 5;
            switch (i6)
            {
            default:
              i6 = i;
              i5 = (char)(i5 ^ i6);
              localObject19[localObject9] = i5;
              localObject10 = i2 + 1;
              if (localObject26 != 0)
                break;
              localObject19 = localObject25;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject19 = localObject26;
          Object localObject31 = localObject25;
          localObject25 = localObject10;
          localObject11 = localObject31;
        }
        while (true)
        {
          if (localObject19 <= localObject25);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t\f%A5q\013 J8t".toCharArray();
          Object localObject20 = localObject11.length;
          Object localObject21;
          label663: Object localObject13;
          if (localObject20 <= l)
          {
            localObject25 = localObject1;
            localObject26 = localObject20;
            int i3 = localObject25;
            localObject21 = localObject11;
            Object localObject32 = localObject25;
            localObject25 = localObject11;
            Object localObject12;
            for (localObject11 = localObject32; ; localObject12 = localObject26)
            {
              i5 = localObject21[localObject11];
              i6 = i3 % 5;
              switch (i6)
              {
              default:
                i6 = i;
                i5 = (char)(i5 ^ i6);
                localObject21[localObject11] = i5;
                localObject12 = i3 + 1;
                if (localObject26 != 0)
                  break;
                localObject21 = localObject25;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject21 = localObject26;
            Object localObject33 = localObject25;
            localObject25 = localObject12;
            localObject13 = localObject33;
          }
          while (true)
          {
            if (localObject21 <= localObject25);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "|U1E\001{P:H\016v[?O\013mF R\020hA%Y\035gv\020b Xq\025i-W|\036l*Rg\003s7Ib\004v<DmB0v\016#G7s\005.".toCharArray();
            Object localObject22 = localObject13.length;
            label847: Object localObject15;
            if (localObject22 <= l)
            {
              localObject25 = localObject1;
              localObject26 = localObject22;
              int i4 = localObject25;
              localObject23 = localObject13;
              Object localObject34 = localObject25;
              localObject25 = localObject13;
              Object localObject14;
              for (localObject13 = localObject34; ; localObject14 = localObject26)
              {
                i5 = localObject23[localObject13];
                i6 = i4 % 5;
                switch (i6)
                {
                default:
                  i6 = i;
                  int i7 = (char)(i5 ^ i6);
                  localObject23[localObject13] = i5;
                  localObject14 = i4 + 1;
                  if (localObject26 != 0)
                    break;
                  localObject23 = localObject25;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject23 = localObject26;
              Object localObject35 = localObject25;
              localObject25 = localObject14;
              localObject15 = localObject35;
            }
            while (true)
            {
              if (localObject23 <= localObject25);
              String str = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              f = arrayOfString;
              if (!ad.class.desiredAssertionStatus())
                int i8 = l;
              while (true)
              {
                boolean bool = a;
                b = new byte[] { 128, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null };
                return;
                int i9 = localObject1;
              }
              i5 = j;
              break label115:
              i5 = k;
              break label115:
              i5 = 114;
              break label115:
              i5 = l;
              break label115:
              i5 = j;
              break label295:
              i5 = k;
              break label295:
              i5 = 114;
              break label295:
              i5 = l;
              break label295:
              i6 = j;
              break label479:
              i6 = k;
              break label479:
              i6 = 114;
              break label479:
              i6 = l;
              break label479:
              i6 = j;
              break label663:
              i6 = k;
              break label663:
              i6 = 114;
              break label663:
              i6 = l;
              break label663:
              i6 = j;
              break label847:
              i6 = k;
              break label847:
              i6 = 114;
              break label847:
              i6 = l;
              break label847:
              localObject25 = localObject1;
            }
            localObject25 = localObject1;
          }
          localObject25 = localObject1;
        }
        localObject23 = localObject1;
      }
      Object localObject23 = localObject1;
    }
  }

  ad()
  {
    int[] arrayOfInt = new int[4];
    this.c = arrayOfInt;
    byte[] arrayOfByte = new byte[64];
    this.e = arrayOfByte;
    this.c[0] = 1732584193;
    this.c[1] = -271733879;
    this.c[2] = -1732584194;
    this.c[3] = 271733878;
    this.d = 0L;
  }

  private static final int a(int paramInt1, int paramInt2)
  {
    int i = 32;
    int j;
    a = j;
    if ((j == 0) && (((paramInt2 < 0) || (paramInt2 > i))))
      throw new AssertionError();
    if ((paramInt1 == 0) || (paramInt2 == 0) || (paramInt2 == i))
      j = paramInt1;
    while (true)
    {
      return j;
      j = paramInt1 << paramInt2;
      int k = i - paramInt2;
      int l = paramInt1 >>> i;
      j |= i;
    }
  }

  private static final int a(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt1 & paramInt2;
    int j = (paramInt1 ^ 0xFFFFFFFF) & paramInt3;
    return i | j;
  }

  private static final int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return a(a(paramInt2, paramInt3, paramInt4) + paramInt1 + paramInt5, paramInt6);
  }

  private static void a(byte[] paramArrayOfByte, long paramLong)
  {
    int i = 8;
    long l = 255L;
    int j;
    a = j;
    if ((j == 0) && (paramArrayOfByte.length < i))
      throw new AssertionError();
    int k = (byte)(int)(paramLong & l);
    paramArrayOfByte[0] = k;
    int i1 = (byte)(int)(paramLong >> i & l);
    paramArrayOfByte[1] = i1;
    int i2 = (byte)(int)(paramLong >> 16 & l);
    paramArrayOfByte[2] = i2;
    int i3 = (byte)(int)(paramLong >> 24 & l);
    paramArrayOfByte[3] = i3;
    int i4 = (byte)(int)(paramLong >> 32 & l);
    paramArrayOfByte[4] = i4;
    int i5 = (byte)(int)(paramLong >> 40 & l);
    paramArrayOfByte[5] = i5;
    int i6 = (byte)(int)(paramLong >> 48 & l);
    paramArrayOfByte[6] = i6;
    int i7 = (byte)(int)(paramLong >> 56 & l);
    paramArrayOfByte[7] = i7;
  }

  private static void a(byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt)
  {
    int i = 0;
    int j = au.a;
    a = k;
    if (k == 0)
    {
      k = paramInt % 4;
      if (k != 0)
        throw new AssertionError();
    }
    a = k;
    if (k == 0)
    {
      k = paramArrayOfInt.length;
      l = paramInt / 4;
      if (k < l)
        throw new AssertionError();
    }
    a = k;
    if (k == 0)
    {
      k = paramArrayOfByte.length;
      if (k < paramInt)
        throw new AssertionError();
    }
    int k = i;
    int l = i;
    do
    {
      if (k >= paramInt)
        return;
      int i1 = (byte)(paramArrayOfInt[l] & 0xFF);
      paramArrayOfByte[k] = i1;
      int i2 = k + 1;
      int i3 = (byte)(paramArrayOfInt[l] >> 8 & 0xFF);
      paramArrayOfByte[i2] = i3;
      int i4 = k + 2;
      int i5 = (byte)(paramArrayOfInt[l] >> 16 & 0xFF);
      paramArrayOfByte[i4] = i5;
      int i6 = k + 3;
      int i7 = (byte)(paramArrayOfInt[l] >> 24 & 0xFF);
      paramArrayOfByte[i6] = i7;
      ++l;
      k += 4;
    }
    while (j == 0);
  }

  private static void a(int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt)
  {
    int i = 0;
    int j = au.a;
    a = k;
    if (k == 0)
    {
      k = paramInt % 4;
      if (k != 0)
        throw new AssertionError();
    }
    a = k;
    if (k == 0)
    {
      k = paramArrayOfInt.length;
      l = paramInt / 4;
      if (k < l)
        throw new AssertionError();
    }
    a = k;
    if (k == 0)
    {
      k = paramArrayOfByte.length;
      if (k < paramInt)
        throw new AssertionError();
    }
    int k = i;
    int l = i;
    do
    {
      if (k >= paramInt)
        return;
      int i1 = paramArrayOfByte[k] & 0xFF;
      int i2 = k + 1;
      int i3 = paramArrayOfByte[i2] << 8 & 0xFF00;
      int i4 = i1 | i3;
      int i5 = k + 2;
      int i6 = paramArrayOfByte[i5] << 16 & 0xFF0000;
      int i7 = i4 | i6;
      int i8 = k + 3;
      int i9 = paramArrayOfByte[i8] << 24 & 0xFF000000;
      int i10 = i7 | i9;
      paramArrayOfInt[l] = i10;
      ++l;
      k += 4;
    }
    while (j == 0);
  }

  private static final int b(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt1 & paramInt2;
    int j = paramInt1 & paramInt3;
    int k = i | j;
    int l = paramInt2 & paramInt3;
    return k | l;
  }

  private static final int b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return a(b(paramInt2, paramInt3, paramInt4) + paramInt1 + paramInt5 + 1518500249, paramInt6);
  }

  private final void b(byte[] paramArrayOfByte, int paramInt)
  {
    int i;
    a = i;
    if (i == 0)
    {
      int j = paramArrayOfByte.length;
      int k = paramInt + 64;
      if (j < k)
        throw new AssertionError();
    }
    int l = this.c[null];
    int i1 = this.c[1];
    int i2 = this.c[2];
    int i3 = this.c[3];
    int[] arrayOfInt1 = new int[16];
    int[] arrayOfInt2 = arrayOfInt1;
    byte[] arrayOfByte = paramArrayOfByte;
    int i4 = 64;
    a(arrayOfInt2, arrayOfByte, i4);
    int i5 = arrayOfInt1[null];
    int i6 = a(l, i1, i2, i3, i5, 3);
    int i7 = arrayOfInt1[1];
    int i8 = i1;
    int i9 = i2;
    int i10 = a(i3, i6, i8, i9, i7, 7);
    int i11 = arrayOfInt1[2];
    int i12 = i1;
    int i13 = a(i2, i10, i6, i12, i11, 11);
    int i14 = arrayOfInt1[3];
    int i15 = a(i1, i13, i10, i6, i14, 19);
    int i16 = arrayOfInt1[4];
    int i17 = i13;
    int i18 = i10;
    int i19 = a(i6, i15, i17, i18, i16, 3);
    int i20 = arrayOfInt1[5];
    int i21 = i13;
    int i22 = a(i10, i19, i15, i21, i20, 7);
    int i23 = arrayOfInt1[6];
    int i24 = a(i13, i22, i19, i15, i23, 11);
    int i25 = arrayOfInt1[7];
    int i26 = i22;
    int i27 = i19;
    int i28 = a(i15, i24, i26, i27, i25, 19);
    int i29 = arrayOfInt1[8];
    int i30 = i22;
    int i31 = a(i19, i28, i24, i30, i29, 3);
    int i32 = arrayOfInt1[9];
    int i33 = a(i22, i31, i28, i24, i32, 7);
    int i34 = arrayOfInt1[10];
    int i35 = i31;
    int i36 = i28;
    int i37 = a(i24, i33, i35, i36, i34, 11);
    int i38 = arrayOfInt1[11];
    int i39 = i31;
    int i40 = a(i28, i37, i33, i39, i38, 19);
    int i41 = arrayOfInt1[12];
    int i42 = a(i31, i40, i37, i33, i41, 3);
    int i43 = arrayOfInt1[13];
    int i44 = i40;
    int i45 = i37;
    int i46 = a(i33, i42, i44, i45, i43, 7);
    int i47 = arrayOfInt1[14];
    int i48 = i40;
    int i49 = a(i37, i46, i42, i48, i47, 11);
    int i50 = arrayOfInt1[15];
    int i51 = a(i40, i49, i46, i42, i50, 19);
    int i52 = arrayOfInt1[null];
    int i53 = i49;
    int i54 = i46;
    int i55 = b(i42, i51, i53, i54, i52, 3);
    int i56 = arrayOfInt1[4];
    int i57 = i49;
    int i58 = b(i46, i55, i51, i57, i56, 5);
    int i59 = arrayOfInt1[8];
    int i60 = b(i49, i58, i55, i51, i59, 9);
    int i61 = arrayOfInt1[12];
    int i62 = i58;
    int i63 = i55;
    int i64 = b(i51, i60, i62, i63, i61, 13);
    int i65 = arrayOfInt1[1];
    int i66 = i58;
    int i67 = b(i55, i64, i60, i66, i65, 3);
    int i68 = arrayOfInt1[5];
    int i69 = b(i58, i67, i64, i60, i68, 5);
    int i70 = arrayOfInt1[9];
    int i71 = i67;
    int i72 = i64;
    int i73 = b(i60, i69, i71, i72, i70, 9);
    int i74 = arrayOfInt1[13];
    int i75 = i67;
    int i76 = b(i64, i73, i69, i75, i74, 13);
    int i77 = arrayOfInt1[2];
    int i78 = b(i67, i76, i73, i69, i77, 3);
    int i79 = arrayOfInt1[6];
    int i80 = i76;
    int i81 = i73;
    int i82 = b(i69, i78, i80, i81, i79, 5);
    int i83 = arrayOfInt1[10];
    int i84 = i76;
    int i85 = b(i73, i82, i78, i84, i83, 9);
    int i86 = arrayOfInt1[14];
    int i87 = b(i76, i85, i82, i78, i86, 13);
    int i88 = arrayOfInt1[3];
    int i89 = i85;
    int i90 = i82;
    int i91 = b(i78, i87, i89, i90, i88, 3);
    int i92 = arrayOfInt1[7];
    int i93 = i85;
    int i94 = b(i82, i91, i87, i93, i92, 5);
    int i95 = arrayOfInt1[11];
    int i96 = b(i85, i94, i91, i87, i95, 9);
    int i97 = arrayOfInt1[15];
    int i98 = i94;
    int i99 = i91;
    int i100 = b(i87, i96, i98, i99, i97, 13);
    int i101 = arrayOfInt1[null];
    int i102 = i94;
    int i103 = c(i91, i100, i96, i102, i101, 3);
    int i104 = arrayOfInt1[8];
    int i105 = c(i94, i103, i100, i96, i104, 9);
    int i106 = arrayOfInt1[4];
    int i107 = i103;
    int i108 = i100;
    int i109 = c(i96, i105, i107, i108, i106, 11);
    int i110 = arrayOfInt1[12];
    int i111 = i103;
    int i112 = c(i100, i109, i105, i111, i110, 15);
    int i113 = arrayOfInt1[2];
    int i114 = c(i103, i112, i109, i105, i113, 3);
    int i115 = arrayOfInt1[10];
    int i116 = i112;
    int i117 = i109;
    int i118 = c(i105, i114, i116, i117, i115, 9);
    int i119 = arrayOfInt1[6];
    int i120 = i112;
    int i121 = c(i109, i118, i114, i120, i119, 11);
    int i122 = arrayOfInt1[14];
    int i123 = c(i112, i121, i118, i114, i122, 15);
    int i124 = arrayOfInt1[1];
    int i125 = i121;
    int i126 = i118;
    int i127 = c(i114, i123, i125, i126, i124, 3);
    int i128 = arrayOfInt1[9];
    int i129 = i121;
    int i130 = c(i118, i127, i123, i129, i128, 9);
    int i131 = arrayOfInt1[5];
    int i132 = c(i121, i130, i127, i123, i131, 11);
    int i133 = arrayOfInt1[13];
    int i134 = i130;
    int i135 = i127;
    int i136 = c(i123, i132, i134, i135, i133, 15);
    int i137 = arrayOfInt1[3];
    int i138 = i130;
    int i139 = c(i127, i136, i132, i138, i137, 3);
    int i140 = arrayOfInt1[11];
    int i141 = c(i130, i139, i136, i132, i140, 9);
    int i142 = arrayOfInt1[7];
    int i143 = i139;
    int i144 = i136;
    int i145 = c(i132, i141, i143, i144, i142, 11);
    int i146 = arrayOfInt1[15];
    int i147 = i139;
    int i148 = c(i136, i145, i141, i147, i146, 15);
    int[] arrayOfInt3 = this.c;
    int i149 = arrayOfInt3[null] + i139;
    arrayOfInt3[0] = i149;
    int[] arrayOfInt4 = this.c;
    int i150 = arrayOfInt4[1];
    int i151 = i148 + i150;
    arrayOfInt4[1] = i151;
    int[] arrayOfInt5 = this.c;
    int i152 = arrayOfInt5[2] + i145;
    arrayOfInt5[2] = i152;
    int[] arrayOfInt6 = this.c;
    int i153 = arrayOfInt6[3] + i141;
    arrayOfInt6[3] = i153;
  }

  private static final int c(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 ^ paramInt2 ^ paramInt3;
  }

  private static final int c(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return a(c(paramInt2, paramInt3, paramInt4) + paramInt1 + paramInt5 + 1859775393, paramInt6);
  }

  void a(byte[] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length;
    a(paramArrayOfByte, i);
  }

  void a(byte[] paramArrayOfByte, int paramInt)
  {
    int i = 0;
    int j = au.a;
    int k = (int)(this.d >> 3 & 0x3F);
    long l1 = this.d;
    long l2 = paramInt << 3;
    l1 += l2;
    this.d = l1;
    int l = 64 - k;
    if (paramInt >= l)
    {
      byte[] arrayOfByte1 = this.e;
      System.arraycopy(paramArrayOfByte, i, arrayOfByte1, k, l);
      byte[] arrayOfByte2 = this.e;
      b(arrayOfByte2, i);
      do
      {
        if (l + 63 >= paramInt)
          break;
        b(paramArrayOfByte, l);
        l += 64;
        if (j != 0)
          break label176;
      }
      while (j == 0);
      k = l;
      l = i;
      label124: if (j == 0);
    }
    for (j = l; ; j = k)
    {
      k = j;
      j = i;
      while (true)
      {
        byte[] arrayOfByte3 = this.e;
        int i1 = paramInt - j;
        System.arraycopy(paramArrayOfByte, j, arrayOfByte3, k, i1);
        return;
        j = k;
        k = l;
      }
      label176: int i2 = l;
      l = k;
      k = i2;
      break label124:
    }
  }

  byte[] a()
  {
    int i = 56;
    int j = 16;
    int k = 8;
    byte[] arrayOfByte1 = new byte[k];
    long l = this.d;
    a(arrayOfByte1, l);
    int i1 = (int)(this.d >> 3 & 0x3F);
    if (i1 < i);
    for (i1 = i - i1; ; i1 = 120 - i1)
    {
      byte[] arrayOfByte2 = b;
      a(arrayOfByte2, i1);
      a(arrayOfByte1, k);
      byte[] arrayOfByte3 = new byte[j];
      int[] arrayOfInt = this.c;
      a(arrayOfByte1, i1, j);
      return arrayOfByte1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ad
 * JD-Core Version:    0.5.4
 */