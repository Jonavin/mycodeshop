package com.a.a;

import com.a.h;

class cg
  implements aj
{
  private final aj a;
  private h b;
  private h c;
  private bv d;
  private int e;
  private be f;

  cg(aj paramaj, bv parambv)
  {
    this.a = paramaj;
    this.d = parambv;
    h localh = h.d();
    this.b = localh;
    this.c = null;
    this.e = -1;
    this.f = null;
  }

  long a()
  {
    return this.b.c();
  }

  public bv a(bh parambh)
  {
    bv localbv = this.a.a(parambh);
    this.d = localbv;
    h localh = h.d();
    this.b = localh;
    this.f = null;
    return this.d;
  }

  public bv a(ce paramce)
  {
    bv localbv = this.a.a(paramce);
    this.d = localbv;
    h localh = h.d();
    this.c = localh;
    this.b = localh;
    be localbe = (be)paramce;
    this.f = paramce;
    return this.d;
  }

  public bv a(ce paramce, int paramInt)
  {
    this.e = paramInt;
    return a(paramce);
  }

  public void b()
  {
    this.a.b();
    h localh = h.d();
    this.b = localh;
  }

  Long c()
  {
    Object localObject = this.c;
    if (localObject != null)
      localObject = Long.valueOf(this.c.c());
    while (true)
    {
      return localObject;
      int i = 0;
    }
  }

  bv d()
  {
    return this.d;
  }

  int e()
  {
    return this.e;
  }

  be f()
  {
    return this.f;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.cg
 * JD-Core Version:    0.5.4
 */