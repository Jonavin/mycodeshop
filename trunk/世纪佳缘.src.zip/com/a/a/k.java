package com.a.a;

import java.io.EOFException;
import java.io.FilterInputStream;

final class k extends FilterInputStream
{
  private static final int[] b;
  private static final int[] c;
  private static final long[] d;
  private static final long[] e;
  private static final int[] f;
  private static final String j;
  private final i g;
  private int h;
  private int i;

  static
  {
    int k = 7;
    char[] arrayOfChar1 = 0;
    int l = 1;
    char[] arrayOfChar2 = "1g\016\002o5oG\027d1o".toCharArray();
    Object localObject2 = arrayOfChar2.length;
    Object localObject3;
    char[] arrayOfChar5;
    int i3;
    label95: Object localObject1;
    if (localObject2 <= l)
    {
      char[] arrayOfChar4 = arrayOfChar1;
      Object localObject4 = localObject2;
      int i1 = arrayOfChar4;
      localObject3 = arrayOfChar2;
      char[] arrayOfChar6 = arrayOfChar4;
      arrayOfChar5 = arrayOfChar2;
      char[] arrayOfChar3;
      for (arrayOfChar2 = arrayOfChar6; ; arrayOfChar3 = localObject4)
      {
        int i2 = localObject3[arrayOfChar2];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = l;
          int i4 = (char)(i2 ^ i3);
          localObject3[arrayOfChar2] = i2;
          arrayOfChar3 = i1 + 1;
          if (localObject4 != 0)
            break;
          localObject3 = arrayOfChar5;
          i1 = arrayOfChar3;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject3 = localObject4;
      char[] arrayOfChar7 = arrayOfChar5;
      arrayOfChar5 = arrayOfChar3;
      localObject1 = arrayOfChar7;
    }
    while (true)
    {
      if (localObject3 <= arrayOfChar5);
      j = new String(localObject1).intern();
      if (!k.class.desiredAssertionStatus())
        int i5 = l;
      while (true)
      {
        boolean bool = a;
        b = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7 };
        c = new int[] { 255, 63, 31, 15, 7, 3, 1 };
        int tmp1639_1638 = k;
        tmp1639_1638[0] = 0L;
        int tmp1645_1639 = tmp1639_1638;
        tmp1645_1639[1] = 128L;
        int tmp1651_1645 = tmp1645_1639;
        tmp1651_1645[2] = 16512L;
        int tmp1657_1651 = tmp1651_1645;
        tmp1657_1651[3] = 2113664L;
        int tmp1663_1657 = tmp1657_1651;
        tmp1663_1657[4] = 270549120L;
        int tmp1669_1663 = tmp1663_1657;
        tmp1669_1663[5] = 34630287488L;
        int tmp1675_1669 = tmp1669_1663;
        tmp1675_1669[6] = 4432676798592L;
        d = tmp1675_1669;
        65[0] = 0L;
        65[1] = 1L;
        65[2] = 3L;
        65[3] = 7L;
        65[4] = 15L;
        65[5] = 31L;
        65[6] = 63L;
        65[7] = 127L;
        65[8] = 255L;
        65[9] = 511L;
        65[10] = 1023L;
        65[11] = 2047L;
        65[12] = 4095L;
        65[13] = 8191L;
        65[14] = 16383L;
        65[15] = 32767L;
        65[16] = 65535L;
        65[17] = 131071L;
        65[18] = 262143L;
        65[19] = 524287L;
        65[20] = 1048575L;
        65[21] = 2097151L;
        65[22] = 4194303L;
        65[23] = 8388607L;
        65[24] = 16777215L;
        65[25] = 33554431L;
        65[26] = 67108863L;
        65[27] = 134217727L;
        65[28] = 268435455L;
        65[29] = 536870911L;
        65[30] = 1073741823L;
        65[31] = 2147483647L;
        65[32] = -1L;
        65[33] = -1L;
        65[34] = -1L;
        65[35] = -1L;
        65[36] = -1L;
        65[37] = -1L;
        65[38] = -1L;
        65[39] = -1L;
        65[40] = -1L;
        65[41] = -1L;
        65[42] = -1L;
        65[43] = -1L;
        65[44] = -1L;
        65[45] = -1L;
        65[46] = -1L;
        65[47] = -1L;
        65[48] = -1L;
        65[49] = -1L;
        65[50] = -1L;
        65[51] = -1L;
        65[52] = -1L;
        65[53] = -1L;
        65[54] = -1L;
        65[55] = -1L;
        65[56] = -1L;
        65[57] = -1L;
        65[58] = -1L;
        65[59] = -1L;
        65[60] = -1L;
        65[61] = -1L;
        65[62] = -1L;
        65[63] = -1L;
        65[64] = -1L;
        e = 65;
        f = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535, 131071, 262143, 524287, 1048575, 2097151, 4194303, 8388607, 16777215, 33554431, 67108863, 134217727, 268435455, 536870911, 1073741823, 2147483647, -1 };
        return;
        int i6 = arrayOfChar1;
      }
      i3 = 80;
      break label95:
      i3 = 11;
      break label95:
      i3 = 103;
      break label95:
      i3 = 101;
      break label95:
      arrayOfChar5 = arrayOfChar1;
    }
  }

  k(i parami)
  {
    super(parami);
    d();
    this.g = parami;
  }

  public int a()
  {
    int k = this.h;
    int l = this.g.read();
    int i1 = this.i;
    int i2 = l << i1;
    int i3 = k | i2;
    this.h = i3;
    int i4 = this.h & 0xFF;
    int i5 = this.h >>> 8;
    this.h = i5;
    return i4;
  }

  long a(int paramInt)
  {
    int k = 1;
    int l;
    a = l;
    if (l == 0)
    {
      if (k <= paramInt)
      {
        l = 64;
        if (paramInt <= l)
          break label31;
      }
      throw new AssertionError();
    }
    label31: long l1 = c(paramInt);
    int i1 = paramInt - k;
    Object localObject;
    long l2;
    if ((k << i1 & localObject) != 0L)
    {
      long l3 = e[paramInt] ^ 0xFFFF;
      localObject |= l3;
    }
    return l2;
  }

  public int available()
  {
    int k = this.i;
    int l = this.g.available() << 3;
    return k + l;
  }

  int b()
  {
    int k;
    a = k;
    if ((k == 0) && (this.i != 0))
    {
      String str = j;
      throw new AssertionError(str);
    }
    int l = this.g.read();
    int i1 = this.g.read() << 8;
    return l | i1;
  }

  int b(int paramInt)
  {
    int k = au.a;
    int l;
    a = l;
    if (l == 0)
    {
      l = 1;
      if (l <= paramInt)
      {
        i1 = 32;
        if (paramInt <= i1)
          break label35;
      }
      throw new AssertionError();
    }
    label35: int i1 = this.h;
    int i2 = this.i;
    int i3 = i1;
    i1 = i2;
    do
    {
      if (i1 >= paramInt)
        break;
      int i4 = this.g.read() << i1;
      i3 |= i4;
      i1 += 8;
      if (k != 0)
        break label126;
    }
    while (k == 0);
    k = i1;
    int i5 = i3;
    int i6 = i1 >>> paramInt;
    this.h = i3;
    k -= paramInt;
    this.i = k;
    for (k = i1; ; k = i3)
    {
      int i7 = f[paramInt];
      label126: return k & i7;
    }
  }

  long c()
  {
    int k = 32;
    int l;
    a = l;
    if ((l == 0) && (this.i != 0))
    {
      String str = j;
      throw new AssertionError(str);
    }
    int i1 = this.g.read();
    int i2 = this.g.read() << 8;
    int i3 = i1 | i2;
    int i4 = this.g.read() << 16;
    int i5 = i3 | i4;
    int i6 = this.g.read() << 24;
    long l1 = i5 | i6;
    long l2 = e[k];
    long l3 = l1 & l2;
    int i7 = this.g.read();
    int i8 = this.g.read() << 8;
    Object localObject;
    long l4 = (i7 | i8) << localObject;
    return l3 | l4;
  }

  long c(int paramInt)
  {
    int k = au.a;
    int l;
    a = l;
    if (l == 0)
    {
      l = 1;
      if (l <= paramInt)
      {
        i1 = 63;
        if (paramInt <= i1)
          break label35;
      }
      throw new AssertionError();
    }
    label35: long l1 = this.h;
    int i2 = this.i;
    long l2 = l1;
    int i1 = i2;
    do
    {
      if (i1 >= paramInt)
        break;
      long l3 = this.g.read() << l1;
      l2 |= l3;
      i1 += 8;
      if (k != 0)
        break label136;
    }
    while (k == 0);
    k = i1;
    long l4 = l2;
    int i3 = (int)(l1 >>> paramInt);
    this.h = i3;
    k -= paramInt;
    this.i = k;
    long l5 = l1;
    while (true)
    {
      long l6 = e[paramInt];
      return l5 & l6;
      label136: l5 = l2;
    }
  }

  void d()
  {
    this.h = null;
    this.i = null;
  }

  long e()
  {
    int k = au.a;
    int l = available();
    int i1 = 8;
    if (l < i1)
      throw new EOFException();
    i1 = a();
    int i2 = b[i1];
    long l1;
    if (i2 == 0)
      l1 = i1;
    while (true)
    {
      return l1;
      int i3 = i2 << 3;
      if (l <= i3)
        throw new EOFException();
      long l2 = 0L;
      i1 = c[i2] & i1;
      l = i2;
      Object localObject;
      do
      {
        if (l <= 0)
          break;
        int i4 = this.h;
        int i5 = this.g.read();
        int i6 = this.i;
        int i7 = i5 << i6;
        int i8 = i4 | i7;
        this.h = i8;
        i1 = i1 << 8;
        int i9 = this.h & 0xFF;
        i1 |= i9;
        if (k != 0)
          break label223;
        if (l == 4)
        {
          l2 = i1 << 24;
          localObject = null;
        }
        int i10 = this.h >>> 8;
        this.h = i10;
        --l;
      }
      while (k == 0);
      l1 = l2;
      long l3 = localObject;
      l1 |= l2;
      long l4 = d[i2];
      l1 += localObject;
      continue;
      label223: l1 = l2;
    }
  }

  public int read()
  {
    return b(1);
  }

  public void reset()
  {
    d();
    this.g.reset();
  }

  public long skip(long paramLong)
  {
    long l1 = 0L;
    long l2 = null;
    long l3 = paramLong < -1L;
    int k;
    if (k >= 0)
      throw new IllegalArgumentException();
    l3 = paramLong < l1;
    if (k <= 0)
      l3 = l1;
    while (true)
    {
      return l3;
      a = k;
      if (k == 0)
      {
        l3 = available();
        l3 = paramLong < l3;
        if (k > 0)
          throw new AssertionError();
      }
      k = (int)paramLong;
      int l = this.i;
      if (k > l)
      {
        int i1 = this.i;
        k -= i1;
        this.h = l2;
        this.i = l2;
        i locali = this.g;
        long l4 = k >>> 3;
        locali.skip(l2);
        k &= 7;
        if (k <= 0)
          break label217;
        int i2 = this.g.read() >>> k;
        this.h = i2;
        int i3 = 8 - k;
        this.i = i3;
        if (au.a == 0)
          break label217;
      }
      int i4 = this.h >>> k;
      this.h = i4;
      k = this.i - k;
      this.i = k;
      label217: l3 = paramLong;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.k
 * JD-Core Version:    0.5.4
 */