package com.a.a;

import com.a.bv;
import java.io.Closeable;

public abstract class au
  implements Closeable
{
  public static int a;
  private static au b;
  private static final String c;

  static
  {
    int i = 25;
    char[] arrayOfChar1 = "\034x\r>Z_j\006m\016\017k\fmA\013`\023|]".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int j;
    Object localObject3;
    char[] arrayOfChar4;
    int k;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      j = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      k = localObject3[arrayOfChar1];
      l = j % 5;
      switch (l)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int l = 46; ; l = i)
      while (true)
      {
        int i1 = (char)(k ^ l);
        localObject3[arrayOfChar1] = k;
        char[] arrayOfChar2 = j + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          j = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        c = new String(localObject1).intern();
        b = null;
        return;
        l = 127;
        continue;
        l = i;
        continue;
        l = 99;
      }
  }

  public static au b(String paramString1, String paramString2)
  {
    Object localObject = b;
    if (localObject == null);
    for (localObject = new aw(paramString1, paramString2); ; localObject = b.a(paramString1, paramString2))
      return localObject;
  }

  public abstract aq a(bv parambv);

  protected abstract au a(String paramString1, String paramString2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.au
 * JD-Core Version:    0.5.4
 */