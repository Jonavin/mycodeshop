package com.a.a;

import com.a.af;
import com.a.h;

class f
  implements af
{
  static final boolean a;
  private static final String[] h;
  private int b;
  private int c;
  private int d;
  private int e;
  private h g;

  static
  {
    int i = 43;
    int j = 41;
    int k = 24;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[7];
    char[] arrayOfChar1 = "m*MN\016q*LO".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject32;
    Object localObject34;
    Object localObject7;
    Object localObject21;
    int i2;
    int i7;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject20 = localObject1;
      localObject32 = localObject6;
      localObject34 = localObject20;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject20;
      localObject21 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject32)
      {
        i2 = localObject7[arrayOfChar1];
        i7 = localObject34 % 5;
        switch (i7)
        {
        default:
          i7 = 104;
          i2 = (char)(i2 ^ i7);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject34 + 1;
          if (localObject32 != 0)
            break;
          localObject7 = localObject21;
          localObject34 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject32;
      Object localObject35 = localObject21;
      localObject21 = localObject2;
      localObject3 = localObject35;
    }
    while (true)
    {
      if (localObject7 <= localObject21);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "8%NNU".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject21 = localObject1;
        localObject32 = localObject8;
        localObject34 = localObject21;
        localObject9 = localObject3;
        Object localObject36 = localObject21;
        localObject21 = localObject3;
        Object localObject4;
        for (localObject3 = localObject36; ; localObject4 = localObject32)
        {
          i2 = localObject9[localObject3];
          i7 = localObject34 % 5;
          switch (i7)
          {
          default:
            i7 = 104;
            i2 = (char)(i2 ^ i7);
            localObject9[localObject3] = i2;
            localObject4 = localObject34 + 1;
            if (localObject32 != 0)
              break;
            localObject9 = localObject21;
            localObject34 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject32;
        Object localObject37 = localObject21;
        localObject21 = localObject4;
        localObject5 = localObject37;
      }
      while (true)
      {
        if (localObject9 <= localObject21);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "87]J\034q+GJ\032ay".toCharArray();
        Object localObject22 = localObject9.length;
        Object localObject23;
        Object localObject33;
        int i8;
        label480: Object localObject11;
        if (localObject22 <= l)
        {
          localObject32 = localObject1;
          localObject34 = localObject22;
          i2 = localObject32;
          localObject23 = localObject9;
          Object localObject38 = localObject32;
          localObject33 = localObject9;
          Object localObject10;
          for (localObject9 = localObject38; ; localObject10 = localObject34)
          {
            i7 = localObject23[localObject9];
            i8 = i2 % 5;
            switch (i8)
            {
            default:
              i8 = 104;
              i7 = (char)(i7 ^ i8);
              localObject23[localObject9] = i7;
              localObject10 = i2 + 1;
              if (localObject34 != 0)
                break;
              localObject23 = localObject33;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject23 = localObject34;
          Object localObject39 = localObject33;
          localObject33 = localObject10;
          localObject11 = localObject39;
        }
        while (true)
        {
          if (localObject23 <= localObject33);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "8*H[U".toCharArray();
          Object localObject24 = localObject11.length;
          Object localObject25;
          label664: Object localObject13;
          if (localObject24 <= l)
          {
            localObject33 = localObject1;
            localObject34 = localObject24;
            int i3 = localObject33;
            localObject25 = localObject11;
            Object localObject40 = localObject33;
            localObject33 = localObject11;
            Object localObject12;
            for (localObject11 = localObject40; ; localObject12 = localObject34)
            {
              i7 = localObject25[localObject11];
              i8 = i3 % 5;
              switch (i8)
              {
              default:
                i8 = 104;
                i7 = (char)(i7 ^ i8);
                localObject25[localObject11] = i7;
                localObject12 = i3 + 1;
                if (localObject34 != 0)
                  break;
                localObject25 = localObject33;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject25 = localObject34;
            Object localObject41 = localObject33;
            localObject33 = localObject12;
            localObject13 = localObject41;
          }
          while (true)
          {
            if (localObject25 <= localObject33);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "8,YNU".toCharArray();
            Object localObject26 = localObject13.length;
            Object localObject27;
            label848: Object localObject15;
            if (localObject26 <= l)
            {
              localObject33 = localObject1;
              localObject34 = localObject26;
              int i4 = localObject33;
              localObject27 = localObject13;
              Object localObject42 = localObject33;
              localObject33 = localObject13;
              Object localObject14;
              for (localObject13 = localObject42; ; localObject14 = localObject34)
              {
                i7 = localObject27[localObject13];
                i8 = i4 % 5;
                switch (i8)
                {
                default:
                  i8 = 104;
                  i7 = (char)(i7 ^ i8);
                  localObject27[localObject13] = i7;
                  localObject14 = i4 + 1;
                  if (localObject34 != 0)
                    break;
                  localObject27 = localObject33;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject27 = localObject34;
              Object localObject43 = localObject33;
              localObject33 = localObject14;
              localObject15 = localObject43;
            }
            while (true)
            {
              if (localObject27 <= localObject33);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "v1Dx\013y*GN\fY\024Z\026".toCharArray();
              Object localObject28 = localObject15.length;
              Object localObject29;
              label1032: Object localObject17;
              if (localObject28 <= l)
              {
                localObject33 = localObject1;
                localObject34 = localObject28;
                int i5 = localObject33;
                localObject29 = localObject15;
                Object localObject44 = localObject33;
                localObject33 = localObject15;
                Object localObject16;
                for (localObject15 = localObject44; ; localObject16 = localObject34)
                {
                  i7 = localObject29[localObject15];
                  i8 = i5 % 5;
                  switch (i8)
                  {
                  default:
                    i8 = 104;
                    i7 = (char)(i7 ^ i8);
                    localObject29[localObject15] = i7;
                    localObject16 = i5 + 1;
                    if (localObject34 != 0)
                      break;
                    localObject29 = localObject33;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject29 = localObject34;
                Object localObject45 = localObject33;
                localObject33 = localObject16;
                localObject17 = localObject45;
              }
              while (true)
              {
                if (localObject29 <= localObject33);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "v1Dx\013y*GN\fY\024Z\007Hv%Y\007Hy*M\013纮h!\tF\035k0\tN\t{,\tI\r8#[N\tl![\013\034p%G\013\022}6".toCharArray();
                Object localObject30 = localObject17.length;
                label1216: Object localObject19;
                if (localObject30 <= l)
                {
                  localObject33 = localObject1;
                  localObject34 = localObject30;
                  int i6 = localObject33;
                  localObject31 = localObject17;
                  Object localObject46 = localObject33;
                  localObject33 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject46; ; localObject18 = localObject34)
                  {
                    i7 = localObject31[localObject17];
                    i8 = i6 % 5;
                    switch (i8)
                    {
                    default:
                      i8 = 104;
                      int i9 = (char)(i7 ^ i8);
                      localObject31[localObject17] = i7;
                      localObject18 = i6 + 1;
                      if (localObject34 != 0)
                        break;
                      localObject31 = localObject33;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject31 = localObject34;
                  Object localObject47 = localObject33;
                  localObject33 = localObject18;
                  localObject19 = localObject47;
                }
                while (true)
                {
                  if (localObject31 <= localObject33);
                  String str = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  h = arrayOfString;
                  if (!bx.class.desiredAssertionStatus())
                    int i10 = l;
                  while (true)
                  {
                    boolean bool = a;
                    return;
                    int i11 = localObject1;
                  }
                  i7 = k;
                  break label116:
                  i7 = 68;
                  break label116:
                  i7 = j;
                  break label116:
                  i7 = i;
                  break label116:
                  i7 = k;
                  break label296:
                  i7 = 68;
                  break label296:
                  i7 = j;
                  break label296:
                  i7 = i;
                  break label296:
                  i8 = k;
                  break label480:
                  i8 = 68;
                  break label480:
                  i8 = j;
                  break label480:
                  i8 = i;
                  break label480:
                  i8 = k;
                  break label664:
                  i8 = 68;
                  break label664:
                  i8 = j;
                  break label664:
                  i8 = i;
                  break label664:
                  i8 = k;
                  break label848:
                  i8 = 68;
                  break label848:
                  i8 = j;
                  break label848:
                  i8 = i;
                  break label848:
                  i8 = k;
                  break label1032:
                  i8 = 68;
                  break label1032:
                  i8 = j;
                  break label1032:
                  i8 = i;
                  break label1032:
                  i8 = k;
                  break label1216:
                  i8 = 68;
                  break label1216:
                  i8 = j;
                  break label1216:
                  i8 = i;
                  break label1216:
                  localObject33 = localObject1;
                }
                localObject33 = localObject1;
              }
              localObject33 = localObject1;
            }
            localObject33 = localObject1;
          }
          localObject33 = localObject1;
        }
        localObject31 = localObject1;
      }
      Object localObject31 = localObject1;
    }
  }

  f()
  {
  }

  f(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, h paramh)
  {
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt3 < 0))
    {
      String str = h[6];
      throw new IllegalArgumentException(str);
    }
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
    int i;
    if (paramBoolean)
      i = 1;
    while (true)
    {
      this.e = i;
      this.g = paramh;
      return;
      Object localObject = null;
    }
  }

  int a()
  {
    return this.b;
  }

  void a(f paramf)
  {
    int i = this.b;
    int j = paramf.b;
    i += j;
    this.b = i;
    i = this.c;
    int k = paramf.c;
    i += k;
    this.c = i;
    i = this.d;
    int l = paramf.d;
    i += l;
    this.d = i;
    i = this.e;
    int i1 = paramf.e;
    i += i1;
    this.e = i;
    a = i;
    if (i == 0)
    {
      i = this.b;
      if (i < 0)
        throw new AssertionError();
    }
    a = i;
    if (i == 0)
    {
      i = this.c;
      if (i < 0)
        throw new AssertionError();
    }
    a = i;
    if (i == 0)
    {
      i = this.d;
      if (i < 0)
        throw new AssertionError();
    }
    a = i;
    if ((i != 0) || (this.e >= 0))
      return;
    throw new AssertionError();
  }

  int b()
  {
    return this.c;
  }

  int c()
  {
    return this.d;
  }

  int d()
  {
    return this.e;
  }

  public h e()
  {
    return this.g;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = h[5];
    localStringBuilder = localStringBuilder.append(str1);
    int i = this.b;
    localStringBuilder = localStringBuilder.append(i);
    String str2 = h[3];
    localStringBuilder = localStringBuilder.append(str2);
    int j = this.c;
    localStringBuilder = localStringBuilder.append(j);
    String str3 = h[4];
    localStringBuilder = localStringBuilder.append(str3);
    int k = this.d;
    localStringBuilder = localStringBuilder.append(k);
    String str4 = h[2];
    localStringBuilder = localStringBuilder.append(str4);
    int l = this.e;
    localStringBuilder = localStringBuilder.append(l);
    Object localObject = h[1];
    localStringBuilder = localStringBuilder.append((String)localObject);
    localObject = this.g;
    if (localObject == null);
    for (localObject = h[null]; ; localObject = Long.valueOf(this.g.c()))
      return localObject;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.f
 * JD-Core Version:    0.5.4
 */