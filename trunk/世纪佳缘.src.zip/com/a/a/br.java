package com.a.a;

import com.a.bo;
import com.a.h;
import java.util.ArrayList;
import java.util.List;

abstract class br
{
  public static br c()
  {
    return new ba();
  }

  public abstract long a();

  public abstract bo a(g paramg, ArrayList paramArrayList1, ArrayList paramArrayList2, be parambe, boolean paramBoolean1, boolean paramBoolean2, long paramLong, List paramList, h paramh);

  public abstract long b();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.br
 * JD-Core Version:    0.5.4
 */