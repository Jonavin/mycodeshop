package com.a.a;

import java.io.Serializable;
import java.util.Comparator;

public class g
  implements Serializable
{
  static final Comparator a_;
  static final Comparator b;
  static final Comparator c;
  public static boolean d;
  private static final String[] j;
  private double e;
  private boolean f;
  private double g;
  private double h;
  private long i;

  static
  {
    int k = 100;
    int l = 31;
    int i1 = 1;
    Object localObject1 = 0;
    int i2 = 73;
    String[] arrayOfString = new String[4];
    char[] arrayOfChar1 = "r\024".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject20;
    Object localObject22;
    Object localObject7;
    Object localObject15;
    int i4;
    int i6;
    label116: Object localObject3;
    if (localObject6 <= i1)
    {
      Object localObject14 = localObject1;
      localObject20 = localObject6;
      localObject22 = localObject14;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject14;
      localObject15 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject20)
      {
        i4 = localObject7[arrayOfChar1];
        i6 = localObject22 % 5;
        switch (i6)
        {
        default:
          i6 = i2;
          i4 = (char)(i4 ^ i6);
          localObject7[arrayOfChar1] = i4;
          localObject2 = localObject22 + 1;
          if (localObject20 != 0)
            break;
          localObject7 = localObject15;
          localObject22 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject20;
      Object localObject23 = localObject15;
      localObject15 = localObject2;
      localObject3 = localObject23;
    }
    while (true)
    {
      if (localObject7 <= localObject15);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "rG(\b=?".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= i1)
      {
        localObject15 = localObject1;
        localObject20 = localObject8;
        localObject22 = localObject15;
        localObject9 = localObject3;
        Object localObject24 = localObject15;
        localObject15 = localObject3;
        Object localObject4;
        for (localObject3 = localObject24; ; localObject4 = localObject20)
        {
          i4 = localObject9[localObject3];
          i6 = localObject22 % 5;
          switch (i6)
          {
          default:
            i6 = i2;
            i4 = (char)(i4 ^ i6);
            localObject9[localObject3] = i4;
            localObject4 = localObject22 + 1;
            if (localObject20 != 0)
              break;
            localObject9 = localObject15;
            localObject22 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject20;
        Object localObject25 = localObject15;
        localObject15 = localObject4;
        localObject5 = localObject25;
      }
      while (true)
      {
        if (localObject9 <= localObject15);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i1] = localObject5;
        int i3 = 2;
        localObject9 = "3G".toCharArray();
        Object localObject16 = localObject9.length;
        Object localObject17;
        Object localObject21;
        int i7;
        label476: Object localObject11;
        if (localObject16 <= i1)
        {
          localObject20 = localObject1;
          localObject22 = localObject16;
          i4 = localObject20;
          localObject17 = localObject9;
          Object localObject26 = localObject20;
          localObject21 = localObject9;
          Object localObject10;
          for (localObject9 = localObject26; ; localObject10 = localObject22)
          {
            i6 = localObject17[localObject9];
            i7 = i4 % 5;
            switch (i7)
            {
            default:
              i7 = i2;
              i6 = (char)(i6 ^ i7);
              localObject17[localObject9] = i6;
              localObject10 = i4 + 1;
              if (localObject22 != 0)
                break;
              localObject17 = localObject21;
              i4 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject17 = localObject22;
          Object localObject27 = localObject21;
          localObject21 = localObject10;
          localObject11 = localObject27;
        }
        while (true)
        {
          if (localObject17 <= localObject21);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i3] = localObject11;
          i3 = 3;
          localObject11 = "k\017 \027ip\005#\001*kG-\013,l\tn\020iw\006?\001i~G?\005%v\003i\020 r\002".toCharArray();
          Object localObject18 = localObject11.length;
          label660: Object localObject13;
          if (localObject18 <= i1)
          {
            localObject21 = localObject1;
            localObject22 = localObject18;
            int i5 = localObject21;
            localObject19 = localObject11;
            Object localObject28 = localObject21;
            localObject21 = localObject11;
            Object localObject12;
            for (localObject11 = localObject28; ; localObject12 = localObject22)
            {
              i6 = localObject19[localObject11];
              i7 = i5 % 5;
              switch (i7)
              {
              default:
                i7 = i2;
                int i8 = (char)(i6 ^ i7);
                localObject19[localObject11] = i6;
                localObject12 = i5 + 1;
                if (localObject22 != 0)
                  break;
                localObject19 = localObject21;
                i5 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject19 = localObject22;
            Object localObject29 = localObject21;
            localObject21 = localObject12;
            localObject13 = localObject29;
          }
          while (true)
          {
            if (localObject19 <= localObject21);
            String str = new String(localObject13).intern();
            arrayOfString[i3] = localObject13;
            j = arrayOfString;
            a_ = new bj();
            b = new az();
            c = new bc();
            return;
            i6 = l;
            break label116:
            i6 = 103;
            break label116:
            i6 = i2;
            break label116:
            i6 = k;
            break label116:
            i6 = l;
            break label296:
            i6 = 103;
            break label296:
            i6 = i2;
            break label296:
            i6 = k;
            break label296:
            i7 = l;
            break label476:
            i7 = 103;
            break label476:
            i7 = i2;
            break label476:
            i7 = k;
            break label476:
            i7 = l;
            break label660:
            i7 = 103;
            break label660:
            i7 = i2;
            break label660:
            i7 = k;
            break label660:
            localObject21 = localObject1;
          }
          localObject21 = localObject1;
        }
        localObject19 = localObject1;
      }
      Object localObject19 = localObject1;
    }
  }

  protected g()
  {
  }

  protected g(double paramDouble1, double paramDouble2)
  {
    this.g = paramDouble1;
    this.h = ???;
    this.i = 65535L;
  }

  protected g(double paramDouble1, double paramDouble2, long paramLong)
  {
    this.g = paramDouble1;
    this.h = ???;
    this.i = paramDouble2;
  }

  static double a(g paramg)
  {
    return paramg.g;
  }

  static double b(g paramg)
  {
    return paramg.h;
  }

  static long c(g paramg)
  {
    return paramg.i;
  }

  public void a(double paramDouble)
  {
    this.g = paramDouble;
  }

  public void a(long paramLong)
  {
    this.i = paramLong;
  }

  public double a_()
  {
    return this.g;
  }

  public double b()
  {
    return this.h;
  }

  public void b(double paramDouble)
  {
    this.h = paramDouble;
  }

  public long c()
  {
    if (this.i == 65535L)
    {
      String str = j[3];
      throw new UnsupportedOperationException(str);
    }
    return this.i;
  }

  public void c(double paramDouble)
  {
    this.e = paramDouble;
    this.f = true;
  }

  public double d()
  {
    return this.e;
  }

  public boolean f()
  {
    return this.f;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    double d1 = Math.round(a_() * 4711630319722168320L) / 4711630319722168320L;
    localStringBuilder1 = localStringBuilder1.append(d1);
    Object localObject = j[2];
    localStringBuilder1 = localStringBuilder1.append((String)localObject);
    d1 = Math.round(b() * 4711630319722168320L) / 4711630319722168320L;
    localStringBuilder1 = localStringBuilder1.append(d1).append(" ");
    localObject = f();
    String str1;
    if (localObject != 0)
    {
      localObject = new StringBuilder();
      long l1 = this.e;
      localObject = ((StringBuilder)localObject).append(l1);
      str1 = j[1];
    }
    for (localObject = str1; ; localObject = "")
    {
      StringBuilder localStringBuilder2 = localStringBuilder1.append((String)localObject);
      long l2 = this.i;
      StringBuilder localStringBuilder3 = localStringBuilder1.append(localObject);
      String str2 = j[null];
      return (String)localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.g
 * JD-Core Version:    0.5.4
 */