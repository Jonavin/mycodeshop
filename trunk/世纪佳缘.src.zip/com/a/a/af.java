package com.a.a;

import Z;
import com.a.bv;
import java.util.Iterator;
import java.util.LinkedList;

public final class af
{
  static final boolean a;
  private final LinkedList b;
  private final int c;

  static
  {
    if (!af.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  public af(int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    this.b = localLinkedList;
    this.c = paramInt;
  }

  public int a(bv parambv)
  {
    int i = au.a;
    int j = this.b.size();
    Object localObject;
    boolean bool;
    if (j > 0)
    {
      localObject = this.b;
      Iterator localIterator = ((LinkedList)localObject).iterator();
      localObject = localIterator.hasNext();
      if (localObject != 0)
      {
        localObject = (ag)localIterator.next();
        bool = ((ag)localObject).a.equals(parambv);
        if (i != 0)
          break label101;
        if (bool)
        {
          localIterator.remove();
          this.b.addFirst(localObject);
        }
      }
    }
    label101: for (int k = ((ag)localObject).b; ; k = bool)
      while (true)
      {
        return k;
        if (i != 0);
        k = -1;
      }
  }

  public void a(bv parambv, int paramInt)
  {
    int i = -1;
    int j = au.a;
    int k;
    a = k;
    if ((k == 0) && (parambv == null))
      throw new AssertionError();
    a = k;
    if ((k == 0) && (paramInt <= i))
      throw new AssertionError();
    int l = a(parambv);
    int i1;
    if (l > i)
      i1 = 1;
    while (true)
    {
      if (i1 == null)
        break label145;
      a = i1;
      if (i1 != null)
        break;
      boolean bool = ((ag)this.b.getFirst()).a.equals(parambv);
      if (bool)
        break;
      throw new AssertionError();
      localObject1 = null;
    }
    Object localObject1 = (ag)this.b.getFirst();
    ((ag)localObject1).b = paramInt;
    if (j == 0)
      return;
    label145: localObject1 = this.b.size();
    Object localObject2 = this.c;
    if (localObject1 == localObject2)
    {
      localObject1 = (ag)this.b.removeLast();
      ((ag)localObject1).a = parambv;
      ((ag)localObject1).b = paramInt;
      if (j == 0)
        break label207;
    }
    localObject1 = new ag(parambv, paramInt);
    label207: this.b.addFirst(localObject1);
    a = (Z)localObject1;
    if (localObject1 != null)
      return;
    int i2 = this.b.size();
    int i3 = this.c;
    if (i2 <= i3)
      return;
    throw new AssertionError();
  }

  public void b(bv parambv)
  {
    int i = au.a;
    int j = this.b.size();
    if (j <= 0)
      return;
    Iterator localIterator = this.b.iterator();
    do
    {
      if (!localIterator.hasNext())
        return;
      if (!((ag)localIterator.next()).a.equals(parambv))
        continue;
      localIterator.remove();
    }
    while (i == 0);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.af
 * JD-Core Version:    0.5.4
 */