package com.a.a;

import com.a.av;

abstract class m extends q
{
  protected m(av paramav)
  {
    super(paramav);
  }

  public void a(ai paramai, int paramInt1, int paramInt2, aj paramaj)
  {
    ak localak = ak.a;
    long l = paramInt1 * 1000;
    m localm = this;
    ai localai = paramai;
    aj localaj = paramaj;
    localm.a(localai, localak, l, 0, localaj);
  }

  protected boolean a()
  {
    return true;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.m
 * JD-Core Version:    0.5.4
 */