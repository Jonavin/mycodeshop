package com.a.a;

class j
{
  static final int[] a;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.j
 * JD-Core Version:    0.5.4
 */