package com.a.a;

import com.a.ch;
import java.util.List;

abstract interface cf extends cc
{
  public abstract bv a(b paramb, ch paramch, boolean paramBoolean1, boolean paramBoolean2, List paramList);

  public abstract bv a(List paramList, ch paramch);

  public abstract void a();

  public abstract long c();

  public abstract long d();

  public abstract boolean e();

  public abstract void f();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.cf
 * JD-Core Version:    0.5.4
 */