package com.a.a;

public abstract interface aj extends cc
{
  public abstract bv a(ce paramce);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.aj
 * JD-Core Version:    0.5.4
 */