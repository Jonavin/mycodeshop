package com.a.a;

import B;
import com.a.bf;
import com.a.bv;
import java.io.UnsupportedEncodingException;

class am
{
  private static final double a;
  private static final String r;
  private final k b;
  private final String c;
  private final byte[] d;
  private final int e;
  private final int f;
  private final int g;
  private final int h;
  private final long i;
  private final long j;
  private final int k;
  private final int l;
  private final int m;
  private final int n;
  private final int o;
  private final double p;
  private final double q;

  static
  {
    char[] arrayOfChar1 = "\035;h\030r".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i1;
    Object localObject3;
    char[] arrayOfChar4;
    int i2;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i1 = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      i2 = localObject3[arrayOfChar1];
      i3 = i1 % 5;
      switch (i3)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int i3 = 74; ; i3 = 53)
      while (true)
      {
        int i4 = (char)(i2 ^ i3);
        localObject3[arrayOfChar1] = i2;
        char[] arrayOfChar2 = i1 + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i1 = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        r = new String(localObject1).intern();
        a = Math.log(4611686018427387904L);
        return;
        i3 = 72;
        continue;
        i3 = 111;
        continue;
        i3 = 46;
      }
  }

  am(i parami, String paramString, int paramInt)
  {
    this.c = paramString;
    this.e = paramInt;
    Object localObject1 = new k(parami);
    this.b = ((k)localObject1);
    localObject1 = this.b.b(i2);
    if (localObject1 == 0)
      throw new p();
    double d1 = -(localObject1 += 11);
    double d2 = Math.pow(l2, d1);
    Object localObject2;
    this.p = localObject2;
    k localk1 = this.b;
    int i4 = a(4640537203540230144L, localObject1);
    long l3 = localk1.a(i4);
    Object localObject3;
    this.i = localObject3;
    k localk2 = this.b;
    int i5 = a(4645040803167600640L, localObject1);
    long l4 = localk2.a(localObject1);
    Object localObject4;
    this.j = localObject4;
    int i6 = this.b.b(i1);
    this.k = localObject1;
    int i7 = this.b.b(i1);
    this.l = localObject1;
    int i8 = this.b.b(i2);
    this.m = localObject1;
    int i9 = this.b.b(i2);
    this.n = localObject1;
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = Long.toString(this.i);
    StringBuilder localStringBuilder2 = ((StringBuilder)localObject1).append(str1);
    String str2 = Long.toString(this.j);
    StringBuilder localStringBuilder3 = ((StringBuilder)localObject1).append(str2);
    String str3 = this.c;
    String str4 = str3;
    String str5 = r;
    byte[] arrayOfByte = ((String)localObject1).getBytes(str5);
    this.d = ((B)localObject1);
    int i10 = this.k;
    Object localObject5 = this.l;
    int i11 = localObject1 + localObject5;
    Object localObject6 = this.m;
    int i12 = localObject1 + localObject6;
    Object localObject7 = this.n;
    int i13 = localObject1 + localObject7;
    this.o = localObject1;
    if ((this.p == 0L) || (this.i == l1) || (this.j == l1) || (this.k == 0) || (this.l == 0) || (this.m == 0) || (this.k == 0))
      throw new p();
    double d3 = this.n;
    double d4 = Math.pow(l2, d3) - 4607182418800017408L;
    double d5 = 4613937818241073152L * d4;
    this.q = d5;
    this.b.d();
    this.b.e();
    int i14 = (int)this.b.e();
    this.h = i14;
    int i15 = this.h * 8 - 2;
    this.g = i15;
    int i16 = parami.a();
    int i17 = this.b.available() >>> 3;
    int i18 = i16 - i17;
    this.f = i18;
    if (bf.d == 0)
      return;
    au.a = ++i3;
  }

  private static int a(double paramDouble, int paramInt)
  {
    paramInt = null;
    long l1 = 0L;
    double d1 = paramDouble < l1;
    int i1;
    if (i1 == 0);
    int i4;
    for (int i2 = paramInt; ; i4 = paramInt)
      while (true)
      {
        return i2;
        double d2 = Math.log(paramDouble);
        long l2 = a;
        d1 /= l2;
        double d3 = ???;
        d1 += d3;
        if (d1 <= l1)
          break;
        int i3 = (int)Math.ceil(d1);
      }
  }

  private long b(bv parambv)
  {
    Object localObject1 = null;
    Object localObject2 = this.c;
    if (localObject2 != null)
    {
      localObject2 = this.c.length();
      if (localObject2 != 0)
        break label31;
    }
    localObject2 = parambv.a();
    while (true)
    {
      Object localObject3;
      return localObject3;
      try
      {
        label31: localObject2 = parambv.toString().substring(0, 8);
        String str = r;
        localObject2 = ((String)localObject2).getBytes(str);
        ad localad = new ad();
        localad.a(localObject2);
        localObject2 = this.d;
        localad.a(localObject2);
        localObject2 = localad.a();
        long l2 = localObject2[localObject1] << 40 & 0x0;
        long l3 = localObject2[1] << 32 & 0x0;
        long l4 = l2 | localObject1;
        long l5 = localObject2[2] << 24 & 0xFF000000;
        long l6 = l4 | localObject1;
        long l7 = localObject2[3] << 16 & 0xFF0000;
        long l1 = l6 | localObject1;
        long l8 = parambv.a() & 0xFFFFFFFF;
        l1 |= l8;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        throw new RuntimeException(localUnsupportedEncodingException);
      }
    }
  }

  int a()
  {
    return this.e;
  }

  aq a(bv parambv)
  {
    int i1 = au.a;
    long l1 = b(parambv);
    this.b.reset();
    Object localObject2 = this.b;
    long l2 = this.f * 8;
    ((k)localObject2).skip(l2);
    localObject2 = this.b.c();
    Object localObject3 = this.f;
    int i3 = this.g;
    localObject3 = (localObject3 + i3) * 8;
    i3 = this.h;
    if (i3 == 1);
    Object localObject5;
    Object localObject6;
    Object localObject1;
    label103: Object localObject4;
    for (int i4 = this.b.available(); localObject5 > localObject6; localObject4 = null)
    {
      localObject1 = null;
      return localObject1;
    }
    Object localObject7 = 1;
    Object localObject8 = localObject4;
    long l5 = localObject5;
    localObject2 = localObject7;
    Object localObject9 = localObject8;
    label130: Object localObject10 = this.h;
    Object localObject11;
    int i6;
    if (localObject2 < localObject10)
    {
      localObject10 = this.b.c();
      localObject9 = this.b.b();
      long l6 = localObject11 < localObject6;
      if (localObject1 != 0)
        break label575;
      if (i6 <= 0)
        break label207;
    }
    while (true)
    {
      Object localObject12 = this.h;
      label207: int i5;
      if (localObject2 == localObject12)
      {
        long l3 = l5 < localObject6;
        if (localObject2 < 0)
        {
          localObject1 = null;
          break label103:
          localObject3 += localObject9;
          l5 = localObject11 < localObject6;
          if (localObject4 == 0)
          {
            i5 = this.o;
            i5 += 8;
            if (localObject1 == 0)
              break label246;
          }
          ++localObject2;
          if (localObject1 == 0)
            break label568;
          label246: l5 = localObject11;
        }
      }
      this.b.reset();
      localObject2 = this.b;
      long l7 = localObject3;
      ((k)localObject2).skip(l7);
      long l4;
      localObject6 -= l5;
      int i2 = this.b.available() - i5;
      do
      {
        long l8 = this.b.e();
        Object localObject13;
        l4 -= localObject13;
        if (l4 > 0L)
        {
          k localk1 = this.b;
          long l9 = this.o;
          localk1.skip(l9);
          if (localObject1 == 0)
            continue;
        }
        long l10 = l4 < 0L;
        if (localObject1 < 0)
          localObject1 = null;
        l10 = this.i;
        k localk2 = this.b;
        int i7 = this.k;
        long l12 = localk2.b(i7);
        double d1;
        l10 += l12;
        double d3 = this.p * d1;
        long l11 = this.j;
        k localk3 = this.b;
        int i8 = this.l;
        long l13 = localk3.b(i8);
        double d2;
        l11 += l13;
        double d4 = this.p * d2;
        localObject1 = this.b;
        int i9 = this.m;
        int i10 = ((k)localObject1).b(i9) + 18;
        k localk4 = this.b;
        int i11 = this.n;
        double d5 = localk4.b(i11);
        long l14 = this.q;
        double d6 = d5 / l14 + 4595172819793696085L;
        bv localbv = parambv;
        localObject1 = new aq(localbv, d3, d4, i10, d6);
        break label103:
      }
      while (this.b.available() > i2);
      l1 = null;
      if (localObject1 == 0)
        localObject1 = l1;
      localObject1 = l1;
      break label103:
      label568: l5 = localObject11;
      break label130:
      label575: i2 = i6;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.am
 * JD-Core Version:    0.5.4
 */