package com.a.a;

public enum bh
{
  private static final String[] i;

  static
  {
    int j = 29;
    int k = 21;
    int l = 12;
    int i1 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[7];
    char[] arrayOfChar1 = " \\kBP%^wOJ$IjKP%SmST!MqQT5@}".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject32;
    Object localObject34;
    Object localObject7;
    Object localObject21;
    int i3;
    int i8;
    label115: Object localObject3;
    if (localObject6 <= i1)
    {
      Object localObject20 = localObject1;
      localObject32 = localObject6;
      localObject34 = localObject20;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject20;
      localObject21 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject32)
      {
        i3 = localObject7[arrayOfChar1];
        i8 = localObject34 % 5;
        switch (i8)
        {
        default:
          i8 = k;
          i3 = (char)(i3 ^ i8);
          localObject7[arrayOfChar1] = i3;
          localObject2 = localObject34 + 1;
          if (localObject32 != 0)
            break;
          localObject7 = localObject21;
          localObject34 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject32;
      Object localObject35 = localObject21;
      localObject21 = localObject2;
      localObject3 = localObject35;
    }
    while (true)
    {
      if (localObject7 <= localObject21);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = " \\kBZ<".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= i1)
      {
        localObject21 = localObject1;
        localObject32 = localObject8;
        localObject34 = localObject21;
        localObject9 = localObject3;
        Object localObject36 = localObject21;
        localObject21 = localObject3;
        Object localObject4;
        for (localObject3 = localObject36; ; localObject4 = localObject32)
        {
          i3 = localObject9[localObject3];
          i8 = localObject34 % 5;
          switch (i8)
          {
          default:
            i8 = k;
            i3 = (char)(i3 ^ i8);
            localObject9[localObject3] = i3;
            localObject4 = localObject34 + 1;
            if (localObject32 != 0)
              break;
            localObject9 = localObject21;
            localObject34 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject32;
        Object localObject37 = localObject21;
        localObject21 = localObject4;
        localObject5 = localObject37;
      }
      while (true)
      {
        if (localObject9 <= localObject21);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i1] = localObject5;
        int i2 = 2;
        localObject9 = " \\kBP%^wO".toCharArray();
        Object localObject22 = localObject9.length;
        Object localObject23;
        Object localObject33;
        int i9;
        label475: Object localObject11;
        if (localObject22 <= i1)
        {
          localObject32 = localObject1;
          localObject34 = localObject22;
          i3 = localObject32;
          localObject23 = localObject9;
          Object localObject38 = localObject32;
          localObject33 = localObject9;
          Object localObject10;
          for (localObject9 = localObject38; ; localObject10 = localObject34)
          {
            i8 = localObject23[localObject9];
            i9 = i3 % 5;
            switch (i9)
            {
            default:
              i9 = k;
              i8 = (char)(i8 ^ i9);
              localObject23[localObject9] = i8;
              localObject10 = i3 + 1;
              if (localObject34 != 0)
                break;
              localObject23 = localObject33;
              i3 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject23 = localObject34;
          Object localObject39 = localObject33;
          localObject33 = localObject10;
          localObject11 = localObject39;
        }
        while (true)
        {
          if (localObject23 <= localObject33);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i2] = localObject11;
          i2 = 3;
          localObject11 = " \\kBP%^wOJ E~TJ9ClBT!MqQT5@}".toCharArray();
          Object localObject24 = localObject11.length;
          Object localObject25;
          label659: Object localObject13;
          if (localObject24 <= i1)
          {
            localObject33 = localObject1;
            localObject34 = localObject24;
            int i4 = localObject33;
            localObject25 = localObject11;
            Object localObject40 = localObject33;
            localObject33 = localObject11;
            Object localObject12;
            for (localObject11 = localObject40; ; localObject12 = localObject34)
            {
              i8 = localObject25[localObject11];
              i9 = i4 % 5;
              switch (i9)
              {
              default:
                i9 = k;
                i8 = (char)(i8 ^ i9);
                localObject25[localObject11] = i8;
                localObject12 = i4 + 1;
                if (localObject34 != 0)
                  break;
                localObject25 = localObject33;
                i4 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject25 = localObject34;
            Object localObject41 = localObject33;
            localObject33 = localObject12;
            localObject13 = localObject41;
          }
          while (true)
          {
            if (localObject25 <= localObject33);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i2] = localObject13;
            i2 = 4;
            localObject13 = " \\kBP%^wOJ\"ByHA?CjTO2H".toCharArray();
            Object localObject26 = localObject13.length;
            Object localObject27;
            label843: Object localObject15;
            if (localObject26 <= i1)
            {
              localObject33 = localObject1;
              localObject34 = localObject26;
              int i5 = localObject33;
              localObject27 = localObject13;
              Object localObject42 = localObject33;
              localObject33 = localObject13;
              Object localObject14;
              for (localObject13 = localObject42; ; localObject14 = localObject34)
              {
                i8 = localObject27[localObject13];
                i9 = i5 % 5;
                switch (i9)
                {
                default:
                  i9 = k;
                  i8 = (char)(i8 ^ i9);
                  localObject27[localObject13] = i8;
                  localObject14 = i5 + 1;
                  if (localObject34 != 0)
                    break;
                  localObject27 = localObject33;
                  i5 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject27 = localObject34;
              Object localObject43 = localObject33;
              localObject33 = localObject14;
              localObject15 = localObject43;
            }
            while (true)
            {
              if (localObject27 <= localObject33);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i2] = localObject15;
              i2 = 5;
              localObject15 = " \\kBP%^wOJ9CgJ\\1EgT[(^ySR2".toCharArray();
              Object localObject28 = localObject15.length;
              Object localObject29;
              label1027: Object localObject17;
              if (localObject28 <= i1)
              {
                localObject33 = localObject1;
                localObject34 = localObject28;
                int i6 = localObject33;
                localObject29 = localObject15;
                Object localObject44 = localObject33;
                localObject33 = localObject15;
                Object localObject16;
                for (localObject15 = localObject44; ; localObject16 = localObject34)
                {
                  i8 = localObject29[localObject15];
                  i9 = i6 % 5;
                  switch (i9)
                  {
                  default:
                    i9 = k;
                    i8 = (char)(i8 ^ i9);
                    localObject29[localObject15] = i8;
                    localObject16 = i6 + 1;
                    if (localObject34 != 0)
                      break;
                    localObject29 = localObject33;
                    i6 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject29 = localObject34;
                Object localObject45 = localObject33;
                localObject33 = localObject16;
                localObject17 = localObject45;
              }
              while (true)
              {
                if (localObject29 <= localObject33);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i2] = localObject17;
                i2 = 6;
                localObject17 = " \\kBP%^wOJ;C{\\A>CvBV6BvRA(N}BQ2X}OX>B}Y".toCharArray();
                Object localObject30 = localObject17.length;
                label1211: Object localObject19;
                if (localObject30 <= i1)
                {
                  localObject33 = localObject1;
                  localObject34 = localObject30;
                  int i7 = localObject33;
                  localObject31 = localObject17;
                  Object localObject46 = localObject33;
                  localObject33 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject46; ; localObject18 = localObject34)
                  {
                    i8 = localObject31[localObject17];
                    i9 = i7 % 5;
                    switch (i9)
                    {
                    default:
                      i9 = k;
                      int i10 = (char)(i8 ^ i9);
                      localObject31[localObject17] = i8;
                      localObject18 = i7 + 1;
                      if (localObject34 != 0)
                        break;
                      localObject31 = localObject33;
                      i7 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject31 = localObject34;
                  Object localObject47 = localObject33;
                  localObject33 = localObject18;
                  localObject19 = localObject47;
                }
                while (true)
                {
                  if (localObject31 <= localObject33);
                  String str1 = new String(localObject19).intern();
                  arrayOfString[i2] = localObject19;
                  i = arrayOfString;
                  String str2 = i[i1];
                  a = new bh(i2, localObject1);
                  String str3 = i[3];
                  b = new bh(i2, i1);
                  String str4 = i[5];
                  c = new bh(i2, 2);
                  String str5 = i[4];
                  d = new bh(i2, 3);
                  String str6 = i[localObject1];
                  e = new bh(i2, 4);
                  String str7 = i[6];
                  f = new bh(i2, 5);
                  String str8 = i[2];
                  g = new bh(i2, 6);
                  bh[] arrayOfbh = new bh[7];
                  bh localbh1 = a;
                  arrayOfString[localObject1] = i2;
                  bh localbh2 = b;
                  arrayOfString[i1] = i2;
                  bh localbh3 = c;
                  arrayOfString[2] = localObject19;
                  bh localbh4 = d;
                  arrayOfString[3] = localObject19;
                  bh localbh5 = e;
                  arrayOfString[4] = localObject19;
                  bh localbh6 = f;
                  arrayOfString[5] = localObject19;
                  bh localbh7 = g;
                  arrayOfString[6] = localObject19;
                  h = arrayOfString;
                  return;
                  i8 = 119;
                  break label115:
                  i8 = l;
                  break label115:
                  i8 = 56;
                  break label115:
                  i8 = j;
                  break label115:
                  i8 = 119;
                  break label295:
                  i8 = l;
                  break label295:
                  i8 = 56;
                  break label295:
                  i8 = j;
                  break label295:
                  i9 = 119;
                  break label475:
                  i9 = l;
                  break label475:
                  i9 = 56;
                  break label475:
                  i9 = j;
                  break label475:
                  i9 = 119;
                  break label659:
                  i9 = l;
                  break label659:
                  i9 = 56;
                  break label659:
                  i9 = j;
                  break label659:
                  i9 = 119;
                  break label843:
                  i9 = l;
                  break label843:
                  i9 = 56;
                  break label843:
                  i9 = j;
                  break label843:
                  i9 = 119;
                  break label1027:
                  i9 = l;
                  break label1027:
                  i9 = 56;
                  break label1027:
                  i9 = j;
                  break label1027:
                  i9 = 119;
                  break label1211:
                  i9 = l;
                  break label1211:
                  i9 = 56;
                  break label1211:
                  i9 = j;
                  break label1211:
                  localObject33 = localObject1;
                }
                localObject33 = localObject1;
              }
              localObject33 = localObject1;
            }
            localObject33 = localObject1;
          }
          localObject33 = localObject1;
        }
        localObject31 = localObject1;
      }
      Object localObject31 = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bh
 * JD-Core Version:    0.5.4
 */