package com.a.a;

import com.a.af;
import com.a.c;
import com.a.h;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;

class y
  implements Iterable
{
  static final boolean a;
  private static final String e;
  private final long b;
  private final int c;
  private final LinkedList d;

  static
  {
    int i = 1;
    char[] arrayOfChar1 = 0;
    char[] arrayOfChar2 = "\006\007I\036\t\037\034N>\024K\003R(\023K\fB{纮\031\013F/\002\031NS3\006\005N]>\025\004T".toCharArray();
    Object localObject2 = arrayOfChar2.length;
    Object localObject3;
    char[] arrayOfChar5;
    int l;
    label88: Object localObject1;
    if (localObject2 <= i)
    {
      char[] arrayOfChar4 = arrayOfChar1;
      Object localObject4 = localObject2;
      int j = arrayOfChar4;
      localObject3 = arrayOfChar2;
      char[] arrayOfChar6 = arrayOfChar4;
      arrayOfChar5 = arrayOfChar2;
      char[] arrayOfChar3;
      for (arrayOfChar2 = arrayOfChar6; ; arrayOfChar3 = localObject4)
      {
        int k = localObject3[arrayOfChar2];
        l = j % 5;
        switch (l)
        {
        default:
          l = 103;
          int i1 = (char)(k ^ l);
          localObject3[arrayOfChar2] = k;
          arrayOfChar3 = j + 1;
          if (localObject4 != 0)
            break;
          localObject3 = arrayOfChar5;
          j = arrayOfChar3;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject3 = localObject4;
      char[] arrayOfChar7 = arrayOfChar5;
      arrayOfChar5 = arrayOfChar3;
      localObject1 = arrayOfChar7;
    }
    while (true)
    {
      if (localObject3 <= arrayOfChar5);
      e = new String(localObject1).intern();
      if (!y.class.desiredAssertionStatus())
        int i2 = i;
      while (true)
      {
        boolean bool = a;
        return;
        int i3 = arrayOfChar1;
      }
      l = 107;
      break label88:
      l = 110;
      break label88:
      l = 39;
      break label88:
      l = 91;
      break label88:
      arrayOfChar5 = arrayOfChar1;
    }
  }

  y(long paramLong, int paramInt)
  {
    if (??? <= 0)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      String str1 = e;
      String str2 = str1 + ???;
      throw new IllegalArgumentException(str2);
    }
    this.b = paramLong;
    this.c = ???;
    LinkedList localLinkedList = new LinkedList();
    this.d = localLinkedList;
  }

  int a()
  {
    return this.d.size();
  }

  Iterable a(long paramLong, int paramInt, h paramh)
  {
    h paramh;
    if (??? <= 0)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      String str1 = e;
      String str2 = str1 + ???;
      throw new IllegalArgumentException(str2);
    }
    LinkedList localLinkedList = this.d;
    y localy = this;
    int i = ???;
    int j = paramInt;
    long l = paramLong;
    ac localac = new ac(localy, i, j, l);
    return c.b(localLinkedList, localac);
  }

  void a(af paramaf)
  {
    LinkedList localLinkedList1 = this.d;
    localLinkedList1.addFirst(paramaf);
    a = localLinkedList1;
    if (localLinkedList1 != null)
      return;
    LinkedList localLinkedList2 = this.d;
    Comparator localComparator = af.f;
    if (c.a(localLinkedList2, localComparator))
      return;
    throw new AssertionError();
  }

  void a(h paramh)
  {
    int i;
    g.d = i;
    int j = 0;
    Object localObject3 = j;
    label9: int k = this.d.size();
    int l = this.c;
    Object localObject2;
    if (k >= l)
    {
      localObject2 = (af)this.d.getLast();
      if (i != 0)
        break label115;
      long l1 = ((af)localObject2).e().a(paramh);
      long l2 = this.b;
      Object localObject4;
      long l3 = localObject4 < l2;
      if (localObject2 >= 0)
      {
        localObject2 = (af)this.d.removeLast();
        if (i == 0);
      }
    }
    for (Object localObject1 = localObject2; ; localObject1 = localObject3)
    {
      if (localObject2 != 0)
        label88: this.d.addLast(localObject1);
      return;
      localObject3 = localObject2;
      break label9:
      localObject2 = localObject3;
      label115: break label88:
    }
  }

  void b()
  {
    this.d.clear();
  }

  public Iterator iterator()
  {
    return this.d.iterator();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.y
 * JD-Core Version:    0.5.4
 */