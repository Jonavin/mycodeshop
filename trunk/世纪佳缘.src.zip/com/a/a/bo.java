package com.a.a;

import com.a.ag;
import com.a.ba;
import com.a.bk;
import com.a.bv;
import com.a.by;
import com.a.c;
import com.a.f;
import com.a.h;
import com.a.n;
import com.a.t;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

class bo
{
  static final boolean a;
  private static final String[] e;
  private final ag b;
  private final u c;
  private final aa d;

  static
  {
    int i = 53;
    int j = 19;
    int k = 3;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[30];
    char[] arrayOfChar1 = "3v\f`||@>#3u\0258b2tP".toCharArray();
    Object localObject10 = arrayOfChar1.length;
    Object localObject124;
    Object localObject126;
    Object localObject11;
    Object localObject71;
    int i4;
    int i31;
    label116: Object localObject3;
    if (localObject10 <= l)
    {
      Object localObject70 = localObject1;
      localObject124 = localObject10;
      localObject126 = localObject70;
      localObject11 = arrayOfChar1;
      char[] arrayOfChar4 = localObject70;
      localObject71 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar4; ; localObject2 = localObject124)
      {
        i4 = localObject11[arrayOfChar1];
        i31 = localObject126 % 5;
        switch (i31)
        {
        default:
          i31 = 92;
          i4 = (char)(i4 ^ i31);
          localObject11[arrayOfChar1] = i4;
          localObject2 = localObject126 + 1;
          if (localObject124 != 0)
            break;
          localObject11 = localObject71;
          localObject126 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject11 = localObject124;
      Object localObject127 = localObject71;
      localObject71 = localObject2;
      localObject3 = localObject127;
    }
    while (true)
    {
      if (localObject11 <= localObject71);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "3v\fm||@>#3u\0258b2tP".toCharArray();
      Object localObject12 = localObject3.length;
      Object localObject13;
      label296: Object localObject5;
      if (localObject12 <= l)
      {
        localObject71 = localObject1;
        localObject124 = localObject12;
        localObject126 = localObject71;
        localObject13 = localObject3;
        Object localObject128 = localObject71;
        localObject71 = localObject3;
        Object localObject4;
        for (localObject3 = localObject128; ; localObject4 = localObject124)
        {
          i4 = localObject13[localObject3];
          i31 = localObject126 % 5;
          switch (i31)
          {
          default:
            i31 = 92;
            i4 = (char)(i4 ^ i31);
            localObject13[localObject3] = i4;
            localObject4 = localObject126 + 1;
            if (localObject124 != 0)
              break;
            localObject13 = localObject71;
            localObject126 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject13 = localObject124;
        Object localObject129 = localObject71;
        localObject71 = localObject4;
        localObject5 = localObject129;
      }
      while (true)
      {
        if (localObject13 <= localObject71);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject13 = "De\031#0|V+w5|[p#".toCharArray();
        Object localObject72 = localObject13.length;
        Object localObject73;
        Object localObject125;
        int i32;
        label480: Object localObject15;
        if (localObject72 <= l)
        {
          localObject124 = localObject1;
          localObject126 = localObject72;
          i4 = localObject124;
          localObject73 = localObject13;
          Object localObject130 = localObject124;
          localObject125 = localObject13;
          Object localObject14;
          for (localObject13 = localObject130; ; localObject14 = localObject126)
          {
            i31 = localObject73[localObject13];
            i32 = i4 % 5;
            switch (i32)
            {
            default:
              i32 = 92;
              i31 = (char)(i31 ^ i32);
              localObject73[localObject13] = i31;
              localObject14 = i4 + 1;
              if (localObject126 != 0)
                break;
              localObject73 = localObject125;
              i4 = localObject14;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject73 = localObject126;
          Object localObject131 = localObject125;
          localObject125 = localObject14;
          localObject15 = localObject131;
        }
        while (true)
        {
          if (localObject73 <= localObject125);
          localObject73 = new String(localObject15);
          localObject15 = ((String)localObject73).intern();
          arrayOfString[i1] = localObject15;
          char[] arrayOfChar2 = "3g\031P|dT9#0zX#w9w\025>l|>\fzg\036~".toCharArray();
          Object localObject16 = arrayOfChar2.length;
          Object localObject17;
          label664: Object localObject7;
          if (localObject16 <= l)
          {
            localObject73 = localObject1;
            localObject125 = localObject16;
            localObject126 = localObject73;
            localObject17 = arrayOfChar2;
            char[] arrayOfChar5 = localObject73;
            localObject73 = arrayOfChar2;
            Object localObject6;
            for (arrayOfChar2 = arrayOfChar5; ; localObject6 = localObject125)
            {
              i4 = localObject17[arrayOfChar2];
              i31 = localObject126 % 5;
              switch (i31)
              {
              default:
                i31 = 92;
                i4 = (char)(i4 ^ i31);
                localObject17[arrayOfChar2] = i4;
                localObject6 = localObject126 + 1;
                if (localObject125 != 0)
                  break;
                localObject17 = localObject73;
                localObject126 = localObject6;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject17 = localObject125;
            Object localObject132 = localObject73;
            localObject73 = localObject6;
            localObject7 = localObject132;
          }
          while (true)
          {
            if (localObject17 <= localObject73);
            localObject7 = new String(localObject7).intern();
            arrayOfString[k] = localObject7;
            int i2 = 4;
            localObject17 = "3@9j2t\025".toCharArray();
            Object localObject74 = localObject17.length;
            Object localObject75;
            label848: Object localObject19;
            if (localObject74 <= l)
            {
              localObject125 = localObject1;
              localObject126 = localObject74;
              int i5 = localObject125;
              localObject75 = localObject17;
              Object localObject133 = localObject125;
              localObject125 = localObject17;
              Object localObject18;
              for (localObject17 = localObject133; ; localObject18 = localObject126)
              {
                i31 = localObject75[localObject17];
                i32 = i5 % 5;
                switch (i32)
                {
                default:
                  i32 = 92;
                  i31 = (char)(i31 ^ i32);
                  localObject75[localObject17] = i31;
                  localObject18 = i5 + 1;
                  if (localObject126 != 0)
                    break;
                  localObject75 = localObject125;
                  i5 = localObject18;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject75 = localObject126;
              Object localObject134 = localObject125;
              localObject125 = localObject18;
              localObject19 = localObject134;
            }
            while (true)
            {
              if (localObject75 <= localObject125);
              localObject19 = new String(localObject19).intern();
              arrayOfString[i2] = localObject19;
              i2 = 5;
              localObject19 = "3Xep".toCharArray();
              Object localObject76 = localObject19.length;
              Object localObject77;
              label1032: Object localObject21;
              if (localObject76 <= l)
              {
                localObject125 = localObject1;
                localObject126 = localObject76;
                int i6 = localObject125;
                localObject77 = localObject19;
                Object localObject135 = localObject125;
                localObject125 = localObject19;
                Object localObject20;
                for (localObject19 = localObject135; ; localObject20 = localObject126)
                {
                  i31 = localObject77[localObject19];
                  i32 = i6 % 5;
                  switch (i32)
                  {
                  default:
                    i32 = 92;
                    i31 = (char)(i31 ^ i32);
                    localObject77[localObject19] = i31;
                    localObject20 = i6 + 1;
                    if (localObject126 != 0)
                      break;
                    localObject77 = localObject125;
                    i6 = localObject20;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject77 = localObject126;
                Object localObject136 = localObject125;
                localObject125 = localObject20;
                localObject21 = localObject136;
              }
              while (true)
              {
                if (localObject77 <= localObject125);
                localObject21 = new String(localObject21).intern();
                arrayOfString[i2] = localObject21;
                i2 = 6;
                localObject21 = "\\'j(z[-#(|\025&l+3F:f9w".toCharArray();
                Object localObject78 = localObject21.length;
                Object localObject79;
                label1216: Object localObject23;
                if (localObject78 <= l)
                {
                  localObject125 = localObject1;
                  localObject126 = localObject78;
                  int i7 = localObject125;
                  localObject79 = localObject21;
                  Object localObject137 = localObject125;
                  localObject125 = localObject21;
                  Object localObject22;
                  for (localObject21 = localObject137; ; localObject22 = localObject126)
                  {
                    i31 = localObject79[localObject21];
                    i32 = i7 % 5;
                    switch (i32)
                    {
                    default:
                      i32 = 92;
                      i31 = (char)(i31 ^ i32);
                      localObject79[localObject21] = i31;
                      localObject22 = i7 + 1;
                      if (localObject126 != 0)
                        break;
                      localObject79 = localObject125;
                      i7 = localObject22;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject79 = localObject126;
                  Object localObject138 = localObject125;
                  localObject125 = localObject22;
                  localObject23 = localObject138;
                }
                while (true)
                {
                  if (localObject79 <= localObject125);
                  localObject23 = new String(localObject23).intern();
                  arrayOfString[i2] = localObject23;
                  i2 = 7;
                  localObject23 = "`P>w5}Rjp,vP.#(|\0250f.|\025(f?r@9f||Sjs3dP8#.vT.j2tFj>|".toCharArray();
                  Object localObject80 = localObject23.length;
                  Object localObject81;
                  label1400: Object localObject25;
                  if (localObject80 <= l)
                  {
                    localObject125 = localObject1;
                    localObject126 = localObject80;
                    int i8 = localObject125;
                    localObject81 = localObject23;
                    Object localObject139 = localObject125;
                    localObject125 = localObject23;
                    Object localObject24;
                    for (localObject23 = localObject139; ; localObject24 = localObject126)
                    {
                      i31 = localObject81[localObject23];
                      i32 = i8 % 5;
                      switch (i32)
                      {
                      default:
                        i32 = 92;
                        i31 = (char)(i31 ^ i32);
                        localObject81[localObject23] = i31;
                        localObject24 = i8 + 1;
                        if (localObject126 != 0)
                          break;
                        localObject81 = localObject125;
                        i8 = localObject24;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject81 = localObject126;
                    Object localObject140 = localObject125;
                    localObject125 = localObject24;
                    localObject25 = localObject140;
                  }
                  while (true)
                  {
                    if (localObject81 <= localObject125);
                    localObject25 = new String(localObject25).intern();
                    arrayOfString[i2] = localObject25;
                    i2 = 8;
                    localObject25 = "gZ>b03T)`9P8b(zZ$#*rG#b2pPjj/3".toCharArray();
                    Object localObject82 = localObject25.length;
                    Object localObject83;
                    label1584: Object localObject27;
                    if (localObject82 <= l)
                    {
                      localObject125 = localObject1;
                      localObject126 = localObject82;
                      int i9 = localObject125;
                      localObject83 = localObject25;
                      Object localObject141 = localObject125;
                      localObject125 = localObject25;
                      Object localObject26;
                      for (localObject25 = localObject141; ; localObject26 = localObject126)
                      {
                        i31 = localObject83[localObject25];
                        i32 = i9 % 5;
                        switch (i32)
                        {
                        default:
                          i32 = 92;
                          i31 = (char)(i31 ^ i32);
                          localObject83[localObject25] = i31;
                          localObject26 = i9 + 1;
                          if (localObject126 != 0)
                            break;
                          localObject83 = localObject125;
                          i9 = localObject26;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject83 = localObject126;
                      Object localObject142 = localObject125;
                      localObject125 = localObject26;
                      localObject27 = localObject142;
                    }
                    while (true)
                    {
                      if (localObject83 <= localObject125);
                      localObject27 = new String(localObject27).intern();
                      arrayOfString[i2] = localObject27;
                      i2 = 9;
                      localObject27 = "}Z>#/vA>j2t\0259s9vQjl.3F>b(zZ$b.j\0259j2pPjm3g\025/m3fR\"#/rX:o9`\025%q|g\\'f|w\\,e9aP$`93A%l|T8d9".toCharArray();
                      Object localObject84 = localObject27.length;
                      Object localObject85;
                      label1768: Object localObject29;
                      if (localObject84 <= l)
                      {
                        localObject125 = localObject1;
                        localObject126 = localObject84;
                        int i10 = localObject125;
                        localObject85 = localObject27;
                        Object localObject143 = localObject125;
                        localObject125 = localObject27;
                        Object localObject28;
                        for (localObject27 = localObject143; ; localObject28 = localObject126)
                        {
                          i31 = localObject85[localObject27];
                          i32 = i10 % 5;
                          switch (i32)
                          {
                          default:
                            i32 = 92;
                            i31 = (char)(i31 ^ i32);
                            localObject85[localObject27] = i31;
                            localObject28 = i10 + 1;
                            if (localObject126 != 0)
                              break;
                            localObject85 = localObject125;
                            i10 = localObject28;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject85 = localObject126;
                        Object localObject144 = localObject125;
                        localObject125 = localObject28;
                        localObject29 = localObject144;
                      }
                      while (true)
                      {
                        if (localObject85 <= localObject125);
                        localObject29 = new String(localObject29).intern();
                        arrayOfString[i2] = localObject29;
                        i2 = 10;
                        localObject29 = "fF/q|zFjs.|W+a0j\025=b0x\\$d".toCharArray();
                        Object localObject86 = localObject29.length;
                        Object localObject87;
                        label1952: Object localObject31;
                        if (localObject86 <= l)
                        {
                          localObject125 = localObject1;
                          localObject126 = localObject86;
                          int i11 = localObject125;
                          localObject87 = localObject29;
                          Object localObject145 = localObject125;
                          localObject125 = localObject29;
                          Object localObject30;
                          for (localObject29 = localObject145; ; localObject30 = localObject126)
                          {
                            i31 = localObject87[localObject29];
                            i32 = i11 % 5;
                            switch (i32)
                            {
                            default:
                              i32 = 92;
                              i31 = (char)(i31 ^ i32);
                              localObject87[localObject29] = i31;
                              localObject30 = i11 + 1;
                              if (localObject126 != 0)
                                break;
                              localObject87 = localObject125;
                              i11 = localObject30;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject87 = localObject126;
                          Object localObject146 = localObject125;
                          localObject125 = localObject30;
                          localObject31 = localObject146;
                        }
                        while (true)
                        {
                          if (localObject87 <= localObject125);
                          localObject31 = new String(localObject31).intern();
                          arrayOfString[i2] = localObject31;
                          i2 = 11;
                          localObject31 = "3Ijs3dP8B*t\025w#".toCharArray();
                          Object localObject88 = localObject31.length;
                          Object localObject89;
                          label2136: Object localObject33;
                          if (localObject88 <= l)
                          {
                            localObject125 = localObject1;
                            localObject126 = localObject88;
                            int i12 = localObject125;
                            localObject89 = localObject31;
                            Object localObject147 = localObject125;
                            localObject125 = localObject31;
                            Object localObject32;
                            for (localObject31 = localObject147; ; localObject32 = localObject126)
                            {
                              i31 = localObject89[localObject31];
                              i32 = i12 % 5;
                              switch (i32)
                              {
                              default:
                                i32 = 92;
                                i31 = (char)(i31 ^ i32);
                                localObject89[localObject31] = i31;
                                localObject32 = i12 + 1;
                                if (localObject126 != 0)
                                  break;
                                localObject89 = localObject125;
                                i12 = localObject32;
                              case 0:
                              case 1:
                              case 2:
                              case 3:
                              }
                            }
                            localObject89 = localObject126;
                            Object localObject148 = localObject125;
                            localObject125 = localObject32;
                            localObject33 = localObject148;
                          }
                          while (true)
                          {
                            if (localObject89 <= localObject125);
                            localObject33 = new String(localObject33).intern();
                            arrayOfString[i2] = localObject33;
                            i2 = 12;
                            localObject33 = "`P>w5}Rjp,vP.#(|\0250f.|\025(f?r@9f||Sjw4v\025+u9aT-f||W9f.eT>j3}\025w#".toCharArray();
                            Object localObject90 = localObject33.length;
                            Object localObject91;
                            label2320: Object localObject35;
                            if (localObject90 <= l)
                            {
                              localObject125 = localObject1;
                              localObject126 = localObject90;
                              int i13 = localObject125;
                              localObject91 = localObject33;
                              Object localObject149 = localObject125;
                              localObject125 = localObject33;
                              Object localObject34;
                              for (localObject33 = localObject149; ; localObject34 = localObject126)
                              {
                                i31 = localObject91[localObject33];
                                i32 = i13 % 5;
                                switch (i32)
                                {
                                default:
                                  i32 = 92;
                                  i31 = (char)(i31 ^ i32);
                                  localObject91[localObject33] = i31;
                                  localObject34 = i13 + 1;
                                  if (localObject126 != 0)
                                    break;
                                  localObject91 = localObject125;
                                  i13 = localObject34;
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                }
                              }
                              localObject91 = localObject126;
                              Object localObject150 = localObject125;
                              localObject125 = localObject34;
                              localObject35 = localObject150;
                            }
                            while (true)
                            {
                              if (localObject91 <= localObject125);
                              localObject35 = new String(localObject35).intern();
                              arrayOfString[i2] = localObject35;
                              i2 = 13;
                              localObject35 = "}Z>#/vA>j2t\0259s9vQjl.3F>b(zZ$b.j\0259j2pPjm33C+o5w\0258f=w\\$d|vM#p(`".toCharArray();
                              Object localObject92 = localObject35.length;
                              Object localObject93;
                              label2504: Object localObject37;
                              if (localObject92 <= l)
                              {
                                localObject125 = localObject1;
                                localObject126 = localObject92;
                                int i14 = localObject125;
                                localObject93 = localObject35;
                                Object localObject151 = localObject125;
                                localObject125 = localObject35;
                                Object localObject36;
                                for (localObject35 = localObject151; ; localObject36 = localObject126)
                                {
                                  i31 = localObject93[localObject35];
                                  i32 = i14 % 5;
                                  switch (i32)
                                  {
                                  default:
                                    i32 = 92;
                                    i31 = (char)(i31 ^ i32);
                                    localObject93[localObject35] = i31;
                                    localObject36 = i14 + 1;
                                    if (localObject126 != 0)
                                      break;
                                    localObject93 = localObject125;
                                    i14 = localObject36;
                                  case 0:
                                  case 1:
                                  case 2:
                                  case 3:
                                  }
                                }
                                localObject93 = localObject126;
                                Object localObject152 = localObject125;
                                localObject125 = localObject36;
                                localObject37 = localObject152;
                              }
                              while (true)
                              {
                                if (localObject93 <= localObject125);
                                localObject37 = new String(localObject37).intern();
                                arrayOfString[i2] = localObject37;
                                i2 = 14;
                                localObject37 = "De\031#/cP/g|zFj".toCharArray();
                                Object localObject94 = localObject37.length;
                                Object localObject95;
                                label2688: Object localObject39;
                                if (localObject94 <= l)
                                {
                                  localObject125 = localObject1;
                                  localObject126 = localObject94;
                                  int i15 = localObject125;
                                  localObject95 = localObject37;
                                  Object localObject153 = localObject125;
                                  localObject125 = localObject37;
                                  Object localObject38;
                                  for (localObject37 = localObject153; ; localObject38 = localObject126)
                                  {
                                    i31 = localObject95[localObject37];
                                    i32 = i15 % 5;
                                    switch (i32)
                                    {
                                    default:
                                      i32 = 92;
                                      i31 = (char)(i31 ^ i32);
                                      localObject95[localObject37] = i31;
                                      localObject38 = i15 + 1;
                                      if (localObject126 != 0)
                                        break;
                                      localObject95 = localObject125;
                                      i15 = localObject38;
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    }
                                  }
                                  localObject95 = localObject126;
                                  Object localObject154 = localObject125;
                                  localObject125 = localObject38;
                                  localObject39 = localObject154;
                                }
                                while (true)
                                {
                                  if (localObject95 <= localObject125);
                                  localObject39 = new String(localObject39).intern();
                                  arrayOfString[i2] = localObject39;
                                  i2 = 15;
                                  localObject39 = "3Ijb*tt:L>`P8u=g\\%m|.\025".toCharArray();
                                  Object localObject96 = localObject39.length;
                                  Object localObject97;
                                  label2872: Object localObject41;
                                  if (localObject96 <= l)
                                  {
                                    localObject125 = localObject1;
                                    localObject126 = localObject96;
                                    int i16 = localObject125;
                                    localObject97 = localObject39;
                                    Object localObject155 = localObject125;
                                    localObject125 = localObject39;
                                    Object localObject40;
                                    for (localObject39 = localObject155; ; localObject40 = localObject126)
                                    {
                                      i31 = localObject97[localObject39];
                                      i32 = i16 % 5;
                                      switch (i32)
                                      {
                                      default:
                                        i32 = 92;
                                        i31 = (char)(i31 ^ i32);
                                        localObject97[localObject39] = i31;
                                        localObject40 = i16 + 1;
                                        if (localObject126 != 0)
                                          break;
                                        localObject97 = localObject125;
                                        i16 = localObject40;
                                      case 0:
                                      case 1:
                                      case 2:
                                      case 3:
                                      }
                                    }
                                    localObject97 = localObject126;
                                    Object localObject156 = localObject125;
                                    localObject125 = localObject40;
                                    localObject41 = localObject156;
                                  }
                                  while (true)
                                  {
                                    if (localObject97 <= localObject125);
                                    localObject41 = new String(localObject41).intern();
                                    arrayOfString[i2] = localObject41;
                                    i2 = 16;
                                    localObject41 = "fF/q|zFjs.|W+a0j\0259w=g\\%m=aL".toCharArray();
                                    Object localObject98 = localObject41.length;
                                    Object localObject99;
                                    label3056: Object localObject43;
                                    if (localObject98 <= l)
                                    {
                                      localObject125 = localObject1;
                                      localObject126 = localObject98;
                                      int i17 = localObject125;
                                      localObject99 = localObject41;
                                      Object localObject157 = localObject125;
                                      localObject125 = localObject41;
                                      Object localObject42;
                                      for (localObject41 = localObject157; ; localObject42 = localObject126)
                                      {
                                        i31 = localObject99[localObject41];
                                        i32 = i17 % 5;
                                        switch (i32)
                                        {
                                        default:
                                          i32 = 92;
                                          i31 = (char)(i31 ^ i32);
                                          localObject99[localObject41] = i31;
                                          localObject42 = i17 + 1;
                                          if (localObject126 != 0)
                                            break;
                                          localObject99 = localObject125;
                                          i17 = localObject42;
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        }
                                      }
                                      localObject99 = localObject126;
                                      Object localObject158 = localObject125;
                                      localObject125 = localObject42;
                                      localObject43 = localObject158;
                                    }
                                    while (true)
                                    {
                                      if (localObject99 <= localObject125);
                                      localObject43 = new String(localObject43).intern();
                                      arrayOfString[i2] = localObject43;
                                      i2 = 17;
                                      localObject43 = "cZ=f.ET8j=}V/#a3".toCharArray();
                                      Object localObject100 = localObject43.length;
                                      Object localObject101;
                                      label3240: Object localObject45;
                                      if (localObject100 <= l)
                                      {
                                        localObject125 = localObject1;
                                        localObject126 = localObject100;
                                        int i18 = localObject125;
                                        localObject101 = localObject43;
                                        Object localObject159 = localObject125;
                                        localObject125 = localObject43;
                                        Object localObject44;
                                        for (localObject43 = localObject159; ; localObject44 = localObject126)
                                        {
                                          i31 = localObject101[localObject43];
                                          i32 = i18 % 5;
                                          switch (i32)
                                          {
                                          default:
                                            i32 = 92;
                                            i31 = (char)(i31 ^ i32);
                                            localObject101[localObject43] = i31;
                                            localObject44 = i18 + 1;
                                            if (localObject126 != 0)
                                              break;
                                            localObject101 = localObject125;
                                            i18 = localObject44;
                                          case 0:
                                          case 1:
                                          case 2:
                                          case 3:
                                          }
                                        }
                                        localObject101 = localObject126;
                                        Object localObject160 = localObject125;
                                        localObject125 = localObject44;
                                        localObject45 = localObject160;
                                      }
                                      while (true)
                                      {
                                        if (localObject101 <= localObject125);
                                        localObject45 = new String(localObject45).intern();
                                        arrayOfString[i2] = localObject45;
                                        i2 = 18;
                                        localObject45 = "3F+n,P9".toCharArray();
                                        Object localObject102 = localObject45.length;
                                        Object localObject103;
                                        label3424: Object localObject47;
                                        if (localObject102 <= l)
                                        {
                                          localObject125 = localObject1;
                                          localObject126 = localObject102;
                                          int i19 = localObject125;
                                          localObject103 = localObject45;
                                          Object localObject161 = localObject125;
                                          localObject125 = localObject45;
                                          Object localObject46;
                                          for (localObject45 = localObject161; ; localObject46 = localObject126)
                                          {
                                            i31 = localObject103[localObject45];
                                            i32 = i19 % 5;
                                            switch (i32)
                                            {
                                            default:
                                              i32 = 92;
                                              i31 = (char)(i31 ^ i32);
                                              localObject103[localObject45] = i31;
                                              localObject46 = i19 + 1;
                                              if (localObject126 != 0)
                                                break;
                                              localObject103 = localObject125;
                                              i19 = localObject46;
                                            case 0:
                                            case 1:
                                            case 2:
                                            case 3:
                                            }
                                          }
                                          localObject103 = localObject126;
                                          Object localObject162 = localObject125;
                                          localObject125 = localObject46;
                                          localObject47 = localObject162;
                                        }
                                        while (true)
                                        {
                                          if (localObject103 <= localObject125);
                                          localObject103 = new String(localObject47);
                                          localObject47 = ((String)localObject103).intern();
                                          arrayOfString[i2] = localObject47;
                                          char[] arrayOfChar3 = "fF/q|zFjs.|W+a0j\025$l(3F>b(zZ$b.j".toCharArray();
                                          Object localObject48 = arrayOfChar3.length;
                                          Object localObject49;
                                          label3608: Object localObject9;
                                          if (localObject48 <= l)
                                          {
                                            localObject103 = localObject1;
                                            localObject125 = localObject48;
                                            localObject126 = localObject103;
                                            localObject49 = arrayOfChar3;
                                            char[] arrayOfChar6 = localObject103;
                                            localObject103 = arrayOfChar3;
                                            Object localObject8;
                                            for (arrayOfChar3 = arrayOfChar6; ; localObject8 = localObject125)
                                            {
                                              int i20 = localObject49[arrayOfChar3];
                                              i31 = localObject126 % 5;
                                              switch (i31)
                                              {
                                              default:
                                                i31 = 92;
                                                i20 = (char)(i20 ^ i31);
                                                localObject49[arrayOfChar3] = i20;
                                                localObject8 = localObject126 + 1;
                                                if (localObject125 != 0)
                                                  break;
                                                localObject49 = localObject103;
                                                localObject126 = localObject8;
                                              case 0:
                                              case 1:
                                              case 2:
                                              case 3:
                                              }
                                            }
                                            localObject49 = localObject125;
                                            Object localObject163 = localObject103;
                                            localObject103 = localObject8;
                                            localObject9 = localObject163;
                                          }
                                          while (true)
                                          {
                                            if (localObject49 <= localObject103);
                                            localObject9 = new String(localObject9).intern();
                                            arrayOfString[j] = localObject9;
                                            int i3 = 20;
                                            localObject49 = "fF#m;3S#q/g\025#m|r\025x.=c\025)o)`A/q".toCharArray();
                                            Object localObject104 = localObject49.length;
                                            Object localObject105;
                                            label3792: Object localObject51;
                                            if (localObject104 <= l)
                                            {
                                              localObject125 = localObject1;
                                              localObject126 = localObject104;
                                              int i21 = localObject125;
                                              localObject105 = localObject49;
                                              Object localObject164 = localObject125;
                                              localObject125 = localObject49;
                                              Object localObject50;
                                              for (localObject49 = localObject164; ; localObject50 = localObject126)
                                              {
                                                i31 = localObject105[localObject49];
                                                i32 = i21 % 5;
                                                switch (i32)
                                                {
                                                default:
                                                  i32 = 92;
                                                  i31 = (char)(i31 ^ i32);
                                                  localObject105[localObject49] = i31;
                                                  localObject50 = i21 + 1;
                                                  if (localObject126 != 0)
                                                    break;
                                                  localObject105 = localObject125;
                                                  i21 = localObject50;
                                                case 0:
                                                case 1:
                                                case 2:
                                                case 3:
                                                }
                                              }
                                              localObject105 = localObject126;
                                              Object localObject165 = localObject125;
                                              localObject125 = localObject50;
                                              localObject51 = localObject165;
                                            }
                                            while (true)
                                            {
                                              if (localObject105 <= localObject125);
                                              localObject51 = new String(localObject51).intern();
                                              arrayOfString[i3] = localObject51;
                                              i3 = 21;
                                              localObject51 = "fF#m;3]#p(|G3#5}\025+#n>T:#?@9w9a".toCharArray();
                                              Object localObject106 = localObject51.length;
                                              Object localObject107;
                                              label3976: Object localObject53;
                                              if (localObject106 <= l)
                                              {
                                                localObject125 = localObject1;
                                                localObject126 = localObject106;
                                                int i22 = localObject125;
                                                localObject107 = localObject51;
                                                Object localObject166 = localObject125;
                                                localObject125 = localObject51;
                                                Object localObject52;
                                                for (localObject51 = localObject166; ; localObject52 = localObject126)
                                                {
                                                  i31 = localObject107[localObject51];
                                                  i32 = i22 % 5;
                                                  switch (i32)
                                                  {
                                                  default:
                                                    i32 = 92;
                                                    i31 = (char)(i31 ^ i32);
                                                    localObject107[localObject51] = i31;
                                                    localObject52 = i22 + 1;
                                                    if (localObject126 != 0)
                                                      break;
                                                    localObject107 = localObject125;
                                                    i22 = localObject52;
                                                  case 0:
                                                  case 1:
                                                  case 2:
                                                  case 3:
                                                  }
                                                }
                                                localObject107 = localObject126;
                                                Object localObject167 = localObject125;
                                                localObject125 = localObject52;
                                                localObject53 = localObject167;
                                              }
                                              while (true)
                                              {
                                                if (localObject107 <= localObject125);
                                                localObject53 = new String(localObject53).intern();
                                                arrayOfString[i3] = localObject53;
                                                i3 = 22;
                                                localObject53 = "}ZjB\f`\025>l|pY?p(vG".toCharArray();
                                                Object localObject108 = localObject53.length;
                                                Object localObject109;
                                                label4160: Object localObject55;
                                                if (localObject108 <= l)
                                                {
                                                  localObject125 = localObject1;
                                                  localObject126 = localObject108;
                                                  int i23 = localObject125;
                                                  localObject109 = localObject53;
                                                  Object localObject168 = localObject125;
                                                  localObject125 = localObject53;
                                                  Object localObject54;
                                                  for (localObject53 = localObject168; ; localObject54 = localObject126)
                                                  {
                                                    i31 = localObject109[localObject53];
                                                    i32 = i23 % 5;
                                                    switch (i32)
                                                    {
                                                    default:
                                                      i32 = 92;
                                                      i31 = (char)(i31 ^ i32);
                                                      localObject109[localObject53] = i31;
                                                      localObject54 = i23 + 1;
                                                      if (localObject126 != 0)
                                                        break;
                                                      localObject109 = localObject125;
                                                      i23 = localObject54;
                                                    case 0:
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                    }
                                                  }
                                                  localObject109 = localObject126;
                                                  Object localObject169 = localObject125;
                                                  localObject125 = localObject54;
                                                  localObject55 = localObject169;
                                                }
                                                while (true)
                                                {
                                                  if (localObject109 <= localObject125);
                                                  localObject55 = new String(localObject55).intern();
                                                  arrayOfString[i3] = localObject55;
                                                  i3 = 23;
                                                  localObject55 = "fF#m;3]#p(|G3#5}\025+#m>T:#?@9w9a".toCharArray();
                                                  Object localObject110 = localObject55.length;
                                                  Object localObject111;
                                                  label4344: Object localObject57;
                                                  if (localObject110 <= l)
                                                  {
                                                    localObject125 = localObject1;
                                                    localObject126 = localObject110;
                                                    int i24 = localObject125;
                                                    localObject111 = localObject55;
                                                    Object localObject170 = localObject125;
                                                    localObject125 = localObject55;
                                                    Object localObject56;
                                                    for (localObject55 = localObject170; ; localObject56 = localObject126)
                                                    {
                                                      i31 = localObject111[localObject55];
                                                      i32 = i24 % 5;
                                                      switch (i32)
                                                      {
                                                      default:
                                                        i32 = 92;
                                                        i31 = (char)(i31 ^ i32);
                                                        localObject111[localObject55] = i31;
                                                        localObject56 = i24 + 1;
                                                        if (localObject126 != 0)
                                                          break;
                                                        localObject111 = localObject125;
                                                        i24 = localObject56;
                                                      case 0:
                                                      case 1:
                                                      case 2:
                                                      case 3:
                                                      }
                                                    }
                                                    localObject111 = localObject126;
                                                    Object localObject171 = localObject125;
                                                    localObject125 = localObject56;
                                                    localObject57 = localObject171;
                                                  }
                                                  while (true)
                                                  {
                                                    if (localObject111 <= localObject125);
                                                    localObject57 = new String(localObject57).intern();
                                                    arrayOfString[i3] = localObject57;
                                                    i3 = 24;
                                                    localObject57 = "fF#m;3X/g5r[jj23Tj`0fF>f.".toCharArray();
                                                    Object localObject112 = localObject57.length;
                                                    Object localObject113;
                                                    label4528: Object localObject59;
                                                    if (localObject112 <= l)
                                                    {
                                                      localObject125 = localObject1;
                                                      localObject126 = localObject112;
                                                      int i25 = localObject125;
                                                      localObject113 = localObject57;
                                                      Object localObject172 = localObject125;
                                                      localObject125 = localObject57;
                                                      Object localObject58;
                                                      for (localObject57 = localObject172; ; localObject58 = localObject126)
                                                      {
                                                        i31 = localObject113[localObject57];
                                                        i32 = i25 % 5;
                                                        switch (i32)
                                                        {
                                                        default:
                                                          i32 = 92;
                                                          i31 = (char)(i31 ^ i32);
                                                          localObject113[localObject57] = i31;
                                                          localObject58 = i25 + 1;
                                                          if (localObject126 != 0)
                                                            break;
                                                          localObject113 = localObject125;
                                                          i25 = localObject58;
                                                        case 0:
                                                        case 1:
                                                        case 2:
                                                        case 3:
                                                        }
                                                      }
                                                      localObject113 = localObject126;
                                                      Object localObject173 = localObject125;
                                                      localObject125 = localObject58;
                                                      localObject59 = localObject173;
                                                    }
                                                    while (true)
                                                    {
                                                      if (localObject113 <= localObject125);
                                                      localObject59 = new String(localObject59).intern();
                                                      arrayOfString[i3] = localObject59;
                                                      i3 = 25;
                                                      localObject59 = "fF#m;3Tjp5}R&f|rEjj23V&v/gP8".toCharArray();
                                                      Object localObject114 = localObject59.length;
                                                      Object localObject115;
                                                      label4712: Object localObject61;
                                                      if (localObject114 <= l)
                                                      {
                                                        localObject125 = localObject1;
                                                        localObject126 = localObject114;
                                                        int i26 = localObject125;
                                                        localObject115 = localObject59;
                                                        Object localObject174 = localObject125;
                                                        localObject125 = localObject59;
                                                        Object localObject60;
                                                        for (localObject59 = localObject174; ; localObject60 = localObject126)
                                                        {
                                                          i31 = localObject115[localObject59];
                                                          i32 = i26 % 5;
                                                          switch (i32)
                                                          {
                                                          default:
                                                            i32 = 92;
                                                            i31 = (char)(i31 ^ i32);
                                                            localObject115[localObject59] = i31;
                                                            localObject60 = i26 + 1;
                                                            if (localObject126 != 0)
                                                              break;
                                                            localObject115 = localObject125;
                                                            i26 = localObject60;
                                                          case 0:
                                                          case 1:
                                                          case 2:
                                                          case 3:
                                                          }
                                                        }
                                                        localObject115 = localObject126;
                                                        Object localObject175 = localObject125;
                                                        localObject125 = localObject60;
                                                        localObject61 = localObject175;
                                                      }
                                                      while (true)
                                                      {
                                                        if (localObject115 <= localObject125);
                                                        localObject61 = new String(localObject61).intern();
                                                        arrayOfString[i3] = localObject61;
                                                        i3 = 26;
                                                        localObject61 = "}Zj`0fF>f.3S%v2w\025b0|rE9#3a\025'l.v\025+o03S+q|rE+q(:".toCharArray();
                                                        Object localObject116 = localObject61.length;
                                                        Object localObject117;
                                                        label4896: Object localObject63;
                                                        if (localObject116 <= l)
                                                        {
                                                          localObject125 = localObject1;
                                                          localObject126 = localObject116;
                                                          int i27 = localObject125;
                                                          localObject117 = localObject61;
                                                          Object localObject176 = localObject125;
                                                          localObject125 = localObject61;
                                                          Object localObject62;
                                                          for (localObject61 = localObject176; ; localObject62 = localObject126)
                                                          {
                                                            i31 = localObject117[localObject61];
                                                            i32 = i27 % 5;
                                                            switch (i32)
                                                            {
                                                            default:
                                                              i32 = 92;
                                                              i31 = (char)(i31 ^ i32);
                                                              localObject117[localObject61] = i31;
                                                              localObject62 = i27 + 1;
                                                              if (localObject126 != 0)
                                                                break;
                                                              localObject117 = localObject125;
                                                              i27 = localObject62;
                                                            case 0:
                                                            case 1:
                                                            case 2:
                                                            case 3:
                                                            }
                                                          }
                                                          localObject117 = localObject126;
                                                          Object localObject177 = localObject125;
                                                          localObject125 = localObject62;
                                                          localObject63 = localObject177;
                                                        }
                                                        while (true)
                                                        {
                                                          if (localObject117 <= localObject125);
                                                          localObject63 = new String(localObject63).intern();
                                                          arrayOfString[i3] = localObject63;
                                                          i3 = 27;
                                                          localObject63 = "}Zj`0fF>f.3S%v2w\025b1|rE9#:rGjb,rG>/|}Zjk5`A%q%:".toCharArray();
                                                          Object localObject118 = localObject63.length;
                                                          Object localObject119;
                                                          label5080: Object localObject65;
                                                          if (localObject118 <= l)
                                                          {
                                                            localObject125 = localObject1;
                                                            localObject126 = localObject118;
                                                            int i28 = localObject125;
                                                            localObject119 = localObject63;
                                                            Object localObject178 = localObject125;
                                                            localObject125 = localObject63;
                                                            Object localObject64;
                                                            for (localObject63 = localObject178; ; localObject64 = localObject126)
                                                            {
                                                              i31 = localObject119[localObject63];
                                                              i32 = i28 % 5;
                                                              switch (i32)
                                                              {
                                                              default:
                                                                i32 = 92;
                                                                i31 = (char)(i31 ^ i32);
                                                                localObject119[localObject63] = i31;
                                                                localObject64 = i28 + 1;
                                                                if (localObject126 != 0)
                                                                  break;
                                                                localObject119 = localObject125;
                                                                i28 = localObject64;
                                                              case 0:
                                                              case 1:
                                                              case 2:
                                                              case 3:
                                                              }
                                                            }
                                                            localObject119 = localObject126;
                                                            Object localObject179 = localObject125;
                                                            localObject125 = localObject64;
                                                            localObject65 = localObject179;
                                                          }
                                                          while (true)
                                                          {
                                                            if (localObject119 <= localObject125);
                                                            localObject65 = new String(localObject65).intern();
                                                            arrayOfString[i3] = localObject65;
                                                            i3 = 28;
                                                            localObject65 = "}Zj`0fF>f.3S%v2w".toCharArray();
                                                            Object localObject120 = localObject65.length;
                                                            Object localObject121;
                                                            label5264: Object localObject67;
                                                            if (localObject120 <= l)
                                                            {
                                                              localObject125 = localObject1;
                                                              localObject126 = localObject120;
                                                              int i29 = localObject125;
                                                              localObject121 = localObject65;
                                                              Object localObject180 = localObject125;
                                                              localObject125 = localObject65;
                                                              Object localObject66;
                                                              for (localObject65 = localObject180; ; localObject66 = localObject126)
                                                              {
                                                                i31 = localObject121[localObject65];
                                                                i32 = i29 % 5;
                                                                switch (i32)
                                                                {
                                                                default:
                                                                  i32 = 92;
                                                                  i31 = (char)(i31 ^ i32);
                                                                  localObject121[localObject65] = i31;
                                                                  localObject66 = i29 + 1;
                                                                  if (localObject126 != 0)
                                                                    break;
                                                                  localObject121 = localObject125;
                                                                  i29 = localObject66;
                                                                case 0:
                                                                case 1:
                                                                case 2:
                                                                case 3:
                                                                }
                                                              }
                                                              localObject121 = localObject126;
                                                              Object localObject181 = localObject125;
                                                              localObject125 = localObject66;
                                                              localObject67 = localObject181;
                                                            }
                                                            while (true)
                                                            {
                                                              if (localObject121 <= localObject125);
                                                              localObject67 = new String(localObject67).intern();
                                                              arrayOfString[i3] = localObject67;
                                                              i3 = 29;
                                                              localObject67 = "u\\&w9aP.#3QjB\f3".toCharArray();
                                                              Object localObject122 = localObject67.length;
                                                              label5448: Object localObject69;
                                                              if (localObject122 <= l)
                                                              {
                                                                localObject125 = localObject1;
                                                                localObject126 = localObject122;
                                                                int i30 = localObject125;
                                                                localObject123 = localObject67;
                                                                Object localObject182 = localObject125;
                                                                localObject125 = localObject67;
                                                                Object localObject68;
                                                                for (localObject67 = localObject182; ; localObject68 = localObject126)
                                                                {
                                                                  i31 = localObject123[localObject67];
                                                                  i32 = i30 % 5;
                                                                  switch (i32)
                                                                  {
                                                                  default:
                                                                    i32 = 92;
                                                                    int i33 = (char)(i31 ^ i32);
                                                                    localObject123[localObject67] = i31;
                                                                    localObject68 = i30 + 1;
                                                                    if (localObject126 != 0)
                                                                      break;
                                                                    localObject123 = localObject125;
                                                                    i30 = localObject68;
                                                                  case 0:
                                                                  case 1:
                                                                  case 2:
                                                                  case 3:
                                                                  }
                                                                }
                                                                localObject123 = localObject126;
                                                                Object localObject183 = localObject125;
                                                                localObject125 = localObject68;
                                                                localObject69 = localObject183;
                                                              }
                                                              while (true)
                                                              {
                                                                if (localObject123 <= localObject125);
                                                                String str = new String(localObject69).intern();
                                                                arrayOfString[i3] = localObject69;
                                                                e = arrayOfString;
                                                                if (!bo.class.desiredAssertionStatus())
                                                                  int i34 = l;
                                                                while (true)
                                                                {
                                                                  boolean bool = a;
                                                                  return;
                                                                  int i35 = localObject1;
                                                                }
                                                                i31 = j;
                                                                break label116:
                                                                i31 = i;
                                                                break label116:
                                                                i31 = 74;
                                                                break label116:
                                                                i31 = k;
                                                                break label116:
                                                                i31 = j;
                                                                break label296:
                                                                i31 = i;
                                                                break label296:
                                                                i31 = 74;
                                                                break label296:
                                                                i31 = k;
                                                                break label296:
                                                                i32 = j;
                                                                break label480:
                                                                i32 = i;
                                                                break label480:
                                                                i32 = 74;
                                                                break label480:
                                                                i32 = k;
                                                                break label480:
                                                                i31 = j;
                                                                break label664:
                                                                i31 = i;
                                                                break label664:
                                                                i31 = 74;
                                                                break label664:
                                                                i31 = k;
                                                                break label664:
                                                                i32 = j;
                                                                break label848:
                                                                i32 = i;
                                                                break label848:
                                                                i32 = 74;
                                                                break label848:
                                                                i32 = k;
                                                                break label848:
                                                                i32 = j;
                                                                break label1032:
                                                                i32 = i;
                                                                break label1032:
                                                                i32 = 74;
                                                                break label1032:
                                                                i32 = k;
                                                                break label1032:
                                                                i32 = j;
                                                                break label1216:
                                                                i32 = i;
                                                                break label1216:
                                                                i32 = 74;
                                                                break label1216:
                                                                i32 = k;
                                                                break label1216:
                                                                i32 = j;
                                                                break label1400:
                                                                i32 = i;
                                                                break label1400:
                                                                i32 = 74;
                                                                break label1400:
                                                                i32 = k;
                                                                break label1400:
                                                                i32 = j;
                                                                break label1584:
                                                                i32 = i;
                                                                break label1584:
                                                                i32 = 74;
                                                                break label1584:
                                                                i32 = k;
                                                                break label1584:
                                                                i32 = j;
                                                                break label1768:
                                                                i32 = i;
                                                                break label1768:
                                                                i32 = 74;
                                                                break label1768:
                                                                i32 = k;
                                                                break label1768:
                                                                i32 = j;
                                                                break label1952:
                                                                i32 = i;
                                                                break label1952:
                                                                i32 = 74;
                                                                break label1952:
                                                                i32 = k;
                                                                break label1952:
                                                                i32 = j;
                                                                break label2136:
                                                                i32 = i;
                                                                break label2136:
                                                                i32 = 74;
                                                                break label2136:
                                                                i32 = k;
                                                                break label2136:
                                                                i32 = j;
                                                                break label2320:
                                                                i32 = i;
                                                                break label2320:
                                                                i32 = 74;
                                                                break label2320:
                                                                i32 = k;
                                                                break label2320:
                                                                i32 = j;
                                                                break label2504:
                                                                i32 = i;
                                                                break label2504:
                                                                i32 = 74;
                                                                break label2504:
                                                                i32 = k;
                                                                break label2504:
                                                                i32 = j;
                                                                break label2688:
                                                                i32 = i;
                                                                break label2688:
                                                                i32 = 74;
                                                                break label2688:
                                                                i32 = k;
                                                                break label2688:
                                                                i32 = j;
                                                                break label2872:
                                                                i32 = i;
                                                                break label2872:
                                                                i32 = 74;
                                                                break label2872:
                                                                i32 = k;
                                                                break label2872:
                                                                i32 = j;
                                                                break label3056:
                                                                i32 = i;
                                                                break label3056:
                                                                i32 = 74;
                                                                break label3056:
                                                                i32 = k;
                                                                break label3056:
                                                                i32 = j;
                                                                break label3240:
                                                                i32 = i;
                                                                break label3240:
                                                                i32 = 74;
                                                                break label3240:
                                                                i32 = k;
                                                                break label3240:
                                                                i32 = j;
                                                                break label3424:
                                                                i32 = i;
                                                                break label3424:
                                                                i32 = 74;
                                                                break label3424:
                                                                i32 = k;
                                                                break label3424:
                                                                i31 = j;
                                                                break label3608:
                                                                i31 = i;
                                                                break label3608:
                                                                i31 = 74;
                                                                break label3608:
                                                                i31 = k;
                                                                break label3608:
                                                                i32 = j;
                                                                break label3792:
                                                                i32 = i;
                                                                break label3792:
                                                                i32 = 74;
                                                                break label3792:
                                                                i32 = k;
                                                                break label3792:
                                                                i32 = j;
                                                                break label3976:
                                                                i32 = i;
                                                                break label3976:
                                                                i32 = 74;
                                                                break label3976:
                                                                i32 = k;
                                                                break label3976:
                                                                i32 = j;
                                                                break label4160:
                                                                i32 = i;
                                                                break label4160:
                                                                i32 = 74;
                                                                break label4160:
                                                                i32 = k;
                                                                break label4160:
                                                                i32 = j;
                                                                break label4344:
                                                                i32 = i;
                                                                break label4344:
                                                                i32 = 74;
                                                                break label4344:
                                                                i32 = k;
                                                                break label4344:
                                                                i32 = j;
                                                                break label4528:
                                                                i32 = i;
                                                                break label4528:
                                                                i32 = 74;
                                                                break label4528:
                                                                i32 = k;
                                                                break label4528:
                                                                i32 = j;
                                                                break label4712:
                                                                i32 = i;
                                                                break label4712:
                                                                i32 = 74;
                                                                break label4712:
                                                                i32 = k;
                                                                break label4712:
                                                                i32 = j;
                                                                break label4896:
                                                                i32 = i;
                                                                break label4896:
                                                                i32 = 74;
                                                                break label4896:
                                                                i32 = k;
                                                                break label4896:
                                                                i32 = j;
                                                                break label5080:
                                                                i32 = i;
                                                                break label5080:
                                                                i32 = 74;
                                                                break label5080:
                                                                i32 = k;
                                                                break label5080:
                                                                i32 = j;
                                                                break label5264:
                                                                i32 = i;
                                                                break label5264:
                                                                i32 = 74;
                                                                break label5264:
                                                                i32 = k;
                                                                break label5264:
                                                                i32 = j;
                                                                break label5448:
                                                                i32 = i;
                                                                break label5448:
                                                                i32 = 74;
                                                                break label5448:
                                                                i32 = k;
                                                                break label5448:
                                                                localObject125 = localObject1;
                                                              }
                                                              localObject125 = localObject1;
                                                            }
                                                            localObject125 = localObject1;
                                                          }
                                                          localObject125 = localObject1;
                                                        }
                                                        localObject125 = localObject1;
                                                      }
                                                      localObject125 = localObject1;
                                                    }
                                                    localObject125 = localObject1;
                                                  }
                                                  localObject125 = localObject1;
                                                }
                                                localObject125 = localObject1;
                                              }
                                              localObject125 = localObject1;
                                            }
                                            localObject123 = localObject1;
                                          }
                                          localObject125 = localObject1;
                                        }
                                        localObject125 = localObject1;
                                      }
                                      localObject125 = localObject1;
                                    }
                                    localObject125 = localObject1;
                                  }
                                  localObject125 = localObject1;
                                }
                                localObject125 = localObject1;
                              }
                              localObject125 = localObject1;
                            }
                            localObject125 = localObject1;
                          }
                          localObject125 = localObject1;
                        }
                        localObject125 = localObject1;
                      }
                      localObject125 = localObject1;
                    }
                    localObject125 = localObject1;
                  }
                  localObject125 = localObject1;
                }
                localObject125 = localObject1;
              }
              localObject125 = localObject1;
            }
            localObject123 = localObject1;
          }
          localObject125 = localObject1;
        }
        localObject123 = localObject1;
      }
      Object localObject123 = localObject1;
    }
  }

  bo()
  {
    ag localag = ag.b(bo.class);
    this.b = localag;
    u localu = new u(42);
    this.c = localu;
    aa localaa = new aa(10000L);
    this.d = localaa;
  }

  private static double a(g paramg1, g paramg2)
  {
    double d1 = paramg1.a_();
    double d2 = paramg2.a_();
    Object localObject1;
    Object localObject2;
    double d3 = Math.abs(localObject1 - localObject2);
    double d4 = paramg1.b();
    double d5 = paramg2.b();
    Object localObject3;
    Object localObject4;
    double d6 = Math.abs(localObject3 - localObject4);
    Object localObject5;
    Object localObject6;
    return localObject5 + localObject6;
  }

  private double a(Iterable paramIterable)
  {
    int i;
    g.d = i;
    long l1 = 0L;
    Iterator localIterator = paramIterable.iterator();
    long l2 = 0L;
    long l3 = 0L;
    long l4 = l2;
    while (true)
    {
      double d3;
      double d1;
      if (localIterator.hasNext())
      {
        double d2 = ((n)localIterator.next()).a();
        l3 += 1L;
        Object localObject;
        d3 = localObject - l1;
        double d4 = l3;
        d3 = d3 / d4 + l1;
        double d5 = localObject - l1;
        double d6 = localObject - d3;
        double d7 = l1 * d6;
        l4 += l1;
        if (i != 0)
          break label152;
        if (i == 0)
          break label160;
      }
      long l5 = d1;
      long l7 = l3;
      double d8;
      if (l7 > 1L)
      {
        double d9 = l7 - 1L;
        l5 /= l7;
      }
      while (true)
      {
        return d8;
        label152: long l6 = 0L;
      }
      label160: l1 = d3;
    }
  }

  private static int a(ArrayList paramArrayList1, ArrayList paramArrayList2, bn parambn, h paramh)
  {
    int i;
    g.d = i;
    int j;
    a = j;
    boolean bool;
    if (j == 0)
    {
      bool = paramArrayList2.isEmpty();
      if (bool)
        throw new AssertionError();
    }
    a = bool;
    if (!bool)
    {
      localObject1 = f.a;
      ArrayList localArrayList1 = paramArrayList1;
      ArrayList localArrayList2 = paramArrayList2;
      Object localObject3 = localObject1;
      localObject1 = c.a(localArrayList1, localArrayList2, localObject3);
      if (localObject1 != 0)
        throw new AssertionError();
    }
    ArrayList localArrayList3 = paramArrayList2;
    int l = 0;
    double d1 = ((aq)localArrayList3.get(l)).g();
    ArrayList localArrayList4 = paramArrayList1;
    int i1 = 0;
    Object localObject1 = (by)localArrayList4.get(i1);
    int i2 = ((by)localObject1).b();
    long l1 = 0L;
    Object localObject4 = paramArrayList2.iterator();
    long l2 = 0L;
    Object localObject5;
    long l4 = localObject5;
    long l3 = l2;
    long l5 = 0L;
    long l6 = 0L;
    long l7 = l5;
    double d7;
    double d5;
    double d2;
    double d4;
    double d3;
    do
    {
      localObject1 = ((Iterator)localObject4).hasNext();
      if (localObject1 == 0)
        break;
      localObject1 = (aq)((Iterator)localObject4).next();
      double d6 = ((aq)localObject1).g() < l4;
      if (i != 0)
        break label1142;
      int i3;
      if (i3 < 0)
        double d8 = ((aq)localObject1).g();
      d7 = ((aq)localObject1).a_();
      l7 += d6;
      d7 = ((aq)localObject1).b();
      l1 += d6;
      d7 = ((aq)localObject1).a_();
      double d9 = ((aq)localObject1).a_();
      Object localObject6;
      d6 *= localObject6;
      l6 += d6;
      d7 = ((aq)localObject1).b();
      double d10 = ((aq)localObject1).b();
      Object localObject7;
      d6 *= localObject7;
      l3 += d6;
    }
    while (i == 0);
    paramArrayList1 = paramArrayList1.iterator();
    localObject1 = i2;
    long l8 = d2;
    long l9 = d5;
    long l10 = d4;
    long l12 = l8;
    long l13 = l4;
    label338: ArrayList localArrayList5 = paramArrayList1.hasNext();
    ArrayList localArrayList6 = paramArrayList1;
    paramArrayList1 = localArrayList5;
    ArrayList localArrayList7 = localObject1;
    localObject1 = localArrayList6;
    l4 = l13;
    ArrayList localArrayList8 = localArrayList7;
    while (true)
    {
      if (paramArrayList1 != 0)
      {
        paramArrayList1 = (by)((Iterator)localObject1).next();
        localObject4 = paramArrayList1.b();
        if (i == 0)
        {
          int i5 = localObject4;
          int i6 = localArrayList8;
          if (i5 > i6)
          {
            paramArrayList1 = paramArrayList1.b();
            label414: if (i == 0);
          }
        }
      }
      while (true)
      {
        ArrayList localArrayList9 = paramArrayList2.size();
        paramArrayList2 = paramArrayList1;
        paramArrayList1 = localArrayList9;
        while (true)
        {
          long l14 = paramArrayList1;
          l10 /= l14;
          double d12 = l9 * l9;
          double d13 = l14 * l14;
          double d14 = l9 / d13;
          d11 -= l9;
          d3 = d3 / l14 + d11;
          double d11 = l12 * l12;
          double d15 = l14 * l14;
          d11 /= l12;
          d3 -= d11;
          l11 = 0L;
          bn localbn = parambn;
          h localh = paramh;
          long l15 = 20000L;
          paramArrayList1 = localbn.a(localh, l15);
          if (paramArrayList1 != null)
          {
            double d16 = (l4 - 4595172939889686149L) / 4599677620380967213L;
            double d17 = Math.pow(4622382067542392832L, d16) - 4616977747989548237L;
            double d18 = 4602678819172646912L * d17 / 4614275588213125939L;
            double d19 = Math.sqrt(4607182418800017408L / l14) - 4601778099247172813L;
            double d20 = 4599075939470750515L * d19 / 4595653203753948938L;
            double d21 = d18 + d20;
            double d22 = 4711630319722168320L * d3 - 4613262278296967578L;
            double d23 = 4598175219545276416L * d22 / 4617315517961601024L;
            double d24 = d21 + d23;
            paramArrayList1 = -paramArrayList2 - 75;
            long l16 = paramArrayList1;
            double d25 = 4596373779694328218L * l16 / 4619567317775286272L;
            double d26 = d24 + d25;
            parambn = 4631811479262199808L * d26 / 4608308318706860032L + 4638003928749834240L;
          }
          while (true)
          {
            paramArrayList1 = parambn < 0L;
            if (paramArrayList1 == 0)
            {
              parambn = 4607182418800017408L;
              paramArrayList1 = l14 < parambn;
              if (paramArrayList1 == 0)
              {
                double d27 = (l4 - 4595172939889686149L) / 4599677620380967213L;
                double d28 = Math.pow(4622382067542392832L, d27) - 4619004367821864960L;
                double d29 = 4599976659396224614L * d28 / 4613239760298830725L + 4595876582295466515L;
                paramArrayList1 = -paramArrayList2 - 80;
                long l17 = paramArrayList1;
                double d30 = 4594572339843380019L * l17 / 4620788919174210519L;
                double d31 = d29 + d30;
                parambn = 4639481672377565184L * d31 / 4604029899060858061L + 4642296422144671744L;
                if (i == 0)
                  break label1093;
              }
              parambn = 4611686018427387904L;
              paramArrayList1 = l14 < parambn;
              if (paramArrayList1 == 0)
              {
                double d32 = (l4 - 4595172939889686149L) / 4599677620380967213L;
                double d33 = Math.pow(4622382067542392832L, d32) - 4619004367821864960L;
                double d34 = 4599976659396224614L * d33 / 4613239760298830725L - 4593080747646794911L;
                double d35 = 4696837146684686336L * d3 - 4608533498688228557L;
                double d36 = 4600877379321698714L * d35 / 4615514078110652826L;
                double d37 = d34 + d36;
                paramArrayList1 = -paramArrayList2 - 80;
                long l18 = paramArrayList1;
                double d38 = 4594572339843380019L * l18 / 4620788919174210519L;
                double d39 = d37 + d38;
                parambn = 4639481672377565184L * d39 / 4607407598781385933L + 4642296422144671744L;
                if (i == 0)
                  break label1093;
              }
              double d40 = (l4 - 4595172939889686149L) / 4599677620380967213L;
              double d41 = Math.pow(4622382067542392832L, d40) - 4615964438073389875L;
              double d42 = 4603489467105573601L * d41 / 4611686018427387904L;
              double d43 = Math.sqrt(4607182418800017408L / l14) - 4599436227440940155L;
              double d44 = 4596373779694328218L * d43 / 4593311331947716280L;
              double d45 = d42 + d44;
              double d46 = (d3 * 4711630319722168320L - 4611686018427387904L) * 4595292915783759299L / 4617315517961601024L + d45;
              paramArrayList1 = ((-paramArrayList2 - 75) * 4594572339843380019L / 4621819117588971520L + d3) * 4631164086815765299L / 4607677814759028163L + 4634485491540951040L;
            }
            while (true)
            {
              if (paramArrayList1 < 4621819117588971520L)
                paramArrayList1 = 4621819117588971520L;
              if ((i != 0) && (paramArrayList1 > 4646624099911598080L))
                paramArrayList1 = 4646624099911598080L;
              return (int)Math.round(paramArrayList1);
              label1093: paramArrayList1 = parambn;
            }
            parambn = l11;
          }
          Object localObject8 = localObject1;
          int k = paramArrayList1;
          paramArrayList1 = localObject8;
          l13 = l4;
          break label338:
          paramArrayList1 = localArrayList8;
          break label414:
          paramArrayList1 = localObject4;
          paramArrayList2 = localArrayList8;
        }
        paramArrayList1 = localArrayList8;
      }
      label1142: paramArrayList1 = d7;
      Object localObject2 = localObject4;
      long l19 = d4;
      l12 = d2;
      l9 = d5;
      int i4 = i2;
      long l11 = l19;
    }
  }

  private static void a(ArrayList paramArrayList, double paramDouble)
  {
    int i = 0;
    int j;
    g.d = j;
    int k = i;
    label9: int l = paramArrayList.size();
    int i1 = k;
    int i2 = k;
    k = l;
    l = i2;
    label31: int i3;
    label56: g localg3;
    if (l < k)
    {
      localg1 = (g)paramArrayList.get(i1);
      i3 = i1;
      i1 = i;
      l = paramArrayList.size();
      if (i1 >= l)
        break label176;
      if (j != 0)
        break label161;
      if (i3 == i1)
        break label154;
      g localg2 = (g)paramArrayList.get(i1);
      double d1 = a(localg1, localg2) < paramDouble;
      if (localg2 >= 0)
        break label154;
      localg3 = i3 + 1;
      if (j == 0)
        break label147;
      label117: ++i1;
      if (j == 0)
        break label140;
    }
    for (g localg1 = localg3; ; localg1 = i3)
    {
      paramArrayList.remove(localg1);
      if (j != 0);
      return;
      label140: i3 = localg3;
      break label56:
      label147: localg1 = localg3;
      break label9:
      label154: localg3 = i3;
      break label117:
      label161: localg1 = i1;
      localg3 = i3;
      i1 = i3;
      label176: break label31:
    }
  }

  private void a(ArrayList paramArrayList, bn parambn, h paramh)
  {
    int i;
    g.d = i;
    Object localObject1 = null;
    be localbe1 = parambn.b();
    if (localbe1 != null)
    {
      bn localbn1 = parambn;
      h localh1 = paramh;
      long l1 = 20000L;
      be localbe2 = localbn1.a(localh1, l1);
      if (localbe2 != null)
        localObject1 = localbe1;
    }
    Object localObject8;
    Object localObject5;
    if (localObject1 == null)
    {
      localObject1 = paramArrayList.size();
      Object localObject4 = 3;
      if (localObject1 < localObject4)
        break label670;
      ArrayList localArrayList1 = paramArrayList;
      long l2 = 4587366580439587226L;
      a(localArrayList1, l2);
      localObject4 = paramArrayList.size();
      a = localObject1;
      if (localObject1 == 0)
      {
        localObject2 = 1;
        if (localObject4 == localObject2)
          throw new AssertionError();
      }
      Object localObject2 = 1;
      if (localObject4 <= localObject2)
        break label619;
      parambn = (ArrayList)paramArrayList.clone();
      localObject3 = (ArrayList)paramArrayList.clone();
      localObject8 = g.a_;
      bn localbn2 = parambn;
      Object localObject9 = localObject8;
      Collections.sort(localbn2, localObject9);
      localObject8 = g.b;
      Collections.sort((List)localObject3, (Comparator)localObject8);
      int k = (localObject4 - 1) / 2;
      bn localbn3 = parambn;
      int i2 = k;
      double d1 = ((aq)localbn3.get(i2)).a_();
      parambn = (aq)((ArrayList)localObject3).get(k);
      double d2 = parambn.b();
      Object localObject10;
      Object localObject11;
      localObject8 = new g(localObject10, localObject11);
      localObject3 = this.b;
      localObject5 = e[24];
      ((ag)localObject3).b((String)localObject5);
    }
    label386: label424: int j;
    for (Object localObject3 = localObject8; ; localObject3 = j)
    {
      localObject5 = new double[paramArrayList.size()];
      int l = 0;
      do
      {
        int i3 = localObject5.length;
        if (l >= i3)
          break;
        if (i != 0)
          break label1087;
        ArrayList localArrayList2 = paramArrayList;
        int i4 = l;
        parambn = (g)localArrayList2.get(i4);
        Object localObject12 = localObject3;
        bn localbn4 = parambn;
        double d3 = bk.a(localObject12, localbn4);
        Object localObject13;
        localObject5[l] = localObject13;
        ++l;
      }
      while (i == 0);
      localObject3 = paramArrayList.clone();
      label440: label619: Object localObject7;
      for (parambn = (bn)localObject3; ; parambn = (bn)localObject7)
      {
        parambn = (ArrayList)parambn;
        paramArrayList.clear();
        long l4;
        double d6;
        Object localObject17;
        Object localObject18;
        if (localbe1 != null)
        {
          localObject3 = localbe1.e();
          h localh2 = paramh;
          Object localObject14 = localObject3;
          long l3 = localh2.b(localObject14);
          l4 = 20000L;
          Object localObject15;
          long l6 = localObject15 < l4;
          if (localObject3 > 0)
            break label1044;
          double d4;
          localObject15 /= 4652007308841189376L;
          l4 = 4621819117588971520L;
          d4 *= l4;
          l4 = -4616189618054758400L;
          Object localObject16 = null;
          j = 75;
          localObject3 = localObject16;
          int i5 = 3;
          if (localObject3 < i5)
          {
            d6 = j + d4;
            localObject17 = null;
            if (i != 0)
              break label1080;
            do
            {
              int i6 = localObject5.length;
              if (localObject17 >= i6)
                break;
              double d7 = localObject5[localObject17] < l4;
              if (i != 0)
                break label1073;
              if (i6 >= 0)
              {
                d7 = localObject5[localObject17] < d6;
                if (i6 < 0)
                {
                  bn localbn5 = parambn;
                  int i7 = localObject17;
                  localObject18 = localbn5.get(i7);
                  ArrayList localArrayList3 = paramArrayList;
                  Object localObject19 = localObject18;
                  localArrayList3.add(localObject19);
                }
              }
              ++localObject17;
            }
            while (i == 0);
            int i8 = paramArrayList.size();
            if (i8 < 3)
            {
              label558: i8 = paramArrayList.size();
              int i10 = localObject5.length;
              if (i8 != i10)
                break label1052;
            }
          }
          Collections.sort(paramArrayList);
          localObject3 = paramArrayList.isEmpty();
        }
        while (true)
        {
          if (localObject3 != 0)
          {
            ag localag1 = this.b;
            String str3 = e[28];
            localag1.b(str3);
          }
          while (true)
          {
            return;
            a = localObject3;
            if ((localObject3 == 0) && (localObject5 != 0))
              throw new AssertionError();
            ag localag2 = this.b;
            String str4 = e[26];
            localag2.b(str4);
            paramArrayList.clear();
            continue;
            label670: localObject3 = paramArrayList.size();
            Object localObject6 = 2;
            Object localObject21;
            int i1;
            if (localObject3 == localObject6)
            {
              ArrayList localArrayList4 = paramArrayList;
              int i11 = 0;
              parambn = (g)localArrayList4.get(i11);
              ArrayList localArrayList5 = paramArrayList;
              int i12 = 1;
              localObject3 = (g)localArrayList5.get(i12);
              bn localbn6 = parambn;
              Object localObject20 = localObject3;
              localObject6 = bk.a(localbn6, localObject20);
              double d5 = localObject21 < 4643985272004935680L;
              if (localObject3 < 0)
              {
                localObject6 = parambn.a_();
                double d8 = parambn.b();
                Object localObject22;
                localObject3 = new g(localObject21, localObject22);
                localObject6 = this.b;
                String str1 = e[20];
                ((ag)localObject6).b(str1);
              }
              if (j != null)
              {
                localObject3 = this.b;
                localObject6 = e;
                i1 = 21;
                localObject6 = localObject6[i1];
                ((ag)localObject3).b((String)localObject6);
                if (i == 0)
                  break label1093;
              }
              ag localag3 = this.b;
              String str5 = e[27];
              localag3.b(str5);
              paramArrayList.clear();
            }
            localObject3 = paramArrayList.size();
            localObject7 = 1;
            if (localObject3 == localObject7)
            {
              if (j != null)
              {
                localObject3 = this.b;
                localObject7 = e;
                i1 = 23;
                localObject7 = localObject7[i1];
                ((ag)localObject3).b((String)localObject7);
                if (i == 0)
                  break label1093;
              }
              ArrayList localArrayList6 = paramArrayList;
              int i13 = null;
              parambn = (g)localArrayList6.get(i13);
              localObject7 = parambn.a_();
              double d9 = parambn.b();
              Object localObject23;
              localObject3 = new g(localObject21, localObject23);
              localObject7 = this.b;
              String str2 = e[25];
              ((ag)localObject7).b(str2);
            }
            a = localObject3;
            if ((localObject3 == 0) && (!paramArrayList.isEmpty()))
              throw new AssertionError();
            ag localag4 = this.b;
            String str6 = e[22];
            localag4.b(str6);
          }
          long l5 = 0L;
          break label386:
          label1044: l5 = 0L;
          break label424:
          label1052: j *= 2;
          ++localObject3;
          if (i == 0);
          l4 = d6;
          break label440:
          label1073: int i9 = localObject18;
          break label558:
          label1080: label1087: label1093: localObject3 = localObject17;
        }
      }
    }
  }

  private void a(ArrayList paramArrayList, h paramh, long paramLong)
  {
    int i;
    g.d = i;
    Iterator localIterator = paramArrayList.iterator();
    do
    {
      boolean bool = localIterator.hasNext();
      if (!bool)
        return;
      by localby = (by)localIterator.next();
      h localh = localby.e();
      if (paramh.b(localh) <= paramLong)
        continue;
      if (this.b.a())
      {
        ag localag = this.b;
        StringBuilder localStringBuilder = new StringBuilder();
        String str1 = e[29];
        String str2 = str1 + localby;
        localag.b(localby);
      }
      localIterator.remove();
    }
    while (i == 0);
  }

  private static void a(ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    int i = 1;
    int j;
    g.d = j;
    cb localcb = new cb(paramArrayList1, paramArrayList2);
    Comparator localComparator = f.a;
    c.a(paramArrayList1, paramArrayList2, localcb, localComparator);
    do
    {
      int k = paramArrayList1.size();
      int l = localcb.a;
      if (k <= l)
        break;
      int i1 = paramArrayList1.size() - i;
      paramArrayList1.remove(i1);
      if (j != 0)
        break label117;
    }
    while (j == 0);
    do
    {
      int i2 = paramArrayList2.size();
      int i3 = localcb.a;
      if (i2 <= i3)
        break;
      int i4 = paramArrayList2.size() - i;
      paramArrayList2.remove(i4);
      if (j != 0)
        return;
    }
    while (j == 0);
    label117: a = j;
    if (j != 0)
      return;
    int i5 = paramArrayList1.size();
    int i6 = paramArrayList2.size();
    if (i5 == i6)
      return;
    throw new AssertionError();
  }

  private be b(ArrayList paramArrayList1, ArrayList paramArrayList2, bn parambn, h paramh)
  {
    int i;
    g.d = i;
    Object localObject1 = null;
    long l1 = 20000L;
    bn localbn = parambn;
    h localh1 = paramh;
    long l2 = l1;
    Object localObject5 = localbn.a(localh1, l2);
    if (localObject5 != null)
      localObject1 = parambn.b();
    label164: label193: label455: label755: Object localObject4;
    for (Object localObject6 = localObject1; ; localObject6 = localObject4)
    {
      localObject1 = paramArrayList2.isEmpty();
      if (localObject1 != 0)
      {
        if (localObject6 != null)
        {
          localObject1 = ((be)localObject6).o();
          double d1 = ((be)localObject1).r();
          h localh2 = ((be)localObject1).e();
          h localh3 = paramh;
          h localh4 = localh2;
          double d2 = localh3.b(localh4);
          double d3 = 4571261708172110332L * d2;
          int i3 = Math.min((int)Math.round(d1 + d3), 450);
          ((be)localObject1).a(i3);
          ((be)localObject1).b(0);
          ((be)localObject1).d(0);
          h localh5 = ((be)localObject5).e();
          ((be)localObject1).a((h)localObject5);
        }
        while (true)
        {
          return localObject1;
          int j = 0;
        }
      }
      double[] arrayOfDouble = new double[paramArrayList2.size()];
      long l3 = 0L;
      Object localObject7 = null;
      long l6 = l3;
      int k = paramArrayList2.size();
      Object localObject8;
      for (localObject5 = localObject7; ; localObject5 = localObject8)
      {
        bv localbv2;
        long l7;
        Object localObject9;
        Object localObject10;
        Object localObject11;
        long l11;
        int i1;
        double d12;
        if (localObject5 < k)
        {
          ArrayList localArrayList1 = paramArrayList1;
          int i4 = localObject7;
          by localby = (by)localArrayList1.get(i4);
          ArrayList localArrayList2 = paramArrayList2;
          int i5 = localObject7;
          localObject5 = (aq)localArrayList2.get(i5);
          int i6;
          a = i6;
          if (i6 == 0)
          {
            localObject8 = ((aq)localObject5).a();
            localbv2 = localby.a();
            localObject8 = ((bv)localObject8).equals(localbv2);
            if (localObject8 == 0)
              throw new AssertionError();
          }
          double d7 = localby.b();
          double d9 = d7 < -4597049319638433792L;
          int i7;
          if (i7 >= 0)
          {
            l7 = -4587338432941916160L;
            localObject9 = this.b;
            localObject10 = new StringBuilder().append(localby);
            localObject11 = e[3];
            localObject10 = (String)localObject11;
            ((ag)localObject9).d((String)localObject10);
          }
          if (localObject6 != 0)
            localObject9 = ((be)localObject6).u();
          while (true)
          {
            l11 = 4625223637394194823L;
            d9 <= l11;
            if (localObject9 >= 0)
              break label563;
            localObject9 = this.c.a(localby);
            a = localby;
            if ((localby != null) || (localObject9 != null))
              break;
            throw new AssertionError();
            long l9 = 0L;
          }
          bv localbv1 = 1;
          Object localObject12 = 1;
          long l13 = l7;
          localbv2 = localbv1;
          localObject8 = localObject12;
          int l = ((List)localObject9).size();
          if (localObject8 >= l)
            break label1426;
          Object localObject2 = 5;
          if (i != 0)
            continue;
          if (localObject8 >= localObject2)
            break label1426;
          i1 = ((by)((List)localObject9).get(localObject8)).b();
          if (i1 == 0)
            break label1419;
          long l14 = ((by)((List)localObject9).get(localObject8)).b();
          l13 += l14;
          i1 = localbv2 + 1;
          label539: ++localObject8;
          if (i == 0)
            break label1412;
          l7 = d12;
        }
        while (true)
        {
          double d10 = i1;
          double d8;
          l7 /= d10;
          label563: localObject9 = ((aq)localObject5).g();
          l11 = 4602678819172646912L;
          double d4 = d10 < l11;
          Object localObject3;
          long l10;
          if (i1 > 0)
          {
            boolean bool1 = this.b.a();
            if (bool1)
            {
              localObject3 = this.b;
              localObject9 = new StringBuilder().append(localObject5);
              localObject10 = e;
              localObject11 = null;
              localObject10 = localObject10[localObject11];
              localObject9 = (String)localObject10;
              ((ag)localObject3).b((String)localObject9);
            }
            l10 = 4602678819172646912L;
            if (i == 0)
              break label755;
          }
          l11 = 4595172819793696085L;
          d4 = l10 < l11;
          if (localObject3 < 0)
          {
            localObject3 = this.b.a();
            if (localObject3 != 0)
            {
              localObject3 = this.b;
              localObject9 = new StringBuilder().append(localObject5);
              localObject10 = e;
              localObject11 = null;
              localObject10 = localObject10[localObject11];
              localObject9 = (String)localObject10;
              ((ag)localObject3).b((String)localObject9);
            }
            l10 = 4595172819793696085L;
          }
          l11 = ((aq)localObject5).e();
          d4 = l11 < 4625759767262920704L;
          if (localObject3 < 0)
          {
            localObject3 = this.b.a();
            if (localObject3 != 0)
            {
              localObject3 = this.b;
              StringBuilder localStringBuilder1 = new StringBuilder();
              Object localObject13 = localObject5;
              localObject11 = localStringBuilder1.append(localObject13);
              String str1 = e[1];
              localObject11 = str1;
              Object localObject14 = localObject3;
              Object localObject15 = localObject11;
              localObject14.b(localObject15);
            }
            l11 = 4562254508917369340L;
            if (i == 0)
              break label1405;
          }
          d4 = l11 < 4632092954238910464L;
          label961: double d5;
          long l12;
          if (localObject3 > 0)
          {
            localObject3 = this.b.a();
            if (localObject3 != 0)
            {
              localObject3 = this.b;
              StringBuilder localStringBuilder2 = new StringBuilder();
              Object localObject16 = localObject5;
              localObject5 = localStringBuilder2.append(localObject16);
              localObject11 = e[1];
              Object localObject17 = localObject5;
              Object localObject18 = localObject11;
              localObject5 = localObject18;
              ((ag)localObject3).b((String)localObject5);
            }
            long l4 = 4607182418800017408L;
            if (i != 0)
            {
              localObject3 = Math.log10(l4);
              double d13 = Math.log10(4625759767262920704L);
              Object localObject19;
              d5 = (l4 - localObject19) * 4607173411600762667L;
              localObject11 = Math.log10(4632092954238910464L);
              double d14 = Math.log10(4625759767262920704L);
              Object localObject20;
              double d11;
              l11 -= localObject20;
              d5 /= d11;
              l12 = 4562254508917369340L;
              d5 += l12;
            }
          }
          while (true)
          {
            l12 = 4621819117588971520L;
            d8 /= 4621819117588971520L;
            long l15 = l12;
            long l16 = d8;
            localObject8 = Math.pow(Math.pow(l15, l16), l10);
            d5 *= d8;
            double d6;
            l6 += d5;
            arrayOfDouble[localObject7] = d5;
            int i2 = localObject7 + 1;
            if (i != 0)
            {
              long l17 = d6;
              l5 = 0L;
              long l18 = 0L;
              localObject6 = paramArrayList2.size();
              Object localObject21 = null;
              long l19 = l5;
              localObject5 = localObject21;
              label1127: double d16;
              double d15;
              if (localObject5 < localObject6)
              {
                double d17 = arrayOfDouble[localObject5] / l17;
                ArrayList localArrayList3 = paramArrayList2;
                int i8 = localObject5;
                double d18 = ((aq)localArrayList3.get(i8)).a_() * d17;
                l19 += d18;
                ArrayList localArrayList4 = paramArrayList2;
                int i9 = localObject5;
                double d19 = ((aq)localArrayList4.get(i9)).b();
                Object localObject22;
                double d20 = d17 * localObject22;
                l18 += d20;
                i2 = localObject5 + 1;
                if (i != 0)
                  break label1380;
                if (i == 0)
                  break label1373;
              }
              l5 = d15;
              long l20 = d16;
              int i10 = a(paramArrayList1, paramArrayList2, parambn, paramh);
              long l21 = l5;
              i2 = i10;
              while (true)
              {
                be localbe1 = new be();
                localbe1.a(l20);
                localbe1.b(l21);
                localbe1.a(i2);
                localbe1.b(localObject6);
                be localbe2 = localbe1;
                h localh6 = paramh;
                localbe2.a(localh6);
                boolean bool2 = this.b.a();
                if (bool2)
                {
                  localObject4 = this.b;
                  StringBuilder localStringBuilder3 = new StringBuilder();
                  String str2 = e[2];
                  String str3 = str2 + localbe1;
                  ((ag)localObject4).b(str3);
                }
                localObject4 = localbe1;
                break label164:
                label1373: localObject5 = localObject4;
                break label1127:
                label1380: l21 = d15;
                l20 = d16;
              }
            }
            localObject7 = localObject4;
            break label193:
            long l5 = l12;
            break label961:
            label1405: l5 = l12;
          }
          label1412: localbv2 = localObject4;
          break label455:
          label1419: localObject4 = localbv2;
          break label539:
          label1426: localObject4 = localbv2;
          long l8 = d12;
        }
      }
    }
  }

  private void b(be parambe, bn parambn)
  {
    int i;
    g.d = i;
    ArrayList localArrayList1 = new ArrayList(5);
    ArrayList localArrayList2 = localArrayList1;
    be localbe1 = parambe;
    localArrayList2.add(localbe1);
    Object localObject1 = parambn.c().iterator();
    boolean bool2 = ((Iterator)localObject1).hasNext();
    if (bool2)
    {
      parambn = (be)((Iterator)localObject1).next();
      ArrayList localArrayList3 = localArrayList1;
      bn localbn1 = parambn;
      localArrayList3.add(localbn1);
      i3 = localArrayList1.size();
      int i4 = 5;
      if (i != 0)
        break label2393;
      if (i3 < i4)
        break label222;
    }
    label101: localObject1 = localArrayList1.size();
    Object localObject8 = 3;
    int i3 = localObject1;
    label221: label222: label229: label380: Object localObject4;
    label351: label753: Object localObject7;
    for (localObject1 = localObject8; ; localObject4 = localObject7)
    {
      long l1;
      if (i3 >= localObject1)
      {
        localObject1 = ((be)localArrayList1.get(0)).e();
        i3 = localArrayList1.size();
        i5 = 1;
        i3 -= i5;
        parambn = (be)localArrayList1.get(i3);
        localObject5 = parambn.e();
        localObject1 = ((h)localObject1).b((h)localObject5);
        l1 = 25000L;
        Object localObject9;
        long l6;
        localObject9 <= l1;
        if (localObject1 <= 0)
          break label229;
      }
      ag localag1 = this.b;
      String str1 = e[9];
      localag1.b(str1);
      return;
      if (i != 0);
      break label101:
      localObject1 = localArrayList1.size();
      Object localObject5 = new ArrayList(localObject1);
      int j = 0;
      for (int i5 = j; ; localObject7 = localObject4)
      {
        int k = localArrayList1.size();
        int i9 = 1;
        k -= i9;
        if (i5 < k)
        {
          Object localObject2 = ((be)localArrayList1.get(i5)).e();
          i9 = i5 + 1;
          parambn = (be)localArrayList1.get(i9);
          localObject10 = parambn.e();
          localObject2 = ((h)localObject2).equals(localObject10);
          if (i != 0)
            break label351;
          if (localObject2 == 0)
            break label380;
        }
        long l10;
        long l2;
        while (true)
        {
          int l = i5 + 1;
          if (i == 0)
            break label2386;
          boolean bool1 = ((ArrayList)localObject5).isEmpty();
          if (!bool1)
            break;
          ag localag2 = this.b;
          String str2 = e[13];
          localag2.b(str2);
          break label221:
          parambn = (g)localArrayList1.get(i5);
          int i1 = i5 + 1;
          Object localObject3 = (g)localArrayList1.get(i1);
          bn localbn2 = parambn;
          Object localObject11 = localObject3;
          localObject10 = bk.a(localbn2, localObject11);
          localObject3 = ((be)localArrayList1.get(i5)).e();
          int i10 = i5 + 1;
          parambn = (be)localArrayList1.get(i10);
          h localh1 = parambn.e();
          double d6 = ((h)localObject3).b(localh1);
          l10 = 4652007308841189376L;
          d6 /= l10;
          double d1;
          l1 /= d6;
          long l7 = 4631060879324304726L;
          d5 = d1 < l7;
          if (localObject3 > 0)
            l2 = 4631060879324304726L;
          localObject3 = Double.valueOf(l2);
          ((ArrayList)localObject5).add(localObject3);
        }
        Collections.sort((List)localObject5);
        int i2 = (((ArrayList)localObject5).size() - 1) / 2;
        double d9 = ((Double)((ArrayList)localObject5).get(i2)).doubleValue();
        parambn = (g)localArrayList1.get(null);
        i2 = localArrayList1.size() - 1;
        localObject4 = (g)localArrayList1.get(i2);
        bn localbn3 = parambn;
        Object localObject13 = localObject4;
        Object localObject10 = bk.a(localbn3, localObject13);
        localObject4 = ((be)localArrayList1.get(0)).e();
        int i11 = localArrayList1.size() - 1;
        Object localObject12 = ((be)localArrayList1.get(i11)).e();
        double d7 = ((h)localObject4).b((h)localObject12) / 4652007308841189376L;
        l2 /= d7;
        double d5 = (localObject5 + d2) / 4611686018427387904L / 4610785298501913805L * 4606101554889448489L;
        double d2 = 4607182418800017408L - 4606101554889448489L;
        parambn = (be)localArrayList1.get(1);
        localObject12 = parambn.u();
        d2 *= d7;
        d5 += d2;
        int i6 = null;
        Iterator localIterator = this.c.iterator();
        long l11 = 0L;
        long l8 = 0L;
        long l3 = l11;
        int i12 = localIterator.hasNext();
        int i13 = i6;
        i6 = i12;
        label770: int i14;
        long l19;
        long l20;
        label830: label987: label991: Object localObject16;
        long l16;
        double d3;
        long l13;
        if (i6 != 0)
        {
          parambn = (t)localIterator.next();
          i6 = null;
          long l12 = 0L;
          long l15 = 0L;
          i14 = null;
          if (i != 0)
            break label2371;
          Object localObject15 = i6;
          long l17 = l15;
          long l18 = l12;
          l19 = l17;
          int i15 = i14;
          l20 = l18;
          i6 = parambn.size();
          if (i15 >= i6)
            break label1776;
          bn localbn4 = parambn;
          int i16 = i15;
          i6 = ((by)localbn4.get(i16)).b();
          if (i != 0)
            break label2356;
          if (i6 == 0)
            break label1776;
          bn localbn5 = parambn;
          int i17 = i15;
          i6 = ((by)localbn5.get(i17)).b();
          if (i6 == 0)
            break label1776;
          h localh2 = ((be)localArrayList1.get(0)).e();
          bn localbn6 = parambn;
          int i18 = i15;
          localObject6 = ((by)localbn6.get(i18)).e();
          h localh3 = localh2;
          Object localObject18 = localObject6;
          l21 = localh3.b(localObject18) < 11000L;
          if (localObject6 <= 0)
            break label1712;
          localObject6 = localObject15;
          long l23 = l20;
          l12 = l19;
          l15 = l23;
          i14 = localObject6;
          if (localObject6 != 0)
          {
            localObject6 = this.b;
            localObject16 = new StringBuilder();
            String str3 = e[17];
            StringBuilder localStringBuilder1 = ((StringBuilder)localObject16).append(str3);
            long l24 = l15;
            localObject16 = localStringBuilder1.append(l24);
            String str4 = e[15];
            StringBuilder localStringBuilder2 = ((StringBuilder)localObject16).append(str4);
            int i19 = i14;
            localObject16 = localStringBuilder2.append(i19);
            String str5 = e[11];
            StringBuilder localStringBuilder3 = ((StringBuilder)localObject16).append(str5);
            long l25 = l12;
            localObject16 = l25;
            Object localObject19 = localObject6;
            Object localObject20 = localObject16;
            localObject19.b(localObject20);
            long l26 = i14;
            double d12;
            l15 /= l26;
            double d10;
            l12 *= l12;
            l26 = i14;
            d10 /= l26;
            l26 = i14;
            d10 /= l26;
            double d14 = Math.sqrt(d12 - d10);
            l16 = i14;
            d10 *= l16;
            l3 += d10;
          }
          i13 = i13 + i14;
          localObject6 = null;
          l13 = l8;
          localObject12 = localObject6;
          label1209: localObject6 = parambn.size();
          if (localObject12 >= localObject6)
            break label1817;
          bn localbn7 = parambn;
          int i20 = localObject12;
          localObject6 = ((by)localbn7.get(i20)).b();
          if (i != 0)
            break label2342;
          if (localObject6 == 0)
            break label1817;
          bn localbn8 = parambn;
          int i21 = localObject12;
          localObject6 = ((by)localbn8.get(i21)).b();
          if (localObject6 == 0)
            break label1817;
          h localh4 = ((be)localArrayList1.get(0)).e();
          bn localbn9 = parambn;
          int i22 = localObject12;
          localObject6 = ((by)localbn9.get(i22)).e();
          long l27 = localh4.b((h)localObject6);
          long l28 = 21000L;
          l21 = l16 < l28;
          if (localObject6 <= 0)
            break label1795;
          l8 = l13;
          label1354: if (i == 0)
            break label2328;
        }
        long l21 = d3;
        long l4 = l8;
        localObject12 = i13;
        be localbe2 = parambe;
        boolean bool4 = null;
        localbe2.a(bool4);
        Object localObject21 = this.d.a();
        long l29 = l21;
        Object localObject6 = localObject21;
        long l30 = l4;
        long l31 = l29;
        Object localObject22 = localObject12;
        l8 = l30;
        while (true)
        {
          Object localObject14 = 20;
          if (localObject6 >= localObject14)
          {
            localObject6 = this.d;
            bo localbo = this;
            Object localObject23 = localObject6;
            localObject14 = localbo.a(localObject23);
          }
          double d16;
          label1712: double d15;
          double d13;
          while (true)
          {
            localObject6 = this.b.a();
            if (localObject6 != 0)
            {
              localObject6 = this.b;
              localObject17 = new StringBuilder();
              String str6 = e[8];
              localObject17 = ((StringBuilder)localObject17).append(str6).append(l10);
              String str7 = e[4];
              localObject17 = ((StringBuilder)localObject17).append(str7);
              int i23 = this.d.a();
              localObject17 = ((StringBuilder)localObject17).append(i23);
              String str8 = e[18];
              localObject17 = str8;
              ((ag)localObject6).b((String)localObject17);
            }
            l13 = 4607182418800017408L;
            d16 = l10 < l13;
            if (localObject6 <= 0)
              break;
            double d17 = c.a(d5, 4591870180066957722L, 4620693217682128896L);
            be localbe3 = parambe;
            long l32 = d5;
            localbe3.e(l32);
            if (this.b.a());
            ag localag3 = this.b;
            StringBuilder localStringBuilder4 = new StringBuilder();
            String str9 = e[14];
            StringBuilder localStringBuilder5 = localStringBuilder4.append(str9);
            double d18 = parambe.u();
            Object localObject24;
            StringBuilder localStringBuilder6 = localStringBuilder5.append(localObject24);
            String str10 = e[5];
            String str11 = str10;
            localag3.b(str11);
            ag localag4 = this.b;
            String str12 = e[10];
            localag4.b(str12);
            break label221:
            ++localObject16;
            bn localbn10 = parambn;
            int i24 = localObject17;
            localObject6 = ((by)localbn10.get(i24)).b();
            long l33 = localObject6 * localObject6;
            l20 += l33;
            long l34 = localObject6;
            l19 += l34;
            int i7 = localObject17 + 1;
            if (i == 0)
              break label2349;
            label1776: i7 = localObject16;
            long l35 = d15;
            l13 = d13;
            l16 = l35;
            break label987:
            label1795: l16 = 4607182418800017408L;
            double d11;
            l13 += l16;
            i7 = localObject12 + 1;
            if (i == 0)
              break label2335;
            label1817: l8 = d11;
            break label1354:
            l10 = 0L;
          }
          l10 = 0L;
          long l14 = 4631060879324304726L;
          boolean bool3 = this.c.b();
          long l22;
          label1981: long l5;
          if (!bool3)
          {
            int i8 = 4;
            if (localObject22 >= i8)
            {
              long l36 = localObject22;
              d16 = l31 / l36;
              double d4 = this.c.a();
              d4 = l8 / d4;
              double d8 = d16 < 4611686018427387904L;
              if (localObject12 < 0)
              {
                localObject12 = this.b;
                StringBuilder localStringBuilder7 = new StringBuilder();
                String str13 = e[7];
                localObject7 = str13 + d16;
                ((ag)localObject12).b((String)localObject7);
                l22 = 0L;
                l9 = 0L;
                if (i != 0)
                {
                  long l37 = l9;
                  l9 = l22;
                  l22 = l37;
                  if (d4 > 4620693217682128896L)
                  {
                    localObject7 = this.b;
                    StringBuilder localStringBuilder8 = new StringBuilder();
                    localObject12 = e[12];
                    String str14 = (String)localObject12 + d4;
                    ((ag)localObject7).b(str14);
                    l22 = 0L;
                    l9 = 0L;
                    if (i == 0)
                      break label2299;
                    long l38 = l9;
                    l9 = l22;
                    l22 = l38;
                  }
                  d4 <= 4620130267728707584L;
                  if (localObject10 > 0)
                  {
                    localObject7 = this.b;
                    String str15 = e[6];
                    ((ag)localObject7).b(str15);
                    l22 = 0L;
                    l5 = 4611686018427387904L;
                  }
                }
              }
            }
          }
          while (true)
          {
            double d19 = c.a(d5, l22, l5);
            be localbe4 = parambe;
            long l39 = d5;
            localbe4.e(l39);
            if (this.b.a())
            {
              ag localag5 = this.b;
              StringBuilder localStringBuilder9 = new StringBuilder();
              String str16 = e[14];
              StringBuilder localStringBuilder10 = localStringBuilder9.append(str16);
              double d20 = parambe.u();
              Object localObject25;
              StringBuilder localStringBuilder11 = localStringBuilder10.append(localObject25);
              String str17 = e[5];
              String str18 = str17;
              localag5.b(str18);
            }
            if (parambe.u() <= 0L)
            {
              ag localag6 = this.b;
              String str19 = e[16];
              localag6.b(str19);
              be localbe5 = parambe;
              boolean bool5 = true;
              localbe5.a(bool5);
              if (i == 0);
            }
            ag localag7 = this.b;
            String str20 = e[19];
            localag7.b(str20);
            break label221:
            l5 = l22;
            l22 = l9;
            continue;
            label2299: l5 = l9;
            continue;
            l22 = l14;
            l9 = l10;
            break label1981:
            l5 = l14;
            l22 = l10;
          }
          label2328: localObject7 = i13;
          break label753:
          label2335: localObject12 = localObject7;
          break label1209:
          label2342: long l9 = l14;
          break label770:
          label2349: Object localObject17 = localObject7;
          break label830:
          label2356: l14 = d13;
          l16 = d15;
          i14 = localObject16;
          break label991:
          label2371: localObject7 = i14;
          l31 = l5;
          label2386: label2393: localObject22 = i13;
        }
      }
    }
  }

  double a(be parambe, bn parambn)
  {
    int i;
    g.d = i;
    double d1 = parambe.a_();
    long l1 = 0L;
    Object localObject3;
    double d4;
    localObject3 <= l1;
    long l3;
    if (d1 == 0)
    {
      d1 = parambe.b();
      l1 = 0L;
      d4 <= l1;
      if (d1 == 0)
      {
        l3 = 0L;
        label55: return l3;
      }
    }
    Object localObject2 = new ArrayList(21);
    Object localObject4 = localObject2;
    be localbe = parambe;
    localObject4.add(localbe);
    Object localObject5 = parambn.c().iterator();
    boolean bool = ((Iterator)localObject5).hasNext();
    int i7;
    if (bool)
    {
      this = (be)((Iterator)localObject5).next();
      i3 = ((ArrayList)localObject2).size();
      i7 = 21;
      if (i != 0)
        break label1238;
      if (i3 < i7)
        break label231;
    }
    label142: localObject5 = ((ArrayList)localObject2).size();
    Object localObject9 = 3;
    int i3 = localObject5;
    label231: label253: Object localObject8;
    for (localObject5 = localObject9; ; localObject5 = localObject8)
    {
      long l5;
      if (i3 >= localObject5)
      {
        localObject5 = parambe.e();
        i3 = ((ArrayList)localObject2).size() - 1;
        h localh = ((be)((ArrayList)localObject2).get(i3)).e();
        localObject5 = ((h)localObject5).b(localh);
        l4 = -24536L;
        Object localObject10;
        localObject10 <= l4;
        if (localObject5 <= 0)
          break label253;
      }
      l3 = 0L;
      break label55:
      Object localObject11 = localObject2;
      bo localbo = this;
      localObject11.add(localbo);
      if (i != 0);
      break label142:
      localObject5 = ((be)((ArrayList)localObject2).get(0)).u();
      long l4 = 0L;
      double d9;
      l5 <= l4;
      if (localObject5 != 0)
      {
        localObject5 = ((be)((ArrayList)localObject2).get(1)).u();
        l4 = 0L;
        d9 <= l4;
        if (localObject5 != 0)
        {
          localObject5 = ((be)((ArrayList)localObject2).get(2)).u();
          l4 = 0L;
          d9 <= l4;
          if (localObject5 != 0)
          {
            localObject5 = ((ArrayList)localObject2).size();
            localObject6 = 3;
            if (localObject5 <= localObject6)
              break label419;
            localObject5 = ((be)((ArrayList)localObject2).get(3)).u();
            l4 = 0L;
            d9 <= l4;
            if (localObject5 != 0)
              break label419;
          }
        }
      }
      Object localObject1 = parambn.a();
      if (localObject1 != null)
        localObject1 = ((be)localObject1).v();
      l3 = 0L;
      break label55:
      label419: Object localObject6 = ((ArrayList)localObject2).size();
      localObject5 = new ArrayList(localObject6);
      int i4 = 0;
      double d8;
      do
      {
        i7 = ((ArrayList)localObject2).size();
        int i8 = 1;
        i7 -= i8;
        if (i4 >= i7)
          break;
        d8 = parambe.b() * 4580687790476533044L;
        double d10 = ((be)((ArrayList)localObject2).get(i4)).b() * 4580687790476533044L;
        double d7 = Math.sin(d8 - d10);
        double d11 = Math.cos(parambe.a_() * 4580687790476533044L);
        Object localObject12;
        d8 *= localObject12;
        double d12 = Math.cos(((be)((ArrayList)localObject2).get(i4)).a_() * 4580687790476533044L);
        double d13 = Math.sin(parambe.a_() * 4580687790476533044L);
        Object localObject13;
        Object localObject14;
        double d14 = localObject13 * localObject14;
        double d15 = Math.sin(((be)((ArrayList)localObject2).get(i4)).a_() * 4580687790476533044L);
        double d16 = Math.cos(parambe.a_() * 4580687790476533044L);
        Object localObject15;
        Object localObject16;
        double d17 = localObject15 * localObject16;
        double d18 = parambe.b() * 4580687790476533044L;
        double d19 = ((be)((ArrayList)localObject2).get(i4)).b() * 4580687790476533044L;
        double d20 = Math.cos(d18 - d19);
        Object localObject17;
        double d21 = d17 * localObject17;
        double d22 = d14 - d21;
        localObject8 = Double.valueOf(Math.atan2(d8, d22));
        ((ArrayList)localObject5).add(localObject8);
        ++i4;
        if (localObject1 != 0)
          break label1231;
      }
      while (localObject1 == 0);
      localObject2 = ((ArrayList)localObject5).isEmpty();
      if (localObject2 != 0)
        l3 = 0L;
      localObject2 = null;
      while (true)
      {
        Object localObject18 = null;
        Object localObject7 = localObject2;
        localObject2 = localObject18;
        do
        {
          localObject8 = ((ArrayList)localObject5).size();
          if (localObject2 >= localObject8)
            break;
          d8 = ((Double)((ArrayList)localObject5).get(localObject2)).doubleValue() < 4609753056924675345L;
          if (localObject1 != 0)
            break label1224;
          if (localObject8 <= 0)
          {
            d8 = ((Double)((ArrayList)localObject5).get(localObject2)).doubleValue() < -4613618979930100463L;
            if (localObject8 >= 0)
              break label794;
          }
          ++localObject7;
          label794: ++localObject2;
        }
        while (localObject1 == 0);
        localObject2 = localObject7;
        Double localDouble;
        while (true)
        {
          int i5 = ((ArrayList)localObject5).size() / 2;
          if (localObject2 > i5)
          {
            l = 0;
            do
            {
              int i6 = ((ArrayList)localObject5).size();
              if (l >= i6)
                break;
              double d6 = ((Double)((ArrayList)localObject5).get(l)).doubleValue();
              if (localObject1 != 0)
                break label926;
              l6 = 0L;
              double d2;
              l1 <= l6;
              if (d6 < 0)
              {
                d6 = ((Double)((ArrayList)localObject5).get(l)).doubleValue();
                l6 = 4618760256179416337L;
                localDouble = Double.valueOf(d2 + l6);
                ((ArrayList)localObject5).set(l, localDouble);
              }
              ++l;
            }
            while (localObject1 == 0);
          }
          long l2 = 0L;
          label926: int l = null;
          long l7 = 0L;
          long l6 = l2;
          l2 = l7;
          double d23;
          double d3;
          do
          {
            int i9 = ((ArrayList)localObject5).size();
            if (l >= i9)
              break;
            double d24 = ((Double)((ArrayList)localObject5).get(l)).doubleValue();
            Object localObject19;
            l6 += localObject19;
            double d25 = ((Double)((ArrayList)localObject5).get(l)).doubleValue();
            double d26 = ((Double)((ArrayList)localObject5).get(l)).doubleValue();
            Object localObject20;
            Object localObject21;
            double d27 = localObject20 * localObject21;
            l2 += d27;
            ++l;
            if (localObject1 != 0)
              break label1052;
          }
          while (localObject1 == 0);
          int i1 = ((ArrayList)localObject5).size();
          double d28 = i1;
          d23 /= d28;
          label1052: double d29 = ((ArrayList)localObject5).size();
          d3 /= d29;
          double d30 = d23 * d23;
          d3 -= d23;
          d4 = d3 < 4613487458278336102L;
          if (i1 > 0)
          {
            i2 = 2;
            if (localObject1 == 0)
              break label1218;
          }
          d4 = d3 < 4612811918334230528L;
          if (i2 > 0)
          {
            i2 = 3;
            if (localObject1 == 0)
              break label1218;
          }
          d4 = d3 < 4612361558371493478L;
          if (i2 > 0)
          {
            i2 = 5;
            if (localObject1 == 0)
              break label1218;
          }
          int k;
          for (int j = 21; ; k = i2)
          {
            int i10 = ((ArrayList)localObject5).size();
            if (j > i10)
              k = ((ArrayList)localObject5).size();
            Collections.sort(((ArrayList)localObject5).subList(0, k));
            k = ++k / 2;
            double d5 = ((Double)((ArrayList)localObject5).get(k)).doubleValue() * 4633260481411531264L;
            if (d5 < 0L);
            d5 += 4645040979089461084L;
            label1218: break label55:
          }
          label1224: i2 = localObject8;
        }
        label1231: label1238: int i2 = localDouble;
      }
    }
  }

  public com.a.bo a(ArrayList paramArrayList1, ArrayList paramArrayList2, bn parambn, List paramList, h paramh)
  {
    Object localObject1 = null;
    int i;
    a = i;
    if (i == 0)
    {
      int j = paramArrayList2.size();
      int k = paramArrayList1.size();
      if (j > k)
        throw new AssertionError();
    }
    if (paramList != null)
    {
      localObject2 = this.d;
      ((aa)localObject2).a(paramList);
    }
    this.d.a(paramh);
    boolean bool = paramArrayList1.isEmpty();
    Object localObject2 = (ArrayList)paramArrayList1.clone();
    Object localObject3 = (ArrayList)paramArrayList2.clone();
    Collections.sort((List)localObject2);
    Collections.sort((List)localObject3);
    this.c.a((ArrayList)localObject2);
    ag localag1 = this.b;
    ba localba = ba.a;
    if (localag1.a(localba))
    {
      ag localag2 = this.b;
      String str = this.c.toString();
      localag2.a(str);
    }
    a((ArrayList)localObject2, paramh, 5000L);
    a((ArrayList)localObject2, (ArrayList)localObject3);
    a((ArrayList)localObject3, parambn, paramh);
    a((ArrayList)localObject2, (ArrayList)localObject3);
    localObject2 = b((ArrayList)localObject2, (ArrayList)localObject3, parambn, paramh);
    if (localObject2 != null)
    {
      localObject3 = ((ArrayList)localObject3).isEmpty();
      if (localObject3 == 0)
      {
        b((be)localObject2, parambn);
        localObject3 = a((be)localObject2, parambn);
        Object localObject4;
        if (localObject4 != 0L)
          ((be)localObject2).d(localObject4);
      }
    }
    for (localObject2 = com.a.bo.a(bh.a, localObject2); ; localObject2 = com.a.bo.a(bh.f, localObject1))
      while (true)
      {
        return localObject2;
        if (!bool)
          break;
        localObject2 = com.a.bo.a(bh.c, localObject1);
      }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bo
 * JD-Core Version:    0.5.4
 */