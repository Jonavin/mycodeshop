package com.a.a;

import java.io.InputStream;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;

public class i extends InputStream
{
  private final ByteBuffer b;
  private final int c;

  static
  {
    if (!i.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  public i(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    int i;
    a = i;
    if ((i == 0) && (!paramByteBuffer.isDirect()))
      throw new AssertionError();
    this.c = paramInt1;
    ByteBuffer localByteBuffer1 = paramByteBuffer.asReadOnlyBuffer();
    this.b = localByteBuffer1;
    ByteBuffer localByteBuffer2 = this.b;
    int j = this.c;
    localByteBuffer2.position(j);
    ByteBuffer localByteBuffer3 = this.b;
    int k = paramInt1 + paramInt2;
    localByteBuffer3.limit(k);
    a = localByteBuffer3;
    if ((localByteBuffer3 != null) || (this.b.isDirect()))
      return;
    throw new AssertionError();
  }

  public int a()
  {
    int i = this.b.limit();
    int j = this.c;
    return i - j;
  }

  public int available()
  {
    return this.b.remaining();
  }

  public int read()
  {
    try
    {
      byte b1 = this.b.get();
      b1 &= 255;
      return b1;
    }
    catch (BufferUnderflowException i)
    {
      int i = -1;
    }
  }

  public void reset()
  {
    ByteBuffer localByteBuffer = this.b;
    int i = this.c;
    localByteBuffer.position(i);
  }

  public long skip(long paramLong)
  {
    long l = Math.min(available(), paramLong);
    ByteBuffer localByteBuffer = this.b;
    Object localObject;
    int i = (int)(this.b.position() + localObject);
    localByteBuffer.position(i);
    return localObject;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.i
 * JD-Core Version:    0.5.4
 */