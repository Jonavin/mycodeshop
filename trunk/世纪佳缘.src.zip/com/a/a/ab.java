package com.a.a;

import com.a.ag;
import com.a.bo;
import com.a.bv;
import com.a.by;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ab
{
  private static final String[] g;
  private final ag a;
  private ai b;
  private List c;
  private ae d;
  private bu e;
  private al f;

  static
  {
    int i = 73;
    int j = 26;
    int k = 21;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[10];
    char[] arrayOfChar1 = "|t\036?;go\032.,q".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject44;
    Object localObject46;
    Object localObject7;
    Object localObject27;
    int i2;
    int i10;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject26 = localObject1;
      localObject44 = localObject6;
      localObject46 = localObject26;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject26;
      localObject27 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject44)
      {
        i2 = localObject7[arrayOfChar1];
        i10 = localObject46 % 5;
        switch (i10)
        {
        default:
          i10 = i;
          i2 = (char)(i2 ^ i10);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject46 + 1;
          if (localObject44 != 0)
            break;
          localObject7 = localObject27;
          localObject46 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject44;
      Object localObject47 = localObject27;
      localObject27 = localObject2;
      localObject3 = localObject47;
    }
    while (true)
    {
      if (localObject7 <= localObject27);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "9:\0353%y:\b?ig\016/*p~J.&5w\013.*}".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject27 = localObject1;
        localObject44 = localObject8;
        localObject46 = localObject27;
        localObject9 = localObject3;
        Object localObject48 = localObject27;
        localObject27 = localObject3;
        Object localObject4;
        for (localObject3 = localObject48; ; localObject4 = localObject44)
        {
          i2 = localObject9[localObject3];
          i10 = localObject46 % 5;
          switch (i10)
          {
          default:
            i10 = i;
            i2 = (char)(i2 ^ i10);
            localObject9[localObject3] = i2;
            localObject4 = localObject46 + 1;
            if (localObject44 != 0)
              break;
            localObject9 = localObject27;
            localObject46 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject44;
        Object localObject49 = localObject27;
        localObject27 = localObject4;
        localObject5 = localObject49;
      }
      while (true)
      {
        if (localObject9 <= localObject27);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "as\0063'r:\003)ipt\0138%p~".toCharArray();
        Object localObject28 = localObject9.length;
        Object localObject29;
        Object localObject45;
        int i11;
        label475: Object localObject11;
        if (localObject28 <= l)
        {
          localObject44 = localObject1;
          localObject46 = localObject28;
          i2 = localObject44;
          localObject29 = localObject9;
          Object localObject50 = localObject44;
          localObject45 = localObject9;
          Object localObject10;
          for (localObject9 = localObject50; ; localObject10 = localObject46)
          {
            i10 = localObject29[localObject9];
            i11 = i2 % 5;
            switch (i11)
            {
            default:
              i11 = i;
              i10 = (char)(i10 ^ i11);
              localObject29[localObject9] = i10;
              localObject10 = i2 + 1;
              if (localObject46 != 0)
                break;
              localObject29 = localObject45;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject29 = localObject46;
          Object localObject51 = localObject45;
          localObject45 = localObject10;
          localObject11 = localObject51;
        }
        while (true)
        {
          if (localObject29 <= localObject45);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "7:\f5;5n\0036,f3".toCharArray();
          Object localObject30 = localObject11.length;
          Object localObject31;
          label659: Object localObject13;
          if (localObject30 <= l)
          {
            localObject45 = localObject1;
            localObject46 = localObject30;
            int i3 = localObject45;
            localObject31 = localObject11;
            Object localObject52 = localObject45;
            localObject45 = localObject11;
            Object localObject12;
            for (localObject11 = localObject52; ; localObject12 = localObject46)
            {
              i10 = localObject31[localObject11];
              i11 = i3 % 5;
              switch (i11)
              {
              default:
                i11 = i;
                i10 = (char)(i10 ^ i11);
                localObject31[localObject11] = i10;
                localObject12 = i3 + 1;
                if (localObject46 != 0)
                  break;
                localObject31 = localObject45;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject31 = localObject46;
            Object localObject53 = localObject45;
            localObject45 = localObject12;
            localObject13 = localObject53;
          }
          while (true)
          {
            if (localObject31 <= localObject45);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "as\0063'r:\003)iqs\031;+y\016za{uJ*(arJ<&g:\0363%piC".toCharArray();
            Object localObject32 = localObject13.length;
            Object localObject33;
            label843: Object localObject15;
            if (localObject32 <= l)
            {
              localObject45 = localObject1;
              localObject46 = localObject32;
              int i4 = localObject45;
              localObject33 = localObject13;
              Object localObject54 = localObject45;
              localObject45 = localObject13;
              Object localObject14;
              for (localObject13 = localObject54; ; localObject14 = localObject46)
              {
                i10 = localObject33[localObject13];
                i11 = i4 % 5;
                switch (i11)
                {
                default:
                  i11 = i;
                  i10 = (char)(i10 ^ i11);
                  localObject33[localObject13] = i10;
                  localObject14 = i4 + 1;
                  if (localObject46 != 0)
                    break;
                  localObject33 = localObject45;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject33 = localObject46;
              Object localObject55 = localObject45;
              localObject45 = localObject14;
              localObject15 = localObject55;
            }
            while (true)
            {
              if (localObject33 <= localObject45);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "5s\031z.g\013.,g:\0362({:\007;1Q{\036;\032|`\017\016&a{\006z".toCharArray();
              Object localObject34 = localObject15.length;
              Object localObject35;
              label1027: Object localObject17;
              if (localObject34 <= l)
              {
                localObject45 = localObject1;
                localObject46 = localObject34;
                int i5 = localObject45;
                localObject35 = localObject15;
                Object localObject56 = localObject45;
                localObject45 = localObject15;
                Object localObject16;
                for (localObject15 = localObject56; ; localObject16 = localObject46)
                {
                  i10 = localObject35[localObject15];
                  i11 = i5 % 5;
                  switch (i11)
                  {
                  default:
                    i11 = i;
                    i10 = (char)(i10 ^ i11);
                    localObject35[localObject15] = i10;
                    localObject16 = i5 + 1;
                    if (localObject46 != 0)
                      break;
                    localObject35 = localObject45;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject35 = localObject46;
                Object localObject57 = localObject45;
                localObject45 = localObject16;
                localObject17 = localObject57;
              }
              while (true)
              {
                if (localObject35 <= localObject45);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "x{\022\036(a{933pJ\017(\032pi\0313&{:".toCharArray();
                Object localObject36 = localObject17.length;
                Object localObject37;
                label1211: Object localObject19;
                if (localObject36 <= l)
                {
                  localObject45 = localObject1;
                  localObject46 = localObject36;
                  int i6 = localObject45;
                  localObject37 = localObject17;
                  Object localObject58 = localObject45;
                  localObject45 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject58; ; localObject18 = localObject46)
                  {
                    i10 = localObject37[localObject17];
                    i11 = i6 % 5;
                    switch (i11)
                    {
                    default:
                      i11 = i;
                      i10 = (char)(i10 ^ i11);
                      localObject37[localObject17] = i10;
                      localObject18 = i6 + 1;
                      if (localObject46 != 0)
                        break;
                      localObject37 = localObject45;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject37 = localObject46;
                  Object localObject59 = localObject45;
                  localObject45 = localObject18;
                  localObject19 = localObject59;
                }
                while (true)
                {
                  if (localObject37 <= localObject45);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  i1 = 7;
                  localObject19 = "as\0063'r:\003)iqs\031;+y\016za|t\034;%|~J*(arJx".toCharArray();
                  Object localObject38 = localObject19.length;
                  Object localObject39;
                  label1395: Object localObject21;
                  if (localObject38 <= l)
                  {
                    localObject45 = localObject1;
                    localObject46 = localObject38;
                    int i7 = localObject45;
                    localObject39 = localObject19;
                    Object localObject60 = localObject45;
                    localObject45 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject60; ; localObject20 = localObject46)
                    {
                      i10 = localObject39[localObject19];
                      i11 = i7 % 5;
                      switch (i11)
                      {
                      default:
                        i11 = i;
                        i10 = (char)(i10 ^ i11);
                        localObject39[localObject19] = i10;
                        localObject20 = i7 + 1;
                        if (localObject46 != 0)
                          break;
                        localObject39 = localObject45;
                        i7 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject39 = localObject46;
                    Object localObject61 = localObject45;
                    localObject45 = localObject20;
                    localObject21 = localObject61;
                  }
                  while (true)
                  {
                    if (localObject39 <= localObject45);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i1] = localObject21;
                    i1 = 8;
                    localObject21 = "as\0063'r:\003)iqs\031;+y\016za{uJ;<ar\0174=|y\013. ztC".toCharArray();
                    Object localObject40 = localObject21.length;
                    Object localObject41;
                    label1579: Object localObject23;
                    if (localObject40 <= l)
                    {
                      localObject45 = localObject1;
                      localObject46 = localObject40;
                      int i8 = localObject45;
                      localObject41 = localObject21;
                      Object localObject62 = localObject45;
                      localObject45 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject62; ; localObject22 = localObject46)
                      {
                        i10 = localObject41[localObject21];
                        i11 = i8 % 5;
                        switch (i11)
                        {
                        default:
                          i11 = i;
                          i10 = (char)(i10 ^ i11);
                          localObject41[localObject21] = i10;
                          localObject22 = i8 + 1;
                          if (localObject46 != 0)
                            break;
                          localObject41 = localObject45;
                          i8 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject41 = localObject46;
                      Object localObject63 = localObject45;
                      localObject45 = localObject22;
                      localObject23 = localObject63;
                    }
                    while (true)
                    {
                      if (localObject41 <= localObject45);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i1] = localObject23;
                      i1 = 9;
                      localObject23 = "yu\t;%5|\0036,5o\031;.p:\003)iqs\031;+y\016".toCharArray();
                      Object localObject42 = localObject23.length;
                      label1763: Object localObject25;
                      if (localObject42 <= l)
                      {
                        localObject45 = localObject1;
                        localObject46 = localObject42;
                        int i9 = localObject45;
                        localObject43 = localObject23;
                        Object localObject64 = localObject45;
                        localObject45 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject64; ; localObject24 = localObject46)
                        {
                          i10 = localObject43[localObject23];
                          i11 = i9 % 5;
                          switch (i11)
                          {
                          default:
                            i11 = i;
                            int i12 = (char)(i10 ^ i11);
                            localObject43[localObject23] = i10;
                            localObject24 = i9 + 1;
                            if (localObject46 != 0)
                              break;
                            localObject43 = localObject45;
                            i9 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject43 = localObject46;
                        Object localObject65 = localObject45;
                        localObject45 = localObject24;
                        localObject25 = localObject65;
                      }
                      while (true)
                      {
                        if (localObject43 <= localObject45);
                        String str = new String(localObject25).intern();
                        arrayOfString[i1] = localObject25;
                        g = arrayOfString;
                        return;
                        i10 = k;
                        break label115:
                        i10 = j;
                        break label115:
                        i10 = 106;
                        break label115:
                        i10 = 90;
                        break label115:
                        i10 = k;
                        break label295:
                        i10 = j;
                        break label295:
                        i10 = 106;
                        break label295:
                        i10 = 90;
                        break label295:
                        i11 = k;
                        break label475:
                        i11 = j;
                        break label475:
                        i11 = 106;
                        break label475:
                        i11 = 90;
                        break label475:
                        i11 = k;
                        break label659:
                        i11 = j;
                        break label659:
                        i11 = 106;
                        break label659:
                        i11 = 90;
                        break label659:
                        i11 = k;
                        break label843:
                        i11 = j;
                        break label843:
                        i11 = 106;
                        break label843:
                        i11 = 90;
                        break label843:
                        i11 = k;
                        break label1027:
                        i11 = j;
                        break label1027:
                        i11 = 106;
                        break label1027:
                        i11 = 90;
                        break label1027:
                        i11 = k;
                        break label1211:
                        i11 = j;
                        break label1211:
                        i11 = 106;
                        break label1211:
                        i11 = 90;
                        break label1211:
                        i11 = k;
                        break label1395:
                        i11 = j;
                        break label1395:
                        i11 = 106;
                        break label1395:
                        i11 = 90;
                        break label1395:
                        i11 = k;
                        break label1579:
                        i11 = j;
                        break label1579:
                        i11 = 106;
                        break label1579:
                        i11 = 90;
                        break label1579:
                        i11 = k;
                        break label1763:
                        i11 = j;
                        break label1763:
                        i11 = 106;
                        break label1763:
                        i11 = 90;
                        break label1763:
                        localObject45 = localObject1;
                      }
                      localObject45 = localObject1;
                    }
                    localObject45 = localObject1;
                  }
                  localObject45 = localObject1;
                }
                localObject45 = localObject1;
              }
              localObject45 = localObject1;
            }
            localObject45 = localObject1;
          }
          localObject45 = localObject1;
        }
        localObject43 = localObject1;
      }
      Object localObject43 = localObject1;
    }
  }

  public ab(ai paramai, List paramList, bu parambu)
  {
    ag localag = ag.b(ab.class);
    this.a = localag;
    a(paramai);
    a(parambu);
    a(paramList);
  }

  private void d()
  {
    this.d = null;
  }

  private void e()
  {
    try
    {
      al localal = this.f;
      if (localal != null)
      {
        localal = this.f;
        localal.a();
      }
      this.f = null;
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      if (this.a.a());
      ag localag = this.a;
      String str = g[null];
      localag.a(str, localInterruptedException);
    }
  }

  public void a()
  {
    int i = au.a;
    if ((this.d == null) && (this.c != null))
    {
      Object localObject = this.b;
      ae localae = new ae((ai)localObject);
      this.d = localae;
      localObject = this.c.iterator();
      do
      {
        if (!((Iterator)localObject).hasNext())
          break;
        String str = (String)((Iterator)localObject).next();
        this.d.a(str);
        if (i != 0)
          return;
      }
      while (i == 0);
    }
    if ((this.f != null) || (this.b == null) || (this.e == null))
      return;
    ai localai = this.b;
    bu localbu = this.e;
    al localal = new al(localai, localbu);
    this.f = localal;
  }

  public void a(ai paramai)
  {
    if ((this.b == null) || (paramai == null))
    {
      if (this.b == paramai)
        break label52;
      d();
      e();
    }
    if ((au.a != 0) && (!this.b.equals(paramai)))
    {
      d();
      e();
    }
    label52: this.b = paramai;
    if ((this.b != null) && (this.b.a() != null) && (this.b.a().length() != 0) && (this.b.b() != null) && (this.b.b().length() != 0))
      return;
    ag localag = this.a;
    String str = g[8];
    localag.b(str);
    this.b = null;
  }

  public void a(b paramb, ArrayList paramArrayList)
  {
    int i = au.a;
    boolean bool = paramb.e();
    if (!bool);
    while (true)
    {
      return;
      a();
      Object localObject1 = this.f;
      if (localObject1 != null)
      {
        this.f.a(paramb, paramArrayList);
        localObject1 = paramArrayList.isEmpty();
        if (localObject1 == 0)
          continue;
      }
      localObject1 = this.d;
      if (localObject1 == null)
        continue;
      localObject1 = paramb.a();
      Iterator localIterator = ((ArrayList)localObject1).iterator();
      do
      {
        localObject1 = localIterator.hasNext();
        if (localObject1 != 0);
        localObject1 = (by)localIterator.next();
        ae localae = this.d;
        localObject1 = ((by)localObject1).a();
        localObject1 = localae.a((bv)localObject1);
        if (localObject1 == null)
          continue;
        Object localObject2 = ((bo)localObject1).b;
        paramArrayList.add(localObject1);
      }
      while (i == 0);
    }
  }

  public void a(bu parambu)
  {
    int i = 0;
    int j = au.a;
    if ((this.e == null) || (parambu == null))
    {
      if (this.e == parambu)
        break label48;
      e();
    }
    if ((j != 0) && (!this.e.equals(parambu)))
      e();
    label48: this.e = parambu;
    if ((this.e == null) || (this.e.a() == null) || (this.e.a().length() == 0))
    {
      ag localag1 = this.a;
      String str1 = g[4];
      localag1.b(str1);
      this.e = i;
      if (j == 0)
        return;
    }
    String str2 = this.e.a();
    if (!new File(str2).isDirectory())
    {
      ag localag2 = this.a;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = g[7];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str3);
      String str4 = this.e.a();
      StringBuilder localStringBuilder3 = localStringBuilder2.append(str4);
      String str5 = g[3];
      String str6 = str5;
      localag2.d(str6);
      this.e = i;
      if (j == 0)
        return;
    }
    long l1 = this.e.b();
    long l2 = this.e.c();
    Object localObject1;
    Object localObject2;
    if (localObject1 > localObject2)
    {
      ag localag3 = this.a;
      StringBuilder localStringBuilder4 = new StringBuilder();
      String str7 = g[6];
      StringBuilder localStringBuilder5 = localStringBuilder4.append(str7);
      long l3 = this.e.b();
      Object localObject3;
      StringBuilder localStringBuilder6 = localStringBuilder5.append(localObject3);
      String str8 = g[5];
      StringBuilder localStringBuilder7 = localStringBuilder6.append(str8);
      long l4 = this.e.c();
      Object localObject4;
      StringBuilder localStringBuilder8 = localStringBuilder7.append(localObject4);
      String str9 = g[1];
      String str10 = str9;
      localag3.d(str10);
      String str11 = this.e.a();
      long l5 = this.e.c();
      long l6 = this.e.c();
      ao localao = this.e.d();
      Object localObject5;
      Object localObject6;
      bu localbu = new bu(str11, localObject5, localObject6, localao);
      this.e = localbu;
      if (j == 0)
        return;
    }
    ag localag4 = this.a;
    String str12 = g[2];
    localag4.b(str12);
  }

  public void a(List paramList)
  {
    if ((this.c == null) || (paramList == null))
    {
      if (this.c == paramList)
        break label44;
      d();
    }
    if ((au.a != 0) && (!this.c.equals(paramList)))
      d();
    label44: this.c = paramList;
    if ((this.c != null) && (!this.c.isEmpty()))
      return;
    ag localag = this.a;
    String str = g[9];
    localag.b(str);
    this.c = null;
  }

  public boolean b()
  {
    Object localObject1 = this.c;
    if (localObject1 == null)
    {
      localObject1 = this.b;
      if (localObject1 == null)
        break label31;
      localObject1 = this.e;
      if (localObject1 == null)
        break label31;
    }
    int i = 1;
    while (true)
    {
      return i;
      label31: Object localObject2 = null;
    }
  }

  public void c()
  {
    if (this.f == null)
      return;
    this.f.b();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ab
 * JD-Core Version:    0.5.4
 */