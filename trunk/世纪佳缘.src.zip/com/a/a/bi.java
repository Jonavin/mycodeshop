package com.a.a;

import com.a.ag;

final class bi
{
  static final boolean a;
  private static final String[] i;
  private final ag b;
  private final ai c;
  private final long d;
  private final bs e;
  private volatile boolean f = null;
  private by g = null;
  private by h = null;

  static
  {
    int j = 72;
    int k = 53;
    int l = 34;
    int i1 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "T*M\020\"\\&E".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject16;
    Object localObject18;
    Object localObject7;
    Object localObject13;
    int i3;
    int i4;
    label116: Object localObject3;
    if (localObject6 <= i1)
    {
      Object localObject12 = localObject1;
      localObject16 = localObject6;
      localObject18 = localObject12;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject12;
      localObject13 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject16)
      {
        i3 = localObject7[arrayOfChar1];
        i4 = localObject18 % 5;
        switch (i4)
        {
        default:
          i4 = 86;
          i3 = (char)(i3 ^ i4);
          localObject7[arrayOfChar1] = i3;
          localObject2 = localObject18 + 1;
          if (localObject16 != 0)
            break;
          localObject7 = localObject13;
          localObject18 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject16;
      Object localObject19 = localObject13;
      localObject13 = localObject2;
      localObject3 = localObject19;
    }
    while (true)
    {
      if (localObject7 <= localObject13);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "X)Z&7A)q\013,P\030G\020\005P;Q\0139[h\037B".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= i1)
      {
        localObject13 = localObject1;
        localObject16 = localObject8;
        localObject18 = localObject13;
        localObject9 = localObject3;
        Object localObject20 = localObject13;
        localObject13 = localObject3;
        Object localObject4;
        for (localObject3 = localObject20; ; localObject4 = localObject16)
        {
          i3 = localObject9[localObject3];
          i4 = localObject18 % 5;
          switch (i4)
          {
          default:
            i4 = 86;
            i3 = (char)(i3 ^ i4);
            localObject9[localObject3] = i3;
            localObject4 = localObject18 + 1;
            if (localObject16 != 0)
              break;
            localObject9 = localObject13;
            localObject18 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject16;
        Object localObject21 = localObject13;
        localObject13 = localObject4;
        localObject5 = localObject21;
      }
      while (true)
      {
        if (localObject9 <= localObject13);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i1] = localObject5;
        int i2 = 2;
        localObject9 = "\031hv\013:\\&E!:\\-L\026vB!N\016v['VB9E-P\003\"Pf".toCharArray();
        Object localObject14 = localObject9.length;
        Object localObject17;
        int i5;
        label480: Object localObject11;
        if (localObject14 <= i1)
        {
          localObject16 = localObject1;
          localObject18 = localObject14;
          i3 = localObject16;
          localObject15 = localObject9;
          Object localObject22 = localObject16;
          localObject17 = localObject9;
          Object localObject10;
          for (localObject9 = localObject22; ; localObject10 = localObject18)
          {
            i4 = localObject15[localObject9];
            i5 = i3 % 5;
            switch (i5)
            {
            default:
              i5 = 86;
              int i6 = (char)(i4 ^ i5);
              localObject15[localObject9] = i4;
              localObject10 = i3 + 1;
              if (localObject18 != 0)
                break;
              localObject15 = localObject17;
              i3 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject15 = localObject18;
          Object localObject23 = localObject17;
          localObject17 = localObject10;
          localObject11 = localObject23;
        }
        while (true)
        {
          if (localObject15 <= localObject17);
          String str = new String(localObject11).intern();
          arrayOfString[i2] = localObject11;
          i = arrayOfString;
          if (!bi.class.desiredAssertionStatus())
            int i7 = i1;
          while (true)
          {
            boolean bool = a;
            return;
            int i8 = localObject1;
          }
          i4 = k;
          break label116:
          i4 = j;
          break label116:
          i4 = l;
          break label116:
          i4 = 98;
          break label116:
          i4 = k;
          break label296:
          i4 = j;
          break label296:
          i4 = l;
          break label296:
          i4 = 98;
          break label296:
          i5 = k;
          break label480:
          i5 = j;
          break label480:
          i5 = l;
          break label480:
          i5 = 98;
          break label480:
          localObject17 = localObject1;
        }
        localObject15 = localObject1;
      }
      Object localObject15 = localObject1;
    }
  }

  bi(ai paramai, long paramLong, bs parambs)
  {
    ag localag1 = ag.b(bi.class);
    this.b = localag1;
    this.c = paramai;
    this.d = paramLong;
    this.e = ???;
    if (this.d != 0L)
      return;
    ag localag2 = this.b;
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = i[1];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(paramLong);
    String str2 = i[2];
    String str3 = str2;
    localag2.c(str3);
  }

  void a()
  {
    int j = 1;
    Object localObject2 = null;
    int k = bu.a;
    Object localObject4 = this.b;
    String str = i[localObject2];
    ((ag)localObject4).c(str);
    this.f = j;
    localObject4 = new by[2];
    monitorenter;
    Object localObject6 = 0;
    while (true)
    {
      int l;
      try
      {
        localObject1 = this.g;
        localObject4[localObject6] = localObject1;
        localObject6 = 1;
        localObject1 = this.h;
        localObject4[localObject6] = localObject1;
        monitorexit;
        localObject6 = localObject4.length;
        localObject1 = localObject2;
        do
        {
          if (localObject1 >= localObject6)
            break;
          localObject8 = localObject4[localObject1];
          if (k != 0)
            break label201;
          if (localObject8 != null)
            localObject8.a();
          ++localObject1;
        }
        while (k == 0);
        localObject6 = localObject4.length;
        localObject1 = localObject4;
        localObject4 = localObject2;
        if (localObject4 < localObject6)
        {
          localObject8 = localObject1[localObject4];
          if (k != 0)
            break label185;
          localObject9 = localObject1;
          localObject1 = localObject4;
          localObject4 = localObject8;
          Object localObject10 = localObject6;
          localObject7 = localObject8;
          localObject8 = localObject10;
          if (localObject4 != null)
            localObject7.join();
          l = localObject1 + 1;
          if (k == 0);
        }
        label185: return;
      }
      finally
      {
        monitorexit;
      }
      Object localObject7 = localObject8;
      Object localObject1 = localObject9;
      continue;
      label201: Object localObject9 = l;
      Object localObject5 = localObject8;
      Object localObject11 = localObject7;
      localObject7 = localObject8;
      Object localObject8 = localObject11;
    }
  }

  boolean a(an paraman)
  {
    Object localObject1 = null;
    long l1 = this.d < 0L;
    int j;
    Object localObject2;
    if (j == 0)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      boolean bool = this.f;
      Object localObject3;
      if (bool)
        localObject3 = localObject1;
      monitorenter;
      try
      {
        ai localai = this.c;
        bs localbs = this.e;
        long l2 = this.d;
        an localan = paraman;
        localObject3 = new bb(localai, localan, localbs, l2);
        by localby = new by((r)localObject3);
        this.g = localby;
        this.g.start();
        monitorexit;
        int k = 1;
      }
      finally
      {
        monitorexit;
      }
    }
  }

  boolean a(ax paramax)
  {
    a = bool;
    if (!bool)
    {
      long l = this.d < 0L;
      if (!bool)
        throw new AssertionError();
    }
    boolean bool = this.f;
    by localby;
    if (bool)
      localby = null;
    while (true)
    {
      return localby;
      monitorenter;
      try
      {
        bs localbs = this.e;
        ay localay = new ay(paramax, localbs);
        localby = new by(localay);
        this.h = localby;
        this.h.start();
        monitorexit;
        int j = 1;
      }
      finally
      {
        monitorexit;
      }
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bi
 * JD-Core Version:    0.5.4
 */