package com.a.a;

import java.util.AbstractList;
import java.util.List;

public final class bz extends AbstractList
{
  static final boolean a;
  private List b;

  static
  {
    if (!u.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  bz(List paramList)
  {
    this.b = paramList;
  }

  void a(List paramList)
  {
    int i;
    a = i;
    if ((i == 0) && (paramList == null))
      throw new AssertionError();
    this.b = paramList;
  }

  public Object get(int paramInt)
  {
    Object localObject = this.b;
    this = (List)((List)localObject).get(paramInt);
    if (this != null)
    {
      localObject = super.isEmpty();
      if (localObject == 0)
        break label35;
    }
    localObject = null;
    while (true)
    {
      return localObject;
      label35: localObject = super.get(0);
    }
  }

  public int size()
  {
    return this.b.size();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bz
 * JD-Core Version:    0.5.4
 */