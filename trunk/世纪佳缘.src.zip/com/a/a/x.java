package com.a.a;

import com.a.af;
import com.a.bu;
import com.a.h;

class x
  implements bu
{
  final h a;
  final long b;
  final aa c;

  x(aa paramaa, h paramh, long paramLong)
  {
  }

  public boolean a(af paramaf)
  {
    Object localObject1 = paramaf.e();
    h localh = this.a;
    localObject1 = ((h)localObject1).a(localh);
    long l1 = this.b;
    Object localObject3;
    long l2;
    localObject3 <= l1;
    int i;
    if (localObject1 <= 0)
      i = 1;
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.x
 * JD-Core Version:    0.5.4
 */