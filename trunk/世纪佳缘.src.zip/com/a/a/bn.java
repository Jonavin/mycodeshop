package com.a.a;

import com.a.h;

class bn
{
  private final aa b;
  private final aa c;

  static
  {
    if (!bn.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  bn(long paramLong)
  {
    aa localaa1 = new aa(paramLong);
    this.b = localaa1;
    aa localaa2 = new aa(paramLong);
    this.c = localaa2;
  }

  be a()
  {
    return (be)this.b.c();
  }

  be a(h paramh, long paramLong)
  {
    return (be)this.b.b(paramh, paramLong);
  }

  void a(be parambe1, be parambe2, h paramh)
  {
    int i;
    a = i;
    if ((i == 0) && (((parambe1 == null) || (parambe2 == null))))
      throw new AssertionError();
    be localbe1 = parambe2.o();
    localbe1.a(paramh);
    aa localaa = this.b;
    be localbe2 = parambe1.o();
    localaa.a(localbe2);
    this.c.a(localbe1);
  }

  void a(h paramh)
  {
    this.b.a(paramh);
    this.c.a(paramh);
  }

  be b()
  {
    return (be)this.c.c();
  }

  Iterable b(h paramh, long paramLong)
  {
    return this.b.c(paramh, paramLong);
  }

  Iterable c()
  {
    return this.c;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bn
 * JD-Core Version:    0.5.4
 */