package com.a.a;

public abstract interface bg extends cc
{
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bg
 * JD-Core Version:    0.5.4
 */