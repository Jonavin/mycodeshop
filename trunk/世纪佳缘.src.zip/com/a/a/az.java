package com.a.a;

import java.util.Comparator;

final class az
  implements Comparator
{
  public int a(g paramg1, g paramg2)
  {
    double d1 = g.b(paramg1);
    double d3 = g.b(paramg2);
    Object localObject2;
    Object localObject3;
    double d4;
    localObject2 <= localObject3;
    int i;
    if (d1 < 0)
      i = -1;
    while (true)
    {
      return i;
      double d2 = g.b(paramg1);
      double d5 = g.b(paramg2);
      Object localObject4;
      d4 <= localObject4;
      if (d2 > 0)
        int j = 1;
      Object localObject1 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.az
 * JD-Core Version:    0.5.4
 */