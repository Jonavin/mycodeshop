package com.a.a;

class bf
{
  static final int[] a;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bf
 * JD-Core Version:    0.5.4
 */