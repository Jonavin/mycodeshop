package com.a.a;

import Z;
import com.a.by;
import com.a.c;
import com.a.cd;
import com.a.f;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

final class u
  implements Iterable
{
  static final boolean a;
  private static final String[] e;
  private final int b;
  private ArrayList c;
  private final bz d;

  static
  {
    int i = 48;
    int j = 22;
    int k = 10;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "5�".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "D*".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        e = arrayOfString;
        if (!u.class.desiredAssertionStatus())
          int i5 = l;
        while (true)
        {
          boolean bool = a;
          return;
          int i6 = localObject1;
        }
        i3 = 104;
        break label115:
        i3 = k;
        break label115:
        i3 = i;
        break label115:
        i3 = 77;
        break label115:
        i3 = 104;
        break label295:
        i3 = k;
        break label295:
        i3 = i;
        break label295:
        i3 = 77;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  u(int paramInt)
  {
    this.b = paramInt;
    ArrayList localArrayList1 = new ArrayList();
    this.c = localArrayList1;
    ArrayList localArrayList2 = this.c;
    bz localbz = new bz(localArrayList2);
    this.d = localbz;
  }

  static ArrayList a(u paramu)
  {
    return paramu.c;
  }

  private static boolean a(List paramList)
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int i;
    g.d = i;
    cd.b();
    Iterator localIterator = paramList.iterator();
    boolean bool1 = localIterator.hasNext();
    Object localObject4;
    int k;
    label114: Object localObject3;
    if (bool1)
    {
      paramList = (List)localIterator.next();
      if (i != 0)
        break label145;
      localObject4 = paramList.iterator();
      int j = localObject1;
      Object localObject5;
      do
      {
        boolean bool2 = ((Iterator)localObject4).hasNext();
        if (!bool2)
          break;
        paramList = (by)((Iterator)localObject4).next();
        k = paramList.b();
        if (i != 0)
          break label138;
        if (k == 0)
          continue;
        if (i == 0)
          break label132;
        localObject5 = localObject2;
      }
      while (i == 0);
      localObject4 = localObject5;
      if (localObject4 != null)
        localObject3 = localObject2;
    }
    while (true)
    {
      return localObject3;
      if (localObject3 != 0);
      localObject3 = localObject1;
      continue;
      label132: localObject4 = localObject2;
      break label114:
      label138: localObject4 = k;
      break label114:
      label145: localObject3 = localObject1;
    }
  }

  static int b(u paramu)
  {
    return paramu.b;
  }

  private static boolean b(ArrayList paramArrayList)
  {
    int i;
    g.d = i;
    cd.b();
    Iterator localIterator = paramArrayList.iterator();
    boolean bool = localIterator.hasNext();
    int k;
    Object localObject;
    if (bool)
    {
      k = ((by)localIterator.next()).b();
      if (i != 0)
        break label57;
      if (k == 0)
        localObject = null;
    }
    while (true)
    {
      return localObject;
      if (localObject != 0);
      int j = 1;
      continue;
      label57: j = k;
    }
  }

  static bz c(u paramu)
  {
    return paramu.d;
  }

  int a()
  {
    return this.c.size();
  }

  List a(by paramby)
  {
    Object localObject = this.d;
    Comparator localComparator = f.a;
    localObject = Collections.binarySearch((List)localObject, paramby, localComparator);
    int i;
    if (localObject < 0)
      i = 0;
    while (true)
    {
      return i;
      List localList = (List)this.c.get(i);
    }
  }

  void a(ArrayList paramArrayList)
  {
    int i;
    a = i;
    boolean bool;
    if (i == 0)
    {
      bool = b(paramArrayList);
      if (!bool)
        throw new AssertionError();
    }
    a = bool;
    if (!bool)
    {
      bool = c.a(paramArrayList);
      if (!bool)
        throw new AssertionError();
    }
    int j = this.c.size();
    int k = paramArrayList.size();
    int l = j + k;
    Object localObject = new ArrayList(l);
    t localt = new t(this, paramArrayList, (ArrayList)localObject);
    bz localbz = this.d;
    Comparator localComparator = f.a;
    c.a(localbz, paramArrayList, localt, localComparator);
    this.c = ((ArrayList)localObject);
    localObject = this.d;
    ArrayList localArrayList = this.c;
    ((bz)localObject).a(localArrayList);
    a = (Z)localObject;
    if (localObject == null)
    {
      localObject = a(this.c);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = (Z)localObject;
    if ((localObject != null) || (c.a(this.d)))
      return;
    throw new AssertionError();
  }

  boolean b()
  {
    return this.c.isEmpty();
  }

  public Iterator iterator()
  {
    return this.c.iterator();
  }

  public String toString()
  {
    Object localObject1 = null;
    int i = 1;
    int j;
    g.d = j;
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = this.c.iterator();
    Object localObject2;
    Object localObject3;
    for (boolean bool = localIterator.hasNext(); ; localObject2 = localObject3)
    {
      int k;
      if (bool != null)
      {
        this = (com.a.t)localIterator.next();
        localObject2 = "[";
        localStringBuilder.append((String)localObject2);
        if (j != 0)
          break label186;
        localObject2 = super.iterator();
        k = i;
      }
      while (true)
      {
        if (((Iterator)localObject2).hasNext())
        {
          this = (by)((Iterator)localObject2).next();
          if (j != 0)
            break;
          if (k == null)
          {
            localObject3 = e[i];
            localStringBuilder.append((String)localObject3);
          }
          localObject3 = super.toString();
          localStringBuilder.append((String)localObject3);
          if (j == 0)
            break label192;
        }
        localObject2 = e[localObject1];
        localStringBuilder.append((String)localObject2);
        if (j != 0);
        if (localStringBuilder.length() > i)
        {
          int l = localStringBuilder.length() - i;
          localStringBuilder.deleteCharAt(l);
        }
        label186: return localStringBuilder.toString();
        label192: localObject3 = localObject1;
      }
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.u
 * JD-Core Version:    0.5.4
 */