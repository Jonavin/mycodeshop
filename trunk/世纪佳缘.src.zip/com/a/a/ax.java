package com.a.a;

final class ax
{
  private static final String[] e;
  private final String a;
  private final int b;
  private final String c;
  private final boolean d;

  static
  {
    int i = 78;
    int j = 73;
    int k = 63;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "\\/;n$\037)0=pK&0i6V\"0i ^:=i6P<u(pj\034\031".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 80;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "\\/;n$\037)0=pK&0i\005m\002u/?Mn4i6V\"0".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 80;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        e = arrayOfString;
        return;
        i3 = k;
        break label116:
        i3 = i;
        break label116:
        i3 = 85;
        break label116:
        i3 = j;
        break label116:
        i3 = k;
        break label296:
        i3 = i;
        break label296:
        i3 = 85;
        break label296:
        i3 = j;
        break label296:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  private ax(String paramString1, int paramInt, String paramString2, boolean paramBoolean)
  {
    this.a = paramString1;
    this.c = paramString2;
    this.d = paramBoolean;
    this.b = paramInt;
  }

  static ax a(String paramString1, int paramInt, String paramString2)
  {
    return new ax(paramString1, paramInt, paramString2, true);
  }

  static ax b(String paramString1, int paramInt, String paramString2)
  {
    return new ax(paramString1, paramInt, paramString2, null);
  }

  String a()
  {
    return this.a;
  }

  boolean a(ax paramax)
  {
    int i = this.a.length();
    int j = paramax.a.length();
    String str1;
    if (i <= j)
    {
      localObject = paramax.a;
      str1 = this.a;
    }
    String str2;
    for (Object localObject = ((String)localObject).startsWith(str1); ; localObject = ((String)localObject).startsWith(str2))
    {
      return localObject;
      localObject = this.a;
      str2 = paramax.a;
    }
  }

  int b()
  {
    return this.b;
  }

  boolean b(ax paramax)
  {
    int i = this.a.length();
    int j = paramax.a.length();
    if (i >= j);
    String str;
    for (Object localObject = null; ; localObject = ((String)localObject).startsWith(str))
    {
      return localObject;
      localObject = paramax.a;
      str = this.a;
    }
  }

  String c()
  {
    if (this.d)
    {
      String str = e[1];
      throw new UnsupportedOperationException(str);
    }
    return this.c;
  }

  String d()
  {
    if (!this.d)
    {
      String str = e[null];
      throw new UnsupportedOperationException(str);
    }
    return this.c;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      try
      {
        paramObject = (ax)paramObject;
        boolean bool1 = this.d;
        boolean bool2 = paramObject.d;
        if (bool1 == bool2)
        {
          Object localObject3 = this.a;
          String str1 = paramObject.a;
          localObject3 = ((String)localObject3).equals(str1);
          if (localObject3 != 0)
          {
            int i = this.b;
            int k = paramObject.b;
            if (i == k)
            {
              Object localObject4 = this.c;
              String str2 = paramObject.c;
              localObject4 = ((String)localObject4).equals(str2);
              if (localObject4 != 0)
                int j = 1;
            }
          }
        }
        Object localObject5 = localObject1;
      }
      catch (ClassCastException localObject6)
      {
        Object localObject6 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    int i = 17 * 37;
    boolean bool = this.d;
    Object localObject;
    if (bool)
      localObject = null;
    while (true)
    {
      int k = (localObject + 629) * 37;
      int l = this.a.hashCode();
      int i1 = (localObject + l) * 37;
      int i2 = this.b;
      int i3 = (localObject + i2) * 37;
      int i4 = this.c.hashCode();
      return localObject + i4;
      int j = 1;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str = this.a;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str).append("_");
    int i = this.b;
    return i;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ax
 * JD-Core Version:    0.5.4
 */