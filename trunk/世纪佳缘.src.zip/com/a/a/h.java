package com.a.a;

public abstract interface h extends cc
{
  public abstract void a();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.h
 * JD-Core Version:    0.5.4
 */