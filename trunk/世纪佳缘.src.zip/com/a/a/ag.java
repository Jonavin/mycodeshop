package com.a.a;

import com.a.bv;

final class ag
{
  bv a;
  int b;

  ag(bv parambv, int paramInt)
  {
    this.a = parambv;
    this.b = paramInt;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ag
 * JD-Core Version:    0.5.4
 */