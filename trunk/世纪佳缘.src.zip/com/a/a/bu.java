package com.a.a;

public final class bu
{
  public static int a;
  private final String b;
  private final long c;
  private final long d;
  private final ao e;

  public bu(String paramString, long paramLong1, long paramLong2, ao paramao)
  {
    this.b = paramString;
    this.c = paramLong1;
    this.d = ???;
    this.e = paramLong2;
  }

  public String a()
  {
    return this.b;
  }

  public long b()
  {
    return this.c;
  }

  public long c()
  {
    return this.d;
  }

  public ao d()
  {
    return this.e;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      label8: return localObject2;
      try
      {
        paramObject = (bu)paramObject;
        localObject2 = this.b;
        if (localObject2 != null)
        {
          localObject2 = paramObject.b;
          if (localObject2 != null)
            break label55;
        }
        localObject2 = this.b;
        String str1 = paramObject.b;
        if (localObject2 != str1)
        {
          localObject2 = localObject1;
          break label8:
          label55: localObject2 = this.b;
          String str2 = paramObject.b;
          localObject2 = ((String)localObject2).equals(str2);
          if (localObject2 == 0)
            localObject2 = localObject1;
        }
        long l1 = this.c;
        long l2 = paramObject.c;
        l1 <= l2;
        if (localObject2 == 0)
        {
          l1 = this.d;
          l2 = paramObject.d;
          l1 <= l2;
          if (localObject2 == 0)
            int i = 1;
        }
        Object localObject3 = localObject1;
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    int i = 17 * 37;
    int j = (this.b.hashCode() + 629) * 37;
    long l1 = this.c;
    long l2 = this.c >>> 32;
    int k = (int)(l1 ^ l2);
    int l = (j + k) * 37;
    long l3 = this.d;
    long l4 = this.d >>> 32;
    int i1 = (int)(l3 ^ l4);
    return l + i1;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bu
 * JD-Core Version:    0.5.4
 */