package com.a.a;

import Z;
import com.a.af;
import com.a.bu;
import com.a.h;

class ac
  implements bu
{
  final int a;
  final h b;
  final long c;
  final y d;
  private int e = null;
  private boolean f = true;

  ac(y paramy, int paramInt, h paramh, long paramLong)
  {
  }

  public boolean a(af paramaf)
  {
    Object localObject1 = 1;
    boolean bool = this.f;
    int i = this.e;
    int j = this.a - localObject1;
    if (i >= j)
    {
      localObject2 = paramaf.e();
      h localh = this.b;
      localObject2 = ((h)localObject2).a(localh);
      long l1 = this.c;
      Object localObject3;
      long l2;
      localObject3 <= l1;
      if (localObject2 >= 0)
        break label95;
    }
    Object localObject2 = localObject1;
    while (true)
    {
      this.f = ((Z)localObject2);
      int k = this.e;
      this.e = (++localObject2);
      return bool;
      label95: localObject2 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ac
 * JD-Core Version:    0.5.4
 */