package com.a.a;

import com.a.bv;
import com.a.f;

public final class aq extends g
  implements f, Comparable
{
  private final bv e;
  private final int f;
  private final double g;

  public aq(bv parambv, double paramDouble1, double paramDouble2, int paramInt, double paramDouble3)
  {
    super(paramDouble1, ???);
    this.e = parambv;
    this.f = paramDouble2;
    this.g = ???;
  }

  public int a(aq paramaq)
  {
    int i = -1;
    int j;
    if (paramaq == null)
      j = i;
    while (true)
    {
      return j;
      Object localObject1 = this.e;
      bv localbv = paramaq.e;
      localObject1 = ((bv)localObject1).a(localbv);
      if (localObject1 != 0)
        continue;
      int k = this.f;
      int l = paramaq.f;
      k -= l;
      if (k != 0)
        continue;
      long l1 = this.g;
      long l3 = paramaq.g;
      double d1;
      l1 <= l3;
      if (k < 0)
        k = i;
      long l2 = this.g;
      long l4 = paramaq.g;
      double d2;
      l2 <= l4;
      if (k > 0)
        k = 1;
      Object localObject2 = null;
    }
  }

  public bv a()
  {
    return this.e;
  }

  public int e()
  {
    return this.f;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    try
    {
      paramObject = (aq)paramObject;
      if (paramObject != null)
      {
        Object localObject2 = this.e;
        bv localbv = paramObject.e;
        localObject2 = ((bv)localObject2).equals(localbv);
        if (localObject2 != 0)
        {
          int i = this.f;
          int j = paramObject.f;
          if (i == j)
          {
            long l1 = this.g;
            long l2 = paramObject.g;
            double d;
            l1 <= l2;
            if (i == 0)
            {
              i = 1;
              return i;
            }
          }
        }
      }
      Object localObject3 = localObject1;
    }
    catch (ClassCastException localObject4)
    {
      Object localObject4 = localObject1;
    }
  }

  public double g()
  {
    return this.g;
  }

  public int hashCode()
  {
    return (int)this.e.a();
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("(");
    bv localbv = this.e;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localbv).append(",");
    String str = super.toString();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str).append(",");
    int i = this.f;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(i).append(",");
    long l = this.g;
    return l + ")";
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.aq
 * JD-Core Version:    0.5.4
 */