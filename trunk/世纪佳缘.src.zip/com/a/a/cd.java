package com.a.a;

import android.content.Context;
import com.a.aq;

public class cd extends m
{
  public cd(Context paramContext)
  {
    super(localaq);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.cd
 * JD-Core Version:    0.5.4
 */