package com.a.a;

import com.a.ac;
import com.a.ao;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

class e extends FutureTask
  implements ao
{
  private static final String b;
  private final ac a;

  static
  {
    char[] arrayOfChar1 = "\035%]\001H^6VGO\r-TH\034\n,V\006y\b!]Ro\027*X".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 60; ; k = 38)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        return;
        k = 126;
        continue;
        k = 68;
        continue;
        k = 51;
      }
  }

  public e(ac paramac, Callable paramCallable)
  {
    super(paramCallable);
    this.a = paramac;
  }

  public void a(ac paramac)
  {
    String str = b;
    throw new UnsupportedOperationException(str);
  }

  protected void done()
  {
    this.a.a(this);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.e
 * JD-Core Version:    0.5.4
 */