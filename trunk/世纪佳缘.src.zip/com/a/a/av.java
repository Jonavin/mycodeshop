package com.a.a;

import com.a.ag;
import com.a.bo;
import com.a.bv;
import com.a.by;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class av
{
  private static final String[] e;
  private final ag a;
  private final long b;
  private final ae c;
  private final Map d;

  static
  {
    int i = 69;
    int j = 55;
    int k = 21;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[14];
    char[] arrayOfChar1 = "gQ)z(gT4y)\"T/|*)".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject60;
    Object localObject62;
    Object localObject7;
    Object localObject35;
    int i2;
    int i14;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject34 = localObject1;
      localObject60 = localObject6;
      localObject62 = localObject34;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject34;
      localObject35 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject60)
      {
        i2 = localObject7[arrayOfChar1];
        i14 = localObject62 % 5;
        switch (i14)
        {
        default:
          i14 = i;
          i2 = (char)(i2 ^ i14);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject62 + 1;
          if (localObject60 != 0)
            break;
          localObject7 = localObject35;
          localObject62 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject60;
      Object localObject63 = localObject35;
      localObject35 = localObject2;
      localObject3 = localObject63;
    }
    while (true)
    {
      if (localObject7 <= localObject35);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "5R6z3.Y<51.[>5".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject35 = localObject1;
        localObject60 = localObject8;
        localObject62 = localObject35;
        localObject9 = localObject3;
        Object localObject64 = localObject35;
        localObject35 = localObject3;
        Object localObject4;
        for (localObject3 = localObject64; ; localObject4 = localObject60)
        {
          i2 = localObject9[localObject3];
          i14 = localObject62 % 5;
          switch (i14)
          {
          default:
            i14 = i;
            i2 = (char)(i2 ^ i14);
            localObject9[localObject3] = i2;
            localObject4 = localObject62 + 1;
            if (localObject60 != 0)
              break;
            localObject9 = localObject35;
            localObject62 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject60;
        Object localObject65 = localObject35;
        localObject35 = localObject4;
        localObject5 = localObject65;
      }
      while (true)
      {
        if (localObject9 <= localObject35);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "&S?|+ \027/|)\"\027".toCharArray();
        Object localObject36 = localObject9.length;
        Object localObject37;
        Object localObject61;
        int i15;
        label475: Object localObject11;
        if (localObject36 <= l)
        {
          localObject60 = localObject1;
          localObject62 = localObject36;
          i2 = localObject60;
          localObject37 = localObject9;
          Object localObject66 = localObject60;
          localObject61 = localObject9;
          Object localObject10;
          for (localObject9 = localObject66; ; localObject10 = localObject62)
          {
            i14 = localObject37[localObject9];
            i15 = i2 % 5;
            switch (i15)
            {
            default:
              i15 = i;
              i14 = (char)(i14 ^ i15);
              localObject37[localObject9] = i14;
              localObject10 = i2 + 1;
              if (localObject62 != 0)
                break;
              localObject37 = localObject61;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject37 = localObject62;
          Object localObject67 = localObject61;
          localObject61 = localObject10;
          localObject11 = localObject67;
        }
        while (true)
        {
          if (localObject37 <= localObject61);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "k\027?p)\"C2{\"gC3pe!^7pki\031".toCharArray();
          Object localObject38 = localObject11.length;
          Object localObject39;
          label659: Object localObject13;
          if (localObject38 <= l)
          {
            localObject61 = localObject1;
            localObject62 = localObject38;
            int i3 = localObject61;
            localObject39 = localObject11;
            Object localObject68 = localObject61;
            localObject61 = localObject11;
            Object localObject12;
            for (localObject11 = localObject68; ; localObject12 = localObject62)
            {
              i14 = localObject39[localObject11];
              i15 = i3 % 5;
              switch (i15)
              {
              default:
                i15 = i;
                i14 = (char)(i14 ^ i15);
                localObject39[localObject11] = i14;
                localObject12 = i3 + 1;
                if (localObject62 != 0)
                  break;
                localObject39 = localObject61;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject39 = localObject62;
            Object localObject69 = localObject61;
            localObject61 = localObject12;
            localObject13 = localObject69;
          }
          while (true)
          {
            if (localObject39 <= localObject61);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "g^(5*+S>ge3_:{e\"O2f1.Y<5".toCharArray();
            Object localObject40 = localObject13.length;
            Object localObject41;
            label843: Object localObject15;
            if (localObject40 <= l)
            {
              localObject61 = localObject1;
              localObject62 = localObject40;
              int i4 = localObject61;
              localObject41 = localObject13;
              Object localObject70 = localObject61;
              localObject61 = localObject13;
              Object localObject14;
              for (localObject13 = localObject70; ; localObject14 = localObject62)
              {
                i14 = localObject41[localObject13];
                i15 = i4 % 5;
                switch (i15)
                {
                default:
                  i15 = i;
                  i14 = (char)(i14 ^ i15);
                  localObject41[localObject13] = i14;
                  localObject14 = i4 + 1;
                  if (localObject62 != 0)
                    break;
                  localObject41 = localObject61;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject41 = localObject62;
              Object localObject71 = localObject61;
              localObject61 = localObject14;
              localObject15 = localObject71;
            }
            while (true)
            {
              if (localObject41 <= localObject61);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "!V2y #\027/ze(G>{e".toCharArray();
              Object localObject42 = localObject15.length;
              Object localObject43;
              label1027: Object localObject17;
              if (localObject42 <= l)
              {
                localObject61 = localObject1;
                localObject62 = localObject42;
                int i5 = localObject61;
                localObject43 = localObject15;
                Object localObject72 = localObject61;
                localObject61 = localObject15;
                Object localObject16;
                for (localObject15 = localObject72; ; localObject16 = localObject62)
                {
                  i14 = localObject43[localObject15];
                  i15 = i5 % 5;
                  switch (i15)
                  {
                  default:
                    i15 = i;
                    i14 = (char)(i14 ^ i15);
                    localObject43[localObject15] = i14;
                    localObject16 = i5 + 1;
                    if (localObject62 != 0)
                      break;
                    localObject43 = localObject61;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject43 = localObject62;
                Object localObject73 = localObject61;
                localObject61 = localObject16;
                localObject17 = localObject73;
              }
              while (true)
              {
                if (localObject43 <= localObject61);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "gC45&([7p&3^4{".toCharArray();
                Object localObject44 = localObject17.length;
                Object localObject45;
                label1211: Object localObject19;
                if (localObject44 <= l)
                {
                  localObject61 = localObject1;
                  localObject62 = localObject44;
                  int i6 = localObject61;
                  localObject45 = localObject17;
                  Object localObject74 = localObject61;
                  localObject61 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject74; ; localObject18 = localObject62)
                  {
                    i14 = localObject45[localObject17];
                    i15 = i6 % 5;
                    switch (i15)
                    {
                    default:
                      i15 = i;
                      i14 = (char)(i14 ^ i15);
                      localObject45[localObject17] = i14;
                      localObject18 = i6 + 1;
                      if (localObject62 != 0)
                        break;
                      localObject45 = localObject61;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject45 = localObject62;
                  Object localObject75 = localObject61;
                  localObject61 = localObject18;
                  localObject19 = localObject75;
                }
                while (true)
                {
                  if (localObject45 <= localObject61);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  i1 = 7;
                  localObject19 = "3^7pe".toCharArray();
                  Object localObject46 = localObject19.length;
                  Object localObject47;
                  label1395: Object localObject21;
                  if (localObject46 <= l)
                  {
                    localObject61 = localObject1;
                    localObject62 = localObject46;
                    int i7 = localObject61;
                    localObject47 = localObject19;
                    Object localObject76 = localObject61;
                    localObject61 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject76; ; localObject20 = localObject62)
                    {
                      i14 = localObject47[localObject19];
                      i15 = i7 % 5;
                      switch (i15)
                      {
                      default:
                        i15 = i;
                        i14 = (char)(i14 ^ i15);
                        localObject47[localObject19] = i14;
                        localObject20 = i7 + 1;
                        if (localObject62 != 0)
                          break;
                        localObject47 = localObject61;
                        i7 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject47 = localObject62;
                    Object localObject77 = localObject61;
                    localObject61 = localObject20;
                    localObject21 = localObject77;
                  }
                  while (true)
                  {
                    if (localObject47 <= localObject61);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i1] = localObject21;
                    i1 = 8;
                    localObject21 = "2Y:w)\"\027/ze#R7p1\"\027=|)\"\r{".toCharArray();
                    Object localObject48 = localObject21.length;
                    Object localObject49;
                    label1579: Object localObject23;
                    if (localObject48 <= l)
                    {
                      localObject61 = localObject1;
                      localObject62 = localObject48;
                      int i8 = localObject61;
                      localObject49 = localObject21;
                      Object localObject78 = localObject61;
                      localObject61 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject78; ; localObject22 = localObject62)
                      {
                        i14 = localObject49[localObject21];
                        i15 = i8 % 5;
                        switch (i15)
                        {
                        default:
                          i15 = i;
                          i14 = (char)(i14 ^ i15);
                          localObject49[localObject21] = i14;
                          localObject22 = i8 + 1;
                          if (localObject62 != 0)
                            break;
                          localObject49 = localObject61;
                          i8 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject49 = localObject62;
                      Object localObject79 = localObject61;
                      localObject61 = localObject22;
                      localObject23 = localObject79;
                    }
                    while (true)
                    {
                      if (localObject49 <= localObject61);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i1] = localObject23;
                      i1 = 9;
                      localObject23 = "&C/p(7C>qe3X{t!#\027/|)\"\027,},$_{|6gV7g &S\"5)(V?p!".toCharArray();
                      Object localObject50 = localObject23.length;
                      Object localObject51;
                      label1763: Object localObject25;
                      if (localObject50 <= l)
                      {
                        localObject61 = localObject1;
                        localObject62 = localObject50;
                        int i9 = localObject61;
                        localObject51 = localObject23;
                        Object localObject80 = localObject61;
                        localObject61 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject80; ; localObject24 = localObject62)
                        {
                          i14 = localObject51[localObject23];
                          i15 = i9 % 5;
                          switch (i15)
                          {
                          default:
                            i15 = i;
                            i14 = (char)(i14 ^ i15);
                            localObject51[localObject23] = i14;
                            localObject24 = i9 + 1;
                            if (localObject62 != 0)
                              break;
                            localObject51 = localObject61;
                            i9 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject51 = localObject62;
                        Object localObject81 = localObject61;
                        localObject61 = localObject24;
                        localObject25 = localObject81;
                      }
                      while (true)
                      {
                        if (localObject51 <= localObject61);
                        localObject25 = new String(localObject25).intern();
                        arrayOfString[i1] = localObject25;
                        i1 = 10;
                        localObject25 = "3_>56.M>5*!\027/} gC2y 4\027>m&\"R?p!gF.z1&\033{e*7G2{\"gC3pe\013e\01651.[>;ki".toCharArray();
                        Object localObject52 = localObject25.length;
                        Object localObject53;
                        label1947: Object localObject27;
                        if (localObject52 <= l)
                        {
                          localObject61 = localObject1;
                          localObject62 = localObject52;
                          int i10 = localObject61;
                          localObject53 = localObject25;
                          Object localObject82 = localObject61;
                          localObject61 = localObject25;
                          Object localObject26;
                          for (localObject25 = localObject82; ; localObject26 = localObject62)
                          {
                            i14 = localObject53[localObject25];
                            i15 = i10 % 5;
                            switch (i15)
                            {
                            default:
                              i15 = i;
                              i14 = (char)(i14 ^ i15);
                              localObject53[localObject25] = i14;
                              localObject26 = i10 + 1;
                              if (localObject62 != 0)
                                break;
                              localObject53 = localObject61;
                              i10 = localObject26;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject53 = localObject62;
                          Object localObject83 = localObject61;
                          localObject61 = localObject26;
                          localObject27 = localObject83;
                        }
                        while (true)
                        {
                          if (localObject53 <= localObject61);
                          localObject27 = new String(localObject27).intern();
                          arrayOfString[i1] = localObject27;
                          i1 = 11;
                          localObject27 = "g^(57\"G7t&\"S{w<g".toCharArray();
                          Object localObject54 = localObject27.length;
                          Object localObject55;
                          label2131: Object localObject29;
                          if (localObject54 <= l)
                          {
                            localObject61 = localObject1;
                            localObject62 = localObject54;
                            int i11 = localObject61;
                            localObject55 = localObject27;
                            Object localObject84 = localObject61;
                            localObject61 = localObject27;
                            Object localObject28;
                            for (localObject27 = localObject84; ; localObject28 = localObject62)
                            {
                              i14 = localObject55[localObject27];
                              i15 = i11 % 5;
                              switch (i15)
                              {
                              default:
                                i15 = i;
                                i14 = (char)(i14 ^ i15);
                                localObject55[localObject27] = i14;
                                localObject28 = i11 + 1;
                                if (localObject62 != 0)
                                  break;
                                localObject55 = localObject61;
                                i11 = localObject28;
                              case 0:
                              case 1:
                              case 2:
                              case 3:
                              }
                            }
                            localObject55 = localObject62;
                            Object localObject85 = localObject61;
                            localObject61 = localObject28;
                            localObject29 = localObject85;
                          }
                          while (true)
                          {
                            if (localObject55 <= localObject61);
                            localObject29 = new String(localObject29).intern();
                            arrayOfString[i1] = localObject29;
                            i1 = 12;
                            localObject29 = "#R7p1\"\027/|)\"\027".toCharArray();
                            Object localObject56 = localObject29.length;
                            Object localObject57;
                            label2315: Object localObject31;
                            if (localObject56 <= l)
                            {
                              localObject61 = localObject1;
                              localObject62 = localObject56;
                              int i12 = localObject61;
                              localObject57 = localObject29;
                              Object localObject86 = localObject61;
                              localObject61 = localObject29;
                              Object localObject30;
                              for (localObject29 = localObject86; ; localObject30 = localObject62)
                              {
                                i14 = localObject57[localObject29];
                                i15 = i12 % 5;
                                switch (i15)
                                {
                                default:
                                  i15 = i;
                                  i14 = (char)(i14 ^ i15);
                                  localObject57[localObject29] = i14;
                                  localObject30 = i12 + 1;
                                  if (localObject62 != 0)
                                    break;
                                  localObject57 = localObject61;
                                  i12 = localObject30;
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                }
                              }
                              localObject57 = localObject62;
                              Object localObject87 = localObject61;
                              localObject61 = localObject30;
                              localObject31 = localObject87;
                            }
                            while (true)
                            {
                              if (localObject57 <= localObject61);
                              localObject31 = new String(localObject31).intern();
                              arrayOfString[i1] = localObject31;
                              i1 = 13;
                              localObject31 = "5R6z3.Y<5".toCharArray();
                              Object localObject58 = localObject31.length;
                              label2499: Object localObject33;
                              if (localObject58 <= l)
                              {
                                localObject61 = localObject1;
                                localObject62 = localObject58;
                                int i13 = localObject61;
                                localObject59 = localObject31;
                                Object localObject88 = localObject61;
                                localObject61 = localObject31;
                                Object localObject32;
                                for (localObject31 = localObject88; ; localObject32 = localObject62)
                                {
                                  i14 = localObject59[localObject31];
                                  i15 = i13 % 5;
                                  switch (i15)
                                  {
                                  default:
                                    i15 = i;
                                    int i16 = (char)(i14 ^ i15);
                                    localObject59[localObject31] = i14;
                                    localObject32 = i13 + 1;
                                    if (localObject62 != 0)
                                      break;
                                    localObject59 = localObject61;
                                    i13 = localObject32;
                                  case 0:
                                  case 1:
                                  case 2:
                                  case 3:
                                  }
                                }
                                localObject59 = localObject62;
                                Object localObject89 = localObject61;
                                localObject61 = localObject32;
                                localObject33 = localObject89;
                              }
                              while (true)
                              {
                                if (localObject59 <= localObject61);
                                String str = new String(localObject33).intern();
                                arrayOfString[i1] = localObject33;
                                e = arrayOfString;
                                return;
                                i14 = 71;
                                break label115:
                                i14 = j;
                                break label115:
                                i14 = 91;
                                break label115:
                                i14 = k;
                                break label115:
                                i14 = 71;
                                break label295:
                                i14 = j;
                                break label295:
                                i14 = 91;
                                break label295:
                                i14 = k;
                                break label295:
                                i15 = 71;
                                break label475:
                                i15 = j;
                                break label475:
                                i15 = 91;
                                break label475:
                                i15 = k;
                                break label475:
                                i15 = 71;
                                break label659:
                                i15 = j;
                                break label659:
                                i15 = 91;
                                break label659:
                                i15 = k;
                                break label659:
                                i15 = 71;
                                break label843:
                                i15 = j;
                                break label843:
                                i15 = 91;
                                break label843:
                                i15 = k;
                                break label843:
                                i15 = 71;
                                break label1027:
                                i15 = j;
                                break label1027:
                                i15 = 91;
                                break label1027:
                                i15 = k;
                                break label1027:
                                i15 = 71;
                                break label1211:
                                i15 = j;
                                break label1211:
                                i15 = 91;
                                break label1211:
                                i15 = k;
                                break label1211:
                                i15 = 71;
                                break label1395:
                                i15 = j;
                                break label1395:
                                i15 = 91;
                                break label1395:
                                i15 = k;
                                break label1395:
                                i15 = 71;
                                break label1579:
                                i15 = j;
                                break label1579:
                                i15 = 91;
                                break label1579:
                                i15 = k;
                                break label1579:
                                i15 = 71;
                                break label1763:
                                i15 = j;
                                break label1763:
                                i15 = 91;
                                break label1763:
                                i15 = k;
                                break label1763:
                                i15 = 71;
                                break label1947:
                                i15 = j;
                                break label1947:
                                i15 = 91;
                                break label1947:
                                i15 = k;
                                break label1947:
                                i15 = 71;
                                break label2131:
                                i15 = j;
                                break label2131:
                                i15 = 91;
                                break label2131:
                                i15 = k;
                                break label2131:
                                i15 = 71;
                                break label2315:
                                i15 = j;
                                break label2315:
                                i15 = 91;
                                break label2315:
                                i15 = k;
                                break label2315:
                                i15 = 71;
                                break label2499:
                                i15 = j;
                                break label2499:
                                i15 = 91;
                                break label2499:
                                i15 = k;
                                break label2499:
                                localObject61 = localObject1;
                              }
                              localObject61 = localObject1;
                            }
                            localObject61 = localObject1;
                          }
                          localObject61 = localObject1;
                        }
                        localObject61 = localObject1;
                      }
                      localObject61 = localObject1;
                    }
                    localObject61 = localObject1;
                  }
                  localObject61 = localObject1;
                }
                localObject61 = localObject1;
              }
              localObject61 = localObject1;
            }
            localObject61 = localObject1;
          }
          localObject61 = localObject1;
        }
        localObject59 = localObject1;
      }
      Object localObject59 = localObject1;
    }
  }

  av(ai paramai, long paramLong)
  {
    ag localag = ag.b(av.class);
    this.a = localag;
    this.b = paramLong;
    ae localae = new ae(paramai);
    this.c = localae;
    HashMap localHashMap = new HashMap();
    this.d = localHashMap;
  }

  private long a()
  {
    int i = bu.a;
    long l1 = 0L;
    Iterator localIterator = this.d.entrySet().iterator();
    do
    {
      if (!localIterator.hasNext())
        break;
      String str = ((ax)((Map.Entry)localIterator.next()).getValue()).d();
      long l2 = new File(str).length();
      Object localObject;
      l1 += localObject;
    }
    while ((i == 0) && (i == 0));
    return l1;
  }

  private void a(Map.Entry paramEntry)
  {
    ag localag = this.a;
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = e[1];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = ((ax)paramEntry.getValue()).a();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append("_");
    int i = ((ax)paramEntry.getValue()).b();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(i);
    String str3 = e[null];
    String str4 = str3;
    localag.c(str4);
    ae localae = this.c;
    au localau = (au)paramEntry.getKey();
    localae.a(localau);
    ax localax = (ax)paramEntry.getValue();
    c(localax);
  }

  private void b()
  {
    au localau = this.c.a();
    String str1 = ((ax)this.d.get(localau)).d();
    boolean bool = this.a.a();
    if (bool)
    {
      localObject = this.a;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str2 = e[13];
      String str3 = str2 + str1;
      ((ag)localObject).b(str3);
    }
    Object localObject = new File(str1);
    if ((((File)localObject).exists()) && (!((File)localObject).isDirectory()) && (!((File)localObject).delete()))
    {
      ag localag = this.a;
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str4 = e[8];
      String str5 = str4 + localObject;
      localag.d((String)localObject);
    }
    this.d.remove(localau);
  }

  private void c(ax paramax)
  {
    boolean bool = this.a.a();
    if (bool)
    {
      localObject = this.a;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = e[12];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      String str2 = paramax.d();
      String str3 = str2;
      ((ag)localObject).b(str3);
    }
    String str4 = paramax.d();
    Object localObject = new File(str4);
    if ((!((File)localObject).exists()) || (((File)localObject).isDirectory()) || (((File)localObject).delete()))
      return;
    ag localag = this.a;
    StringBuilder localStringBuilder3 = new StringBuilder();
    String str5 = e[8];
    String str6 = str5 + localObject;
    localag.d((String)localObject);
  }

  /** @deprecated */
  String a(ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    Object localObject1 = null;
    monitorenter;
    while (true)
    {
      Object localObject4;
      try
      {
        int i = bu.a;
        HashMap localHashMap = new HashMap();
        int j = 0;
        Iterator localIterator = paramArrayList1.iterator();
        localObject3 = j;
        boolean bool = localIterator.hasNext();
        if (!bool)
          break label295;
        localObject2 = (by)localIterator.next();
        localObject4 = this.c;
        localObject2 = ((by)localObject2).a();
        localObject4 = ((ae)localObject4).a((bv)localObject2);
        if (i != 0)
          break label288;
        if (localObject4 == null)
          break label279;
        localObject2 = ((bo)localObject4).b;
        paramArrayList2.add(localObject2);
        localObject2 = ((bo)localObject4).a;
        localObject2 = (Integer)localHashMap.get(localObject2);
        if (localObject2 == null)
          localObject2 = Integer.valueOf(0);
        Object localObject5 = ((bo)localObject4).a;
        localObject2 = ((Integer)localObject2).intValue();
        Integer localInteger = Integer.valueOf(++localObject2);
        localHashMap.put(localObject5, localInteger);
        localObject2 = localInteger.intValue();
        if (localObject2 <= localObject1)
          break label279;
        localObject2 = (au)((bo)localObject4).a;
        Object localObject6 = localInteger.intValue();
        localObject1 = localObject2;
        localObject2 = localObject6;
        if (i == 0)
          break label302;
        localObject2 = localObject1;
        if (localObject2 != 0)
        {
          localObject2 = this.d.get(localObject2);
          localObject2 = (ax)localObject2;
          if (localObject2 != null);
          for (localObject2 = ((ax)localObject2).a(); ; localObject2 = "")
            return localObject2;
        }
      }
      finally
      {
        monitorexit;
      }
      label279: Object localObject2 = localObject1;
      localObject1 = localObject3;
      continue;
      label288: localObject2 = localObject4;
      continue;
      label295: localObject2 = localObject3;
      continue;
      label302: Object localObject3 = localObject1;
      localObject1 = localObject2;
    }
  }

  /** @deprecated */
  void a(ax paramax)
  {
    monitorenter;
    int i;
    Object localObject2;
    label96: ag localag1;
    label448: 
    do
      try
      {
        i = bu.a;
        localObject1 = this.d.entrySet();
        Iterator localIterator = ((Set)localObject1).iterator();
        do
        {
          localObject1 = localIterator.hasNext();
          if (localObject1 == 0)
            break label452;
          localObject1 = (Map.Entry)localIterator.next();
          localObject2 = (ax)((Map.Entry)localObject1).getValue();
          boolean bool1 = ((ax)localObject2).equals(paramax);
          if (i != 0)
            break label797;
          if (bool1)
          {
            ag localag2 = this.a;
            String str1 = e[9];
            localag2.d(str1);
            return;
          }
          bool1 = ((ax)localObject2).a(paramax);
          if (!bool1)
            break label448;
          int j = ((ax)localObject2).b();
          int k = paramax.b();
          if (j > k)
            break;
          boolean bool2 = this.a.a();
          if (bool2)
          {
            localag1 = this.a;
            StringBuilder localStringBuilder1 = new StringBuilder();
            String str2 = e[7];
            StringBuilder localStringBuilder2 = localStringBuilder1.append(str2);
            String str3 = ((ax)localObject2).a();
            StringBuilder localStringBuilder3 = localStringBuilder2.append(str3).append("_");
            int l = ((ax)localObject2).b();
            StringBuilder localStringBuilder4 = localStringBuilder3.append(l);
            String str4 = e[11];
            StringBuilder localStringBuilder5 = localStringBuilder4.append(str4);
            String str5 = paramax.a();
            StringBuilder localStringBuilder6 = localStringBuilder5.append(str5).append("_");
            int i1 = paramax.b();
            String str6 = i1;
            localag1.b(str6);
          }
          a((Map.Entry)localObject1);
          localIterator.remove();
        }
        while (i == 0);
        if (this.a.a())
        {
          ag localag3 = this.a;
          StringBuilder localStringBuilder7 = new StringBuilder();
          String str7 = e[7];
          StringBuilder localStringBuilder8 = localStringBuilder7.append(str7);
          String str8 = paramax.a();
          StringBuilder localStringBuilder9 = localStringBuilder8.append(str8).append("_");
          int i2 = paramax.b();
          StringBuilder localStringBuilder10 = localStringBuilder9.append(i2);
          String str9 = e[4];
          StringBuilder localStringBuilder11 = localStringBuilder10.append(str9);
          String str10 = ((ax)localObject2).a();
          StringBuilder localStringBuilder12 = localStringBuilder11.append(str10).append("_");
          int i3 = ((ax)localObject2).b();
          String str11 = localObject2;
          localag3.b((String)localObject2);
        }
      }
      finally
      {
        monitorexit;
      }
    while (i == 0);
    label452: Object localObject1 = this.a.a();
    while (true)
    {
      if (localObject1 != 0)
      {
        localObject1 = this.a;
        localObject2 = new StringBuilder();
        String str12 = e[2];
        localObject2 = ((StringBuilder)localObject2).append(str12);
        String str13 = paramax.a();
        localObject2 = ((StringBuilder)localObject2).append(str13).append("_");
        int i4 = paramax.b();
        localObject2 = ((StringBuilder)localObject2).append(i4);
        String str14 = e[6];
        localObject2 = str14;
        ((ag)localObject1).b((String)localObject2);
      }
      localObject1 = paramax.d();
      localObject2 = this.c.a((String)localObject1);
      if (localObject2 == null)
      {
        localObject2 = this.a;
        StringBuilder localStringBuilder13 = new StringBuilder();
        String str15 = e[5];
        StringBuilder localStringBuilder14 = localStringBuilder13.append(str15).append((String)localObject1);
        String str16 = e[3];
        String str17 = str16;
        ((ag)localObject2).d(str17);
        localObject2 = new File((String)localObject1);
        if ((((File)localObject2).exists()) && (!((File)localObject2).isDirectory()) && (!((File)localObject2).delete()));
        ag localag4 = this.a;
        StringBuilder localStringBuilder15 = new StringBuilder();
        String str18 = e[8];
        String str19 = str18 + localObject2;
        localag4.d((String)localObject2);
      }
      this.d.put(localObject2, paramax);
      do
      {
        long l1 = a();
        long l2 = this.b;
        Object localObject4;
        if ((localObject4 > l2) && (!this.d.isEmpty()));
        ag localag5 = this.a;
        String str20 = e[10];
        localag5.b(str20);
        b();
      }
      while (i == 0);
      break label96:
      label797: localObject1 = localag1;
    }
  }

  /** @deprecated */
  ax b(ax paramax)
  {
    monitorenter;
    try
    {
      int i = bu.a;
      Object localObject1 = this.d.values();
      Iterator localIterator = ((Collection)localObject1).iterator();
      do
      {
        localObject1 = localIterator.hasNext();
        if (localObject1 == 0)
          break;
        localObject1 = (ax)localIterator.next();
        boolean bool = paramax.a((ax)localObject1);
        if (bool)
          return localObject1;
      }
      while (i == 0);
      localObject1 = null;
    }
    finally
    {
      monitorexit;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.av
 * JD-Core Version:    0.5.4
 */