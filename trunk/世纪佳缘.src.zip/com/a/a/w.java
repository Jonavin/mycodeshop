package com.a.a;

import com.a.ag;
import com.a.av;
import com.a.i;

class w extends n
{
  private static final String[] g;
  private final ag b;
  private final ai c;
  private final av d;
  private final ai e;
  private final h f;

  static
  {
    int i = 42;
    int j = 35;
    int k = 28;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = ",s:FGOr ^\003\nd;XB\fhogb,<?XF\tu7\020\003".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "=y(CP\033n.^J纮r\035_M\001}-FFOz.CO\nxo]J\033toO[\fy?^J�".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        g = arrayOfString;
        return;
        i3 = 111;
        break label115:
        i3 = k;
        break label115:
        i3 = 79;
        break label115:
        i3 = i;
        break label115:
        i3 = 111;
        break label295:
        i3 = k;
        break label295:
        i3 = 79;
        break label295:
        i3 = i;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  private w(ai paramai1, ai paramai2, av paramav, h paramh)
  {
    ag localag = ag.b(w.class);
    this.b = localag;
    this.c = paramai1;
    this.d = paramav;
    this.e = paramai2;
    this.f = paramh;
  }

  w(ai paramai1, ai paramai2, av paramav, h paramh, l paraml)
  {
    this(paramai1, paramai2, paramav, paramh);
  }

  public void run()
  {
    Object localObject = null;
    try
    {
      String str1 = i.b(this.d).d();
      localObject = str1.substring(0, 8);
      c localc = this.a;
      ai localai1 = this.c;
      ai localai2 = this.e;
      localObject = localc.a(localai1, localai2, (String)localObject);
      bh localbh1 = bh.a;
      if (localObject == localbh1)
      {
        h localh1 = this.f;
        localh1.a();
        g.d = localh1;
        if (localh1 == null)
          break label93;
      }
      this.f.a((bh)localObject);
      label93: q.a(this.f);
      label100: return;
    }
    catch (NullPointerException localNullPointerException)
    {
      ag localag1 = this.b;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str2 = g[null];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str2);
      String str3 = localNullPointerException.getMessage();
      String str4 = localNullPointerException;
      localag1.e(localNullPointerException);
    }
    catch (Throwable localThrowable)
    {
      ag localag2 = this.b;
      String str5 = g[1];
      localag2.d(str5, localThrowable);
      h localh2 = this.f;
      bh localbh2 = bh.g;
      q.a(localh2, localbh2);
      break label100:
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      ag localag3 = this.b;
      StringBuilder localStringBuilder3 = new StringBuilder();
      String str6 = g[null];
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str6);
      String str7 = localIndexOutOfBoundsException.getMessage();
      String str8 = localIndexOutOfBoundsException;
      localag3.e(localIndexOutOfBoundsException);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.w
 * JD-Core Version:    0.5.4
 */