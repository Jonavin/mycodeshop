package com.a.a;

import java.util.Comparator;

final class bc
  implements Comparator
{
  public int a(g paramg1, g paramg2)
  {
    long l1 = g.c(paramg1);
    long l3 = g.c(paramg2);
    Object localObject2;
    Object localObject3;
    long l4;
    localObject2 <= localObject3;
    int i;
    if (l1 < 0)
      i = -1;
    while (true)
    {
      return i;
      long l2 = g.c(paramg1);
      long l5 = g.c(paramg2);
      Object localObject4;
      l4 <= localObject4;
      if (l2 > 0)
        int j = 1;
      Object localObject1 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bc
 * JD-Core Version:    0.5.4
 */