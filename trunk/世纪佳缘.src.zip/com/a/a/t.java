package com.a.a;

import com.a.bv;
import com.a.by;
import com.a.cb;
import java.util.ArrayList;

class t
  implements cb
{
  final ArrayList a;
  final ArrayList b;
  final u c;

  t(u paramu, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    com.a.t localt = (com.a.t)u.a(this.c).get(paramInt1);
    Object localObject = this.a.get(paramInt2);
    localt.add(localObject);
    this.b.add(localt);
  }

  public void b(int paramInt1, int paramInt2)
  {
    int i = u.b(this.c);
    com.a.t localt = new com.a.t(i);
    Object localObject = this.a.get(paramInt2);
    localt.add(localObject);
    this.b.add(localt);
  }

  public void c(int paramInt1, int paramInt2)
  {
    int i;
    g.d = i;
    com.a.t localt = (com.a.t)u.a(this.c).get(paramInt1);
    bv localbv1 = ((by)u.c(this.c).get(paramInt1)).a();
    by localby = new by(localbv1, 0, 0L, null);
    localt.add(localby);
    bv localbv2 = localt.size() - 1;
    bv localbv3;
    for (localbv1 = localbv2; ; localbv1 = localbv3)
    {
      if (localbv1 > 0)
      {
        int j = ((by)localt.get(localbv1)).b();
        if (j != 0)
        {
          ArrayList localArrayList = this.b;
          localArrayList.add(localt);
          if (i == 0)
            break label130;
        }
        localbv3 = localbv1 + -1;
        if (i == 0)
          continue;
      }
      label130: return;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.t
 * JD-Core Version:    0.5.4
 */