package com.a.a;

import com.a.aa;
import com.a.v;
import java.io.InputStream;

final class ay
  implements r
{
  private static final String[] d;
  private final ax a;
  private final bs b;
  private final v c;

  static
  {
    int i = 85;
    int j = 74;
    int k = 40;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "+\030\001'\\/\036".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = k;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "/\002\r0X>\023\001;\b%\031\r Z8\037\no\b".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = k;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        d = arrayOfString;
        return;
        i3 = j;
        break label115:
        i3 = 122;
        break label115:
        i3 = 110;
        break label115:
        i3 = i;
        break label115:
        i3 = j;
        break label295:
        i3 = 122;
        break label295:
        i3 = 110;
        break label295:
        i3 = i;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  ay(ax paramax, bs parambs)
  {
    this.a = paramax;
    this.b = parambs;
    v localv = v.c();
    this.c = localv;
  }

  public void a()
  {
    this.c.a();
  }

  public void run()
  {
    int i = -1;
    Object localObject;
    try
    {
      localObject = this.c;
      String str1 = this.a.c();
      localObject = ((v)localObject).b(str1);
      if (Thread.interrupted())
      {
        bs localbs1 = this.b;
        String str2 = d[null];
        localbs1.b(-1, str2);
        label52: return;
      }
      if (((aa)localObject).b() == 200)
        break label153;
      bs localbs2 = this.b;
      int j = ((aa)localObject).b();
      label153: localbs2.b(localObject, "");
    }
    catch (Exception localException)
    {
      bs localbs3 = this.b;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str3 = d[1];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str3);
      String str4 = localException.toString();
      String str5 = str4;
      localbs3.b(i, str5);
      break label52:
      bs localbs4 = this.b;
      ax localax = this.a;
      InputStream localInputStream = ((aa)localObject).e();
      localbs4.a(localax, (InputStream)localObject);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ay
 * JD-Core Version:    0.5.4
 */