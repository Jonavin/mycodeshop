package com.a.a;

abstract interface cc
{
  public abstract bv a(bh parambh);

  public abstract void b();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.cc
 * JD-Core Version:    0.5.4
 */