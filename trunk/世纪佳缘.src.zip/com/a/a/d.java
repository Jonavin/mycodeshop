package com.a.a;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

class d extends LinkedHashMap
{
  final int a;
  final bq b;

  d(bq parambq, int paramInt1, float paramFloat, boolean paramBoolean, int paramInt2)
  {
    super(paramInt1, paramFloat, paramBoolean);
  }

  protected boolean removeEldestEntry(Map.Entry paramEntry)
  {
    int i = size();
    int k = this.a;
    int j;
    if (i > k)
      j = 1;
    while (true)
    {
      return j;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.d
 * JD-Core Version:    0.5.4
 */