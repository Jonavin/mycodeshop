package com.a.a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public final class an
  implements Iterable
{
  private static final String[] g;
  private final List b;
  private int c;
  private int d;
  private int e;
  private final int f;

  static
  {
    int i = 112;
    int j = 33;
    int k = 23;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "%\037PL\020o)\031[\0247\027\005R\0057\030\025\001\026e\037\021U\024eZ\004I\020yZ\nD\003x@P".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject16;
    Object localObject18;
    Object localObject7;
    Object localObject13;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject12 = localObject1;
      localObject16 = localObject6;
      localObject18 = localObject12;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject12;
      localObject13 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject16)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = localObject18 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject18 + 1;
          if (localObject16 != 0)
            break;
          localObject7 = localObject13;
          localObject18 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject16;
      Object localObject19 = localObject13;
      localObject13 = localObject2;
      localObject3 = localObject19;
    }
    while (true)
    {
      if (localObject7 <= localObject13);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "<b\t\004\001\037x\016PC\0247\031\021M\035r\036PV\031r\024PU\031rZ\030H\002c\025\002XQ~\tPD\034g\016\t".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject13 = localObject1;
        localObject16 = localObject8;
        localObject18 = localObject13;
        localObject9 = localObject3;
        Object localObject20 = localObject13;
        localObject13 = localObject3;
        Object localObject4;
        for (localObject3 = localObject20; ; localObject4 = localObject16)
        {
          i2 = localObject9[localObject3];
          i3 = localObject18 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            i2 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = localObject18 + 1;
            if (localObject16 != 0)
              break;
            localObject9 = localObject13;
            localObject18 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject16;
        Object localObject21 = localObject13;
        localObject13 = localObject4;
        localObject5 = localObject21;
      }
      while (true)
      {
        if (localObject9 <= localObject13);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "%\037PR\022v\024PL\004d\016PB\036y\016\021H\0377\033\004\001\035r\033\003UQx\024\025\0010GZ\037SQt\037\034MQc\025\007D\003".toCharArray();
        Object localObject14 = localObject9.length;
        Object localObject17;
        int i4;
        label475: Object localObject11;
        if (localObject14 <= l)
        {
          localObject16 = localObject1;
          localObject18 = localObject14;
          i2 = localObject16;
          localObject15 = localObject9;
          Object localObject22 = localObject16;
          localObject17 = localObject9;
          Object localObject10;
          for (localObject9 = localObject22; ; localObject10 = localObject18)
          {
            i3 = localObject15[localObject9];
            i4 = i2 % 5;
            switch (i4)
            {
            default:
              i4 = j;
              int i5 = (char)(i3 ^ i4);
              localObject15[localObject9] = i3;
              localObject10 = i2 + 1;
              if (localObject18 != 0)
                break;
              localObject15 = localObject17;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject15 = localObject18;
          Object localObject23 = localObject17;
          localObject17 = localObject10;
          localObject11 = localObject23;
        }
        while (true)
        {
          if (localObject15 <= localObject17);
          String str = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          g = arrayOfString;
          if (!an.class.desiredAssertionStatus())
            int i6 = l;
          while (true)
          {
            boolean bool = a;
            return;
            int i7 = localObject1;
          }
          i3 = 113;
          break label115:
          i3 = k;
          break label115:
          i3 = 122;
          break label115:
          i3 = i;
          break label115:
          i3 = 113;
          break label295:
          i3 = k;
          break label295:
          i3 = 122;
          break label295:
          i3 = i;
          break label295:
          i4 = 113;
          break label475:
          i4 = k;
          break label475:
          i4 = 122;
          break label475:
          i4 = i;
          break label475:
          localObject17 = localObject1;
        }
        localObject15 = localObject1;
      }
      Object localObject15 = localObject1;
    }
  }

  public an(int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    this.b = localLinkedList;
    this.f = paramInt;
    g();
    if (this.f >= 1)
      return;
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = g[null];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    int i = this.f;
    String str2 = i;
    throw new IllegalArgumentException(str2);
  }

  private void a(Iterator paramIterator)
  {
    int i;
    a = i;
    boolean bool;
    if (i == 0)
    {
      bool = a();
      if (bool)
        throw new AssertionError();
    }
    a = bool;
    if ((!bool) && (!paramIterator.hasNext()))
      throw new AssertionError();
    b localb = (b)paramIterator.next();
    f(localb);
    paramIterator.remove();
  }

  private void a(ListIterator paramListIterator)
  {
    int i;
    a = i;
    if ((i == 0) && (!paramListIterator.hasPrevious()))
      throw new AssertionError();
    paramListIterator.previous();
    a(paramListIterator);
  }

  private static boolean a(Iterator paramIterator, b paramb)
  {
    int i;
    g.d = i;
    Object localObject1;
    do
    {
      boolean bool = paramIterator.hasNext();
      if (!bool)
        break label43;
      localObject1 = (b)paramIterator.next();
      localObject1 = paramb.a((b)localObject1);
    }
    while (localObject1 == 0);
    int j = 1;
    if (i == 0);
    while (true)
    {
      return j;
      label43: Object localObject2 = null;
    }
  }

  private void b(b paramb)
  {
    e(paramb);
    this.b.add(0, paramb);
  }

  private void c(b paramb)
  {
    int i;
    g.d = i;
    int j = paramb.d();
    do
    {
      int k = b() + j;
      int l = this.f;
      if (k <= l)
        return;
      j();
    }
    while (i == 0);
  }

  private void d(b paramb)
  {
    int i;
    g.d = i;
    ListIterator localListIterator = this.b.listIterator();
    do
    {
      do
        if (!localListIterator.hasNext())
          return;
      while (!((b)localListIterator.next()).a(paramb));
      a(localListIterator);
    }
    while (i == 0);
  }

  private void e(b paramb)
  {
    int i = this.c;
    int j = paramb.a().size();
    int k = i + j;
    this.c = k;
    int l = this.d;
    int i1 = paramb.b().size();
    int i2 = l + i1;
    this.d = i2;
    int i3 = this.e;
    int i4 = paramb.c().size();
    int i5 = i3 + i4;
    this.e = i5;
  }

  private void f(b paramb)
  {
    int i = this.c;
    int j = paramb.a().size();
    int k = i - j;
    this.c = k;
    int l = this.d;
    int i1 = paramb.b().size();
    int i2 = l - i1;
    this.d = i2;
    int i3 = this.e;
    int i4 = paramb.c().size();
    int i5 = i3 - i4;
    this.e = i5;
  }

  private void i()
  {
    Iterator localIterator = iterator();
    a(localIterator);
  }

  private void j()
  {
    ListIterator localListIterator = h();
    a(localListIterator);
  }

  private void k()
  {
    if (a());
    while (true)
    {
      return;
      Iterator localIterator = iterator();
      localIterator.next();
      b localb = f();
      if (!a(localIterator, localb))
        continue;
      i();
    }
  }

  public void a(b paramb)
  {
    if (!paramb.e())
    {
      String str = g[2];
      throw new IllegalArgumentException(str);
    }
    k();
    d(paramb);
    c(paramb);
    b(paramb);
  }

  public boolean a()
  {
    return this.b.isEmpty();
  }

  public int b()
  {
    int i = c();
    int j = d();
    int k = i + j;
    int l = e();
    return k + l;
  }

  public int c()
  {
    return this.c;
  }

  public int d()
  {
    return this.d;
  }

  public int e()
  {
    return this.e;
  }

  public b f()
  {
    if (this.b.isEmpty())
    {
      String str = g[1];
      throw new IllegalStateException(str);
    }
    return (b)this.b.get(0);
  }

  public void g()
  {
    this.b.clear();
    this.e = null;
    this.d = null;
    this.c = null;
  }

  public ListIterator h()
  {
    List localList = this.b;
    int i = this.b.size();
    return localList.listIterator(i);
  }

  public Iterator iterator()
  {
    return this.b.iterator();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.an
 * JD-Core Version:    0.5.4
 */