package com.a.a;

import java.io.InputStream;
import java.util.LinkedList;

abstract interface bs
{
  public abstract void a(int paramInt, String paramString);

  public abstract void a(ax paramax, InputStream paramInputStream);

  public abstract void a(LinkedList paramLinkedList);

  public abstract void b(int paramInt, String paramString);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bs
 * JD-Core Version:    0.5.4
 */