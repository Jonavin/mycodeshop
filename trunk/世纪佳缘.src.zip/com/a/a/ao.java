package com.a.a;

public abstract interface ao
{
  public abstract bv a(int paramInt1, int paramInt2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ao
 * JD-Core Version:    0.5.4
 */