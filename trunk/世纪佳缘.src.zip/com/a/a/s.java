package com.a.a;

import com.a.h;
import java.util.ArrayList;
import java.util.Iterator;

abstract class s
{
  static final boolean a;

  static
  {
    if (!s.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  static void a(bn parambn, be parambe1, be parambe2, o paramo, h paramh)
  {
    int i;
    g.d = i;
    Object localObject1 = parambn.b();
    if (localObject1 == null);
    label16: boolean bool;
    ArrayList localArrayList1;
    Object localObject4;
    long l9;
    label275: long l3;
    int k;
    long l12;
    do
    {
      return;
      h localh1 = parambe1.e();
      localObject1 = ((be)localObject1).e();
      bool = a(parambe2);
      int j;
      a = j;
      long l2;
      if (j == 0)
      {
        long l1 = ((h)localObject1).b(localh1);
        l2 = 20000L;
        Object localObject3;
        long l7;
        localObject3 <= l2;
        if (l1 > 0)
          throw new AssertionError();
      }
      Object localObject2 = null;
      int[] arrayOfInt = j.a;
      int i1 = paramo.ordinal();
      int l = arrayOfInt[i1];
      switch (l)
      {
      default:
      case 1:
      case 2:
      case 3:
      }
      while (true)
      {
        localArrayList1 = new ArrayList();
        ArrayList localArrayList2 = localArrayList1;
        be localbe1 = parambe1;
        localArrayList2.add(localbe1);
        l2 = localObject2 - 1;
        bn localbn1 = parambn;
        h localh2 = paramh;
        long l8 = l2;
        parambn = localbn1.b(localh2, l8);
        parambe1 = parambn.iterator();
        do
        {
          do
          {
            parambn = parambe1.hasNext();
            if (parambn == 0)
              break label275;
            parambn = (be)parambe1.next();
            localObject4 = o.c;
            if (i != 0)
              break label1591;
            o localo = paramo;
            Object localObject5 = localObject4;
            if (localo != localObject5)
              break;
            localObject4 = parambn.v();
            l9 = 0L;
            double d1;
            l2 <= l9;
          }
          while (localObject4 == 0);
          ArrayList localArrayList3 = localArrayList1;
          bn localbn2 = parambn;
          localArrayList3.add(localbn2);
        }
        while (i == 0);
        parambn = localArrayList1.size();
        parambe1 = 2;
        int i2 = parambn;
        int i3 = parambe1;
        if (i2 >= i3);
        a = parambn;
        if (parambn != 0)
          break;
        parambn = localh1.b((h)localObject1);
        l3 = localObject2;
        parambn <= l3;
        if (parambn <= 0)
          break;
        throw new AssertionError();
        if (bool)
        {
          k = 10000;
          if (i == 0)
            continue;
        }
        k = 8000;
        if (i == 0)
          continue;
        k = 10000;
        if (i == 0)
          continue;
        k = 6000;
      }
      parambn = localh1.b((h)localObject1);
      l12 = k;
      parambn <= l12;
    }
    while (parambn > 0);
    parambn = o.c;
    for (parambe1 = paramo; ; parambe1 = paramo)
    {
      be localbe2 = parambe1;
      bn localbn3 = parambn;
      if (localbe2 == localbn3)
      {
        parambn = null;
        parambe1 = null;
        localObject1 = parambn;
        label425: parambn = localArrayList1.size();
        int i4 = parambe1;
        int i5 = parambn;
        if (i4 >= i5)
          break label1585;
        ArrayList localArrayList4 = localArrayList1;
        int i6 = parambe1;
        localObject4 = ((be)localArrayList4.get(i6)).v();
        l9 = 4636033603912859648L;
        parambn = l3 < l9;
        if (i == 0)
        {
          if (parambn >= 0)
          {
            ArrayList localArrayList5 = localArrayList1;
            int i7 = parambe1;
            localObject4 = ((be)localArrayList5.get(i7)).v();
            l9 = 4643457506423603200L;
            parambn = l3 < l9;
            if (parambn <= 0)
              break label1579;
          }
          parambn = localObject1 + 1;
          label528: ++parambe1;
          if (i == 0)
            break label1573;
        }
      }
      while (true)
      {
        parambe1 = localArrayList1.size();
        parambe1 = ++parambe1 / 2;
        bn localbn4 = parambn;
        int i8 = parambe1;
        if (localbn4 >= i8)
        {
          parambn = null;
          parambe1 = parambn;
          label566: parambn = localArrayList1.size();
          int i9 = parambe1;
          int i10 = parambn;
          if (i9 < i10)
          {
            ArrayList localArrayList6 = localArrayList1;
            int i11 = parambe1;
            parambn = (ce)localArrayList6.get(i11);
            localObject1 = parambn.v();
            if (i != 0)
              break label1567;
            l3 = 4640537203540230144L;
            double d8;
            l12 <= l3;
            if (localObject1 > 0)
            {
              localObject1 = parambn.v();
              l3 = 4645040803167600640L;
              d8 -= l3;
              bn localbn5 = parambn;
              long l16 = d8;
              localbn5.d(l16);
            }
            parambn = parambe1 + 1;
            if (i == 0)
              break label1562;
          }
        }
        parambn = 0L;
        while (true)
        {
          localObject1 = j.a;
          paramo = paramo.ordinal();
          paramo = localObject1[paramo];
          label757: long l19;
          long l14;
          long l4;
          switch (paramo)
          {
          case 2:
          default:
            break;
          case 1:
            long l13 = 0L;
            l3 = 0L;
            if (bool)
            {
              paramo = null;
              l9 = parambn;
              parambe1 = paramo;
              long l17 = l13;
              l13 = l3;
              l3 = l17;
              parambn = localArrayList1.size();
              int i12 = parambe1;
              int i13 = parambn;
              double d2;
              double d9;
              double d5;
              if (i12 < i13)
              {
                ArrayList localArrayList7 = localArrayList1;
                int i14 = parambe1;
                double d12 = ((be)localArrayList7.get(i14)).a_();
                Object localObject6;
                l3 += localObject6;
                ArrayList localArrayList8 = localArrayList1;
                int i15 = parambe1;
                d12 = ((be)localArrayList8.get(i15)).b();
                l13 += localObject6;
                l19 = 4607182418800017408L;
                l9 += l19;
                parambn = parambe1 + 1;
                if (i != 0)
                  break label1165;
                if (i == 0)
                  break label1544;
              }
              parambn = d9;
              l14 = d2;
              l4 = d5;
              if (i == 0);
            }
          case 3:
          }
          label1156: label1165: label1196: label1258: double d11;
          while (true)
          {
            paramo = null;
            long l10 = l4;
            l4 = l14;
            l14 = parambn;
            double d4;
            for (parambe1 = paramo; ; parambe1 = parambn)
            {
              parambn = localArrayList1.size();
              int i16 = parambe1;
              int i17 = parambn;
              double d3;
              double d10;
              double d6;
              if (i16 < i17)
              {
                ArrayList localArrayList9 = localArrayList1;
                int i18 = parambe1;
                h localh3 = ((be)localArrayList9.get(i18)).e();
                h localh4 = paramh;
                long l18 = localh3.a(localh4);
                long l20 = k / 2;
                parambn = l19 < l20;
                if (i != 0)
                  break label1196;
                if (parambn <= 0)
                {
                  long l21 = l19;
                  double d14 = 4585925428558828667L * l21 / 4652007308841189376L + 4590429028186199163L;
                  ArrayList localArrayList10 = localArrayList1;
                  int i19 = parambe1;
                  double d15 = ((be)localArrayList10.get(i19)).a_() * d14;
                  l4 += d15;
                  ArrayList localArrayList11 = localArrayList1;
                  int i20 = parambe1;
                  parambn = (be)localArrayList11.get(i20);
                  double d16 = parambn.b() * d14;
                  l14 += d16;
                  l10 += d14;
                  if (i == 0)
                    break label1156;
                }
                double d13 = l19 * -4637446608295947141L / 4652007308841189376L + 4600877379321698714L;
                ArrayList localArrayList12 = localArrayList1;
                int i21 = parambe1;
                double d17 = ((be)localArrayList12.get(i21)).a_() * d13;
                d3 += d17;
                ArrayList localArrayList13 = localArrayList1;
                int i22 = parambe1;
                parambn = (be)localArrayList13.get(i22);
                double d18 = parambn.b() * d13;
                d10 += d18;
                d6 += d13;
                parambn = parambe1 + 1;
                if (i == 0)
                  continue;
              }
              parambn = d10;
              long l15 = d3;
              long l5 = d6;
              paramo = l5 < 0L;
              long l11 = l5;
              l5 = l15;
              l15 = parambn;
              parambn = paramo;
              if (parambn != 0);
              parambn = l5 / l11;
              be localbe3 = parambe2;
              long l22 = parambn;
              localbe3.a(l22);
              parambn = l15 / l11;
              be localbe4 = parambe2;
              long l23 = parambn;
              localbe4.b(l23);
              if (i != 0);
              parambn = l11;
              l15 = 0L;
              paramo = null;
              l5 = parambn;
              parambe1 = paramo;
              parambn = localArrayList1.size();
              int i23 = parambe1;
              int i24 = parambn;
              if (i23 < i24)
              {
                ArrayList localArrayList14 = localArrayList1;
                int i25 = parambe1;
                h localh5 = ((be)localArrayList14.get(i25)).e();
                h localh6 = paramh;
                long l24 = localh5.a(localh6);
                long l25 = k / 2;
                parambn = l11 < l25;
                if (i != 0)
                  break label1529;
                if (parambn <= 0)
                {
                  long l26 = l11;
                  double d19 = 4592590756007337001L * l26 / 4652007308841189376L;
                  ArrayList localArrayList15 = localArrayList1;
                  int i26 = parambe1;
                  parambn = (be)localArrayList15.get(i26);
                  double d20 = parambn.v() * d19;
                  l15 += d20;
                  l5 += d19;
                  if (i == 0)
                    break label1455;
                }
                double d7 = l11 * -4630781280847438807L / 4652007308841189376L + 4604119971053405471L;
                ArrayList localArrayList16 = localArrayList1;
                int i27 = parambe1;
                parambn = (be)localArrayList16.get(i27);
                double d21 = parambn.v() * d7;
                d11 += d21;
                d4 += d7;
                label1455: parambn = parambe1 + 1;
                if (i == 0)
                  break label1524;
              }
              parambn = d11;
              paramo = d4;
              bn localbn6 = paramo < 0L;
              long l27 = paramo;
              paramo = parambn;
              parambn = localbn6;
              while (true)
              {
                if (parambn != 0);
                parambn = paramo / l27;
                if (parambn < 0L)
                  parambn += 4645040979089461084L;
                be localbe5 = parambe2;
                long l28 = parambn;
                localbe5.d(l28);
                break label16:
                label1524: parambe1 = parambn;
                break label1258:
                label1529: paramo = d11;
                l27 = d4;
              }
            }
            label1544: parambe1 = parambn;
            break label757:
            long l29 = d4;
            long l6 = parambn;
            parambn = l29;
          }
          label1562: parambe1 = parambn;
          break label566:
          label1567: parambn = d11;
        }
        label1573: localObject1 = parambn;
        break label425:
        label1579: parambn = (bn)localObject1;
        break label528:
        label1585: parambn = (bn)localObject1;
      }
      label1591: parambn = (bn)localObject4;
    }
  }

  static boolean a(double paramDouble)
  {
    double d = paramDouble < 4612186418385984626L;
    int i;
    if (d <= 0)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }

  static boolean a(be parambe)
  {
    boolean bool = parambe.m();
    int i;
    if (bool)
    {
      bool = a(parambe.u());
      if (bool)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.s
 * JD-Core Version:    0.5.4
 */