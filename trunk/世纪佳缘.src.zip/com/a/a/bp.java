package com.a.a;

import com.a.aw;
import com.a.c;
import com.a.f;
import java.util.ArrayList;
import java.util.Comparator;

final class bp
{
  static final boolean a;
  private final bq b;

  static
  {
    if (!bp.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  public bp()
  {
    this(60);
  }

  public bp(int paramInt)
  {
    bq localbq = new bq(paramInt);
    this.b = localbq;
  }

  public be a(b paramb)
  {
    int i;
    a = i;
    Object localObject;
    if (i == 0)
    {
      localObject = paramb.a();
      Comparator localComparator1 = f.a;
      localObject = c.a((Iterable)localObject, localComparator1);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      localObject = paramb.b();
      Comparator localComparator2 = aw.c;
      localObject = c.a((Iterable)localObject, localComparator2);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      localObject = paramb.a();
      Comparator localComparator3 = f.a;
      localObject = c.b((Iterable)localObject, localComparator3);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      ArrayList localArrayList = paramb.b();
      Comparator localComparator4 = aw.c;
      if (!c.b(localArrayList, localComparator4))
        throw new AssertionError();
    }
    return (be)(be)this.b.a(paramb);
  }

  public void a(b paramb, be parambe)
  {
    int i;
    a = i;
    Object localObject;
    if (i == 0)
    {
      localObject = paramb.a();
      Comparator localComparator1 = f.a;
      localObject = c.a((Iterable)localObject, localComparator1);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      localObject = paramb.b();
      Comparator localComparator2 = aw.c;
      localObject = c.a((Iterable)localObject, localComparator2);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      localObject = paramb.a();
      Comparator localComparator3 = f.a;
      localObject = c.b((Iterable)localObject, localComparator3);
      if (localObject == 0)
        throw new AssertionError();
    }
    a = localObject;
    if (localObject == 0)
    {
      ArrayList localArrayList = paramb.b();
      Comparator localComparator4 = aw.c;
      if (!c.b(localArrayList, localComparator4))
        throw new AssertionError();
    }
    this.b.a(paramb, parambe);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bp
 * JD-Core Version:    0.5.4
 */