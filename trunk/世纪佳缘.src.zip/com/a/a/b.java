package com.a.a;

import com.a.ad;
import com.a.af;
import com.a.ax;
import com.a.bv;
import com.a.by;
import com.a.c;
import com.a.f;
import com.a.h;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public final class b
  implements Cloneable
{
  static final boolean a;
  private ArrayList b;
  private ArrayList c;
  private ArrayList d;

  static
  {
    if (!b.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = a;
      return;
    }
  }

  public b()
  {
    ArrayList localArrayList1 = new ArrayList();
    this.b = localArrayList1;
    ArrayList localArrayList2 = new ArrayList();
    this.c = localArrayList2;
    ArrayList localArrayList3 = new ArrayList();
    this.d = localArrayList3;
  }

  public b(ArrayList paramArrayList1, ArrayList paramArrayList2, be parambe)
  {
    if (paramArrayList1 != null)
    {
      localArrayList1 = (ArrayList)paramArrayList1.clone();
      label17: this.b = localArrayList1;
      if (paramArrayList2 == null)
        break label98;
    }
    for (ArrayList localArrayList1 = (ArrayList)paramArrayList2.clone(); ; localArrayList1 = new ArrayList())
    {
      this.c = localArrayList1;
      ArrayList localArrayList2 = new ArrayList();
      this.d = localArrayList1;
      if (parambe != null)
      {
        ArrayList localArrayList3 = this.d;
        be localbe = parambe.o();
        localArrayList3.add(localbe);
      }
      h();
      return;
      localArrayList1 = new ArrayList();
      label98: break label17:
    }
  }

  private static void a(ArrayList paramArrayList1, ArrayList paramArrayList2, boolean[] paramArrayOfBoolean)
  {
    int i;
    g.d = i;
    Object localObject1 = null;
    Iterator localIterator1 = paramArrayList2.iterator();
    do
    {
      label13: paramArrayList2 = localIterator1.hasNext();
      if (paramArrayList2 == 0)
        break label216;
      paramArrayList2 = (af)localIterator1.next();
      if (localObject1 == null)
        break;
      localObject3 = paramArrayList2.e();
      localh2 = localObject1.e();
      localObject3 = ((h)localObject3).equals(localh2);
    }
    while (localObject3 != 0);
    h localh1 = -1;
    Iterator localIterator2 = paramArrayList1.iterator();
    long l1 = -4480L;
    h localh2 = localh1;
    Object localObject3 = null;
    label94: boolean bool = localIterator2.hasNext();
    Object localObject2;
    long l4;
    if (bool)
    {
      localObject2 = (be)localIterator2.next();
      h localh3 = paramArrayList2.e();
      localObject2 = ((be)localObject2).e();
      long l2 = localh3.b((h)localObject2);
      Object localObject5;
      long l3 = localObject5 < l1;
      if (i == 0)
        if (localObject2 < 0)
        {
          l3 = localObject5 < 0L;
          if (localObject2 >= 0)
          {
            localObject2 = localObject3;
            l4 = localObject5;
            label181: ++localObject3;
            if (i == 0);
          }
        }
    }
    while (true)
    {
      label216: ArrayList localArrayList2;
      for (localObject3 = localObject2; ; localObject3 = localArrayList2)
      {
        Object localObject4 = -1;
        if (localObject2 > localObject4)
        {
          int j = 1;
          paramArrayOfBoolean[localObject3] = j;
        }
        if (i != 0)
          return;
        localArrayList1 = paramArrayList2;
        break label13:
        l1 = l4;
        localArrayList2 = localArrayList1;
        break label94:
        localArrayList1 = localArrayList2;
        l4 = l1;
        break label181:
      }
      ArrayList localArrayList1 = localArrayList2;
    }
  }

  private static void a(ArrayList paramArrayList, boolean[] paramArrayOfBoolean)
  {
    af localaf1 = -1;
    int i;
    g.d = i;
    int j = 0;
    int l = 0;
    int i1 = localaf1;
    Object localObject2 = j;
    while (true)
    {
      int k = paramArrayList.size();
      af localaf2;
      Object localObject1;
      if (l < k)
      {
        localaf2 = (af)paramArrayList.get(l);
        if (i == 0)
        {
          if ((localObject2 != 0) && (af.f.compare(localaf2, localObject2) >= 0))
            break label95;
          localObject1 = localaf2;
          localaf2 = l;
          label76: ++l;
          if (i == 0)
            break label113;
        }
      }
      while (true)
      {
        if (localaf2 > localaf1)
          paramArrayOfBoolean[localaf2] = true;
        return;
        label95: localaf2 = localObject1;
        localObject1 = localObject2;
        break label76:
        localaf2 = localObject1;
      }
      label113: localObject2 = localObject1;
      int i2 = localaf2;
    }
  }

  private static void a(Collection paramCollection)
  {
    if (paramCollection.size() <= 1)
      return;
    Comparator localComparator = af.f;
    af localaf = (af)Collections.min(paramCollection, localComparator);
    a locala = new a(localaf);
    c.a(paramCollection, locala);
  }

  private void h()
  {
    if ((this.d.isEmpty()) || (!e()));
    while (true)
    {
      return;
      boolean[] arrayOfBoolean = new boolean[this.d.size()];
      Arrays.fill(arrayOfBoolean, null);
      ArrayList localArrayList1 = this.d;
      ArrayList localArrayList2 = this.b;
      a(localArrayList1, localArrayList2, arrayOfBoolean);
      ArrayList localArrayList3 = this.d;
      ArrayList localArrayList4 = this.c;
      a(localArrayList3, localArrayList4, arrayOfBoolean);
      a(this.d, arrayOfBoolean);
      c.a(this.d, arrayOfBoolean);
    }
  }

  public final ArrayList a()
  {
    return this.b;
  }

  public boolean a(b paramb)
  {
    Object localObject1 = this.b;
    ArrayList localArrayList1 = paramb.b;
    Comparator localComparator1 = f.a;
    localObject1 = c.a((ArrayList)localObject1, localArrayList1, localComparator1);
    int i;
    if (localObject1 != 0)
    {
      localObject1 = this.c;
      ArrayList localArrayList2 = paramb.c;
      Comparator localComparator2 = ad.c;
      localObject1 = c.a((ArrayList)localObject1, localArrayList2, localComparator2);
      if (localObject1 != 0)
        i = 1;
    }
    while (true)
    {
      return i;
      Object localObject2 = null;
    }
  }

  public final ArrayList b()
  {
    return this.c;
  }

  public final ArrayList c()
  {
    return this.d;
  }

  public int d()
  {
    int i = this.b.size();
    int j = this.c.size();
    int k = i + j;
    int l = this.d.size();
    return k + l;
  }

  public boolean e()
  {
    boolean bool = this.b.isEmpty();
    if (bool)
    {
      bool = this.c.isEmpty();
      if (bool)
        break label28;
    }
    int i = 1;
    while (true)
    {
      return i;
      label28: Object localObject = null;
    }
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    int i;
    g.d = i;
    if (paramObject == null);
    label13: label77: label249: Object localObject3;
    label263: for (Object localObject2 = localObject1; ; localObject3 = localObject1)
      while (true)
      {
        return localObject2;
        try
        {
          paramObject = (b)paramObject;
          localObject2 = this.b.size();
          int k = paramObject.b.size();
          if (localObject2 == k)
          {
            localObject2 = this.c.size();
            k = paramObject.c.size();
            if (localObject2 == k)
              break label77;
          }
          localObject2 = localObject1;
          break label13:
          Iterator localIterator = this.b.iterator();
          localObject2 = paramObject.b;
          Object localObject4 = ((ArrayList)localObject2).iterator();
          do
          {
            localObject2 = localIterator.hasNext();
            if (localObject2 == 0)
              break label163;
            bv localbv = ((by)localIterator.next()).a();
            localObject2 = ((by)((Iterator)localObject4).next()).a();
            localObject2 = localbv.equals(localObject2);
          }
          while (localObject2 != 0);
          localObject2 = localObject1;
          break label13:
          label163: localObject2 = this.c.iterator();
          localIterator = paramObject.c.iterator();
          do
          {
            localObject4 = ((Iterator)localObject2).hasNext();
            if (localObject4 == 0)
              break label249;
            localObject4 = ((ad)((Iterator)localObject2).next()).a();
            ax localax = ((ad)localIterator.next()).a();
            localObject4 = ((ax)localObject4).equals(localax);
          }
          while (localObject4 != 0);
          if (i != 0)
            break label263;
          localObject2 = localObject1;
          break label13:
          int j = 1;
        }
        catch (ClassCastException localObject3)
        {
          localObject3 = localObject1;
        }
      }
  }

  public b f()
  {
    b localb = g();
    a(localb.b);
    a(localb.c);
    localb.h();
    return localb;
  }

  public b g()
  {
    try
    {
      b localb = (b)super.clone();
      ArrayList localArrayList1 = (ArrayList)this.b.clone();
      localb.b = localArrayList1;
      ArrayList localArrayList2 = (ArrayList)this.c.clone();
      localb.c = localArrayList2;
      ArrayList localArrayList3 = (ArrayList)this.d.clone();
      localb.d = this;
      return localb;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new RuntimeException(localCloneNotSupportedException);
    }
  }

  public int hashCode()
  {
    int i = 0;
    int j = this.b.size();
    if (j > 0)
      j = ((by)this.b.get(i)).a().hashCode();
    while (true)
    {
      return j;
      j = this.c.size();
      if (j > 0)
        j = ((ad)this.c.get(i)).a().hashCode();
      j = i;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.b
 * JD-Core Version:    0.5.4
 */