package com.a.a;

public abstract interface r extends Runnable
{
  public abstract void a();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.r
 * JD-Core Version:    0.5.4
 */