package com.a.a;

import com.a.ag;
import java.util.Map;

public class bq
{
  static final boolean a;
  private static final String[] f;
  private final Map b;
  private final ag c;
  private int d;
  private int e;

  static
  {
    int i = 70;
    int j = 24;
    int k = 4;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[5];
    char[] arrayOfChar1 = "s#>Sim53Sjw2g\021a8(2\037h".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject24;
    Object localObject26;
    Object localObject9;
    Object localObject19;
    int i2;
    int i5;
    label115: Object localObject3;
    if (localObject8 <= l)
    {
      Object localObject18 = localObject1;
      localObject24 = localObject8;
      localObject26 = localObject18;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar3 = localObject18;
      localObject19 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject24)
      {
        i2 = localObject9[arrayOfChar1];
        i5 = localObject26 % 5;
        switch (i5)
        {
        default:
          i5 = k;
          i2 = (char)(i2 ^ i5);
          localObject9[arrayOfChar1] = i2;
          localObject2 = localObject26 + 1;
          if (localObject24 != 0)
            break;
          localObject9 = localObject19;
          localObject26 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject24;
      Object localObject27 = localObject19;
      localObject19 = localObject2;
      localObject3 = localObject27;
    }
    while (true)
    {
      if (localObject9 <= localObject19);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "n'+\006a8+2纮p8((\007$z#g\035qt".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label295: Object localObject5;
      if (localObject10 <= l)
      {
        localObject19 = localObject1;
        localObject24 = localObject10;
        localObject26 = localObject19;
        localObject11 = localObject3;
        Object localObject28 = localObject19;
        localObject19 = localObject3;
        Object localObject4;
        for (localObject3 = localObject28; ; localObject4 = localObject24)
        {
          i2 = localObject11[localObject3];
          i5 = localObject26 % 5;
          switch (i5)
          {
          default:
            i5 = k;
            i2 = (char)(i2 ^ i5);
            localObject11[localObject3] = i2;
            localObject4 = localObject26 + 1;
            if (localObject24 != 0)
              break;
            localObject11 = localObject19;
            localObject26 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject24;
        Object localObject29 = localObject19;
        localObject19 = localObject4;
        localObject5 = localObject29;
      }
      while (true)
      {
        if (localObject11 <= localObject19);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject11 = "u/4�".toCharArray();
        Object localObject20 = localObject11.length;
        Object localObject21;
        Object localObject25;
        int i6;
        label475: Object localObject13;
        if (localObject20 <= l)
        {
          localObject24 = localObject1;
          localObject26 = localObject20;
          i2 = localObject24;
          localObject21 = localObject11;
          Object localObject30 = localObject24;
          localObject25 = localObject11;
          Object localObject12;
          for (localObject11 = localObject30; ; localObject12 = localObject26)
          {
            i5 = localObject21[localObject11];
            i6 = i2 % 5;
            switch (i6)
            {
            default:
              i6 = k;
              i5 = (char)(i5 ^ i6);
              localObject21[localObject11] = i5;
              localObject12 = i2 + 1;
              if (localObject26 != 0)
                break;
              localObject21 = localObject25;
              i2 = localObject12;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject21 = localObject26;
          Object localObject31 = localObject25;
          localObject25 = localObject12;
          localObject13 = localObject31;
        }
        while (true)
        {
          if (localObject21 <= localObject25);
          localObject13 = new String(localObject13).intern();
          arrayOfString[i1] = localObject13;
          i1 = 3;
          localObject13 = "{'$\033a8c4S,p/3Svy2\"I$=\"hV`4fb]6~cbZ".toCharArray();
          Object localObject22 = localObject13.length;
          label659: Object localObject15;
          if (localObject22 <= l)
          {
            localObject25 = localObject1;
            localObject26 = localObject22;
            int i3 = localObject25;
            localObject23 = localObject13;
            Object localObject32 = localObject25;
            localObject25 = localObject13;
            Object localObject14;
            for (localObject13 = localObject32; ; localObject14 = localObject26)
            {
              i5 = localObject23[localObject13];
              i6 = i3 % 5;
              switch (i6)
              {
              default:
                i6 = k;
                i5 = (char)(i5 ^ i6);
                localObject23[localObject13] = i5;
                localObject14 = i3 + 1;
                if (localObject26 != 0)
                  break;
                localObject23 = localObject25;
                i3 = localObject14;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject23 = localObject26;
            Object localObject33 = localObject25;
            localObject25 = localObject14;
            localObject15 = localObject33;
          }
          while (true)
          {
            if (localObject23 <= localObject25);
            localObject23 = new String(localObject15);
            localObject15 = ((String)localObject23).intern();
            arrayOfString[i1] = localObject15;
            char[] arrayOfChar2 = "p/3".toCharArray();
            Object localObject16 = arrayOfChar2.length;
            Object localObject17;
            label843: Object localObject7;
            if (localObject16 <= l)
            {
              localObject23 = localObject1;
              localObject25 = localObject16;
              localObject26 = localObject23;
              localObject17 = arrayOfChar2;
              char[] arrayOfChar4 = localObject23;
              localObject23 = arrayOfChar2;
              Object localObject6;
              for (arrayOfChar2 = arrayOfChar4; ; localObject6 = localObject25)
              {
                int i4 = localObject17[arrayOfChar2];
                i5 = localObject26 % 5;
                switch (i5)
                {
                default:
                  i5 = k;
                  int i7 = (char)(i4 ^ i5);
                  localObject17[arrayOfChar2] = i4;
                  localObject6 = localObject26 + 1;
                  if (localObject25 != 0)
                    break;
                  localObject17 = localObject23;
                  localObject26 = localObject6;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject17 = localObject25;
              Object localObject34 = localObject23;
              localObject23 = localObject6;
              localObject7 = localObject34;
            }
            while (true)
            {
              if (localObject17 <= localObject23);
              String str = new String(localObject7).intern();
              arrayOfString[k] = localObject7;
              f = arrayOfString;
              if (!bq.class.desiredAssertionStatus())
                int i8 = l;
              while (true)
              {
                boolean bool = a;
                return;
                int i9 = localObject1;
              }
              i5 = j;
              break label115:
              i5 = i;
              break label115:
              i5 = 71;
              break label115:
              i5 = 115;
              break label115:
              i5 = j;
              break label295:
              i5 = i;
              break label295:
              i5 = 71;
              break label295:
              i5 = 115;
              break label295:
              i6 = j;
              break label475:
              i6 = i;
              break label475:
              i6 = 71;
              break label475:
              i6 = 115;
              break label475:
              i6 = j;
              break label659:
              i6 = i;
              break label659:
              i6 = 71;
              break label659:
              i6 = 115;
              break label659:
              i5 = j;
              break label843:
              i5 = i;
              break label843:
              i5 = 71;
              break label843:
              i5 = 115;
              break label843:
              localObject23 = localObject1;
            }
            localObject25 = localObject1;
          }
          localObject25 = localObject1;
        }
        localObject23 = localObject1;
      }
      Object localObject23 = localObject1;
    }
  }

  public bq()
  {
    this(60);
  }

  public bq(int paramInt)
  {
    ag localag = ag.b(bq.class);
    this.c = localag;
    bq localbq = this;
    int i = paramInt;
    int j = paramInt;
    d locald = new d(localbq, i, 1061158912, true, j);
    this.b = locald;
    a = locald;
    if ((locald == null) && (this.b.size() > paramInt))
      throw new AssertionError();
    a();
  }

  private void a()
  {
    this.e = null;
    this.d = null;
  }

  private void b(Object paramObject)
  {
    int i = 4;
    int j = 3;
    int k = 2;
    boolean bool1 = true;
    String str1 = 0;
    boolean bool2 = this.c.a();
    if (!bool2)
      label27: return;
    label36: ag localag;
    String str3;
    Object[] arrayOfObject;
    if (paramObject != null)
    {
      bool2 = bool1;
      int l = this.d;
      this.d = (++l);
      if (bool2)
      {
        l = this.e;
        this.e = (++l);
      }
      localag = this.c;
      str3 = f[j];
      arrayOfObject = new Object[i];
      if (!bool2)
        break label205;
    }
    for (String str2 = f[i]; ; str2 = f[k])
    {
      arrayOfObject[str1] = str2;
      Integer localInteger1 = Integer.valueOf(this.e);
      arrayOfObject[bool1] = str2;
      Integer localInteger2 = Integer.valueOf(this.d);
      arrayOfObject[k] = str2;
      double d1 = this.e;
      Object localObject1;
      double d2 = 4636737291354636288L * localObject1;
      double d3 = this.d;
      Object localObject2;
      Double localDouble = Double.valueOf(localObject2 / localObject1);
      arrayOfObject[j] = str2;
      String str4 = String.format(str3, arrayOfObject);
      localag.b(str2);
      break label27:
      str2 = str1;
      label205: break label36:
    }
  }

  public Object a(Object paramObject)
  {
    Object localObject = this.b.get(paramObject);
    b(localObject);
    return localObject;
  }

  public void a(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == null)
    {
      String str1 = f[null];
      throw new NullPointerException(str1);
    }
    if (paramObject2 == null)
    {
      String str2 = f[1];
      throw new NullPointerException(str2);
    }
    this.b.put(paramObject1, paramObject2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bq
 * JD-Core Version:    0.5.4
 */