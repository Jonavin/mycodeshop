package com.a.a;

import Z;
import com.a.af;
import com.a.ag;
import com.a.bo;
import com.a.h;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

final class bt
{
  static final boolean a;
  private static final String e;
  private final ag b;
  private final br c;
  private final ab d;

  static
  {
    int i = 1;
    char[] arrayOfChar1 = 0;
    char[] arrayOfChar2 = "~\020ICXmYDDR*\025JIWfYCCZoYUKBb\n\005DY~YFEXl\020B_Do\035\t\nZe\032DFZsYAOBo\013HCXo\035\005]_l\020\005L_rYRCZfYKEB*\033@\nW|\030LFWh\025@\004".toCharArray();
    Object localObject2 = arrayOfChar2.length;
    Object localObject3;
    char[] arrayOfChar5;
    int l;
    label88: Object localObject1;
    if (localObject2 <= i)
    {
      char[] arrayOfChar4 = arrayOfChar1;
      Object localObject4 = localObject2;
      int j = arrayOfChar4;
      localObject3 = arrayOfChar2;
      char[] arrayOfChar6 = arrayOfChar4;
      arrayOfChar5 = arrayOfChar2;
      char[] arrayOfChar3;
      for (arrayOfChar2 = arrayOfChar6; ; arrayOfChar3 = localObject4)
      {
        int k = localObject3[arrayOfChar2];
        l = j % 5;
        switch (l)
        {
        default:
          l = 54;
          int i1 = (char)(k ^ l);
          localObject3[arrayOfChar2] = k;
          arrayOfChar3 = j + 1;
          if (localObject4 != 0)
            break;
          localObject3 = arrayOfChar5;
          j = arrayOfChar3;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject3 = localObject4;
      char[] arrayOfChar7 = arrayOfChar5;
      arrayOfChar5 = arrayOfChar3;
      localObject1 = arrayOfChar7;
    }
    while (true)
    {
      if (localObject3 <= arrayOfChar5);
      e = new String(localObject1).intern();
      if (!bt.class.desiredAssertionStatus())
        int i2 = i;
      while (true)
      {
        boolean bool = a;
        return;
        int i3 = arrayOfChar1;
      }
      l = 10;
      break label88:
      l = 121;
      break label88:
      l = 37;
      break label88:
      l = 42;
      break label88:
      arrayOfChar5 = arrayOfChar1;
    }
  }

  bt(ai paramai, List paramList, bu parambu)
  {
    ag localag = ag.b(bt.class);
    this.b = localag;
    br localbr = br.c();
    this.c = localbr;
    ab localab = new ab(paramai, paramList, parambu);
    this.d = localab;
  }

  bo a(g paramg, b paramb, boolean paramBoolean1, boolean paramBoolean2, long paramLong, List paramList)
  {
    List paramList = new ArrayList();
    boolean bool1 = this.d.b();
    Object localObject2;
    if (!bool1)
    {
      localObject1 = this.b;
      localObject2 = e;
      ((ag)localObject1).c((String)localObject2);
      g.d = (Z)localObject1;
      if (localObject1 == null)
        break label65;
    }
    Object localObject1 = this.d;
    ((ab)localObject1).a(paramb, paramList);
    label65: localObject1 = paramb.c().isEmpty();
    if (localObject1 != 0)
      localObject1 = null;
    h localh1;
    for (Object localObject3 = localObject1; ; localObject3 = localObject1)
    {
      localh1 = h.d();
      long l1 = System.currentTimeMillis();
      localObject1 = this.c;
      ArrayList localArrayList = paramb.a();
      localObject2 = paramg;
      boolean bool2 = paramBoolean1;
      boolean bool3 = paramBoolean2;
      long l2 = paramLong;
      Object localObject4 = ???;
      localObject1 = ((br)localObject1).a((g)localObject2, localArrayList, paramList, localObject3, bool2, bool3, l2, localObject4, localh1);
      localObject2 = ((bo)localObject1).b;
      if (localObject2 == null)
        break label300;
      this = (be)((bo)localObject1).b;
      localObject2 = super.n();
      if (localObject2 != 0)
        break label273;
      a = localObject2;
      if ((localObject2 != 0) || (((be)((bo)localObject1).b).e() != null))
        break;
      throw new AssertionError();
      localObject1 = paramb.c();
      localObject2 = af.f;
      localObject1 = (be)Collections.min((Collection)localObject1, (Comparator)localObject2);
    }
    h localh2 = super.e();
    long l3 = localh1.b(localh2);
    Object localObject5;
    Object localObject6;
    long l4 = localObject5 - localObject6;
    super.a(l4);
    if (super.m())
    {
      label273: double d1 = super.u() * 4660134898793709568L / 4652007308841189376L;
      super.e(d1);
    }
    label300: Object localObject7 = ((bo)localObject1).a;
    bh localbh = bh.c;
    if ((localObject7 == localbh) && (!paramb.b().isEmpty()))
      localObject1 = bo.a(bh.f, null);
    return (bo)(bo)localObject1;
  }

  void a()
  {
    if (!this.d.b())
      return;
    this.d.a();
  }

  void a(ai paramai)
  {
    this.d.a(paramai);
  }

  void b()
  {
    this.d.c();
  }

  boolean c()
  {
    return this.d.b();
  }

  long d()
  {
    return this.c.a();
  }

  long e()
  {
    return this.c.b();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bt
 * JD-Core Version:    0.5.4
 */