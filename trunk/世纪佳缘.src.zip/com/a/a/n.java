package com.a.a;

abstract class n
  implements r
{
  protected final c a;

  n()
  {
    c localc = new c();
    this.a = localc;
  }

  public void a()
  {
    this.a.a();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.n
 * JD-Core Version:    0.5.4
 */