package com.a.a;

import com.a.bf;
import java.io.Serializable;

public class ce extends g
  implements Serializable, Cloneable
{
  private static final String[] m;
  b e;
  private int f;
  private int g;
  private int h;
  private double i;
  private double j;
  private boolean k;
  private ah l;

  static
  {
    int i1 = 53;
    int i2 = 32;
    int i3 = 15;
    int i4 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[8];
    char[] arrayOfChar1 = "\t/".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject36;
    Object localObject38;
    Object localObject7;
    Object localObject23;
    int i6;
    int i12;
    label116: Object localObject3;
    if (localObject6 <= i4)
    {
      Object localObject22 = localObject1;
      localObject36 = localObject6;
      localObject38 = localObject22;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject22;
      localObject23 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject36)
      {
        i6 = localObject7[arrayOfChar1];
        i12 = localObject38 % 5;
        switch (i12)
        {
        default:
          i12 = 113;
          i6 = (char)(i6 ^ i12);
          localObject7[arrayOfChar1] = i6;
          localObject2 = localObject38 + 1;
          if (localObject36 != 0)
            break;
          localObject7 = localObject23;
          localObject38 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject36;
      Object localObject39 = localObject23;
      localObject23 = localObject2;
      localObject3 = localObject39;
    }
    while (true)
    {
      if (localObject7 <= localObject23);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "DjR\030".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= i4)
      {
        localObject23 = localObject1;
        localObject36 = localObject8;
        localObject38 = localObject23;
        localObject9 = localObject3;
        Object localObject40 = localObject23;
        localObject23 = localObject3;
        Object localObject4;
        for (localObject3 = localObject40; ; localObject4 = localObject36)
        {
          i6 = localObject9[localObject3];
          i12 = localObject38 % 5;
          switch (i12)
          {
          default:
            i12 = 113;
            i6 = (char)(i6 ^ i12);
            localObject9[localObject3] = i6;
            localObject4 = localObject38 + 1;
            if (localObject36 != 0)
              break;
            localObject9 = localObject23;
            localObject38 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject36;
        Object localObject41 = localObject23;
        localObject23 = localObject4;
        localObject5 = localObject41;
      }
      while (true)
      {
        if (localObject9 <= localObject23);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i4] = localObject5;
        int i5 = 2;
        localObject9 = "M|".toCharArray();
        Object localObject24 = localObject9.length;
        Object localObject25;
        Object localObject37;
        int i13;
        label480: Object localObject11;
        if (localObject24 <= i4)
        {
          localObject36 = localObject1;
          localObject38 = localObject24;
          i6 = localObject36;
          localObject25 = localObject9;
          Object localObject42 = localObject36;
          localObject37 = localObject9;
          Object localObject10;
          for (localObject9 = localObject42; ; localObject10 = localObject38)
          {
            i12 = localObject25[localObject9];
            i13 = i6 % 5;
            switch (i13)
            {
            default:
              i13 = 113;
              i12 = (char)(i12 ^ i13);
              localObject25[localObject9] = i12;
              localObject10 = i6 + 1;
              if (localObject38 != 0)
                break;
              localObject25 = localObject37;
              i6 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject25 = localObject38;
          Object localObject43 = localObject37;
          localObject37 = localObject10;
          localObject11 = localObject43;
        }
        while (true)
        {
          if (localObject25 <= localObject37);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i5] = localObject11;
          i5 = 3;
          localObject11 = "M/TT\005".toCharArray();
          Object localObject26 = localObject11.length;
          Object localObject27;
          label664: Object localObject13;
          if (localObject26 <= i4)
          {
            localObject37 = localObject1;
            localObject38 = localObject26;
            int i7 = localObject37;
            localObject27 = localObject11;
            Object localObject44 = localObject37;
            localObject37 = localObject11;
            Object localObject12;
            for (localObject11 = localObject44; ; localObject12 = localObject38)
            {
              i12 = localObject27[localObject11];
              i13 = i7 % 5;
              switch (i13)
              {
              default:
                i13 = 113;
                i12 = (char)(i12 ^ i13);
                localObject27[localObject11] = i12;
                localObject12 = i7 + 1;
                if (localObject38 != 0)
                  break;
                localObject27 = localObject37;
                i7 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject27 = localObject38;
            Object localObject45 = localObject37;
            localObject37 = localObject12;
            localObject13 = localObject45;
          }
          while (true)
          {
            if (localObject27 <= localObject37);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i5] = localObject13;
            i5 = 4;
            localObject13 = "M/\035".toCharArray();
            Object localObject28 = localObject13.length;
            Object localObject29;
            label848: Object localObject15;
            if (localObject28 <= i4)
            {
              localObject37 = localObject1;
              localObject38 = localObject28;
              int i8 = localObject37;
              localObject29 = localObject13;
              Object localObject46 = localObject37;
              localObject37 = localObject13;
              Object localObject14;
              for (localObject13 = localObject46; ; localObject14 = localObject38)
              {
                i12 = localObject29[localObject13];
                i13 = i8 % 5;
                switch (i13)
                {
                default:
                  i13 = 113;
                  i12 = (char)(i12 ^ i13);
                  localObject29[localObject13] = i12;
                  localObject14 = i8 + 1;
                  if (localObject38 != 0)
                    break;
                  localObject29 = localObject37;
                  i8 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject29 = localObject38;
              Object localObject47 = localObject37;
              localObject37 = localObject14;
              localObject15 = localObject47;
            }
            while (true)
            {
              if (localObject29 <= localObject37);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i5] = localObject15;
              i5 = 5;
              localObject15 = "纮$\032".toCharArray();
              Object localObject30 = localObject15.length;
              Object localObject31;
              label1032: Object localObject17;
              if (localObject30 <= i4)
              {
                localObject37 = localObject1;
                localObject38 = localObject30;
                int i9 = localObject37;
                localObject31 = localObject15;
                Object localObject48 = localObject37;
                localObject37 = localObject15;
                Object localObject16;
                for (localObject15 = localObject48; ; localObject16 = localObject38)
                {
                  i12 = localObject31[localObject15];
                  i13 = i9 % 5;
                  switch (i13)
                  {
                  default:
                    i13 = 113;
                    i12 = (char)(i12 ^ i13);
                    localObject31[localObject15] = i12;
                    localObject16 = i9 + 1;
                    if (localObject38 != 0)
                      break;
                    localObject31 = localObject37;
                    i9 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject31 = localObject38;
                Object localObject49 = localObject37;
                localObject37 = localObject16;
                localObject17 = localObject49;
              }
              while (true)
              {
                if (localObject31 <= localObject37);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i5] = localObject17;
                i5 = 6;
                localObject17 = "\f/".toCharArray();
                Object localObject32 = localObject17.length;
                Object localObject33;
                label1216: Object localObject19;
                if (localObject32 <= i4)
                {
                  localObject37 = localObject1;
                  localObject38 = localObject32;
                  int i10 = localObject37;
                  localObject33 = localObject17;
                  Object localObject50 = localObject37;
                  localObject37 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject50; ; localObject18 = localObject38)
                  {
                    i12 = localObject33[localObject17];
                    i13 = i10 % 5;
                    switch (i13)
                    {
                    default:
                      i13 = 113;
                      i12 = (char)(i12 ^ i13);
                      localObject33[localObject17] = i12;
                      localObject18 = i10 + 1;
                      if (localObject38 != 0)
                        break;
                      localObject33 = localObject37;
                      i10 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject33 = localObject38;
                  Object localObject51 = localObject37;
                  localObject37 = localObject18;
                  localObject19 = localObject51;
                }
                while (true)
                {
                  if (localObject33 <= localObject37);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i5] = localObject19;
                  i5 = 7;
                  localObject19 = "Kb\032PQ".toCharArray();
                  Object localObject34 = localObject19.length;
                  label1400: Object localObject21;
                  if (localObject34 <= i4)
                  {
                    localObject37 = localObject1;
                    localObject38 = localObject34;
                    int i11 = localObject37;
                    localObject35 = localObject19;
                    Object localObject52 = localObject37;
                    localObject37 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject52; ; localObject20 = localObject38)
                    {
                      i12 = localObject35[localObject19];
                      i13 = i11 % 5;
                      switch (i13)
                      {
                      default:
                        i13 = 113;
                        int i14 = (char)(i12 ^ i13);
                        localObject35[localObject19] = i12;
                        localObject20 = i11 + 1;
                        if (localObject38 != 0)
                          break;
                        localObject35 = localObject37;
                        i11 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject35 = localObject38;
                    Object localObject53 = localObject37;
                    localObject37 = localObject20;
                    localObject21 = localObject53;
                  }
                  while (true)
                  {
                    if (localObject35 <= localObject37);
                    String str = new String(localObject21).intern();
                    arrayOfString[i5] = localObject21;
                    m = arrayOfString;
                    return;
                    i12 = i2;
                    break label116:
                    i12 = i3;
                    break label116:
                    i12 = i1;
                    break label116:
                    i12 = 56;
                    break label116:
                    i12 = i2;
                    break label296:
                    i12 = i3;
                    break label296:
                    i12 = i1;
                    break label296:
                    i12 = 56;
                    break label296:
                    i13 = i2;
                    break label480:
                    i13 = i3;
                    break label480:
                    i13 = i1;
                    break label480:
                    i13 = 56;
                    break label480:
                    i13 = i2;
                    break label664:
                    i13 = i3;
                    break label664:
                    i13 = i1;
                    break label664:
                    i13 = 56;
                    break label664:
                    i13 = i2;
                    break label848:
                    i13 = i3;
                    break label848:
                    i13 = i1;
                    break label848:
                    i13 = 56;
                    break label848:
                    i13 = i2;
                    break label1032:
                    i13 = i3;
                    break label1032:
                    i13 = i1;
                    break label1032:
                    i13 = 56;
                    break label1032:
                    i13 = i2;
                    break label1216:
                    i13 = i3;
                    break label1216:
                    i13 = i1;
                    break label1216:
                    i13 = 56;
                    break label1216:
                    i13 = i2;
                    break label1400:
                    i13 = i3;
                    break label1400:
                    i13 = i1;
                    break label1400:
                    i13 = 56;
                    break label1400:
                    localObject37 = localObject1;
                  }
                  localObject37 = localObject1;
                }
                localObject37 = localObject1;
              }
              localObject37 = localObject1;
            }
            localObject37 = localObject1;
          }
          localObject37 = localObject1;
        }
        localObject35 = localObject1;
      }
      Object localObject35 = localObject1;
    }
  }

  protected ce()
  {
  }

  public ce(double paramDouble1, double paramDouble2, long paramLong, int paramInt1, int paramInt2, int paramInt3, double paramDouble3, double paramDouble4, boolean paramBoolean, ah paramah, b paramb)
  {
    super(paramDouble1, ???, paramDouble2);
    this.f = ???;
    this.g = paramLong;
    this.h = ???;
    this.i = paramInt1;
    this.j = paramInt2;
    boolean paramBoolean = paramInt3;
    this.k = paramBoolean;
    ah paramah = paramDouble3;
    this.l = paramah;
    b paramb = ???;
    this.e = paramb;
  }

  protected void a(int paramInt)
  {
    this.f = paramInt;
  }

  public void a(ah paramah)
  {
    this.l = paramah;
  }

  void a(boolean paramBoolean)
  {
    this.k = paramBoolean;
  }

  protected void b(int paramInt)
  {
    this.g = paramInt;
  }

  protected void c(int paramInt)
  {
    this.h = paramInt;
  }

  protected void d(double paramDouble)
  {
    this.j = paramDouble;
  }

  protected void e(double paramDouble)
  {
    this.i = paramDouble;
  }

  public ce q()
  {
    try
    {
      ce localce = (ce)super.clone();
      if (this.l != null)
      {
        ah localah = this.l.a();
        localce.l = localah;
      }
      if (this.e != null)
      {
        b localb = this.e.g();
        localce.e = localb;
      }
      return localce;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new RuntimeException(localCloneNotSupportedException);
    }
  }

  public int r()
  {
    return this.f;
  }

  public int s()
  {
    return this.g;
  }

  public int t()
  {
    return this.h;
  }

  public String toString()
  {
    int i1;
    g.d = i1;
    Object localObject1 = new StringBuilder();
    double d1 = Math.round(a_() * 4711630319722168320L) / 4711630319722168320L;
    localObject1 = ((StringBuilder)localObject1).append(d1);
    String str1 = m[6];
    localObject1 = ((StringBuilder)localObject1).append(str1);
    d1 = Math.round(b() * 4711630319722168320L) / 4711630319722168320L;
    localObject1 = ((StringBuilder)localObject1).append(d1);
    str1 = m[5];
    localObject1 = ((StringBuilder)localObject1).append(str1);
    int i2 = Math.round(r() * 10) / 10;
    localObject1 = ((StringBuilder)localObject1).append(i2);
    Object localObject2 = m[4];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    localObject2 = s();
    localObject1 = ((StringBuilder)localObject1).append(localObject2).append("+");
    localObject2 = t();
    localObject1 = ((StringBuilder)localObject1).append(localObject2);
    localObject2 = m[null];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    long l1 = Math.round(u() * 4621819117588971520L) / 10L;
    localObject1 = ((StringBuilder)localObject1).append(l1);
    localObject2 = m[7];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    l1 = Math.round(v() * 4621819117588971520L) / 10L;
    localObject1 = ((StringBuilder)localObject1).append(l1);
    localObject2 = m[1];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    localObject2 = f();
    label301: ah localah;
    if (localObject2 != 0)
    {
      localObject2 = new StringBuilder().append(" ");
      double d2 = d();
      Object localObject3;
      localObject2 = ((StringBuilder)localObject2).append(localObject3);
      String str2 = m[3];
      localObject2 = str2;
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
      localObject2 = this.l;
      if (localObject2 == null)
        break label387;
      localObject2 = new StringBuilder().append("\n");
      localah = this.l;
    }
    label387: String str3;
    for (localObject2 = localah; ; localObject2 = str3)
    {
      localObject1 = (String)localObject2;
      if (i1 != 0)
      {
        int i3 = bf.d;
        ++i1;
        bf.d = i3;
      }
      return localObject1;
      localObject2 = "";
      break label301:
      localObject2 = new StringBuilder().append(" ");
      long l2 = c();
      Object localObject4;
      localObject2 = ((StringBuilder)localObject2).append(localObject4);
      str3 = m[2];
    }
  }

  public double u()
  {
    return this.i;
  }

  public double v()
  {
    return this.j;
  }

  boolean w()
  {
    return this.k;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.ce
 * JD-Core Version:    0.5.4
 */