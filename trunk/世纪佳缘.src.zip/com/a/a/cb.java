package com.a.a;

import java.util.ArrayList;

final class cb
  implements com.a.cb
{
  static final boolean b;
  public int a = null;
  final ArrayList c;
  final ArrayList d;

  static
  {
    if (!bo.class.desiredAssertionStatus());
    while (true)
    {
      boolean bool = b;
      return;
    }
  }

  cb(ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
  }

  public void a(int paramInt1, int paramInt2)
  {
    int i;
    b = i;
    if ((i == 0) && (((this.a > paramInt1) || (this.a > paramInt2))))
      throw new AssertionError();
    ArrayList localArrayList1 = this.c;
    int j = this.a;
    Object localObject1 = this.c.get(paramInt1);
    localArrayList1.set(j, localObject1);
    ArrayList localArrayList2 = this.d;
    int k = this.a;
    Object localObject2 = this.d.get(paramInt2);
    localArrayList2.set(k, localObject2);
    int l = this.a;
    ++i;
    this.a = l;
  }

  public void b(int paramInt1, int paramInt2)
  {
  }

  public void c(int paramInt1, int paramInt2)
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.cb
 * JD-Core Version:    0.5.4
 */