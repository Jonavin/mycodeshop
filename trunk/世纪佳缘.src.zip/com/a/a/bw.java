package com.a.a;

public final class bw extends g
{
  private static final String[] g;
  protected final String e;
  protected final ah f;

  static
  {
    int i = 28;
    int j = 15;
    int k = 10;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "&\017".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "*\025".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        g = arrayOfString;
        return;
        i3 = k;
        break label115:
        i3 = 47;
        break label115:
        i3 = i;
        break label115:
        i3 = 29;
        break label115:
        i3 = k;
        break label295:
        i3 = 47;
        break label295:
        i3 = i;
        break label295:
        i3 = 29;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  bw(double paramDouble1, double paramDouble2, long paramLong, String paramString, ah paramah)
  {
    super(paramDouble1, ???, paramDouble2);
    this.e = ???;
    this.f = paramLong;
  }

  public String e()
  {
    return this.e;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Object localObject1 = e();
    localStringBuilder = localStringBuilder.append((String)localObject1);
    localObject1 = g[1];
    localStringBuilder = localStringBuilder.append((String)localObject1);
    localObject1 = a_();
    Object localObject2;
    localStringBuilder = localStringBuilder.append(localObject2);
    localObject1 = g[null];
    localStringBuilder = localStringBuilder.append((String)localObject1);
    localObject1 = b();
    localStringBuilder = localStringBuilder.append(localObject2);
    localObject1 = this.f;
    ah localah;
    if (localObject1 != null)
    {
      localObject1 = new StringBuilder().append("\n");
      localah = this.f;
    }
    for (localObject1 = localah; ; localObject1 = "")
      return (String)localObject1;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bw
 * JD-Core Version:    0.5.4
 */