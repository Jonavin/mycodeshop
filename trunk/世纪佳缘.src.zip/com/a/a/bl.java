package com.a.a;

import com.a.bo;
import java.util.concurrent.Callable;

class bl
  implements Callable
{
  final ai a;
  final ak b;
  final b c;
  final c d;

  bl(c paramc, ai paramai, ak paramak, b paramb)
  {
  }

  public bo a()
  {
    c localc = this.d;
    ai localai = this.a;
    ak localak = this.b;
    b localb = this.c;
    return localc.a(localai, localak, localb);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a.bl
 * JD-Core Version:    0.5.4
 */