package com.a;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

public class at
{
  private static Handler a;
  private static final String b;

  static
  {
    char[] arrayOfChar1 = "G纮`7k[纮F7eZ\017u".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 4; ; k = 95)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        localObject1 = Looper.getMainLooper();
        if (localObject1 == null)
        {
          String str = b;
          HandlerThread localHandlerThread = new HandlerThread(str, -1);
          localHandlerThread.start();
          Looper localLooper = localHandlerThread.getLooper();
          a = new Handler(localLooper);
        }
        while (true)
        {
          return;
          a = new Handler((Looper)localObject1);
        }
        k = 52;
        continue;
        k = 107;
        continue;
        k = 25;
      }
  }

  public static Looper a()
  {
    return a.getLooper();
  }

  public static Future a(Callable paramCallable)
  {
    r localr = new r(paramCallable);
    int i;
    if (!a.post(localr))
      i = 0;
    return i;
  }

  public static boolean a(Runnable paramRunnable, long paramLong)
  {
    return a.postDelayed(paramRunnable, paramLong);
  }

  static boolean b()
  {
    return c();
  }

  private static boolean c()
  {
    long l1 = Thread.currentThread().getId();
    long l2 = a().getThread().getId();
    Object localObject2;
    Object localObject3;
    long l3;
    localObject2 <= localObject3;
    int i;
    if (l1 == 0)
      i = 1;
    while (true)
    {
      return i;
      Object localObject1 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.at
 * JD-Core Version:    0.5.4
 */