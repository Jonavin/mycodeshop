package com.a;

public class by
  implements af, f, Comparable
{
  private static final String g;
  private final bv b;
  private final int c;
  private final long d;
  private final h e;

  static
  {
    int i = 95;
    char[] arrayOfChar1 = "28\002".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int j;
    Object localObject3;
    char[] arrayOfChar4;
    int k;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      j = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      k = localObject3[arrayOfChar1];
      l = j % 5;
      switch (l)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int l = 67; ; l = 59)
      while (true)
      {
        int i1 = (char)(k ^ l);
        localObject3[arrayOfChar1] = k;
        char[] arrayOfChar2 = j + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          j = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        g = new String(localObject1).intern();
        return;
        l = i;
        continue;
        l = 75;
        continue;
        l = i;
      }
  }

  public by(bv parambv, int paramInt, long paramLong, h paramh)
  {
    this.b = parambv;
    this.c = paramInt;
    this.d = paramLong;
    this.e = ???;
  }

  public int a(by paramby)
  {
    int i;
    if (paramby == null)
      i = 1;
    while (true)
    {
      return i;
      Object localObject = this.b;
      bv localbv = paramby.b;
      localObject = ((bv)localObject).a(localbv);
      if (localObject != 0)
        continue;
      localObject = this.e;
      h localh = paramby.e;
      localObject = ((h)localObject).c(localh);
      if (localObject != 0)
        continue;
      int j = this.c;
      int k = paramby.c;
      j -= k;
    }
  }

  public bv a()
  {
    return this.b;
  }

  public int b()
  {
    return this.c;
  }

  public long c()
  {
    return this.d;
  }

  public h e()
  {
    return this.e;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    try
    {
      by localby = (by)paramObject;
      int i = a(paramObject);
      if (i == 0)
      {
        int j = 1;
        return j;
      }
      Object localObject2 = localObject1;
    }
    catch (ClassCastException localObject3)
    {
      Object localObject3 = localObject1;
    }
  }

  public int hashCode()
  {
    int i = i.c;
    int j = 17 * 37;
    j = (this.b.hashCode() + 629) * 37;
    long l1 = this.d;
    long l2 = this.d >>> 32;
    int k = (int)(l1 ^ l2);
    j = (j + k) * 37;
    int l = this.c;
    j += l;
    if (bf.d != 0)
      i.c = ++i;
    return j;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("[");
    bv localbv = this.b;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localbv).append(" ");
    int i = this.c;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(i).append(" ");
    long l = this.d;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l);
    String str = g;
    return str;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.by
 * JD-Core Version:    0.5.4
 */