package com.a;

import java.util.Comparator;

public abstract interface f
{
  public static final Comparator a = new b();

  public abstract bv a();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.f
 * JD-Core Version:    0.5.4
 */