package com.a;

public abstract interface cb
{
  public abstract void a(int paramInt1, int paramInt2);

  public abstract void b(int paramInt1, int paramInt2);

  public abstract void c(int paramInt1, int paramInt2);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.cb
 * JD-Core Version:    0.5.4
 */