package com.a;

import java.io.OutputStream;

final class am extends OutputStream
{
  final ba a;
  final StringBuilder b;
  final ag c;

  public am(ag paramag, ba paramba)
  {
    this.a = paramba;
    StringBuilder localStringBuilder = new StringBuilder();
    this.b = localStringBuilder;
  }

  public void close()
  {
    if (this.b.length() <= 0)
      return;
    ag localag = this.c;
    ba localba = this.a;
    String str = this.b.toString();
    localag.a(localba, str, null);
  }

  public void write(int paramInt)
  {
    this.b.appendCodePoint(paramInt);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.am
 * JD-Core Version:    0.5.4
 */