package com.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class ai extends BroadcastReceiver
{
  private static final String[] b;
  final p a;

  static
  {
    Object localObject1 = 119;
    Object localObject2 = 114;
    Object localObject3 = 3;
    int i = 1;
    Object localObject4 = 0;
    String[] arrayOfString = new String[localObject3];
    char[] arrayOfChar1 = "s\024\002\032\025f\034".toCharArray();
    Object localObject9 = arrayOfChar1.length;
    Object localObject19;
    Object localObject21;
    Object localObject10;
    Object localObject16;
    int k;
    int l;
    label115: Object localObject6;
    if (localObject9 <= i)
    {
      Object localObject15 = localObject4;
      localObject19 = localObject9;
      localObject21 = localObject15;
      localObject10 = arrayOfChar1;
      char[] arrayOfChar2 = localObject15;
      localObject16 = arrayOfChar1;
      Object localObject5;
      for (arrayOfChar1 = arrayOfChar2; ; localObject5 = localObject19)
      {
        k = localObject10[arrayOfChar1];
        l = localObject21 % 5;
        switch (l)
        {
        default:
          l = localObject2;
          k = (char)(k ^ l);
          localObject10[arrayOfChar1] = k;
          localObject5 = localObject21 + 1;
          if (localObject19 != 0)
            break;
          localObject10 = localObject16;
          localObject21 = localObject5;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject10 = localObject19;
      Object localObject22 = localObject16;
      localObject16 = localObject5;
      localObject6 = localObject22;
    }
    while (true)
    {
      if (localObject10 <= localObject16);
      localObject6 = new String(localObject6).intern();
      arrayOfString[localObject4] = localObject6;
      localObject6 = "s\027纮\030纮#\013\030\b纮`\035W\024\001#\026".toCharArray();
      Object localObject11 = localObject6.length;
      Object localObject12;
      label295: Object localObject8;
      if (localObject11 <= i)
      {
        localObject16 = localObject4;
        localObject19 = localObject11;
        localObject21 = localObject16;
        localObject12 = localObject6;
        Object localObject23 = localObject16;
        localObject16 = localObject6;
        Object localObject7;
        for (localObject6 = localObject23; ; localObject7 = localObject19)
        {
          k = localObject12[localObject6];
          l = localObject21 % 5;
          switch (l)
          {
          default:
            l = localObject2;
            k = (char)(k ^ l);
            localObject12[localObject6] = k;
            localObject7 = localObject21 + 1;
            if (localObject19 != 0)
              break;
            localObject12 = localObject16;
            localObject21 = localObject7;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject12 = localObject19;
        Object localObject24 = localObject16;
        localObject16 = localObject7;
        localObject8 = localObject24;
      }
      while (true)
      {
        if (localObject12 <= localObject16);
        localObject8 = new String(localObject8).intern();
        arrayOfString[i] = localObject8;
        int j = 2;
        localObject12 = "f纮\024\030\002w\021\030\023Rj\026W\022\034Q\035\024\030\033u\035_".toCharArray();
        Object localObject17 = localObject12.length;
        Object localObject20;
        label475: Object localObject14;
        if (localObject17 <= i)
        {
          localObject19 = localObject4;
          localObject21 = localObject17;
          k = localObject19;
          localObject18 = localObject12;
          Object localObject25 = localObject19;
          localObject20 = localObject12;
          Object localObject13;
          for (localObject12 = localObject25; ; localObject13 = localObject21)
          {
            l = localObject18[localObject12];
            localObject4 = k % 5;
            switch (localObject4)
            {
            default:
              localObject4 = localObject2;
              int i1 = (char)(l ^ localObject4);
              localObject18[localObject12] = l;
              localObject13 = k + 1;
              if (localObject21 != 0)
                break;
              localObject18 = localObject20;
              k = localObject13;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject18 = localObject21;
          Object localObject26 = localObject20;
          localObject20 = localObject13;
          localObject14 = localObject26;
        }
        while (true)
        {
          if (localObject18 <= localObject20);
          String str = new String(localObject14).intern();
          arrayOfString[j] = localObject14;
          b = arrayOfString;
          return;
          l = localObject3;
          break label115:
          l = 120;
          break label115:
          l = localObject1;
          break label115:
          l = 125;
          break label115:
          l = localObject3;
          break label295:
          l = 120;
          break label295:
          l = localObject1;
          break label295:
          l = 125;
          break label295:
          localObject4 = localObject3;
          break label475:
          localObject4 = 120;
          break label475:
          localObject4 = localObject1;
          break label475:
          localObject4 = 125;
          break label475:
          localObject20 = localObject4;
        }
        localObject18 = localObject4;
      }
      Object localObject18 = localObject4;
    }
  }

  ai(p paramp)
  {
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i = 1;
    Object localObject1 = null;
    int j;
    s.a = j;
    try
    {
      Object localObject2 = b[null];
      localObject2 = paramIntent.getIntExtra((String)localObject2, -1);
      p localp = this.a;
      monitorenter;
      switch (localObject2)
      {
      default:
      case 1:
      case 2:
      case 0:
      }
      label289: 
      while (true)
        try
        {
          localObject2 = this.a;
          az localaz1 = az.c;
          p.a((p)localObject2, localaz1);
          do
          {
            localObject2 = p.a(this.a).a();
            if (localObject2 != 0)
            {
              localObject2 = p.a(this.a);
              StringBuilder localStringBuilder1 = new StringBuilder();
              String str1 = b[1];
              StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
              String str2 = p.b(this.a).name();
              String str3 = str2;
              ((ag)localObject2).b(str3);
            }
            localObject2 = this.a;
            p.c((p)localObject2);
            monitorexit;
            if (bf.d != 0)
            {
              label179: if (j == 0)
                break label289;
              Object localObject4 = localObject1;
            }
            boolean bool;
            return;
            localObject2 = this.a;
            az localaz2 = az.a;
            p.a((p)localObject2, localaz2);
          }
          while (j == 0);
          localObject2 = this.a;
          az localaz3 = az.b;
          p.a((p)localObject2, localaz3);
        }
        finally
        {
          monitorexit;
        }
    }
    catch (Throwable localThrowable)
    {
      ag localag = p.a(this.a);
      String str4 = b[2];
      localag.a(str4, localThrowable);
      break label179:
      int k = i;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ai
 * JD-Core Version:    0.5.4
 */