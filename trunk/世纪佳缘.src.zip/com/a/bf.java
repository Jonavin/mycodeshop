package com.a;

public abstract class bf
  implements ao
{
  public static int d;
  private ac a;

  /** @deprecated */
  protected void a()
  {
    monitorenter;
    try
    {
      if (this.a != null)
        this.a.a(this);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  /** @deprecated */
  public void a(ac paramac)
  {
    monitorenter;
    try
    {
      this.a = paramac;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bf
 * JD-Core Version:    0.5.4
 */