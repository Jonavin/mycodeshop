package com.a;

public enum ay
{
  private static final ay[] e;
  private static final String[] f;

  static
  {
    int i = 7;
    int j = 3;
    int k = 2;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[4];
    char[] arrayOfChar1 = "\\~K\f".toCharArray();
    Object localObject10 = arrayOfChar1.length;
    Object localObject19;
    int i1;
    Object localObject11;
    Object localObject18;
    int i2;
    int i3;
    label112: Object localObject3;
    if (localObject10 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject19 = localObject10;
      i1 = arrayOfChar2;
      localObject11 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject18 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject19)
      {
        i2 = localObject11[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = l;
          i2 = (char)(i2 ^ i3);
          localObject11[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject19 != 0)
            break;
          localObject11 = localObject18;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject11 = localObject19;
      Object localObject20 = localObject18;
      localObject18 = localObject2;
      localObject3 = localObject20;
    }
    while (true)
    {
      if (localObject11 <= localObject18);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "IcC\006TN".toCharArray();
      Object localObject12 = localObject3.length;
      Object localObject13;
      label292: Object localObject5;
      if (localObject12 <= l)
      {
        localObject18 = localObject1;
        localObject19 = localObject12;
        i1 = localObject18;
        localObject13 = localObject3;
        Object localObject21 = localObject18;
        localObject18 = localObject3;
        Object localObject4;
        for (localObject3 = localObject21; ; localObject4 = localObject19)
        {
          i2 = localObject13[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = l;
            i2 = (char)(i2 ^ i3);
            localObject13[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject19 != 0)
              break;
            localObject13 = localObject18;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject13 = localObject19;
        Object localObject22 = localObject18;
        localObject18 = localObject4;
        localObject5 = localObject22;
      }
      while (true)
      {
        if (localObject13 <= localObject18);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        localObject5 = "XbN\005UE~I".toCharArray();
        Object localObject14 = localObject5.length;
        Object localObject15;
        label472: Object localObject7;
        if (localObject14 <= l)
        {
          localObject18 = localObject1;
          localObject19 = localObject14;
          i1 = localObject18;
          localObject15 = localObject5;
          Object localObject23 = localObject18;
          localObject18 = localObject5;
          Object localObject6;
          for (localObject5 = localObject23; ; localObject6 = localObject19)
          {
            i2 = localObject15[localObject5];
            i3 = i1 % 5;
            switch (i3)
            {
            default:
              i3 = l;
              i2 = (char)(i2 ^ i3);
              localObject15[localObject5] = i2;
              localObject6 = i1 + 1;
              if (localObject19 != 0)
                break;
              localObject15 = localObject18;
              i1 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject15 = localObject19;
          Object localObject24 = localObject18;
          localObject18 = localObject6;
          localObject7 = localObject24;
        }
        while (true)
        {
          if (localObject15 <= localObject18);
          localObject7 = new String(localObject7).intern();
          arrayOfString[k] = localObject7;
          localObject7 = "TbK\005".toCharArray();
          Object localObject16 = localObject7.length;
          Object localObject17;
          label652: Object localObject9;
          if (localObject16 <= l)
          {
            localObject18 = localObject1;
            localObject19 = localObject16;
            i1 = localObject18;
            localObject17 = localObject7;
            Object localObject25 = localObject18;
            localObject18 = localObject7;
            Object localObject8;
            for (localObject7 = localObject25; ; localObject8 = localObject19)
            {
              i2 = localObject17[localObject7];
              i3 = i1 % 5;
              switch (i3)
              {
              default:
                i3 = l;
                int i4 = (char)(i2 ^ i3);
                localObject17[localObject7] = i2;
                localObject8 = i1 + 1;
                if (localObject19 != 0)
                  break;
                localObject17 = localObject18;
                i1 = localObject8;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject17 = localObject19;
            Object localObject26 = localObject18;
            localObject18 = localObject8;
            localObject9 = localObject26;
          }
          while (true)
          {
            if (localObject17 <= localObject18);
            String str1 = new String(localObject9).intern();
            arrayOfString[j] = localObject9;
            f = arrayOfString;
            String str2 = f[l];
            a = new ay(localObject9, localObject1);
            String str3 = f[localObject1];
            b = new ay(localObject9, l);
            String str4 = f[k];
            c = new ay(localObject9, k);
            String str5 = f[j];
            d = new ay(localObject9, j);
            ay[] arrayOfay = new ay[4];
            ay localay1 = a;
            arrayOfString[localObject1] = localObject9;
            ay localay2 = b;
            arrayOfString[l] = localObject9;
            ay localay3 = c;
            arrayOfString[k] = localObject9;
            ay localay4 = d;
            arrayOfString[j] = localObject9;
            e = arrayOfString;
            return;
            i3 = 26;
            break label112:
            i3 = 55;
            break label112:
            i3 = i;
            break label112:
            i3 = 73;
            break label112:
            i3 = 26;
            break label292:
            i3 = 55;
            break label292:
            i3 = i;
            break label292:
            i3 = 73;
            break label292:
            i3 = 26;
            break label472:
            i3 = 55;
            break label472:
            i3 = i;
            break label472:
            i3 = 73;
            break label472:
            i3 = 26;
            break label652:
            i3 = 55;
            break label652:
            i3 = i;
            break label652:
            i3 = 73;
            break label652:
            localObject18 = localObject1;
          }
          localObject18 = localObject1;
        }
        localObject18 = localObject1;
      }
      localObject18 = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ay
 * JD-Core Version:    0.5.4
 */