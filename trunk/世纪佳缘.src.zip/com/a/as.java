package com.a;

import android.content.Context;
import android.telephony.TelephonyManager;
import java.util.concurrent.Callable;

class as
  implements Callable
{
  private static final String b;
  final z a;

  static
  {
    char[] arrayOfChar1 = "5\004\031y@".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 37; ; k = 23)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        return;
        k = 69;
        continue;
        k = 108;
        continue;
        k = 118;
      }
  }

  as(z paramz)
  {
  }

  public TelephonyManager a()
  {
    Context localContext = z.a(this.a);
    String str = b;
    return (TelephonyManager)localContext.getSystemService(str);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.as
 * JD-Core Version:    0.5.4
 */