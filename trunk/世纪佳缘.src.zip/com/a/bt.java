package com.a;

import com.a.a.be;

public abstract class bt extends bf
{
  private static bt a;
  public static final String b;
  public static final String c;
  public static final String e;
  public static final bt f;
  public static int g;
  private static final String h;

  static
  {
    int i = 54;
    int j = 53;
    int k = 35;
    int l = 1;
    Object localObject1 = 0;
    char[] arrayOfChar1 = "UZ[\004,\026HPWxFIZW7BBEF+".toCharArray();
    Object localObject10 = arrayOfChar1.length;
    Object localObject19;
    int i1;
    Object localObject11;
    Object localObject18;
    int i2;
    int i3;
    label108: Object localObject3;
    if (localObject10 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject19 = localObject10;
      i1 = arrayOfChar2;
      localObject11 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject18 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject19)
      {
        i2 = localObject11[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 88;
          i2 = (char)(i2 ^ i3);
          localObject11[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject19 != 0)
            break;
          localObject11 = localObject18;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject11 = localObject19;
      Object localObject20 = localObject18;
      localObject18 = localObject2;
      localObject3 = localObject20;
    }
    while (true)
    {
      if (localObject11 <= localObject18);
      h = new String(localObject3).intern();
      localObject3 = "qkf".toCharArray();
      Object localObject12 = localObject3.length;
      Object localObject13;
      label284: Object localObject5;
      if (localObject12 <= l)
      {
        localObject18 = localObject1;
        localObject19 = localObject12;
        i1 = localObject18;
        localObject13 = localObject3;
        Object localObject21 = localObject18;
        localObject18 = localObject3;
        Object localObject4;
        for (localObject3 = localObject21; ; localObject4 = localObject19)
        {
          i2 = localObject13[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 88;
            i2 = (char)(i2 ^ i3);
            localObject13[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject19 != 0)
              break;
            localObject13 = localObject18;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject13 = localObject19;
        Object localObject22 = localObject18;
        localObject18 = localObject4;
        localObject5 = localObject22;
      }
      while (true)
      {
        if (localObject13 <= localObject18);
        b = new String(localObject5).intern();
        localObject5 = "uxb".toCharArray();
        Object localObject14 = localObject5.length;
        Object localObject15;
        label460: Object localObject7;
        if (localObject14 <= l)
        {
          localObject18 = localObject1;
          localObject19 = localObject14;
          i1 = localObject18;
          localObject15 = localObject5;
          Object localObject23 = localObject18;
          localObject18 = localObject5;
          Object localObject6;
          for (localObject5 = localObject23; ; localObject6 = localObject19)
          {
            i2 = localObject15[localObject5];
            i3 = i1 % 5;
            switch (i3)
            {
            default:
              i3 = 88;
              i2 = (char)(i2 ^ i3);
              localObject15[localObject5] = i2;
              localObject6 = i1 + 1;
              if (localObject19 != 0)
                break;
              localObject15 = localObject18;
              i1 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject15 = localObject19;
          Object localObject24 = localObject18;
          localObject18 = localObject6;
          localObject7 = localObject24;
        }
        while (true)
        {
          if (localObject15 <= localObject18);
          e = new String(localObject7).intern();
          localObject7 = "x~at\027dp".toCharArray();
          Object localObject16 = localObject7.length;
          Object localObject17;
          label636: Object localObject9;
          if (localObject16 <= l)
          {
            localObject18 = localObject1;
            localObject19 = localObject16;
            i1 = localObject18;
            localObject17 = localObject7;
            Object localObject25 = localObject18;
            localObject18 = localObject7;
            Object localObject8;
            for (localObject7 = localObject25; ; localObject8 = localObject19)
            {
              i2 = localObject17[localObject7];
              i3 = i1 % 5;
              switch (i3)
              {
              default:
                i3 = 88;
                int i4 = (char)(i2 ^ i3);
                localObject17[localObject7] = i2;
                localObject8 = i1 + 1;
                if (localObject19 != 0)
                  break;
                localObject17 = localObject18;
                i1 = localObject8;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject17 = localObject19;
            Object localObject26 = localObject18;
            localObject18 = localObject8;
            localObject9 = localObject26;
          }
          while (true)
          {
            if (localObject17 <= localObject18);
            c = new String(localObject9).intern();
            f = new y();
            a = null;
            return;
            i3 = i;
            break label108:
            i3 = 59;
            break label108:
            i3 = j;
            break label108:
            i3 = k;
            break label108:
            i3 = i;
            break label284:
            i3 = 59;
            break label284:
            i3 = j;
            break label284:
            i3 = k;
            break label284:
            i3 = i;
            break label460:
            i3 = 59;
            break label460:
            i3 = j;
            break label460:
            i3 = k;
            break label460:
            i3 = i;
            break label636:
            i3 = 59;
            break label636:
            i3 = j;
            break label636:
            i3 = k;
            break label636:
            localObject18 = localObject1;
          }
          localObject18 = localObject1;
        }
        localObject18 = localObject1;
      }
      localObject18 = localObject1;
    }
  }

  public static bt b(av paramav, String paramString)
  {
    boolean bool = e.equals(paramString);
    if (bool);
    for (Object localObject = new z(paramav); ; localObject = a.a(paramav, paramString))
      while (true)
      {
        return localObject;
        localObject = a;
        if (localObject != null)
          break;
        localObject = new u(paramav, paramString);
      }
  }

  protected abstract bt a(av paramav, String paramString);

  public abstract void a(long paramLong);

  public abstract be b();

  public abstract boolean c();

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bt
 * JD-Core Version:    0.5.4
 */