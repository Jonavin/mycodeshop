package com.a;

import com.a.a.be;

final class y extends bt
{
  public bt a(av paramav, String paramString)
  {
    return this;
  }

  public void a(long paramLong)
  {
  }

  public be b()
  {
    return null;
  }

  public boolean c()
  {
    return null;
  }

  public void d()
  {
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.y
 * JD-Core Version:    0.5.4
 */