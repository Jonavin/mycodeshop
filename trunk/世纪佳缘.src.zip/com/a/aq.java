package com.a;

import android.content.Context;

public class aq
  implements av
{
  private static final String b;
  private final Context a;

  static
  {
    char[] arrayOfChar1 = "{tKr\006s0\035P\005t Xk\036:=N3\030%Hz\0300".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 106; ; k = 19)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        return;
        k = 26;
        continue;
        k = 84;
        continue;
        k = 61;
      }
  }

  public aq(Context paramContext)
  {
    if (paramContext == null)
    {
      String str = b;
      throw new NullPointerException(str);
    }
    if (paramContext.getApplicationContext() != null)
    {
      Context localContext = paramContext.getApplicationContext();
      this.a = localContext;
      if (i == 0)
        break label53;
    }
    this.a = paramContext;
    if (bf.d == 0)
      label53: return;
    h.a = ++i;
  }

  public Context a()
  {
    return this.a;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.aq
 * JD-Core Version:    0.5.4
 */