package com.a;

import android.os.SystemClock;

public final class e extends h
{
  public long a()
  {
    return SystemClock.elapsedRealtime();
  }

  protected h b()
  {
    return new e();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.e
 * JD-Core Version:    0.5.4
 */