package com.a;

import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ab
{
  private DocumentBuilder a;

  public ab()
  {
    try
    {
      DocumentBuilder localDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
      this.a = localDocumentBuilder;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }

  public static String a(Document paramDocument, String paramString1, String paramString2)
  {
    int i = 0;
    Object localObject = a(paramDocument, paramString1);
    if (localObject == null);
    for (localObject = i; ; localObject = ((Node)localObject).getNodeValue())
      while (true)
      {
        return localObject;
        localObject = ((Node)localObject).getAttributes();
        if (localObject == null)
          localObject = i;
        localObject = ((NamedNodeMap)localObject).getNamedItem(paramString2);
        if (localObject != null)
          break;
        localObject = i;
      }
  }

  public static Node a(Document paramDocument, String paramString)
  {
    NodeList localNodeList = paramDocument.getElementsByTagName(paramString);
    int i;
    if ((localNodeList == null) || (localNodeList.getLength() != 1))
      i = 0;
    while (true)
    {
      return i;
      Node localNode = i.item(0);
    }
  }

  public static Integer b(Document paramDocument, String paramString1, String paramString2)
  {
    String str = a(paramDocument, paramString1, paramString2);
    int i;
    if (str == null)
      i = 0;
    while (true)
    {
      return i;
      Integer localInteger = Integer.valueOf(i);
    }
  }

  public static String b(Document paramDocument, String paramString)
  {
    int i = 0;
    Object localObject = a(paramDocument, paramString);
    if (localObject == null);
    for (localObject = i; ; localObject = ((NodeList)localObject).item(0).getNodeValue())
      while (true)
      {
        return localObject;
        localObject = ((Node)localObject).getChildNodes();
        if ((localObject != null) && (((NodeList)localObject).getLength() == 1))
          break;
        localObject = i;
      }
  }

  public static String[] c(Document paramDocument, String paramString)
  {
    int i = 0;
    int j = 0;
    int k = c.b;
    NodeList localNodeList = paramDocument.getElementsByTagName(paramString);
    if (localNodeList == null);
    String[] arrayOfString;
    label117: for (Object localObject = i; ; localObject = arrayOfString)
      while (true)
      {
        return localObject;
        int l = localNodeList.getLength();
        if (l == 0)
          localObject = i;
        arrayOfString = new String[l];
        int i1 = j;
        do
        {
          if (i1 >= l)
            break;
          if (localObject != 0)
            break label117;
          String str = localNodeList.item(i1).getChildNodes().item(j).getNodeValue();
          arrayOfString[i1] = str;
          ++i1;
        }
        while (localObject == 0);
        localObject = arrayOfString;
      }
  }

  public static Integer d(Document paramDocument, String paramString)
  {
    String str = b(paramDocument, paramString);
    int i;
    if (str == null)
      i = 0;
    while (true)
    {
      return i;
      Integer localInteger = Integer.valueOf(i);
    }
  }

  public static Double e(Document paramDocument, String paramString)
  {
    String str = b(paramDocument, paramString);
    int i;
    if (str == null)
      i = 0;
    while (true)
    {
      return i;
      Double localDouble = Double.valueOf(i);
    }
  }

  /** @deprecated */
  public Document a(InputStream paramInputStream)
  {
    monitorenter;
    try
    {
      Document localDocument = this.a.parse(paramInputStream);
      monitorexit;
      return localDocument;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ab
 * JD-Core Version:    0.5.4
 */