package com.a;

import java.util.Comparator;

public abstract interface aw
{
  public static final Comparator c = new ae();

  public abstract ax a();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.aw
 * JD-Core Version:    0.5.4
 */