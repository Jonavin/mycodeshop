package com.a;

import java.io.OutputStream;
import java.io.PrintStream;

public abstract class ag
{
  public static boolean b;
  private static ba c;
  private static ag d;
  private static final String[] e;
  protected final String a;

  static
  {
    String str1 = 0;
    Object localObject2 = new String[4];
    String str2 = a(f("A,RWj\002>Y\004>R?S\004qV4L\025m"));
    localObject2[str1] = str2;
    String str4 = a(f("m"));
    localObject2[1] = str4;
    str4 = a(f("\002\026"));
    localObject2[2] = str4;
    str4 = a(f("\0029T\002z\037"));
    localObject2[3] = str4;
    e = (String)localObject2;
    c = ba.f;
    d = null;
    localObject2 = ba.values();
    String str3 = localObject2.length;
    str4 = str1;
    if (str4 < str3)
    {
      label82: Object localObject1 = localObject2[str4];
      String str5 = localObject1.name();
      String str6 = a(f("f\b~%Y"));
      if (!str5.equals(str6))
        break label175;
      c = localObject1;
    }
    int[] arrayOfInt = bp.a;
    int i = ar.b.ordinal();
    switch (arrayOfInt[i])
    {
    default:
      d = new be();
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      label175: ++str4;
      break label82:
      d = new bj(ag.class);
      continue;
      d = new ap(ag.class);
      continue;
      d = new bl(ag.class);
    }
  }

  private ag()
  {
    this.a = null;
  }

  ag(be parambe)
  {
  }

  protected ag(Class paramClass)
  {
    String str = paramClass.getName();
    this.a = str;
  }

  private static String a(char[] paramArrayOfChar)
  {
    Object localObject1 = paramArrayOfChar.length;
    Object localObject3 = 0;
    char[] arrayOfChar3 = 1;
    Object localObject4;
    char[] arrayOfChar4;
    label34: char[] arrayOfChar6;
    if (localObject1 <= arrayOfChar3)
    {
      arrayOfChar3 = localObject3;
      localObject3 = localObject1;
      char[] arrayOfChar1 = paramArrayOfChar;
      Object localObject5 = localObject3;
      int i = arrayOfChar3;
      localObject4 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      int j = localObject4[arrayOfChar1];
      int k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
      char[] arrayOfChar2;
      for (k = 30; ; k = 112)
        while (true)
        {
          int l = (char)(j ^ k);
          localObject4[arrayOfChar1] = j;
          arrayOfChar2 = i + 1;
          if (localObject5 != 0)
            break label142;
          localObject4 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject5;
          break label34:
          k = 34;
          continue;
          k = 77;
          continue;
          k = 60;
        }
      label142: localObject4 = localObject5;
      arrayOfChar6 = arrayOfChar4;
      arrayOfChar4 = arrayOfChar2;
    }
    for (Object localObject2 = arrayOfChar6; ; localObject2 = paramArrayOfChar)
    {
      if (localObject4 <= arrayOfChar4);
      return new String(localObject2).intern();
      arrayOfChar4 = localObject4;
      localObject4 = localObject2;
    }
  }

  /** @deprecated */
  public static ag b(Class paramClass)
  {
    synchronized (ag.class)
    {
      ag localag2 = d.a(paramClass);
      return localag2;
    }
  }

  private final String b(ba paramba, String paramString)
  {
    int i = paramString.length() + 256;
    StringBuilder localStringBuilder1 = new StringBuilder(i);
    String str1 = e[3];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    long l = Thread.currentThread().getId();
    Object localObject;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(localObject).append(" ");
    String str2 = this.a;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str2);
    String str3 = e[2];
    StringBuilder localStringBuilder5 = localStringBuilder4.append(str3);
    String str4 = paramba.toString();
    StringBuilder localStringBuilder6 = localStringBuilder5.append(str4);
    String str5 = e[1];
    return str5 + paramString;
  }

  private static char[] f(String paramString)
  {
    char[] arrayOfChar1 = paramString.toCharArray();
    char[] arrayOfChar2 = arrayOfChar1;
    while (true)
    {
      int i = arrayOfChar1.length;
      if (i < 2)
      {
        if (i == 0)
          break label33;
        int j = (char)(arrayOfChar2[null] ^ 0x1E);
        arrayOfChar2[0] = j;
      }
      return arrayOfChar2;
      label33: Object localObject = arrayOfChar2;
    }
  }

  protected abstract ag a(Class paramClass);

  protected abstract void a(ba paramba, String paramString);

  public void a(ba paramba, String paramString, Throwable paramThrowable)
  {
    boolean bool = a(paramba);
    if (bool)
    {
      if (paramThrowable != null)
        break label32;
      String str = b(paramba, paramString);
      a(paramba, str);
    }
    while (true)
    {
      return;
      label32: OutputStream localOutputStream = b(paramba);
      PrintStream localPrintStream = new PrintStream(localOutputStream);
      try
      {
        localPrintStream.println(paramString);
        paramThrowable.printStackTrace(localPrintStream);
        localPrintStream.close();
      }
      finally
      {
        localPrintStream.close();
      }
    }
  }

  public final void a(String paramString)
  {
    ba localba = ba.a;
    a(localba, paramString, null);
  }

  public final void a(String paramString, Throwable paramThrowable)
  {
    ba localba = ba.b;
    a(localba, paramString, paramThrowable);
  }

  public boolean a()
  {
    ba localba = ba.b;
    return a(localba);
  }

  public boolean a(ba paramba)
  {
    int i = c.compareTo(paramba);
    int j;
    if (i <= 0)
    {
      boolean bool = bq.a(paramba);
      if (bool)
        j = 1;
    }
    while (true)
    {
      return j;
      Object localObject = null;
    }
  }

  public final OutputStream b(ba paramba)
  {
    return new am(this, paramba);
  }

  public final void b(String paramString)
  {
    ba localba = ba.b;
    a(localba, paramString, null);
  }

  public final void b(String paramString, Throwable paramThrowable)
  {
    ba localba = ba.c;
    a(localba, paramString, paramThrowable);
  }

  public boolean b()
  {
    ba localba = ba.c;
    return a(localba);
  }

  public final void c(String paramString)
  {
    ba localba = ba.c;
    a(localba, paramString, null);
  }

  public final void c(String paramString, Throwable paramThrowable)
  {
    ba localba = ba.d;
    a(localba, paramString, paramThrowable);
  }

  public final void d(String paramString)
  {
    ba localba = ba.d;
    a(localba, paramString, null);
  }

  public final void d(String paramString, Throwable paramThrowable)
  {
    ba localba = ba.e;
    a(localba, paramString, paramThrowable);
  }

  public final void e(String paramString)
  {
    ba localba = ba.e;
    a(localba, paramString, null);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ag
 * JD-Core Version:    0.5.4
 */