package com.a;

import java.util.Comparator;

final class bx
  implements Comparator
{
  public int a(af paramaf1, af paramaf2)
  {
    h localh1 = paramaf1.e();
    h localh2 = paramaf2.e();
    return localh1.c(localh2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bx
 * JD-Core Version:    0.5.4
 */