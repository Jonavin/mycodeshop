package com.a;

public abstract interface ac
{
  public abstract void a(ao paramao);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ac
 * JD-Core Version:    0.5.4
 */