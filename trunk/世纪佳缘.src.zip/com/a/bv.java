package com.a;

public final class bv
  implements Comparable
{
  private static final char[] a;
  private static final String[] c;
  private long b;

  static
  {
    int i = 92;
    int j = 87;
    int k = 70;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "\0136\024r|%\0269o32W5d|(\0220`(/\0012".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = i;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "f\036$!5(\0016m5\"W;d2!\003?".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = i;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        c = arrayOfString;
        a = new char[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
        return;
        i3 = k;
        break label115:
        i3 = 119;
        break label115:
        i3 = j;
        break label115:
        i3 = l;
        break label115:
        i3 = k;
        break label295:
        i3 = 119;
        break label295:
        i3 = j;
        break label295:
        i3 = l;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  public bv(String paramString)
  {
    int l = paramString.length();
    StringBuilder localStringBuilder1;
    int i1;
    char c1;
    char c7;
    if (l != j)
    {
      localStringBuilder1 = new StringBuilder(j);
      i1 = i;
      do
      {
        int i2 = paramString.length();
        if (i1 >= i2)
          break;
        c1 = paramString.charAt(i1);
        char c2 = '0';
        if (k != 0)
          break label284;
        if (c1 >= c2)
        {
          char c3 = '9';
          if (c1 <= c3)
            break label131;
        }
        char c4 = 'a';
        if (c1 >= c4)
        {
          char c5 = 'f';
          if (c1 <= c5)
            break label131;
        }
        char c6 = 'A';
        if (c1 >= c6)
        {
          c7 = 'F';
          if (c1 <= c7)
            label131: localStringBuilder1.append(c1);
        }
        ++i1;
      }
      while (k == 0);
      i1 = localStringBuilder1.length();
      k = j;
    }
    while (true)
    {
      if (i1 == k);
      for (String str1 = localStringBuilder1.toString(); ; str1 = paramString)
      {
        if (str1.length() != j)
        {
          StringBuilder localStringBuilder2 = new StringBuilder();
          int i3 = str1.length();
          StringBuilder localStringBuilder3 = localStringBuilder2.append(str1);
          String str2 = c[1];
          String str3 = str2;
          throw new IllegalArgumentException(str1);
        }
        long l1 = Long.parseLong(str1, 16);
        this.b = str1;
        if (this.b < 0L)
        {
          String str4 = c[i];
          throw new IllegalArgumentException(str4);
        }
        return;
      }
      label284: str1 = c7;
      i1 = c1;
    }
  }

  public int a(bv parambv)
  {
    long l1 = this.b;
    long l2 = parambv.b;
    l1 <= l2;
    int i;
    if (i < 0)
      i = -1;
    while (true)
    {
      return i;
      l1 = parambv.b;
      long l3 = this.b;
      l1 <= l3;
      if (i < 0)
        i = 1;
      Object localObject = null;
    }
  }

  public long a()
  {
    return this.b;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      try
      {
        long l1 = this.b;
        long l2 = ((bv)paramObject).b;
        l1 <= l2;
        if (localObject2 == 0)
          int i = 1;
        Object localObject3 = localObject1;
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    return (int)this.b;
  }

  public String toString()
  {
    int i = i.c;
    StringBuilder localStringBuilder1 = new StringBuilder(12);
    int j = 11;
    StringBuilder localStringBuilder2;
    do
    {
      if (j < 0)
        break;
      char[] arrayOfChar = a;
      long l = this.b;
      int k = j * 4;
      Object localObject2;
      int i1 = (int)(l >> localObject2 & 0xF);
      char c1 = arrayOfChar[i1];
      localStringBuilder2 = localStringBuilder1.append(c1);
      if (i != 0)
        break;
      --j;
    }
    while (i == 0);
    for (Object localObject1 = localStringBuilder1; ; localObject1 = localStringBuilder2)
      return localObject1.toString();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bv
 * JD-Core Version:    0.5.4
 */