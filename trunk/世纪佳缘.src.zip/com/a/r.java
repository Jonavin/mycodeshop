package com.a;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

final class r extends FutureTask
{
  r(Callable paramCallable)
  {
    super(paramCallable);
  }

  public Object get()
  {
    if ((!isDone()) && (at.b()))
      run();
    return super.get();
  }

  public Object get(long paramLong, TimeUnit paramTimeUnit)
  {
    TimeUnit paramTimeUnit;
    if ((!isDone()) && (at.b()))
      run();
    return super.get(paramLong, ???);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.r
 * JD-Core Version:    0.5.4
 */