package com.a;

import com.a.a.be;
import java.util.WeakHashMap;

public class br extends bf
{
  private static final ag c;
  private static final WeakHashMap e;
  private static final bo f;
  private static be g;
  private static final String[] h;
  private boolean a;
  private be b;

  static
  {
    int i = 77;
    int j = 24;
    int k = 2;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[6];
    char[] arrayOfChar1 = "}5>\036rl$2\025\"q#+\024iq#:[rw!1\036p".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject28;
    Object localObject30;
    Object localObject9;
    Object localObject21;
    int i2;
    int i5;
    label115: Object localObject3;
    if (localObject8 <= l)
    {
      Object localObject20 = localObject1;
      localObject28 = localObject8;
      localObject30 = localObject20;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar2 = localObject20;
      localObject21 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject28)
      {
        i2 = localObject9[arrayOfChar1];
        i5 = localObject30 % 5;
        switch (i5)
        {
        default:
          i5 = k;
          i2 = (char)(i2 ^ i5);
          localObject9[arrayOfChar1] = i2;
          localObject2 = localObject30 + 1;
          if (localObject28 != 0)
            break;
          localObject9 = localObject21;
          localObject30 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject28;
      Object localObject31 = localObject21;
      localObject21 = localObject2;
      localObject3 = localObject31;
    }
    while (true)
    {
      if (localObject9 <= localObject21);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "}>)\022oy98\037\"t\">\032vq\"3[c(}\031ck(9[mvm-\tgn$2\016q8!2\030cl$2\02588".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label295: Object localObject5;
      if (localObject10 <= l)
      {
        localObject21 = localObject1;
        localObject28 = localObject10;
        localObject30 = localObject21;
        localObject11 = localObject3;
        Object localObject32 = localObject21;
        localObject21 = localObject3;
        Object localObject4;
        for (localObject3 = localObject32; ; localObject4 = localObject28)
        {
          i2 = localObject11[localObject3];
          i5 = localObject30 % 5;
          switch (i5)
          {
          default:
            i5 = k;
            i2 = (char)(i2 ^ i5);
            localObject11[localObject3] = i2;
            localObject4 = localObject30 + 1;
            if (localObject28 != 0)
              break;
            localObject11 = localObject21;
            localObject30 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject28;
        Object localObject33 = localObject21;
        localObject21 = localObject4;
        localObject5 = localObject33;
      }
      while (true)
      {
        if (localObject11 <= localObject21);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        localObject5 = "t\">\032vq\"3[jy>}\025m8,:\036.8$:\025mj$3\034".toCharArray();
        Object localObject12 = localObject5.length;
        Object localObject13;
        label475: Object localObject7;
        if (localObject12 <= l)
        {
          localObject21 = localObject1;
          localObject28 = localObject12;
          localObject30 = localObject21;
          localObject13 = localObject5;
          Object localObject34 = localObject21;
          localObject21 = localObject5;
          Object localObject6;
          for (localObject5 = localObject34; ; localObject6 = localObject28)
          {
            i2 = localObject13[localObject5];
            i5 = localObject30 % 5;
            switch (i5)
            {
            default:
              i5 = k;
              i2 = (char)(i2 ^ i5);
              localObject13[localObject5] = i2;
              localObject6 = localObject30 + 1;
              if (localObject28 != 0)
                break;
              localObject13 = localObject21;
              localObject30 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject13 = localObject28;
          Object localObject35 = localObject21;
          localObject21 = localObject6;
          localObject7 = localObject35;
        }
        while (true)
        {
          if (localObject13 <= localObject21);
          localObject7 = new String(localObject7).intern();
          arrayOfString[k] = localObject7;
          int i1 = 3;
          localObject13 = "t\">\032vq\"3[kkm3\024v8,}\035k`a}\022ev\"/\022l".toCharArray();
          Object localObject22 = localObject13.length;
          Object localObject23;
          Object localObject29;
          int i6;
          label655: Object localObject15;
          if (localObject22 <= l)
          {
            localObject28 = localObject1;
            localObject30 = localObject22;
            i2 = localObject28;
            localObject23 = localObject13;
            Object localObject36 = localObject28;
            localObject29 = localObject13;
            Object localObject14;
            for (localObject13 = localObject36; ; localObject14 = localObject30)
            {
              i5 = localObject23[localObject13];
              i6 = i2 % 5;
              switch (i6)
              {
              default:
                i6 = k;
                i5 = (char)(i5 ^ i6);
                localObject23[localObject13] = i5;
                localObject14 = i2 + 1;
                if (localObject30 != 0)
                  break;
                localObject23 = localObject29;
                i2 = localObject14;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject23 = localObject30;
            Object localObject37 = localObject29;
            localObject29 = localObject14;
            localObject15 = localObject37;
          }
          while (true)
          {
            if (localObject23 <= localObject29);
            localObject15 = new String(localObject15).intern();
            arrayOfString[i1] = localObject15;
            i1 = 4;
            localObject15 = "}>)\022oy98\037\"y*8[kkm-\tmz,?\027{892\024\"q#<\030am?<\017g4m4\034lw?4\025e8!2\030cl$2\025".toCharArray();
            Object localObject24 = localObject15.length;
            Object localObject25;
            label839: Object localObject17;
            if (localObject24 <= l)
            {
              localObject29 = localObject1;
              localObject30 = localObject24;
              int i3 = localObject29;
              localObject25 = localObject15;
              Object localObject38 = localObject29;
              localObject29 = localObject15;
              Object localObject16;
              for (localObject15 = localObject38; ; localObject16 = localObject30)
              {
                i5 = localObject25[localObject15];
                i6 = i3 % 5;
                switch (i6)
                {
                default:
                  i6 = k;
                  i5 = (char)(i5 ^ i6);
                  localObject25[localObject15] = i5;
                  localObject16 = i3 + 1;
                  if (localObject30 != 0)
                    break;
                  localObject25 = localObject29;
                  i3 = localObject16;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject25 = localObject30;
              Object localObject39 = localObject29;
              localObject29 = localObject16;
              localObject17 = localObject39;
            }
            while (true)
            {
              if (localObject25 <= localObject29);
              localObject17 = new String(localObject17).intern();
              arrayOfString[i1] = localObject17;
              i1 = 5;
              localObject17 = "y)97m{,)\022mve".toCharArray();
              Object localObject26 = localObject17.length;
              label1023: Object localObject19;
              if (localObject26 <= l)
              {
                localObject29 = localObject1;
                localObject30 = localObject26;
                int i4 = localObject29;
                localObject27 = localObject17;
                Object localObject40 = localObject29;
                localObject29 = localObject17;
                Object localObject18;
                for (localObject17 = localObject40; ; localObject18 = localObject30)
                {
                  i5 = localObject27[localObject17];
                  i6 = i4 % 5;
                  switch (i6)
                  {
                  default:
                    i6 = k;
                    int i7 = (char)(i5 ^ i6);
                    localObject27[localObject17] = i5;
                    localObject18 = i4 + 1;
                    if (localObject30 != 0)
                      break;
                    localObject27 = localObject29;
                    i4 = localObject18;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject27 = localObject30;
                Object localObject41 = localObject29;
                localObject29 = localObject18;
                localObject19 = localObject41;
              }
              while (true)
              {
                if (localObject27 <= localObject29);
                String str = new String(localObject19).intern();
                arrayOfString[i1] = localObject19;
                h = arrayOfString;
                c = ag.b(br.class);
                e = new WeakHashMap();
                f = null;
                return;
                i5 = j;
                break label115:
                i5 = i;
                break label115:
                i5 = 93;
                break label115:
                i5 = 123;
                break label115:
                i5 = j;
                break label295:
                i5 = i;
                break label295:
                i5 = 93;
                break label295:
                i5 = 123;
                break label295:
                i5 = j;
                break label475:
                i5 = i;
                break label475:
                i5 = 93;
                break label475:
                i5 = 123;
                break label475:
                i6 = j;
                break label655:
                i6 = i;
                break label655:
                i6 = 93;
                break label655:
                i6 = 123;
                break label655:
                i6 = j;
                break label839:
                i6 = i;
                break label839:
                i6 = 93;
                break label839:
                i6 = 123;
                break label839:
                i6 = j;
                break label1023:
                i6 = i;
                break label1023:
                i6 = 93;
                break label1023:
                i6 = 123;
                break label1023:
                localObject29 = localObject1;
              }
              localObject29 = localObject1;
            }
            localObject29 = localObject1;
          }
          localObject27 = localObject1;
        }
        localObject27 = localObject1;
      }
      Object localObject27 = localObject1;
    }
  }

  // ERROR //
  public static void a(be parambe)
  {
    // Byte code:
    //   0: ldc2_w 64
    //   3: lstore_1
    //   4: getstatic 70	com/a/bt:g	I
    //   7: istore_3
    //   8: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   11: invokevirtual 73	com/a/ag:a	()Z
    //   14: astore 4
    //   16: iload 4
    //   18: ifeq +60 -> 78
    //   21: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   24: astore 4
    //   26: new 75	java/lang/StringBuilder
    //   29: dup
    //   30: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   33: astore 5
    //   35: getstatic 47	com/a/br:h	[Ljava/lang/String;
    //   38: iconst_5
    //   39: aaload
    //   40: astore 6
    //   42: aload 5
    //   44: aload 6
    //   46: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: aload_0
    //   50: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   53: astore 5
    //   55: ldc 85
    //   57: astore 6
    //   59: aload 5
    //   61: aload 6
    //   63: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   69: astore 5
    //   71: aload 4
    //   73: aload 5
    //   75: invokevirtual 91	com/a/ag:b	(Ljava/lang/String;)V
    //   78: ldc 2
    //   80: astore 5
    //   82: aload 5
    //   84: monitorenter
    //   85: getstatic 93	com/a/br:g	Lcom/a/a/be;
    //   88: astore 4
    //   90: aload 4
    //   92: ifnull +187 -> 279
    //   95: aload_0
    //   96: invokevirtual 98	com/a/a/be:e	()Lcom/a/h;
    //   99: astore 4
    //   101: aload 4
    //   103: ifnonnull +254 -> 357
    //   106: getstatic 93	com/a/br:g	Lcom/a/a/be;
    //   109: invokevirtual 98	com/a/a/be:e	()Lcom/a/h;
    //   112: invokevirtual 103	com/a/h:c	()J
    //   115: astore 6
    //   117: aload_0
    //   118: invokevirtual 104	com/a/a/be:c	()J
    //   121: astore 7
    //   123: getstatic 93	com/a/br:g	Lcom/a/a/be;
    //   126: invokevirtual 104	com/a/a/be:c	()J
    //   129: astore 8
    //   131: lload 9
    //   133: lload 11
    //   135: lsub
    //   136: lstore 13
    //   138: lload 15
    //   140: lload 13
    //   142: lsub
    //   143: lstore 15
    //   145: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   148: invokevirtual 73	com/a/ag:a	()Z
    //   151: astore 4
    //   153: iload 4
    //   155: ifeq +48 -> 203
    //   158: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   161: astore 4
    //   163: new 75	java/lang/StringBuilder
    //   166: dup
    //   167: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   170: astore 17
    //   172: getstatic 47	com/a/br:h	[Ljava/lang/String;
    //   175: iconst_1
    //   176: aaload
    //   177: astore 18
    //   179: aload 17
    //   181: aload 18
    //   183: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: lload 15
    //   188: invokevirtual 107	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   191: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   194: astore 19
    //   196: aload 4
    //   198: aload 19
    //   200: invokevirtual 91	com/a/ag:b	(Ljava/lang/String;)V
    //   203: lload 15
    //   205: ldc2_w 108
    //   208: lcmp
    //   209: lstore 20
    //   211: iload 4
    //   213: iflt +16 -> 229
    //   216: lload 15
    //   218: ldc2_w 110
    //   221: lcmp
    //   222: lstore 20
    //   224: iload 4
    //   226: ifle +26 -> 252
    //   229: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   232: astore 4
    //   234: getstatic 47	com/a/br:h	[Ljava/lang/String;
    //   237: iconst_4
    //   238: aaload
    //   239: astore 22
    //   241: aload 4
    //   243: aload 22
    //   245: invokevirtual 91	com/a/ag:b	(Ljava/lang/String;)V
    //   248: aload 5
    //   250: monitorexit
    //   251: return
    //   252: ldc2_w 64
    //   255: lload 15
    //   257: invokestatic 117	java/lang/Math:max	(JJ)J
    //   260: astore 6
    //   262: lload 15
    //   264: invokestatic 120	com/a/h:a	(J)Lcom/a/h;
    //   267: astore 4
    //   269: aload_0
    //   270: aload 4
    //   272: invokevirtual 123	com/a/a/be:a	(Lcom/a/h;)V
    //   275: iload_3
    //   276: ifeq +81 -> 357
    //   279: aload_0
    //   280: invokevirtual 127	com/a/a/be:a_	()D
    //   283: astore 6
    //   285: dload 15
    //   287: dload_1
    //   288: dcmpl
    //   289: dstore 20
    //   291: iload 4
    //   293: ifne +20 -> 313
    //   296: aload_0
    //   297: invokevirtual 129	com/a/a/be:b	()D
    //   300: astore 6
    //   302: dload 15
    //   304: dload_1
    //   305: dcmpl
    //   306: dstore 20
    //   308: iload 4
    //   310: ifeq +14 -> 324
    //   313: aload_0
    //   314: invokevirtual 132	com/a/a/be:i	()Z
    //   317: astore 4
    //   319: iload 4
    //   321: ifne +36 -> 357
    //   324: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   327: astore 4
    //   329: getstatic 47	com/a/br:h	[Ljava/lang/String;
    //   332: iconst_3
    //   333: aaload
    //   334: astore 23
    //   336: aload 4
    //   338: aload 23
    //   340: invokevirtual 91	com/a/ag:b	(Ljava/lang/String;)V
    //   343: aload 5
    //   345: monitorexit
    //   346: goto -95 -> 251
    //   349: astore 4
    //   351: aload 5
    //   353: monitorexit
    //   354: aload 4
    //   356: athrow
    //   357: aload_0
    //   358: invokevirtual 98	com/a/a/be:e	()Lcom/a/h;
    //   361: astore 4
    //   363: aload 4
    //   365: ifnonnull +28 -> 393
    //   368: getstatic 54	com/a/br:c	Lcom/a/ag;
    //   371: astore 4
    //   373: getstatic 47	com/a/br:h	[Ljava/lang/String;
    //   376: iconst_2
    //   377: aaload
    //   378: astore 24
    //   380: aload 4
    //   382: aload 24
    //   384: invokevirtual 91	com/a/ag:b	(Ljava/lang/String;)V
    //   387: aload 5
    //   389: monitorexit
    //   390: goto -139 -> 251
    //   393: aload_0
    //   394: putstatic 93	com/a/br:g	Lcom/a/a/be;
    //   397: getstatic 60	com/a/br:e	Ljava/util/WeakHashMap;
    //   400: invokevirtual 136	java/util/WeakHashMap:keySet	()Ljava/util/Set;
    //   403: astore 4
    //   405: aload 4
    //   407: invokeinterface 142 1 0
    //   412: astore 6
    //   414: aload 6
    //   416: invokeinterface 147 1 0
    //   421: astore 4
    //   423: iload 4
    //   425: ifeq +29 -> 454
    //   428: aload 6
    //   430: invokeinterface 151 1 0
    //   435: checkcast 2	com/a/br
    //   438: astore 4
    //   440: aload 4
    //   442: aload_0
    //   443: invokespecial 153	com/a/br:b	(Lcom/a/a/be;)V
    //   446: iload_3
    //   447: ifne +10 -> 457
    //   450: iload_3
    //   451: ifeq -37 -> 414
    //   454: aload 5
    //   456: monitorexit
    //   457: getstatic 156	com/a/bf:d	I
    //   460: istore 4
    //   462: iload 4
    //   464: ifeq -213 -> 251
    //   467: iload_3
    //   468: iconst_1
    //   469: iadd
    //   470: istore 4
    //   472: iload 4
    //   474: putstatic 70	com/a/bt:g	I
    //   477: goto -226 -> 251
    //
    // Exception table:
    //   from	to	target	type
    //   85	354	349	finally
    //   357	457	349	finally
  }

  /** @deprecated */
  private void b(be parambe)
  {
    monitorenter;
    try
    {
      boolean bool = b();
      if (!bool)
        return;
      this.b = parambe;
    }
    finally
    {
      monitorexit;
    }
  }

  /** @deprecated */
  public boolean b()
  {
    monitorenter;
    try
    {
      boolean bool = this.a;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.br
 * JD-Core Version:    0.5.4
 */