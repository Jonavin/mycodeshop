package com.a;

import java.io.InputStream;

public abstract class aa
{
  protected int b = null;
  protected String c = "";
  protected String d = null;
  protected long e = 0L;
  protected InputStream f = null;

  public void a()
  {
    this.f.close();
  }

  public int b()
  {
    return this.b;
  }

  public String c()
  {
    return this.c;
  }

  public String d()
  {
    return this.d;
  }

  public InputStream e()
  {
    return this.f;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.aa
 * JD-Core Version:    0.5.4
 */