package com.a;

public abstract interface ao
{
  public abstract void a(ac paramac);
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ao
 * JD-Core Version:    0.5.4
 */