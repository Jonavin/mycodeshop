package com.a;

class cc
  implements Runnable
{
  private static final String c;
  final h a;
  final d b;

  static
  {
    char[] arrayOfChar1 = "\007]\rVaCA\007Pc\007G\b]bCW\nYd\017WL\021&\002T\020]tC".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 6; ; k = 56)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        c = new String(localObject1).intern();
        return;
        k = 99;
        continue;
        k = 50;
        continue;
        k = 100;
      }
  }

  cc(d paramd)
  {
    h localh = h.d();
    this.a = localh;
  }

  public void run()
  {
    boolean bool = d.a(this.b).a();
    Object localObject2;
    if (bool)
    {
      ??? = d.a(this.b);
      localObject2 = new StringBuilder();
      String str = c;
      localObject2 = ((StringBuilder)localObject2).append(str);
      long l = this.a.c();
      Object localObject5;
      localObject2 = localObject5;
      ((ag)???).b((String)localObject2);
    }
    synchronized (this.b)
    {
      localObject2 = this.b;
      d.b((d)localObject2);
    }
    try
    {
      localObject2 = this.b;
      d.a((d)localObject2, null);
      monitorexit;
      return;
      localObject3 = finally;
      d.a(this.b, null);
      throw localObject3;
    }
    finally
    {
      monitorexit;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.cc
 * JD-Core Version:    0.5.4
 */