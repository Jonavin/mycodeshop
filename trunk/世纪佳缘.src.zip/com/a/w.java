package com.a;

import java.io.InputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;

final class w extends aa
{
  HttpEntity a;

  w(HttpResponse paramHttpResponse)
  {
    int i = paramHttpResponse.getStatusLine().getStatusCode();
    this.b = i;
    String str1 = paramHttpResponse.getStatusLine().getReasonPhrase();
    this.c = str1;
    HttpEntity localHttpEntity = paramHttpResponse.getEntity();
    this.a = localHttpEntity;
    if (this.a == null)
      return;
    InputStream localInputStream = this.a.getContent();
    this.f = localInputStream;
    long l = this.a.getContentLength();
    Object localObject;
    this.e = localObject;
    if (this.a.getContentType() == null)
      return;
    String str2 = this.a.getContentType().getValue();
    this.d = str2;
  }

  public void a()
  {
    super.a();
    this.a.consumeContent();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.w
 * JD-Core Version:    0.5.4
 */