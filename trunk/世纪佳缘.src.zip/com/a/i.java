package com.a;

import java.util.ArrayList;

public abstract class i extends bf
{
  private static i a;
  public static final i b;
  public static int c;
  private static final String e;

  static
  {
    char[] arrayOfChar1 = "N\005p=C\r\027{n\027]\026qnXY\035nD".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 55; ; k = 26)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        e = new String(localObject1).intern();
        b = new g();
        a = null;
        return;
        k = 45;
        continue;
        k = 100;
        continue;
        k = 30;
      }
  }

  public static i b(av paramav)
  {
    Object localObject = a;
    if (localObject == null);
    for (localObject = new d(paramav); ; localObject = a.a(paramav))
      return localObject;
  }

  protected abstract i a(av paramav);

  public abstract void a(long paramLong);

  public abstract void a(ArrayList paramArrayList);

  public abstract boolean b();

  public abstract void c();

  public abstract String d();

  public abstract boolean e();

  public abstract boolean f();

  public abstract boolean g();

  public abstract String h();

  public abstract boolean i();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.i
 * JD-Core Version:    0.5.4
 */