package com.a;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Looper;
import com.a.a.be;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

final class u extends bt
{
  private static final String[] p;
  private final Callable a;
  private final ag h;
  private final Context i;
  private final LocationManager j;
  private final cg k;
  private final bz l;
  private final String m;
  private long n;
  private be o;

  static
  {
    int i1 = 100;
    int i2 = 85;
    int i3 = 21;
    int i4 = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[18];
    char[] arrayOfChar1 = "-\024{\n\026\031<qN(\0316t\032\r\031;E\034\013纮<q\013\026?8e\002".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject76;
    Object localObject78;
    Object localObject7;
    Object localObject43;
    int i6;
    int i22;
    label115: Object localObject3;
    if (localObject6 <= i4)
    {
      Object localObject42 = localObject1;
      localObject76 = localObject6;
      localObject78 = localObject42;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject42;
      localObject43 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject76)
      {
        i6 = localObject7[arrayOfChar1];
        i22 = localObject78 % 5;
        switch (i22)
        {
        default:
          i22 = i1;
          i6 = (char)(i6 ^ i22);
          localObject7[arrayOfChar1] = i6;
          localObject2 = localObject78 + 1;
          if (localObject76 != 0)
            break;
          localObject7 = localObject43;
          localObject78 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject76;
      Object localObject79 = localObject43;
      localObject43 = localObject2;
      localObject3 = localObject79;
    }
    while (true)
    {
      if (localObject7 <= localObject43);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "_\b".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= i4)
      {
        localObject43 = localObject1;
        localObject76 = localObject8;
        localObject78 = localObject43;
        localObject9 = localObject3;
        Object localObject80 = localObject43;
        localObject43 = localObject3;
        Object localObject4;
        for (localObject3 = localObject80; ; localObject4 = localObject76)
        {
          i6 = localObject9[localObject3];
          i22 = localObject78 % 5;
          switch (i22)
          {
          default:
            i22 = i1;
            i6 = (char)(i6 ^ i22);
            localObject9[localObject3] = i6;
            localObject4 = localObject78 + 1;
            if (localObject76 != 0)
              break;
            localObject9 = localObject43;
            localObject78 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject76;
        Object localObject81 = localObject43;
        localObject43 = localObject4;
        localObject5 = localObject81;
      }
      while (true)
      {
        if (localObject9 <= localObject43);
        localObject5 = new String(localObject5).intern();
        arrayOfString[i4] = localObject5;
        int i5 = 2;
        localObject9 = "V%g\001\022\0371p\034D\027#t\007\b\0277y\013".toCharArray();
        Object localObject44 = localObject9.length;
        Object localObject45;
        Object localObject77;
        int i23;
        label475: Object localObject11;
        if (localObject44 <= i4)
        {
          localObject76 = localObject1;
          localObject78 = localObject44;
          i6 = localObject76;
          localObject45 = localObject9;
          Object localObject82 = localObject76;
          localObject77 = localObject9;
          Object localObject10;
          for (localObject9 = localObject82; ; localObject10 = localObject78)
          {
            i22 = localObject45[localObject9];
            i23 = i6 % 5;
            switch (i23)
            {
            default:
              i23 = i1;
              i22 = (char)(i22 ^ i23);
              localObject45[localObject9] = i22;
              localObject10 = i6 + 1;
              if (localObject78 != 0)
                break;
              localObject45 = localObject77;
              i6 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject45 = localObject78;
          Object localObject83 = localObject77;
          localObject77 = localObject10;
          localObject11 = localObject83;
        }
        while (true)
        {
          if (localObject45 <= localObject77);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i5] = localObject11;
          i5 = 3;
          localObject11 = "8\020A9+$\036".toCharArray();
          Object localObject46 = localObject11.length;
          Object localObject47;
          label659: Object localObject13;
          if (localObject46 <= i4)
          {
            localObject77 = localObject1;
            localObject78 = localObject46;
            int i7 = localObject77;
            localObject47 = localObject11;
            Object localObject84 = localObject77;
            localObject77 = localObject11;
            Object localObject12;
            for (localObject11 = localObject84; ; localObject12 = localObject78)
            {
              i22 = localObject47[localObject11];
              i23 = i7 % 5;
              switch (i23)
              {
              default:
                i23 = i1;
                i22 = (char)(i22 ^ i23);
                localObject47[localObject11] = i22;
                localObject12 = i7 + 1;
                if (localObject78 != 0)
                  break;
                localObject47 = localObject77;
                i7 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject47 = localObject78;
            Object localObject85 = localObject77;
            localObject77 = localObject12;
            localObject13 = localObject85;
          }
          while (true)
          {
            if (localObject47 <= localObject77);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i5] = localObject13;
            i5 = 4;
            localObject13 = "1\005F".toCharArray();
            Object localObject48 = localObject13.length;
            Object localObject49;
            label843: Object localObject15;
            if (localObject48 <= i4)
            {
              localObject77 = localObject1;
              localObject78 = localObject48;
              int i8 = localObject77;
              localObject49 = localObject13;
              Object localObject86 = localObject77;
              localObject77 = localObject13;
              Object localObject14;
              for (localObject13 = localObject86; ; localObject14 = localObject78)
              {
                i22 = localObject49[localObject13];
                i23 = i8 % 5;
                switch (i23)
                {
                default:
                  i23 = i1;
                  i22 = (char)(i22 ^ i23);
                  localObject49[localObject13] = i22;
                  localObject14 = i8 + 1;
                  if (localObject78 != 0)
                    break;
                  localObject49 = localObject77;
                  i8 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject49 = localObject78;
              Object localObject87 = localObject77;
              localObject77 = localObject14;
              localObject15 = localObject87;
            }
            while (true)
            {
              if (localObject49 <= localObject77);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i5] = localObject15;
              i5 = 5;
              localObject15 = "\030:5".toCharArray();
              Object localObject50 = localObject15.length;
              Object localObject51;
              label1027: Object localObject17;
              if (localObject50 <= i4)
              {
                localObject77 = localObject1;
                localObject78 = localObject50;
                int i9 = localObject77;
                localObject51 = localObject15;
                Object localObject88 = localObject77;
                localObject77 = localObject15;
                Object localObject16;
                for (localObject15 = localObject88; ; localObject16 = localObject78)
                {
                  i22 = localObject51[localObject15];
                  i23 = i9 % 5;
                  switch (i23)
                  {
                  default:
                    i23 = i1;
                    i22 = (char)(i22 ^ i23);
                    localObject51[localObject15] = i22;
                    localObject16 = i9 + 1;
                    if (localObject78 != 0)
                      break;
                    localObject51 = localObject77;
                    i9 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject51 = localObject78;
                Object localObject89 = localObject77;
                localObject77 = localObject16;
                localObject17 = localObject89;
              }
              while (true)
              {
                if (localObject51 <= localObject77);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i5] = localObject17;
                i5 = 6;
                localObject17 = "\025:`\002纮V;z\032D\0210aN(\0316t\032\r\031;X\017\n\0272p".toCharArray();
                Object localObject52 = localObject17.length;
                Object localObject53;
                label1211: Object localObject19;
                if (localObject52 <= i4)
                {
                  localObject77 = localObject1;
                  localObject78 = localObject52;
                  int i10 = localObject77;
                  localObject53 = localObject17;
                  Object localObject90 = localObject77;
                  localObject77 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject90; ; localObject18 = localObject78)
                  {
                    i22 = localObject53[localObject17];
                    i23 = i10 % 5;
                    switch (i23)
                    {
                    default:
                      i23 = i1;
                      i22 = (char)(i22 ^ i23);
                      localObject53[localObject17] = i22;
                      localObject18 = i10 + 1;
                      if (localObject78 != 0)
                        break;
                      localObject53 = localObject77;
                      i10 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject53 = localObject78;
                  Object localObject91 = localObject77;
                  localObject77 = localObject18;
                  localObject19 = localObject91;
                }
                while (true)
                {
                  if (localObject53 <= localObject77);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i5] = localObject19;
                  i5 = 7;
                  localObject19 = "\0300a\031\013\004>".toCharArray();
                  Object localObject54 = localObject19.length;
                  Object localObject55;
                  label1395: Object localObject21;
                  if (localObject54 <= i4)
                  {
                    localObject77 = localObject1;
                    localObject78 = localObject54;
                    int i11 = localObject77;
                    localObject55 = localObject19;
                    Object localObject92 = localObject77;
                    localObject77 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject92; ; localObject20 = localObject78)
                    {
                      i22 = localObject55[localObject19];
                      i23 = i11 % 5;
                      switch (i23)
                      {
                      default:
                        i23 = i1;
                        i22 = (char)(i22 ^ i23);
                        localObject55[localObject19] = i22;
                        localObject20 = i11 + 1;
                        if (localObject78 != 0)
                          break;
                        localObject55 = localObject77;
                        i11 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject55 = localObject78;
                    Object localObject93 = localObject77;
                    localObject77 = localObject20;
                    localObject21 = localObject93;
                  }
                  while (true)
                  {
                    if (localObject55 <= localObject77);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i5] = localObject21;
                    i5 = 8;
                    localObject21 = "\0276a\007\022\037!lN纮\0310f纮C\002u}\017\022\023ue\013\026\033<f\035\r\031;5\032\013V f\013D\006'z\030\r\0220".toCharArray();
                    Object localObject56 = localObject21.length;
                    Object localObject57;
                    label1579: Object localObject23;
                    if (localObject56 <= i4)
                    {
                      localObject77 = localObject1;
                      localObject78 = localObject56;
                      int i12 = localObject77;
                      localObject57 = localObject21;
                      Object localObject94 = localObject77;
                      localObject77 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject94; ; localObject22 = localObject78)
                      {
                        i22 = localObject57[localObject21];
                        i23 = i12 % 5;
                        switch (i23)
                        {
                        default:
                          i23 = i1;
                          i22 = (char)(i22 ^ i23);
                          localObject57[localObject21] = i22;
                          localObject22 = i12 + 1;
                          if (localObject78 != 0)
                            break;
                          localObject57 = localObject77;
                          i12 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject57 = localObject78;
                      Object localObject95 = localObject77;
                      localObject77 = localObject22;
                      localObject23 = localObject95;
                    }
                    while (true)
                    {
                      if (localObject57 <= localObject77);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i5] = localObject23;
                      i5 = 9;
                      localObject23 = "\021%f".toCharArray();
                      Object localObject58 = localObject23.length;
                      Object localObject59;
                      label1763: Object localObject25;
                      if (localObject58 <= i4)
                      {
                        localObject77 = localObject1;
                        localObject78 = localObject58;
                        int i13 = localObject77;
                        localObject59 = localObject23;
                        Object localObject96 = localObject77;
                        localObject77 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject96; ; localObject24 = localObject78)
                        {
                          i22 = localObject59[localObject23];
                          i23 = i13 % 5;
                          switch (i23)
                          {
                          default:
                            i23 = i1;
                            i22 = (char)(i22 ^ i23);
                            localObject59[localObject23] = i22;
                            localObject24 = i13 + 1;
                            if (localObject78 != 0)
                              break;
                            localObject59 = localObject77;
                            i13 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject59 = localObject78;
                        Object localObject97 = localObject77;
                        localObject77 = localObject24;
                        localObject25 = localObject97;
                      }
                      while (true)
                      {
                        if (localObject59 <= localObject77);
                        localObject25 = new String(localObject25).intern();
                        arrayOfString[i5] = localObject25;
                        i5 = 10;
                        localObject25 = "V\"|\032\fV%p\034\r\03115".toCharArray();
                        Object localObject60 = localObject25.length;
                        Object localObject61;
                        label1947: Object localObject27;
                        if (localObject60 <= i4)
                        {
                          localObject77 = localObject1;
                          localObject78 = localObject60;
                          int i14 = localObject77;
                          localObject61 = localObject25;
                          Object localObject98 = localObject77;
                          localObject77 = localObject25;
                          Object localObject26;
                          for (localObject25 = localObject98; ; localObject26 = localObject78)
                          {
                            i22 = localObject61[localObject25];
                            i23 = i14 % 5;
                            switch (i23)
                            {
                            default:
                              i23 = i1;
                              i22 = (char)(i22 ^ i23);
                              localObject61[localObject25] = i22;
                              localObject26 = i14 + 1;
                              if (localObject78 != 0)
                                break;
                              localObject61 = localObject77;
                              i14 = localObject26;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject61 = localObject78;
                          Object localObject99 = localObject77;
                          localObject77 = localObject26;
                          localObject27 = localObject99;
                        }
                        while (true)
                        {
                          if (localObject61 <= localObject77);
                          localObject27 = new String(localObject27).intern();
                          arrayOfString[i5] = localObject27;
                          i5 = 11;
                          localObject27 = "\002't\r\017\037;rN\024\023'|\001纮V\"t\035D\030:aN\007\0364{\t\001".toCharArray();
                          Object localObject62 = localObject27.length;
                          Object localObject63;
                          label2131: Object localObject29;
                          if (localObject62 <= i4)
                          {
                            localObject77 = localObject1;
                            localObject78 = localObject62;
                            int i15 = localObject77;
                            localObject63 = localObject27;
                            Object localObject100 = localObject77;
                            localObject77 = localObject27;
                            Object localObject28;
                            for (localObject27 = localObject100; ; localObject28 = localObject78)
                            {
                              i22 = localObject63[localObject27];
                              i23 = i15 % 5;
                              switch (i23)
                              {
                              default:
                                i23 = i1;
                                i22 = (char)(i22 ^ i23);
                                localObject63[localObject27] = i22;
                                localObject28 = i15 + 1;
                                if (localObject78 != 0)
                                  break;
                                localObject63 = localObject77;
                                i15 = localObject28;
                              case 0:
                              case 1:
                              case 2:
                              case 3:
                              }
                            }
                            localObject63 = localObject78;
                            Object localObject101 = localObject77;
                            localObject77 = localObject28;
                            localObject29 = localObject101;
                          }
                          while (true)
                          {
                            if (localObject63 <= localObject77);
                            localObject29 = new String(localObject29).intern();
                            arrayOfString[i5] = localObject29;
                            i5 = 12;
                            localObject29 = "\037;c\017\b\03715\036\001\004<z\n^V".toCharArray();
                            Object localObject64 = localObject29.length;
                            Object localObject65;
                            label2315: Object localObject31;
                            if (localObject64 <= i4)
                            {
                              localObject77 = localObject1;
                              localObject78 = localObject64;
                              int i16 = localObject77;
                              localObject65 = localObject29;
                              Object localObject102 = localObject77;
                              localObject77 = localObject29;
                              Object localObject30;
                              for (localObject29 = localObject102; ; localObject30 = localObject78)
                              {
                                i22 = localObject65[localObject29];
                                i23 = i16 % 5;
                                switch (i23)
                                {
                                default:
                                  i23 = i1;
                                  i22 = (char)(i22 ^ i23);
                                  localObject65[localObject29] = i22;
                                  localObject30 = i16 + 1;
                                  if (localObject78 != 0)
                                    break;
                                  localObject65 = localObject77;
                                  i16 = localObject30;
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                }
                              }
                              localObject65 = localObject78;
                              Object localObject103 = localObject77;
                              localObject77 = localObject30;
                              localObject31 = localObject103;
                            }
                            while (true)
                            {
                              if (localObject65 <= localObject77);
                              localObject31 = new String(localObject31).intern();
                              arrayOfString[i5] = localObject31;
                              i5 = 13;
                              localObject31 = "\005!t\034\020\02315\032\026\0276~\007\n\021u".toCharArray();
                              Object localObject66 = localObject31.length;
                              Object localObject67;
                              label2499: Object localObject33;
                              if (localObject66 <= i4)
                              {
                                localObject77 = localObject1;
                                localObject78 = localObject66;
                                int i17 = localObject77;
                                localObject67 = localObject31;
                                Object localObject104 = localObject77;
                                localObject77 = localObject31;
                                Object localObject32;
                                for (localObject31 = localObject104; ; localObject32 = localObject78)
                                {
                                  i22 = localObject67[localObject31];
                                  i23 = i17 % 5;
                                  switch (i23)
                                  {
                                  default:
                                    i23 = i1;
                                    i22 = (char)(i22 ^ i23);
                                    localObject67[localObject31] = i22;
                                    localObject32 = i17 + 1;
                                    if (localObject78 != 0)
                                      break;
                                    localObject67 = localObject77;
                                    i17 = localObject32;
                                  case 0:
                                  case 1:
                                  case 2:
                                  case 3:
                                  }
                                }
                                localObject67 = localObject78;
                                Object localObject105 = localObject77;
                                localObject77 = localObject32;
                                localObject33 = localObject105;
                              }
                              while (true)
                              {
                                if (localObject67 <= localObject77);
                                localObject33 = new String(localObject33).intern();
                                arrayOfString[i5] = localObject33;
                                i5 = 14;
                                localObject33 = "\025:`\002纮\030raN\003\023!5\002\013\0254a\007\013\030u`\036纮\027!p\035D\020:gN\024\004:c\007纮".toCharArray();
                                Object localObject68 = localObject33.length;
                                Object localObject69;
                                label2683: Object localObject35;
                                if (localObject68 <= i4)
                                {
                                  localObject77 = localObject1;
                                  localObject78 = localObject68;
                                  int i18 = localObject77;
                                  localObject69 = localObject33;
                                  Object localObject106 = localObject77;
                                  localObject77 = localObject33;
                                  Object localObject34;
                                  for (localObject33 = localObject106; ; localObject34 = localObject78)
                                  {
                                    i22 = localObject69[localObject33];
                                    i23 = i18 % 5;
                                    switch (i23)
                                    {
                                    default:
                                      i23 = i1;
                                      i22 = (char)(i22 ^ i23);
                                      localObject69[localObject33] = i22;
                                      localObject34 = i18 + 1;
                                      if (localObject78 != 0)
                                        break;
                                      localObject69 = localObject77;
                                      i18 = localObject34;
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    }
                                  }
                                  localObject69 = localObject78;
                                  Object localObject107 = localObject77;
                                  localObject77 = localObject34;
                                  localObject35 = localObject107;
                                }
                                while (true)
                                {
                                  if (localObject69 <= localObject77);
                                  localObject35 = new String(localObject35).intern();
                                  arrayOfString[i5] = localObject35;
                                  i5 = 15;
                                  localObject35 = "V<{\035\020\0234qN\013\020u".toCharArray();
                                  Object localObject70 = localObject35.length;
                                  Object localObject71;
                                  label2867: Object localObject37;
                                  if (localObject70 <= i4)
                                  {
                                    localObject77 = localObject1;
                                    localObject78 = localObject70;
                                    int i19 = localObject77;
                                    localObject71 = localObject35;
                                    Object localObject108 = localObject77;
                                    localObject77 = localObject35;
                                    Object localObject36;
                                    for (localObject35 = localObject108; ; localObject36 = localObject78)
                                    {
                                      i22 = localObject71[localObject35];
                                      i23 = i19 % 5;
                                      switch (i23)
                                      {
                                      default:
                                        i23 = i1;
                                        i22 = (char)(i22 ^ i23);
                                        localObject71[localObject35] = i22;
                                        localObject36 = i19 + 1;
                                        if (localObject78 != 0)
                                          break;
                                        localObject71 = localObject77;
                                        i19 = localObject36;
                                      case 0:
                                      case 1:
                                      case 2:
                                      case 3:
                                      }
                                    }
                                    localObject71 = localObject78;
                                    Object localObject109 = localObject77;
                                    localObject77 = localObject36;
                                    localObject37 = localObject109;
                                  }
                                  while (true)
                                  {
                                    if (localObject71 <= localObject77);
                                    localObject37 = new String(localObject37).intern();
                                    arrayOfString[i5] = localObject37;
                                    i5 = 16;
                                    localObject37 = "\005!z\036\024\02315\032\026\0276~\007\n\021u".toCharArray();
                                    Object localObject72 = localObject37.length;
                                    Object localObject73;
                                    label3051: Object localObject39;
                                    if (localObject72 <= i4)
                                    {
                                      localObject77 = localObject1;
                                      localObject78 = localObject72;
                                      int i20 = localObject77;
                                      localObject73 = localObject37;
                                      Object localObject110 = localObject77;
                                      localObject77 = localObject37;
                                      Object localObject38;
                                      for (localObject37 = localObject110; ; localObject38 = localObject78)
                                      {
                                        i22 = localObject73[localObject37];
                                        i23 = i20 % 5;
                                        switch (i23)
                                        {
                                        default:
                                          i23 = i1;
                                          i22 = (char)(i22 ^ i23);
                                          localObject73[localObject37] = i22;
                                          localObject38 = i20 + 1;
                                          if (localObject78 != 0)
                                            break;
                                          localObject73 = localObject77;
                                          i20 = localObject38;
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        }
                                      }
                                      localObject73 = localObject78;
                                      Object localObject111 = localObject77;
                                      localObject77 = localObject38;
                                      localObject39 = localObject111;
                                    }
                                    while (true)
                                    {
                                      if (localObject73 <= localObject77);
                                      localObject39 = new String(localObject39).intern();
                                      arrayOfString[i5] = localObject39;
                                      i5 = 17;
                                      localObject39 = "\025:`\002纮\030raN\026\0238z\030\001V e\n\005\0020".toCharArray();
                                      Object localObject74 = localObject39.length;
                                      label3235: Object localObject41;
                                      if (localObject74 <= i4)
                                      {
                                        localObject77 = localObject1;
                                        localObject78 = localObject74;
                                        int i21 = localObject77;
                                        localObject75 = localObject39;
                                        Object localObject112 = localObject77;
                                        localObject77 = localObject39;
                                        Object localObject40;
                                        for (localObject39 = localObject112; ; localObject40 = localObject78)
                                        {
                                          i22 = localObject75[localObject39];
                                          i23 = i21 % 5;
                                          switch (i23)
                                          {
                                          default:
                                            i23 = i1;
                                            int i24 = (char)(i22 ^ i23);
                                            localObject75[localObject39] = i22;
                                            localObject40 = i21 + 1;
                                            if (localObject78 != 0)
                                              break;
                                            localObject75 = localObject77;
                                            i21 = localObject40;
                                          case 0:
                                          case 1:
                                          case 2:
                                          case 3:
                                          }
                                        }
                                        localObject75 = localObject78;
                                        Object localObject113 = localObject77;
                                        localObject77 = localObject40;
                                        localObject41 = localObject113;
                                      }
                                      while (true)
                                      {
                                        if (localObject75 <= localObject77);
                                        String str = new String(localObject41).intern();
                                        arrayOfString[i5] = localObject41;
                                        p = arrayOfString;
                                        return;
                                        i22 = 118;
                                        break label115:
                                        i22 = i2;
                                        break label115:
                                        i22 = i3;
                                        break label115:
                                        i22 = 110;
                                        break label115:
                                        i22 = 118;
                                        break label295:
                                        i22 = i2;
                                        break label295:
                                        i22 = i3;
                                        break label295:
                                        i22 = 110;
                                        break label295:
                                        i23 = 118;
                                        break label475:
                                        i23 = i2;
                                        break label475:
                                        i23 = i3;
                                        break label475:
                                        i23 = 110;
                                        break label475:
                                        i23 = 118;
                                        break label659:
                                        i23 = i2;
                                        break label659:
                                        i23 = i3;
                                        break label659:
                                        i23 = 110;
                                        break label659:
                                        i23 = 118;
                                        break label843:
                                        i23 = i2;
                                        break label843:
                                        i23 = i3;
                                        break label843:
                                        i23 = 110;
                                        break label843:
                                        i23 = 118;
                                        break label1027:
                                        i23 = i2;
                                        break label1027:
                                        i23 = i3;
                                        break label1027:
                                        i23 = 110;
                                        break label1027:
                                        i23 = 118;
                                        break label1211:
                                        i23 = i2;
                                        break label1211:
                                        i23 = i3;
                                        break label1211:
                                        i23 = 110;
                                        break label1211:
                                        i23 = 118;
                                        break label1395:
                                        i23 = i2;
                                        break label1395:
                                        i23 = i3;
                                        break label1395:
                                        i23 = 110;
                                        break label1395:
                                        i23 = 118;
                                        break label1579:
                                        i23 = i2;
                                        break label1579:
                                        i23 = i3;
                                        break label1579:
                                        i23 = 110;
                                        break label1579:
                                        i23 = 118;
                                        break label1763:
                                        i23 = i2;
                                        break label1763:
                                        i23 = i3;
                                        break label1763:
                                        i23 = 110;
                                        break label1763:
                                        i23 = 118;
                                        break label1947:
                                        i23 = i2;
                                        break label1947:
                                        i23 = i3;
                                        break label1947:
                                        i23 = 110;
                                        break label1947:
                                        i23 = 118;
                                        break label2131:
                                        i23 = i2;
                                        break label2131:
                                        i23 = i3;
                                        break label2131:
                                        i23 = 110;
                                        break label2131:
                                        i23 = 118;
                                        break label2315:
                                        i23 = i2;
                                        break label2315:
                                        i23 = i3;
                                        break label2315:
                                        i23 = 110;
                                        break label2315:
                                        i23 = 118;
                                        break label2499:
                                        i23 = i2;
                                        break label2499:
                                        i23 = i3;
                                        break label2499:
                                        i23 = 110;
                                        break label2499:
                                        i23 = 118;
                                        break label2683:
                                        i23 = i2;
                                        break label2683:
                                        i23 = i3;
                                        break label2683:
                                        i23 = 110;
                                        break label2683:
                                        i23 = 118;
                                        break label2867:
                                        i23 = i2;
                                        break label2867:
                                        i23 = i3;
                                        break label2867:
                                        i23 = 110;
                                        break label2867:
                                        i23 = 118;
                                        break label3051:
                                        i23 = i2;
                                        break label3051:
                                        i23 = i3;
                                        break label3051:
                                        i23 = 110;
                                        break label3051:
                                        i23 = 118;
                                        break label3235:
                                        i23 = i2;
                                        break label3235:
                                        i23 = i3;
                                        break label3235:
                                        i23 = 110;
                                        break label3235:
                                        localObject77 = localObject1;
                                      }
                                      localObject77 = localObject1;
                                    }
                                    localObject77 = localObject1;
                                  }
                                  localObject77 = localObject1;
                                }
                                localObject77 = localObject1;
                              }
                              localObject77 = localObject1;
                            }
                            localObject77 = localObject1;
                          }
                          localObject77 = localObject1;
                        }
                        localObject77 = localObject1;
                      }
                      localObject77 = localObject1;
                    }
                    localObject77 = localObject1;
                  }
                  localObject77 = localObject1;
                }
                localObject77 = localObject1;
              }
              localObject77 = localObject1;
            }
            localObject77 = localObject1;
          }
          localObject77 = localObject1;
        }
        localObject75 = localObject1;
      }
      Object localObject75 = localObject1;
    }
  }

  u(av paramav, String paramString)
  {
    cf localcf = new cf(this);
    this.a = localcf;
    ag localag = ag.b(u.class);
    this.h = localag;
    Context localContext = ((aq)paramav).a();
    this.i = localContext;
    this.n = 65535L;
    if (p[4].equals(paramString))
    {
      String str1 = p[i1];
      this.m = str1;
      if (i5 == 0)
        break label207;
      int i6 = bf.d;
      int i7;
      ++i7;
      bf.d = i6;
    }
    if (p[3].equals(paramString))
    {
      String str2 = p[7];
      this.m = str2;
      if (i5 == 0)
        break label207;
    }
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str3 = p[i3];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str3).append(paramString);
    String str4 = p[i4];
    String str5 = str4;
    throw new bc(str5);
    try
    {
      label207: Future localFuture = at.a(this.a);
      TimeUnit localTimeUnit = TimeUnit.MILLISECONDS;
      LocationManager localLocationManager1 = (LocationManager)localFuture.get(2000L, localTimeUnit);
      this.j = localLocationManager1;
      if (this.j == null)
      {
        String str6 = p[6];
        throw new bc(str6);
      }
    }
    catch (Throwable localThrowable)
    {
      String str7 = p[i2];
      throw new bc(str7, localThrowable);
    }
    String str8 = p[9];
    String str9 = this.m;
    if (str8.equals(str9))
    {
      LocationManager localLocationManager2 = this.j;
      bz localbz = new bz(localLocationManager2);
      this.l = localbz;
      if (i5 == 0)
        break label348;
    }
    this.l = null;
    label348: cg localcg = new cg(this, null);
    this.k = localcg;
    List localList1 = this.j.getProviders(null);
    String str10 = this.m;
    if (localList1.contains(str10))
      return;
    List localList2 = this.j.getAllProviders();
    String str11 = this.m;
    if (localList2.contains(str11))
    {
      StringBuilder localStringBuilder3 = new StringBuilder();
      String str12 = p[8];
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str12);
      String str13 = this.m;
      String str14 = str13;
      throw new bc(str14);
    }
    StringBuilder localStringBuilder5 = new StringBuilder();
    String str15 = p[i3];
    StringBuilder localStringBuilder6 = localStringBuilder5.append(str15);
    String str16 = this.m;
    StringBuilder localStringBuilder7 = localStringBuilder6.append(str16);
    String str17 = p[i4];
    String str18 = str17;
    throw new bc(str18);
  }

  static Context a(u paramu)
  {
    return paramu.i;
  }

  static be a(Location paramLocation)
  {
    long l1 = 0L;
    int i1;
    if (paramLocation == null)
      i1 = 0;
    while (true)
    {
      return i1;
      be localbe = new be();
      if ((paramLocation.getLatitude() != l1) || (paramLocation.getLongitude() != l1))
      {
        double d1 = paramLocation.getLatitude();
        Object localObject1;
        localbe.a(localObject1);
        double d2 = paramLocation.getLongitude();
        Object localObject2;
        localbe.b(localObject2);
      }
      if (paramLocation.getTime() != 0L)
      {
        long l2 = paramLocation.getTime();
        Object localObject3;
        localbe.a(localObject3);
      }
      if (paramLocation.hasAccuracy())
      {
        int i2 = Math.round(paramLocation.getAccuracy());
        localbe.a(i2);
      }
      if (paramLocation.hasAltitude())
      {
        double d3 = paramLocation.getAltitude();
        Object localObject4;
        localbe.c(localObject4);
      }
      if (paramLocation.hasBearing())
      {
        double d4 = paramLocation.getBearing();
        localbe.d(d4);
      }
      if (!paramLocation.hasSpeed())
        continue;
      double d5 = paramLocation.getSpeed();
      localbe.e(d5);
    }
  }

  static be a(u paramu, be parambe)
  {
    paramu.o = parambe;
    return parambe;
  }

  static ag b(u paramu)
  {
    return paramu.h;
  }

  static String c(u paramu)
  {
    return paramu.m;
  }

  static bz d(u paramu)
  {
    return paramu.l;
  }

  static be e(u paramu)
  {
    return paramu.o;
  }

  static void f(u paramu)
  {
    paramu.a();
  }

  public bt a(av paramav, String paramString)
  {
    return new u(paramav, paramString);
  }

  public void a(long paramLong)
  {
    if (paramLong < 0L)
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = p[12];
      String str2 = str1 + paramLong;
      throw new IllegalArgumentException(str2);
    }
    long l1 = this.n;
    if (paramLong == l1)
    {
      ag localag1 = this.h;
      String str3 = p[11];
      localag1.b(str3);
    }
    while (true)
    {
      return;
      d();
      try
      {
        LocationManager localLocationManager = this.j;
        String str4 = this.m;
        cg localcg = this.k;
        Looper localLooper = at.a();
        long l2 = paramLong;
        localLocationManager.requestLocationUpdates(str4, l2, null, localcg, localLooper);
        if (this.h.a())
        {
          ag localag2 = this.h;
          StringBuilder localStringBuilder2 = new StringBuilder();
          String str5 = p[13];
          StringBuilder localStringBuilder3 = localStringBuilder2.append(str5);
          String str6 = this.m;
          StringBuilder localStringBuilder4 = localStringBuilder3.append(str6);
          String str7 = p[10];
          StringBuilder localStringBuilder5 = localStringBuilder4.append(str7).append(paramLong);
          String str8 = p[15];
          StringBuilder localStringBuilder6 = localStringBuilder5.append(str8);
          long l3 = this.n;
          String str9 = l3;
          localag2.b(str9);
        }
        this.n = paramLong;
        String str10 = this.m;
        String str11 = p[9];
        if (str10.equals(str11));
        this.l.a();
      }
      catch (Throwable localThrowable)
      {
        ag localag3 = this.h;
        StringBuilder localStringBuilder7 = new StringBuilder();
        String str12 = p[14];
        StringBuilder localStringBuilder8 = localStringBuilder7.append(str12);
        String str13 = this.m;
        String str14 = str13;
        localag3.b(str14, localThrowable);
      }
    }
  }

  /** @deprecated */
  public be b()
  {
    monitorenter;
    try
    {
      be localbe1 = this.o;
      if (localbe1 == null)
      {
        int i1 = 0;
        return i1;
      }
    }
    finally
    {
      be localbe2;
      monitorexit;
    }
  }

  public boolean c()
  {
    long l1 = this.n < 65535L;
    int i1;
    if (i1 > 0)
      i1 = 1;
    while (true)
    {
      return i1;
      Object localObject = null;
    }
  }

  public void d()
  {
    if (!c());
    while (true)
    {
      return;
      try
      {
        LocationManager localLocationManager = this.j;
        cg localcg = this.k;
        localLocationManager.removeUpdates(localcg);
        if (this.h.a())
        {
          ag localag1 = this.h;
          StringBuilder localStringBuilder1 = new StringBuilder();
          String str1 = p[16];
          StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
          String str2 = this.m;
          StringBuilder localStringBuilder3 = localStringBuilder2.append(str2);
          String str3 = p[10];
          StringBuilder localStringBuilder4 = localStringBuilder3.append(str3);
          long l1 = this.n;
          String str4 = l1;
          localag1.b(str4);
        }
        label120: this.o = null;
        this.n = 65535L;
        String str5 = this.m;
        String str6 = p[9];
        if (str5.equals(str6));
        this.l.b();
      }
      catch (Throwable localThrowable)
      {
        ag localag2 = this.h;
        String str7 = p[17];
        localag2.c(str7, localThrowable);
        break label120:
      }
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = p[null];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = this.m;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2);
    String str3 = p[1];
    return str3;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.u
 * JD-Core Version:    0.5.4
 */