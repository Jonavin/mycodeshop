package com.a;

public final class ax
  implements Comparable
{
  private final int a;
  private final int b;
  private final int c;
  private final int d;
  private final int e;

  public ax(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramInt1;
    this.b = paramInt2;
    if (paramInt3 == i);
    for (int j = i; ; j = 0xFFFF & paramInt3)
    {
      this.c = j;
      this.d = paramInt4;
      this.e = i;
      return;
    }
  }

  public int a()
  {
    return this.e;
  }

  public int a(ax paramax)
  {
    int i;
    if (paramax == null)
      i = -1;
    while (true)
    {
      return i;
      i = this.a;
      int j = paramax.a;
      i -= j;
      if (i != 0)
        continue;
      i = this.b;
      int k = paramax.b;
      i -= k;
      if (i != 0)
        continue;
      i = this.c;
      int l = paramax.c;
      i -= l;
      if (i != 0)
        continue;
      i = this.d;
      int i1 = paramax.d;
      i -= i1;
      if (i != 0)
        continue;
      i = this.e;
      int i2 = paramax.e;
      i -= i2;
    }
  }

  public int b()
  {
    return this.c;
  }

  public int c()
  {
    return this.d;
  }

  public int d()
  {
    return this.a;
  }

  public int e()
  {
    return this.b;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      try
      {
        paramObject = (ax)paramObject;
        int i = this.c;
        int j = paramObject.c;
        if (i == j)
        {
          i = this.d;
          j = paramObject.d;
          if (i == j)
          {
            i = this.b;
            j = paramObject.b;
            if (i == j)
            {
              i = this.a;
              j = paramObject.a;
              if (i == j)
              {
                i = this.e;
                j = paramObject.e;
                if (i == j)
                  i = 1;
              }
            }
          }
        }
        Object localObject3 = localObject1;
      }
      catch (ClassCastException localObject4)
      {
        Object localObject4 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    int i = this.e;
    if (i == -1)
    {
      i = this.c;
      int j = this.d;
      i ^= j;
    }
    while (true)
    {
      return i;
      i = this.e;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("[");
    int i = this.a;
    localStringBuilder = localStringBuilder.append(i).append(",");
    i = this.b;
    localStringBuilder = localStringBuilder.append(i).append(",");
    i = this.e;
    int k;
    if (i == -1)
    {
      localObject = new StringBuilder();
      int j = this.d;
      localObject = ((StringBuilder)localObject).append(j).append(",");
      k = this.c;
    }
    for (Object localObject = k; ; localObject = Integer.valueOf(this.e))
      return localObject + "]";
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ax
 * JD-Core Version:    0.5.4
 */