package com.a;

import java.util.Comparator;

public abstract interface af
{
  public static final Comparator f = new bx();

  public abstract h e();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.af
 * JD-Core Version:    0.5.4
 */