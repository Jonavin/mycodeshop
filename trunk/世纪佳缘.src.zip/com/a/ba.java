package com.a;

public enum ba
{
  private static final ba[] g;
  private static final String[] h;

  static
  {
    int i = 94;
    int j = 79;
    int k = 32;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[6];
    char[] arrayOfChar1 = "\032#\r+g".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject28;
    Object localObject30;
    Object localObject7;
    Object localObject19;
    int i2;
    int i6;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject18 = localObject1;
      localObject28 = localObject6;
      localObject30 = localObject18;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject18;
      localObject19 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject28)
      {
        i2 = localObject7[arrayOfChar1];
        i6 = localObject30 % 5;
        switch (i6)
        {
        default:
          i6 = k;
          i2 = (char)(i2 ^ i6);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject30 + 1;
          if (localObject28 != 0)
            break;
          localObject7 = localObject19;
          localObject30 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject28;
      Object localObject31 = localObject19;
      localObject19 = localObject2;
      localObject3 = localObject31;
    }
    while (true)
    {
      if (localObject7 <= localObject19);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "\n4\016=e".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject19 = localObject1;
        localObject28 = localObject8;
        localObject30 = localObject19;
        localObject9 = localObject3;
        Object localObject32 = localObject19;
        localObject19 = localObject3;
        Object localObject4;
        for (localObject3 = localObject32; ; localObject4 = localObject28)
        {
          i2 = localObject9[localObject3];
          i6 = localObject30 % 5;
          switch (i6)
          {
          default:
            i6 = k;
            i2 = (char)(i2 ^ i6);
            localObject9[localObject3] = i2;
            localObject4 = localObject30 + 1;
            if (localObject28 != 0)
              break;
            localObject9 = localObject19;
            localObject30 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject28;
        Object localObject33 = localObject19;
        localObject19 = localObject4;
        localObject5 = localObject33;
      }
      while (true)
      {
        if (localObject9 <= localObject19);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "\020)\001;".toCharArray();
        Object localObject20 = localObject9.length;
        Object localObject21;
        Object localObject29;
        int i7;
        label475: Object localObject11;
        if (localObject20 <= l)
        {
          localObject28 = localObject1;
          localObject30 = localObject20;
          i2 = localObject28;
          localObject21 = localObject9;
          Object localObject34 = localObject28;
          localObject29 = localObject9;
          Object localObject10;
          for (localObject9 = localObject34; ; localObject10 = localObject30)
          {
            i6 = localObject21[localObject9];
            i7 = i2 % 5;
            switch (i7)
            {
            default:
              i7 = k;
              i6 = (char)(i6 ^ i7);
              localObject21[localObject9] = i6;
              localObject10 = i2 + 1;
              if (localObject30 != 0)
                break;
              localObject21 = localObject29;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject21 = localObject30;
          Object localObject35 = localObject29;
          localObject29 = localObject10;
          localObject11 = localObject35;
        }
        while (true)
        {
          if (localObject21 <= localObject29);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "\t'\0350".toCharArray();
          Object localObject22 = localObject11.length;
          Object localObject23;
          label659: Object localObject13;
          if (localObject22 <= l)
          {
            localObject29 = localObject1;
            localObject30 = localObject22;
            int i3 = localObject29;
            localObject23 = localObject11;
            Object localObject36 = localObject29;
            localObject29 = localObject11;
            Object localObject12;
            for (localObject11 = localObject36; ; localObject12 = localObject30)
            {
              i6 = localObject23[localObject11];
              i7 = i3 % 5;
              switch (i7)
              {
              default:
                i7 = k;
                i6 = (char)(i6 ^ i7);
                localObject23[localObject11] = i6;
                localObject12 = i3 + 1;
                if (localObject30 != 0)
                  break;
                localObject23 = localObject29;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject23 = localObject30;
            Object localObject37 = localObject29;
            localObject29 = localObject12;
            localObject13 = localObject37;
          }
          while (true)
          {
            if (localObject23 <= localObject29);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "\0334\0351r".toCharArray();
            Object localObject24 = localObject13.length;
            Object localObject25;
            label843: Object localObject15;
            if (localObject24 <= l)
            {
              localObject29 = localObject1;
              localObject30 = localObject24;
              int i4 = localObject29;
              localObject25 = localObject13;
              Object localObject38 = localObject29;
              localObject29 = localObject13;
              Object localObject14;
              for (localObject13 = localObject38; ; localObject14 = localObject30)
              {
                i6 = localObject25[localObject13];
                i7 = i4 % 5;
                switch (i7)
                {
                default:
                  i7 = k;
                  i6 = (char)(i6 ^ i7);
                  localObject25[localObject13] = i6;
                  localObject14 = i4 + 1;
                  if (localObject30 != 0)
                    break;
                  localObject25 = localObject29;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject25 = localObject30;
              Object localObject39 = localObject29;
              localObject29 = localObject14;
              localObject15 = localObject39;
            }
            while (true)
            {
              if (localObject25 <= localObject29);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "\027(\t1".toCharArray();
              Object localObject26 = localObject15.length;
              label1027: Object localObject17;
              if (localObject26 <= l)
              {
                localObject29 = localObject1;
                localObject30 = localObject26;
                int i5 = localObject29;
                localObject27 = localObject15;
                Object localObject40 = localObject29;
                localObject29 = localObject15;
                Object localObject16;
                for (localObject15 = localObject40; ; localObject16 = localObject30)
                {
                  i6 = localObject27[localObject15];
                  i7 = i5 % 5;
                  switch (i7)
                  {
                  default:
                    i7 = k;
                    int i8 = (char)(i6 ^ i7);
                    localObject27[localObject15] = i6;
                    localObject16 = i5 + 1;
                    if (localObject30 != 0)
                      break;
                    localObject27 = localObject29;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject27 = localObject30;
                Object localObject41 = localObject29;
                localObject29 = localObject16;
                localObject17 = localObject41;
              }
              while (true)
              {
                if (localObject27 <= localObject29);
                String str1 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                h = arrayOfString;
                String str2 = h[l];
                a = new ba(i1, localObject1);
                String str3 = h[localObject1];
                b = new ba(i1, l);
                String str4 = h[5];
                c = new ba(i1, 2);
                String str5 = h[3];
                d = new ba(i1, 3);
                String str6 = h[4];
                e = new ba(i1, 4);
                String str7 = h[2];
                f = new ba(i1, 5);
                ba[] arrayOfba = new ba[6];
                ba localba1 = a;
                arrayOfString[localObject1] = i1;
                ba localba2 = b;
                arrayOfString[l] = i1;
                ba localba3 = c;
                arrayOfString[2] = localObject17;
                ba localba4 = d;
                arrayOfString[3] = localObject17;
                ba localba5 = e;
                arrayOfString[4] = localObject17;
                ba localba6 = f;
                arrayOfString[5] = localObject17;
                g = arrayOfString;
                return;
                i6 = i;
                break label115:
                i6 = 102;
                break label115:
                i6 = j;
                break label115:
                i6 = 126;
                break label115:
                i6 = i;
                break label295:
                i6 = 102;
                break label295:
                i6 = j;
                break label295:
                i6 = 126;
                break label295:
                i7 = i;
                break label475:
                i7 = 102;
                break label475:
                i7 = j;
                break label475:
                i7 = 126;
                break label475:
                i7 = i;
                break label659:
                i7 = 102;
                break label659:
                i7 = j;
                break label659:
                i7 = 126;
                break label659:
                i7 = i;
                break label843:
                i7 = 102;
                break label843:
                i7 = j;
                break label843:
                i7 = 126;
                break label843:
                i7 = i;
                break label1027:
                i7 = 102;
                break label1027:
                i7 = j;
                break label1027:
                i7 = 126;
                break label1027:
                localObject29 = localObject1;
              }
              localObject29 = localObject1;
            }
            localObject29 = localObject1;
          }
          localObject29 = localObject1;
        }
        localObject27 = localObject1;
      }
      Object localObject27 = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ba
 * JD-Core Version:    0.5.4
 */