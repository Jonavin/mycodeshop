package com.a;

import java.util.ArrayList;

public abstract class bh extends bf
{
  public static final bh a;
  private static bh b;
  private static final String c;

  static
  {
    char[] arrayOfChar1 = "ad//\037\"v$|Krw.|\004v|1m\030".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 107; ; k = 8)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        c = new String(localObject1).intern();
        a = new bm();
        b = null;
        return;
        k = 2;
        continue;
        k = 5;
        continue;
        k = 65;
      }
  }

  public static bh b(av paramav)
  {
    Object localObject = b;
    if (localObject == null);
    for (localObject = new bn(paramav); ; localObject = b.a(paramav))
      return localObject;
  }

  protected abstract bh a(av paramav);

  public abstract void a(ArrayList paramArrayList);

  public abstract void b();

  public abstract void c();

  public abstract String d();

  public abstract boolean e();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bh
 * JD-Core Version:    0.5.4
 */