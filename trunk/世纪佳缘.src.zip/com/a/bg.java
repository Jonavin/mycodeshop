package com.a;

import java.util.Iterator;

class bg
  implements Iterable
{
  private final Iterable a;
  private final bu b;

  bg(Iterable paramIterable, bu parambu)
  {
    this.a = paramIterable;
    this.b = parambu;
  }

  public Iterator iterator()
  {
    Iterator localIterator = this.a.iterator();
    bu localbu = this.b;
    return new bi(this, localIterator, localbu);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bg
 * JD-Core Version:    0.5.4
 */