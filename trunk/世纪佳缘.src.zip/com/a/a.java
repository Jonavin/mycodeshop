package com.a;

public final class a extends bf
{
  /** @deprecated */
  public void a()
  {
    monitorenter;
    try
    {
      super.a();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.a
 * JD-Core Version:    0.5.4
 */