package com.a;

import android.location.LocationManager;
import java.util.concurrent.Callable;

class ca
  implements Callable
{
  final bz a;

  ca(bz parambz)
  {
  }

  public Boolean a()
  {
    LocationManager localLocationManager = bz.a(this.a);
    bz localbz = this.a;
    return Boolean.valueOf(localLocationManager.addGpsStatusListener(localbz));
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ca
 * JD-Core Version:    0.5.4
 */