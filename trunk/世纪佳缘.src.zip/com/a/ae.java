package com.a;

import java.util.Comparator;

final class ae
  implements Comparator
{
  public int a(aw paramaw1, aw paramaw2)
  {
    ax localax1 = paramaw1.a();
    ax localax2 = paramaw2.a();
    return localax1.a(localax2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ae
 * JD-Core Version:    0.5.4
 */