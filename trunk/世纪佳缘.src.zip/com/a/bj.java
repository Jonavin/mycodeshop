package com.a;

import android.util.Log;

final class bj extends ag
{
  private static final String c;

  static
  {
    char[] arrayOfChar1 = "9xkx\0221nn9\0161`o$\0046ru%O\"gu".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 97; ; k = 86)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        c = new String(localObject1).intern();
        return;
        k = 90;
        continue;
        k = 23;
        continue;
        k = 6;
      }
  }

  public bj(Class paramClass)
  {
    super(paramClass);
  }

  protected ag a(Class paramClass)
  {
    return new bj(paramClass);
  }

  protected void a(ba paramba, String paramString)
  {
    int i;
    ag.b = i;
    int[] arrayOfInt = bs.a;
    int j = paramba.ordinal();
    switch (arrayOfInt[j])
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    }
    while (true)
    {
      return;
      Log.d(c, paramString);
      if (i == 0)
        continue;
      Log.e(c, paramString);
      if (i == 0)
        continue;
      Log.i(c, paramString);
      if (i == 0)
        continue;
      Log.v(c, paramString);
      if (i == 0)
        continue;
      Log.w(c, paramString);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bj
 * JD-Core Version:    0.5.4
 */