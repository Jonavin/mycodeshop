package com.a;

public abstract class ar
{
  public static final String a;
  public static final ay b;
  public static final String c;
  public static final String d;
  private static final String[] e;

  static
  {
    int i = 51;
    int j = 32;
    int k = 2;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[8];
    char[] arrayOfChar1 = "&O\001FInPMPOlR\nTUpU\027ZOlI".toCharArray();
    Object localObject14 = arrayOfChar1.length;
    Object localObject48;
    Object localObject50;
    Object localObject15;
    Object localObject37;
    int i2;
    int i7;
    label115: Object localObject3;
    if (localObject14 <= l)
    {
      Object localObject36 = localObject1;
      localObject48 = localObject14;
      localObject50 = localObject36;
      localObject15 = arrayOfChar1;
      char[] arrayOfChar2 = localObject36;
      localObject37 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject48)
      {
        i2 = localObject15[arrayOfChar1];
        i7 = localObject50 % 5;
        switch (i7)
        {
        default:
          i7 = j;
          i2 = (char)(i2 ^ i7);
          localObject15[arrayOfChar1] = i2;
          localObject2 = localObject50 + 1;
          if (localObject48 != 0)
            break;
          localObject15 = localObject37;
          localObject50 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject15 = localObject48;
      Object localObject51 = localObject37;
      localObject37 = localObject2;
      localObject3 = localObject51;
    }
    while (true)
    {
      if (localObject15 <= localObject37);
      a = new String(localObject3).intern();
      localObject3 = "-G\007PApPLDPqX\fT\016vL\027".toCharArray();
      Object localObject16 = localObject3.length;
      Object localObject17;
      label287: Object localObject5;
      if (localObject16 <= l)
      {
        localObject37 = localObject1;
        localObject48 = localObject16;
        localObject50 = localObject37;
        localObject17 = localObject3;
        Object localObject52 = localObject37;
        localObject37 = localObject3;
        Object localObject4;
        for (localObject3 = localObject52; ; localObject4 = localObject48)
        {
          i2 = localObject17[localObject3];
          i7 = localObject50 % 5;
          switch (i7)
          {
          default:
            i7 = j;
            i2 = (char)(i2 ^ i7);
            localObject17[localObject3] = i2;
            localObject4 = localObject50 + 1;
            if (localObject48 != 0)
              break;
            localObject17 = localObject37;
            localObject50 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject17 = localObject48;
        Object localObject53 = localObject37;
        localObject37 = localObject4;
        localObject5 = localObject53;
      }
      while (true)
      {
        if (localObject17 <= localObject37);
        d = new String(localObject5).intern();
        localObject5 = "Fq!fg".toCharArray();
        Object localObject18 = localObject5.length;
        Object localObject19;
        label459: Object localObject7;
        if (localObject18 <= l)
        {
          localObject37 = localObject1;
          localObject48 = localObject18;
          localObject50 = localObject37;
          localObject19 = localObject5;
          Object localObject54 = localObject37;
          localObject37 = localObject5;
          Object localObject6;
          for (localObject5 = localObject54; ; localObject6 = localObject48)
          {
            i2 = localObject19[localObject5];
            i7 = localObject50 % 5;
            switch (i7)
            {
            default:
              i7 = j;
              i2 = (char)(i2 ^ i7);
              localObject19[localObject5] = i2;
              localObject6 = localObject50 + 1;
              if (localObject48 != 0)
                break;
              localObject19 = localObject37;
              localObject50 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject19 = localObject48;
          Object localObject55 = localObject37;
          localObject37 = localObject6;
          localObject7 = localObject55;
        }
        while (true)
        {
          if (localObject19 <= localObject37);
          c = new String(localObject7).intern();
          localObject7 = ".\024\005\\RaQ&]A`X\006dId]^".toCharArray();
          Object localObject20 = localObject7.length;
          Object localObject21;
          label631: Object localObject9;
          if (localObject20 <= l)
          {
            localObject37 = localObject1;
            localObject48 = localObject20;
            localObject50 = localObject37;
            localObject21 = localObject7;
            Object localObject56 = localObject37;
            localObject37 = localObject7;
            Object localObject8;
            for (localObject7 = localObject56; ; localObject8 = localObject48)
            {
              i2 = localObject21[localObject7];
              i7 = localObject50 % 5;
              switch (i7)
              {
              default:
                i7 = j;
                i2 = (char)(i2 ^ i7);
                localObject21[localObject7] = i2;
                localObject8 = localObject50 + 1;
                if (localObject48 != 0)
                  break;
                localObject21 = localObject37;
                localObject50 = localObject8;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject21 = localObject48;
            Object localObject57 = localObject37;
            localObject37 = localObject8;
            localObject9 = localObject57;
          }
          while (true)
          {
            if (localObject21 <= localObject37);
            localObject9 = new String(localObject9).intern();
            arrayOfString[localObject1] = localObject9;
            localObject9 = ".\024\026@EE[\fTLgr\002_L`U纮X".toCharArray();
            Object localObject22 = localObject9.length;
            Object localObject23;
            label811: Object localObject11;
            if (localObject22 <= l)
            {
              localObject37 = localObject1;
              localObject48 = localObject22;
              localObject50 = localObject37;
              localObject23 = localObject9;
              Object localObject58 = localObject37;
              localObject37 = localObject9;
              Object localObject10;
              for (localObject9 = localObject58; ; localObject10 = localObject48)
              {
                i2 = localObject23[localObject9];
                i7 = localObject50 % 5;
                switch (i7)
                {
                default:
                  i7 = j;
                  i2 = (char)(i2 ^ i7);
                  localObject23[localObject9] = i2;
                  localObject10 = localObject50 + 1;
                  if (localObject48 != 0)
                    break;
                  localObject23 = localObject37;
                  localObject50 = localObject10;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject23 = localObject48;
              Object localObject59 = localObject37;
              localObject37 = localObject10;
              localObject11 = localObject59;
            }
            while (true)
            {
              if (localObject23 <= localObject37);
              localObject11 = new String(localObject11).intern();
              arrayOfString[l] = localObject11;
              localObject11 = ".\024\r\\sc@*TNmF\006cEp]\fW\035".toCharArray();
              Object localObject24 = localObject11.length;
              Object localObject25;
              label991: Object localObject13;
              if (localObject24 <= l)
              {
                localObject37 = localObject1;
                localObject48 = localObject24;
                localObject50 = localObject37;
                localObject25 = localObject11;
                Object localObject60 = localObject37;
                localObject37 = localObject11;
                Object localObject12;
                for (localObject11 = localObject60; ; localObject12 = localObject48)
                {
                  i2 = localObject25[localObject11];
                  i7 = localObject50 % 5;
                  switch (i7)
                  {
                  default:
                    i7 = j;
                    i2 = (char)(i2 ^ i7);
                    localObject25[localObject11] = i2;
                    localObject12 = localObject50 + 1;
                    if (localObject48 != 0)
                      break;
                    localObject25 = localObject37;
                    localObject50 = localObject12;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject25 = localObject48;
                Object localObject61 = localObject37;
                localObject37 = localObject12;
                localObject13 = localObject61;
              }
              while (true)
              {
                if (localObject25 <= localObject37);
                localObject13 = new String(localObject13).intern();
                arrayOfString[k] = localObject13;
                int i1 = 3;
                localObject25 = ".\024\017\\GD]\017Vpc@\013\016\017qP纮RRf\033\024CSn[\004\035Tz".toCharArray();
                Object localObject38 = localObject25.length;
                Object localObject39;
                Object localObject49;
                int i8;
                label1171: Object localObject27;
                if (localObject38 <= l)
                {
                  localObject48 = localObject1;
                  localObject50 = localObject38;
                  i2 = localObject48;
                  localObject39 = localObject25;
                  Object localObject62 = localObject48;
                  localObject49 = localObject25;
                  Object localObject26;
                  for (localObject25 = localObject62; ; localObject26 = localObject50)
                  {
                    i7 = localObject39[localObject25];
                    i8 = i2 % 5;
                    switch (i8)
                    {
                    default:
                      i8 = j;
                      i7 = (char)(i7 ^ i8);
                      localObject39[localObject25] = i7;
                      localObject26 = i2 + 1;
                      if (localObject50 != 0)
                        break;
                      localObject39 = localObject49;
                      i2 = localObject26;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject39 = localObject50;
                  Object localObject63 = localObject49;
                  localObject49 = localObject26;
                  localObject27 = localObject63;
                }
                while (true)
                {
                  if (localObject39 <= localObject49);
                  localObject27 = new String(localObject27).intern();
                  arrayOfString[i1] = localObject27;
                  i1 = 4;
                  localObject27 = ".\024\007ZScV\017VwkR\nzFA[\r]Ea@\006W\035".toCharArray();
                  Object localObject40 = localObject27.length;
                  Object localObject41;
                  label1355: Object localObject29;
                  if (localObject40 <= l)
                  {
                    localObject49 = localObject1;
                    localObject50 = localObject40;
                    int i3 = localObject49;
                    localObject41 = localObject27;
                    Object localObject64 = localObject49;
                    localObject49 = localObject27;
                    Object localObject28;
                    for (localObject27 = localObject64; ; localObject28 = localObject50)
                    {
                      i7 = localObject41[localObject27];
                      i8 = i3 % 5;
                      switch (i8)
                      {
                      default:
                        i8 = j;
                        i7 = (char)(i7 ^ i8);
                        localObject41[localObject27] = i7;
                        localObject28 = i3 + 1;
                        if (localObject50 != 0)
                          break;
                        localObject41 = localObject49;
                        i3 = localObject28;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject41 = localObject50;
                    Object localObject65 = localObject49;
                    localObject49 = localObject28;
                    localObject29 = localObject65;
                  }
                  while (true)
                  {
                    if (localObject41 <= localObject49);
                    localObject29 = new String(localObject29).intern();
                    arrayOfString[i1] = localObject29;
                    i1 = 5;
                    localObject29 = ".\024\016ZNN[\004EtQ\017\016".toCharArray();
                    Object localObject42 = localObject29.length;
                    Object localObject43;
                    label1539: Object localObject31;
                    if (localObject42 <= l)
                    {
                      localObject49 = localObject1;
                      localObject50 = localObject42;
                      int i4 = localObject49;
                      localObject43 = localObject29;
                      Object localObject66 = localObject49;
                      localObject49 = localObject29;
                      Object localObject30;
                      for (localObject29 = localObject66; ; localObject30 = localObject50)
                      {
                        i7 = localObject43[localObject29];
                        i8 = i4 % 5;
                        switch (i8)
                        {
                        default:
                          i8 = j;
                          i7 = (char)(i7 ^ i8);
                          localObject43[localObject29] = i7;
                          localObject30 = i4 + 1;
                          if (localObject50 != 0)
                            break;
                          localObject43 = localObject49;
                          i4 = localObject30;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject43 = localObject50;
                      Object localObject67 = localObject49;
                      localObject49 = localObject30;
                      localObject31 = localObject67;
                    }
                    while (true)
                    {
                      if (localObject43 <= localObject49);
                      localObject31 = new String(localObject31).intern();
                      arrayOfString[i1] = localObject31;
                      i1 = 6;
                      localObject31 = "YV\026ZLf\032纮\\Nd]\004FRc@\n\\N?\020\030QUkX\007\035CmZ\005ZGwF\002GImZ\036\037纮cX\017\\WQQ\027cRm@\fGYrQ\020\016FcX\020V\f\"A\020VgrG3\\LnQ\021\016FcX\020V\f\"X\fTGgF7JP".toCharArray();
                      Object localObject44 = localObject31.length;
                      Object localObject45;
                      label1723: Object localObject33;
                      if (localObject44 <= l)
                      {
                        localObject49 = localObject1;
                        localObject50 = localObject44;
                        int i5 = localObject49;
                        localObject45 = localObject31;
                        Object localObject68 = localObject49;
                        localObject49 = localObject31;
                        Object localObject32;
                        for (localObject31 = localObject68; ; localObject32 = localObject50)
                        {
                          i7 = localObject45[localObject31];
                          i8 = i5 % 5;
                          switch (i8)
                          {
                          default:
                            i8 = j;
                            i7 = (char)(i7 ^ i8);
                            localObject45[localObject31] = i7;
                            localObject32 = i5 + 1;
                            if (localObject50 != 0)
                              break;
                            localObject45 = localObject49;
                            i5 = localObject32;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject45 = localObject50;
                        Object localObject69 = localObject49;
                        localObject49 = localObject32;
                        localObject33 = localObject69;
                      }
                      while (true)
                      {
                        if (localObject45 <= localObject49);
                        localObject33 = new String(localObject33).intern();
                        arrayOfString[i1] = localObject33;
                        i1 = 7;
                        localObject33 = ".\024\r\\grG3AOt]\007VRKZ\tVCv]\f]\035".toCharArray();
                        Object localObject46 = localObject33.length;
                        label1907: Object localObject35;
                        if (localObject46 <= l)
                        {
                          localObject49 = localObject1;
                          localObject50 = localObject46;
                          int i6 = localObject49;
                          localObject47 = localObject33;
                          Object localObject70 = localObject49;
                          localObject49 = localObject33;
                          Object localObject34;
                          for (localObject33 = localObject70; ; localObject34 = localObject50)
                          {
                            i7 = localObject47[localObject33];
                            i8 = i6 % 5;
                            switch (i8)
                            {
                            default:
                              i8 = j;
                              int i9 = (char)(i7 ^ i8);
                              localObject47[localObject33] = i7;
                              localObject34 = i6 + 1;
                              if (localObject50 != 0)
                                break;
                              localObject47 = localObject49;
                              i6 = localObject34;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject47 = localObject50;
                          Object localObject71 = localObject49;
                          localObject49 = localObject34;
                          localObject35 = localObject71;
                        }
                        while (true)
                        {
                          if (localObject47 <= localObject49);
                          String str = new String(localObject35).intern();
                          arrayOfString[i1] = localObject35;
                          e = arrayOfString;
                          b = ay.c;
                          return;
                          i7 = k;
                          break label115:
                          i7 = 52;
                          break label115:
                          i7 = 99;
                          break label115:
                          i7 = i;
                          break label115:
                          i7 = k;
                          break label287:
                          i7 = 52;
                          break label287:
                          i7 = 99;
                          break label287:
                          i7 = i;
                          break label287:
                          i7 = k;
                          break label459:
                          i7 = 52;
                          break label459:
                          i7 = 99;
                          break label459:
                          i7 = i;
                          break label459:
                          i7 = k;
                          break label631:
                          i7 = 52;
                          break label631:
                          i7 = 99;
                          break label631:
                          i7 = i;
                          break label631:
                          i7 = k;
                          break label811:
                          i7 = 52;
                          break label811:
                          i7 = 99;
                          break label811:
                          i7 = i;
                          break label811:
                          i7 = k;
                          break label991:
                          i7 = 52;
                          break label991:
                          i7 = 99;
                          break label991:
                          i7 = i;
                          break label991:
                          i8 = k;
                          break label1171:
                          i8 = 52;
                          break label1171:
                          i8 = 99;
                          break label1171:
                          i8 = i;
                          break label1171:
                          i8 = k;
                          break label1355:
                          i8 = 52;
                          break label1355:
                          i8 = 99;
                          break label1355:
                          i8 = i;
                          break label1355:
                          i8 = k;
                          break label1539:
                          i8 = 52;
                          break label1539:
                          i8 = 99;
                          break label1539:
                          i8 = i;
                          break label1539:
                          i8 = k;
                          break label1723:
                          i8 = 52;
                          break label1723:
                          i8 = 99;
                          break label1723:
                          i8 = i;
                          break label1723:
                          i8 = k;
                          break label1907:
                          i8 = 52;
                          break label1907:
                          i8 = 99;
                          break label1907:
                          i8 = i;
                          break label1907:
                          localObject49 = localObject1;
                        }
                        localObject49 = localObject1;
                      }
                      localObject49 = localObject1;
                    }
                    localObject49 = localObject1;
                  }
                  localObject49 = localObject1;
                }
                localObject47 = localObject1;
              }
              localObject47 = localObject1;
            }
            localObject47 = localObject1;
          }
          localObject47 = localObject1;
        }
        localObject47 = localObject1;
      }
      Object localObject47 = localObject1;
    }
  }

  public static String a()
  {
    boolean bool1 = null;
    boolean bool2 = true;
    int i = h.a;
    Object localObject1 = new StringBuilder();
    Object localObject2 = e[6];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    localObject2 = b;
    localObject1 = ((StringBuilder)localObject1).append(localObject2);
    localObject2 = e[5];
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    localObject2 = c;
    localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
    localObject2 = b;
    ay localay = ay.b;
    if (localObject2 == localay);
    for (localObject2 = e[3]; ; localObject2 = "")
    {
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2);
      String str1 = e[bool1];
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(bool2);
      String str2 = e[4];
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(bool2);
      String str3 = e[2];
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(2000L);
      String str4 = e[7];
      localObject1 = ((StringBuilder)localObject1).append((String)localObject2).append(bool1);
      String str5 = e[bool2];
      localObject1 = (String)localObject2 + bool2 + "]";
      if (i != 0)
      {
        int j = bf.d;
        ++i;
        bf.d = j;
      }
      return localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ar
 * JD-Core Version:    0.5.4
 */