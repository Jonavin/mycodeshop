package com.a;

import android.net.wifi.WifiManager;

class ah
{
  static final boolean a;
  private static final String[] g;
  private final ag b;
  private int c;
  private int d;
  private boolean e;
  private WifiManager f;

  static
  {
    int i = 75;
    int j = 66;
    int k = 44;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[20];
    char[] arrayOfChar1 = "[\"$\033F_?+\036\n\f%'\027\002I/".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject84;
    Object localObject86;
    Object localObject7;
    Object localObject47;
    int i2;
    int i20;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject46 = localObject1;
      localObject84 = localObject6;
      localObject86 = localObject46;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject46;
      localObject47 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject84)
      {
        i2 = localObject7[arrayOfChar1];
        i20 = localObject86 % 5;
        switch (i20)
        {
        default:
          i20 = 102;
          i2 = (char)(i2 ^ i20);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject86 + 1;
          if (localObject84 != 0)
            break;
          localObject7 = localObject47;
          localObject86 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject84;
      Object localObject87 = localObject47;
      localObject47 = localObject2;
      localObject3 = localObject87;
    }
    while (true)
    {
      if (localObject7 <= localObject47);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "H\"1\023\004@.j[".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject47 = localObject1;
        localObject84 = localObject8;
        localObject86 = localObject47;
        localObject9 = localObject3;
        Object localObject88 = localObject47;
        localObject47 = localObject3;
        Object localObject4;
        for (localObject3 = localObject88; ; localObject4 = localObject84)
        {
          i2 = localObject9[localObject3];
          i20 = localObject86 % 5;
          switch (i20)
          {
          default:
            i20 = 102;
            i2 = (char)(i2 ^ i20);
            localObject9[localObject3] = i2;
            localObject4 = localObject86 + 1;
            if (localObject84 != 0)
              break;
            localObject9 = localObject47;
            localObject86 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject84;
        Object localObject89 = localObject47;
        localObject47 = localObject4;
        localObject5 = localObject89;
      }
      while (true)
      {
        if (localObject9 <= localObject47);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "[\"$\033FE8b\026\017_* \036\003Hgb\005\017@'b\027\bM).\027".toCharArray();
        Object localObject48 = localObject9.length;
        Object localObject49;
        Object localObject85;
        int i21;
        label480: Object localObject11;
        if (localObject48 <= l)
        {
          localObject84 = localObject1;
          localObject86 = localObject48;
          i2 = localObject84;
          localObject49 = localObject9;
          Object localObject90 = localObject84;
          localObject85 = localObject9;
          Object localObject10;
          for (localObject9 = localObject90; ; localObject10 = localObject86)
          {
            i20 = localObject49[localObject9];
            i21 = i2 % 5;
            switch (i21)
            {
            default:
              i21 = 102;
              i20 = (char)(i20 ^ i21);
              localObject49[localObject9] = i20;
              localObject10 = i2 + 1;
              if (localObject86 != 0)
                break;
              localObject49 = localObject85;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject49 = localObject86;
          Object localObject91 = localObject85;
          localObject85 = localObject10;
          localObject11 = localObject91;
        }
        while (true)
        {
          if (localObject49 <= localObject85);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "O$7\036\002B?eR\003B* \036\003\f<+\024\017".toCharArray();
          Object localObject50 = localObject11.length;
          Object localObject51;
          label664: Object localObject13;
          if (localObject50 <= l)
          {
            localObject85 = localObject1;
            localObject86 = localObject50;
            int i3 = localObject85;
            localObject51 = localObject11;
            Object localObject92 = localObject85;
            localObject85 = localObject11;
            Object localObject12;
            for (localObject11 = localObject92; ; localObject12 = localObject86)
            {
              i20 = localObject51[localObject11];
              i21 = i3 % 5;
              switch (i21)
              {
              default:
                i21 = 102;
                i20 = (char)(i20 ^ i21);
                localObject51[localObject11] = i20;
                localObject12 = i3 + 1;
                if (localObject86 != 0)
                  break;
                localObject51 = localObject85;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject51 = localObject86;
            Object localObject93 = localObject85;
            localObject85 = localObject12;
            localObject13 = localObject93;
          }
          while (true)
          {
            if (localObject51 <= localObject85);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "[.b\026\tBl6R\021M%6R\022Ck'\034\007N''R\021E-+R\007B2/\035\024I".toCharArray();
            Object localObject52 = localObject13.length;
            Object localObject53;
            label848: Object localObject15;
            if (localObject52 <= l)
            {
              localObject85 = localObject1;
              localObject86 = localObject52;
              int i4 = localObject85;
              localObject53 = localObject13;
              Object localObject94 = localObject85;
              localObject85 = localObject13;
              Object localObject14;
              for (localObject13 = localObject94; ; localObject14 = localObject86)
              {
                i20 = localObject53[localObject13];
                i21 = i4 % 5;
                switch (i21)
                {
                default:
                  i21 = 102;
                  i20 = (char)(i20 ^ i21);
                  localObject53[localObject13] = i20;
                  localObject14 = i4 + 1;
                  if (localObject86 != 0)
                    break;
                  localObject53 = localObject85;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject53 = localObject86;
              Object localObject95 = localObject85;
              localObject85 = localObject14;
              localObject15 = localObject95;
            }
            while (true)
            {
              if (localObject53 <= localObject85);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "[\"$\033FE8b\027\bM).\033\bK".toCharArray();
              Object localObject54 = localObject15.length;
              Object localObject55;
              label1032: Object localObject17;
              if (localObject54 <= l)
              {
                localObject85 = localObject1;
                localObject86 = localObject54;
                int i5 = localObject85;
                localObject55 = localObject15;
                Object localObject96 = localObject85;
                localObject85 = localObject15;
                Object localObject16;
                for (localObject15 = localObject96; ; localObject16 = localObject86)
                {
                  i20 = localObject55[localObject15];
                  i21 = i5 % 5;
                  switch (i21)
                  {
                  default:
                    i21 = 102;
                    i20 = (char)(i20 ^ i21);
                    localObject55[localObject15] = i20;
                    localObject16 = i5 + 1;
                    if (localObject86 != 0)
                      break;
                    localObject55 = localObject85;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject55 = localObject86;
                Object localObject97 = localObject85;
                localObject85 = localObject16;
                localObject17 = localObject97;
              }
              while (true)
              {
                if (localObject55 <= localObject85);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "[\"$\033FE8b\027\bM).\027\002".toCharArray();
                Object localObject56 = localObject17.length;
                Object localObject57;
                label1216: Object localObject19;
                if (localObject56 <= l)
                {
                  localObject85 = localObject1;
                  localObject86 = localObject56;
                  int i6 = localObject85;
                  localObject57 = localObject17;
                  Object localObject98 = localObject85;
                  localObject85 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject98; ; localObject18 = localObject86)
                  {
                    i20 = localObject57[localObject17];
                    i21 = i6 % 5;
                    switch (i21)
                    {
                    default:
                      i21 = 102;
                      i20 = (char)(i20 ^ i21);
                      localObject57[localObject17] = i20;
                      localObject18 = i6 + 1;
                      if (localObject86 != 0)
                        break;
                      localObject57 = localObject85;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject57 = localObject86;
                  Object localObject99 = localObject85;
                  localObject85 = localObject18;
                  localObject19 = localObject99;
                }
                while (true)
                {
                  if (localObject57 <= localObject85);
                  localObject19 = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  i1 = 7;
                  localObject19 = "[\"$\033FE8b\026\017_* \036\017B,nR\021E'.R\003B* \036\003\f'#\006\003^".toCharArray();
                  Object localObject58 = localObject19.length;
                  Object localObject59;
                  label1400: Object localObject21;
                  if (localObject58 <= l)
                  {
                    localObject85 = localObject1;
                    localObject86 = localObject58;
                    int i7 = localObject85;
                    localObject59 = localObject19;
                    Object localObject100 = localObject85;
                    localObject85 = localObject19;
                    Object localObject20;
                    for (localObject19 = localObject100; ; localObject20 = localObject86)
                    {
                      i20 = localObject59[localObject19];
                      i21 = i7 % 5;
                      switch (i21)
                      {
                      default:
                        i21 = 102;
                        i20 = (char)(i20 ^ i21);
                        localObject59[localObject19] = i20;
                        localObject20 = i7 + 1;
                        if (localObject86 != 0)
                          break;
                        localObject59 = localObject85;
                        i7 = localObject20;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject59 = localObject86;
                    Object localObject101 = localObject85;
                    localObject85 = localObject20;
                    localObject21 = localObject101;
                  }
                  while (true)
                  {
                    if (localObject59 <= localObject85);
                    localObject21 = new String(localObject21).intern();
                    arrayOfString[i1] = localObject21;
                    i1 = 8;
                    localObject21 = "_?#\006\003\f>2\026\007X.b\001\005D.&\007\nI/".toCharArray();
                    Object localObject60 = localObject21.length;
                    Object localObject61;
                    label1584: Object localObject23;
                    if (localObject60 <= l)
                    {
                      localObject85 = localObject1;
                      localObject86 = localObject60;
                      int i8 = localObject85;
                      localObject61 = localObject21;
                      Object localObject102 = localObject85;
                      localObject85 = localObject21;
                      Object localObject22;
                      for (localObject21 = localObject102; ; localObject22 = localObject86)
                      {
                        i20 = localObject61[localObject21];
                        i21 = i8 % 5;
                        switch (i21)
                        {
                        default:
                          i21 = 102;
                          i20 = (char)(i20 ^ i21);
                          localObject61[localObject21] = i20;
                          localObject22 = i8 + 1;
                          if (localObject86 != 0)
                            break;
                          localObject61 = localObject85;
                          i8 = localObject22;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject61 = localObject86;
                      Object localObject103 = localObject85;
                      localObject85 = localObject22;
                      localObject23 = localObject103;
                    }
                    while (true)
                    {
                      if (localObject61 <= localObject85);
                      localObject23 = new String(localObject23).intern();
                      arrayOfString[i1] = localObject23;
                      i1 = 9;
                      localObject23 = "Y;&\023\022Ik#\036\024I*&\013F_(*\027\002Y''\026".toCharArray();
                      Object localObject62 = localObject23.length;
                      Object localObject63;
                      label1768: Object localObject25;
                      if (localObject62 <= l)
                      {
                        localObject85 = localObject1;
                        localObject86 = localObject62;
                        int i9 = localObject85;
                        localObject63 = localObject23;
                        Object localObject104 = localObject85;
                        localObject85 = localObject23;
                        Object localObject24;
                        for (localObject23 = localObject104; ; localObject24 = localObject86)
                        {
                          i20 = localObject63[localObject23];
                          i21 = i9 % 5;
                          switch (i21)
                          {
                          default:
                            i21 = 102;
                            i20 = (char)(i20 ^ i21);
                            localObject63[localObject23] = i20;
                            localObject24 = i9 + 1;
                            if (localObject86 != 0)
                              break;
                            localObject63 = localObject85;
                            i9 = localObject24;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject63 = localObject86;
                        Object localObject105 = localObject85;
                        localObject85 = localObject24;
                        localObject25 = localObject105;
                      }
                      while (true)
                      {
                        if (localObject63 <= localObject85);
                        localObject25 = new String(localObject25).intern();
                        arrayOfString[i1] = localObject25;
                        i1 = 10;
                        localObject25 = "_?#\006\003\f>2\026\007X.b\021\tA;.\027\022I".toCharArray();
                        Object localObject64 = localObject25.length;
                        Object localObject65;
                        label1952: Object localObject27;
                        if (localObject64 <= l)
                        {
                          localObject85 = localObject1;
                          localObject86 = localObject64;
                          int i10 = localObject85;
                          localObject65 = localObject25;
                          Object localObject106 = localObject85;
                          localObject85 = localObject25;
                          Object localObject26;
                          for (localObject25 = localObject106; ; localObject26 = localObject86)
                          {
                            i20 = localObject65[localObject25];
                            i21 = i10 % 5;
                            switch (i21)
                            {
                            default:
                              i21 = 102;
                              i20 = (char)(i20 ^ i21);
                              localObject65[localObject25] = i20;
                              localObject26 = i10 + 1;
                              if (localObject86 != 0)
                                break;
                              localObject65 = localObject85;
                              i10 = localObject26;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject65 = localObject86;
                          Object localObject107 = localObject85;
                          localObject85 = localObject26;
                          localObject27 = localObject107;
                        }
                        while (true)
                        {
                          if (localObject65 <= localObject85);
                          localObject27 = new String(localObject27).intern();
                          arrayOfString[i1] = localObject27;
                          i1 = 11;
                          localObject27 = "[\"$\033FE8b\026\017_* \036\017B,".toCharArray();
                          Object localObject66 = localObject27.length;
                          Object localObject67;
                          label2136: Object localObject29;
                          if (localObject66 <= l)
                          {
                            localObject85 = localObject1;
                            localObject86 = localObject66;
                            int i11 = localObject85;
                            localObject67 = localObject27;
                            Object localObject108 = localObject85;
                            localObject85 = localObject27;
                            Object localObject28;
                            for (localObject27 = localObject108; ; localObject28 = localObject86)
                            {
                              i20 = localObject67[localObject27];
                              i21 = i11 % 5;
                              switch (i21)
                              {
                              default:
                                i21 = 102;
                                i20 = (char)(i20 ^ i21);
                                localObject67[localObject27] = i20;
                                localObject28 = i11 + 1;
                                if (localObject86 != 0)
                                  break;
                                localObject67 = localObject85;
                                i11 = localObject28;
                              case 0:
                              case 1:
                              case 2:
                              case 3:
                              }
                            }
                            localObject67 = localObject86;
                            Object localObject109 = localObject85;
                            localObject85 = localObject28;
                            localObject29 = localObject109;
                          }
                          while (true)
                          {
                            if (localObject67 <= localObject85);
                            localObject29 = new String(localObject29).intern();
                            arrayOfString[i1] = localObject29;
                            i1 = 12;
                            localObject29 = "O$7\036\002Bl6R\002E8#\020\nIk5\033纮".toCharArray();
                            Object localObject68 = localObject29.length;
                            Object localObject69;
                            label2320: Object localObject31;
                            if (localObject68 <= l)
                            {
                              localObject85 = localObject1;
                              localObject86 = localObject68;
                              int i12 = localObject85;
                              localObject69 = localObject29;
                              Object localObject110 = localObject85;
                              localObject85 = localObject29;
                              Object localObject30;
                              for (localObject29 = localObject110; ; localObject30 = localObject86)
                              {
                                i20 = localObject69[localObject29];
                                i21 = i12 % 5;
                                switch (i21)
                                {
                                default:
                                  i21 = 102;
                                  i20 = (char)(i20 ^ i21);
                                  localObject69[localObject29] = i20;
                                  localObject30 = i12 + 1;
                                  if (localObject86 != 0)
                                    break;
                                  localObject69 = localObject85;
                                  i12 = localObject30;
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                }
                              }
                              localObject69 = localObject86;
                              Object localObject111 = localObject85;
                              localObject85 = localObject30;
                              localObject31 = localObject111;
                            }
                            while (true)
                            {
                              if (localObject69 <= localObject85);
                              localObject31 = new String(localObject31).intern();
                              arrayOfString[i1] = localObject31;
                              i1 = 13;
                              localObject31 = "[\"$\033FE8b\027\bM).\033\bKgb\005\017@'b\026\017_* \036\003\f'#\006\003^".toCharArray();
                              Object localObject70 = localObject31.length;
                              Object localObject71;
                              label2504: Object localObject33;
                              if (localObject70 <= l)
                              {
                                localObject85 = localObject1;
                                localObject86 = localObject70;
                                int i13 = localObject85;
                                localObject71 = localObject31;
                                Object localObject112 = localObject85;
                                localObject85 = localObject31;
                                Object localObject32;
                                for (localObject31 = localObject112; ; localObject32 = localObject86)
                                {
                                  i20 = localObject71[localObject31];
                                  i21 = i13 % 5;
                                  switch (i21)
                                  {
                                  default:
                                    i21 = 102;
                                    i20 = (char)(i20 ^ i21);
                                    localObject71[localObject31] = i20;
                                    localObject32 = i13 + 1;
                                    if (localObject86 != 0)
                                      break;
                                    localObject71 = localObject85;
                                    i13 = localObject32;
                                  case 0:
                                  case 1:
                                  case 2:
                                  case 3:
                                  }
                                }
                                localObject71 = localObject86;
                                Object localObject113 = localObject85;
                                localObject85 = localObject32;
                                localObject33 = localObject113;
                              }
                              while (true)
                              {
                                if (localObject71 <= localObject85);
                                localObject33 = new String(localObject33).intern();
                                arrayOfString[i1] = localObject33;
                                i1 = 14;
                                localObject33 = "[.b\026\tBl6R\021M%6R\022Ck&\033\025M).\027F[\"$\033FM%;\037\t^.".toCharArray();
                                Object localObject72 = localObject33.length;
                                Object localObject73;
                                label2688: Object localObject35;
                                if (localObject72 <= l)
                                {
                                  localObject85 = localObject1;
                                  localObject86 = localObject72;
                                  int i14 = localObject85;
                                  localObject73 = localObject33;
                                  Object localObject114 = localObject85;
                                  localObject85 = localObject33;
                                  Object localObject34;
                                  for (localObject33 = localObject114; ; localObject34 = localObject86)
                                  {
                                    i20 = localObject73[localObject33];
                                    i21 = i14 % 5;
                                    switch (i21)
                                    {
                                    default:
                                      i21 = 102;
                                      i20 = (char)(i20 ^ i21);
                                      localObject73[localObject33] = i20;
                                      localObject34 = i14 + 1;
                                      if (localObject86 != 0)
                                        break;
                                      localObject73 = localObject85;
                                      i14 = localObject34;
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    }
                                  }
                                  localObject73 = localObject86;
                                  Object localObject115 = localObject85;
                                  localObject85 = localObject34;
                                  localObject35 = localObject115;
                                }
                                while (true)
                                {
                                  if (localObject73 <= localObject85);
                                  localObject35 = new String(localObject35).intern();
                                  arrayOfString[i1] = localObject35;
                                  i1 = 15;
                                  localObject35 = "[\"$\033FE8b\026\017_* \036\003H".toCharArray();
                                  Object localObject74 = localObject35.length;
                                  Object localObject75;
                                  label2872: Object localObject37;
                                  if (localObject74 <= l)
                                  {
                                    localObject85 = localObject1;
                                    localObject86 = localObject74;
                                    int i15 = localObject85;
                                    localObject75 = localObject35;
                                    Object localObject116 = localObject85;
                                    localObject85 = localObject35;
                                    Object localObject36;
                                    for (localObject35 = localObject116; ; localObject36 = localObject86)
                                    {
                                      i20 = localObject75[localObject35];
                                      i21 = i15 % 5;
                                      switch (i21)
                                      {
                                      default:
                                        i21 = 102;
                                        i20 = (char)(i20 ^ i21);
                                        localObject75[localObject35] = i20;
                                        localObject36 = i15 + 1;
                                        if (localObject86 != 0)
                                          break;
                                        localObject75 = localObject85;
                                        i15 = localObject36;
                                      case 0:
                                      case 1:
                                      case 2:
                                      case 3:
                                      }
                                    }
                                    localObject75 = localObject86;
                                    Object localObject117 = localObject85;
                                    localObject85 = localObject36;
                                    localObject37 = localObject117;
                                  }
                                  while (true)
                                  {
                                    if (localObject75 <= localObject85);
                                    localObject37 = new String(localObject37).intern();
                                    arrayOfString[i1] = localObject37;
                                    i1 = 16;
                                    localObject37 = "[\"$\033FE8b\027\bM).\027\002纮k5\033\n@k&\033\025M).".toCharArray();
                                    Object localObject76 = localObject37.length;
                                    Object localObject77;
                                    label3056: Object localObject39;
                                    if (localObject76 <= l)
                                    {
                                      localObject85 = localObject1;
                                      localObject86 = localObject76;
                                      int i16 = localObject85;
                                      localObject77 = localObject37;
                                      Object localObject118 = localObject85;
                                      localObject85 = localObject37;
                                      Object localObject38;
                                      for (localObject37 = localObject118; ; localObject38 = localObject86)
                                      {
                                        i20 = localObject77[localObject37];
                                        i21 = i16 % 5;
                                        switch (i21)
                                        {
                                        default:
                                          i21 = 102;
                                          i20 = (char)(i20 ^ i21);
                                          localObject77[localObject37] = i20;
                                          localObject38 = i16 + 1;
                                          if (localObject86 != 0)
                                            break;
                                          localObject77 = localObject85;
                                          i16 = localObject38;
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        }
                                      }
                                      localObject77 = localObject86;
                                      Object localObject119 = localObject85;
                                      localObject85 = localObject38;
                                      localObject39 = localObject119;
                                    }
                                    while (true)
                                    {
                                      if (localObject77 <= localObject85);
                                      localObject39 = new String(localObject39).intern();
                                      arrayOfString[i1] = localObject39;
                                      i1 = 17;
                                      localObject39 = "[.b\026\017H%e\006FI%#\020\nIk5\033纮".toCharArray();
                                      Object localObject78 = localObject39.length;
                                      Object localObject79;
                                      label3240: Object localObject41;
                                      if (localObject78 <= l)
                                      {
                                        localObject85 = localObject1;
                                        localObject86 = localObject78;
                                        int i17 = localObject85;
                                        localObject79 = localObject39;
                                        Object localObject120 = localObject85;
                                        localObject85 = localObject39;
                                        Object localObject40;
                                        for (localObject39 = localObject120; ; localObject40 = localObject86)
                                        {
                                          i20 = localObject79[localObject39];
                                          i21 = i17 % 5;
                                          switch (i21)
                                          {
                                          default:
                                            i21 = 102;
                                            i20 = (char)(i20 ^ i21);
                                            localObject79[localObject39] = i20;
                                            localObject40 = i17 + 1;
                                            if (localObject86 != 0)
                                              break;
                                            localObject79 = localObject85;
                                            i17 = localObject40;
                                          case 0:
                                          case 1:
                                          case 2:
                                          case 3:
                                          }
                                        }
                                        localObject79 = localObject86;
                                        Object localObject121 = localObject85;
                                        localObject85 = localObject40;
                                        localObject41 = localObject121;
                                      }
                                      while (true)
                                      {
                                        if (localObject79 <= localObject85);
                                        localObject41 = new String(localObject41).intern();
                                        arrayOfString[i1] = localObject41;
                                        i1 = 18;
                                        localObject41 = "[\"$\033FM'0\027\007H2b\027\bM).\027\002\f$,\021\003".toCharArray();
                                        Object localObject80 = localObject41.length;
                                        Object localObject81;
                                        label3424: Object localObject43;
                                        if (localObject80 <= l)
                                        {
                                          localObject85 = localObject1;
                                          localObject86 = localObject80;
                                          int i18 = localObject85;
                                          localObject81 = localObject41;
                                          Object localObject122 = localObject85;
                                          localObject85 = localObject41;
                                          Object localObject42;
                                          for (localObject41 = localObject122; ; localObject42 = localObject86)
                                          {
                                            i20 = localObject81[localObject41];
                                            i21 = i18 % 5;
                                            switch (i21)
                                            {
                                            default:
                                              i21 = 102;
                                              i20 = (char)(i20 ^ i21);
                                              localObject81[localObject41] = i20;
                                              localObject42 = i18 + 1;
                                              if (localObject86 != 0)
                                                break;
                                              localObject81 = localObject85;
                                              i18 = localObject42;
                                            case 0:
                                            case 1:
                                            case 2:
                                            case 3:
                                            }
                                          }
                                          localObject81 = localObject86;
                                          Object localObject123 = localObject85;
                                          localObject85 = localObject42;
                                          localObject43 = localObject123;
                                        }
                                        while (true)
                                        {
                                          if (localObject81 <= localObject85);
                                          localObject43 = new String(localObject43).intern();
                                          arrayOfString[i1] = localObject43;
                                          i1 = 19;
                                          localObject43 = "I%#\020\nIck".toCharArray();
                                          Object localObject82 = localObject43.length;
                                          label3608: Object localObject45;
                                          if (localObject82 <= l)
                                          {
                                            localObject85 = localObject1;
                                            localObject86 = localObject82;
                                            int i19 = localObject85;
                                            localObject83 = localObject43;
                                            Object localObject124 = localObject85;
                                            localObject85 = localObject43;
                                            Object localObject44;
                                            for (localObject43 = localObject124; ; localObject44 = localObject86)
                                            {
                                              i20 = localObject83[localObject43];
                                              i21 = i19 % 5;
                                              switch (i21)
                                              {
                                              default:
                                                i21 = 102;
                                                int i22 = (char)(i20 ^ i21);
                                                localObject83[localObject43] = i20;
                                                localObject44 = i19 + 1;
                                                if (localObject86 != 0)
                                                  break;
                                                localObject83 = localObject85;
                                                i19 = localObject44;
                                              case 0:
                                              case 1:
                                              case 2:
                                              case 3:
                                              }
                                            }
                                            localObject83 = localObject86;
                                            Object localObject125 = localObject85;
                                            localObject85 = localObject44;
                                            localObject45 = localObject125;
                                          }
                                          while (true)
                                          {
                                            if (localObject83 <= localObject85);
                                            String str = new String(localObject45).intern();
                                            arrayOfString[i1] = localObject45;
                                            g = arrayOfString;
                                            if (!ah.class.desiredAssertionStatus())
                                              int i23 = l;
                                            while (true)
                                            {
                                              boolean bool = a;
                                              return;
                                              int i24 = localObject1;
                                            }
                                            i20 = k;
                                            break label116:
                                            i20 = i;
                                            break label116:
                                            i20 = j;
                                            break label116:
                                            i20 = 114;
                                            break label116:
                                            i20 = k;
                                            break label296:
                                            i20 = i;
                                            break label296:
                                            i20 = j;
                                            break label296:
                                            i20 = 114;
                                            break label296:
                                            i21 = k;
                                            break label480:
                                            i21 = i;
                                            break label480:
                                            i21 = j;
                                            break label480:
                                            i21 = 114;
                                            break label480:
                                            i21 = k;
                                            break label664:
                                            i21 = i;
                                            break label664:
                                            i21 = j;
                                            break label664:
                                            i21 = 114;
                                            break label664:
                                            i21 = k;
                                            break label848:
                                            i21 = i;
                                            break label848:
                                            i21 = j;
                                            break label848:
                                            i21 = 114;
                                            break label848:
                                            i21 = k;
                                            break label1032:
                                            i21 = i;
                                            break label1032:
                                            i21 = j;
                                            break label1032:
                                            i21 = 114;
                                            break label1032:
                                            i21 = k;
                                            break label1216:
                                            i21 = i;
                                            break label1216:
                                            i21 = j;
                                            break label1216:
                                            i21 = 114;
                                            break label1216:
                                            i21 = k;
                                            break label1400:
                                            i21 = i;
                                            break label1400:
                                            i21 = j;
                                            break label1400:
                                            i21 = 114;
                                            break label1400:
                                            i21 = k;
                                            break label1584:
                                            i21 = i;
                                            break label1584:
                                            i21 = j;
                                            break label1584:
                                            i21 = 114;
                                            break label1584:
                                            i21 = k;
                                            break label1768:
                                            i21 = i;
                                            break label1768:
                                            i21 = j;
                                            break label1768:
                                            i21 = 114;
                                            break label1768:
                                            i21 = k;
                                            break label1952:
                                            i21 = i;
                                            break label1952:
                                            i21 = j;
                                            break label1952:
                                            i21 = 114;
                                            break label1952:
                                            i21 = k;
                                            break label2136:
                                            i21 = i;
                                            break label2136:
                                            i21 = j;
                                            break label2136:
                                            i21 = 114;
                                            break label2136:
                                            i21 = k;
                                            break label2320:
                                            i21 = i;
                                            break label2320:
                                            i21 = j;
                                            break label2320:
                                            i21 = 114;
                                            break label2320:
                                            i21 = k;
                                            break label2504:
                                            i21 = i;
                                            break label2504:
                                            i21 = j;
                                            break label2504:
                                            i21 = 114;
                                            break label2504:
                                            i21 = k;
                                            break label2688:
                                            i21 = i;
                                            break label2688:
                                            i21 = j;
                                            break label2688:
                                            i21 = 114;
                                            break label2688:
                                            i21 = k;
                                            break label2872:
                                            i21 = i;
                                            break label2872:
                                            i21 = j;
                                            break label2872:
                                            i21 = 114;
                                            break label2872:
                                            i21 = k;
                                            break label3056:
                                            i21 = i;
                                            break label3056:
                                            i21 = j;
                                            break label3056:
                                            i21 = 114;
                                            break label3056:
                                            i21 = k;
                                            break label3240:
                                            i21 = i;
                                            break label3240:
                                            i21 = j;
                                            break label3240:
                                            i21 = 114;
                                            break label3240:
                                            i21 = k;
                                            break label3424:
                                            i21 = i;
                                            break label3424:
                                            i21 = j;
                                            break label3424:
                                            i21 = 114;
                                            break label3424:
                                            i21 = k;
                                            break label3608:
                                            i21 = i;
                                            break label3608:
                                            i21 = j;
                                            break label3608:
                                            i21 = 114;
                                            break label3608:
                                            localObject85 = localObject1;
                                          }
                                          localObject85 = localObject1;
                                        }
                                        localObject85 = localObject1;
                                      }
                                      localObject85 = localObject1;
                                    }
                                    localObject85 = localObject1;
                                  }
                                  localObject85 = localObject1;
                                }
                                localObject85 = localObject1;
                              }
                              localObject85 = localObject1;
                            }
                            localObject85 = localObject1;
                          }
                          localObject85 = localObject1;
                        }
                        localObject85 = localObject1;
                      }
                      localObject85 = localObject1;
                    }
                    localObject85 = localObject1;
                  }
                  localObject85 = localObject1;
                }
                localObject85 = localObject1;
              }
              localObject85 = localObject1;
            }
            localObject85 = localObject1;
          }
          localObject85 = localObject1;
        }
        localObject83 = localObject1;
      }
      Object localObject83 = localObject1;
    }
  }

  ah()
  {
    ag localag = ag.b(ah.class);
    this.b = localag;
  }

  static int a(ah paramah)
  {
    int i = paramah.d - 1;
    paramah.d = i;
    return i;
  }

  private void a()
  {
    int i = i.c;
    int j = this.c;
    if (j > 0)
    {
      bool = d();
      if (i == 0)
        break label27;
    }
    boolean bool = c();
    if (!bool)
    {
      label27: b();
      if (i == 0)
        return;
    }
    ag localag = this.b;
    String str = g[10];
    localag.b(str);
  }

  private void b()
  {
    if (this.d > 0)
    {
      ag localag1 = this.b;
      String str1 = g[9];
      localag1.b(str1);
    }
    while (true)
    {
      return;
      at.a(new an(this), 1000L);
      int i = this.d;
      int j;
      ++j;
      this.d = i;
      ag localag2 = this.b;
      String str2 = g[8];
      localag2.b(str2);
    }
  }

  static void b(ah paramah)
  {
    paramah.a();
  }

  private boolean c()
  {
    Object localObject1 = 1;
    Object localObject2 = null;
    int i = i.c;
    if (!this.e)
    {
      localObject3 = this.b;
      String str1 = g[17];
      ((ag)localObject3).b(str1);
    }
    for (Object localObject3 = localObject1; ; localObject3 = localObject1)
    {
      label36: return localObject3;
      if (this.c <= 0)
        break;
      localObject3 = this.b;
      String str2 = g[14];
      ((ag)localObject3).b(str2);
    }
    switch (this.f.getWifiState())
    {
    default:
    case 3:
    case 2:
    case 1:
    case 0:
    }
    while (true)
    {
      localObject3 = localObject1;
      break label36:
      ag localag1 = this.b;
      String str3 = g[16];
      localag1.b(str3);
      this.e = localObject2;
      try
      {
        this.f.setWifiEnabled(null);
      }
      catch (Throwable localThrowable)
      {
        ag localag2 = this.b;
        String str4 = g[12];
        localag2.a(str4, localThrowable);
      }
      if (localObject3 == 0)
        continue;
      localObject3 = this.b;
      String str5 = g[13];
      ((ag)localObject3).b(str5);
      localObject3 = localObject2;
      break label36:
      ag localag3 = this.b;
      String str6 = g[15];
      localag3.b(str6);
      this.e = localObject2;
      if (localObject3 == 0)
        continue;
      localObject3 = this.b;
      String str7 = g[11];
      ((ag)localObject3).b(str7);
      this.e = localObject2;
    }
  }

  private boolean d()
  {
    Object localObject1 = null;
    Object localObject2 = 1;
    int i = i.c;
    Object localObject3;
    if (this.c < localObject2)
    {
      localObject3 = this.b;
      String str1 = g[4];
      ((ag)localObject3).b(str1);
      localObject3 = localObject2;
    }
    while (true)
    {
      label36: return localObject3;
      switch (this.f.getWifiState())
      {
      default:
      case 3:
      case 2:
      case 1:
        do
          while (true)
          {
            localObject3 = localObject2;
            break label36:
            ag localag1 = this.b;
            String str2 = g[6];
            localag1.b(str2);
            if (localObject3 == 0)
              continue;
            ag localag2 = this.b;
            String str3 = g[5];
            localag2.b(str3);
            if (localObject3 == 0)
              continue;
            ag localag3 = this.b;
            String str4 = g[2];
            localag3.b(str4);
            try
            {
              boolean bool = this.f.setWifiEnabled(true);
              this.e = bool;
            }
            catch (Throwable localThrowable)
            {
              ag localag4 = this.b;
              String str5 = g[3];
              localag4.a(str5, localThrowable);
              this.e = localObject1;
            }
          }
        while (localObject3 == 0);
      case 0:
      }
      localObject3 = this.b;
      String str6 = g[7];
      ((ag)localObject3).b(str6);
      this.e = localObject1;
      localObject3 = localObject1;
    }
  }

  /** @deprecated */
  public void a(WifiManager paramWifiManager)
  {
    monitorenter;
    try
    {
      ag localag1 = this.b;
      String str1 = g[19];
      localag1.b(str1);
      this.f = paramWifiManager;
      int i = this.c;
      int j = i + 1;
      this.c = j;
      if (i == 0)
      {
        a();
        if (i.c == 0)
          break label78;
      }
      ag localag2 = this.b;
      String str2 = g[18];
      localag2.b(str2);
      label78: monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  /** @deprecated */
  public void b(WifiManager paramWifiManager)
  {
    int i = 1;
    monitorenter;
    try
    {
      ag localag1 = this.b;
      String str1 = g[1];
      localag1.b(str1);
      this.f = paramWifiManager;
      a = localag1;
      if (localag1 == null)
        throw new AssertionError();
    }
    finally
    {
      monitorexit;
    }
    if (this.c > 0)
    {
      int j = this.c - i;
      this.c = j;
      if (j == 0)
      {
        b();
        if (i.c == 0)
          break label113;
      }
      ag localag2 = this.b;
      String str2 = g[null];
      localag2.b(str2);
    }
    label113: monitorexit;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ah
 * JD-Core Version:    0.5.4
 */