package com.a;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public abstract class v
{
  protected static final ag a;
  public static int b;
  private static v c;
  private static String d;
  private static final String[] e;

  static
  {
    String[] arrayOfString = new String[10];
    String str1 = a(c("`,z\003a#>qP5s?{Pzw4dAf"));
    arrayOfString[0] = str1;
    String str2 = a(c("w(lP:{ x"));
    arrayOfString[1] = str2;
    String str3 = a(c("q(gTzm>q\004vl#`A{wm`]efw4"));
    arrayOfString[2] = str3;
    String str4 = a(c("q(gTzm>q\004vl#`A{ww4"));
    arrayOfString[3] = str4;
    String str5 = a(c("q(gTzm>q\004vl)q\0365"));
    arrayOfString[4] = str5;
    String str6 = a(c("b/{Va+d4JzwmgQes\"fPpg"));
    arrayOfString[5] = str6;
    String str7 = a(c("s\"gP="));
    arrayOfString[6] = str7;
    String str8 = a(c("/\026"));
    arrayOfString[7] = str8;
    String str9 = a(c("B9`Axs94Pz#>qP5w%q\004ff?bAgV?x\004pr8uH5w\"4G`q?qJa-mGO|s=}Jr"));
    arrayOfString[8] = str9;
    String str10 = a(c("d(`\f"));
    arrayOfString[9] = str10;
    e = arrayOfString;
    a = ag.b(v.class);
    c = null;
    d = a(c("k9`Tf9b;EejcgOlk\"{Obj?qHpp>:GznbcTf1"));
  }

  private static String a(char[] paramArrayOfChar)
  {
    Object localObject1 = paramArrayOfChar.length;
    Object localObject3 = 0;
    char[] arrayOfChar3 = 1;
    Object localObject4;
    char[] arrayOfChar4;
    label34: char[] arrayOfChar6;
    if (localObject1 <= arrayOfChar3)
    {
      arrayOfChar3 = localObject3;
      localObject3 = localObject1;
      char[] arrayOfChar1 = paramArrayOfChar;
      Object localObject5 = localObject3;
      int i = arrayOfChar3;
      localObject4 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      int j = localObject4[arrayOfChar1];
      int k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
      char[] arrayOfChar2;
      for (k = 21; ; k = 36)
        while (true)
        {
          int l = (char)(j ^ k);
          localObject4[arrayOfChar1] = j;
          arrayOfChar2 = i + 1;
          if (localObject5 != 0)
            break label141;
          localObject4 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject5;
          break label34:
          k = 3;
          continue;
          k = 77;
          continue;
          k = 20;
        }
      label141: localObject4 = localObject5;
      arrayOfChar6 = arrayOfChar4;
      arrayOfChar4 = arrayOfChar2;
    }
    for (Object localObject2 = arrayOfChar6; ; localObject2 = paramArrayOfChar)
    {
      if (localObject4 <= arrayOfChar4);
      return new String(localObject2).intern();
      arrayOfChar4 = localObject4;
      localObject4 = localObject2;
    }
  }

  private void a(aa paramaa)
  {
    int i = 1024;
    Object localObject1 = 0;
    int j = b;
    boolean bool = a.a();
    if (!bool);
    Object localObject3;
    label203: int k;
    byte[] arrayOfByte;
    do
    {
      int i2;
      do
      {
        do
        {
          return;
          localObject3 = a;
          localObject4 = new StringBuilder();
          localObject5 = e;
          int i1 = 4;
          localObject5 = localObject5[i1];
          localObject4 = ((StringBuilder)localObject4).append((String)localObject5);
          localObject5 = paramaa.b();
          localObject4 = localObject5;
          ((ag)localObject3).b((String)localObject4);
          localObject3 = paramaa.e();
        }
        while (localObject3 == null);
        localObject4 = paramaa.d();
        localObject5 = a;
        Object localObject7 = new StringBuilder();
        String str1 = e[2];
        localObject7 = str1 + (String)localObject4;
        ((ag)localObject5).b((String)localObject7);
        localObject5 = e;
        i2 = 1;
        localObject5 = localObject5[i2];
        localObject4 = ((String)localObject4).startsWith((String)localObject5);
      }
      while (localObject4 == 0);
      Object localObject4 = new byte[i];
      Object localObject5 = ((InputStream)localObject3).markSupported();
      if (localObject5 != 0)
        break label445;
      localObject5 = localObject4;
      localObject4 = localObject1;
      int i3;
      do
      {
        i2 = localObject5.length - localObject4;
        i3 = ((InputStream)localObject3).read(localObject5, localObject4, i2);
        if (i3 <= 0)
          break label434;
        localObject4 += i3;
        i3 = localObject5.length;
      }
      while (i3 != k);
      arrayOfByte = new byte[localObject5.length * 2];
      int i4 = localObject5.length;
      System.arraycopy(localObject5, localObject1, arrayOfByte, localObject1, i4);
    }
    while (j != 0);
    label291: ByteArrayInputStream localByteArrayInputStream;
    Object localObject2;
    if (j != 0)
    {
      j = k;
      localObject3 = arrayOfByte;
      localByteArrayInputStream = new ByteArrayInputStream(localObject3, localObject1, j);
      paramaa.f = localByteArrayInputStream;
      localObject2 = localObject3;
      localObject3 = localByteArrayInputStream;
    }
    while (true)
    {
      Object localObject6;
      while (true)
      {
        ((InputStream)localObject3).mark(i);
        localByteArrayInputStream = null;
        int l = 1024;
        try
        {
          int i5 = ((InputStream)localObject3).read(localObject2, localByteArrayInputStream, l);
          ag localag = a;
          StringBuilder localStringBuilder1 = new StringBuilder();
          String str2 = e[3];
          StringBuilder localStringBuilder2 = localStringBuilder1.append(str2);
          String str3 = new String(localObject2, null, localByteArrayInputStream);
          String str4 = str3;
          l.b(localObject2);
          ((InputStream)localObject3).reset();
        }
        finally
        {
          ((InputStream)localObject3).reset();
        }
      }
      break label203:
      label434: localObject2 = localByteArrayInputStream;
      localObject3 = localObject6;
      break label291:
      label445: localObject2 = localByteArrayInputStream;
    }
  }

  /** @deprecated */
  public static v c()
  {
    synchronized (v.class)
    {
      Object localObject1 = c;
      if (localObject1 == null)
      {
        localObject1 = new q();
        return localObject1;
      }
      localObject1 = c.b();
    }
  }

  private static char[] c(String paramString)
  {
    char[] arrayOfChar1 = paramString.toCharArray();
    char[] arrayOfChar2 = arrayOfChar1;
    while (true)
    {
      int i = arrayOfChar1.length;
      if (i < 2)
      {
        if (i == 0)
          break label33;
        int j = (char)(arrayOfChar2[null] ^ 0x15);
        arrayOfChar2[0] = j;
      }
      return arrayOfChar2;
      label33: Object localObject = arrayOfChar2;
    }
  }

  /** @deprecated */
  public static String d()
  {
    synchronized (v.class)
    {
      String str = d;
      return str;
    }
  }

  /** @deprecated */
  public static boolean e()
  {
    synchronized (v.class)
    {
      Object localObject1 = d;
      if (localObject1 != null)
      {
        localObject1 = d.length();
        if (localObject1 != 0)
        {
          int i = 1;
          return i;
        }
      }
      Object localObject2 = null;
    }
  }

  protected abstract aa a(String paramString);

  protected abstract aa a(String paramString1, String paramString2);

  public void a()
  {
    String str = e[5];
    throw new UnsupportedOperationException(str);
  }

  public final aa b(String paramString)
  {
    if (a.a())
    {
      ag localag = a;
      StringBuilder localStringBuilder = new StringBuilder();
      String str1 = e[9];
      String str2 = str1 + paramString + ")";
      localag.b(str2);
    }
    aa localaa = a(paramString);
    a(localaa);
    return localaa;
  }

  public final aa b(String paramString1, String paramString2)
  {
    Object localObject = new StringBuilder();
    String str1 = d();
    localObject = str1 + paramString1;
    if (a.a())
    {
      ag localag = a;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str2 = e[6];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str2).append((String)localObject);
      String str3 = e[7];
      StringBuilder localStringBuilder3 = localStringBuilder2.append(str3);
      int i = paramString2.length();
      String str4 = i + "]" + paramString2 + ")";
      localag.b(str4);
    }
    aa localaa = a((String)localObject, paramString2);
    a((aa)localObject);
    return (aa)localObject;
  }

  protected abstract v b();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.v
 * JD-Core Version:    0.5.4
 */