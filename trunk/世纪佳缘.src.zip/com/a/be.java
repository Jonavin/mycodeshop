package com.a;

final class be extends ag
{
  be()
  {
    super(null);
  }

  protected ag a(Class paramClass)
  {
    return this;
  }

  protected void a(ba paramba, String paramString)
  {
  }

  public boolean a(ba paramba)
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.be
 * JD-Core Version:    0.5.4
 */