package com.a;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

final class ap extends ag
{
  private static FileWriter c;
  private static final String[] d;

  static
  {
    int i = 39;
    int j = 38;
    int k = 22;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "F\f\003bKN\030\0262R\007\035\002'\002\027i\t3\027GIk6".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "LNCuG\021Y\baV\020QHq\b\027ES".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str1 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        d = arrayOfString;
        try
        {
          String str2 = d[1];
          c = new FileWriter(str2, true);
          label405: return;
        }
        catch (Exception localException)
        {
          c = null;
          break label405:
          i3 = 99;
        }
        break label115:
        i3 = 61;
        break label115:
        i3 = i;
        break label115:
        i3 = k;
        break label115:
        i3 = 99;
        break label295:
        i3 = 61;
        break label295:
        i3 = i;
        break label295:
        i3 = k;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  public ap(Class paramClass)
  {
    super(paramClass);
  }

  protected ag a(Class paramClass)
  {
    return new ap(paramClass);
  }

  protected void a(ba paramba, String paramString)
  {
    try
    {
      synchronized (ap.class)
      {
        FileWriter localFileWriter = c;
        if (localFileWriter != null)
        {
          localFileWriter = c;
          String str1 = d[null];
          Object[] arrayOfObject = new Object[1];
          long l = System.currentTimeMillis();
          Object localObject2;
          Date localDate = new Date(localObject2);
          arrayOfObject[0] = localDate;
          String str2 = String.format(str1, arrayOfObject);
          localFileWriter.write(str2);
          c.write(paramString);
          c.write("\n");
          localFileWriter = c;
          localFileWriter.flush();
        }
        return;
      }
    }
    catch (IOException i)
    {
      int i = 0;
      c = i;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ap
 * JD-Core Version:    0.5.4
 */