package com.a;

public class bd extends Exception
{
  public bd(String paramString)
  {
    super(paramString);
  }

  public bd(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bd
 * JD-Core Version:    0.5.4
 */