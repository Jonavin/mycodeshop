package com.a;

public class bc extends Exception
{
  public bc(String paramString)
  {
    super(paramString);
  }

  public bc(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bc
 * JD-Core Version:    0.5.4
 */