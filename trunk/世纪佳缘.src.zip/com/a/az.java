package com.a;

public enum az
{
  private static final az[] d;
  private static final String[] e;

  static
  {
    int i = 48;
    int j = 24;
    int k = 2;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[3];
    char[] arrayOfChar1 = "M\024\031~8O\024".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject15;
    int i1;
    Object localObject9;
    Object localObject14;
    int i2;
    int i3;
    label116: Object localObject3;
    if (localObject8 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject15 = localObject8;
      i1 = arrayOfChar2;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject14 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject15)
      {
        i2 = localObject9[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 119;
          i2 = (char)(i2 ^ i3);
          localObject9[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject15 != 0)
            break;
          localObject9 = localObject14;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject15;
      Object localObject16 = localObject14;
      localObject14 = localObject2;
      localObject3 = localObject16;
    }
    while (true)
    {
      if (localObject9 <= localObject14);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "]\002\006u%V\033\036".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label296: Object localObject5;
      if (localObject10 <= l)
      {
        localObject14 = localObject1;
        localObject15 = localObject10;
        i1 = localObject14;
        localObject11 = localObject3;
        Object localObject17 = localObject14;
        localObject14 = localObject3;
        Object localObject4;
        for (localObject3 = localObject17; ; localObject4 = localObject15)
        {
          i2 = localObject11[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 119;
            i2 = (char)(i2 ^ i3);
            localObject11[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject15 != 0)
              break;
            localObject11 = localObject14;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject15;
        Object localObject18 = localObject14;
        localObject14 = localObject4;
        localObject5 = localObject18;
      }
      while (true)
      {
        if (localObject11 <= localObject14);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        localObject5 = "Z\033\006d2J\003".toCharArray();
        Object localObject12 = localObject5.length;
        Object localObject13;
        label476: Object localObject7;
        if (localObject12 <= l)
        {
          localObject14 = localObject1;
          localObject15 = localObject12;
          i1 = localObject14;
          localObject13 = localObject5;
          Object localObject19 = localObject14;
          localObject14 = localObject5;
          Object localObject6;
          for (localObject5 = localObject19; ; localObject6 = localObject15)
          {
            i2 = localObject13[localObject5];
            i3 = i1 % 5;
            switch (i3)
            {
            default:
              i3 = 119;
              int i4 = (char)(i2 ^ i3);
              localObject13[localObject5] = i2;
              localObject6 = i1 + 1;
              if (localObject15 != 0)
                break;
              localObject13 = localObject14;
              i1 = localObject6;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject13 = localObject15;
          Object localObject20 = localObject14;
          localObject14 = localObject6;
          localObject7 = localObject20;
        }
        while (true)
        {
          if (localObject13 <= localObject14);
          String str1 = new String(localObject7).intern();
          arrayOfString[k] = localObject7;
          e = arrayOfString;
          String str2 = e[l];
          a = new az(localObject7, localObject1);
          String str3 = e[k];
          b = new az(localObject7, l);
          String str4 = e[localObject1];
          c = new az(localObject7, k);
          az[] arrayOfaz = new az[3];
          az localaz1 = a;
          arrayOfString[localObject1] = localObject7;
          az localaz2 = b;
          arrayOfString[l] = localObject7;
          az localaz3 = c;
          arrayOfString[k] = localObject7;
          d = arrayOfString;
          return;
          i3 = j;
          break label116:
          i3 = 90;
          break label116:
          i3 = 82;
          break label116:
          i3 = i;
          break label116:
          i3 = j;
          break label296:
          i3 = 90;
          break label296:
          i3 = 82;
          break label296:
          i3 = i;
          break label296:
          i3 = j;
          break label476:
          i3 = 90;
          break label476:
          i3 = 82;
          break label476:
          i3 = i;
          break label476:
          localObject14 = localObject1;
        }
        localObject14 = localObject1;
      }
      localObject14 = localObject1;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.az
 * JD-Core Version:    0.5.4
 */