package com.a;

public final class ad
  implements af, aw, Comparable
{
  public static boolean b;
  private static final String i;
  private final ax d;
  private final int e;
  private final int g;
  private final h h;

  static
  {
    char[] arrayOfChar1 = 0;
    int j = 1;
    char[] arrayOfChar2 = "u\020>\bna\027kGg4\001$]op\020q\b".toCharArray();
    Object localObject2 = arrayOfChar2.length;
    Object localObject3;
    char[] arrayOfChar5;
    int i1;
    label87: Object localObject1;
    if (localObject2 <= j)
    {
      char[] arrayOfChar4 = arrayOfChar1;
      Object localObject4 = localObject2;
      int k = arrayOfChar4;
      localObject3 = arrayOfChar2;
      char[] arrayOfChar6 = arrayOfChar4;
      arrayOfChar5 = arrayOfChar2;
      char[] arrayOfChar3;
      for (arrayOfChar2 = arrayOfChar6; ; arrayOfChar3 = localObject4)
      {
        int l = localObject3[arrayOfChar2];
        i1 = k % 5;
        switch (i1)
        {
        default:
          i1 = j;
          int i2 = (char)(l ^ i1);
          localObject3[arrayOfChar2] = l;
          arrayOfChar3 = k + 1;
          if (localObject4 != 0)
            break;
          localObject3 = arrayOfChar5;
          k = arrayOfChar3;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject3 = localObject4;
      char[] arrayOfChar7 = arrayOfChar5;
      arrayOfChar5 = arrayOfChar3;
      localObject1 = arrayOfChar7;
    }
    while (true)
    {
      if (localObject3 <= arrayOfChar5);
      i = new String(localObject1).intern();
      if (!ad.class.desiredAssertionStatus())
        int i3 = j;
      while (true)
      {
        boolean bool = a;
        return;
        int i4 = arrayOfChar1;
      }
      i1 = 20;
      break label87:
      i1 = 99;
      break label87:
      i1 = 75;
      break label87:
      i1 = 40;
      break label87:
      arrayOfChar5 = arrayOfChar1;
    }
  }

  public ad(ax paramax, int paramInt1, int paramInt2, h paramh)
  {
    this.d = paramax;
    this.e = paramInt1;
    this.g = paramInt2;
    this.h = paramh;
  }

  static boolean a(int paramInt)
  {
    if (paramInt >= 0)
    {
      int j = 31;
      if (paramInt <= j)
        break label24;
      int k = 99;
      if (paramInt == k)
        break label24;
    }
    int l = 1;
    while (true)
    {
      return l;
      label24: Object localObject = null;
    }
  }

  static int b(int paramInt)
  {
    int j;
    a = j;
    if (j == 0)
    {
      bool = a(paramInt);
      if (bool)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        String str1 = i;
        String str2 = str1 + paramInt;
        throw new AssertionError(str2);
      }
    }
    boolean bool = a(paramInt);
    if (bool);
    for (int k = 65423; ; k -= 113)
    {
      return k;
      k = paramInt * 2;
    }
  }

  public int a(ad paramad)
  {
    int j;
    if (paramad == null)
      j = 1;
    while (true)
    {
      return j;
      Object localObject = this.d;
      ax localax = paramad.d;
      localObject = ((ax)localObject).a(localax);
      if (localObject != 0)
        continue;
      localObject = this.h;
      h localh = paramad.h;
      localObject = ((h)localObject).c(localh);
      if (localObject != 0)
        continue;
      int k = this.g;
      int l = paramad.g;
      k -= l;
      if (k != 0)
        continue;
      k = this.e;
      int i1 = paramad.e;
      k -= i1;
    }
  }

  public ax a()
  {
    return this.d;
  }

  public int b()
  {
    return this.e;
  }

  public int c()
  {
    return this.g;
  }

  public h e()
  {
    return this.h;
  }

  public boolean equals(Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    if (paramObject == null)
      localObject2 = localObject1;
    while (true)
    {
      return localObject2;
      try
      {
        paramObject = (ad)paramObject;
        localObject2 = this.d;
        ax localax = paramObject.d;
        localObject2 = ((ax)localObject2).equals(localax);
        if (localObject2 != 0)
        {
          int j = this.e;
          int l = paramObject.e;
          if (j == l)
          {
            j = this.g;
            int i1 = paramObject.g;
            if (j == i1)
            {
              Object localObject3 = this.h;
              h localh = paramObject.h;
              localObject3 = ((h)localObject3).equals(localh);
              if (localObject3 != 0)
                int k = 1;
            }
          }
        }
        Object localObject4 = localObject1;
      }
      catch (ClassCastException localObject5)
      {
        Object localObject5 = localObject1;
      }
    }
  }

  public int hashCode()
  {
    int j = this.d.hashCode();
    int k = this.g;
    return j ^ k;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("[");
    String str = this.d.toString();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str).append(",");
    int j = this.g;
    return j + "]";
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ad
 * JD-Core Version:    0.5.4
 */