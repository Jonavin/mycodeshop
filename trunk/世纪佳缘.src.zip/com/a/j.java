package com.a;

import android.content.Context;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.util.ArrayList;
import java.util.List;

final class j extends o
{
  private static final String[] i;
  private final SensorEventListener c;
  private final ag e;
  private final Context f;
  private SensorManager g;
  private List h;

  static
  {
    int j = 30;
    int k = 5;
    int l = 1;
    Object localObject1 = 0;
    int i1 = 120;
    String[] arrayOfString = new String[6];
    char[] arrayOfChar1 = "@\024\027mlM\037XaB\b\f{w".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject28;
    Object localObject30;
    Object localObject9;
    Object localObject21;
    int i3;
    int i7;
    label115: Object localObject3;
    if (localObject8 <= l)
    {
      Object localObject20 = localObject1;
      localObject28 = localObject8;
      localObject30 = localObject20;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar3 = localObject20;
      localObject21 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject28)
      {
        i3 = localObject9[arrayOfChar1];
        i7 = localObject30 % 5;
        switch (i7)
        {
        default:
          i7 = k;
          i3 = (char)(i3 ^ i7);
          localObject9[arrayOfChar1] = i3;
          localObject2 = localObject30 + 1;
          if (localObject28 != 0)
            break;
          localObject9 = localObject21;
          localObject30 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject28;
      Object localObject31 = localObject21;
      localObject21 = localObject2;
      localObject3 = localObject31;
    }
    while (true)
    {
      if (localObject9 <= localObject21);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "B\026\034ljJ\0346qJ\016\035$D@\033\035r`Q\027\025{qF\n9zdS\f\035lLN\b\024".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label291: Object localObject5;
      if (localObject10 <= l)
      {
        localObject21 = localObject1;
        localObject28 = localObject10;
        localObject30 = localObject21;
        localObject11 = localObject3;
        Object localObject32 = localObject21;
        localObject21 = localObject3;
        Object localObject4;
        for (localObject3 = localObject32; ; localObject4 = localObject28)
        {
          i3 = localObject11[localObject3];
          i7 = localObject30 % 5;
          switch (i7)
          {
          default:
            i7 = k;
            i3 = (char)(i3 ^ i7);
            localObject11[localObject3] = i3;
            localObject4 = localObject30 + 1;
            if (localObject28 != 0)
              break;
            localObject11 = localObject21;
            localObject30 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject28;
        Object localObject33 = localObject21;
        localObject21 = localObject4;
        localObject5 = localObject33;
      }
      while (true)
      {
        if (localObject11 <= localObject21);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i2 = 2;
        localObject11 = "M\027Xf@\035\024{wL\025\035j`QX\021p%W\020\035>iJ\013\f>jEX\013{kP\027\nm".toCharArray();
        Object localObject22 = localObject11.length;
        Object localObject23;
        Object localObject29;
        int i8;
        label471: Object localObject13;
        if (localObject22 <= l)
        {
          localObject28 = localObject1;
          localObject30 = localObject22;
          i3 = localObject28;
          localObject23 = localObject11;
          Object localObject34 = localObject28;
          localObject29 = localObject11;
          Object localObject12;
          for (localObject11 = localObject34; ; localObject12 = localObject30)
          {
            i7 = localObject23[localObject11];
            i8 = i3 % 5;
            switch (i8)
            {
            default:
              i8 = k;
              i7 = (char)(i7 ^ i8);
              localObject23[localObject11] = i7;
              localObject12 = i3 + 1;
              if (localObject30 != 0)
                break;
              localObject23 = localObject29;
              i3 = localObject12;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject23 = localObject30;
          Object localObject35 = localObject29;
          localObject29 = localObject12;
          localObject13 = localObject35;
        }
        while (true)
        {
          if (localObject23 <= localObject29);
          localObject13 = new String(localObject13).intern();
          arrayOfString[i2] = localObject13;
          i2 = 3;
          localObject13 = "@\027\rra\003\026\027j%D\035\f>d@\033\035r`Q\027\025{qF\nXsdM\031\037{w\003\013\035lsJ\033\035".toCharArray();
          Object localObject24 = localObject13.length;
          Object localObject25;
          label651: Object localObject15;
          if (localObject24 <= l)
          {
            localObject29 = localObject1;
            localObject30 = localObject24;
            int i4 = localObject29;
            localObject25 = localObject13;
            Object localObject36 = localObject29;
            localObject29 = localObject13;
            Object localObject14;
            for (localObject13 = localObject36; ; localObject14 = localObject30)
            {
              i7 = localObject25[localObject13];
              i8 = i4 % 5;
              switch (i8)
              {
              default:
                i8 = k;
                i7 = (char)(i7 ^ i8);
                localObject25[localObject13] = i7;
                localObject14 = i4 + 1;
                if (localObject30 != 0)
                  break;
                localObject25 = localObject29;
                i4 = localObject14;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject25 = localObject30;
            Object localObject37 = localObject29;
            localObject29 = localObject14;
            localObject15 = localObject37;
          }
          while (true)
          {
            if (localObject25 <= localObject29);
            localObject15 = new String(localObject15).intern();
            arrayOfString[i2] = localObject15;
            i2 = 4;
            localObject15 = "B\033\033{iF\n\027s`W\035\n>dG\031\bj`QX\031rwF\031\034g%L\b\035p".toCharArray();
            Object localObject26 = localObject15.length;
            label831: Object localObject17;
            if (localObject26 <= l)
            {
              localObject29 = localObject1;
              localObject30 = localObject26;
              int i5 = localObject29;
              localObject27 = localObject15;
              Object localObject38 = localObject29;
              localObject29 = localObject15;
              Object localObject16;
              for (localObject15 = localObject38; ; localObject16 = localObject30)
              {
                i7 = localObject27[localObject15];
                i8 = i5 % 5;
                switch (i8)
                {
                default:
                  i8 = k;
                  i7 = (char)(i7 ^ i8);
                  localObject27[localObject15] = i7;
                  localObject16 = i5 + 1;
                  if (localObject30 != 0)
                    break;
                  localObject27 = localObject29;
                  i5 = localObject16;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject27 = localObject30;
              Object localObject39 = localObject29;
              localObject29 = localObject16;
              localObject17 = localObject39;
            }
            while (true)
            {
              if (localObject27 <= localObject29);
              localObject27 = new String(localObject17);
              localObject17 = ((String)localObject27).intern();
              arrayOfString[i2] = localObject17;
              char[] arrayOfChar2 = "V\026\031|iFX\fq%Q\035\037wvW\035\n>d@\033\035r`Q\027\025{qF\nXrlP\f\035p`Q".toCharArray();
              Object localObject18 = arrayOfChar2.length;
              Object localObject19;
              label1015: Object localObject7;
              if (localObject18 <= l)
              {
                localObject27 = localObject1;
                localObject29 = localObject18;
                localObject30 = localObject27;
                localObject19 = arrayOfChar2;
                char[] arrayOfChar4 = localObject27;
                localObject27 = arrayOfChar2;
                Object localObject6;
                for (arrayOfChar2 = arrayOfChar4; ; localObject6 = localObject29)
                {
                  int i6 = localObject19[arrayOfChar2];
                  i7 = localObject30 % 5;
                  switch (i7)
                  {
                  default:
                    i7 = k;
                    int i9 = (char)(i6 ^ i7);
                    localObject19[arrayOfChar2] = i6;
                    localObject6 = localObject30 + 1;
                    if (localObject29 != 0)
                      break;
                    localObject19 = localObject27;
                    localObject30 = localObject6;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject19 = localObject29;
                Object localObject40 = localObject27;
                localObject27 = localObject6;
                localObject7 = localObject40;
              }
              while (true)
              {
                if (localObject19 <= localObject27);
                String str = new String(localObject7).intern();
                arrayOfString[k] = localObject7;
                i = arrayOfString;
                return;
                i7 = 35;
                break label115:
                i7 = i1;
                break label115:
                i7 = i1;
                break label115:
                i7 = j;
                break label115:
                i7 = 35;
                break label291:
                i7 = i1;
                break label291:
                i7 = i1;
                break label291:
                i7 = j;
                break label291:
                i8 = 35;
                break label471:
                i8 = i1;
                break label471:
                i8 = i1;
                break label471:
                i8 = j;
                break label471:
                i8 = 35;
                break label651:
                i8 = i1;
                break label651:
                i8 = i1;
                break label651:
                i8 = j;
                break label651:
                i8 = 35;
                break label831:
                i8 = i1;
                break label831:
                i8 = i1;
                break label831:
                i8 = j;
                break label831:
                i7 = 35;
                break label1015:
                i7 = i1;
                break label1015:
                i7 = i1;
                break label1015:
                i7 = j;
                break label1015:
                localObject27 = localObject1;
              }
              localObject29 = localObject1;
            }
            localObject29 = localObject1;
          }
          localObject29 = localObject1;
        }
        localObject27 = localObject1;
      }
      Object localObject27 = localObject1;
    }
  }

  public j(av paramav)
  {
    k localk = new k(this);
    this.c = localk;
    this.g = null;
    ag localag = ag.b(j.class);
    this.e = localag;
    Context localContext = ((aq)paramav).a();
    this.f = localContext;
    ArrayList localArrayList = new ArrayList();
    this.h = localArrayList;
  }

  static Context a(j paramj)
  {
    return paramj.f;
  }

  static boolean b(j paramj)
  {
    return paramj.f();
  }

  static ag c(j paramj)
  {
    return paramj.e;
  }

  static List d(j paramj)
  {
    return paramj.h;
  }

  static void e(j paramj)
  {
    paramj.a();
  }

  private boolean f()
  {
    SensorManager localSensorManager = this.g;
    int j;
    if (localSensorManager != null)
      j = 1;
    while (true)
    {
      return j;
      Object localObject = null;
    }
  }

  protected o a(av paramav)
  {
    return new j(paramav);
  }

  /** @deprecated */
  // ERROR //
  public void b()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 84	com/a/j:f	()Z
    //   6: astore_1
    //   7: iload_1
    //   8: ifeq +22 -> 30
    //   11: aload_0
    //   12: getfield 66	com/a/j:e	Lcom/a/ag;
    //   15: astore_2
    //   16: getstatic 46	com/a/j:i	[Ljava/lang/String;
    //   19: iconst_4
    //   20: aaload
    //   21: astore_3
    //   22: aload_2
    //   23: aload_3
    //   24: invokevirtual 97	com/a/ag:b	(Ljava/lang/String;)V
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: new 99	com/a/l
    //   33: dup
    //   34: aload_0
    //   35: invokespecial 100	com/a/l:<init>	(Lcom/a/j;)V
    //   38: invokestatic 105	com/a/at:a	(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    //   41: astore_1
    //   42: ldc2_w 106
    //   45: lstore 4
    //   47: getstatic 113	java/util/concurrent/TimeUnit:SECONDS	Ljava/util/concurrent/TimeUnit;
    //   50: astore 6
    //   52: aload_1
    //   53: lload 4
    //   55: aload 6
    //   57: invokeinterface 119 4 0
    //   62: checkcast 121	android/hardware/SensorManager
    //   65: astore_1
    //   66: aload_1
    //   67: ifnonnull +46 -> 113
    //   70: getstatic 46	com/a/j:i	[Ljava/lang/String;
    //   73: iconst_3
    //   74: aaload
    //   75: astore 7
    //   77: new 123	com/a/bb
    //   80: dup
    //   81: aload 7
    //   83: invokespecial 125	com/a/bb:<init>	(Ljava/lang/String;)V
    //   86: athrow
    //   87: astore 8
    //   89: aload_0
    //   90: monitorexit
    //   91: aload 8
    //   93: athrow
    //   94: astore_1
    //   95: getstatic 46	com/a/j:i	[Ljava/lang/String;
    //   98: iconst_3
    //   99: aaload
    //   100: astore 9
    //   102: new 123	com/a/bb
    //   105: dup
    //   106: aload 9
    //   108: aload_1
    //   109: invokespecial 128	com/a/bb:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   112: athrow
    //   113: aload_1
    //   114: iconst_1
    //   115: invokevirtual 132	android/hardware/SensorManager:getSensorList	(I)Ljava/util/List;
    //   118: astore 10
    //   120: aload 10
    //   122: invokeinterface 137 1 0
    //   127: ifeq +20 -> 147
    //   130: getstatic 46	com/a/j:i	[Ljava/lang/String;
    //   133: iconst_2
    //   134: aaload
    //   135: astore 11
    //   137: new 123	com/a/bb
    //   140: dup
    //   141: aload 11
    //   143: invokespecial 125	com/a/bb:<init>	(Ljava/lang/String;)V
    //   146: athrow
    //   147: aload_0
    //   148: getfield 56	com/a/j:c	Landroid/hardware/SensorEventListener;
    //   151: astore 12
    //   153: aload 10
    //   155: iconst_0
    //   156: invokeinterface 140 2 0
    //   161: checkcast 142	android/hardware/Sensor
    //   164: astore 13
    //   166: aload_1
    //   167: aload 12
    //   169: aload 10
    //   171: iconst_2
    //   172: invokevirtual 146	android/hardware/SensorManager:registerListener	(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   175: ifne +20 -> 195
    //   178: getstatic 46	com/a/j:i	[Ljava/lang/String;
    //   181: iconst_5
    //   182: aaload
    //   183: astore 14
    //   185: new 123	com/a/bb
    //   188: dup
    //   189: aload 14
    //   191: invokespecial 125	com/a/bb:<init>	(Ljava/lang/String;)V
    //   194: athrow
    //   195: aload_0
    //   196: aload_1
    //   197: putfield 58	com/a/j:g	Landroid/hardware/SensorManager;
    //   200: goto -173 -> 27
    //
    // Exception table:
    //   from	to	target	type
    //   2	27	87	finally
    //   30	66	87	finally
    //   70	87	87	finally
    //   95	200	87	finally
    //   30	66	94	java/lang/Throwable
  }

  /** @deprecated */
  public void c()
  {
    monitorenter;
    try
    {
      boolean bool = f();
      if (!bool)
        return;
      ag localag = this.e;
      String str = i[null];
      localag.b(str);
      SensorManager localSensorManager = this.g;
      SensorEventListener localSensorEventListener = this.c;
      localSensorManager.unregisterListener(localSensorEventListener);
      this.g = null;
    }
    finally
    {
      monitorexit;
    }
  }

  /** @deprecated */
  public List d()
  {
    monitorenter;
    try
    {
      List localList = this.h;
      ArrayList localArrayList = new ArrayList(localList);
      this.h.clear();
      monitorexit;
      return localArrayList;
    }
    finally
    {
      localObject = finally;
      monitorexit;
      throw localObject;
    }
  }

  public String e()
  {
    return i[1];
  }

  public String toString()
  {
    return e();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.j
 * JD-Core Version:    0.5.4
 */