package com.a;

import java.util.Iterator;
import java.util.NoSuchElementException;

public final class bi
  implements Iterator
{
  final bg a;
  private final Iterator b;
  private final bu c;
  private Object d;
  private boolean e;

  public bi(bg parambg, Iterator paramIterator, bu parambu)
  {
    this.b = paramIterator;
    this.c = parambu;
    this.e = null;
  }

  public boolean hasNext()
  {
    int i = c.b;
    Object localObject1;
    do
    {
      boolean bool2 = this.e;
      if (bool2)
        break label79;
      boolean bool3 = this.b.hasNext();
      if (!bool3)
        break label79;
      localObject1 = this.b.next();
      this.d = localObject1;
      localObject1 = this.c;
      Object localObject2 = this.d;
      localObject1 = ((bu)localObject1).a(localObject2);
    }
    while (localObject1 == 0);
    int j = 1;
    this.e = j;
    if (i == 0);
    label79: boolean bool1;
    for (i = j; ; bool1 = j)
      while (true)
      {
        return i;
        bool1 = this.e;
      }
  }

  public Object next()
  {
    if (!hasNext())
      throw new NoSuchElementException();
    Object localObject = this.d;
    this.d = null;
    this.e = null;
    return localObject;
  }

  public void remove()
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bi
 * JD-Core Version:    0.5.4
 */