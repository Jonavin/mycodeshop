package com.a;

import java.io.PrintStream;

public class bl extends ag
{
  public bl(Class paramClass)
  {
    super(paramClass);
  }

  protected ag a(Class paramClass)
  {
    return new bl(paramClass);
  }

  protected void a(ba paramba, String paramString)
  {
    System.out.println(paramString);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bl
 * JD-Core Version:    0.5.4
 */