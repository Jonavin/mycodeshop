package com.a;

import java.util.ArrayList;

final class g extends i
{
  private static final String[] a;

  static
  {
    int i = 84;
    int j = 11;
    int k = 9;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "G-\030G\b^1\022B\bH<\025[\003L*".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = 87;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "j\031:,#)\027$n9)6\001G\033V/\035M\036V9\020J\007]=\006".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = 87;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        a = arrayOfString;
        return;
        i3 = k;
        break label116:
        i3 = 120;
        break label116:
        i3 = i;
        break label116:
        i3 = j;
        break label116:
        i3 = k;
        break label296:
        i3 = 120;
        break label296:
        i3 = i;
        break label296:
        i3 = j;
        break label296:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  protected i a(av paramav)
  {
    return this;
  }

  public void a(long paramLong)
  {
    String str = a[1];
    throw new bd(str);
  }

  public void a(ArrayList paramArrayList)
  {
  }

  public boolean b()
  {
    return null;
  }

  public void c()
  {
  }

  public String d()
  {
    return null;
  }

  public boolean e()
  {
    return null;
  }

  public boolean f()
  {
    return null;
  }

  public boolean g()
  {
    return null;
  }

  public String h()
  {
    return a[null];
  }

  public boolean i()
  {
    return null;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.g
 * JD-Core Version:    0.5.4
 */