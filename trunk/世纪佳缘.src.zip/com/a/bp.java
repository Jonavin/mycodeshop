package com.a;

class bp
{
  static final int[] a;
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bp
 * JD-Core Version:    0.5.4
 */