package com.a;

import java.util.AbstractList;

public final class t extends AbstractList
{
  private static final String[] d;
  private int a;
  private int b;
  private final Object[] c;

  static
  {
    int i = 50;
    int j = 43;
    int k = 10;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[2];
    char[] arrayOfChar1 = "\0228P~\013[8\037Q\033\036".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject11;
    int i1;
    Object localObject7;
    Object localObject10;
    int i2;
    int i3;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      char[] arrayOfChar2 = localObject1;
      localObject11 = localObject6;
      i1 = arrayOfChar2;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar3 = arrayOfChar2;
      localObject10 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject11)
      {
        i2 = localObject7[arrayOfChar1];
        i3 = i1 % 5;
        switch (i3)
        {
        default:
          i3 = j;
          i2 = (char)(i2 ^ i3);
          localObject7[arrayOfChar1] = i2;
          localObject2 = i1 + 1;
          if (localObject11 != 0)
            break;
          localObject7 = localObject10;
          i1 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject11;
      Object localObject12 = localObject10;
      localObject10 = localObject2;
      localObject3 = localObject12;
    }
    while (true)
    {
      if (localObject7 <= localObject10);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "\022h\002*".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject10 = localObject1;
        localObject11 = localObject8;
        i1 = localObject10;
        localObject9 = localObject3;
        Object localObject13 = localObject10;
        localObject10 = localObject3;
        Object localObject4;
        for (localObject3 = localObject13; ; localObject4 = localObject11)
        {
          i2 = localObject9[localObject3];
          i3 = i1 % 5;
          switch (i3)
          {
          default:
            i3 = j;
            int i4 = (char)(i2 ^ i3);
            localObject9[localObject3] = i2;
            localObject4 = i1 + 1;
            if (localObject11 != 0)
              break;
            localObject9 = localObject10;
            i1 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject11;
        Object localObject14 = localObject10;
        localObject10 = localObject4;
        localObject5 = localObject14;
      }
      while (true)
      {
        if (localObject9 <= localObject10);
        String str = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        d = arrayOfString;
        return;
        i3 = i;
        break label115:
        i3 = 86;
        break label115:
        i3 = 63;
        break label115:
        i3 = k;
        break label115:
        i3 = i;
        break label295:
        i3 = 86;
        break label295:
        i3 = 63;
        break label295:
        i3 = k;
        break label295:
        localObject10 = localObject1;
      }
      localObject10 = localObject1;
    }
  }

  public t(int paramInt)
  {
    Object[] arrayOfObject = new Object[paramInt];
    this.c = arrayOfObject;
    this.a = null;
    int i = this.c.length;
    this.b = i;
  }

  public boolean add(Object paramObject)
  {
    int i = 1;
    int j = this.b - i;
    this.b = j;
    if (j < 0)
    {
      int k = this.c.length - i;
      this.b = k;
    }
    Object[] arrayOfObject = this.c;
    int l = this.b;
    arrayOfObject[l] = paramObject;
    int i1 = this.a;
    int i2 = this.c.length;
    if (i1 < i2)
    {
      int i3 = this.a;
      int i4;
      ++i4;
      this.a = i3;
    }
    return i;
  }

  public void clear()
  {
    int i = 0;
    int j = c.b;
    int k = i;
    do
    {
      int l = this.c.length;
      if (k >= l)
        break;
      this.c[k] = null;
      ++k;
      if (j != 0)
        return;
    }
    while (j == 0);
    this.a = i;
    int i1 = this.c.length;
    this.b = i1;
  }

  public boolean equals(Object paramObject)
  {
    ClassCastException localClassCastException1 = 0;
    int i = c.b;
    if (paramObject == null);
    Object localObject1;
    label116: for (i = localClassCastException1; ; localClassCastException2 = localObject1)
      while (true)
      {
        return i;
        try
        {
          paramObject = (t)paramObject;
          int j = this.a;
          int k = paramObject.a;
          if (j != k)
            i = localClassCastException1;
          j = localClassCastException1;
          do
          {
            k = this.a;
            if (j >= k)
              break;
            localObject1 = get(j);
            Object localObject2 = paramObject.get(j);
            localObject1 = localObject1.equals(localObject2);
            if (i != 0)
              break label116;
            if (localObject1 == 0)
              i = localClassCastException1;
            ++j;
          }
          while (i == 0);
          i = 1;
        }
        catch (ClassCastException localClassCastException2)
        {
          localClassCastException2 = localClassCastException1;
        }
      }
  }

  public Object get(int paramInt)
  {
    int i = this.a;
    if ((paramInt >= i) || (paramInt < 0))
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append(paramInt);
      String str1 = d[1];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      int j = this.a;
      String str2 = j;
      throw new IndexOutOfBoundsException(str2);
    }
    Object[] arrayOfObject = this.c;
    int k = this.b + paramInt;
    int l = this.c.length;
    int i1 = k % l;
    return arrayOfObject[i1];
  }

  public int hashCode()
  {
    int i = this.a;
    if (i <= 0);
    int j;
    for (Object localObject = null; ; localObject = localObject[j].hashCode())
    {
      return localObject;
      localObject = this.c;
      j = this.b;
    }
  }

  public Object set(int paramInt, Object paramObject)
  {
    int i = this.a;
    if ((paramInt > i) || (paramInt < 0))
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append(paramInt);
      String str1 = d[null];
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      int j = this.a;
      String str2 = j + "]";
      throw new IndexOutOfBoundsException(str2);
    }
    int k = this.b + paramInt;
    int l = this.c.length;
    int i1 = k % l;
    Object localObject = this.c[i1];
    this.c[i1] = paramObject;
    return localObject;
  }

  public int size()
  {
    return this.a;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.t
 * JD-Core Version:    0.5.4
 */