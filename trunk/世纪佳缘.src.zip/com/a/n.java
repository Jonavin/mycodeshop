package com.a;

public class n
  implements af
{
  private static final String[] h;
  public final float a;
  public final float b;
  public final float c;
  public final double d;
  final o e;
  private final h g;

  static
  {
    int i = 71;
    int j = 57;
    int k = 30;
    Object localObject1 = 0;
    int l = 1;
    String[] arrayOfString = new String[4];
    char[] arrayOfChar1 = "7glX-p.uL.{z".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject20;
    Object localObject22;
    Object localObject7;
    Object localObject15;
    int i2;
    int i4;
    label116: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject14 = localObject1;
      localObject20 = localObject6;
      localObject22 = localObject14;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject14;
      localObject15 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject20)
      {
        i2 = localObject7[arrayOfChar1];
        i4 = localObject22 % 5;
        switch (i4)
        {
        default:
          i4 = 74;
          i2 = (char)(i2 ^ i4);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject22 + 1;
          if (localObject20 != 0)
            break;
          localObject7 = localObject15;
          localObject22 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject20;
      Object localObject23 = localObject15;
      localObject15 = localObject2;
      localObject3 = localObject23;
    }
    while (true)
    {
      if (localObject7 <= localObject15);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = ">&f\\w".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label296: Object localObject5;
      if (localObject8 <= l)
      {
        localObject15 = localObject1;
        localObject20 = localObject8;
        localObject22 = localObject15;
        localObject9 = localObject3;
        Object localObject24 = localObject15;
        localObject15 = localObject3;
        Object localObject4;
        for (localObject3 = localObject24; ; localObject4 = localObject20)
        {
          i2 = localObject9[localObject3];
          i4 = localObject22 % 5;
          switch (i4)
          {
          default:
            i4 = 74;
            i2 = (char)(i2 ^ i4);
            localObject9[localObject3] = i2;
            localObject4 = localObject22 + 1;
            if (localObject20 != 0)
              break;
            localObject9 = localObject15;
            localObject22 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject20;
        Object localObject25 = localObject15;
        localObject15 = localObject4;
        localObject5 = localObject25;
      }
      while (true)
      {
        if (localObject9 <= localObject15);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "2g".toCharArray();
        Object localObject16 = localObject9.length;
        Object localObject17;
        Object localObject21;
        int i5;
        label480: Object localObject11;
        if (localObject16 <= l)
        {
          localObject20 = localObject1;
          localObject22 = localObject16;
          i2 = localObject20;
          localObject17 = localObject9;
          Object localObject26 = localObject20;
          localObject21 = localObject9;
          Object localObject10;
          for (localObject9 = localObject26; ; localObject10 = localObject22)
          {
            i4 = localObject17[localObject9];
            i5 = i2 % 5;
            switch (i5)
            {
            default:
              i5 = 74;
              i4 = (char)(i4 ^ i5);
              localObject17[localObject9] = i4;
              localObject10 = i2 + 1;
              if (localObject22 != 0)
                break;
              localObject17 = localObject21;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject17 = localObject22;
          Object localObject27 = localObject21;
          localObject21 = localObject10;
          localObject11 = localObject27;
        }
        while (true)
        {
          if (localObject17 <= localObject21);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "s4".toCharArray();
          Object localObject18 = localObject11.length;
          label664: Object localObject13;
          if (localObject18 <= l)
          {
            localObject21 = localObject1;
            localObject22 = localObject18;
            int i3 = localObject21;
            localObject19 = localObject11;
            Object localObject28 = localObject21;
            localObject21 = localObject11;
            Object localObject12;
            for (localObject11 = localObject28; ; localObject12 = localObject22)
            {
              i4 = localObject19[localObject11];
              i5 = i3 % 5;
              switch (i5)
              {
              default:
                i5 = 74;
                int i6 = (char)(i4 ^ i5);
                localObject19[localObject11] = i4;
                localObject12 = i3 + 1;
                if (localObject22 != 0)
                  break;
                localObject19 = localObject21;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject19 = localObject22;
            Object localObject29 = localObject21;
            localObject21 = localObject12;
            localObject13 = localObject29;
          }
          while (true)
          {
            if (localObject19 <= localObject21);
            String str = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            h = arrayOfString;
            return;
            i4 = k;
            break label116:
            i4 = i;
            break label116:
            i4 = l;
            break label116:
            i4 = j;
            break label116:
            i4 = k;
            break label296:
            i4 = i;
            break label296:
            i4 = l;
            break label296:
            i4 = j;
            break label296:
            i5 = k;
            break label480:
            i5 = i;
            break label480:
            i5 = l;
            break label480:
            i5 = j;
            break label480:
            i5 = k;
            break label664:
            i5 = i;
            break label664:
            i5 = l;
            break label664:
            i5 = j;
            break label664:
            localObject21 = localObject1;
          }
          localObject21 = localObject1;
        }
        localObject19 = localObject1;
      }
      Object localObject19 = localObject1;
    }
  }

  n(o paramo, float paramFloat1, float paramFloat2, float paramFloat3, h paramh)
  {
    this.g = paramh;
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    float f1 = paramFloat1 * paramFloat1;
    float f2 = paramFloat2 * paramFloat2;
    float f3 = f1 + f2;
    float f4 = paramFloat3 * paramFloat3;
    double d1 = Math.sqrt(f3 + f4);
    Object localObject;
    this.d = localObject;
    if (bf.d != 0)
      if (i == 0)
        break label94;
    while (true)
    {
      boolean bool = o.b;
      label94: return;
    }
  }

  public double a()
  {
    return this.d;
  }

  public h e()
  {
    return this.g;
  }

  public String toString()
  {
    int i;
    o.b = i;
    Object localObject1 = new StringBuilder().append("(");
    int j = this.a;
    localObject1 = ((StringBuilder)localObject1).append(j);
    String str1 = h[2];
    localObject1 = ((StringBuilder)localObject1).append(str1);
    int k = this.b;
    localObject1 = ((StringBuilder)localObject1).append(k);
    String str2 = h[2];
    localObject1 = ((StringBuilder)localObject1).append(str2);
    int l = this.c;
    localObject1 = ((StringBuilder)localObject1).append(l);
    String str3 = h[null];
    localObject1 = ((StringBuilder)localObject1).append(str3);
    long l1 = this.d;
    localObject1 = ((StringBuilder)localObject1).append(l1);
    String str4 = h[1];
    localObject1 = ((StringBuilder)localObject1).append(str4);
    long l2 = this.g.c();
    Object localObject2;
    localObject1 = ((StringBuilder)localObject1).append(localObject2);
    String str5 = h[3];
    localObject1 = str5;
    if (i != 0)
    {
      int i1 = bf.d;
      ++i;
      bf.d = i1;
    }
    return (String)localObject1;
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.n
 * JD-Core Version:    0.5.4
 */