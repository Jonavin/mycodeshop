package com.a;

import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import java.lang.reflect.Method;

class ce
{
  private static final String[] c;
  final d a;
  private WifiManager.WifiLock b;

  static
  {
    int i = 45;
    int j = 25;
    int k = 7;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[11];
    char[] arrayOfChar1 = "Ld1Mp_b$\030nDa)\030uBd+".toCharArray();
    Object localObject8 = arrayOfChar1.length;
    Object localObject48;
    Object localObject50;
    Object localObject9;
    Object localObject31;
    int i3;
    int i12;
    label115: Object localObject3;
    if (localObject8 <= l)
    {
      Object localObject30 = localObject1;
      localObject48 = localObject8;
      localObject50 = localObject30;
      localObject9 = arrayOfChar1;
      char[] arrayOfChar3 = localObject30;
      localObject31 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar3; ; localObject2 = localObject48)
      {
        i3 = localObject9[arrayOfChar1];
        i12 = localObject50 % 5;
        switch (i12)
        {
        default:
          i12 = j;
          i3 = (char)(i3 ^ i12);
          localObject9[arrayOfChar1] = i3;
          localObject2 = localObject50 + 1;
          if (localObject48 != 0)
            break;
          localObject9 = localObject31;
          localObject50 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject9 = localObject48;
      Object localObject51 = localObject31;
      localObject31 = localObject2;
      localObject3 = localObject51;
    }
    while (true)
    {
      if (localObject9 <= localObject31);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "Nh5T}C 4\030xNv5QkH',WzF".toCharArray();
      Object localObject10 = localObject3.length;
      Object localObject11;
      label295: Object localObject5;
      if (localObject10 <= l)
      {
        localObject31 = localObject1;
        localObject48 = localObject10;
        localObject50 = localObject31;
        localObject11 = localObject3;
        Object localObject52 = localObject31;
        localObject31 = localObject3;
        Object localObject4;
        for (localObject3 = localObject52; ; localObject4 = localObject48)
        {
          i3 = localObject11[localObject3];
          i12 = localObject50 % 5;
          switch (i12)
          {
          default:
            i12 = j;
            i3 = (char)(i3 ^ i12);
            localObject11[localObject3] = i3;
            localObject4 = localObject50 + 1;
            if (localObject48 != 0)
              break;
            localObject11 = localObject31;
            localObject50 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject11 = localObject48;
        Object localObject53 = localObject31;
        localObject31 = localObject4;
        localObject5 = localObject53;
      }
      while (true)
      {
        if (localObject11 <= localObject31);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject11 = "Nh5T}C 4\030hXb2A9Ah#S9^s!Ll^".toCharArray();
        Object localObject32 = localObject11.length;
        Object localObject33;
        Object localObject49;
        int i13;
        label475: Object localObject13;
        if (localObject32 <= l)
        {
          localObject48 = localObject1;
          localObject50 = localObject32;
          i3 = localObject48;
          localObject33 = localObject11;
          Object localObject54 = localObject48;
          localObject49 = localObject11;
          Object localObject12;
          for (localObject11 = localObject54; ; localObject12 = localObject50)
          {
            i12 = localObject33[localObject11];
            i13 = i3 % 5;
            switch (i13)
            {
            default:
              i13 = j;
              i12 = (char)(i12 ^ i13);
              localObject33[localObject11] = i12;
              localObject12 = i3 + 1;
              if (localObject50 != 0)
                break;
              localObject33 = localObject49;
              i3 = localObject12;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject33 = localObject50;
          Object localObject55 = localObject49;
          localObject49 = localObject12;
          localObject13 = localObject55;
        }
        while (true)
        {
          if (localObject33 <= localObject49);
          localObject13 = new String(localObject13).intern();
          arrayOfString[i1] = localObject13;
          i1 = 3;
          localObject13 = "Nh5T}C 4\030kHk%YjH',WzF".toCharArray();
          Object localObject34 = localObject13.length;
          Object localObject35;
          label659: Object localObject15;
          if (localObject34 <= l)
          {
            localObject49 = localObject1;
            localObject50 = localObject34;
            int i4 = localObject49;
            localObject35 = localObject13;
            Object localObject56 = localObject49;
            localObject49 = localObject13;
            Object localObject14;
            for (localObject13 = localObject56; ; localObject14 = localObject50)
            {
              i12 = localObject35[localObject13];
              i13 = i4 % 5;
              switch (i13)
              {
              default:
                i13 = j;
                i12 = (char)(i12 ^ i13);
                localObject35[localObject13] = i12;
                localObject14 = i4 + 1;
                if (localObject50 != 0)
                  break;
                localObject35 = localObject49;
                i4 = localObject14;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject35 = localObject50;
            Object localObject57 = localObject49;
            localObject49 = localObject14;
            localObject15 = localObject57;
          }
          while (true)
          {
            if (localObject35 <= localObject49);
            localObject15 = new String(localObject15).intern();
            arrayOfString[i1] = localObject15;
            i1 = 4;
            localObject15 = "_b,]x^b$\030nDa)\030uBd+".toCharArray();
            Object localObject36 = localObject15.length;
            Object localObject37;
            label843: Object localObject17;
            if (localObject36 <= l)
            {
              localObject49 = localObject1;
              localObject50 = localObject36;
              int i5 = localObject49;
              localObject37 = localObject15;
              Object localObject58 = localObject49;
              localObject49 = localObject15;
              Object localObject16;
              for (localObject15 = localObject58; ; localObject16 = localObject50)
              {
                i12 = localObject37[localObject15];
                i13 = i5 % 5;
                switch (i13)
                {
                default:
                  i13 = j;
                  i12 = (char)(i12 ^ i13);
                  localObject37[localObject15] = i12;
                  localObject16 = i5 + 1;
                  if (localObject50 != 0)
                    break;
                  localObject37 = localObject49;
                  i5 = localObject16;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject37 = localObject50;
              Object localObject59 = localObject49;
              localObject49 = localObject16;
              localObject17 = localObject59;
            }
            while (true)
            {
              if (localObject37 <= localObject49);
              localObject17 = new String(localObject17).intern();
              arrayOfString[i1] = localObject17;
              i1 = 5;
              localObject17 = "Nh5T}C 4\030pCq/S|\rp)^p\rk/[r\rp)Lq\rP\t~PrJ\017|\\rT\003yWrH\016t@".toCharArray();
              Object localObject38 = localObject17.length;
              Object localObject39;
              label1027: Object localObject19;
              if (localObject38 <= l)
              {
                localObject49 = localObject1;
                localObject50 = localObject38;
                int i6 = localObject49;
                localObject39 = localObject17;
                Object localObject60 = localObject49;
                localObject49 = localObject17;
                Object localObject18;
                for (localObject17 = localObject60; ; localObject18 = localObject50)
                {
                  i12 = localObject39[localObject17];
                  i13 = i6 % 5;
                  switch (i13)
                  {
                  default:
                    i13 = j;
                    i12 = (char)(i12 ^ i13);
                    localObject39[localObject17] = i12;
                    localObject18 = i6 + 1;
                    if (localObject50 != 0)
                      break;
                    localObject39 = localObject49;
                    i6 = localObject18;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject39 = localObject50;
                Object localObject61 = localObject49;
                localObject49 = localObject18;
                localObject19 = localObject61;
              }
              while (true)
              {
                if (localObject39 <= localObject49);
                localObject19 = new String(localObject19).intern();
                arrayOfString[i1] = localObject19;
                i1 = 6;
                localObject19 = "Nh5T}C 4\030z_b!L|\rf`OpKn`TvNl".toCharArray();
                Object localObject40 = localObject19.length;
                Object localObject41;
                label1211: Object localObject21;
                if (localObject40 <= l)
                {
                  localObject49 = localObject1;
                  localObject50 = localObject40;
                  int i7 = localObject49;
                  localObject41 = localObject19;
                  Object localObject62 = localObject49;
                  localObject49 = localObject19;
                  Object localObject20;
                  for (localObject19 = localObject62; ; localObject20 = localObject50)
                  {
                    i12 = localObject41[localObject19];
                    i13 = i7 % 5;
                    switch (i13)
                    {
                    default:
                      i13 = j;
                      i12 = (char)(i12 ^ i13);
                      localObject41[localObject19] = i12;
                      localObject20 = i7 + 1;
                      if (localObject50 != 0)
                        break;
                      localObject41 = localObject49;
                      i7 = localObject20;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject41 = localObject50;
                  Object localObject63 = localObject49;
                  localObject49 = localObject20;
                  localObject21 = localObject63;
                }
                while (true)
                {
                  if (localObject41 <= localObject49);
                  localObject41 = new String(localObject21);
                  localObject21 = ((String)localObject41).intern();
                  arrayOfString[i1] = localObject21;
                  char[] arrayOfChar2 = "Nu%YmHc`OpKn`TvNl".toCharArray();
                  Object localObject22 = arrayOfChar2.length;
                  Object localObject23;
                  label1395: Object localObject7;
                  if (localObject22 <= l)
                  {
                    localObject41 = localObject1;
                    localObject49 = localObject22;
                    localObject50 = localObject41;
                    localObject23 = arrayOfChar2;
                    char[] arrayOfChar4 = localObject41;
                    localObject41 = arrayOfChar2;
                    Object localObject6;
                    for (arrayOfChar2 = arrayOfChar4; ; localObject6 = localObject49)
                    {
                      int i8 = localObject23[arrayOfChar2];
                      i12 = localObject50 % 5;
                      switch (i12)
                      {
                      default:
                        i12 = j;
                        i8 = (char)(i8 ^ i12);
                        localObject23[arrayOfChar2] = i8;
                        localObject6 = localObject50 + 1;
                        if (localObject49 != 0)
                          break;
                        localObject23 = localObject41;
                        localObject50 = localObject6;
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      }
                    }
                    localObject23 = localObject49;
                    Object localObject64 = localObject41;
                    localObject41 = localObject6;
                    localObject7 = localObject64;
                  }
                  while (true)
                  {
                    if (localObject23 <= localObject41);
                    localObject7 = new String(localObject7).intern();
                    arrayOfString[k] = localObject7;
                    int i2 = 8;
                    localObject23 = "Nu%YmHc`oPkN\037uViB\037kZlI\037wWa^`OpKn`TvNl".toCharArray();
                    Object localObject42 = localObject23.length;
                    Object localObject43;
                    label1579: Object localObject25;
                    if (localObject42 <= l)
                    {
                      localObject49 = localObject1;
                      localObject50 = localObject42;
                      int i9 = localObject49;
                      localObject43 = localObject23;
                      Object localObject65 = localObject49;
                      localObject49 = localObject23;
                      Object localObject24;
                      for (localObject23 = localObject65; ; localObject24 = localObject50)
                      {
                        i12 = localObject43[localObject23];
                        i13 = i9 % 5;
                        switch (i13)
                        {
                        default:
                          i13 = j;
                          i12 = (char)(i12 ^ i13);
                          localObject43[localObject23] = i12;
                          localObject24 = i9 + 1;
                          if (localObject50 != 0)
                            break;
                          localObject43 = localObject49;
                          i9 = localObject24;
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        }
                      }
                      localObject43 = localObject50;
                      Object localObject66 = localObject49;
                      localObject49 = localObject24;
                      localObject25 = localObject66;
                    }
                    while (true)
                    {
                      if (localObject43 <= localObject49);
                      localObject25 = new String(localObject25).intern();
                      arrayOfString[i2] = localObject25;
                      i2 = 9;
                      localObject25 = "Nu%YmHP)^pah#S".toCharArray();
                      Object localObject44 = localObject25.length;
                      Object localObject45;
                      label1763: Object localObject27;
                      if (localObject44 <= l)
                      {
                        localObject49 = localObject1;
                        localObject50 = localObject44;
                        int i10 = localObject49;
                        localObject45 = localObject25;
                        Object localObject67 = localObject49;
                        localObject49 = localObject25;
                        Object localObject26;
                        for (localObject25 = localObject67; ; localObject26 = localObject50)
                        {
                          i12 = localObject45[localObject25];
                          i13 = i10 % 5;
                          switch (i13)
                          {
                          default:
                            i13 = j;
                            i12 = (char)(i12 ^ i13);
                            localObject45[localObject25] = i12;
                            localObject26 = i10 + 1;
                            if (localObject50 != 0)
                              break;
                            localObject45 = localObject49;
                            i10 = localObject26;
                          case 0:
                          case 1:
                          case 2:
                          case 3:
                          }
                        }
                        localObject45 = localObject50;
                        Object localObject68 = localObject49;
                        localObject49 = localObject26;
                        localObject27 = localObject68;
                      }
                      while (true)
                      {
                        if (localObject45 <= localObject49);
                        localObject27 = new String(localObject27).intern();
                        arrayOfString[i2] = localObject27;
                        i2 = 10;
                        localObject27 = "~l9PvBl``I~'\027QD'\fWzF".toCharArray();
                        Object localObject46 = localObject27.length;
                        label1947: Object localObject29;
                        if (localObject46 <= l)
                        {
                          localObject49 = localObject1;
                          localObject50 = localObject46;
                          int i11 = localObject49;
                          localObject47 = localObject27;
                          Object localObject69 = localObject49;
                          localObject49 = localObject27;
                          Object localObject28;
                          for (localObject27 = localObject69; ; localObject28 = localObject50)
                          {
                            i12 = localObject47[localObject27];
                            i13 = i11 % 5;
                            switch (i13)
                            {
                            default:
                              i13 = j;
                              int i14 = (char)(i12 ^ i13);
                              localObject47[localObject27] = i12;
                              localObject28 = i11 + 1;
                              if (localObject50 != 0)
                                break;
                              localObject47 = localObject49;
                              i11 = localObject28;
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            }
                          }
                          localObject47 = localObject50;
                          Object localObject70 = localObject49;
                          localObject49 = localObject28;
                          localObject29 = localObject70;
                        }
                        while (true)
                        {
                          if (localObject47 <= localObject49);
                          String str = new String(localObject29).intern();
                          arrayOfString[i2] = localObject29;
                          c = arrayOfString;
                          return;
                          i12 = i;
                          break label115:
                          i12 = k;
                          break label115:
                          i12 = 64;
                          break label115:
                          i12 = 56;
                          break label115:
                          i12 = i;
                          break label295:
                          i12 = k;
                          break label295:
                          i12 = 64;
                          break label295:
                          i12 = 56;
                          break label295:
                          i13 = i;
                          break label475:
                          i13 = k;
                          break label475:
                          i13 = 64;
                          break label475:
                          i13 = 56;
                          break label475:
                          i13 = i;
                          break label659:
                          i13 = k;
                          break label659:
                          i13 = 64;
                          break label659:
                          i13 = 56;
                          break label659:
                          i13 = i;
                          break label843:
                          i13 = k;
                          break label843:
                          i13 = 64;
                          break label843:
                          i13 = 56;
                          break label843:
                          i13 = i;
                          break label1027:
                          i13 = k;
                          break label1027:
                          i13 = 64;
                          break label1027:
                          i13 = 56;
                          break label1027:
                          i13 = i;
                          break label1211:
                          i13 = k;
                          break label1211:
                          i13 = 64;
                          break label1211:
                          i13 = 56;
                          break label1211:
                          i12 = i;
                          break label1395:
                          i12 = k;
                          break label1395:
                          i12 = 64;
                          break label1395:
                          i12 = 56;
                          break label1395:
                          i13 = i;
                          break label1579:
                          i13 = k;
                          break label1579:
                          i13 = 64;
                          break label1579:
                          i13 = 56;
                          break label1579:
                          i13 = i;
                          break label1763:
                          i13 = k;
                          break label1763:
                          i13 = 64;
                          break label1763:
                          i13 = 56;
                          break label1763:
                          i13 = i;
                          break label1947:
                          i13 = k;
                          break label1947:
                          i13 = 64;
                          break label1947:
                          i13 = 56;
                          break label1947:
                          localObject49 = localObject1;
                        }
                        localObject49 = localObject1;
                      }
                      localObject49 = localObject1;
                    }
                    localObject47 = localObject1;
                  }
                  localObject49 = localObject1;
                }
                localObject49 = localObject1;
              }
              localObject49 = localObject1;
            }
            localObject49 = localObject1;
          }
          localObject49 = localObject1;
        }
        localObject47 = localObject1;
      }
      Object localObject47 = localObject1;
    }
  }

  ce(d paramd, WifiManager paramWifiManager)
  {
    try
    {
      String str1 = c[9];
      Class[] arrayOfClass = new Class[2];
      Class localClass = Integer.TYPE;
      arrayOfClass[0] = localClass;
      arrayOfClass[1] = String.class;
      Method localMethod = WifiManager.class.getMethod(str1, arrayOfClass);
      Object[] arrayOfObject = new Object[2];
      Integer localInteger = Integer.valueOf(2);
      arrayOfObject[0] = localInteger;
      String str2 = c[10];
      arrayOfObject[1] = str2;
      WifiManager.WifiLock localWifiLock1 = (WifiManager.WifiLock)localMethod.invoke(paramWifiManager, arrayOfObject);
      this.b = localWifiLock1;
      ag localag1 = d.a(paramd);
      String str3 = c[8];
      localag1.b(str3);
      this.b.setReferenceCounted(null);
      label129: return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      ag localag2 = d.a(paramd);
      String str4 = c[5];
      localag2.b(str4);
      String str5 = c[10];
      WifiManager.WifiLock localWifiLock2 = paramWifiManager.createWifiLock(str5);
      this.b = localWifiLock2;
      ag localag3 = d.a(paramd);
      String str6 = c[7];
      localag3.b(str6);
    }
    catch (Throwable localThrowable)
    {
      ag localag4 = d.a(paramd);
      String str7 = c[6];
      localag4.a(str7, localThrowable);
      this.b = null;
      break label129:
    }
  }

  public void a()
  {
    if (this.b != null);
    try
    {
      this.b.acquire();
      ag localag1 = d.a(this.a);
      String str1 = c[null];
      localag1.b(str1);
      return;
    }
    catch (Exception localException)
    {
      ag localag2 = d.a(this.a);
      String str2 = c[1];
      localag2.c(str2, localException);
    }
  }

  public void b()
  {
    if (c());
    try
    {
      this.b.release();
      ag localag1 = d.a(this.a);
      String str1 = c[4];
      localag1.b(str1);
      return;
    }
    catch (Exception localException)
    {
      ag localag2 = d.a(this.a);
      String str2 = c[3];
      localag2.a(str2, localException);
    }
  }

  public boolean c()
  {
    Object localObject1 = this.b;
    if (localObject1 != null);
    try
    {
      localObject1 = this.b.isHeld();
      return localObject1;
    }
    catch (Exception localObject2)
    {
      ag localag = d.a(this.a);
      String str = c[2];
      localag.c(str, localException);
      Object localObject2 = null;
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ce
 * JD-Core Version:    0.5.4
 */