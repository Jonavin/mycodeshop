package com.a;

import java.util.Comparator;

final class bw
  implements Comparator
{
  public int compare(Object paramObject1, Object paramObject2)
  {
    return ((Comparable)paramObject1).compareTo(paramObject2);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bw
 * JD-Core Version:    0.5.4
 */