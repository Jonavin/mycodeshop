package com.a;

import com.a.a.g;

public class bk
{
  public static double a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    // Byte code:
    //   0: getstatic 16	com/a/c:b	I
    //   3: istore 4
    //   5: dload_0
    //   6: ldc2_w 17
    //   9: dmul
    //   10: dstore_0
    //   11: dload_1
    //   12: ldc2_w 17
    //   15: dmul
    //   16: dstore 8
    //   18: dload_2
    //   19: ldc2_w 17
    //   22: dmul
    //   23: dstore 10
    //   25: dload_3
    //   26: ldc2_w 17
    //   29: dmul
    //   30: dstore 12
    //   32: dload_0
    //   33: invokestatic 24	java/lang/Math:sin	(D)D
    //   36: astore 14
    //   38: dload_2
    //   39: invokestatic 24	java/lang/Math:sin	(D)D
    //   42: astore 15
    //   44: dload 16
    //   46: dload 18
    //   48: dmul
    //   49: dstore 20
    //   51: dload_0
    //   52: invokestatic 27	java/lang/Math:cos	(D)D
    //   55: astore_0
    //   56: dload_2
    //   57: invokestatic 27	java/lang/Math:cos	(D)D
    //   60: astore 22
    //   62: dload_0
    //   63: dload_2
    //   64: dmul
    //   65: dstore_0
    //   66: dload_1
    //   67: dload_3
    //   68: dsub
    //   69: invokestatic 27	java/lang/Math:cos	(D)D
    //   72: astore 23
    //   74: dload_0
    //   75: dload_1
    //   76: dmul
    //   77: dload 20
    //   79: dadd
    //   80: invokestatic 30	java/lang/Math:acos	(D)D
    //   83: ldc2_w 31
    //   86: dmul
    //   87: dstore_0
    //   88: dload_0
    //   89: invokestatic 38	java/lang/Double:isNaN	(D)Z
    //   92: ifeq +9 -> 101
    //   95: ldc2_w 39
    //   98: lstore_0
    //   99: lload_0
    //   100: lreturn
    //   101: iload 4
    //   103: ifeq -4 -> 99
    //   106: getstatic 45	com/a/bf:d	I
    //   109: istore 24
    //   111: iinc 1 1
    //   114: iload 24
    //   116: putstatic 45	com/a/bf:d	I
    //   119: goto -20 -> 99
  }

  public static double a(g paramg1, g paramg2)
  {
    double d1 = paramg1.a_();
    double d2 = paramg1.b();
    double d3 = paramg2.a_();
    double d4 = paramg2.b();
    Object localObject1;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    return a(localObject1, localObject2, localObject3, localObject4);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.bk
 * JD-Core Version:    0.5.4
 */