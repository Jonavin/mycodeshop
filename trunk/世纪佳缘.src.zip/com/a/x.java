package com.a;

public class x extends RuntimeException
{
  public x(String paramString)
  {
    super(paramString);
  }

  public x(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.x
 * JD-Core Version:    0.5.4
 */