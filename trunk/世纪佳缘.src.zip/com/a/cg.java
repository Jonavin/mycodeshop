package com.a;

import android.location.LocationListener;
import android.os.Bundle;

final class cg
  implements LocationListener
{
  private static final String[] b;
  final u a;

  static
  {
    int i = 58;
    int j = 49;
    int k = 37;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[7];
    char[] arrayOfChar1 = "V I".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject32;
    Object localObject34;
    Object localObject7;
    Object localObject21;
    int i2;
    int i7;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject20 = localObject1;
      localObject32 = localObject6;
      localObject34 = localObject20;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject20;
      localObject21 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject32)
      {
        i2 = localObject7[arrayOfChar1];
        i7 = localObject34 % 5;
        switch (i7)
        {
        default:
          i7 = k;
          i2 = (char)(i2 ^ i7);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject34 + 1;
          if (localObject32 != 0)
            break;
          localObject7 = localObject21;
          localObject34 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject32;
      Object localObject35 = localObject21;
      localObject21 = localObject2;
      localObject3 = localObject35;
    }
    while (true)
    {
      if (localObject7 <= localObject21);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "^>v8FP$S8Kr8[9BT4\022".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject21 = localObject1;
        localObject32 = localObject8;
        localObject34 = localObject21;
        localObject9 = localObject3;
        Object localObject36 = localObject21;
        localObject21 = localObject3;
        Object localObject4;
        for (localObject3 = localObject36; ; localObject4 = localObject32)
        {
          i2 = localObject9[localObject3];
          i7 = localObject34 % 5;
          switch (i7)
          {
          default:
            i7 = k;
            i2 = (char)(i2 ^ i7);
            localObject9[localObject3] = i2;
            localObject4 = localObject34 + 1;
            if (localObject32 != 0)
              break;
            localObject9 = localObject21;
            localObject34 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject32;
        Object localObject37 = localObject21;
        localObject21 = localObject4;
        localObject5 = localObject37;
      }
      while (true)
      {
        if (localObject9 <= localObject21);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "X7T8WX>]w\025\034#[#\005W9B".toCharArray();
        Object localObject22 = localObject9.length;
        Object localObject23;
        Object localObject33;
        int i8;
        label475: Object localObject11;
        if (localObject22 <= l)
        {
          localObject32 = localObject1;
          localObject34 = localObject22;
          i2 = localObject32;
          localObject23 = localObject9;
          Object localObject38 = localObject32;
          localObject33 = localObject9;
          Object localObject10;
          for (localObject9 = localObject38; ; localObject10 = localObject34)
          {
            i7 = localObject23[localObject9];
            i8 = i2 % 5;
            switch (i8)
            {
            default:
              i8 = k;
              i7 = (char)(i7 ^ i8);
              localObject23[localObject9] = i7;
              localObject10 = i2 + 1;
              if (localObject34 != 0)
                break;
              localObject23 = localObject33;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject23 = localObject34;
          Object localObject39 = localObject33;
          localObject33 = localObject10;
          localObject11 = localObject39;
        }
        while (true)
        {
          if (localObject23 <= localObject33);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "X7T8WX>]wL_&[;LUpV8FP$S8K".toCharArray();
          Object localObject24 = localObject11.length;
          Object localObject25;
          label659: Object localObject13;
          if (localObject24 <= l)
          {
            localObject33 = localObject1;
            localObject34 = localObject24;
            int i3 = localObject33;
            localObject25 = localObject11;
            Object localObject40 = localObject33;
            localObject33 = localObject11;
            Object localObject12;
            for (localObject11 = localObject40; ; localObject12 = localObject34)
            {
              i7 = localObject25[localObject11];
              i8 = i3 % 5;
              switch (i8)
              {
              default:
                i8 = k;
                i7 = (char)(i7 ^ i8);
                localObject25[localObject11] = i7;
                localObject12 = i3 + 1;
                if (localObject34 != 0)
                  break;
                localObject25 = localObject33;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject25 = localObject34;
            Object localObject41 = localObject33;
            localObject33 = localObject12;
            localObject13 = localObject41;
          }
          while (true)
          {
            if (localObject25 <= localObject33);
            localObject13 = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            i1 = 4;
            localObject13 = "^>i#DE%I\024MP>]2A\031".toCharArray();
            Object localObject26 = localObject13.length;
            Object localObject27;
            label843: Object localObject15;
            if (localObject26 <= l)
            {
              localObject33 = localObject1;
              localObject34 = localObject26;
              int i4 = localObject33;
              localObject27 = localObject13;
              Object localObject42 = localObject33;
              localObject33 = localObject13;
              Object localObject14;
              for (localObject13 = localObject42; ; localObject14 = localObject34)
              {
                i7 = localObject27[localObject13];
                i8 = i4 % 5;
                switch (i8)
                {
                default:
                  i8 = k;
                  i7 = (char)(i7 ^ i8);
                  localObject27[localObject13] = i7;
                  localObject14 = i4 + 1;
                  if (localObject34 != 0)
                    break;
                  localObject27 = localObject33;
                  i4 = localObject14;
                case 0:
                case 1:
                case 2:
                case 3:
                }
              }
              localObject27 = localObject34;
              Object localObject43 = localObject33;
              localObject33 = localObject14;
              localObject15 = localObject43;
            }
            while (true)
            {
              if (localObject27 <= localObject33);
              localObject15 = new String(localObject15).intern();
              arrayOfString[i1] = localObject15;
              i1 = 5;
              localObject15 = "^>j%JG9^2Wt>[5IT4\022".toCharArray();
              Object localObject28 = localObject15.length;
              Object localObject29;
              label1027: Object localObject17;
              if (localObject28 <= l)
              {
                localObject33 = localObject1;
                localObject34 = localObject28;
                int i5 = localObject33;
                localObject29 = localObject15;
                Object localObject44 = localObject33;
                localObject33 = localObject15;
                Object localObject16;
                for (localObject15 = localObject44; ; localObject16 = localObject34)
                {
                  i7 = localObject29[localObject15];
                  i8 = i5 % 5;
                  switch (i8)
                  {
                  default:
                    i8 = k;
                    i7 = (char)(i7 ^ i8);
                    localObject29[localObject15] = i7;
                    localObject16 = i5 + 1;
                    if (localObject34 != 0)
                      break;
                    localObject29 = localObject33;
                    i5 = localObject16;
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
                }
                localObject29 = localObject34;
                Object localObject45 = localObject33;
                localObject33 = localObject16;
                localObject17 = localObject45;
              }
              while (true)
              {
                if (localObject29 <= localObject33);
                localObject17 = new String(localObject17).intern();
                arrayOfString[i1] = localObject17;
                i1 = 6;
                localObject17 = "^>j%JG9^2Wu9I6G]5^".toCharArray();
                Object localObject30 = localObject17.length;
                label1211: Object localObject19;
                if (localObject30 <= l)
                {
                  localObject33 = localObject1;
                  localObject34 = localObject30;
                  int i6 = localObject33;
                  localObject31 = localObject17;
                  Object localObject46 = localObject33;
                  localObject33 = localObject17;
                  Object localObject18;
                  for (localObject17 = localObject46; ; localObject18 = localObject34)
                  {
                    i7 = localObject31[localObject17];
                    i8 = i6 % 5;
                    switch (i8)
                    {
                    default:
                      i8 = k;
                      int i9 = (char)(i7 ^ i8);
                      localObject31[localObject17] = i7;
                      localObject18 = i6 + 1;
                      if (localObject34 != 0)
                        break;
                      localObject31 = localObject33;
                      i6 = localObject18;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    }
                  }
                  localObject31 = localObject34;
                  Object localObject47 = localObject33;
                  localObject33 = localObject18;
                  localObject19 = localObject47;
                }
                while (true)
                {
                  if (localObject31 <= localObject33);
                  String str = new String(localObject19).intern();
                  arrayOfString[i1] = localObject19;
                  b = arrayOfString;
                  return;
                  i7 = j;
                  break label115:
                  i7 = 80;
                  break label115:
                  i7 = i;
                  break label115:
                  i7 = 87;
                  break label115:
                  i7 = j;
                  break label295:
                  i7 = 80;
                  break label295:
                  i7 = i;
                  break label295:
                  i7 = 87;
                  break label295:
                  i8 = j;
                  break label475:
                  i8 = 80;
                  break label475:
                  i8 = i;
                  break label475:
                  i8 = 87;
                  break label475:
                  i8 = j;
                  break label659:
                  i8 = 80;
                  break label659:
                  i8 = i;
                  break label659:
                  i8 = 87;
                  break label659:
                  i8 = j;
                  break label843:
                  i8 = 80;
                  break label843:
                  i8 = i;
                  break label843:
                  i8 = 87;
                  break label843:
                  i8 = j;
                  break label1027:
                  i8 = 80;
                  break label1027:
                  i8 = i;
                  break label1027:
                  i8 = 87;
                  break label1027:
                  i8 = j;
                  break label1211:
                  i8 = 80;
                  break label1211:
                  i8 = i;
                  break label1211:
                  i8 = 87;
                  break label1211:
                  localObject33 = localObject1;
                }
                localObject33 = localObject1;
              }
              localObject33 = localObject1;
            }
            localObject33 = localObject1;
          }
          localObject33 = localObject1;
        }
        localObject31 = localObject1;
      }
      Object localObject31 = localObject1;
    }
  }

  private cg(u paramu)
  {
  }

  cg(u paramu, cf paramcf)
  {
    this(paramu);
  }

  // ERROR //
  public void onLocationChanged(android.location.Location paramLocation)
  {
    // Byte code:
    //   0: ldc2_w 53
    //   3: lstore_2
    //   4: aload_0
    //   5: getfield 45	com/a/cg:a	Lcom/a/u;
    //   8: invokestatic 59	com/a/u:b	(Lcom/a/u;)Lcom/a/ag;
    //   11: invokevirtual 64	com/a/ag:a	()Z
    //   14: astore 4
    //   16: iload 4
    //   18: ifeq +79 -> 97
    //   21: aload_0
    //   22: getfield 45	com/a/cg:a	Lcom/a/u;
    //   25: invokestatic 59	com/a/u:b	(Lcom/a/u;)Lcom/a/ag;
    //   28: astore 4
    //   30: new 66	java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   37: astore 5
    //   39: getstatic 42	com/a/cg:b	[Ljava/lang/String;
    //   42: iconst_1
    //   43: aaload
    //   44: astore 6
    //   46: aload 5
    //   48: aload 6
    //   50: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: astore 5
    //   55: aload_0
    //   56: getfield 45	com/a/cg:a	Lcom/a/u;
    //   59: invokestatic 75	com/a/u:c	(Lcom/a/u;)Ljava/lang/String;
    //   62: astore 7
    //   64: aload 5
    //   66: aload 7
    //   68: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: ldc 77
    //   73: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: aload_1
    //   77: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   80: ldc 82
    //   82: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   88: astore 5
    //   90: aload 4
    //   92: aload 5
    //   94: invokevirtual 88	com/a/ag:b	(Ljava/lang/String;)V
    //   97: aload_1
    //   98: ifnull +29 -> 127
    //   101: aload_1
    //   102: invokevirtual 94	android/location/Location:getLatitude	()D
    //   105: dload_2
    //   106: dcmpl
    //   107: dstore 8
    //   109: iload 4
    //   111: ifne +40 -> 151
    //   114: aload_1
    //   115: invokevirtual 97	android/location/Location:getLongitude	()D
    //   118: dload_2
    //   119: dcmpl
    //   120: dstore 8
    //   122: iload 4
    //   124: ifne +27 -> 151
    //   127: aload_0
    //   128: getfield 45	com/a/cg:a	Lcom/a/u;
    //   131: invokestatic 59	com/a/u:b	(Lcom/a/u;)Lcom/a/ag;
    //   134: astore 10
    //   136: getstatic 42	com/a/cg:b	[Ljava/lang/String;
    //   139: iconst_3
    //   140: aaload
    //   141: astore 11
    //   143: aload 10
    //   145: aload 11
    //   147: invokevirtual 88	com/a/ag:b	(Ljava/lang/String;)V
    //   150: return
    //   151: aload_0
    //   152: getfield 45	com/a/cg:a	Lcom/a/u;
    //   155: astore 4
    //   157: aload 4
    //   159: monitorenter
    //   160: aload_1
    //   161: invokestatic 100	com/a/u:a	(Landroid/location/Location;)Lcom/a/a/be;
    //   164: astore 5
    //   166: invokestatic 106	com/a/h:d	()Lcom/a/h;
    //   169: astore 12
    //   171: aload 5
    //   173: aload 12
    //   175: invokevirtual 111	com/a/a/be:a	(Lcom/a/h;)V
    //   178: aload_0
    //   179: getfield 45	com/a/cg:a	Lcom/a/u;
    //   182: invokestatic 75	com/a/u:c	(Lcom/a/u;)Ljava/lang/String;
    //   185: astore 13
    //   187: getstatic 42	com/a/cg:b	[Ljava/lang/String;
    //   190: aconst_null
    //   191: aaload
    //   192: astore 14
    //   194: aload 13
    //   196: aload 14
    //   198: if_icmpne +128 -> 326
    //   201: aload_0
    //   202: getfield 45	com/a/cg:a	Lcom/a/u;
    //   205: invokestatic 114	com/a/u:d	(Lcom/a/u;)Lcom/a/bz;
    //   208: ifnull +22 -> 230
    //   211: aload_0
    //   212: getfield 45	com/a/cg:a	Lcom/a/u;
    //   215: invokestatic 114	com/a/u:d	(Lcom/a/u;)Lcom/a/bz;
    //   218: invokevirtual 119	com/a/bz:c	()I
    //   221: astore 15
    //   223: aload 5
    //   225: iload 15
    //   227: invokevirtual 122	com/a/a/be:d	(I)V
    //   230: aload 5
    //   232: invokevirtual 125	com/a/a/be:g	()I
    //   235: ifne +83 -> 318
    //   238: aload_0
    //   239: getfield 45	com/a/cg:a	Lcom/a/u;
    //   242: invokestatic 129	com/a/u:e	(Lcom/a/u;)Lcom/a/a/be;
    //   245: ifnull +73 -> 318
    //   248: aload_0
    //   249: getfield 45	com/a/cg:a	Lcom/a/u;
    //   252: invokestatic 129	com/a/u:e	(Lcom/a/u;)Lcom/a/a/be;
    //   255: invokevirtual 125	com/a/a/be:g	()I
    //   258: ifle +60 -> 318
    //   261: aload_0
    //   262: getfield 45	com/a/cg:a	Lcom/a/u;
    //   265: invokestatic 129	com/a/u:e	(Lcom/a/u;)Lcom/a/a/be;
    //   268: invokevirtual 131	com/a/a/be:e	()Lcom/a/h;
    //   271: invokevirtual 134	com/a/h:c	()J
    //   274: ldc2_w 135
    //   277: lcmp
    //   278: ifge +40 -> 318
    //   281: aload_0
    //   282: getfield 45	com/a/cg:a	Lcom/a/u;
    //   285: invokestatic 59	com/a/u:b	(Lcom/a/u;)Lcom/a/ag;
    //   288: astore 5
    //   290: getstatic 42	com/a/cg:b	[Ljava/lang/String;
    //   293: iconst_2
    //   294: aaload
    //   295: astore 16
    //   297: aload 5
    //   299: aload 16
    //   301: invokevirtual 88	com/a/ag:b	(Ljava/lang/String;)V
    //   304: aload 4
    //   306: monitorexit
    //   307: goto -157 -> 150
    //   310: astore 5
    //   312: aload 4
    //   314: monitorexit
    //   315: aload 5
    //   317: athrow
    //   318: aload 5
    //   320: invokevirtual 140	com/a/a/be:o	()Lcom/a/a/be;
    //   323: invokestatic 145	com/a/br:a	(Lcom/a/a/be;)V
    //   326: aload_0
    //   327: getfield 45	com/a/cg:a	Lcom/a/u;
    //   330: aload 5
    //   332: invokestatic 148	com/a/u:a	(Lcom/a/u;Lcom/a/a/be;)Lcom/a/a/be;
    //   335: pop
    //   336: aload_0
    //   337: getfield 45	com/a/cg:a	Lcom/a/u;
    //   340: astore 5
    //   342: aload 5
    //   344: invokestatic 151	com/a/u:f	(Lcom/a/u;)V
    //   347: aload 4
    //   349: monitorexit
    //   350: goto -200 -> 150
    //
    // Exception table:
    //   from	to	target	type
    //   160	315	310	finally
    //   318	350	310	finally
  }

  public void onProviderDisabled(String paramString)
  {
    if (!u.b(this.a).a())
      return;
    ag localag = u.b(this.a);
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = b[6];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = u.c(this.a);
    String str3 = str2 + ")";
    localag.b(str3);
  }

  public void onProviderEnabled(String paramString)
  {
    if (!u.b(this.a).a())
      return;
    ag localag = u.b(this.a);
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = b[5];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = u.c(this.a);
    String str3 = str2 + ")";
    localag.b(str3);
  }

  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
  {
    if (!u.b(this.a).a())
      return;
    ag localag = u.b(this.a);
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = b[4];
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = u.c(this.a);
    String str3 = str2 + "," + paramInt + "," + paramBundle + ")";
    localag.b(str3);
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.cg
 * JD-Core Version:    0.5.4
 */