package com.a;

public abstract class s extends bf
{
  public static boolean a;
  private static s b = null;

  public static s b(av paramav)
  {
    Object localObject = b;
    if (localObject == null);
    for (localObject = new p(paramav); ; localObject = b.a(paramav))
      return localObject;
  }

  public abstract s a(av paramav);

  public abstract void b();

  public abstract az c();

  public abstract void d();
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.s
 * JD-Core Version:    0.5.4
 */