package com.a;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import java.util.List;

class k
  implements SensorEventListener
{
  private static final String b;
  final j a;

  static
  {
    char[] arrayOfChar1 = "$\006,Y@5\f6\r\0054\0011\025@c\n4\026V&\r".toCharArray();
    Object localObject2 = arrayOfChar1.length;
    char[] arrayOfChar3 = 0;
    Object localObject4 = 1;
    int i;
    Object localObject3;
    char[] arrayOfChar4;
    int j;
    if (localObject2 <= localObject4)
    {
      localObject4 = localObject2;
      i = arrayOfChar3;
      localObject3 = arrayOfChar1;
      char[] arrayOfChar5 = arrayOfChar3;
      arrayOfChar4 = arrayOfChar1;
      arrayOfChar1 = arrayOfChar5;
      j = localObject3[arrayOfChar1];
      k = i % 5;
      switch (k)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    for (int k = 37; ; k = 121)
      while (true)
      {
        int l = (char)(j ^ k);
        localObject3[arrayOfChar1] = j;
        char[] arrayOfChar2 = i + 1;
        if (localObject4 == 0)
        {
          localObject3 = arrayOfChar4;
          i = arrayOfChar2;
          arrayOfChar2 = localObject4;
        }
        localObject3 = localObject4;
        char[] arrayOfChar6 = arrayOfChar4;
        arrayOfChar4 = arrayOfChar2;
        Object localObject1 = arrayOfChar6;
        if (localObject3 <= arrayOfChar4);
        b = new String(localObject1).intern();
        return;
        k = 67;
        continue;
        k = 105;
        continue;
        k = 88;
      }
  }

  k(j paramj)
  {
  }

  public void onAccuracyChanged(Sensor paramSensor, int paramInt)
  {
  }

  public void onSensorChanged(SensorEvent paramSensorEvent)
  {
    synchronized (this.a)
    {
      boolean bool = j.b(this.a);
      if (!bool)
      {
        localObject1 = j.c(this.a);
        String str = b;
        ((ag)localObject1).b(str);
        return;
      }
      List localList = j.d(this.a);
      j localj2 = this.a;
      int i = paramSensorEvent.values[null];
      int j = paramSensorEvent.values[1];
      int k = paramSensorEvent.values[2];
      h localh = h.d();
      Object localObject1 = new n(localj2, i, j, k, localh);
      localList.add(localObject1);
      localObject1 = this.a;
      j.e((j)localObject1);
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.k
 * JD-Core Version:    0.5.4
 */