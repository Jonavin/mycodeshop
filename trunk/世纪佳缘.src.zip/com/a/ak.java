package com.a;

import android.telephony.CellLocation;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.cdma.CdmaCellLocation;

class ak extends PhoneStateListener
{
  static final boolean a;
  private static final String[] c;
  final z b;

  static
  {
    int i = 67;
    int j = 31;
    int k = 23;
    int l = 1;
    Object localObject1 = 0;
    String[] arrayOfString = new String[4];
    char[] arrayOfChar1 = "\037;\024ro\016*\030y?\023-Wxq)&\005av\031&$c~\016&4~\024$\022s7S".toCharArray();
    Object localObject6 = arrayOfChar1.length;
    Object localObject20;
    Object localObject22;
    Object localObject7;
    Object localObject15;
    int i2;
    int i4;
    label115: Object localObject3;
    if (localObject6 <= l)
    {
      Object localObject14 = localObject1;
      localObject20 = localObject6;
      localObject22 = localObject14;
      localObject7 = arrayOfChar1;
      char[] arrayOfChar2 = localObject14;
      localObject15 = arrayOfChar1;
      Object localObject2;
      for (arrayOfChar1 = arrayOfChar2; ; localObject2 = localObject20)
      {
        i2 = localObject7[arrayOfChar1];
        i4 = localObject22 % 5;
        switch (i4)
        {
        default:
          i4 = j;
          i2 = (char)(i2 ^ i4);
          localObject7[arrayOfChar1] = i2;
          localObject2 = localObject22 + 1;
          if (localObject20 != 0)
            break;
          localObject7 = localObject15;
          localObject22 = localObject2;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      }
      localObject7 = localObject20;
      Object localObject23 = localObject15;
      localObject15 = localObject2;
      localObject3 = localObject23;
    }
    while (true)
    {
      if (localObject7 <= localObject15);
      localObject3 = new String(localObject3).intern();
      arrayOfString[localObject1] = localObject3;
      localObject3 = "\025-$rm\f*\024rL\016\"\003r\\\022\"\031pz\036k".toCharArray();
      Object localObject8 = localObject3.length;
      Object localObject9;
      label295: Object localObject5;
      if (localObject8 <= l)
      {
        localObject15 = localObject1;
        localObject20 = localObject8;
        localObject22 = localObject15;
        localObject9 = localObject3;
        Object localObject24 = localObject15;
        localObject15 = localObject3;
        Object localObject4;
        for (localObject3 = localObject24; ; localObject4 = localObject20)
        {
          i2 = localObject9[localObject3];
          i4 = localObject22 % 5;
          switch (i4)
          {
          default:
            i4 = j;
            i2 = (char)(i2 ^ i4);
            localObject9[localObject3] = i2;
            localObject4 = localObject22 + 1;
            if (localObject20 != 0)
              break;
            localObject9 = localObject15;
            localObject22 = localObject4;
          case 0:
          case 1:
          case 2:
          case 3:
          }
        }
        localObject9 = localObject20;
        Object localObject25 = localObject15;
        localObject15 = localObject4;
        localObject5 = localObject25;
      }
      while (true)
      {
        if (localObject9 <= localObject15);
        localObject5 = new String(localObject5).intern();
        arrayOfString[l] = localObject5;
        int i1 = 2;
        localObject9 = "\025-4rs\026\017\030t~\016*\030y\\\022\"\031pz\036k".toCharArray();
        Object localObject16 = localObject9.length;
        Object localObject17;
        Object localObject21;
        int i5;
        label475: Object localObject11;
        if (localObject16 <= l)
        {
          localObject20 = localObject1;
          localObject22 = localObject16;
          i2 = localObject20;
          localObject17 = localObject9;
          Object localObject26 = localObject20;
          localObject21 = localObject9;
          Object localObject10;
          for (localObject9 = localObject26; ; localObject10 = localObject22)
          {
            i4 = localObject17[localObject9];
            i5 = i2 % 5;
            switch (i5)
            {
            default:
              i5 = j;
              i4 = (char)(i4 ^ i5);
              localObject17[localObject9] = i4;
              localObject10 = i2 + 1;
              if (localObject22 != 0)
                break;
              localObject17 = localObject21;
              i2 = localObject10;
            case 0:
            case 1:
            case 2:
            case 3:
            }
          }
          localObject17 = localObject22;
          Object localObject27 = localObject21;
          localObject21 = localObject10;
          localObject11 = localObject27;
        }
        while (true)
        {
          if (localObject17 <= localObject21);
          localObject11 = new String(localObject11).intern();
          arrayOfString[i1] = localObject11;
          i1 = 3;
          localObject11 = "\037;\024ro\016*\030y?\023-Wxq9&\033{S\025 \026cv\025-4~\024$\022s".toCharArray();
          Object localObject18 = localObject11.length;
          label659: Object localObject13;
          if (localObject18 <= l)
          {
            localObject21 = localObject1;
            localObject22 = localObject18;
            int i3 = localObject21;
            localObject19 = localObject11;
            Object localObject28 = localObject21;
            localObject21 = localObject11;
            Object localObject12;
            for (localObject11 = localObject28; ; localObject12 = localObject22)
            {
              i4 = localObject19[localObject11];
              i5 = i3 % 5;
              switch (i5)
              {
              default:
                i5 = j;
                int i6 = (char)(i4 ^ i5);
                localObject19[localObject11] = i4;
                localObject12 = i3 + 1;
                if (localObject22 != 0)
                  break;
                localObject19 = localObject21;
                i3 = localObject12;
              case 0:
              case 1:
              case 2:
              case 3:
              }
            }
            localObject19 = localObject22;
            Object localObject29 = localObject21;
            localObject21 = localObject12;
            localObject13 = localObject29;
          }
          while (true)
          {
            if (localObject19 <= localObject21);
            String str = new String(localObject13).intern();
            arrayOfString[i1] = localObject13;
            c = arrayOfString;
            if (!z.class.desiredAssertionStatus())
              int i7 = l;
            while (true)
            {
              boolean bool = a;
              return;
              int i8 = localObject1;
            }
            i4 = 122;
            break label115:
            i4 = i;
            break label115:
            i4 = 119;
            break label115:
            i4 = k;
            break label115:
            i4 = 122;
            break label295:
            i4 = i;
            break label295:
            i4 = 119;
            break label295:
            i4 = k;
            break label295:
            i5 = 122;
            break label475:
            i5 = i;
            break label475:
            i5 = 119;
            break label475:
            i5 = k;
            break label475:
            i5 = 122;
            break label659:
            i5 = i;
            break label659:
            i5 = 119;
            break label659:
            i5 = k;
            break label659:
            localObject21 = localObject1;
          }
          localObject21 = localObject1;
        }
        localObject19 = localObject1;
      }
      Object localObject19 = localObject1;
    }
  }

  ak(z paramz)
  {
  }

  public void onCellLocationChanged(CellLocation paramCellLocation)
  {
    while (true)
    {
      try
      {
        boolean bool = z.b(this.b).a();
        ag localag1;
        if (bool)
        {
          localag1 = z.b(this.b);
          StringBuilder localStringBuilder = new StringBuilder();
          String str1 = c[2];
          String str2 = str1 + paramCellLocation + ")";
          localag1.b(str2);
        }
        a = localag1;
        if ((localag1 == 0) && (paramCellLocation != null) && (!paramCellLocation instanceof CdmaCellLocation))
          throw new AssertionError();
      }
      catch (Throwable localThrowable)
      {
        ag localag2 = z.b(this.b);
        String str3 = c[3];
        localag2.d(str3, localThrowable);
        return;
      }
      z localz = this.b;
      CdmaCellLocation localCdmaCellLocation = (CdmaCellLocation)paramCellLocation;
      z.a(localz, paramCellLocation);
    }
  }

  public void onServiceStateChanged(ServiceState paramServiceState)
  {
    int i = 1;
    Object localObject1 = null;
    int j;
    z.a = j;
    try
    {
      boolean bool1 = z.b(this.b).a();
      if (bool1)
      {
        localObject2 = z.b(this.b);
        StringBuilder localStringBuilder = new StringBuilder();
        String str1 = c[1];
        String str2 = str1 + paramServiceState + ")";
        ((ag)localObject2).b(str2);
      }
      Object localObject2 = paramServiceState.getState();
      switch (localObject2)
      {
      case 2:
      default:
        if (bf.d != 0)
        {
          label112: if (j == 0)
            break label173;
          Object localObject3 = localObject1;
          label126: boolean bool2 = z.a;
        }
        return;
      case 1:
      case 3:
      }
      label173: z.a(this.b, null);
    }
    catch (Throwable localThrowable)
    {
      ag localag = z.b(this.b);
      String str3 = c[localObject1];
      localag.d(str3, localThrowable);
      break label112:
      int k = i;
      break label126:
    }
  }
}

/* Location:           E:\apk\dex2java\classes.dex.dex2jar.jar
 * Qualified Name:     com.a.ak
 * JD-Core Version:    0.5.4
 */