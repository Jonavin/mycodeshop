Spring Android 1.0.0.M4 (July 21, 2011)
-----------------------------------------------------------
The Spring Android project provides support for developing Android based applications.

To find out what has changed in this release, see 'changelog.txt'

Please consult the documentation located within the 'docs/reference' directory
of this release and also visit the official Spring Android home at:
http://www.springsource.org/spring-android

There you will find links to the forum, issue tracker, and other resources.